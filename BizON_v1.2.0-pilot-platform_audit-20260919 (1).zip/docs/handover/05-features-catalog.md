# Каталог функций и интерфейса BizON

> Задача: H1-ui. Подготовлено для внешней GPT-команды аудита. Источник истины — исходный код
> репозитория /home/z/my-project (Next.js 16 App Router, TypeScript, Tailwind 4, shadcn/ui).
> Все ссылки `файл:строка` актуальны на момент написания (проверено чтением исходников).
> Обозначения статусов: **ГОТОВО** — реальное поведение с API/состоянием; **ЧАСТИЧНО** — работает,
> но с ограничениями/заглушками в части; **СТАБ** — только видимость действия (тост/«скоро»/no-op).
>
> Легенда API: все запросы идут через хелпер `api()` из `src/stores/app-store.ts:352-378`
> (fetch + cookie `bizon_session`, при !ok кидает Error с `.status` и `.data`).

---

## 0. Как устроено приложение (коротко)

- SPA внутри Next.js: один публичный маршрут `/` (`src/app/page.tsx`) рендерит `AppShell` и
  переключает «view» из zustand-стора (`src/stores/app-store.ts`). Отдельные URL-маршруты:
  `/search`, `/legal`, `/p/[token]` (публичный паспорт человека), `/c/[token]` (паспорт компании).
- Неавторизованным показывается `LandingPage` (`src/components/landing/landing-page.tsx`),
  из него — `AuthScreen` (`src/components/auth/auth-screen.tsx`).
- Авторизация определяется ТОЛЬКО сервером: `GET /api/auth/me` (`src/app/page.tsx:70`).
  Токен не хранится на клиенте — HttpOnly cookie (C5), см. `src/stores/app-store.ts:142-143,337`.

---

## 1. Карта навигации (полное дерево разделов/вкладок + как открываются)

### 1.1 TopBar (`src/components/shell/app-shell.tsx:194-270`)

| Элемент | Поведение | Статус |
|---|---|---|
| «Назад» (виден при непустой истории, app-shell:197-207) | `goBack()` — восстанавливает ПОЛНЫЙ снимок локации (view + подразделы + выборы) из `viewHistory` (app-store:313-328). Также Alt+← / Cmd+← (app-shell:139-158) | ГОТОВО |
| Логотип BizON (app-shell:209-218) | `setView('dashboard')` + сброс профиля | ГОТОВО |
| Поисковая строка (app-shell:221-251) | дебаунс 250 мс → `GET /api/users/search?q=…` (app-shell:169), дропдаун людей; клик → `setProfileUserId(id)` → просмотр профиля. Ищет только ЛЮДЕЙ (не компании/вакансии — для этого отдельная страница `/search`) | ГОТОВО (ограничен людьми) |
| AICoPilot — кнопка-ассистент (app-shell:254) | плавающий диалог AI (см. §2.30) | ГОТОВО |
| Bell — уведомления (app-shell:255, 717-775) | `GET /api/notifications` при открытии + каждые 30 с (app-shell:725,733); открытие дропдауна при unread>0 → `POST /api/notifications/read` (app-shell:739,747); список последних 10, элементы списка НЕ кликабельны (нет перехода к объекту уведомления) | ГОТОВО / ЧАСТИЧНО (нет переходов из уведомлений) |
| Тема light/dark (app-shell:256-258) | `next-themes` toggle | ГОТОВО |
| Аватар пользователя (app-shell:259-265) | `setView('profile')` + сброс `profileUserId` → свой профиль | ГОТОВО |
| Выход (app-shell:266-268) | `POST /api/auth/logout` + `logout()` (сброс стора) | ГОТОВО |

- ToS-баннер «Примите условия люмен-программы» (app-shell:273-300): ссылка `/legal` (новая вкладка),
  «Принимаю» → `PATCH /api/me/accept-tos` (app-shell:103), «X» — скрытие до конца сессии
  (sessionStorage). ГОТОВО.
- RightRail (app-shell:472-474, 787-866): «Найти контакт»→matchmaker (805), «Карта карьеры»→career (812),
  «AI-подбор вакансий»→jobs (819); `SubSectionBar` (830); `CompactCalendar` на view feed (833);
  рекламная карточка партнёра — `GET /api/ads` после 2 с (795), клик → `POST /api/ads {adId}` —
  фиксация клика, НО переход на сайт рекламодателя НЕ выполняется (только тост «Переход по рекламе
  зафиксирован», app-shell:838-853) — ЧАСТИЧНО (метрика пишется, пользователя никуда не ведёт).
- Версия «v10.0 MVP · Фаза 1» (app-shell:862) — текст.

### 1.2 Левый сайдбар (desktop) — меню-дерево (`app-shell.tsx:29-69, 336-461`)

Основной набор для `individual` (app-shell:31-38):
1. **Главная** → view `dashboard` (`DashboardView`)
2. **Новости** → view `feed` (`TrustStreamView`)
3. **Профиль** → view `profile`, `profileUserId=null` → рендерится `MeView` (см. §2.6)
4. **Компании** → view `companies`
5. **Работа** → view `jobs`
6. **Контакты** → view `network`

Для `company`/`hr_agency` тот же набор в другом порядке (app-shell:41-48): Главная, Работа, Новости,
Профиль, Компании, Контакты.

Кнопка **«Ещё»** (app-shell:365-415) раскрывает дополнительные разделы (app-shell:53-69), c дедупликацией
пунктов из основного меню (app-shell:379) и честным уровневым замком (🔒 + тост «Функция заблокирована.
Требуется уровень: …» app-shell:391-394; NFT-навыки и DAO требуют level `extended`):

- Контакты / Работа / Компании (дубли, отфильтровываются на desktop)
- **Сообщения** → `messages`
- **Сообщества** → `communities`
- **Проекты** → `projects`
- **Граф доверия** → `trust-graph`
- **NFT-навыки** → `nft-skills` (🔒 level extended)
- **DAO** → `dao` (🔒 level extended)
- **AI-Поиск** → view `matchmaker` (`MatchmakerView`, «AI-Matchmaker 5 рукопожатий»)
- **AI-Карьера** → view `career` (`CareerAgentView`)
- **Исследование** → view `research` (`ResearchView`, волна D)
- **Тарифы** → `subscription` (`SubscriptionView`)
- **Настройки** → `settings` (`SettingsView`)

Внизу сайдбара: апселл «Перейти на Pro» (free, app-shell:422-430) / «Перейти на Business» (pro,
app-shell:431-440) → view `subscription`; кнопка «Создать проект» (app-shell:441-460) → view
`projects` (саму форму не открывает — откроется список проектов, где есть кнопка создания).
Collapse сайдбара — иконка-шеврон (app-shell:310-317), состояние в localStorage
`bizon-sidebar-collapsed` (app-shell:114-127). Все кнопки — ГОТОВО.

### 1.3 Мобильная навигация (`app-shell.tsx:478-566`)

- Нижний таб-бар: 4 основных раздела (первые 4 из NAV_MAIN) + «Ещё» → bottom-sheet «Все разделы»
  (grid 3 колонки, те же NAV_MORE c дедупликацией и замками; app-shell:509-566) + кнопка
  «Перейти на Pro» для free (app-shell:555-563). ГОТОВО.
- FAB «+» (SmartButton, app-shell:577-715): меню из 3 групп:
  - **Создать**: «Опубликовать пост» → настоящий PostComposer в диалоге; «Новый проект» → форма
    (POST /api/projects); «Создать событие» → форма (POST /api/events, free → честный апселл);
    «Опубликовать вакансию» → только для company/hr_agency (POST /api/jobs) — см. §1.5.
  - **Найти**: «AI-поиск контакта» → matchmaker; «AI-подбор вакансий» → jobs; «Карта карьеры» → career.
  - **Действия**: «Подтвердить навык» → network; «Назад» (если есть история) → `goBack()`.
  Все пункты — реальные переходы/формы (fab-create-dialogs.tsx), заглушка «Фаза 2» удалена (A8).
  ГОТОВО.

### 1.4 Подразделы правой панели (`src/components/shell/sub-section-bar.tsx`)

Показывается только для view `feed` и `jobs` (sub-section-bar:165-185; для остальных view — `null`).
Счётчики бейджей: `GET /api/subsections/counts` при монтировании и каждые 60 с (sub-section-bar:149-161).
Клик по подразделу → `setFeedSubSection`/`setJobsSubSection` (push в историю навигации) + в главном
окне перезагрузка данных. ГОТОВО. Mobile — горизонтальные чипы (sub-section-bar:188-213).

**Лента (feed)** (sub-section-bar:55-80):
- Лента: `recommended` «Рекомендуемое» (default), `all` «Все новости», `friends` «От друзей»
- Моё: `mine` «Мои посты», `favorites` «Избранное»
- Социальное: `favGroups` «Избранные группы», `favNews` «Избранные новости» (подписки на авторов)

**Работа (jobs)** (sub-section-bar:82-109):
- Лента: `recommended` «Рекомендованные», `all` «Все вакансии», `hot` «Горячие» (= платные/срочные
  размещения Job.boosted, jobs-view:79-82)
- Моё: `applied` «Мои отклики», `my-path` «Мой путь» (Job Pipeline), `saved` «Сохранённые»
- Социальное: `favCompanies` «Избранные компании»

**Объявления (ads)** (sub-section-bar:111-134) — конфиг существует, но view `ads` в приложении НЕТ,
поэтому раздел недостижим (зарезервировано на будущее; sub-section-bar:179-183 явно возвращает `null`
для companies) — **СТАБ/не активировано**.

В jobs-разделе снизу — `SavedFiltersPanel` «Мои фильтры» (sub-section-bar:260-264, см. §2.8).

### 1.5 FAB-формы создания (`src/components/shell/fab-create-dialogs.tsx`)

| Форма | API | Детали |
|---|---|---|
| Пост (fab:43-56) | PostComposer → `POST /api/posts` (post-composer:56) | после публикации → view feed |
| Проект (fab:58-67, 100-179) | `POST /api/projects {title≤200, description≤10000, tags[]}` (fab:110) | тост «Проект создан», переход в projects |
| Событие (fab:69-83, 181-397) | `POST /api/events {title, description, format, category, startDate, location?, maxParticipants?}` (fab:231) | для free — диалог-апселл «Доступно на Pro и Business» + «Смотреть тарифы» → subscription (зеркалит 403 API) (fab:252-283) |
| Вакансия (fab:86-94, 400-523) | `POST /api/jobs {title, description, requiredSkills[], salaryFrom/To, location}` (fab:414) | пункт в FAB только для company/hr_agency (app-shell:595-599); ошибки 402/403 — тост с текстом сервера |

ГОТОВО.

### 1.6 Полное дерево view → компонент (`src/app/page.tsx:109-146`)

dashboard → DashboardView (individual) / CompanyDashboard (company/hr_agency); feed → TrustStreamView;
profile → ProfileView (чужой) или MeView (свой, `profileUserId=null`); me → MeView; projects →
ProjectsView; jobs → JobsView (+ deep-link `?view=jobs&jobId=...` открывает диалог вакансии,
page.tsx:81-95, jobs-view:486-491); matchmaker → MatchmakerView; career → CareerAgentView; network →
NetworkView; subscription → SubscriptionView; companies → CompaniesView; company → CompanyView;
events → EventsView; communities → CommunitiesView; community → CommunityView; messages → MessagesView;
trust-graph → TrustGraphView; nft-skills → NFTSkillsView; dao → DAOView; settings → SettingsView;
mentor → MentorView; publications → PublicationsView; truth → TruthProfile; research → ResearchView.

**Важно**: раздел «Мероприятия» (events) НЕ входит ни в NAV_MAIN, ни в NAV_MORE — в навигации его нет;
попасть можно только из блока «Ближайшие события» на дашборде / календаря (проверить блок на дашборде —
кнопки ведут в events) или FAB-меню после создания события. Аналогично `mentor`, `publications`,
`truth` — открываются только программно из других модулей (см. §2).

---

## 2. Модули (для каждого: назначение / интерактив и реальное поведение / API / данные / статус / некликабельное)

### 2.1 Дашборд — `src/components/dashboard/dashboard-view.tsx` (813 строк)

(а) Первый экран после входа. Приветствие + профессиональный статус (dashboard:192-205), затем
5 блоков doc_a: «Что изменилось» (дельты из whats-new, dashboard:210-249), «Что важно»
(ProfessionalTrustHomeCard + IP-score ring с пометкой «легаси-вторичный», dashboard:256-317),
«Что делать» (NextBestActionCard, dashboard:322-323), «Какие возможности появились» (BizonDiscover,
dashboard:328-329), «Что произошло на рынке» (BizonSignalCard, dashboard:334-335). Ниже —
вспомогательные: InfoBanner (342-349), «BizON рекомендует сегодня» (352-388), ActionCards (390-421),
MonthlyCalendar (424), InterestedCompanies (427), QuickStats (430-435), превью ленты (438+),
ближайшие события, «Репутация — ваша валюта».

(б/в) Интерактив и API:
- Загрузка: `GET /api/feed?limit=3&mode=posts`, `GET /api/events?limit=3`, `GET /api/me/whats-new`
  (dashboard:138-143).
- «Завершить проект (+8)» → setView('projects'); «Добавить связь (+3)» → setView('network')
  (dashboard:307-312) — переходы, не действия.
- RecItem/ActionCard «Открыть/Найти/Запустить» → jobs / matchmaker / career (dashboard:365-385,
  393-420) — ГОТОВО.
- **QuickStats «Проекты / Связи / Навыки / Посты»** — кликабельные карточки: → projects / network /
  свой профиль / feed (dashboard:431-434). ГОТОВО (в отличие от профиля-«развертки» здесь переход в
  раздел, а не список).
- ProfessionalTrustHomeCard — `GET /api/me/home-metrics` (dashboard:615).
- InterestedCompanies — см. §2.2 (фейковые matchScore!).
- MonthlyCalendar — `GET /api/events?limit=100` (monthly-calendar:56), сетка месяца с событиями.
- Все кнопки-переходы работают.

(г) Данные из перечисленных API, результат отображается в блоках 1-5.
(д) **ГОТОВО** (за исключением InterestedCompanies — ЧАСТИЧНО/фейковые цифры, §2.2).
(е) Некликабельное: блок «Что изменилось» — числа (±trust, вакансии, подтверждения) — просто текст;
   «Evidence Coverage %» — текст.

### 2.2 InterestedCompanies — `src/components/dashboard/interested-companies.tsx` (125 строк)

(б) Логотипы «компаний, которым вы интересны». Клик по логотипу → `setSelectedCompanyId(c.id)`
(interested:89-94) — открывает компанию (НБ: не вызывает setView, но стор переключает view='company'
— app-store:260-265). Кнопка «Все» → setView('companies') (interested:81).
(в) `GET /api/companies` (interested:33).
(г) **КРИТИЧНО/НЕЧЕСТНО**: `matchScore = 70 + random(25)`, `openJobs = 1 + random(5)`
(interested:34-41, комментарий «в Фазе 2 будет реальный матчинг») — проценты соответствия и число
вакансий ВЫДУМАНЫ на клиенте при каждом монтировании.
(д) **СТАБ-ДАННЫЕ / ЧАСТИЧНО** — переход работает, цифры фейковые (interested-companies.tsx:35-41).

### 2.3 Daily Brief и Predictive Flow

- `src/components/dashboard/daily-brief.tsx` (154): модальное окно «Доброе утро» 1 раз в день
  (localStorage `bizon_daily_brief_date`, daily-brief:31-53). Данные: `GET /api/feed?limit=5&mode=posts`,
  `GET /api/connections?direction=incoming`, `GET /api/me/home-metrics` (daily-brief:36-42).
  Professional Trust — primary, IP-score — легаси (daily-brief:99-126). Кнопки-действия: «К проектам»
  → projects, «Читать» → feed, «Посмотреть/Найти» → network/matchmaker (daily-brief:59-81,136).
  «Начать день» закрывает (daily-brief:142). **ГОТОВО**.
- `src/components/dashboard/predictive-flow.tsx` (78): невидимый компонент, показывает подсказки-тосты
  после переходов (проекты→дашборд, сеть→дашборд, низкая заполненность профиля, утро). Чисто
  информационный, кнопок нет. **ГОТОВО (информационный)**.

### 2.4 Лента «Новости» (Trust Stream) — `src/components/feed/trust-stream.tsx` (925 строк)

(а) Единая лента доверия: посты + события репутации + спонсорские карточки; 7 подразделов
(SUBSECTION_META trust-stream:46-54); режимы отображения mini/vk (toggle trust-stream:224-257);
табы «Все / Посты / Достижения» (feedMode, trust-stream:288-307).

(б/в) Интерактив:
- Загрузка: `GET /api/feed?limit=20&offset=&mode=&sub=&random=`, для favorites — `GET /api/posts/saved`
  (trust-stream:101,138); «Загрузить ещё» (trust-stream:362); «Обновить» (270); «Случайные» —
  перемешивание с сохранением скролла (trust-stream:170-182).
- PostCard: лайк (оптимистично) → `POST /api/posts/[id]/like` (trust-stream:443); сохранить —
  `POST /api/posts/[id]/save` (456); комментарий — `POST /api/posts/[id]/comment` (468); клик по
  автору/аватару → профиль; FollowButton подписки (534, §2.32); CTA коммерческого поста —
  диалог отклика В ПЛАТФОРМЕ `RespondDialog` → `POST /api/posts/[id]/respond` (trust-stream:608-625,
  737-740), после успеха опциональный mailto-дубль (753-756, честная подпись «откроется ваш почтовый
  клиент»); «…» → ThreeDotsMenu (664) — см. §3 (два из трёх пунктов — стабы).
- ReputationEventCard: клик по автору → профиль; содержимое события — текст (trust-stream:387-421,
  869-911).
- SponsoredCard: «X» — скрытие ТОЛЬКО на клиенте (setItems filter, trust-stream:206-209) — тост
  «в дальнейшем AI будет учитывать…» обещает то, чего нет; CTA — внешняя ссылка (856-864).
- Контекстные вставки FeedRecommendations (jobs после 2-го поста, people — 6-го, events — 11-го,
  trust-stream:350-358).
- NewsFeedSection + RecommendationsCarousel — в recommended/all (281-285), см. §2.5.

(д) Статус: **ГОТОВО**; minor-заглушки: скрытие рекламы без backend-запоминания (trust-stream:206-209),
ThreeDotsMenu (§3).

### 2.5 Feed-компоненты

- **PostComposer** (`src/components/feed/post-composer.tsx`, 253): форма поста → `POST /api/posts`
  (post-composer:56); результат — новый пост сверху ленты (trust-stream:184-204). ГОТОВО.
- **NewsFeedSection / NewsCard** (`src/components/feed/news-card.tsx`, 528): `GET /api/news?limit=…`
  (468), `GET /api/news/shared?limit=10` (480) — рекомендации коллег; кнопка «Почему это важно?» →
  `GET /api/news/[id]/relevance` с кэшем (304); «Поделиться» → `ShareNewsDialog` → поиск получателя
  `GET /api/users/search` (share-news-dialog:71) + `POST /api/news/recommend` (87). ГОТОВО.
- **RecommendationsCarousel** (`src/components/feed/recommendations-carousel.tsx`, 602): карусель
  рекомендаций (вакансии/люди/сообщества) — `GET /api/feed/recommendations` (316); «Не интересно» →
  `POST /api/feed/recommendations/ignore` (342) + анти-эхо; Epsilon-Greedy бейджи exploration.
  ГОТОВО.
- **FeedRecommendations** (`src/components/feed/feed-recommendations.tsx`, 227): блоки «работа/люди/
  события»: `GET /api/users/search?q=` (76), `GET /api/events?limit=3` (84); клики — переходы.
  ГОТОВО (упрощённый подбор).
- **Dwell-tracking** (`src/components/feed/dwell-tracking.ts`, 312): невидимый трекинг времени
  просмотра постов, батч-флаш `POST /api/feed/dwell` (65) при уходе/unmount. Используется каруселью
  рекомендаций (comments recommendations-carousel:22). ГОТОВО (телеметрия).
- **CompactCalendar** (`src/components/feed/compact-calendar.tsx`, 215): мини-календарь событий в
  RightRail — `GET /api/events?limit=20` (45). ГОТОВО.

### 2.6 Профиль «Я» — MeView (`src/components/me/me-view.tsx`, 240) — 7 табов

Табы (me-view:90-120): **Что нового** (default) | **Моё лицо** | **Анализ** | **Мои навыки** |
**AI-Коуч и Капитал** | **Действия** | **Редактировать**. Переключение — локальный state. ГОТОВО.

- «Что нового» = WhileYouWereAwayDigest + WhatsNewTab + (WhoViewedCard, SkillFuturesPanel) +
  (TalentForecastScenariosCard, CausalityCard) (me-view:127-139) — см. §2.14-2.17.
- «Моё лицо» = ProfileView (me-view:143-145) — §2.7.
- «Анализ» = TrustExplainCard + TruthProfile + EvidenceGraph; CareerCompass и EduRecommendations
  скрыты за onboarding-гейтом (onboardingStep ≥ 3), иначе честный замок «Продвинутые функции… после
  завершения 3 шагов онбординга» (me-view:147-190).
- «Мои навыки» = SkillGraphView (me-view:217-231) — §2.20.
- «AI-Коуч и Капитал» = CapitalDashboard + BizonCoachCard + ProfessionalMemory (me-view:192-210) — §2.16.
- «Действия» = ActionsTimelineTab (me-view:212-215).
- «Редактировать» = SettingsView (me-view:233-236).

### 2.7 ПРОФИЛЬ (критичный модуль) — `src/components/profile/profile-view.tsx` (1201 строк)

(а) «Паспорт доверия»: шапка с аватаром/ролями, IP-score с breakdown, счётчики-статы, QR, навыки
с подтверждениями, проекты, реферальный блок, ИИ-профиль (свой), «Общее с вами» (чужой).

(б/в) Интерактив и реальное поведение:
- Загрузка: `GET /api/users/[id]` (profile:72) — отдаёт user (в т.ч. `stats.projectsCount /
  connectionsCount / skillsCount / postsCount`), skills, projects, common (для чужого).
- Свой профиль: «Редактировать» → форма (Имя/Должность/Локация/ДР/О себе, profile:183-207) →
  `PATCH /api/users/[id]` (profile:94) → setUser + reload. «Сохранить/Отмена» (154-155). ГОТОВО.
- «QR» → диалог с QR-кодом `https://bizon.app/u/[id]` + «Скопировать ссылку» → clipboard (392-418).
  ГОТОВО (ссылка захардкожена на bizon.app, не на текущий домен — ЧАСТИЧНО).
- Чужой профиль: «Подписаться» FollowButton (173, §2.32); «Добавить в контакты» →
  `POST /api/connections {toUserId, note}` (profile:110-113) → тост «Запрос на связь отправлен».
  ГОТОВО.
- **IP-score breakdown (P1-6)**, profile:243-286 — 4 полосы: «Завершённые проекты 40%» → клик
  (свой профиль) → setView('projects') (250-257); «Отзывы и рейтинги 30%» → **`onClick={undefined}` —
  НЕКЛИКАБЕЛЬНО (profile:259-266)**; «Подтверждённые навыки 20%» → setView('profile') (267-275);
  «Посты и связи 10%» → setView('feed') (276-284). Для чужого профиля — все без клика.
- **Счётчики-статы «Проекты / Связи / Навыки / Посты» (profile:288-295)** — рендерятся компонентом
  `Stat` (profile:543-562) как `<button>` с `min-h-[44px]`, `aria-label`, шевроном ⌄. КАЖДЫЙ
  передаёт `onClick={() => setStatOpen(...)}` — то есть **все четыре счётчика КЛИКАБЕЛЬНЫ** (Волна D,
  комментарий profile:56-60 «запрос владельца, 2026-09-11»).
- **ProfileStatDialog (развертка статов)** (profile:923-1093):
  - «Проекты» — список из `data.projects` (тот же GET /api/users/[id]); клик по проекту →
    `setSelectedProjectId(id); setView('projects')` (profile:467, 990-1003). ГОТОВО.
  - «Связи» — лениво `GET /api/users/[id]/connections?limit=100` (profile:942) — принятые связи с
    публичными полями; клик по человеку → `setProfileUserId(id)` (468, 1016-1031). ГОТОВО.
  - «Навыки» — список из `data.skills`, у каждого кнопка «Кто подтвердил (N)» → ConfirmationsDialog
    (1048-1059). ГОТОВО.
  - «Посты» — лениво `GET /api/posts?authorId=…&limit=20` (950); «Открыть в ленте» → setView('feed')
    (1082-1086, только свой). ГОТОВО.
  - Нюанс честности: цифра на карточке = `stats.*Count` из GET /api/users/[id], а список — из других
    источников; если счётчик > 0, а список пуст (например, связи есть, но все не «accepted»), увидите
    «Принятых связей пока нет» при числе N в плитке — расхождение возможно.
- **Навыки (SkillRow)** (profile:590-647): счётчик «✓ N» и подпись «Подтверждён N коллегами… нажмите,
  чтобы увидеть кто» — кликабельны → ConfirmationsDialog (610-617, 627-633); бейдж NFT (619-623);
  чужой профиль: кнопка «Подтвердить» → ConfirmSkillDialog → `POST /api/skills/confirm {userSkillId,
  projectId, comment}` (profile:724) — только при наличии общего проекта (745-749). ГОТОВО.
- «Добавить» навык → AddSkillDialog → `POST /api/skills {name, level}` (profile:659). ГОТОВО.
- **ConfirmationsDialog «кто подтвердил»** (profile:1115-1199): `GET /api/skills/[id]/confirmations`
  (1133) — коллега, проект, комментарий, дата; клик по человеку → его профиль. ГОТОВО.
- Проекты-карточки в профиле (481-519): клик → раздел Проекты с выбранным проектом. ГОТОВО.
- ReferralBlock (свой профиль, profile:809-891): `GET /api/referral` (814) — реальная ссылка + статы
  {total, rewarded, rewardTotal} + список приглашённых; «Копировать» → clipboard. ГОТОВО.
- ResearchProfileCard «ИИ-профиль» (свой, profile:336; research-view:542-608): `GET
  /api/research/insights`, «Пройти/Продолжить исследование» → setView('research'). ГОТОВО.
- AI-рекомендации (521-538): кнопка «Запустить AI-Career-Agent» → setView('career'). ГОТОВО.

(д) **ГОТОВО** в целом. Жалоба владельца «Связи/Проекты не кликабельны» на текущий код НЕ
распространяется: клик реализован (Волна D). Единственный оставшийся некликабельный счётчик профиля —
**«Отзывы и рейтинги» в breakdown IP-score (profile-view.tsx:265, `onClick={undefined}`)** — вероятно,
именно его видит владелец (визуально это тоже «счётчик» в той же карточке IP-score).

(е) Некликабельное в профиле: «Отзывы и рейтинги» (265); breakdown-полосы чужого профиля; «День
рождения» (298-303) — текст; «Общие проекты/навыки/контакты» чужого профиля (339-388) — только
просмотр, названия общих проектов не кликабельны; PostStat-элементы списка постов — не кликабельны
(открывается только лента целиком).

### 2.8 Работа (Jobs) — `src/components/jobs/jobs-view.tsx` (889) + подсистемы

(а) Intention-first экран «Работа»: интент-строка + 4 режима; единая лента с влитыми топ-возможностями
(бейдж «Вам подходит»); группы выдачи Точное/Сильное/Смежные; карточки; личные подразделы.

(б/в) Интерактив:
- `JobIntentBar` (job-intent-bar.tsx): ввод запроса + Enter/«Найти работу» → `executeSearch` →
  `GET /api/jobs?q=…&mode=…` (jobs-view:296). ToggleGroup режимов: 🔎 Быстро | ✍️ Своими словами (nl) |
  🎯 Точно (precise) | 🔬 Исследовать (explore) (job-intent-bar:68-88). ГОТОВО.
- **Своими словами (nl)**: авто-поиск с дебаунсом 1.2 с, порог 12 символов, гварды против дублей/гонок
  (jobs-view:311-329); чипы-примеры — мгновенный поиск (624-637); панель «Я правильно вас понял?» —
  parsedIntent из API, «Да, искать»/«Изменить» (671-677, 826-858). ГОТОВО.
- **Точно (precise)**: `JobPreciseFilters` (локация/зарплата/формат/уровень/отрасль + «Что важно» чипы)
  → параметры поиска (jobs-view:643-652, 372-380); валидация «Уточните запрос» (375-378). ГОТОВО.
- **ИССЛЕДОВАТЬ (explore) — детально (запрос владельца)**:
  - UI: `ResearchInviteCard` (jobs-view:659; research-view:481-536) — приглашение пройти 3 опросника,
    пока ИИ-профиль не заполнен (кнопка → view research); `JobExplorePanel` — 6 карточек-целей
    «Что для вас сейчас важнее?» (💰 Дохода, 📈 Уровня, 🌴 Свободы, 🧭 Сменить профессию,
    🧑‍💼 Руководящая роль, ✨ Пока не знаю; job-explore-panel:99-123, коды в jobs-types:145-152);
    опросник ExploreQuiz (6 вопросов → `POST /api/me/preferences {exploreQuiz}` с merge —
    explore-quiz:1-8, 91); «Карьерные сценарии» — `GET /api/me/career-discovery` (jobs-view:203),
    клик по роли → подстановка в запрос + quick-поиск (jobs-view:411-414).
  - Выбор целей: клик по карточке → `handleGoalsChange` → **СРАЗУ** `GET /api/jobs?mode=explore&important=…`
    (jobs-view:401-408 → executeSearch:296). Кнопка «Найти» тоже работает (382-389), при нуле целей —
    честный тост «Выберите, что для вас важно» (383-386).
  - Реальное поведение бэка (`src/app/api/jobs/route.ts`): флаги important → бусты ранжирования
    (salary/remote/growth/leadership/industry/stability; jobs-route:459-505), matchTier-группы
    (jobs-route:584-591), explanation.reasons («удалённая работа», «высокий потенциал роста»…).
    **ВАЖНО**: «Пока не знаю» (unsure) в белом списке бэка ОТСУТСТВУЕТ (IMPORTANT_FLAGS jobs-route:59-62)
    — выбор этой цели молча не влияет на выдачу; эффект бустов зависит от заполненности полей вакансий
    (salary/growthScore/level/industry/workFormat) — если у вакансий поля пусты, выдача почти не
    отличается от общего списка. Вакансии «Исследовать» ОТДАЁТ (это не стаб), но результаты могут
    разочаровать при малом пуле Job.active (лимит 200, jobs-route:293-297).
- **Группы выдачи**: чипы «Все — N / Точное — N / Сильное — N / Смежные — N» — фильтр по matchTier
  (jobs-view:698-718, 863-880). ГОТОВО.
- **JobLightCard** (job-light-card.tsx, 186): «Подробнее» → JobDetailDialog; закладка → save (§ ниже);
  «Не моё» → JobNotMineDialog. VerifiedVacancyBadge — бейдж 8 критериев. ГОТОВО.
- «Сохранить» — оптимистично + `POST /api/jobs/[id]/save` (jobs-view:428-454). ГОТОВО.
- «Не моё» (Explicit Negative Intent) — диалог причин (job-not-mine-dialog.tsx) →
  `POST /api/feed/recommendations/ignore {topic, itemType:'job', reason, targetId}` (jobs-view:463-471)
  + оптимистичное скрытие. ГОТОВО.
- Личные подразделы: saved → `GET /api/jobs/saved`; applied/mine → `GET /api/jobs/applications`
  (jobs-view:140-173); «Обновить» (558-562). ГОТОВО.
- **«Мой путь» (my-path-view.tsx, 745)**: pipeline «Ищу → Сохранил → Откликнулся → HR просмотрел →
  Интервью → Предложение → Принял» + «Отклонённые» с причиной; данные `GET /api/jobs/applications` +
  `GET /api/jobs/saved` (my-path:247,257); смена статуса — клик по цели в меню → `PATCH
  /api/applications/[id]/status` (my-path:296) с оптимистикой и откатом; для rejected — диалог причины.
  ГОТОВО.
- Deep-link `?view=jobs&jobId=` — открывает диалог вакансии (jobs-view:486-491). ГОТОВО.

(д) **ГОТОВО** (модуль целиком рабочий). (е) «Показаны N вакансий» — текст; пагинации нет (честная
подпись, jobs-view:737-742).

### 2.9 Диалоги и бейджи вакансий

- **JobDetailDialog** (job-detail-dialog.tsx, 295): резюме вакансии; «План подготовки» — лениво
  `GET /api/jobs/[id]/growth` (204); при 404/ошибке — честная заглушка «Собираем план подготовки к
  этой вакансии — скоро он появится здесь» (229-233) — **ЧАСТИЧНО** (зависит от данных).
- **JobPassport** (job-passport.tsx, 538): `GET /api/jobs/[id]/job-passport` (177) — Match %,
  Hiring Reality, Employer Trust, время ответа, timeValue-рекомендация; «Откликнуться» →
  `POST /api/jobs/[id]/apply` (194) + тост «Совпадение: N%»; PROVE IT checklist (258-264).
  ГОТОВО.
- **HiringRealityBadge** (hiring-reality-badge.tsx, 244): `GET /api/jobs/[id]/hiring-reality` (111).
  ГОТОВО.
- **ExplainableMatchDialog** (explainable-match-dialog.tsx, 401): «Почему это вам» — `GET
  /api/jobs/[id]/match-explain` (72). **СТАБ-ЧАСТЬ**: блок Company Fit = фиксированная заглушка «88%»
  с честной припиской «Заглушка — Cultural Signals скоро» (159, 293). ЧАСТИЧНО.
- **CompareVacanciesDialog/Button** (compare-vacancies.tsx, 526): side-by-side сравнение —
  `POST /api/jobs/compare` (127). **НЕ ПОДКЛЮЧЕНО к UI** — компонент существует, но не импортируется
  ни в одном активном экране (grep); в «Найди мне» кнопка «Сравнить» даёт тост «Скоро»
  (find-for-me-tab:113-115). СТАБ (в местах использования).
- **SavedFiltersPanel** (saved-filters-panel.tsx, 285): фильтры-мониторы (кап 9) —
  `POST /api/saved-filters` (84), `PATCH` (112), `DELETE` (129); применение → сигнал
  `applyJobsFilter` в стор → JobsView исполняет поиск (app-store:298-308, jobs-view:331-368);
  «Сохранить текущий поиск» берёт `jobsCurrentSearchParams` из стора. ГОТОВО.

### 2.10 Компании — CompaniesView / CompanyView / CompanyDashboard

- **CompaniesView** (companies-view.tsx, 326): `GET /api/companies?limit=30&q=&industry=` (65);
  поиск (дебаунс через перезагрузку), чипы отраслей (из загруженных), вид Список/Таблица
  (localStorage, 50-58); клик по карточке/строке → CompanyView; «Подписаться» →
  `POST /api/companies/[id]/follow` (86) с обновлением счётчика. ГОТОВО.
- **CompanyView** (company-view.tsx, 541): данные компании, follow (80); вкладка «Стрим»
  (company-stream-tab.tsx: `GET /api/companies/[id]/stream` 303, `GET .../workforce-gap` 453);
  отзывы — `POST /api/companies/[id]/reviews` (441); CompanyIntelligencePanel — `GET
  /api/company/intelligence?companyId=` (company-intelligence-panel:55); CompanyTrustCard
  (company-trust-card.tsx — `GET /api/companies/[id]/trust` через сервис). Cultural Signals:
  CulturalSignalsBlock (cultural-signals.tsx:227) — `GET /api/companies/[id]/cultural-signals` (67),
  создание отзыва сотрудником — `POST` (358); модерация админом — `POST /api/cultural-signals/[id]/moderate`
  (бэк есть). ЧАСТИЧНО-ГОТОВО: основной контур реальный; список подчинённых блоков смонтирован по
  вкладкам.
- **CompanyDashboard** (company-dashboard.tsx, 271) — дашборд юрлица: вакансии компании
  (`GET /api/jobs` для company — candidates+limits, jobs-route:212-259), CreateJobDialog →
  `POST /api/jobs` (company-dashboard:210). ГОТОВО.
- Публичный паспорт компании `/c/[token]` (c/[token]/page.tsx, 647) — серверный рендер по токену,
  read-only, OG-метаданные. ГОТОВО (только просмотр). **НБ**: UI-кнопки включить/ regenerate личный
  паспорт (`POST /api/me/company-passport/enable|disable`, `/api/me/passport/*`) в компонентах НЕ
  найдены — API есть, UI нет (см. §3).

### 2.11 HR-модуль (hr_agency) — `src/components/hr/hr-view.tsx` (687) + панели

- **HrView** (для аккаунта hr_agency): HR Organization Section — `GET /api/hr-organizations` (582),
  создание — `POST /api/hr-organizations` (654); при наличии — HrOrganizationDashboard
  (`GET /api/hr-organizations/[id]` + `/pipeline` — hr-organization-dashboard:114-115; приглашение
  рекрутера — `POST .../recruiters` 517). Специализация — чипы, хранятся В LOCALSTORAGE
  (`bizon_hr_specs_[id]`, hr-view:70-89) — не синхронизируется с БД (ЧАСТИЧНО).
  Placement Portfolio — `GET /api/placements` (95) + метрики; «Добавить placement» → диалог →
  `POST /api/placements` (443). Клиенты — переходы в company. **«Отзывы кандидатов» — СТАБ**:
  карточка с бейджем «Скоро», текст «Функция в разработке», никаких действий (hr-view:290-310).
- **BuildTalentPanel** (build-talent-panel.tsx, 340): поиск кандидатов — `GET
  /api/build-talent/candidates?…` (96) с фильтрами навыков/уровней. ГОТОВО.
- **TeamBuilderPanel** (team-builder-panel.tsx, 400): сборка команды — `POST
  /api/team-builder/compose` (90). ГОТОВО.
- **WorkforceGatesPanel** (workforce-gates-panel.tsx, 517): «ворота найма» — `GET
  /api/workforce/overview?companyId=` (134). ГОТОВО.
- **HrContactButton** (hr-contact-button.tsx, 157): контакт HR → `POST /api/hr-contacts` (61).
  ГОТОВО. Блокировка контактов (`POST /api/hr-contacts/[id]/block`) — бэк есть, UI-кнопки нет.

### 2.12 Контакты (Network) + Дни рождения

- **NetworkView** (network-view.tsx, 307): табы Все/Входящие/Исходящие — `GET /api/connections?direction=`
  (47); Принять/Отклонить — `PATCH /api/connections {connectionId, action}` (60); вид Список/Таблица
  (localStorage, 33-41); клики по людям → профиль. ГОТОВО.
- **BirthdaysPanel** (birthdays-panel.tsx, 420): `GET /api/network/birthdays` (82) — сегодня + месяц;
  план поздравления — `POST /api/birthday-plans` (birthday-plan-dialog:79), «готово» — `PATCH
  /api/birthday-plans/[id]` (110), удаление — `DELETE` (120); «Поздравить» — `POST /api/messages` (373).
  ГОТОВО.
- Запросы «Спросить коллегу» — ColleagueInquiryDialog → `POST /api/colleague-inquiries`
  (colleague-inquiry-dialog:85); входящие — IncomingInquiriesDialog (GET список) + `POST
  /api/colleague-inquiries/[id]/respond` (94, 126). ГОТОВО (используются в карточках людей).

### 2.13 Сообщения — `src/components/messages/messages-view.tsx` (118)

Список диалогов `GET /api/messages` (35); открытие — `GET /api/messages/[conversationId]` (47);
отправка — `POST /api/messages {toUserId, content}` (58), Enter = отправить (108); клик по шапке
диалога → профиль собеседника (94). Отметка о прочтении — локально (unreadCount=0, 49). Обновления
в реальном времени НЕТ — только перезагрузка после отправки. ГОТОВО (без realtime/SSE в этом окне).

### 2.14 «Что нового» / сигналы / дайджесты

- **WhatsNewTab** (whats-new-tab.tsx, 842): `GET /api/me/whats-new` + `GET /api/me/actions?limit=5`
  (264-265); 5-блочная структура Home; внутри NewsSourcesCard (371) и MarketIntelligencePanel (61).
  Блоки действий — переходы (setView). ГОТОВО (без LLM-инсайта — см. TruthDashboardTab в §3).
- **WhileYouWereAwayDigest** (while-you-were-away-digest.tsx, 341): `GET /api/me/whats-new`,
  `/api/me/profile-views`, `/api/me/signals` (220-222) — детерминированная сборка без LLM,
  сворачиваемый. ГОТОВО.
- **BizonSignalCard** (bizon-signal-card.tsx, 261): рыночные сигналы — `GET /api/me/signals` (108);
  клик по сигналу → action-навигация (externalUrl / company / setView). ГОТОВО.
- **BizonDiscover** (bizon-discover.tsx, 340): радар возможностей — `GET /api/opportunities/radar`
  (159); клики → действие (vacancy → jobs deep-link, проект, компания). ГОТОВО.
- **WhoViewedCard** (who-viewed-card.tsx, 233): «Вас смотрели» — `GET /api/me/profile-views` (78);
  клик по человеку → профиль. ГОТОВО. (Фиксация просмотра — `POST /api/users/[id]/view` на бэке при
  открытии чужого профиля.)
- **NextBestActionCard** (next-best-action-card.tsx, 221): `GET /api/me/next-best-action` (110) —
  одна рекомендация с кнопкой-действием. ГОТОВО. (Ср. стаб внутри trust-explain-card — §3.)

### 2.15 Действия (Actions Timeline) — `src/components/me/actions-timeline-tab.tsx` (404)

`GET /api/me/actions?limit=&offset=` (188) — журнал действий с фильтрами; пагинация «ещё». ГОТОВО.

### 2.16 AI-Коуч и Капитал

- **CapitalDashboard** (capital-dashboard.tsx, 306): 8 компонентов капитала — `GET /api/me/capital`
  (159); «Пересчитать» — `POST /api/me/capital/recompute` (177). ГОТОВО.
- **BizonCoachCard** (bizon-coach-card.tsx, 580): вопрос дня — `GET /api/me/coach/daily-question` (185);
  ответ — `POST /api/me/coach/answer` (236); инсайты — `GET /api/me/coach/insights` (186);
  «Найти скрытый потенциал» — `POST /api/me/coach/discover` (211); подтверждение/отклонение гипотезы —
  `PATCH /api/me/coach/insights/[id]` (258). ГОТОВО.
- **ProfessionalMemory** (professional-memory.tsx, 233): «что AI знает о вас» — `GET /api/me/memory`
  (126). ГОТОВО (только чтение).

### 2.17 Intelligence-карточки («Я» → Что нового)

- **TalentForecastScenariosCard** (talent-forecast-scenarios-card.tsx, 519): `GET /api/me/talent-forecast`
  (180) — сценарии × горизонты, дефицитность профиля. ГОТОВО (просмотр).
- **CausalityCard** (causality-card.tsx, 583): «Что на вас работает» — `GET /api/me/causality` (385) —
  гипотезы причинности с честными ярлыками (корреляция ≠ причинность). ГОТОВО (просмотр).
- **MarketIntelligencePanel** (market-intelligence-panel.tsx, 440): `GET /api/market/intelligence`
  (169). ГОТОВО (просмотр).
- **SkillFuturesPanel** (skill-futures-panel.tsx, 348): «Ваши траектории» — `GET /api/me/skill-futures`
  (125). ГОТОВО (просмотр).

### 2.18 Truth Engine (view `truth`, компоненты truth/*)

- **TruthProfile** (truth-profile.tsx, 355): `GET /api/reputation/evidence` + `GET /api/claims?pageSize=100`
  (105-106); вкладки: VerifyMeSummary, Claims, Timeline и др. ГОТОВО (агрегатор).
- **VerifyMeSummary** (verify-me-summary.tsx, 222): `GET /api/reputation/evidence` (106). ГОТОВО.
- **ClaimCard / ClaimForm** (claim-card.tsx 153; claim-form.tsx 211): создание клейма —
  `POST /api/claims` (claim-form:96) — ГОТОВО; кнопка «Выбрать верификатора» в ClaimCard —
  **СТАБ**: toast «Функция в разработке. Скоро вы сможете выбрать верификатора…» (claim-card:67-71).
  При этом API подтверждения клейма (`POST /api/claims/[id]/verify`) существует, но из UI НЕ
  вызывается нигде — верификация клейма через интерфейс недоступна.
- **BlindSpotsCard** (blind-spots-card.tsx, 252): `GET /api/me/blind-spots` (87). ГОТОВО (просмотр).
- **EvidenceGraph** (evidence-graph.tsx, 681): `GET /api/me/evidence-graph` (218) — интерактивная
  визуализация claim→project→skill→confirmer. ГОТОВО.
- **CareerScenarioCard** (career-scenario-card.tsx, 413): генерация сценария — `POST
  /api/me/career-scenario` (89, 119); кнопка «Найти наставника» → view mentor. ГОТОВО (с люмен-гейтом
  на бэке).
- **MorningBrief** (morning-brief.tsx, 384): `GET /api/reputation/evidence`, `/api/reputation/snapshots`,
  `/api/claims?status=claimed`, `/api/users/[id]`, `/api/me/signals` (128-133); блок «Возможности» —
  топ-3 реальных сигналов с переходами; «Все возможности» → setView('me') (worklog A18). ГОТОВО.
- **NextBestActionCard** — см. §2.14.
- **BizonMomentCard** (bizon-moment-card.tsx, 365): `GET /api/insights/bizon-moment` (117);
  «Включить» — `POST /api/insights/bizon-moment/opt-in` (166, 346); «Скрыть» — `POST .../dismiss` (323);
  состояние «скоро появится» (185-201) — ожидание ночной генерации (крон `/api/cron/insights`).
  ГОТОВО.
- **TrustExplainCard** (trust-explain-card.tsx, 483): объяснение Trust — `GET /api/me/trust-explain`
  (189) — ГОТОВО; блок «Next Best Actions» внутри — **СТАБ** «Заглушка. Скоро: персональные
  AI-рекомендации» (420, комментарий 138).
- **TruthGapDisplay** (truth-gap-display.tsx, 215): самооценка навыка — `POST
  /api/skills/[id]/self-assessment` (102). ГОТОВО.
- **ReputationTimeline** (reputation-timeline.tsx, 333): `GET /api/reputation/snapshots` (39). ГОТОВО.
- **ReputationMilestones** (reputation-milestones.tsx, 256): evidence + users/[id] (57-59). ГОТОВО.
- **ProfessionalMoments** (professional-moments.tsx, 294): `GET /api/me/moments?limit=` (174). ГОТОВО.
- **ProfessionalTrustCard** (professional-trust-card.tsx, 217): `GET/POST /api/me/professional-trust`
  (82, 99). ГОТОВО.
- **CareerTimeline** (career-timeline.tsx, 348): добавление записи — `POST /api/career-entries` (215).
  ГОТОВО.
- **SkillGraphView** (skill-graph-view.tsx, 920): `GET /api/me/skills/graph` (286); «Почему такой
  уровень» — `GET /api/me/skills/[skillId]/explain` (429); «Доказательства» — `GET .../proofs` (446);
  «Восстановить» (resurrect) — `POST .../resurrect` (462). ГОТОВО.
- **ProveItButton** (prove-it-button.tsx, 125): кнопки-переходы «Добавить достижение» → projects,
  «Подтвердить навык» → network (97, 104) — навигация, не API. ГОТОВО (как CTA).
- **WhyYouMatch** (why-you-match.tsx, 104) — презентационный компонент процента совпадения.

### 2.19 Проекты — `src/components/projects/projects-view.tsx` (672)

`GET`-данные через users/projects API; создание — `POST /api/projects` (608); присоединение —
`PATCH /api/projects/[id] {action:'join'}` (329, 478); редактирование/удаление — `PATCH/DELETE
/api/projects/[id]` (79); подтверждение участников — `GET /api/projects/[id]/confirm` (231) + кнопки
confirm; связанные вакансии — `GET /api/projects/[id]/related-jobs` (project-next-steps:149);
завершение/переход — бэк `POST /api/projects/[id]/confirm|leave|transition` (роуты есть). Клик по
карточке — разворот деталей. ГОТОВО (с оговоркой: часть кнопок подтверждения зависит от роли).

### 2.20 NFT-навыки — `src/components/nft-skills/nft-skills-view.tsx` (149)

Данные навыков — `GET /api/users/[id]` (24); «выбрать для NFT» — `POST /api/nft-skills {userSkillId}`
(40); «Минт» — `POST /api/nft-skills/[id]/mint` (50). Раздел закрыт уровнем `extended` в навигации
(app-shell:61). ГОТОВО (гейт по уровню).

### 2.21 DAO — `src/components/dao/dao-view.tsx` (363)

`GET /api/dao?status=all` (30) — с lazy-close-on-read (закрытие просроченных голосований по чтению,
бэк dao-route); голосование «За/Против/Воздержался» — `POST /api/dao/[id]/vote` (41), вес = IP-score,
гейт ipScore<31 — баннер «нужен IP-score 31+» (89-93); «N голосов» и «кто голосовал» — кликабельны →
VotesDialog → `GET /api/dao/[id]/votes` (D-b, dao-view:117-126, 168-174); «Предложить» — диалог →
`POST /api/dao` (314), кнопка видна при ipScore≥31 (68-70); финальные вердикты «Принято/Отклонено» с
взвешенными итогами (132-154). ГОТОВО (при level extended + ipScore 31+).

### 2.22 Мероприятия — `src/components/events/events-view.tsx` (242)

`GET /api/events?limit=30&format=&category=` (61); фильтры формат/тематика (102-135); RSVP «Иду /
Интересно / Не иду» — `POST /api/events/[id]/rsvp {status}` (74) с локальным пересчётом участников.
Создание события — только через FAB (§1.5), в EventsView формы нет. ГОТОВО (RSVP; список участников
`GET /api/events/[id]/attendees` — бэк есть, UI-списка нет).

### 2.23 Сообщества — CommunitiesView / CommunityView

- **CommunitiesView** (communities-view.tsx, 142): `GET /api/communities?category=` (38); фильтры
  категорий; клик по карточке → CommunityView; «Вступить/Участник» — `POST|DELETE
  /api/communities/[slug]/join` (52, 55). ГОТОВО.
- **CommunityView** (community-view.tsx, 225): join/leave (47-50); публикация поста в сообщество —
  `POST /api/communities/[slug]/posts` (63); лента постов сообщества. ГОТОВО.

### 2.24 Граф доверия — `src/components/trust-graph/trust-graph-view.tsx` (75)

`GET /api/trust-graph` (16) — SVG-«созвездие»; клик по узлу (не центр) → профиль человека (52).
ГОТОВО (простая статичная визуализация, без зума/фильтров).

### 2.25 Менторство — `src/components/mentor/mentor-view.tsx` (698)

`GET /api/me/mentorships` (147); запрос наставничества — `POST /api/mentorships` (167); завершение —
`POST /api/mentorships/[id]/complete` (585); для ментора — `GET /api/mentors/[id]/effectiveness` (210).
Кнопки «Найти наставника» из skill-graph-view/career-scenario ведут сюда (page.tsx:138). ГОТОВО.

### 2.26 Публикации — `src/components/publications/publications-view.tsx` (721)

Долгоживущий соавторский контент: создание — `POST /api/publications` (497); соавторы через
`GET /api/users/search` (464); принять/отклонить приглашение — `POST /api/publications/[id]/accept|reject`
(112, 133). Открывается программно (view `publications`), в меню навигации нет. ГОТОВО (вход из других
модулей ограничен).

### 2.27 AI-Поиск / «Совпадения» (Matchmaker) — `src/components/ai/matchmaker-view.tsx` (288)
**— детально (запрос владельца)**

(а) Модуль в навигации называется **«AI-Поиск»** (app-shell:63); заголовок экрана — «AI-Matchmaker».
Это поиск ПУТИ К ЧЕЛОВЕКУ через граф доверия («5 рукопожатий»). Модуля с навигационным названием
«Совпадения» в приложении НЕТ — владелец, по-видимому, называет так matchmaker (единственное место
с «процентами совпадения/уверенности» в AI-разделе; в ленте проценты показываются только в
job_matched-событиях).

(б) Реальное поведение по шагам:
1. Ввод «Кого ищем?» — дебаунс 250 мс → `GET /api/users/search?q=&limit=10` (matchmaker:39) — список
   людей; клик → выбор цели (128).
2. «Найти путь» → `POST /api/ai/matchmaker {toUserId}` (51-55) → бэк: BFS по графу доверия макс.
   глубиной 5 (matchmaker-route:23, findMatch в src/lib/matchmaker.ts); при успехе —
   ReputationService.awardBulk событие `intro_sent` weight 1 (route:27-37).
3. Результат: «Найдено за N рукопожатий» + «Уверенность %»; визуализация пути — аватары участников,
   клик по любому → его профиль (matchmaker:225-242); бейджи «Вы/Цель/Посредник».
4. AI-интро-сообщение: «Копировать» → clipboard (255-258); «Отправить интро» →
   `POST /api/messages {toUserId: последний в пути, content: introTemplate}` (82-85) → тост +
   переход в «Сообщения».
5. «Путь не найден» — честный негативный экран (192-205); «Сменить цель» (159-161).

(в) API: `/api/users/search`, `/api/ai/matchmaker`, `/api/messages`. (г) Данные — реальный граф
связей (Connection accepted); результат — в карточке результата.

(д) **ГОТОВО функционально**; НБ по полезности (почему «бесполезен» у владельца):
- Ищет ТОЛЬКО людей по имени/должности/городу — не умеет «найти кого угодно по роли» и не выдаёт
  вакансии;
- на малых графах (демо-данные) почти всегда «Путь не найден» — ценность зависит от плотности сети;
- уверенность/путь считаются бэком, но нет объяснения «почему этот посредник»;
- «Совпадений по навыкам/вакансиям» тут нет — возможно, владелец ждал именно подбор (это делает
  JobsView/opportunities, а не matchmaker).

(е) Некликабельное: уверенность и счётчик рукопожатий — текст.

### 2.28 AI-Карьера (CareerAgent) — `src/components/ai/career-agent-view.tsx` (169)

«Запустить анализ» → `POST /api/ai/career` (28); для free — люмен-гейт: 402 →
`LumenPaywallDialog` (47-53, extractLumenNeed) с пополнением `POST /api/lumens/topup` и авто-повтором
запуска. Результат: Резюме, Карта карьеры (этапы + % готовности + рекомендуемые навыки), Рекомендации
(94-163); «Смотреть вакансии» → jobs, «Открыть профиль» → profile (156-163). Внутри —
**CareerSimulator** (career-simulator.tsx, 652): «Что если?» без LLM — `GET /api/me/skills/graph?persist=false`
(135) + `POST /api/me/career-scenario` (193) — слайдеры добавления навыков → прогноз. ГОТОВО.

### 2.29 AI Co-Pilot — `src/components/ai-co-pilot/ai-co-pilot.tsx` (232)

Плавающий ассистент: `POST /api/ai-co-pilot {message, history}` (последние 6 сообщений) — реальный
LLM через AIGateway с heuristic-fallback (worklog A6); Spinner вместо фейковой задержки; бейдж
«Автоответ без AI» при provider='heuristic'; ошибки 429/422/сеть — человекочитаемые тосты; Esc закрывает.
ГОТОВО.

### 2.30 Исследование — `src/components/research/research-view.tsx` (609) — тесты/опросники

(а) Модуль (волна D): 3 теста («Профессиональный ориентир», «Предпочтения в работе», «Внутренние
мотиваторы»; банк в `src/lib/research-tests.ts` — 3×8 вопросов × 4-6 шкал) → контрольные данные ИИ.
(б) Список статусов `GET /api/research/tests` + агрегат `GET /api/research/insights` (88-89);
«Пройти/Пересдать» → TestFlowDialog: вопрос-за-вопросом, прогресс, «Завершить» → `POST
/api/research/tests/[key] {answers[]}` (268) → серверная валидация, очки, LLM-интерпретация
(AIGateway, fallback heuristicSummary) → upsert; экран результата с ScoreBars и ProviderBadge
(«ИИ-интерпретация»/«Локальная интерпретация», 436-446); «глаз» — просмотр сохранённого
(ResultDialog, 392-430). Агрегат «Что BizON понял о вас» — сводка по тестам (134-158).
Интеграции: `/api/research/insights` → системный промпт Co-Pilot, ResearchInviteCard в «Исследовать»,
ResearchProfileCard в профиле. ГОТОВО.

### 2.31 Карьера/CV

- **CareerCompass** (career-compass.tsx, 514): `GET /api/cv/compass` (96) — последняя карта;
  «Построить» — `POST /api/cv/compass` (113); согласия (crossDomainOptIn/hobbies) — `PATCH
  /api/users/[id]` (144, 174, 202); чип «+N вакансий» у области — `GET /api/career-compass/vacancy-count?skill=`
  (A14) → клик: `applyJobsFilter({q, mode:'quick'})` + setView('jobs') — переход в «Работу» с фильтром.
  ГОТОВО.
- **ResumeGeneratorDialog** (resume-generator-dialog.tsx, 1038): генерация резюме — `POST
  /api/cv/generate` (131, люмен-гейт 402 + refund при неудаче); 3 типа (полное/короткое/cover_letter);
  «Скачать PDF» — реальная печать A4 через window.print() + изолированный print-контейнер
  #resume-print-area (A16); «Отправить на вакансию» — выбор активной вакансии (GET /api/jobs) →
  `POST /api/jobs/[id]/apply {resumeId, coverLetter}` (285) + ToastAction «Мои отклики». ГОТОВО
  (заглушки «скоро» удалены, worklog A16).

### 2.32 Общие компоненты

- **FollowButton** (follow-button.tsx, 169): toggle «Подписаться/Вы подписаны»; `POST /api/follows`
  (66) / `DELETE /api/follows?userId=` (73) с оптимистикой и откатом; исходное состояние — 1 GET
  (module-level store useSyncExternalStore); на себя не рендерится. ГОТОВО.
- **LumenPaywallDialog** (lumen-paywall.tsx, 124): единый paywall при 402 — быстрое пополнение
  `POST /api/lumens/topup` (40), пакет 100/300/500/1000; используется в career-agent (и др. AI-гейтах).
  ГОТОВО.
- **ThreeDotsMenu** (three-dots-menu.tsx, 46): «Поделиться» — копирует `window.location.href` (23) —
  ГОТОВО (хотя копирует URL ленты, а не конкретного поста); **«Сохранить» — СТАБ** (тост «Сохранено в
  закладки», никакого API — 28-33; реальное сохранение поста — отдельная кнопка закладки в PostCard);
  **«Пожаловаться» — СТАБ** (тост «Жалоба отправлена. AI-модератор проверит контент», ничего не
  отправляет — 34-39).
- **TrustBadge / IpScoreRing** (trust-badge.tsx, 91) — презентационные (уровень/кольцо).
- **InfoBanner** (info-banner.tsx) — informational, dismissible (localStorage).
- **TermTooltip/TermInfo** (term-tooltip.tsx) — подсказки глоссария (lib/glossary.ts) — tooltip.
- **UserAvatar, LoadingScreen, SkipToContent** — презентационные.

### 2.33 Настройки — `src/components/settings/settings-view.tsx` (271) + секции

- IP-score hero + «Пересчитать» — `POST /api/reputation/recalculate` (32) → обновление стора. ГОТОВО.
- Тариф: «Сменить тариф/Управление» → view subscription (132, 143). ГОТОВО.
- **2FA — СТАБ**: блок «Скоро», без тогла (186-202). При этом: бэк `/api/auth/2fa/enable|confirm|disable`
  есть, вход с 2FA поддержан (auth-screen:100-151) — не хватает только UI-включения.
- **LumenWallet** (lumen-wallet.tsx, 292): `GET /api/lumens` (63); пополнение пакетами — `POST
  /api/lumens/topup` (80) — ДЕМО-шлюз, честная пометка «реальные деньги не списываются» (198);
  «Начислить как за месяц (демо)» — `POST /api/lumens/accrue` (96); журнал операций (25 последних).
  ГОТОВО (демо-платежи).
- **DataSovereigntySection** (data-sovereignty-section.tsx, 247): гражданство/регион/согласия —
  `GET /api/me/sovereignty/update` (62) и `POST` (86) (check-роут `/api/me/sovereignty/check` — бэк).
  ГОТОВО. НБ: «Экспорт данных» (`GET /api/me/export-data`), «Удаление аккаунта» (`POST
  /api/me/delete-account`), «Забыть меня» (`/api/me/forget-me`) — бэк есть, UI-кнопок в настройках НЕТ.
- Тема (170-173), «Выйти» — `POST /api/auth/logout` (43). ГОТОВО.
- **SubscriptionView** (subscription-view.tsx, 318): тарифы — `GET /api/subscriptions` (35); апгрейд —
  `POST /api/subscriptions` (58); отмена — `DELETE` (46). ГОТОВО (демо-биллинг).

### 2.34 Онбординг — `src/components/onboarding/*`

- **OnboardingFlow** (onboarding-flow.tsx, 281): статус — `GET /api/onboarding/status` (93); шаг
  выполнен — `POST /api/onboarding/complete-step` (102); «Пропустить» — `POST /api/onboarding/skip`
  (124). ГОТОВО.
- **OnboardingMission** (onboarding-mission.tsx, 480): миссии дней 1-6 с проверкой — данные
  `GET /api/users/[id]` (153, 248) как верификация факта (verifyDay:238); локальный прогресс.
  ГОТОВО (верификация по данным профиля, не по отдельному API событий).
- **OnboardingBanner** (onboarding-banner.tsx, 95) — прогресс-баннер; гейт продвинутых функций в
  MeView (onboardingStep ≥ 3, me-view:69-71). ГОТОВО.

### 2.35 Поиск — `/search` + SemanticSearchBar

- **/search** (search/page.tsx, 467): standalone страница; автопоиск с дебаунсом 300 мс →
  `GET /api/search?q=&limit=20` (161) — люди/компании/вакансии/сообщества/проекты + totals;
  401 → редирект на `/` (167-170); подсветка совпадений; синхронизация `?q=` с URL (134-147).
  **КРИТИЧНО-ЧАСТИЧНО**: карточки результатов — `<Link href="/">` (301-305, 326, 354, 385, 412) —
  клик по ЛЮБОМУ результату просто ведёт на главную SPA и НЕ открывает найденную сущность (нет
  deep-link `?view=…&id=…`). Пользователь не может перейти к человеку/вакансии из страницы поиска.
- **SemanticSearchBar** (semantic-search-bar.tsx, 387): «Умный поиск по смыслу» — `POST
  /api/search/semantic {query, limit:8}` (153-157) с AbortController и кэшем; интент-бейджи
  (грейд/удалёнка/город/зарплата, 260-298); результаты с «Почему найдено» (349-355); примеры-чипы
  (370-380); 401 — «Войдите», 429 — лимит 10/час (162-170). Тот же дефект: результат —
  `<Link href="/">` (321-323) — вакансия НЕ открывается (deep-link `?view=jobs&jobId` поддержан
  платформой, но здесь не используется). ЧАСТИЧНО.

### 2.36 Публичные паспорта `/p/[token]` и `/c/[token]`

- `/p/[token]` (p/[token]/page.tsx, 1009): серверный компонент; `PassportService.getByToken(token)`
  (96) — профессиональный паспорт человека: профессия-шаблон (ProfessionTemplateService), verified
  навыки, проекты, карьерные записи, рекомендации, breakdown Trust; `generateMetadata` OG (67-78);
  force-dynamic, no-store (62-63). Интеракций НЕТ (read-only). ГОТОВО.
- `/c/[token]` (c/[token]/page.tsx, 648): паспорт компании (TrustIndex, проекты, вакансии, cultural
  signals), тоже read-only. ГОТОВО.
- НБ (см. §3): UI для выпуска/копирования токена личного паспорта (бэк `/api/me/passport/enable |
  regenerate | disable`, `/api/me/company-passport/enable | disable`) в компонентах отсутствует —
  страницы существуют, добраться до токена через интерфейс нельзя.

### 2.37 Культурные сигналы — `src/components/cultural-signals/cultural-signals.tsx` (465)

CulturalSignalsChip (⭐ N (M) у вакансии, 86) — `GET /api/companies/[id]/cultural-signals`; клик →
CulturalSignalsDialog (128) — список отзывов; CulturalSignalsBlock для CompanyView (227); создание
сигнала verified-сотрудником — `POST /api/companies/[id]/cultural-signals` (358); модерация — бэк
`POST /api/cultural-signals/[id]/moderate`. ГОТОВО (гейт «verified employee» на бэке).

### 2.38 Новости-источники — `src/components/news/news-sources-card.tsx` (345)

News Bridge: `GET /api/news/sources` + `GET /api/news?limit=8` (128-129); бейдж источника по домену;
админ-модерация новостей — admin/news-moderation.tsx (241) — `POST /api/news/[id]/moderate` (бэк).
ГОТОВО.

### 2.39 Кто смотрел / «Пока вас не было» — см. §2.14. Career Simulator — §2.28.

### 2.40 Мёртвые/недостижимые модули (код есть — UI нет)

| Компонент | Файл | Суть |
|---|---|---|
| **OpportunitiesView «BIZON WORK»** (4 таба: Найти работу / Найди мне / Найти специалиста / Найти проект) | opportunities-view.tsx:30 | Экспортируется, но НЕ импортируется ни в page.tsx, ни где-либо; `setView('opportunities')` в коде отсутствует → весь раздел недостижим |
| FindForMeTab («Найди мне», Opportunity Engine) | find-for-me-tab.tsx | Достижим только из OpportunitiesView → недостижим; содержит стаб «Сравнение: Скоро» (114) |
| FindSpecialistTab | find-specialist-tab.tsx | Аналогично недостижим (поиск по людям для HR) |
| TruthDashboardTab (P0-1) | me/truth-dashboard-tab.tsx:160 | Заменён WhatsNewTab (whats-new-tab.tsx:76 «не используется здесь»); содержит стаб «BIZON AI INSIGHT — Скоро» (517-547) |
| SearchJobCardV2 | search-job-card-v2.tsx | Не импортируется никуда |
| PublicPersona | profile/public-persona.tsx (1211) | Не импортируется никуда; внутри — заглушки «Спроси у коллег», «Персонализированное приглашение» (80, 751) |
| CompareVacanciesButton/Dialog | compare-vacancies.tsx:476/117 | Диалог рабочий, но не смонтирован в активных экранах |
| JobOpportunities (компонент) | job-opportunities.tsx | Используются только helpers sortOpportunities/opportunityToFeedCard; сам компонент не рендерится |

---

## 3. Сводка проблем: некликабельные элементы, тосты-заглушки, действия без эффекта

### 3.1 Прямые стабы (тост/«скоро»/no-op) — таблица

| # | Где (file:line) | Элемент | Что происходит на самом деле | Категория |
|---|---|---|---|---|
| 1 | `src/components/profile/profile-view.tsx:265` | Полоса «Отзывы и рейтинги 30%» в breakdown IP-score | `onClick={undefined}` — некликабельна (остальные 3 полосы кликабельны у своего профиля) | некликабельный счётчик |
| 2 | `src/components/common/three-dots-menu.tsx:28-33` | «…» → «Сохранить» | Только тост «Сохранено в закладки»; API не вызывается | тост-заглушка |
| 3 | `src/components/common/three-dots-menu.tsx:34-39` | «…» → «Пожаловаться» | Тост «Жалоба отправлена. AI-модератор проверит…»; жалоба никуда не отправляется | тост-заглушка (ложный успех) |
| 4 | `src/components/truth/claim-card.tsx:67-71` | Клейм → «Выбрать верификатора» | Тост «Функция в разработке. Скоро…»; при этом `POST /api/claims/[id]/verify` существует, но UI его не вызывает | тост-заглушка |
| 5 | `src/components/truth/trust-explain-card.tsx:420` (коммент. 138) | Блок «Next Best Actions» внутри TrustExplain | Текст «Заглушка. Скоро: персональные AI-рекомендации» | стаб-блок (реальный NBA — отдельная карточка next-best-action-card.tsx) |
| 6 | `src/components/settings/settings-view.tsx:186-202` | «2FA — двухфакторная аутентификация» | Бейдж «Скоро», интеракции нет; бэк 2fa/enable|disable есть, вход с 2FA работает | стаб-блок |
| 7 | `src/components/hr/hr-view.tsx:290-310` | «Отзывы кандидатов» (HR) | Бейдж «Скоро», текст «Функция в разработке», действий нет | стаб-блок |
| 8 | `src/components/opportunities/find-for-me-tab.tsx:113-115` | «Сравнить» (в «Найди мне») | Тост «Скоро: выбор двух вакансий…»; CompareVacanciesDialog существует, но не подключён (и сам таб недостижим — §2.40) | тост-заглушка + мёртвый модуль |
| 9 | `src/components/jobs/explainable-match-dialog.tsx:159,293` | «Company Fit 88%» в объяснении матча | Фиксированная заглушка с честной припиской «Заглушка — Cultural Signals скоро» | стаб-данные (пометены) |
| 10 | `src/components/me/truth-dashboard-tab.tsx:517-547` | «BIZON AI INSIGHT» | «Скоро»; сам компонент мёртвый (не рендерится) | стаб в мёртвом коде |
| 11 | `src/hooks/use-pwa.ts:72` | Push-разрешение | Тост «Push-уведомления включены. Реальная отправка — скоро» | честный тост-ограничение |
| 12 | `src/components/dashboard/interested-companies.tsx:34-41` | «Компании, которым вы интересны» — matchScore 70-95%, openJobs 1-5 | Числа ГЕНЕРИРУЮТСЯ случайным образом на клиенте («в Фазе 2 будет реальный матчинг») | фейковые данные |
| 13 | `src/app/search/page.tsx:301,326,354,385,412` + `src/components/search/semantic-search-bar.tsx:321-323` | Карточки результатов поиска | `<Link href="/">` — клик ведёт на главную, сущность (человек/компания/вакансия/сообщество/проект) НЕ открывается | «кнопка» без реального действия |
| 14 | `src/components/shell/app-shell.tsx:838-853` | Рекламная карточка партнёра (RightRail) | `POST /api/ads {adId}` фиксирует клик, пользователя не переадресует на ctaUrl | частичное действие |
| 15 | `src/components/feed/trust-stream.tsx:206-209` | «X» (скрыть спонсорскую карточку) | Удаление только из локального массива; предисловие «AI будет учитывать» не подкреплено API | частичное действие |
| 16 | `src/components/ai/matchmaker-view.tsx:274-276` | Подпись «Событие IntroRequestSent зафиксировано в Trust Stream» | Пишется ReputationEvent `intro_sent` (+1 weight) в момент ПОИСКА пути, а не отправки интро — подпись неточна | неточность данных |

### 3.2 API существует — UI не подключён

| API | Файл(ы) роута | Комментарий |
|---|---|---|
| `POST /api/claims/[id]/verify` | `src/app/api/claims/[id]/verify/route.ts` | Верификация клейма недоступна из UI (см. #4 выше) |
| `/api/auth/2fa/enable`, `/confirm`, `/disable` | `src/app/api/auth/2fa/*` | Включение/выключение 2FA — только через API; в настройках стаб «Скоро» |
| `/api/me/export-data`, `/api/me/delete-account`, `/api/me/forget-me` | `src/app/api/me/*` | Экспорт/удаление/забыть-меня — нет кнопок в настройках |
| `/api/me/passport/enable|regenerate|disable`, `/api/me/company-passport/enable|disable` | `src/app/api/me/passport/*`, `me/company-passport/*` | Выпуск токена паспорта (страницы `/p/[token]`, `/c/[token]` есть) — UI-кнопок нет |
| `/api/hr-contacts/[id]/block`, `/api/hr-contacts/incoming` | `src/app/api/hr-contacts/*` | Управление HR-контактами — частично без UI |
| `/api/events/[id]/attendees` | `src/app/api/events/[id]/attendees/route.ts` | Список участников события не показывается |
| `/api/ads/saved`, `/api/sponsored/*` (feed/click/impression) | `src/app/api/ads/saved`, `src/app/api/sponsored/*` | Сохранённые объявления и спонсорский трекинг — UI не использует (спонсорские карточки приходят в составе /api/feed) |
| `/api/notifications/settings`, `/api/notifications/stream` (SSE) | `src/app/api/notifications/*` | Настройки уведомлений и real-time стрим — нет UI; уведомления — только поллинг 30 с |
| `/api/mentors` (список), `/api/me/mentorships` | используется частично | Каталог наставников ограничен |
| `/api/integrations/*` (github/linkedin/telegram) | `src/app/api/integrations/*` | Интеграции — UI отсутствует |
| `/api/email/status`, `/api/auth/verify-email` | `src/app/api/email/status`, `auth/verify-email` | Подтверждение email — баннера/кнопки в UI нет (упоминается только в /legal) |
| `/api/workforce/overview` | используется (workforce-gates) | OK |
| `/api/me/intent`, `/api/me/history-people`, `/api/me/ai-analyze`, `/api/me/causality` (write), `/api/skills/[id]/evidence`, `/api/jobs/[id]/verify|time-value|view|boost|verification`, `/api/companies/[id]/verify|claims/*|talent-forecast|common-contacts` и др. | `src/app/api/**` | Бэкенд-эндпоинты, которые текущие компоненты не вызывают (доступны только через API) |

### 3.3 Некликабельные счётчики/данные без раскрытия деталей (после Волны D)

- Профиль: «Проекты/Связи/Навыки/Посты» — **кликабельны** (profile-view:288-295 → ProfileStatDialog:923).
  Жалоба владельца, судя по коду, устарела; реальный остаток — «Отзывы и рейтинги» (265) и полосы
  breakdown у чужого профиля.
- Посты в ProfileStatDialog — элементы списка не кликабельны (нет перехода к посту в ленте; только
  кнопка «Открыть в ленте» целиком, profile:1082-1086).
- Дашборд QuickStats — кликабельны, но ведут в разделы, а не в детализацию (dashboard:431-434).
- «Общие проекты/навыки» чужого профиля — не кликабельны (profile:339-388).
- Уведомления в дропдауне — не кликабельны (app-shell:762-768).
- Matchmaker-«уверенность», «Evidence Coverage», дельты дашборда — текст.

### 3.4 Ответы на конкретные жалобы владельца

1. **«Связи» и «Проекты» в профиле не кликабельны** — на момент аудита кликабельны: кнопки-плитки
   открывают `ProfileStatDialog` (profile-view.tsx:288-295, 923-1093). «Связи» подтягивает
   `GET /api/users/[id]/connections?limit=100` (942) и клик по связи открывает профиль; «Проекты»
   берёт список проектов из `GET /api/users/[id]` и ведёт в раздел «Проекты» с выбранным проектом
   (467). Некликабельным остаётся только сегмент «Отзывы и рейтинги» в breakdown IP-score (265) —
   вероятно, источник актуальной жалобы. Возможный источник расхождения «цифра ≠ список»: плитка
   показывает `stats.*Count`, список — отдельные запросы.
2. **«Совпадения» бесполезны** — модуля «Совпадения» в навигации нет; есть «AI-Поиск» (Matchmaker,
   §2.27): поиск человека → BFS-путь ≤5 рукопожатий → интро. Реален, но ищет только людей, зависит от
   плотности графа, и не даёт вакансий/подбора — отсюда ощущение бесполезности.
3. **«Исследовать» не даёт вакансий** — даёт: выбор целей сразу выполняет `GET /api/jobs?mode=explore&important=…`
   (jobs-view:401-408) и выдаёт реальные вакансии с бустами (jobs-route:459-505). Ограничения: цель
   «Пока не знаю» (unsure) игнорируется бэком (нет в IMPORTANT_FLAGS, jobs-route:59-62); бусты дают
   эффект только при заполненных полях вакансий (зарплата/growth/level/industry/формат); при малом
   пуле активных вакансий результат почти не отличается от общего списка — это и могло выглядеть как
   «пустышка». Дополнительно «Исследовать» ведёт в опросники «Исследования» (ResearchInviteCard).

---

## 4. Глобальное состояние (zustand) и PWA

### 4.1 Store — `src/stores/app-store.ts` (379 строк)

`useAppStore` (zustand + persist, имя `bizon-app-store`):
- **user: UserPublic | null** + `setUser/logout` (141-145, 230-233). Токен в сторе НЕ хранится
  (HttpOnly cookie, 142-143, 337).
- **view: AppView** + `setView` (147-148, 238-244) — каждый переход пушит снимок в историю.
- **profileUserId** (150-151, 246-254) — null = свой профиль (view profile → MeView, иначе ProfileView).
- **selectedProjectId / selectedCompanyId / selectedCommunitySlug** (153-162, 256-273) — выборы для
  Projects/CompanyHub/Community.
- Подразделы правой панели: **feedSubSection / jobsSubSection / adsSubSection** + сеттеры
  (164-170, 275-296) — типы: `FeedSubSection` (13-20), `JobsSubSection` (39-47), `AdsSubSection`
  (107-112); конфиг pipeline «Мой путь» — `JOBS_PIPELINE_CONFIG`/`JOB_STATUS_GROUPS`/
  `JOBS_SUBSECTION_TITLES` (55-105).
- **jobsFilterApply / applyJobsFilter / jobsCurrentSearchParams / setJobsCurrentSearchParams**
  (172-178, 298-308) — мост «Мои фильтры» ↔ поиск «Работы» (сигнал с ts, чтобы повторное применение
  срабатывало).
- **viewHistory / canGoBack / goBack / clearHistory** (180-185, 310-329) — снимки `NavSnapshot`
  (view + подразделы + выборы), лимит 30 записей (226).
- **_hasHydrated / setHasHydrated** (187-189, 331-332) — ручной rehydrate (skipHydration, 341-345).
- **persist.partialize = { view }** (339) — из localStorage восстанавливается только последний
  раздел; авторизация всегда перепроверяется сервером (page.tsx:60-79).
- Хелпер `api<T>(path, options)` (352-378): JSON-заголовки, cookie автоматически; при !ok — Error
  c `.message` (server error), `.status`, `.data` (нужно для люмен-paywall 402, волна 14).

### 4.2 PWA — `src/hooks/use-pwa.ts` (165 строк)

- **registerServiceWorker** (33-48): `navigator.serviceWorker.register('/sw.js')` — ТОЛЬКО в
  production и один раз за сессию; fail-open (warn, не роняет приложение).
- **beforeinstallprompt** ловится на window в module scope (51-60) → `setDeferredPrompt`;
  **triggerInstall** (88-99) — вызывает prompt() и возвращает выбор пользователя.
- **requestPushPermission** (67-82): `Notification.requestPermission()`; при granted — тост
  «Push-уведомления включены. **Реальная отправка — скоро**» (72) — серверной отправки push нет.
- **usePWA(userId)** (106-132): регистрация SW + запрос push-разрешения через 2 с после логина
  (только если permission='default').
- **useInstallPrompt** (139-164): отслеживает доступность установки и standalone-режим.

**Важно**: `usePWA` и `useInstallPrompt` НЕ вызываются ни в одном компоненте (grep по src — только
определения и комментарии; ожидавшийся вызов в AppShell отсутствует). Следовательно: Service Worker
не регистрируется, push-разрешение не запрашивается, кнопка «Установить приложение» не существует —
PWA-функциональность декларирована, но фактически отключена (мёртвый хук).

### 4.3 Навигационная история (для «Назад»)

`goBack()` восстанавливает полный снимок (app-store:313-328); Alt/Cmd+← — глобальный хоткей
(app-shell:139-158); кнопка «Назад» в FAB-меню и TopBar — один и тот же механизм.

---

## 5. Приложение: полный список API, вызываемых из UI (по модулям)

Auth: `/api/auth/me`, `/auth/login`, `/auth/register` (+refCode, acceptedTos), `/auth/logout`,
`/auth/2fa/verify` · Profile: `/api/users/[id]` (GET/PATCH), `/users/[id]/connections`,
`/users/search`, `/users/recommendations` (feed), `/api/connections` (POST/PATCH) · Skills:
`/api/skills` (POST), `/skills/confirm`, `/skills/[id]/confirmations`, `/skills/[id]/self-assessment`,
`/me/skills/graph`, `/me/skills/[skillId]/explain|proofs|resurrect` · Posts/Feed: `/api/posts` (POST),
`/posts/[id]/like|save|comment|respond`, `/posts/saved`, `/api/feed` (+sub, random), `/feed/dwell`,
`/feed/recommendations`, `/feed/recommendations/ignore` · News: `/api/news`, `/news/shared`,
`/news/[id]/relevance`, `/news/recommend` · Jobs: `/api/jobs` (GET/POST, mode=quick|nl|precise|explore,
important, prof=1), `/jobs/[id]/save|apply|apply-via-contact|chat|job-passport|hiring-reality|growth|
match-explain|boost|time-value`, `/jobs/saved`, `/jobs/applications`, `/jobs/compare`,
`/applications/[id]/status`, `/jobs/applications/[id]/withdraw`, `/career-compass/vacancy-count` ·
Opportunities: `/api/opportunities?type=job`, `/opportunities/radar` · Saved filters:
`/api/saved-filters` (CRUD) · Career: `/api/ai/career`, `/ai/matchmaker`, `/ai-co-pilot`,
`/me/career-discovery`, `/me/career-scenario`, `/cv/compass` (GET/POST), `/cv/generate` · Research:
`/api/research/tests`, `/research/tests/[key]`, `/research/insights` · Trust/Truth: `/api/reputation/
evidence|snapshots|recalculate`, `/api/claims` (GET/POST), `/me/trust-explain`, `/me/evidence-graph`,
`/me/blind-spots`, `/me/next-best-action`, `/me/career-scenario`, `/me/professional-trust` (GET/POST),
`/me/moments`, `/insights/bizon-moment` (+opt-in/dismiss) · Capital/Coach/Memory: `/me/capital`,
`/me/capital/recompute`, `/me/coach/daily-question|answer|insights|discover`,
`/me/coach/insights/[id]`, `/me/memory` · Intelligence: `/me/causality`, `/me/talent-forecast`,
`/me/skill-futures`, `/market/intelligence`, `/company/intelligence` · Signals/views:
`/me/signals`, `/me/profile-views`, `/me/whats-new`, `/me/actions`, `/me/home-metrics` · Social:
`/api/messages` (GET/POST), `/messages/[conversationId]`, `/api/follows`, `/api/network/birthdays`,
`/api/birthday-plans` (CRUD), `/api/colleague-inquiries` (+respond) · Communities:
`/api/communities`, `/communities/[slug]`, `/communities/[slug]/join`, `/communities/[slug]/posts` ·
Events: `/api/events`, `/events/[id]/rsvp` · Companies: `/api/companies`, `/companies/[id]/follow|
stream|workforce-gap|reviews|cultural-signals|trust` · HR: `/api/hr-organizations` (+/[id],
/pipeline, /recruiters), `/hr-contacts`, `/build-talent/candidates`, `/team-builder/compose`,
`/workforce/overview`, `/api/placements` · Projects: `/api/projects` (GET/POST),
`/projects/[id]` (PATCH join/leave/…, DELETE), `/projects/[id]/confirm|related-jobs|transition` ·
DAO: `/api/dao`, `/dao/[id]/vote`, `/dao/[id]/votes` · NFT: `/api/nft-skills`, `/nft-skills/[id]/mint` ·
Mentor: `/api/mentorships`, `/mentorships/[id]/complete`, `/mentors/[id]/effectiveness` ·
Publications: `/api/publications` (GET/POST), `/publications/[id]/accept|reject` · Notifications:
`/api/notifications`, `/notifications/read` · Ads: `/api/ads` (GET/POST-click) · Money: `/api/lumens`,
`/lumens/topup`, `/lumens/accrue`, `/api/subscriptions` (GET/POST/DELETE) · Settings: `/api/reputation/
recalculate`, `/me/sovereignty/update`, `/me/accept-tos`, `/api/onboarding/status|complete-step|skip` ·
Search: `/api/search`, `/api/search/semantic` · Career entries: `/api/career-entries`.

---

*Документ подготовлен агентом H1-ui (Explore). Код не изменялся; кроме этого файла изменён только
worklog.md (добавлена запись задачи).*
