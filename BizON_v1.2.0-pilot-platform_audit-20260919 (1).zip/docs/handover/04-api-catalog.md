# Каталог API и сервисов BizON

> Назначение: полный каталог всех API-роутов и backend-сервисов BizON для внешнего AI-аудита.
> Источник истины — исходный код; каждый тезис снабжён ссылкой `файл:строка`.
> Статусы: **ГОТОВО** = работает как описано; **СТАБ** = заглушка/константа/deprecated.
> Путь `src/...` — от корня проекта `/home/z/my-project`.
> Аудит подготовлен задачей H1-api (см. worklog.md).

---

## 1. Общие принципы backend

### 1.1 Аутентификация и сессии

- **Механизм**: opaque token-сессии в БД (таблица `Session`), без внешних JWT. `src/lib/auth.ts:1-11`.
- **Пароли**: PBKDF2-SHA256, **600 000 итераций** (OWASP 2023), соль 16 байт, формат хранения `pbkdf2$iter$salt$hash` — `src/lib/auth.ts:15-30`; константа `PBKDF2_ITERATIONS = 600_000` — `src/lib/security/password-policy.ts:7`. При логине устаревший хэш (100k) прозрачно пере-хэшируется — `src/lib/auth.ts:101-110`.
- **Сессия**: TTL **7 дней** (`SESSION_TTL_HOURS = 24*7`) — `src/lib/auth.ts:11`; cookie `bizon_session` HttpOnly, SameSite=Lax, Secure в prod — `src/lib/auth.ts:178-187`.
- **Извлечение пользователя**: `getUserFromRequest(req)` — Bearer-токен из `Authorization` или fallback на cookie; истёкшая сессия удаляется — `src/lib/auth.ts:123-176`.
- **Регистрация/логин/удаление сессий**: `src/lib/services/auth-service.ts:10-127` (3 типа аккаунта individual/company/hr_agency).
- **Email**: ищется по `emailHash` = HMAC-SHA256(ключ) — `src/lib/security/crypto.ts:107-110`, `src/lib/auth.ts:72-76`. PII шифруется AES-256-GCM (см. 1.5).
- **DEMO MODE**: `BIZON_DEMO_AUTH=1` (только не-prod) — middleware подставляет фиксированную cookie `bizon_session=8a4be271…e758` (токен демо-пользователя, TTL 7 дней) всем запросам без сессии — `src/middleware.ts:20-21,85-115`. В production переменная не задаётся и демо-режим неактивен.
- **2FA (TOTP)**: секрет AES-256-GCM шифруется и хранится в `user.twoFactorSecret`; `otplib` для generate/verify; 10 backup-кодов, SHA-256(salt:code); tempToken 2FA — KV c TTL 5 мин — `src/lib/services/totp-service.ts:11-219`. Логин при включённой 2FA не выдаёт сессию, а возвращает `twoFactorRequired + tempToken` — `src/app/api/auth/login/route.ts:66-79`.

### 1.2 api-helpers (общие ответы, проекции пользователя)

`src/lib/api-helpers.ts`:
- `json(body, status)` / `errorJson(message, status)` — канонические ответы — `:11-21`.
- `requireUser(req)` — обёртка `getUserFromRequest` — `:23-27`.
- `toUserPublic(user)` — публичная проекция + `profileCompletion`: поля (8 шт) дают до 60% (`filled/8*60`), активность до 40% = `projects*5 + skills*4 + posts*3 + connections*2` (cap 40) — `:61-107`.
- `toUserSelfView(user)` — полная версия для себя (с расшифрованными PII), completion только по полям (до 60%) — `:116-181`.
- `toUserPublicLite(user)` — публичный Lite-слайс БЕЗ PII/roles, без decrypt — `:183-256` (гарантии безопасности — `:188-193`).
- Реэкспорт `withRoute`, `jsonError` из with-route — `:258-262`.
- `decryptOr(...)` — расшифровка с fallback на открытые поля при сбое ключа — `:70-73`, `src/lib/security/crypto.ts:98-102`.

### 1.3 withRoute — композер роутов

`src/lib/with-route.ts`:
- Опции: `auth` (default true → 401 «Не авторизован»), `schema` (zod: body для POST/PATCH/PUT/DELETE, query для GET), `rateLimit {key, limit, windowMs}` → 429 + retry-after — `:35-42,118-138`.
- Body всегда парсится (некорректный JSON → 400); неизвестные поля вырезаются zod-strip; ошибка валидации → 400 c `fields` — `:140-169,60-75`.
- Разрешение `params` (Next 16 Promise) — `:171-175`.
- Маппинг ошибок: `BizonError` → свой статус; ZodError → 400; Prisma P2002 → 409, P2025 → 404; остальное → одна строка в консоль без PII + 500 «Внутренняя ошибка сервера» — `:176-195`.

### 1.4 Валидация (zod-схемы)

`src/lib/validation.ts` — центральный банк схем: register/login (`:33-43`), createProject/updateProject (`:46-62`), createJob (`:65-70`), createPost (content ≤5000, type enum, tags ≤20, ctaUrl ≤2048 — `:75-83`), createMessage (`:86-89`), verifyClaim (`:109-113`), subscribePlan (pro|business; enterprise отклоняется в роуте — `:115-119`), lumensTopup (`:122-124`), cvGenerate (`:132-135`), createPublication (coAuthorIds ≤4 — `:138-147`), createCompanyReview, addUserSkill/confirmSkill, dao, notification settings, createSponsoredOpportunity (budget ≤10M, targeting — `:259-275`). Whitelist-ID `bizonId` = `^[a-zA-Z0-9_-]{1,64}$` — `:25-29`.

### 1.5 Безопасность (src/lib/security)

- **crypto.ts** — AES-256-GCM (IV 12B, base64(iv:ct:tag)), ключ только в env `BIZON_ENCRYPTION_KEY` (в prod отсутствие = падение через instrumentation.ts; dev-fallback — случайный ключ) — `src/lib/security/crypto.ts:13-43`; `decryptOr` — `:98-102`; `hashEmail` HMAC-SHA256 — `:107-110`.
- **rate-limiter.ts** — фиксированные окна на KV (`src/lib/runtime/kv.ts`), maxKeys 100k — `src/lib/security/rate-limiter.ts:30-79`. `getClientIp` доверяет X-Real-IP/XFF только при `TRUST_PROXY` (иначе 'local') — `:98-110`. **LoginBackoff**: экспоненциальная задержка `2^(N-1)` сек, кап 15 мин, ключ IP+hash(email), TTL 15 мин — `:119-187`. `checkRateLimit` (по IP, дефолт 60/мин) — `:192-208`; `checkUserRateLimit` (по user) — `:219-234`.
- **MUTATION_LIMITS** (пресеты) — `src/lib/security/rate-limiter.ts:240-280`: postsCreate 10/час; postsLike 60/мин; postsComment 20/мин; messagesCreate 30/мин; connectionsCreate 20/час; skillsConfirm 20/час; jobsApply 10/час; reviewsCreate 5/час; eventsCreate 10/час; communityPosts 20/час; daoCreate 5/час; daoVote 10/час; adClick 30/мин; savedToggle 60/мин. **AI-лимиты по тарифу** — `:269-279`: matchmaker/career free 5/час, pro 50/час, business 500/час; jobsMatch free 10, pro 100, business 1000/час; выбор ключа `getAiLimitKey` — `:285-306`.
- **anti-fraud.ts (SEC-1 AI-Immunity-Moderator)** — Suspicion Score 0..100: CONFIRM_SPEED +25 (>5 подтверждений/час), NIGHT_HOUR +20 (02:00–05:00), IP_SHARED +30 (1 IP ≥3 пользователей), NO_REPUTATION +25 (ipScore=0 и <7 дней), DEVICE_SHARED +30, RECIPROCAL +40 (взаимные подтверждения за 24ч) — `src/lib/security/anti-fraud.ts:24-31`; авто-заморозка при **score ≥70** на **24 часа** — `:34-37`. Принципы FAIL-OPEN / NON-BLOCKING — `:6-8`.
- **anomaly-detector.ts (SEC-2)** — 4 детектора: OFF_HOUR_ACTIVITY (≥3 действий в 02–05 за 24ч), CONFIRM_BURST (>100 подтверждений/час: SkillConfirmation+ClaimVerification), NEW_LOCATION (новый IP за 30 дней по AuditLog), MASS_MESSAGING (>50 сообщений/час) — `src/lib/security/anomaly-detector.ts:18-33,256-295`; аномалии пишутся в AuditLog как ANOMALY_DETECTED.
- **ssrf.ts (C4)** — блок-лист приватных диапазонов (RFC1918/loopback/link-local/CGNAT/multicast), только http/https, порты 80/443/8080/8443, URL ≤2048, DNS-resolve проверка, `safeFetch` с redirect:'manual' и таймаутом 5с — `src/lib/security/ssrf.ts:19-30,82-170`; `isUrlSafeForStorage` для URL-полей БД — `:177-184`.
- **password-policy.ts** — min 8 / max 1024 (DoS-защита), заглавная+строчная+цифра, блок-лист ~50 common-паролей, запрет последовательностей (1234/abcd/qwerty/…) — `src/lib/security/password-policy.ts:7-75`.

### 1.6 Event Bus (in-process)

`src/lib/event-bus/index.ts`:
- **31 тип события** (`BizonEventType`) — `:25-64`: capital.recomputed, coach.question.generated/answered, coach.insight.confirmed, evidence.added, memory.updated, insight.generated, job.posted/applied/viewed/matched, project.created/completed, claim.verified, post.published/commented, skill.verified, nft.decayed, user.registered, profile.viewed, connection.created, community.joined, event.rsvp, mentorship.started, referral.completed, intent.changed, news.fetched, ad.impression, ad.converted, feed.refreshed, sovereignty.check.failed. Типизированные payload'ы — `:67-102`.
- `publish()` запускает всех подписчиков **параллельно**, ошибка одного не влияет на других; ошибки → DLQ (max 100 записей) — `:208-255,296-311`; статистика `getStats()` — `:278-294`.
- **Подписчики** (`src/lib/event-bus/subscribers.ts:201-222`): job.applied → уведомление-подтверждение кандидату (`:30-56`); skill.verified → CapitalService.recompute + capital.recomputed (`:59-79`); user.registered → welcome-уведомление (`:82-101`); job.viewed → инвалидация кэша `feed-recs:*` (`:161-173`); intent.changed → инвалидация feed-recs (`:183-195`); 13 событий из EVENT_TO_INSIGHT → `BizonAICore.onEvent` (генерация AiInsight) — `:108-152`. Bootstrap — ленивый, только на сервере — `src/lib/event-bus/index.ts:322-335`.

### 1.7 Data Vault и аудит

- `src/lib/data-vault/index.ts:11-15` — фасад: UserVault, AuthVault, PostVault, ReputationVault, AuditLog.
- **AuditLog** (`src/lib/data-vault/audit-log.ts:12-82`): buffered write (flush каждые 5с или при ≥100 записей), действия login/register/read_pii/update_pii/delete/admin_action; 152-ФЗ ст.19; хранение следа — ТЗ 2 года. `logSecurity()` пишет actorId='system' для системных событий — `:44-56`.

### 1.8 Cache

`src/lib/cache.ts` — SimpleCache на Map: `CACHE_TTL.SHORT=30с` (whats-new), `MEDIUM=5мин` (trust-explain, evidence-graph, company trust, feed-recs), `LONG=1час` (hiring-reality) — `:15-19`; hit/miss-счётчики для `/api/metrics` — `:25-46`; `cached(key, ttl, fn)` — `:129-139`; `invalidatePrefix` — `:61-70`. In-memory → не разделяется между инстансами (задокументировано `:6-9`).

### 1.9 Admin guard

`src/lib/admin-guard.ts`: `isAdminRole` — точное совпадение 'admin' в CSV-строке user.roles — `:21-24`; `requireAdmin` → 401/403 — `:35-44`; `adminGuard` → null | Response — `:49-53`. Привилегированные поля (roles и др.) не редактируются через PATCH профиля (FIX-02 P0-2) — `src/app/api/users/[id]/route.ts:164-169`.

### 1.10 AI-инфраструктура (ai-core)

- **AIGateway** (`src/lib/ai-core/gateway.ts`) — единый конвейер всех LLM-вызовов: 1) rate limit на user+operation (default **30/час**, KV) — `:58-75,117`; 2) SHA-256 кэш результата, TTL 1 час — `:47-56`; 3) Sovereignty-проверка + псевдонимизация — `:10-15`; 4) Compute Router + Backpressure-очередь `ai-llm` (maxConcurrent 4, queue 32, reject, wait 5s) + Circuit Breaker (5 неудач, cooldown 30с) — `:77-90`; 5) fallback → локальная эвристика (provider='heuristic'). Model Router: critical/high → 'zai-llm', normal → 'zai-llm-fast', low → heuristic-local — `:140-150`.
- **zai-client** (`src/lib/ai-core/zai-client.ts:1-49`) — ленивый singleton SDK `z-ai-web-dev-sdk` (getZaiClient); SDK инстанцируется ТОЛЬКО здесь и внутри llm-колбэков гейтвея.
- **BizonAICore** (`src/lib/ai-core/index.ts`): InsightType = signal|moment|blind_spot|next_action|opportunity|scenario — `:33`; buildUserContext (кэш 5 мин) — `:80`; EVENT_TO_INSIGHT маппинг — `:242`; onEvent создаёт AiInsight — `:259-330`.
- **Sovereignty Gateway** (`src/lib/sovereignty/gateway.ts`): классы данных A (email/phone/name/bio/location/birthday/ip — строгая PII), B (профессиональные), C (публичные) — `:51-72`; 152-ФЗ для RU, GDPR для EU-стран — `:83-91`; без `consentAiAnalysis` поля класса A не обрабатываются AI; без `consentCrossBorder` внешний compute заблокирован — `:11-23`; `pseudonymizeUser` = `anonymous_user_XXXXX` (5 цифр из SHA-256) — `:99-103`.
- **Compute Router** (`src/lib/compute/router.ts`): классы задач REAL-TIME 3s/critical, INTERACTIVE 15s/high, BATCH 120s/low, EXTERNAL-API 15s/normal — `:69-73`; цепочки провайдеров по приоритету `getChain` — `:325-327`; метрики — `getStats()`.
- **Runtime KV** (`src/lib/runtime/kv.ts:1-60`) — in-memory KV с Redis-совместимым интерфейсом (get/set/delete/expire/ttl/scan/incr/sweep), maxKeys-вытеснение по порядку вставки.
- **Resilience**: circuit-breaker (closed/half-open/open, метрики для /api/metrics) — `src/lib/resilience/circuit-breaker.ts`; backpressure-очереди — `src/lib/resilience/backpressure.ts`.
- **Scaling Controller** (`src/lib/scaling/controller.ts`) — advisory-режим: BIZON_CAPACITY_RPS_PER_REPLICA=20, SLO p95=1000мс, ERROR_RATE_THRESHOLD=0.05 — `:26-29,113`; статусы normal/elevated/high_load/degraded — `:236-243`; рекомендации scale_up/down/stable. HTTP-метрики — `src/lib/scaling/http-metrics.ts` (rps 1м/5м, p50/p95/p99, error rate).

### 1.11 Прочие общие модули

- `src/lib/logger.ts:1-40` — pino; в prod JSON, в dev pino-pretty; redact паролей/токенов/email/телефона.
- `src/lib/errors.ts:15-63` — иерархия BizonError/ValidationError(422)/AuthError(401)/ForbiddenError(403)/NotFoundError(404)/RateLimitError(429).
- `src/lib/reputation.ts` — см. 3.1.
- `src/lib/matchmaker.ts` — см. 3.2.
- `src/lib/research-tests.ts` — см. 3.4 (банк из 3 тестов, детерминированные шкалы).
- `src/lib/skills/level-formula.ts` — см. 3.6; `src/lib/skills/proof-service.ts` — Proof-of-Skill drilldown (5 источников: project/confirmation/claim/result/recommendation) — `src/lib/skills/proof-service.ts:12-45`.
- `src/lib/analytics.ts:1-42` — клиентская отправка событий в Яндекс.Метрику + GA4 (клиент, не backend).
- `src/lib/projects/constants.ts` — нормализация статусов проектов (используется projects/confirm).
- `src/lib/russian-cases.ts` — склонение имён (nameToInstrumental) для news/recommend.

---

## 2. Каталог API-групп

Соглашения: «Auth» = требуемая авторизация (сессия/2FA/роль); вход — поля body/query; «читает/пишет» — Prisma-модели и побочные эффекты (EventBus, уведомления, AI, кэш).

### 2.0 Корень
- **GET /api** — health-check заглушка: `{message:"Hello, world!"}`, без auth — `src/app/api/route.ts:3-5`. **СТАБ** (демо-эндпоинт).

### 2.1 Auth (+2FA)

- **POST /api/auth/register** — регистрация (rate 5/час/IP — `route.ts:23-24`). Вход: email, password (политика §1.5), name, title?, accountType (individual|company|hr_agency), legalForm/website/specialization (для company/hr_agency), **acceptedTos===true обязателен** — `route.ts:46-76`. Читает: User (по emailHash), Referral. Пишет: User (+Company при company/hr_agency — `route.ts:83`), Session; Referral → rewarded (бонус `REFERRAL_BONUS_WEIGHT=5` обоим: reputationEvent referral_joined вес 5 + recompute — `route.ts:27,145-172`); VerificationToken (sha256, 24ч) + письмо sendEmail (fail-open) — `route.ts:190-215`; AuditLog register — `route.ts:218-225`. Ответ: `{user (self view), emailVerificationSent}`; token только в HttpOnly cookie — `route.ts:227-231`. **ГОТОВО**.
- **POST /api/auth/login** — вход (rate 10/мин — `route.ts:29`; backoff 1с→2с→…→15мин на IP+email — `route.ts:43-52`). При 2FA → `{twoFactorRequired:true, tempToken}` (TTL 5 мин) — `route.ts:66-79`; иначе Session + cookie, AuditLog login, запуск runAnomalyDetectionAsync (fire-and-forget) — `route.ts:81-100`. **ГОТОВО**.
- **POST /api/auth/logout** — удаляет сессию из БД + cookie — `src/app/api/auth/logout/route.ts:11-20`. **ГОТОВО**.
- **GET /api/auth/me** — текущий пользователь (toUserSelfView), 401 без сессии — `src/app/api/auth/me/route.ts:9-15`. **ГОТОВО**.
- **GET /api/auth/verify-email?token=** — подтверждение email: ищет sha256-хэш в VerificationToken, помечает user.emailVerified, погашает токен, AuditLog; одноразовый, 24ч — `src/app/api/auth/verify-email/route.ts:20-58`; токен-сервис `src/lib/services/verification-token.ts:31-76`. **ГОТОВО**.
- **POST /api/auth/2fa/enable** — генерирует TOTP-секрет (otpauth:// URL + QR), шифрует AES-GCM, сохраняет + 10 backup-кодов (хэши SHA-256 с солью); подтверждение отдельно через confirm — `src/app/api/auth/2fa/enable/route.ts:25-89`, `src/lib/services/totp-service.ts:29-116`. **ГОТОВО**.
- **POST /api/auth/2fa/confirm** — проверка 6-значного кода, включение `twoFactorEnabled` — `src/app/api/auth/2fa/confirm/route.ts:13-52`. **ГОТОВО**.
- **POST /api/auth/2fa/verify** — полный вход по tempToken + TOTP-код или backup-код (погашается), создание сессии + AuditLog, rate limit — `src/app/api/auth/2fa/verify/route.ts:27-112`; verifyBackupCode — `totp-service.ts:122-155`. **ГОТОВО**.
- **POST /api/auth/2fa/disable** — отключение 2FA (требует пароль; rate limit) — `src/app/api/auth/2fa/disable/route.ts:19-65`. **ГОТОВО**.

### 2.2 Onboarding
- **GET /api/onboarding/status** — текущий шаг онбординга (User.onboardingStep, всего 5 шагов, сценарии по accountType) — `src/app/api/onboarding/status/route.ts:12-42`, `src/lib/services/onboarding-service.ts:16-40,49-95`.
- **POST /api/onboarding/complete-step** — `{step: 1..5}`; монотонно, без откатов, перепрыгивание разрешено — `src/app/api/onboarding/complete-step/route.ts:18-67`, правила — `onboarding-service.ts:87-95`.
- **POST /api/onboarding/skip** — разрешён только при **ipScore > 50** — `src/app/api/onboarding/skip/route.ts:13-45`, `onboarding-service.ts:123-141`. Все **ГОТОВО**.

### 2.3 Пользователи / профиль
- **GET /api/users** — поиск-список пользователей (query q/limit/page/sort), User.findMany + count — `src/app/api/users/route.ts:18-108`. Auth. **ГОТОВО**.
- **GET /api/users/[id]** — публичный профиль: owner → toUserPublic, остальные → **toUserPublicLite без PII** (FIX-02 P0-3); навыки, проекты, общие проекты/навыки с запрашивающим, связь — `src/app/api/users/[id]/route.ts:11-155`. **ГОТОВО**.
- **PATCH /api/users/[id]** — редактирование ТОЛЬКО себя (403 иначе) — `:158-281`. Whitelist полей: name(≤100), title(≤200), avatarUrl (http/https, ≤2048), bio(≤2000, шифруется AES), location(≤200, шифруется), phone(≤50, шифруется), birthday (валидный диапазон), hobbies(≤500), crossDomainOptIn, showHobbiesToHr. **roles/2FA/subscription и др. привилегированные поля игнорируются** — `:164-169`. AuditLog update_pii — `:284-291`. **ГОТОВО**.
- **GET /api/users/[id]/connections** — связи пользователя (query limit 1..100, дефолт 50) — `src/app/api/users/[id]/connections/route.ts:25-62`. **ГОТОВО**.
- **GET /api/users/[id]/common-contacts** — общие контакты (пересечение accepted-связей) — `src/app/api/users/[id]/common-contacts/route.ts:17-108`. **ГОТОВО**.
- **GET /api/users/[id]/persona** — «профессиональная персона»: архетип по навыкам/проектам/NFT/подтверждениям/стажу — `src/app/api/users/[id]/persona/route.ts:23-195`. Читает User, UserSkill, ProjectMember, NFTSkill, SkillConfirmation, CareerEntry. **ГОТОВО**.
- **GET /api/users/[id]/reputation** — репутация через ReputationService.get — `src/app/api/users/[id]/reputation/route.ts:9-28`. **ГОТОВО**.
- **GET /api/users/[id]/transferable** — transferable skills: пересборка навыков пользователя + AI-аннотация через **AIGateway** (operation 'user.transferable', sovereignty — кандидат; SDK только в llm-колбэке, fallback — эвристика) — `src/app/api/users/[id]/transferable/route.ts:35-100,138-225`. **ГОТОВО**.
- **POST /api/users/[id]/view** — фиксация просмотра профиля: ProfileView (дедуп на окно), анонимно для Pro (hidden mode) — `src/app/api/users/[id]/view/route.ts:15-61`. **ГОТОВО**.
- **GET /api/users/recommendations** — «люди, которых стоит знать»: 2-е рукопожатия по контактам → top-8, фолбэк по ipScore; фильтры по навыкам/локации — `src/app/api/users/recommendations/route.ts:39-182`. **ГОТОВО**.
- **GET /api/users/search** — быстрый поиск по name/title (contains) — `src/app/api/users/search/route.ts:9-42`. **ГОТОВО**.

### 2.4 Связи, подписки, граф доверия
- **GET/POST/PATCH /api/connections** — список (`:10-63`), запрос связи `{toUserId, note?}` (создаётся в status='pending'; проверка дублей/самоприглашения) — `:65-97`, приём/отклонение PATCH (status accepted/declined; при accepted — reputationEvent + recompute IP-score обоим, уведомления) — `:99-140`. Rate: MUTATION_LIMITS.connectionsCreate. **ГОТОВО**.
- **POST/DELETE/GET /api/follows** — подписка `{userId}` (unique), отписка, список своих подписок — `src/app/api/follows/route.ts:22-115` (withRoute). **ГОТОВО**.
- **GET /api/trust-graph** — граф доверия: 1-я и 2-я линии связей (accepted) для визуализации — `src/app/api/trust-graph/route.ts:8-57`. **ГОТОВО**.

### 2.5 Feed (+dwell, рекомендации)
- **GET /api/feed** — лента постов через FeedService (см. 3.5): подсекции (all/following/saved/community/reputation/ads), после выдачи публикует `feed.refreshed` — `src/app/api/feed/route.ts:13-34`, `src/lib/services/feed-service.ts:16-209`. Реклама в ленте: только active c moderationScore ≥0.7 — `feed-service.ts:123-124`; impactScore поста = 0.5 + author.ipScore/200 — `:133`. **ГОТОВО**.
- **POST /api/feed/dwell** — батч агрегированного времени просмотра карточек: `{items:[{itemType: job|person|event|company, itemId, topic?, seconds}]}`, лимиты: ≤50 items/батч, seconds 1..300, topic ≤200 — `src/app/api/feed/dwell/route.ts:40-52,84-110,210`; пишет ActionEvent(type='feed_dwell', metadata без PII), дедуп внутри пачки. **ГОТОВО**.
- **GET /api/feed/recommendations** — ядро рекомендаций (935 строк). Auth; кэш 5 мин `feed-recs:<uid>` — `route.ts:460-465`. **Формулы**:
  - decay интереса: `weight = 1/(1 + days_since*0.1)` (A2, doc_agents) — `:59-62,180-183`;
  - implicit-буст просмотров (окно 14 дней): `0.05 × Σweight`, cap **0.25** — `:63-66`;
  - coach-буст (окно 30 дней): токен job_interest → **+0.2**, сфера career_shift → **+0.15** — `:67-70`;
  - dwell-буст (окно 14 дней): ≥10с → полный сигнал, 3..10с → linear seconds/10, <3с → отбрасывается; `0.05 × Σweight`, cap **0.15** — `:73-82`;
  - вакансии 70/20/10: tier exact (точный навык, match = exactHits/required), synonym (синонимы, вес 0.5–0.8 × decay), surprise (только локация, вес 0.35) — `:581-670`; итог matchConfidence = min(1, match+implicit+coach+dwell) — `:687`;
  - люди: 2-е рукопожатия, сортировка по числу общих контактов, топ-8 → 4 + хвост в разведку; фолбэк — top по ipScore (source trending) — `:705-833`;
  - события: ближайшие 12 → 4; компании: топ по culturalScore → 4 — `:835-906`;
  - анти-эхо-камера: фильтр IgnoredTopic (feed|coach); Epsilon-Greedy разведка ~15% (≥6 позиций → min 1, max 3 замены из хвоста пула, помечены exploration+reason) — `:908-919`;
  - выдача: массивы jobs/people/events/companies + interleaved round-robin — `:921-933`.
  **ГОТОВО**.
- **POST /api/feed/recommendations/ignore** — `{topic, reason?, targetId?}` → IgnoredTopic upsert (source='feed'), инвалидация кэша feed-recs — `src/app/api/feed/recommendations/ignore/route.ts:25-94`. **ГОТОВО**.

### 2.6 Посты
- **GET /api/posts** — лента постов (cursor/limit, author include) — `src/app/api/posts/route.ts:20-80`.
- **POST /api/posts** — создание (withRoute, schemas.createPost content ≤5000): лимит Free **5 постов/день** — `:109-118`; для type='commercial' — AI-Ad-Moderator `runAdModerator` (moderationScore <0.4 → block, <0.7 → review — `src/lib/ai.ts:165-213`); imageUrl через SSRF-валидацию; EventService... пишет Post; EventBus `post.published` — `:82-190`. **ГОТОВО**.
- **POST /api/posts/[id]/like** — toggle лайка (PostLike + счётчик likesCount ±1) — `src/app/api/posts/[id]/like/route.ts:9-31`. **ГОТОВО**.
- **POST /api/posts/[id]/comment** — комментарий (schemas.createPostComment; бизнес-лимит 500 в роуте), commentsCount+1, EventBus post.commented — `src/app/api/posts/[id]/comment/route.ts:10-46`. **ГОТОВО**.
- **POST /api/posts/[id]/save** — toggle SavedPost — `src/app/api/posts/[id]/save/route.ts:8-27`. **ГОТОВО**.
- **GET /api/posts/saved** — список сохранённых — `src/app/api/posts/saved/route.ts:9-46`. **ГОТОВО**.
- **POST /api/posts/[id]/respond** — отклик на «коммерческий» пост: создаёт Conversation/Message автору (расшифровка контактов через decryptOr), уведомление, rate limit — `src/app/api/posts/[id]/respond/route.ts:44-134`. **ГОТОВО**.

### 2.7 Сообщества
- **GET /api/communities** — список + myMembership — `src/app/api/communities/route.ts:8-15` → CommunityService.list — `src/lib/services/community-service.ts:14-46`.
- **GET /api/communities/[slug]** — карточка сообщества — `src/app/api/communities/[slug]/route.ts:8-16`.
- **POST/DELETE /api/communities/[slug]/join** — вступление/выход (membersCount±, EventBus community.joined) — `src/app/api/communities/[slug]/join/route.ts:9-29`.
- **POST /api/communities/[slug]/leave** — альтернативный leave — `src/app/api/communities/[slug]/leave/route.ts:11-37`.
- **POST /api/communities/[slug]/posts** — пост в сообщество (schemas.createCommunityPostBySlug ≤5000) — `src/app/api/communities/[slug]/posts/route.ts:11-24`.
- Все через CommunityService — `community-service.ts:47-142`. **ГОТОВО**.

### 2.8 Компании (+claims, cultural signals, паспорт)
- **GET /api/companies** — список (CompanyService.list) — `src/app/api/companies/route.ts:10-40`.
- **POST /api/companies** — создание + Employee(owner) — `:40-70`.
- **GET /api/companies/[id]** — профиль компании: сотрудники, вакансии, рейтинг (avg CompanyReview), аналогичные компании (по industry) — `src/app/api/companies/[id]/route.ts:8-149`.
- **POST /api/companies/[id]/follow** — toggle подписки (CompanyFollower) — `src/app/api/companies/[id]/follow/route.ts:9-22`.
- **GET/POST /api/companies/[id]/reviews** — отзывы; POST требует Employee-связь (иначе 403), schema createCompanyReview (rating 1..5) — `src/app/api/companies/[id]/reviews/route.ts:9-90`.
- **GET /api/companies/[id]/trust** — 4 индекса доверия через CompanyTrustService (кэш 5 мин) — `src/app/api/companies/[id]/trust/route.ts:11-31`; формула — 3.10.
- **GET /api/companies/[id]/cultural-signals** — сигналы культуры (owner/admin — все, остальные — published) — `src/app/api/companies/[id]/cultural-signals/route.ts:13-59`.
- **POST /api/companies/[id]/cultural-signals** — создать/обновить сигнал (5 категорий CULTURE/SALARY/GROWTH/MANAGEMENT/WORK_LIFE — `src/lib/services/cultural-signals-service.ts:8-26`); rating ≤2 → status='pending' (премодерация); только verified-сотрудники — `:59-118`, правила — `cultural-signals-service.ts:59-112`; пересчёт Company.culturalScore — `cultural-signals-service.ts:268-273`.
- **GET /api/companies/[id]/stream** — «живой поток» компании: последние news/projects/jobs/culturalSignals/ActionEvents, объединённые в ленту (375 строк) — `src/app/api/companies/[id]/stream/route.ts:106-374`. **ГОТОВО**.
- **POST /api/companies/[id]/talent-forecast** — TalentForecastService (см. 3.20), rate limit — `src/app/api/companies/[id]/talent-forecast/route.ts:8-47`.
- **GET /api/companies/[id]/workforce-gap** — WorkforceService.gap — `src/app/api/companies/[id]/workforce-gap/route.ts:7-18`.
- **POST /api/companies/[id]/verify** — верификация компании админом; **СТАБ по источнику**: «в реальном проде — интеграция с ЕГРЮЛ API (пока заглушка: простая валидация длины)» — `src/app/api/companies/[id]/verify/route.ts:3,25-84`.
- **GET/POST /api/companies/[id]/claims** — заявки о компании (типы COMPANY_CLAIM_TYPES: см. `src/lib/services/company-claim-service.ts:20-29`); POST — только admin/владелец — `src/app/api/companies/[id]/claims/route.ts:20-133`.
- **POST /api/companies/[id]/claims/[claimId]/verify** — верификация claim (admin) → status='verified' — `src/app/api/companies/[id]/claims/[claimId]/verify/route.ts:13-53`.
- **POST /api/companies/[id]/claims/[claimId]/dispute** — спор по claim (участник) → 'disputed' (снимает verified) — `src/app/api/companies/[id]/claims/[claimId]/dispute/route.ts:14-70`.
- **GET /api/company/intelligence** — Company Intelligence (таймлайн 40 событий: сотрудники/отзывы/сигналы/claims/vacancies/placements, найм-память) — `src/app/api/company/intelligence/route.ts:18-37`, `src/lib/services/company-intelligence-service.ts:32,147-588`. **ГОТОВО**.

### 2.9 Вакансии (jobs) — 20 маршрутов
- **GET /api/jobs** (738 строк): для company/hr_agency — свои вакансии + кандидаты + лимиты постинга `JOB_LIMITS = {company: {free:1, pro:∞, business:∞}, hr_agency: то же, individual: 0}` — `src/app/api/jobs/route.ts:48-54,207-241`. Для individual — поиск: query `q, mode(quick|nl|precise|explore), important(salary,remote,growth,leadership,industry,stability), minSalary, location, workFormat(remote|hybrid|onsite), level, industry, prof=1` (intention-first, Task 7-c/9-g) — `:56-110,243-293`; анти-эхо-камера: скрытые вакансии IgnoredTopic(source jobs|feed, targetId/тема) — `:111-125`; базовый match = overlap/required (пустые skills → 0.3) — `:316-320`.
- **POST /api/jobs** — создание вакансии: проверка лимита тарифа, EventBus `job.posted` — `:681-737`.
- **GET /api/jobs/match** — AI-подбор: 50 активных вакансий, `computeJobMatch` (см. 3.3), summary через LLM, rate limit по тарифу (aiJobsMatch*) — `src/app/api/jobs/match/route.ts:25-96`.
- **GET /api/jobs/saved** — сохранённые + совпадение навыков — `src/app/api/jobs/saved/route.ts:8-48`.
- **POST /api/jobs/[id]/save** — toggle SavedJob — `src/app/api/jobs/[id]/save/route.ts:8-27`.
- **POST /api/jobs/[id]/apply** — отклик: schemas; проверка дубля; resume принадлежит пользователю; считает matchConfidence = computeJobMatch; JobApplication + EventBus `job.applied` — `src/app/api/jobs/[id]/apply/route.ts:27-118`. Rate: jobsApply 10/час.
- **POST /api/jobs/[id]/apply-via-contact** — отклик через знакомого: ищет контакт/со-участника проекта → создаёт ColleagueInquiry посреднику + уведомление + JobApplication (draft/updated) + EventBus job.applied — `src/app/api/jobs/[id]/apply-via-contact/route.ts:12-171`.
- **POST /api/jobs/[id]/chat** — сообщение hiring-менеджеру (или владельцу компании): создаёт Conversation+Message, JobApplication (chat-статус), EventBus job.applied, уведомление — `src/app/api/jobs/[id]/chat/route.ts:11-136`.
- **POST /api/jobs/[id]/view** — просмотр: дедуп 1/сутки по ActionEvent(type='job_viewed', metadata.jobId), EventBus `job.viewed` — `src/app/api/jobs/[id]/view/route.ts:21-88`.
- **POST /api/jobs/applications/[id]/withdraw** — отзыв отклика кандидатом (status='withdrawn') — `src/app/api/jobs/applications/[id]/withdraw/route.ts:9-43`.
- **GET /api/jobs/applications** — мои отклики — `src/app/api/jobs/applications/route.ts:9-41`.
- **PATCH /api/applications/[id]/status** — трекер статусов отклика (только владелец отклика): ALLOWED_TARGETS, отклонение требует rejectReason (≤500), идемпотентный no-op, история переходов statusHistory, ActionEvent — `src/app/api/applications/[id]/status/route.ts:77-236`.
- **GET /api/jobs/[id]/growth** — JobGrowthService: readiness по навыкам (parseRequiredSkillsWithLevels «Skill:L» 1..10) — `src/app/api/jobs/[id]/growth/route.ts:30-52`, `src/lib/services/job-growth-service.ts:41-56`.
- **GET /api/jobs/[id]/hiring-reality** — Hiring Reality Index (11 критериев), кэш 1 час; уровни: ≥70 high, ≥40 medium, иначе low — `src/app/api/jobs/[id]/hiring-reality/route.ts:15-46`, `src/lib/services/hiring-reality-service.ts:42-44,60-365`.
- **GET /api/jobs/[id]/time-value** — «стоит ли тратить время»: рекомендации apply/skip/consider; пороги APPLY: match>80 и hiringReality>70; SKIP: match<60 или hiringReality<40 — `src/app/api/jobs/[id]/time-value/route.ts:22-36`, `src/lib/services/time-value-service.ts:46-51,232-252`.
- **GET /api/jobs/[id]/job-passport** — паспорт вакансии: match-explainable + hiringReality + companyTrust + timeValue + culturalSignals (274 строки) — `src/app/api/jobs/[id]/job-passport/route.ts:25-273`.
- **GET /api/jobs/[id]/match-explain** — explainable match: breakdown skills/trust/growth; **companyFit честный**: если нет Cultural Signals → null (раньше была заглушка 88) — `src/app/api/jobs/[id]/match-explain/route.ts:16,179,347-381`; общая формула — `src/lib/ai.ts:413-468` (skills = matched/required×100; trust = ipScore + min(15, commonContacts×5); candidateFit = skills×0.6 + trust×0.25 + growth×0.15; companyFit = cultural + min(6, verifiedProjects/2)).
- **GET /api/jobs/[id]/verification** — статус верификации вакансии (8 критериев; VERIFIED ≥70, POSTED ≥50) — `src/app/api/jobs/[id]/verification/route.ts:9-19`, `src/lib/services/vacancy-verification-service.ts:41-53`.
- **POST /api/jobs/[id]/verify** — верификация админом → пересчёт статуса — `src/app/api/jobs/[id]/verify/route.ts:12-42`.
- **POST /api/jobs/analyze-url** — анализ URL вакансии: парс домена (2-я часть), токены пути, матчинг по компаниям/вакансиям в БД (SSRF-safe, без внешнего fetch в БД-фазу) — `src/app/api/jobs/analyze-url/route.ts:25-84,85-287`. **ГОТОВО** (эвристика, без LLM).
- **POST /api/jobs/[id]/boost** — платное продвижение: **СТАБ** («заглушка», admin) — ставит boostedUntil — `src/app/api/jobs/[id]/boost/route.ts:1,14-90`.

### 2.10 HR-организации, HR-контакты, placements
- **GET/POST /api/hr-organizations** — список/создание HR-организации (recruiter создаёт org; HrTrustService.agencyTrust в ответе) — `src/app/api/hr-organizations/route.ts:21-157`.
- **GET /api/hr-organizations/[id]** — карточка + placements + trust — `src/app/api/hr-organizations/[id]/route.ts:14-94`.
- **GET /api/hr-organizations/[id]/pipeline** — воронка placements — `src/app/api/hr-organizations/[id]/pipeline/route.ts:14-89`.
- **POST /api/hr-organizations/[id]/recruiters** — добавить рекрутера в организацию (role-check текущего рекрутера) — `src/app/api/hr-organizations/[id]/recruiters/route.ts:14-117`.
- **GET /api/hr-contacts** — исходящие контакты HR (фильтры статусов) — `src/app/api/hr-contacts/route.ts:44-100`.
- **POST /api/hr-contacts** — инициировать контакт: только accountType='hr_agency'; Privacy Shield (`hrInvisible` → 403); блок 7 дней после block; лимит **1 контакт/неделю на пару HR-кандидат** (weekKey unique) — `src/app/api/hr-contacts/route.ts:103-180`.
- **GET /api/hr-contacts/incoming** — входящие контакты кандидата — `src/app/api/hr-contacts/incoming/route.ts:13-54`.
- **POST /api/hr-contacts/[id]/block** — блокировка контакта кандидатом (7 дней) — `src/app/api/hr-contacts/[id]/block/route.ts:12-53`.
- **GET/POST /api/placements** — список/создание placement (анонимный кандидат; лимит анонных — count; HrTrust пересчёт) — `src/app/api/placements/route.ts:18-187`.
- **POST /api/placements/[id]/confirm** — подтверждение закрытия placement сторонами (candidate/company) → при обоих подтверждениях placement.confirmed → пересчёт recruiterTrust — `src/app/api/placements/[id]/confirm/route.ts:12-90`.

### 2.11 Проекты
- **GET /api/projects** — список (фильтры status/visibility) — `src/app/api/projects/route.ts:8-59`.
- **POST /api/projects** — создание (schema createProject) + ProjectMember(owner) — `:60-97`.
- **GET /api/projects/[id]** — карточка с участниками — `src/app/api/projects/[id]/route.ts:9-31`.
- **PATCH /api/projects/[id]** — обновление/авто-join участником (если не member — создаётся) — `:33-99`.
- **POST /api/projects/[id]/confirm** — подтверждение завершения участниками (кворум): GET — статус подтверждений; POST — $transaction: ProjectConfirmation, при полном кворуме → project.status=completed → ReputationEvent project_completed (weight 5, impactScore = computeImpactScore — см. 3.1) всем активным участникам → recomputeIpScoresBulk → уведомления → AuditLog; вне транзакции: ActionEventService moments + EventBus `project.completed` — `src/app/api/projects/[id]/confirm/route.ts:40-67,77-282`.
- **POST /api/projects/[id]/transition** — смена статуса проекта (state-machine, волны подтверждений waveData) — `src/app/api/projects/[id]/transition/route.ts:31-351`; тоже публикует project.completed — `:293`.
- **POST /api/projects/[id]/leave** — выход: ProjectMember.status=left, AuditLog, уведомление владельцу, при последнем участнике — project update; волна подтверждений другим участникам — `src/app/api/projects/[id]/leave/route.ts:30-214`.
- **GET /api/projects/[id]/related-jobs** — похожие вакансии по навыкам проекта — `src/app/api/projects/[id]/related-jobs/route.ts:21-243`.

### 2.12 Claims и навыки
- **GET/POST /api/claims** — список (фильтры, count) / создание claim (участие в проекте проверяется: ProjectMember) — `src/app/api/claims/route.ts:18-131`.
- **GET/PATCH/DELETE /api/claims/[id]** — карточка (с verification), правка (владелец), удаление — `src/app/api/claims/[id]/route.ts:16-174`.
- **POST /api/claims/[id]/verify** — верификация claim (schemas.verifyClaim: status confirmed|rejected, role colleague|manager|client|expert): анти-фрод canConfirm + analyzeConfirmationPattern + runScoreSuspicionAsync; при пороге подтверждений → claim.status='verified' + UserSkill.verificationLevel upgrade + уведомление владельцу — `src/app/api/claims/[id]/verify/route.ts:37-204`.
- **POST /api/skills** — добавить навык: Skill.upsert + UserSkill (unique) — `src/app/api/skills/route.ts:8-52`.
- **POST /api/skills/confirm** — подтверждение чужого навыка: проверка связи (accepted connection ИЛИ со-участие в проекте), дубль — запрет; SkillConfirmation, UserSkill.confirmationsCount+, ReputationEvent skill_confirmed с impactScore = computeImpactScore → EventBus `skill.verified` — `src/app/api/skills/confirm/route.ts:12-114`.
- **GET /api/skills/[id]/confirmations** — кто подтвердил навык — `src/app/api/skills/[id]/confirmations/route.ts:13-50`.
- **GET /api/skills/[id]/evidence** — доказательства навыка (проекты/claims) — `src/app/api/skills/[id]/evidence/route.ts:12-72`.
- **GET /api/skills/[id]/forecast** — SkillFuturesService прогноз — `src/app/api/skills/[id]/forecast/route.ts:7-19`.
- **POST /api/skills/[id]/self-assessment** — self-оценка уровня (AuditLog) — `src/app/api/skills/[id]/self-assessment/route.ts:12-77`.

### 2.13 Репутация
- **POST /api/reputation/recalculate** — recomputeIpScore текущего пользователя — `src/app/api/reputation/recalculate/route.ts:9-20`.
- **GET/POST /api/reputation/snapshots** — история снапшотов IP-score (trend) / ручное создание снапшота (админ/крон; внутри берутся claims и создаётся ReputationSnapshot) — `src/app/api/reputation/snapshots/route.ts:13-93`.
- **GET /api/reputation/evidence** — «доказательства» IP-score: A/B/C/D-компоненты + claims — `src/app/api/reputation/evidence/route.ts:11-130`.

### 2.14 Карьера (career-entries, compass, cv, edu)
- **GET/POST /api/career-entries** — список/создание записей карьерного пути (rate, AuditLog) — `src/app/api/career-entries/route.ts:17-103`.
- **PATCH/DELETE /api/career-entries/[id]** — правка/удаление (владелец, AuditLog) — `src/app/api/career-entries/[id]/route.ts:17-130`.
- **GET /api/career-compass/vacancy-count** — сколько вакансий по запросу (синонимы build-talent + parseRequiredSkillsWithLevels) — `src/app/api/career-compass/vacancy-count/route.ts:26-89`.
- **POST /api/cv/generate** — 3 типа резюме (short/long/cover_letter) через LLM (`generateResume`, AIGateway op 'cv.generate'), собирает профиль/навыки/проекты/careerEntries/job; сохраняет Resume; списывает люмены (LumenService.spend 'cv_generate' cost 2) — `src/app/api/cv/generate/route.ts:22-197`.
- **POST /api/cv/compass** — карьерный компас: runCareerCompass (LLM) → CareerCompass запись; GET — последний — `src/app/api/cv/compass/route.ts:16-152`.
- **GET /api/edu/courses** — каталог курсов (+admin POST создание) — `src/app/api/edu/courses/route.ts:21-144`.
- **GET /api/edu/recommendations** — рекомендация курсов: runEduRecommender (LLM op 'edu.recommend') + детерминированный фолбэк по gap-навыкам — `src/app/api/edu/recommendations/route.ts:16-127`.
- **POST /api/edu/enroll/[courseId]** — запись на курс (UserCourse, дубль запрет, уведомление) — `src/app/api/edu/enroll/[courseId]/route.ts:11-72`.
- **POST /api/edu/complete/[userCourseId]** — завершение курса (100% прогресса) + уведомление; **СТАБ**: NFT-сертификат — «генерируем локальный ID, т.к. смарт-контракта нет» — `src/app/api/edu/complete/[userCourseId]/route.ts:3,12-80`.

### 2.15 События, менторство, наставники, публикации
- **GET/POST /api/events** — список (upcoming, формат/локация) / создание (schema createEvent) — `src/app/api/events/route.ts:10-74`.
- **POST /api/events/[id]/rsvp** — going/not_going (EventService) — `src/app/api/events/[id]/rsvp/route.ts:9-26`.
- **GET /api/events/[id]/attendees** — участники — `src/app/api/events/[id]/attendees/route.ts:12-24`.
- **GET /api/mentors** — подбор наставников по skill gaps (см. 3.13) — `src/app/api/mentors/route.ts:16-40`.
- **GET /api/mentors/[id]/effectiveness** — эффективность ментора (score 0..100: mentee/10×30 + growth×30 + newRole×15 + rating/5×25; <3 mentee — пессимизация) — `src/app/api/mentors/[id]/effectiveness/route.ts:12-25`, `src/lib/services/mentor-service.ts:280-288`.
- **POST /api/mentorships** — запрос наставничества (MentorService.startMentorship: запрет дубля active по той же паре+skill, уведомление ментору, EventBus mentorship.started) — `src/app/api/mentorships/route.ts:17-57`, `mentor-service.ts:383-430`.
- **POST /api/mentorships/[id]/complete** — завершение (только mentee): rating 1..5, growth {skillBefore, skillAfter} — `src/app/api/mentorships/[id]/complete/route.ts:23-58`, `mentor-service.ts:447-480`.
- **GET /api/mentorships** — список моих менторств (см. /api/me/mentorships) — в группе mentors.
- **GET /api/publications** — публикации (фильтры type/status, пагинация) — `src/app/api/publications/route.ts:102-178`.
- **POST /api/publications** — создание (schema createPublication ≤50k, coAuthorIds ≤4 → PublicationAuthor invites + уведомления co-авторам) — `:181-323`.
- **GET /api/publications/[id]** — карточка + авторы — `src/app/api/publications/[id]/route.ts:28-76`.
- **POST /api/publications/[id]/accept | /reject** — принятие/отклонение приглашения со-авторства (уведомления инициатору; accept последнего → publication.status=published) — `src/app/api/publications/[id]/accept/route.ts:11-76`, `.../reject/route.ts:11-56`.

### 2.16 Новости
- **GET /api/news** — лента новостей (published, пагинация) — `src/app/api/news/route.ts:37-78`.
- **GET /api/news/shared** — «поделились со мной» (NewsShare) — `src/app/api/news/shared/route.ts:38-84`.
- **GET/POST /api/news/sources** — персональные/корпоративные источники (JSON в user.newsSources/company.newsSources; SSRF-проверка isUrlSafeForStorage) — `src/app/api/news/sources/route.ts:44-152`.
- **POST /api/news/recommend** — порекомендовать новость пользователю (NewsShare upsert + уведомление, имя в творительном падеже через nameToInstrumental) — `src/app/api/news/recommend/route.ts:15-76`.
- **GET /api/news/moderation** — очередь модерации (admin) — `src/app/api/news/moderation/route.ts:29-65`.
- **POST /api/news/[id]/moderate** — publish/reject/regenerate; regenerate — LLM-резюме через AIGateway (op 'news.summary', SDK только в llm-колбэке) — `src/app/api/news/[id]/moderate/route.ts:47-100,142-178`.
- **GET /api/news/[id]/relevance** — «почему мне это показано»: NewsRelevanceService (эвристика по навыкам/компании/проектам + LLM-объяснение через AIGateway при доступности) — `src/app/api/news/[id]/relevance/route.ts:21-35`, `src/lib/services/news-relevance-service.ts:129-260`.

### 2.17 Сообщения, уведомления
- **GET /api/messages** — список диалогов (Conversation from|to, lastMessageAt desc) — `src/app/api/messages/route.ts:9-38`.
- **POST /api/messages** — отправка: только accepted-связь (иначе 403), Conversation upsert, Message (≤4000), lastMessageAt, уведомление получателю — `:40-95` (schema createMessage). Rate: 30/мин.
- **GET /api/messages/[conversationId]** — сообщения диалога (участник-гейт) + отметить прочитанными (readAt) — `src/app/api/messages/[conversationId]/route.ts:8-33`.
- **GET /api/notifications** — список + unreadCount — `src/app/api/notifications/route.ts:8-24`.
- **POST /api/notifications/read** — отметить все прочитанными — `src/app/api/notifications/read/route.ts:8-19`.
- **GET/PATCH /api/notifications/settings** — настройки частот по типам (instant|daily|off), DND (пишется и в user.dndEnabled) — `src/app/api/notifications/settings/route.ts:12-79`, `src/lib/services/notification-service.ts:27-60,235-265`.
- **GET /api/notifications/stream** — **SSE**: hello-событие, polling-цикл по notification.createdAt > lastSentAt, abort по req.signal — `src/app/api/notifications/stream/route.ts:29-137`.

### 2.18 Поиск
- **GET /api/search** — глобальный поиск (rate 10/мин/user, q ≥2 символа): 5 категорий (users, companies, jobs, communities, projects) + контекстные бейджи (saved/applied/contact/following); preview=1 → 3 на категорию, иначе limit ≤50 (дефолт 20) — `src/app/api/search/route.ts:18-86,41-328`.
- **POST /api/search/semantic** — семантический поиск вакансий (SemanticSearchService: интент-парсинг, синонимы, граф смежных ролей; релевантность = 0.5×навыки + 0.3×роль + 0.1×локация + 0.1×зарплата + vacancyTrust×0.05) — `src/app/api/search/semantic/route.ts:8-26`, `src/lib/services/semantic-search-service.ts:112-298`.
- **GET/POST /api/saved-filters** (+ **PATCH/DELETE /api/saved-filters/[id]**) — сохранённые фильтры поиска (лимит на пользователя — count) — `src/app/api/saved-filters/route.ts:87-176`, `src/app/api/saved-filters/[id]/route.ts:52-132`.

### 2.19 Insights (Bizon Moment), signals, coach
- **GET /api/insights/bizon-moment** — последний unread BIZON MOMENT (AiInsight) — `src/app/api/insights/bizon-moment/route.ts:13-43`.
- **POST /api/insights/bizon-moment/opt-in** — согласие на генерацию (user.bizonMomentOptIn) — `.../opt-in/route.ts:11-30`.
- **POST /api/insights/bizon-moment/dismiss** — пометить dismissed — `.../dismiss/route.ts:11-36`.
- Генерация — BizonMomentService (см. 3.21): не чаще 1/7 дней, 7 паттернов с весами уверенности — `src/lib/services/bizon-moment-service.ts:638-646`.
- **GET /api/me/signals** — 3–5 рыночных сигналов (BizonSignalService; relevance формулы — 3.22) — `src/app/api/me/signals/route.ts:18-35`.
- **GET/POST /api/me/coach/daily-question | answer | discover | insights | insights/[id]** — AI-коуч: вопрос дня (CoachService.ensureDailyQuestion + EventBus coach.question.generated) — `src/app/api/me/coach/daily-question/route.ts:8-29`; ответ на вопрос (coach.question.answered) — `.../answer/route.ts:8-27`; discover — генерация гипотез ≤3/запуск, ≤3/сутки, карантин 7 дней (CoachService.discoverHiddenPotential) — `.../discover/route.ts:8-21`, `coach-service.ts:386-679`; список инсайтов — `.../insights/route.ts:7-19`; подтверждение инсайта (PATCH [id], confirmed=true → IgnoredTopic(source='coach') + ProfessionalIntent.confidence+0.1 cap 1.0 + EventBus coach.insight.confirmed и intent.changed) — `.../insights/[id]/route.ts:34-63`, `coach-service.ts:264-345`.

### 2.20 Возможности, рынок, workforce
- **GET /api/opportunities** — персональные возможности по типам (7 генераторов OpportunityService: jobs/projects/mentors/partnership/experts/courses/events/business; score = relevance × intentAlignment × trust × (0.5 + 0.5×freshness)) — `src/app/api/opportunities/route.ts:28-69`, `src/lib/services/opportunity-service.ts:189-293,1286-1318`.
- **GET /api/opportunities/radar** — топ-5 возможностей за 24ч — `src/app/api/opportunities/radar/route.ts:25-37`, `opportunity-service.ts:293-360`.
- **GET /api/market/intelligence** — Market Intelligence: 5 сегментов SIGNAL/NEWS/IMPACT/OPPORTUNITY/ACTION (top skills 10, hot directions 5) — `src/app/api/market/intelligence/route.ts:18-33`, `market-intelligence-service.ts:45-47,168-736`.
- **GET /api/workforce/overview** — workforce-агрегат компании: сотрудники, gaps, обучение, найм (WorkforceService) — `src/app/api/workforce/overview/route.ts:27-99`.
- **POST /api/team-builder/compose** — сборка команды: жадное назначение + локальный поиск; J = 1.2×coverage + 0.5×meanFit − 0.1×overlap; success = 0.45×coverage + 0.25×meanRoleFit + 0.2×verifiedShare + 0.1×(1−overlap); **запись в БД недоступна** («нет модели Команда») — DTO only — `src/app/api/team-builder/compose/route.ts:28-58`, `team-builder-service.ts:117-122,174,366,512`. **ГОТОВО** (compute), сохранение **СТАБ**.
- **GET/POST /api/build-talent/candidates** — пул талантов под вакансию/навыки (формула — 3.23; limit default 25, max 100) — `src/app/api/build-talent/candidates/route.ts:77-143`.

### 2.21 Социальные механики
- **GET/POST /api/colleague-inquiries** — «спросить коллегу» о человеке: требуются общие проекты (toUser и aboutUser пересечение ProjectMember), isAnonymous скрывает автора, rate = connectionsCreate (20/час), expiresAt TTL — `src/app/api/colleague-inquiries/route.ts:26-88,88-210`.
- **POST /api/colleague-inquiries/[id]/respond** — ответ (или истечение → status='expired') — `src/app/api/colleague-inquiries/[id]/respond/route.ts:12-94`.
- **GET/POST /api/birthday-plans** — планы поздравления коллег (дни рождения), лимит на пользователя — `src/app/api/birthday-plans/route.ts:25-155`; **СТАБ планировщик**: «планировщик напоминаний пока не реализован — сохраняем и сообщаем» — `:136`.
- **PATCH/DELETE /api/birthday-plans/[id]** — правка/удаление — `src/app/api/birthday-plans/[id]/route.ts:11-102`.
- **GET /api/network/birthdays** — ближайшие дни рождения контактов (окно дней) — `src/app/api/network/birthdays/route.ts:44-111`.

### 2.22 DAO
- **GET /api/dao** — список proposals: сначала auto-закрытие истёкших (status + groupBy голосов) — `src/app/api/dao/route.ts:25-90`.
- **POST /api/dao** — создание proposal (schema createDaoProposal; rate daoCreate 5/час) — `:93-125`.
- **POST /api/dao/[id]/vote** — голос (unique user+proposal; счётчики votesFor/votesAgainst) — `src/app/api/dao/[id]/vote/route.ts:8-57`.
- **GET /api/dao/[id]/votes** — список голосов — `src/app/api/dao/[id]/votes/route.ts:14-51`.

### 2.23 Люмены, кошелёк, подписки, рефералка
- **GET /api/lumens** — баланс + последние транзакции — `src/app/api/lumens/route.ts:14-23`.
- **POST /api/lumens/topup** — пополнение: **emailVerified обязателен (403)**; только пресеты **[100,300,500,1000] ₽**; 1₽=1 люмен; демо-шлюз; rate 20/мин — `src/app/api/lumens/topup/route.ts:20-50`, `src/lib/services/lumen-service.ts:31,250-289`.
- **POST /api/lumens/accrue** — демо-начисление дивидендов «как за 30 дней» (rate 10/мин; kill-switch `LUMEN_DIVIDENDS_ENABLED=0`) — `src/app/api/lumens/accrue/route.ts:15-34`, `lumen-service.ts:82-95`.
  - **Формула дивидендов**: `dividend = lumenRubles × 0.15 × (days/365)`; кредитуется только целый люмен, дробный копится в `lumenFraction`; CAS-guard по `lumenAccruedAt` (3 попытки) — `lumen-service.ts:28,97-135`.
- **Списание за AI** (LumenService.spend): career_agent=1, career_scenario=1, cv_generate=2 люменов; guard-декремент `lumenBalance>=cost` + ledger в одной транзакции; refund идемпотентный — `lumen-service.ts:40-44,317-370,370-410`.
- **GET /api/wallet/transfer** — **410 Gone (deprecated)**: «Trust — не валюта» (все методы GET/POST/PUT/DELETE возвращают 410 c code TRUST_NOT_CURRENCY) — `src/app/api/wallet/transfer/route.ts:1-45`. **СТАБ** (намеренно выведен).
- **GET /api/subscriptions** — PLANS (free 0₽; pro 499₽/мес, 4990₽/год; business 1499₽/мес, 14990₽/год) — `src/app/api/subscriptions/route.ts:12-15`, `src/lib/services/payment-service.ts:28-88`.
- **POST /api/subscriptions** — subscribe (schema subscribePlan: pro|business, monthly|yearly; DemoGateway создаёт Subscription мгновенно) — `:17-34`, `payment-service.ts:146-222`.
- **DELETE /api/subscriptions** — отмена (PaymentService.unsubscribe) — `:36-43`.
- **GET /api/subscription** — история подписок (последняя Subscription) — `src/app/api/subscription/route.ts:78-101`.
- **POST /api/subscription/upgrade** — legacy-upgrade: schema upgradeSubscription (pro|business|enterprise), мгновенно меняет tier/until; **внешнего платёжного шлюза нет** (demo) — `src/app/api/subscription/upgrade/route.ts:19-55`.
- **GET /api/referral** — реферальная статистика + ссылка (NEXT_PUBLIC_APP_URL, фолбэк — `src/app/api/referral/route.ts:15-75`). Бонус: reputationEvent weight 5 обоим при регистрации по коду — `src/app/api/auth/register/route.ts:27,145-172`.

### 2.24 Реклама и спонсоры
- **GET /api/ads** — показ объявления: случайный active ad (moderationScore учтён) + AdImpression — `src/app/api/ads/route.ts:9-51`.
- **POST /api/ads** — регистрация клика (последнее impression → clicked=true) — `:53-72`.
- **GET /api/ads/saved** — сохранённые объявления — `src/app/api/ads/saved/route.ts:8-32`.
- **POST /api/ads/[id]/save** — toggle SavedAd — `src/app/api/ads/[id]/save/route.ts:8-27`.
- **GET /api/sponsored** — список спонсорских позиций (владелец — свои) — `src/app/api/sponsored/route.ts:12-29`.
- **POST /api/sponsored** — создание кампании (schema createSponsoredOpportunity: budget ≤10M, cpm ≤10k, targeting skills/industries/intentTypes/locations) — `:29-84`.
- **GET /api/sponsored/feed** — показ в фиде: AdPressureService.canShowAd (лимиты: **MAX_ADS_PER_DAY=5, MIN_ORGANIC_BEFORE_AD=3, MIN_AD_INTERVAL_MIN=30** — `src/lib/services/ad-pressure-service.ts:22-24`), фильтр бюджета spent<budget, таргетинг по навыкам/индустрии/интентам/локации, сортировка cpm desc + лёгкая рандомизация в корзине CPM, top-3 — `src/app/api/sponsored/feed/route.ts:60-143`.
- **POST /api/sponsored/[id]/impression | /click** — фикс показа/клика + списание по CPM (AdPressureService.recordImpression/recordClick) — `src/app/api/sponsored/[id]/impression/route.ts:17-44`, `.../click/route.ts:14-37`.

### 2.25 NFT-навыки
- **GET /api/nft-skills** — список NFT пользователя — `src/app/api/nft-skills/route.ts:9-22`.
- **POST /api/nft-skills** — запрос минта: canMintNftSkill (см. 3.24: ipScore confirmer >10, лимит 3 NFT на confirmer→target, вес Trust Graph); **СТАБ блокчейна**: «в проде вызов смарт-контракта» — `:22-64`, `src/app/api/nft-skills/[id]/mint/route.ts:1`.
- **POST /api/nft-skills/[id]/mint** — минт (status pending→minted) — заглушка контракта — `src/app/api/nft-skills/[id]/mint/route.ts:8-33`. **СТАБ**.
- **GET /api/nft-skills/[id]/weight** — вес подтверждения по Trust Graph + гуманитарная метка (strong ≥0.7, moderate 0.3–0.7, weak <0.3, remote 0) — `src/app/api/nft-skills/[id]/weight/route.ts:15-91`, `nft-skills-service.ts:541-550`.
- **POST /api/nft-skills/stale-check** — batch-проверка устаревания (admin): UserSkill.decayed (>2 лет без подтверждений), NFTSkill.decayStatus (fresh/stale/decayed) — `src/app/api/nft-skills/stale-check/route.ts:15-35`, `nft-skills-service.ts:413-510`.

### 2.26 Cultural signals (глобальные)
- **DELETE /api/cultural-signals/[id]** — удаление (admin) — `src/app/api/cultural-signals/[id]/route.ts:10-26`.
- **POST /api/cultural-signals/[id]/moderate** — moderate (admin: publish/remove) — `src/app/api/cultural-signals/[id]/moderate/route.ts:10-38`.

### 2.27 Исследования (research)
- **GET /api/research/tests** — список тестов + мои результаты (ResearchResult) — `src/app/api/research/tests/route.ts:11-50`.
- **POST /api/research/tests/[key]** — прохождение теста (key ∈ profession|preferences|motivators): подсчёт очков детерминированный (банк тестов — 3.4); интерпретация через **AIGateway** (op 'research.interpret'; SDK в llm-колбэке; provider='llm'|'heuristic' честно) — `src/app/api/research/tests/[key]/route.ts:39-71,71-165`; upsert ResearchResult — `:129`.
- **GET /api/research/insights** — агрегированные инсайты по моим тестам (topScales) — `src/app/api/research/insights/route.ts:15-60`.

### 2.28 Счётчики, метрики, админ, cron, health
- **GET /api/subsections/counts** — бейджи-счётчики для навигации: мои посты/сохранённое/сообщества/отклики/вакансии/реклама/связи + глобальные (posts, active jobs, ads, communities) + hotJobs — `src/app/api/subsections/counts/route.ts:10-87`.
- **GET /api/metrics** — метрики: доступ = METRICS_TOKEN (Bearer) или роль admin — `src/app/api/metrics/route.ts:55-81`; форматы: Prometheus text (дефолт) / JSON (`?format=json`); секции users/content/api/system/http/resilience/compute/scaling — `:105-201`; DB-счётчики — `:238-243`; также cache.sweep().
- **GET /api/admin/metrics** — JSON-снимок для админ-дашборда (requireAdmin или METRICS_TOKEN) — `src/app/api/admin/metrics/route.ts:34-125`.
- **GET /api/admin/data-plane** — состояние data-plane: конфигурация плоскостей, консистентное хэш-кольцо, shard-план сущностей; допускается DATA_PLANE_TOKEN — `src/app/api/admin/data-plane/route.ts:48-61,269-338`.
- **GET /api/admin/causality** — платформенный отчёт причинности (CausalityEngine.platformReport; METRICS_TOKEN/CAUSALITY_ADMIN_TOKEN или admin) — `src/app/api/admin/causality/route.ts:23-50`.
- **POST /api/cron/insights** — cron-генерация коуч-инсайтов: заголовок `x-cron-secret` = env BIZON_CRON_SECRET (иначе 503/401); активные = сессия за 30 дней; ≤500 юзеров/прогон; идемпотентность суток; CoachService.discoverHiddenPotential — `src/app/api/cron/insights/route.ts:34-110`.
- **GET /api/health** — `{status:'ok', db:'connected'}` после db.user.count() — `src/app/api/health/route.ts:17-49`.
- **GET /api/p/[token]** — публичный Professional Passport по токену (≥16 симв; 404 без раскрытия существования; Cache-Control 300) — `src/app/api/p/[token]/route.ts:28-48`.
- **GET /api/c/[token]** — публичный Company Passport (аналогично) — `src/app/api/c/[token]/route.ts:23-43`.
- **GET /api/email/status** — `{smtpConfigured}` (кэш 1 мин) — `src/app/api/email/status/route.ts:13-19`.

### 2.29 Интеграции
- **GET /api/integrations** — **СТАБ**: всегда 3 записи `{connected:false}` (linkedin/github/telegram) — `src/app/api/integrations/route.ts:9-41`.
- **POST /api/integrations/github | linkedin | telegram** — **СТАБ**: 501 `{status:'coming_soon'}` — `src/app/api/integrations/github/route.ts:8-19` (аналогично linkedin/telegram).

### 2.30 AI-эндпоинты
- **POST /api/ai/matchmaker** — «5 рукопожатий» до цели `{toUserId}`: BFS ≤5 по accepted-связям + общим проектам (3.2); ReputationService.recordEvent intro_sent (impactScore) — `src/app/api/ai/matchmaker/route.ts:10-46`.
- **POST /api/ai/career** — карьерный агент: runCareerAgent (LLM op 'ai.career', fallback — статические Now/Next/Future стадии) — `src/app/api/ai/career/route.ts:13-98`, `src/lib/ai.ts:38-156`; rate по тарифу (aiCareer*).
- **POST /api/ai-co-pilot** — плавающий ассистент: withRoute (rate {key:'ai-copilot', limit 10, window 10мин}), zod message 1..2000 + history ≤12×{role, ≤1000}; профиль через buildUserContext; AIGateway op 'ai.copilot' (cacheTtl 10 мин); fallback — canned-ответы (provider='heuristic') — `src/app/api/ai-co-pilot/route.ts:24-73,125-148,203-227`.
- **POST /api/me/ai-analyze** — BizonAICore.analyze (инсайт signal/moment/…; rate limit) — `src/app/api/me/ai-analyze/route.ts:10-26`.

### 2.31 me/* — персональные дашборды (35 маршрутов)
- **PATCH /api/me/accept-tos** — фиксирует acceptedTosAt — `src/app/api/me/accept-tos/route.ts:13-33`.
- **GET /api/me/actions** — мои ActionEvents (фильтр type) — `src/app/api/me/actions/route.ts:30-55`.
- **GET /api/me/moments** — Professional Moments (ActionEventService.getMoments: N последних из PROFESSIONAL_MOMENT_TYPES + синтетика + дедуп) — `src/app/api/me/moments/route.ts:14-36`, `action-event-service.ts:149-261`.
- **GET /api/me/capital** — ProfessionalCapital (без пересчёта) — `src/app/api/me/capital/route.ts:7-18`.
- **POST /api/me/capital/recompute** — CapitalService.recompute + EventBus capital.recomputed — `src/app/api/me/capital/recompute/route.ts:9-29`.
- **GET /api/me/career-discovery** — карьерное открытие: match % по навыкам + история откликов — `src/app/api/me/career-discovery/route.ts:47-180`.
- **GET /api/me/career-outcome** — карьерный исход (CapitalService + jobApplication статистика) — `src/app/api/me/career-outcome/route.ts:72-142`.
- **POST /api/me/career-scenario** — «что если выучу X»: CareerScenarioService (MATCH_THRESHOLD=0.5, время изучения: 3–15 симв ≈2 мес, 16–25 ≈3 мес, >25 ≈6 мес; LLM через AIGateway) — `src/app/api/me/career-scenario/route.ts:19-71`, `career-scenario-service.ts:86,283-285,337-437`; списывает люмены (career_scenario=1).
- **GET /api/me/causality** — персональные причинно-следственные гипотезы (CausalityEngine.personal: топ-K ≤5; окно 180 дней, эффект 14 дней, decay 0.1; кэш 10 мин) — `src/app/api/me/causality/route.ts:17-29`, `causality-engine-service.ts:42-64`.
- **GET /api/me/blind-spots** — слепые зоны: verifiedScore > selfAssessment + **15** (GAP_THRESHOLD); role_mismatch: доля управленческих ролей ≥0.6 и ≥2 — `src/app/api/me/blind-spots/route.ts:15-30`, `blind-spots-service.ts:28,128,200,225`.
- **GET /api/me/coach/** — см. 2.19.
- **GET /api/me/company-passport** + **enable/disable** — паспорт компании: enable — генерирует/переиспользует токен (AuditLog), disable — 404 для /c/<token> — `src/app/api/me/company-passport/route.ts:17-56`, `.../enable/route.ts:29-80`, `.../disable/route.ts:20-59`.
- **POST /api/me/passport/enable | disable | regenerate** — персональный паспорт (PassportService; токен ≥16; regenerate — новый токен) — `src/app/api/me/passport/enable/route.ts:26-61` и соседние.
- **POST /api/me/delete-account** — удаление аккаунта: помечает user (deletedAt/обфускация), удаляет все сессии, AuditLog delete; cookie чистится — `src/app/api/me/delete-account/route.ts:23-98`.
- **POST /api/me/forget-me** — «забудьте меня»: обфускация PII-полей (bio/location/phone/birthday=null, name → «Пользователь»), удаление сессий, AuditLog — `src/app/api/me/forget-me/route.ts:40-144`.
- **GET /api/me/discover** — «Discover»-блок: новые вакансии по навыкам, 2-е рукопожатия, компании с новыми вакансиями, ближайшее событие (381 строка) — `src/app/api/me/discover/route.ts:37-236`.
- **GET/POST /api/me/evidence** — ProfessionalEvidence список/создание — `src/app/api/me/evidence/route.ts:7-47`.
- **GET /api/me/evidence-graph** — граф доказательств доверия (claims/проекты/навыки; кэш 5 мин; 347 строк) — `src/app/api/me/evidence-graph/route.ts:49-346`.
- **POST /api/me/export-data** — экспорт ВСЕХ данных пользователя (40+ таблиц, decryptOr для PII; AuditLog) — `src/app/api/me/export-data/route.ts:42-712`.
- **GET /api/me/history-people** — «люди из истории»: коллеги по прошлым проектам — `src/app/api/me/history-people/route.ts:49-154`.
- **GET /api/me/home-metrics** — метрики доверия для главной (getHomeTrustMetrics) — `src/app/api/me/home-metrics/route.ts:30-41`.
- **GET/POST /api/me/intent** (+ **DELETE /api/me/intent/[id]**) — Professional Intent: явные (confidence 1.0) / AI-выведенные (confidence 0.3–0.7 по сигнальным формулам — 3.18); EventBus intent.changed — `src/app/api/me/intent/route.ts:13-52`, `intent-service.ts:89-160,172-300`.
- **GET /api/me/memory** — нарратив памяти: MemoryService (эволюция) + ProfessionalMemoryService (траектория по годам, milestone ≤12/год) — `src/app/api/me/memory/route.ts:8-28`, `memory-service.ts:19-146`, `professional-memory-service.ts:97-255`.
- **GET /api/me/mentorships** — мои менторства — `src/app/api/me/mentorships/route.ts:16-28`.
- **GET /api/me/next-best-action** — следующее лучшее действие (NextBestActionService: приоритизация по интентам/гэпам; вакансия top-1 match ≥0.4) — `src/app/api/me/next-best-action/route.ts:12-27`, `next-best-action-service.ts:50-261`.
- **GET /api/me/preferences** / **POST** — preferences JSON на user — `src/app/api/me/preferences/route.ts:107-161`.
- **GET /api/me/profile-views** — кто смотрел профиль (Pro-фича; скрытый режим учитывается) — `src/app/api/me/profile-views/route.ts:15-69`.
- **GET/POST /api/me/professional-trust** — Professional Trust (GET — из TrustIndex, пересчёт если >24ч; POST — форс) — `src/app/api/me/professional-trust/route.ts:11-53`, формула — 3.11.
- **GET /api/me/signals** — см. 2.19.
- **GET /api/me/skill-futures** — прогнозы по всем моим навыкам — `src/app/api/me/skill-futures/route.ts:25-73`.
- **GET /api/me/skills/graph** — граф навыков (skill-graph-service, §D.6/D.7) — `src/app/api/me/skills/graph/route.ts:22-51`.
- **GET /api/me/skills/[skillId]/explain** — drilldown навыка — `src/app/api/me/skills/[skillId]/explain/route.ts:18-36`.
- **GET /api/me/skills/[skillId]/proofs** — Proof-of-Skill факты — `src/app/api/me/skills/[skillId]/proofs/route.ts:23-37`.
- **POST /api/me/skills/[skillId]/resurrect** — план восстановления навыка (не мутирует БД) — `src/app/api/me/skills/[skillId]/resurrect/route.ts:22-47`.
- **POST /api/me/sovereignty/check** — проверка легальности AI-операции над полями — `src/app/api/me/sovereignty/check/route.ts:7-20`.
- **GET/PATCH /api/me/sovereignty/update** — согласия consentAiAnalysis/consentCrossBorder (region/citizenship) — `src/app/api/me/sovereignty/update/route.ts:24-120`.
- **GET /api/me/talent-forecast** — персональный прогноз востребованности (TalentForecastService) — `src/app/api/me/talent-forecast/route.ts:49-166`.
- **GET /api/me/trust-explain** — объяснимый Trust: 6 осей (компетентность/надёжность/delivery/лидерство/коллаборация/экспертиза) из «псевдо-формул» с константами 9/14/16/5/15 — `src/app/api/me/trust-explain/route.ts:33-37`; basis (5 фактов), delta30days + trend из ReputationSnapshot; кэш 5 мин — `:43-254`.
- **GET /api/me/trust-state** — внутреннее состояние доверия (TrustStateService: ipScore/level/trend из снапшотов; не для отображения score другим) — `src/app/api/me/trust-state/route.ts:21-35`, `trust-state-service.ts:50-106`.
- **GET /api/me/whats-new** — дайджест «что нового» (кэш 30с): 6 осей trust (leadership = pScore×1.1, expertise = hero×0.95), recent 5 событий с deltaTrust (base: project_completed 22, skill_confirmed 9, intro_sent 4, connection_accepted 3; k = 0.5 + impact; ★ для positive_review), счётчики возможностей (jobs match ≥0.7), whileAway (last Session как прокси визита) — `src/app/api/me/whats-new/route.ts:290-400`.

---

## 3. Каталог сервисов

### 3.1 Reputation Engine — `src/lib/reputation.ts`
- **Формула IP-score** (ТЗ 3.3.1): `IP-score = round((A×0.4 + B×0.3 + C×0.2 + D×0.1) × 100)`, где A = completed/max(3,total) проектов; B = avgRating/5; C = log1p(confirmations)/log1p(20); D = min(events_7d/7, 1) — `reputation.ts:3-8,49`. Clamp 0..100 — `:50`.
- **Уровни**: 0–30 basic, 31–70 extended, 71–100 expert — `:20-24`.
- `recomputeIpScore(userId)` — 4 параллельных запроса + update User — `:69-117`; `recomputeIpScoresBulk` — 3 запроса на N пользователей (FIX-06) — `:128-187`.
- **Impact Score** (Trust Stream): `TrustWeight × Engagement × Relevance`; engagement = rating/5 или 0.3+participants×0.15 или 0.4+confirmations×0.15; relevance по типу: project_completed 1.0, skill_confirmed 0.8, positive_review 0.7, job_matched 0.6, connection_accepted 0.5, intro_sent 0.4, ad_clicked 0.2, default 0.3 — `:194-220`.
- Вызывают: /api/reputation/*, connections PATCH, skills/confirm, projects/confirm|transition, auth/register, ReputationService (дублирующая реализация — `src/lib/services/reputation-service.ts:44` с той же формулой; массовый `grantEventsToUsers` — `:74-141`).

### 3.2 AI-Matchmaker — `src/lib/matchmaker.ts`
- BFS «5 рукопожатий» (MAX_DEPTH=5): соседи = accepted-связи + со-участники проектов — `:11-49,55-83`.
- `computePathConfidence`: `max(0, 1 − (path.length−2)×0.15)` (штраф за длину пути; **упрощение — не средний IP-score**, см. комментарий `:89-93`).
- `findMatch` — путь + профили + introTemplate (шаблон с именами, без LLM) — `:98-168`. Вызывает /api/ai/matchmaker.

### 3.3 Job Matching — `src/lib/ai.ts`
- `computeJobMatch`: `skillMatch×0.6 + (ipScore/100)×0.25 + growthScore×0.15`; нет requiredSkills → 0.3 — `src/lib/ai.ts:234-248`.
- `computeJobMatchExplainable`: skills = matched/required×100; trust = clamp(ipScore + min(15, commonContacts×5)); candidateFit = skills×0.6+trust×0.25+growth×0.15; companyFit = culturalFit (или 88 — **константа-заглушка только при отсутствии Cultural Signals** в базовой функции; match-explain-роут отдаёт null) + min(6, verifiedProjects/2) — `:413-468`.
- `runCareerAgent` (fallback-стадии Now/Next/Future с score 0.5/0.7/0.85) — `:38-156`; `runAdModerator` (temperature 0.2; score<0.4 block, <0.7 review) — `:159-213`; `generateResume` (3 промпта) — `:631-820`; `runCareerCompass` — `:926-1040`; `runEduRecommender` — `:1140-1220`. Все LLM через AIGateway; SDK — только в llm-колбэках.

### 3.4 Research Tests — `src/lib/research-tests.ts`
- 3 теста: «Профессиональный ориентир» (шкалы creator/organizer/analyst/expert/helper, 8 вопросов, опции дают 1–4 очка) — `:52-138`; «Предпочтения в работе» (remote/autonomy/growth/stability/team/balance) — `:143-…`; «Мотиваторы» — далее в файле. Правила честности: вопросы детерминированы, LLM только интерпретация (provider 'llm'|'heuristic') — `:9-16`. Используется /api/research/tests и ai-co-pilot (researchResult как контекст).

### 3.5 FeedService — `src/lib/services/feed-service.ts`
- Подсекции ленты: all/following/saved/community/reputation/ads — `:7-16`.
- Following = connections accepted + community-авторы + follows; impactScore поста = 0.5 + author.ipScore/200 — `:133`; ads: active + moderationScore ≥0.7 — `:123-124`. Вызывает /api/feed.

### 3.6 Skill Level Formula — `src/lib/skills/level-formula.ts` (Spec §D.6/§D.7)
- 4 бакета с saturatingSum: projects w1.0 ceiling 40; confirmations w0.7 ceiling 30; results w0.8 ceiling 20; recommendations+certificates w0.5 ceiling 10 — `:78-91`.
- `total ∈ [0,100]`; `level = clamp(ceil(total/10), 1, 10)`; `confidence = avg(verifierTrust × recency × diversity)` — `:15-17,156-200`.
- Decay: ≤12 мес fresh (×1.0), 12–24 stale (×0.8), >24 decayed (×0.6); peakLevel монотонно не убывает — `:19-23,94-100`.
- Используется skill-graph-service (см. 3.7), роуты me/skills/*.

### 3.7 Skill Graph Service — `src/lib/services/skill-graph-service.ts`
- Строит узлы графа навыков из 4 источников: проекты (weight 1.0, verifierTrust 0.7/0.5), подтверждения (weight 0.7), claims (weight 0.8/1.0, verifierTrust 0.8/0.6), публикации (weight 0.5, self-evidence 0.5) — `:240-354`.
- Recency-кривая: ≤12м → 1.0; 12–24м → 1.0→0.8; >24м → max(0.4, 0.8−0.02×(m−24)) — `:70-80`. verifierTrust = 0.85×ipFactor + 0.15×levelFactor (basic 0 / extended 0.5 / expert 1.0) — `:89-98`.
- При `persist` пишет UserSkill.peakLevel/currentLevel/… — `:408`. `buildSkillExplain` — §D.9; `buildResurrectionPath` — план без записи — `:456-510`.

### 3.8 Capital Service — `src/lib/services/capital-service.ts`
- **8 компонентов** (clamp 0..100) и веса: verifiedExpertise 0.20 (verified-навыки ×15), projectCapital 0.15 (completed ×15), outcomeCapital 0.15 (verified evidence ×20), trustCapital 0.15 (ipScore/5 + бонус уровня expert 15 / extended 8), networkCapital 0.10 (connections ×2), leadershipCapital 0.10 (founder-роли ×20), marketRelevance 0.10 (навыки с >5 активных вакансий ×20), learningVelocity 0.05 (навыки за 30 дней ×10) — `:28-36,70-105`.
- `total = Σ comp×weight` (round 0.01), upsert ProfessionalCapital — `:107-129`.
- **Тренд — СТАБ**: «таблица ProfessionalCapitalSnapshot отсутствует → честно возвращаем stable/0» — `:162-166`. Вызывают /api/me/capital*, subscribers (skill.verified).

### 3.9 Professional Trust — `src/lib/services/professional-trust-service.ts`
- **6 факторов** 0..1: evidenceQuality = 0.6×starFilledAvg + 0.4×confidenceAvg — `:245`; verification = 0.8×(взвеш. evidence) + 0.2×(взвеш. claims), веса уровней claimed 0.1 / verified 0.45 / project_verified 0.75 / expert_verified 1.0 — `:105-109,303-316`; outcome = 0.6×resultShare + 0.4×completedShare — `:267`; recency — кривая §D.7 — `:125-132`; consistency = 0.5×(1−0.25×contradictions) + 0.5×multiConfirmationShare — `:287-291`.
- Пишет TrustIndex (upsert, computedAt; пересчёт если >24ч) — `:407,519-535`. Формула v1 (`TRUST_FORMULA_VERSION='v1'`).
- **Network Influence** = 0.5×(связи/30) + 0.3×(2-е рукопожатия/60) + 0.2×(рекомендации/10), итог 0..100 — `:592-649`.
- **Activity** = 0.6×(события 30д/20) + 0.4×(активные дни/12) — `:672-694`.
- Вызывают /api/me/professional-trust, /api/me/home-metrics, team-builder (trustIndex).

### 3.10 Company Trust — `src/lib/services/company-trust-service.ts`
- 4 индекса: **employer 0.35, business 0.25, delivery 0.25, transparency 0.15** — `:39-42`.
- Cultural: signalsCount ≥5 → 0.9; ≥3 → 0.75; >0 → 0.5 — `:84-86`; business: log1p(20) насыщение — `:98`; delivery: rated ≥3 → 0.9; ≥1 → 0.75 — `:113-114`.
- `recalculate(companyId)` пишет 4 индекса в Company — `:173-190`; `recalculateAll` — `:195-224`. Вызывают /api/companies/[id]/trust, job-passport, time-value, compare.

### 3.11 HR Trust — `src/lib/services/hr-trust-service.ts`
- `recruiterTrust = log1p(closedPlacements) / log1p(20)` (0 → 0.0; 5 → ~0.62; 10 → ~0.83; 20 → ~0.95; 50+ → ~0.99) — `:20-31`; пишет Recruiter.recruiterTrust — `:84-90`.
- `agencyTrust` = среднее по рекрутерам (без рекрутеров → 0) — `:102-140`. Закрытый placement = confirmedByCandidate && confirmedByCompany — `:56-60`. Вызывают hr-organizations, placements.

### 3.12 Notification Service — `src/lib/services/notification-service.ts`
- 7 типов (NOTIFICATION_TYPES — `:17-24`), FORBIDDEN_TYPES=['rating_drop'] — `:27`.
- `notify()` уважает частоту по типу (instant|daily|off) и DND (user.dndEnabled) — `:137-183`; weekly digest (счётчики + reputation-снапшоты) — `:268-340`. Вызывают event-bus subscribers, dozens роутов.

### 3.13 Mentor Service — `src/lib/services/mentor-service.ts`
- `findMentors`: gaps = currentLevel < **7**; менторы = peakLevel ≥ **8**; score = `effectiveness×0.5 + trust×0.3 + mentorLevel×2×0.2` — `:31-34,265-266`.
- Эффективность 0..100: `mentee/10×30 + growthRate×30 + newRoleRate×15 + rating/5×25`; mentee<3 — пессимизация — `:280-288`.
- `startMentorship` (дубль-гейт, уведомление), `completeMentorship` (rating 1..5 + growth) — `:383-480`. Вызывают /api/mentors*, /api/me/mentorships.

### 3.14 Intent Service — `src/lib/services/intent-service.ts`
- 7 IntentType (job_search, project_search, networking, mentor_search, learning, hire_specialist, career_change) — `:36-60`.
- Explicit: confidence 1.0 — `:108-119`. Inferred (окно 30 дней, cap 0.3–0.7): `job_search = 0.3 + applications×0.15 + savedJobs×0.05`; `project_search = 0.3 + projects×0.2`; `networking = 0.3 + connectionsInitiated×0.1 + profileViewsMade×0.02`; `mentor_search = 0.3 + (profileViewsMade−5)×0.02 (cap 0.5)`; `learning = 0.3 + courses×0.15`; `hire_specialist = 0.4 + jobs×0.1` — `:240-269`. Создаются только при confidence ≥0.3 — `:178,292`. Публикует intent.changed — `:326`. Вызывают /api/me/intent, opportunity-service, coach.

### 3.15 Opportunity Service — `src/lib/services/opportunity-service.ts` (1328 строк)
- 7 генераторов возможностей; формулы доверия: jobs `trust = clamp(vacancyTrust/100, 0.3, 1)`, projects `0.5 + owner.ipScore/200`, mentors/experts `ipScore/100`, courses 0.6 (константа), companies `isVerified ? 0.8 : 0.5` — `:415,534,641,718,856,1011`.
- **Итоговый score** = `relevance × intentAlignment × trust × (0.5 + 0.5×freshness)` — `:1286`; freshness линейно 1.0 (сегодня) → 0 (>30 дней) — `:1295-1296`; intentAlignment: прямое 1.0 / смежное 0.5 / нет интентов 0.3 / другие 0.1 — `:1307-1318`. Пороговые подписи relevance ≥0.7/0.4 — `:439-441`.
- Вызывают /api/opportunities*, market-intelligence.

### 3.16 Next Best Action — `src/lib/services/next-best-action-service.ts`
- Приоритизация по: интент, gэпы навыков, неподтверждённые навыки, вакансия top-1 (match ≥0.4 из 50 активных) — `:50-261`. Вызывает /api/me/next-best-action.

### 3.17 Coach Service — `src/lib/services/coach-service.ts`
- `detectSphere` (сферы по ключевым словам) и `tokenizeJobTitle` (токены 3–24 симв.) — экспортируются и используются лентой рекомендаций — `:99-158`.
- Гипотезы коуча: лимиты ≤3/запуск, ≤3/сутки, карантин 7 дней после 2 закрытий подряд — `:386-392`; confidence гипотез 0.6–0.75 (константы по типам) — `:461-651`; viewCount-гипотеза `min(0.85, 0.5 + views×0.05)` — `:627`.
- `confirmInsight`: IgnoredTopic(source='coach') + ProfessionalIntent.confidence +0.1 (cap 1.0) — `:264-345`. Вызывают /api/me/coach/*, /api/cron/insights.

### 3.18 Bizon Signal Service — `src/lib/services/bizon-signal-service.ts`
- 3–5 сигналов (4 типа): рост навыка `relevance = min(0.95, 0.5 + min(0.4, growthPct/200))` — `:211`; фиксированные relevance 0.75/0.8/0.7 для остальных типов — `:284,371,446`. Вызывает /api/me/signals.

### 3.19 Bizon Moment Service — `src/lib/services/bizon-moment-service.ts`
- Генерация инсайта ≤1/7 дней (opt-in гейт) — `:186-255`; анализ профиля (evidence) — `:278-304`.
- 7 паттернов с весами уверенности: reputation_acceleration 0.9, skill_inflation_reverse 0.85, unused_nft_skills 0.8, network_cluster 0.75, cross_domain_bridge 0.7, growth_vector 0.7, role_mismatch 0.65 — `:638-646`. LLM через AIGateway (temperature 0.8) — `:542`. Вызывают /api/insights/bizon-moment*, /api/me/discover.

### 3.20 Talent Forecast — `src/lib/services/talent-forecast-service.ts`
- Воронка: `verifiedFactor = verifiedPool/marketPool × 0.6`; `reachFactor = verifiedFactor + 0.25`; `expectedReach = marketPool × reachFactor × (0.5 + timeFactor×0.5)`; `expectedHire = expectedReach × 0.3 × 0.4` — `:160-166`.
- Сценарии: multipliers conservative 0.7 / realistic 1.0 / optimistic 1.25 — `:92-112`; горизонты 6м 0.75 / 12м 1.0 / 24м 1.15 — `:122-125`; coverage: ≥0.6 moderate, ≥0.3 hard, иначе critical — `:171-172`. Вызывают companies/[id]/talent-forecast, me/talent-forecast.

### 3.21 Hiring Reality — `src/lib/services/hiring-reality-service.ts`
- Индекс из 11 критериев (срок, отклики, оверлап навыков, активность компании, employee-сигналы и др.); уровни: ≥70 high, ≥40 medium, иначе low — `:42-44,60-365`. Вызывают jobs/[id]/hiring-reality, job-passport, time-value, compare.

### 3.22 Time Value — `src/lib/services/time-value-service.ts`
- recommendation apply/skip/consider; пороги: APPLY match>80 && hiringReality>70; SKIP match<60 || hiringReality<40 — `:46-51,232-252`. Вызывают jobs/[id]/time-value, job-passport.

### 3.23 Vacancy Verification — `src/lib/services/vacancy-verification-service.ts`
- 8 критериев; статусы: score ≥70 → verified, ≥50 → posted — `:41-53`; `verify(jobId)` пишет Job.verificationStatus/verificationScore — `:264`. Вызывают jobs/[id]/verification|verify.

### 3.24 NFT Skills Service — `src/lib/services/nft-skills-service.ts`
- **computeWeight** (Trust Graph): прямая связь (accepted ИЛИ общий проект) = **1.0**; через 1 рукопожатие = **0.3**; дальше = 0; общий проект → ×1.5 (cap 1.0) — `:37-46,54-102`.
- canMint: N1 навык с ≥1 подтверждением; N6 confirmer.ipScore > **10**; N4 лимит **3 NFT** от confirmer к target; N2 вес >0 — `:150-158,206-217,233-278`.
- Decay: UserSkill без подтверждений >2 лет → decayed; NFTSkill decayStatus fresh/stale/decayed — `:413-510`. Гуманитарные метки — `:541-550`. Вызывают /api/nft-skills*.

### 3.25 Build Talent / Team Builder — `build-talent-service.ts`, `team-builder-service.ts`
- Общий движок `scoreSkillMatch`: компонент навыка = `0.6×levelFit + 0.4×verificationWeight` (levelFit: соответствие уровню 1 / 0.5 при незаданном требовании; verification: claimed 0.1 / verified 0.45 / project_verified 0.75 / expert_verified 1.0) — `build-talent-service.ts:48-52,182-216`.
- Build Talent: `score = 0.55×skills + 0.25×trust + 0.20×activity` (компоненты без данных исключаются, веса нормализуются) — `:43,61,263,362-364`. Синонимы: SkillSynonym + Skill (~119 синонимов) — `:112-118`.
- Team Builder: жадное назначение ролей по дефицитности + локальный поиск заменой; `J = 1.2×coverage + 0.5×meanFit − 0.1×overlap`; success = `0.45×coverage + 0.25×meanRoleFit + 0.2×verifiedShare + 0.1×(1−overlap)` — `team-builder-service.ts:117-122,366,512`. Сохранение команды — СТАБ (нет модели) — `:174`.

### 3.26 Market Intelligence — `market-intelligence-service.ts`
- 5 сегментов (SIGNAL/NEWS/IMPACT/OPPORTUNITY/ACTION), top skills 10, hot directions 5 — `:45-47`; агрегаты по job/news/ad/placement за 30 дней — `:412-419,629-668`. Сборка из BizonSignalService + OpportunityService + ActionEventService — `:31-34`.

### 3.27 Workforce — `workforce-service.ts`
- Gap-анализ по навыкам сотрудников vs вакансии; каталог курсов для Training; менторские пороги согласованы с mentor-service (7/8) — `:223-226,336-340`; полная цепочка doc_a §35 — `:445`. Вызывает /api/workforce/overview, companies/[id]/workforce-gap.

### 3.28 Causality Engine — `causality-engine-service.ts` (1773 строки)
- Константы: окно 180 дней, эффект 14 дней, минимум наблюдения 3 дня, baseline 3 дня, events ≤1000 (personal) / ≤3000 (platform), negligible 0.01/день, decay 0.1, кэш 10 мин, top-K 5 — `:42-64`.
- Персональные гипотезы (action → effect на 14-дневном окне; монотонность доз ±0.005/0.01) + платформенный отчёт — `:303,652,839,1755-1767`. Вызывают /api/me/causality, /api/admin/causality.

### 3.29 Semantic Search — `semantic-search-service.ts`
- Интент-парсинг, SkillSynonym, граф смежных ролей ADJACENT_ROLE_GRAPH — `:60-138`; релевантность вакансии = `0.5×навыки + 0.3×роль + 0.1×локация + 0.1×зарплата + vacancyTrust×0.05` — `:234-298`. Вызывает /api/search/semantic, /api/jobs (GET advanced).

### 3.30 Lumen Service — `lumen-service.ts` — см. 2.23 (формулы дивидендов/списаний/kill-switch). Вызывают lumens/*, cv/generate, ai/career, me/career-scenario.

### 3.31 Payment Service — `payment-service.ts`
- PLANS free/pro/business (цены — 2.23) — `:28-88`; gateway-контракт (demo|external) — `:90-146`; **DemoGateway** — мгновенная активация Subscription — `:146-222`; ExternalGatewayAdapter — каркас для внешнего провайдера — `:223-264`; webhook — `:329`. Вызывают /api/subscriptions.

### 3.32 Прочие сервисы (кратко)
- **ActionEventService** (`action-event-service.ts`): 20+ ActionEventType, PROFESSIONAL_MOMENT_TYPES, getMoments (N последних + синтетика из снапшотов/подтверждений/откликов/HR-контактов/верификаций + дедуп (type, day, title)) — `:17-61,149-261`. Вызывают feed/dwell, jobs/[id]/view, me/actions|moments, projects/confirm и др.
- **AdPressureService** (`ad-pressure-service.ts`): MAX_ADS_PER_DAY=5, MIN_ORGANIC_BEFORE_AD=3, MIN_AD_INTERVAL_MIN=30; таблица AdPressure; pressure low 0–1 / medium 2–3 / high 4–5+ — `:22-24,192`. Вызывают sponsored/*.
- **Auth Service** — см. 1.1.
- **BizonAICore** — см. 1.10.
- **BlindSpotsService** — GAP_THRESHOLD 15; role_mismatch порог 0.6 — `blind-spots-service.ts:28,200,225`.
- **CommunityService / CompanyService / EventService** — тонкие CRUD-обёртки над Prisma с count-поддержанием — `community-service.ts`, `company-service.ts`, `event-service.ts`.
- **CompanyClaimService**: типы claims (COMPANY_CLAIM_TYPES — `company-claim-service.ts:20-29`), статусы claimed/verified/disputed/rejected — `:31`; **truthScore = verified/total×100** (total=0 → 0) — `:239-246`. Вызывают companies/[id]/claims*.
- **CompanyIntelligenceService** — таймлайн ≤40 событий — `company-intelligence-service.ts:32`.
- **CompanyPassportService / PassportService** — токены ≥16 симв., enable/disable/regenerate; паспорт — без внутренних полей скоринга — `company-passport-service.ts:88-133`, `passport-service.ts:130-194`.
- **CulturalSignalsService** — 5 категорий, премодерация rating ≤2, пересчёт Company.culturalScore — см. 2.8.
- **EmailService** (`email-service.ts`): SMTP через nodemailer; без SMTP — лог в консоль (dev); HTML-шаблоны; reengagement-письма (reputation_growth/new_jobs/skill_confirmed) — `:14-64,311`.
- **HrTrustService** — см. 3.11.
- **JobGrowthService** — parse «Skill:L» (L 1..10, DEFAULT_REQUIRED_LEVEL=3) — `job-growth-service.ts:18,41-56`.
- **MemoryService / ProfessionalMemoryService** — версии нарратива (ProfessionalNarrative), траектория по годам (milestone ≤12/год, фокус management/specialist/mixed по доле ролей ≥0.5) — `memory-service.ts:19-146`, `professional-memory-service.ts:97-255`.
- **MonService** — **СТАБ частично**: in-memory события (KV), drop-off точки — заглушки с isStub:true (Фаза 3) — `mon-service.ts:149-175`. Маршрутом напрямую не используется (только index.ts реэкспорт).
- **NewsRelevanceService** — причины релевантности (skills/company/projects) + LLM через AIGateway (temperature 0.4) — `news-relevance-service.ts:129-260`.
- **OnboardingService** — 5 шагов × accountType; skip при ipScore>50 — см. 2.2.
- **ProfessionTemplateService** — конфиг секций профиля по профессии — `profession-template-service.ts:143`.
- **SkillFuturesService** — `demand36m = clamp(demand12m × (0.8 + momentum×0.5), 0, 100)`; направление rising >×1.1 / declining <×0.9; impact-факторы: demand/50 (cap 0.4), verifiedShare×0.25, confirmations/100 (cap 0.2), growth×0.15; confidence `min(0.85, 0.3 + min(0.3, demand/30) + verifiedShare×0.25)`; дисклеймер «эвристическая модель v6.0, внешние данные — roadmap v6.3» — `skill-futures-service.ts:52-99`.
- **TrustStateService** — ipScore/level/trend из ReputationSnapshot; предупреждение «не передавать score наружу» — `trust-state-service.ts:52-59`.
- **VerificationToken** — sha256-токены email, TTL 24ч — `verification-token.ts:18-76`.
- **TotpService** — см. 1.1.

---

## 4. Карта сигналов «действие → API → сервис → БД → эффект в UI/у других»

| Действие пользователя | API | Сервис/библиотека | Запись в БД | Что изменится |
|---|---|---|---|---|
| Подтвердил навык коллеги | POST /api/skills/confirm | computeImpactScore (`reputation.ts:194`) | SkillConfirmation; UserSkill.confirmationsCount+1; ReputationEvent(skill_confirmed); Notification | EventBus `skill.verified` → CapitalService.recompute + AiInsight; IP-score владельца растёт (C = log1p/20); навык сильнее в match/поиске |
| Запросил связь | POST /api/connections | — | Connection(pending) | У получателя бейдж+уведомление; при accepted → recompute обоих, появляются в trust-graph и 2-е рукопожатия у общих знакомых |
| Принял связь | PATCH /api/connections | ReputationService | Connection(accepted); ReputationEvent(connection_accepted) | Пара появляется в /api/trust-graph, recommendations «люди», matchmaker-граф |
| Создал пост | POST /api/posts | runAdModerator (для commercial), SSRF-проверка URL | Post; ActionEvent | Лента подписчиков (FeedService), EventBus post.published → AiInsight; счётчик в subsections/counts |
| Смотрел вакансию | POST /api/jobs/[id]/view | decay 0.1 (feed) | ActionEvent(job_viewed, дедуп 1/день) | EventBus job.viewed → инвалидация feed-recs; коуч-гипотеза job_interest (metadata.jobTitle); буст вакансий этой темы ≤+0.25 |
| Смотрел карточку ленты ≥10с | POST /api/feed/dwell | dwell-буст ≤+0.15 | ActionEvent(feed_dwell) | Следующий GET /api/feed/recommendations поднимает карточки той же темы |
| Откликнулся на вакансию | POST /api/jobs/[id]/apply | computeJobMatch (`ai.ts:234`) | JobApplication(+matchConfidence) | EventBus job.applied → уведомление-подтверждение; вакансия в applications; HR видит кандидата с match% |
| HR инициировал контакт | POST /api/hr-contacts | Privacy Shield, weekKey | HrContact(pending) | Кандидат видит в /api/hr-contacts/incoming; блок/статусы через block-роут |
| Подтвердил завершение проекта | POST /api/projects/[id]/confirm | computeImpactScore + recomputeIpScoresBulk | ProjectConfirmation; Project(completed); ReputationEvent(project_completed, w5); Notification×N; AuditLog | EventBus project.completed; IP-score всем участникам; Moments «Завершён проект»; what's-new deltaTrust |
| Подтвердил инсайт коуча | PATCH /api/me/coach/insights/[id] | CoachService.confirmInsight | CoachInsight(confirmed); IgnoredTopic(source=coach); ProfessionalIntent+0.1 | EventBus coach.insight.confirmed + intent.changed → пересчёт рекомендаций ленты |
| Обновил PII профиля | PATCH /api/users/[id] | encrypt() AES-GCM | User(*Encrypted); AuditLog(update_pii) | Профиль/поиск/экспорт; без расшифровки поле недоступно никому |
| Сгенерировал резюме | POST /api/cv/generate | generateResume (AIGateway), LumenService.spend(2) | Resume; LumenTransaction(spend) | Баланс люменов падает на 2; резюме в профиле |
| Отклонил тему в ленте | POST /api/feed/recommendations/ignore | анти-эхо-камера | IgnoredTopic(feed) | Кэш feed-recs сброшен; тема исключена из ленты/вакансий |
| Пополнить кошелёк | POST /api/lumens/topup | LumenService.topup | User.lumenBalance/lumenRubles; LumenTransaction(topup) | Дивидендная база увеличена (0.15×days/365); kill-switch env |
| Купил Pro | POST /api/subscriptions | PaymentService.subscribe (demo) | Subscription; User.subscriptionTier/until | Снимает лимиты: посты, AI-лимиты ×10 (rate-limiter), профильные аналитики |
| Зарегистрировался по коду | POST /api/auth/register | ReputationService.recordEvent(×5) | User; Company?; Referral(rewarded); VerificationToken | Оба получают reputationEvent w5 → IP-score; welcome-уведомление (EventBus user.registered) |
| Прошёл тест исследования | POST /api/research/tests/[key] | AIGateway interpretation | ResearchResult(upsert) | Контекст для ai-co-pilot; scale-профиль в research/insights |
| Публикация от компании | POST /api/companies/[id]/cultural-signals | CulturalSignalsService | CulturalSignal (pending при rating≤2) | culturalScore компании (после верификации модератором) → фид компаний, companyFit в match |
| Завершил курс | POST /api/edu/complete/[userCourseId] | — | UserCourse(completed); Notification | СТ: NFT-сертификат — заглушка локального ID |
| Advertiser click | POST /api/sponsored/[id]/click | AdPressureService | SponsoredOpportunity.spent+; ActionEvent | Кампании с spent<budget показываются в sponsored/feed (cpm desc) |

---

## 5. Известные стабы и несоответствия (сводка для аудиторов)

1. **GET /api** — hello-world заглушка (`src/app/api/route.ts:3`).
2. **Интеграции** (linkedin/github/telegram) — 501/константы (`src/app/api/integrations/*`).
3. **wallet/transfer** — 410 Gone (Trust ≠ Currency, намеренно) (`src/app/api/wallet/transfer/route.ts`).
4. **NFT-минт и сертификат edu.complete** — «заглушка смарт-контракта», локальные ID (`nft-skills/[id]/mint/route.ts:1`, `edu/complete/[userCourseId]/route.ts:3`).
5. **companies/[id]/verify** — ЕГРЮЛ-интеграция заменена валидацией длины (`companies/[id]/verify/route.ts:3`).
6. **jobs/[id]/boost** — платное продвижение-заглушка (admin-only) (`jobs/[id]/boost/route.ts:1`).
7. **Company Fit 88** — константа в `computeJobMatchExplainable` при отсутствии Cultural Signals; match-explain-роут честно отдаёт null (`ai.ts:464` vs `jobs/[id]/match-explain/route.ts:347-381`).
8. **CapitalService.getTrend** — всегда stable/0 (нет таблицы снапшотов капитала) (`capital-service.ts:162-166`).
9. **MonService.getDropoffPoints** — isStub:true (`mon-service.ts:149-175`).
10. **birthday-plans** — планировщик напоминаний не реализован (`birthday-plans/route.ts:136`).
11. **Team Builder** — compose считает, но не сохраняет (нет модели «Команда») (`team-builder-service.ts:174`).
12. **matchmaker confidence** — формула `1 − (path−2)×0.15`, а не заявленный «средний IP-score участников» (`matchmaker.ts:89-93`).
13. **/trust-explain 6 осей** — «псевдо-формулы» с подобранными константами 9/14/16/5/15 (`me/trust-explain/route.ts:32-37`).
14. **SkillFuturesService** — эвристика v6.0, внешние market-data только в roadmap (`skill-futures-service.ts:99`).
15. **Ad в ленте** — модерация через runAdModerator только при создании commercial-постов; в /api/feed фильтр moderationScore ≥0.7 (`feed-service.ts:123-124`).
16. **Subscription upgrade legacy** — активирует тариф без реального платежа (`subscription/upgrade/route.ts`); реальный путь — /api/subscriptions (DemoGateway).
17. **me/delete-account** — мягкое удаление; замечание в коде: auth.ts ещё не фильтрует deletedAt (TODO) (`me/delete-account/route.ts:45`).

---

## 6. Статистика покрытия

- **API-роутов**: 249 файлов `route.ts` (все перечислены в разделах 2.0–2.31).
- **Сервисов**: 54 файла в `src/lib/services/` (+index.ts) — все описаны в разделе 3 (+ключевые либы: reputation, matchmaker, research-tests, level-formula, proof-service, event-bus, data-vault, ai-core, sovereignty, compute, data-plane, scaling, resilience, runtime/kv, security/*, cache, validation, api-helpers, with-route, admin-guard, logger, errors, analytics).
