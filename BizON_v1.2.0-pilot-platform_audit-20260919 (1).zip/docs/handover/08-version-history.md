# BizON — История версий

> Полный журнал работ (логи агентов, append-only): `worklog.md` (2400+ строк) в корне архива.

---

## v1.1.1-pilot-ready — 2026-09-16 (текущая)

- **Дозакрытие хвостов ре-аудита 15-09 (w2.5)**: DEF-05 (docs: Follow/`/api/follows` честно «НЕ РЕАЛИЗОВАНО»), DEF-12 (Next Best Actions: хардкод → реальный `NextBestActionService` + `GET /api/me/next-best-action`), DEF-23 (Transactional Outbox: модель `EventOutbox` + `emitDurable` persist→publish + `drainOutbox` at-least-once + 3 теста; проводка project.completed/project.confirmed), H11 (rate-limits на money/AI/PII-мутации: lumens 30/мин, ai тарифные, auth 10/мин+backoff, 2fa 5/мин), H13 (PII-инвентаризация `scripts/pii-inventory.mjs`: 39/252 роутов, MUST-AUDIT 10/10 с AuditLog), DEF-16 критичные классы (auth/2fa/lumens/me-delete → withRoute+zod+rate-limit, 15 файлов).
- **Стабилизация тестов (16-09)**: найден root cause флака w3 kill-switch — фоновые AI-инсайты (реальные SDK-вызовы) загрязняли общий backpressure-очередь/circuit breaker гейтвея; фикс: env-gate `BIZON_AI_INSIGHTS=0` в тестах (прод не затронут). Результат: **79/79 × 5 прогонов подряд**.
- **Независимая ре-верификация всех закрытых пунктов**: код (file:line) + рантайм (live rate-limit 30/мин: 35 запросов → 30×200+5×429; live next-best-action; браузер: лендинг/дашборд/Trust 0/100 честный, консоль чистая).
- Гейты: tsc 0 · lint 0 · каталог-гейт OK 90 моделей/252 роутов · PII-гейт OK 10/10.
- Остатки (честно, вне песочницы): DEF-30 (полный build → CI-джоба ci.yml), DEF-21/IP-pinning (egress-proxy — путь, рекомендованный самим отчётом; external fetch OFF), withRoute на все 252 (критичные классы закрыты, остальные — поэтапно).
- Пакет аудита: `gpt-audit/16-09-2026/` (архив + sha256 + отчёт «что требовалось → что сделано»).

## v1.1.0-pilot-ready «Honest Pilot» — 2026-09-15

- Закрытие всех P0-дефектов аудита rc.1 (DEF-06/07/15/18/19/20/24/30-частично), волны W1–W5, 44 теста, golden-сценарии 10/10, governance-слой (9 моделей Ai*), миграция email-шифрования (0 plaintext), пост-фиксы (CSP dev, стабильный dev-ключ).
- Пакет аудита: `gpt-audit/audit-15-09-26/`.

## v1.0.0-rc.1 «Audit Snapshot» — 2026-09-11

- Кодовая база заморожена для внешнего аудита.
- Собран пакет документации `docs/handover/` (00–08 + промт GPT-анализа).
- Архив: `BizON_v1.0.0-rc.1_audit-20260911.zip` (исключены node_modules/.next/legacy-копии/секреты).
- Создан `.env.example`; package.json зафиксирован как `bizon` v1.0.0-rc.1.
- Изменений в коде приложения **нет** (заморозка).

## 2026-09-10 — Волны качества после FIX-волны

- **Волна A** (5/5), **Волна B** (6/6), **Волна C** (5/5), **P0-волна** (2/2), **волна быстрых побед A–I** (5/5) — закрытие хвостов аудита STUBS: AI Co-Pilot на реальном LLM через AIGateway, честные fallback'и, доступ «Связи/Проекты»-диалогов (Волна D), уведомления, метрики, навигация. Детали — в `worklog.md` (Task ID волн).

## 2026-09-10 — FIX-волна FIX-01…FIX-09 (балл 5,4 → 7,4)

- Источник: внешний аудит v1.0 (`docs/AUDIT-2026-09-10.pdf`). Отчёт «было → стало»: `docs/AFTER-AUDIT.md`.
- 4×P0 безопасности (demo-бэкдор → env-гейт; эскалация admin; PII-утечка → Lite-проекция; 2FA-обход → tempToken).
- Деньги: CAS-дивиденды, атомарный spend+ledger, идемпотентный refund (`refundOf @unique`), индексы, N+1-fixes.
- withRoute на 21 мутирующий хендлер; admin-guard в 16+ роутах.
- Дизайн: primary-пара тёмной темы 2,26:1 → ~12:1, success-text, таб-бар 5+1 + FAB, микротекст <12px → 0, skip-link.
- Продукт: email-верификация + оферта `/legal` + ToS; kill-switch `LUMEN_DIVIDENDS_ENABLED`; `docs/DECISIONS.md` (возврат 100%, дивиденды → бонусная программа).
- Gates: lint 0 errors; tsc 0 (strict + noImplicitAny); ignoreBuildErrors: false.

## Ранее — Волны 1–11 (см. docs/CHECKPOINT.md)

1. Каркас платформы (одна страница, все разделы внутри).
2. Принцип «только реальные данные» (Prisma-источник всего).
3. Professional Trust / IP-score + глоссарий (13 терминов).
4. Вакансии: фильтры, бусты.
5. События: дни рождения, BirthdayPlan.
6. Мессенджер + уведомления.
7. Онбординг-фильтры (белый список валидации — эталон).
8. Explore-вопросник (9 шагов).
9. Подразделы и счётчики `/api/subsections/counts`.
10. ESLint + tsc в гейты.
11. Люмены (кошелёк, транзакции) + NewsShare «Рекомендовано …» + внешний анализ по `docs/ANALIZ-INSTRUKCIYA.md`.

## Legacy (вне архива)

- Версии v5.0/v6.0 и их аудиты лежали в `bizon-recovery/` и `download/` — в архив текущей версии **не включены** (дубликаты кода; исторические отчёты упомянуты в PRE-LAUNCH.md).
