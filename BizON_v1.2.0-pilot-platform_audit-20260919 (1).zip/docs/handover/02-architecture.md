# BizON — Архитектура системы

> Документ пакета внешнего аудита. Версия v1.0.0-rc.1 (2026-09-11).
> Нижележащие детали: 03-модель данных, 04-API и сервисы (включая формулы), 05-UI.

---

## 1. Технологический стек

| Слой | Технология | Версия/файл |
|---|---|---|
| Framework | Next.js App Router (SPA-подход: одна страница `/`, view-switch) | `next ^16.1.1` (live: next-server v16.1.3), `next.config.ts` |
| Язык | TypeScript strict + `noImplicitAny: true`, `ignoreBuildErrors: false` | `tsconfig.json` |
| UI | React 19 + Tailwind CSS 4 + shadcn/ui (New York) + Lucide + framer-motion | `components.json`, `src/components/ui/*` (48 компонентов) |
| Состояние | zustand (клиент), in-memory cache (сервер) | `src/stores/app-store.ts` (379 строк), `src/lib/cache.ts` |
| Данные | Prisma 6 + SQLite `db/custom.db` (1.6 MB, включён в архив) | `prisma/schema.prisma` (1910 строк, 80 моделей) |
| Runtime | Bun (dev-сервер `bun run dev`, порт 3000, лог `dev.log`) | `package.json` |
| AI | `z-ai-web-dev-sdk ^0.0.18` — только в backend | `src/lib/ai-core/*` (см. 06-документ) |
| Прочее | nodemailer 7 (письма), otplib 13 (2FA TOTP), qrcode, sonner (тосты), recharts, uuid | `package.json` |

## 2. Топология приложения

- **Видимая страница одна — `/`** (осознанное архитектурное решение, зафиксировано в `docs/CHECKPOINT.md`). Все разделы — клиентские view, переключение в `src/app/page.tsx:109-146` (карта view → компонент: dashboard, feed, jobs, profile, me, companies, hr, network, messages, events, communities, projects, dao, mentor, opportunities, truth, career, research, edu, settings, search и др.).
- Прочие реальные маршруты: `/search` (результаты поиска), `/legal` (оферта/условия люмен-программы), `/p/[token]` (публичный паспорт специалиста), `/c/[token]` (публичный паспорт компании), `/api/**` (249 роутов).
- **Shell** (`src/components/shell/app-shell.tsx`): TopBar + левый сайдбар-дерево (desktop) / нижний таб-бар 5+1 + FAB `bottom-20` (mobile, grid-cols-5), правая панель подразделов `sub-section-bar.tsx`, FAB-диалоги создания `fab-create-dialogs.tsx`. Полное дерево навигации — 05-документ §1.
- Навигационная история для «Назад» — в zustand store (05 §4.3).

## 3. Backend-слои

```
Клиент (view/компоненты)
  → fetch("/api/...")           — только относительные пути
  → API routes (249, 31 группа) — src/app/api/**/route.ts
  → сервисы (54)                — src/lib/services/*.ts + lib-ядра (reputation.ts, ai.ts, matchmaker.ts…)
  → Prisma Client (singleton)   — src/lib/db.ts → SQLite db/custom.db
```

- **withRoute** (`src/lib/with-route.ts`): композер хендлеров — auth + zod-схема + rate-limit + единый try/catch + маппинг ошибок (BizonError/P2002→409/P2025→404). Покрыт **21 ключевой мутирующий хендлер**; остальные ~228 — классический паттерн `getAuthUser()` + try/catch (осознанный долг, перевод «при касании»).
- **api-helpers** (`src/lib/api-helpers.ts`): проекции пользователя `toUserPublicLite` (без PII) / `toUserSelfView`, decrypt-хелперы. Известный дефект: `api-helpers.ts:146-148` — при ошибке расшифровки поле теряется без fallback на plaintext (в бэклоге).
- **Event-bus** in-process (`src/lib/event-bus/`): pub/sub для доменных событий → подписчики создают уведомления и пр.
- **Cache** in-memory (`src/lib/cache.ts`) + `src/lib/runtime/kv.ts`. Приемлемо для одного воркера; Redis — при прод-деплое.
- **Валидация**: zod-схемы `src/lib/validation.ts`; эталонный паттерн белого списка — `api/me/preferences/route.ts`.
- **Резилиентность/скейлинг**: `src/lib/resilience/` (circuit-breaker, backpressure), `src/lib/scaling/` (controller, http-metrics), `src/lib/data-plane/` (shard/region-router — задел под PostgreSQL-шардирование), `src/lib/compute/router.ts` (роутинг AI-вычислений).

## 4. Аутентификация и защита данных

- **Сессии**: cookie `bizon_session` (sha256-токен, TTL 7 дней, таблица `Session`), httpOnly, secure в production (`src/lib/auth.ts`).
- **Demo-режим**: `BIZON_DEMO_AUTH=1` (только не-prod) — middleware подставляет демо-сессию «Иван Петров» при отсутствии cookie (`src/middleware.ts:86`). В production без переменной — обычный вход.
- **2FA**: TOTP (otplib) + backup-коды (CSPRNG); логин при включённой 2FA возвращает `{twoFactorRequired, tempToken}` (TTL 5 мин) без сессии; `api/auth/2fa/enable|disable` требуют пароль + rate-limit 5/мин.
- **Email-верификация**: `VerificationToken` (sha256-хэш, TTL 24ч, одноразовый), письмо через SMTP (dev — DEV EMAIL STUB); пополнение люменов без подтверждённого email → 403.
- **ToS**: обязательный акцепт при регистрации (`acceptedTosAt`) + баннер; оферта `/legal`.
- **PII-шифрование**: AES-256-GCM (`src/lib/security/crypto.ts`, ключ `BIZON_ENCRYPTION_KEY`; в production без ключа сервер не стартует — `src/instrumentation.ts`). FIX-2026-09-15: в dev без env-ключа используется **стабильный** keyfile `.bizon-encryption-key` в корне (0600, вне git/архивов) — переживает рестарты контейнера (платформа стирает `.env`; прежний per-process fallback ломал emailHash/emailEncrypted). Data-vault: `src/lib/data-vault/` (user/post/reputation/auth-vault + audit-log). Plaintext-колонки `email/bio/location/phone` — nullable и всегда NULL; поиск по `emailHash` (HMAC-SHA256).
- **Проекции**: 401 анониму; не-владельцу — Lite-проекция без PII; full — владелец и accepted-связи.
- **Admin**: `src/lib/admin-guard.ts` (`requireAdmin`, строгое `roles='admin'`) в 16+ роутах; ops-токены: `METRICS_TOKEN`, `DATA_PLANE_TOKEN`, `CAUSALITY_ADMIN_TOKEN`, `BIZON_CRON_SECRET`.
- **Rate-limit**: in-memory (`src/lib/security/rate-limiter.ts`, TRUST_PROXY для X-Real-IP/XFF) + LoginBackoff экспоненциальный (1с→2с→…кап 15 мин) на IP+email-hash.
- **Заголовки**: X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy (`next.config.ts headers()`). TLS 443 + HSTS + строгий CSP — на реверс-прокси Caddy при prod.
- **Anti-fraud/SSRF/anomaly**: `src/lib/security/anti-fraud.ts` (в употреблении), `ssrf.ts` (проверка resolved IP, без pin — отложено), `anomaly-detector.ts` (мёртвый код — отложено).

## 5. AI-инфраструктура (кратко; детали — 06-документ)

Единый шлюз `src/lib/ai-core/` (AIGateway + ленивый singleton `zai-client.ts`), честный fallback `provider='heuristic'`, списание люменов за AI-действия (career_agent=1, cv=2) с идемпотентным refund 100% при сбое. Часть legacy-файлов инстанцирует SDK inline (известный долг).

## 6. Инфраструктура и окружение

- **Caddy** (`Caddyfile`): один внешний порт; для внутренних сервисов — `?XTransformPort=ПОРТ` (WebSocket/минисервисы — задел, WS сейчас не используется).
- **Dev**: `bash .zscripts/dev.sh` (перезаписывает `.zscripts/dev.pid`), лог `dev.log`.
- **deploy/**: заготовки на прод — `Dockerfile`, `docker-compose.yml`, `init-postgres.sh`, Helm-чарт (PostgreSQL; текущая схема — SQLite).
- **PWA**: `public/manifest.json`, `public/sw.js`, хук `src/hooks/use-pwa.ts` — **хуки нигде не подключены** (фактически отключено, см. 05 §4.2).
- **Аналитика (prod)**: Yandex Metrica + GA4 подключаются при наличии `NEXT_PUBLIC_*` в `src/app/layout.tsx`.

### Переменные окружения (полный список, извлечён из кода)

| Переменная | Где | Назначение |
|---|---|---|
| `DATABASE_URL` | prisma/schema.prisma | SQLite путь (`file:./db/custom.db`) |
| `BIZON_DEMO_AUTH` | middleware.ts:86 | `1` = demo-автологин (только не-prod) |
| `BIZON_ENCRYPTION_KEY` | instrumentation.ts, security/crypto.ts | Ключ AES-256-GCM для PII (prod: обязателен) |
| `LUMEN_DIVIDENDS_ENABLED` | lumen-service.ts | `0` = kill-switch дивидендов |
| `METRICS_TOKEN` | api/metrics, api/admin/metrics, admin/causality | Ops-токен метрик |
| `DATA_PLANE_TOKEN` | api/admin/data-plane | Ops-токен data-plane |
| `CAUSALITY_ADMIN_TOKEN` | api/admin/causality | Ops-токен (fallback METRICS_TOKEN) |
| `BIZON_CRON_SECRET` | api/cron/insights | Секрет cron-вызовов (x-cron-secret) |
| `TRUST_PROXY` | security/rate-limiter.ts | `1/true` = доверять X-Real-IP/XFF |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM` | services/email-service.ts | Отправка писем (verify-email, уведомления) |
| `NEXT_PUBLIC_APP_URL` | referral, verification-token, email-service | Публичный URL приложения |
| `NEXT_PUBLIC_YM_ID` / `NEXT_PUBLIC_GA_ID` | layout.tsx, analytics.ts | Прод-аналитика |
| `LOG_LEVEL` | lib/logger.ts | pino-уровень (default info) |

Образец: `.env.example` в корне архива. Реальный `.env` в архив **не включён** (секреты).

## 7. Технический долг (сводная таблица)

| Долг | Детали | Статус |
|---|---|---|
| SPA-монолит | один route `/`, 25+ view в клиентском переключателе; разделение — отдельная волна | осознанно |
| God-файлы | `ai.ts` (1255 строк), `causality-engine-service.ts` (1773), `opportunity-service.ts` (1328), `PublicPersona` (1211, мёртвый) | отложено (нужны тесты) |
| withRoute 21/249 | остальные роуты — legacy try/catch | «при касании» |
| 0 автотестов | Vitest не внедрён; страхуют CAS+идемпотентность в деньгах | обязательно до prod-платежей |
| In-memory лимитеры/кэш | один воркер; Redis при деплое | pre-prod |
| 7+ inline `getZai` | SDK мимо AIGateway (15 файлов с упоминанием SDK, 2 — клиентские компоненты, проверить при аудите) | рефактор |
| anomaly-detector / SSRF pin | мёртвый код / нет pin на сокет | бэклог |
| decrypt-fallback | `api-helpers.ts:146` — потеря поля при ошибке расшифровки | бэклог (P2) |
| PWA не подключена | use-pwa не вызывается | бэклог |
| Мёртвый код | PublicPersona, TruthDashboardTab, SearchJobCardV2, CompareVacancies, BIZON WORK-табы, tailwind.config.ts | уборка |
| Хардкод-цвета | #1e3a8a ×48, emerald-600 ×13 | косметика |
| 11 «висячих» ссылок без FK | ProfessionalEvidence.skillId и др. — целостность на коде | 03-документ §2 |
| auth.ts не фильтрует `deletedAt` | soft-delete User не виден auth-пути | 03-документ §6.10 |
| String-enum рассинхроны | ProfessionalIntent.type (10 в схеме vs 7 в сервисе), Notification.type (6 vs 7) | 03-документ §2 |
| WebSocket | нет realtime (уведомления — SSE `api/notifications/stream`) | бэклог |

### W1-дополнение (14.09.2026): режим деплоя и флаги безопасности

- **instances=1 — обязательное ограничение запуска.** Rate-limiter, AI-cache и event-bus — in-process (in-memory). До перехода на Redis/централизованный KV приложение запускается ТОЛЬКО в один воркер (`instances=1`); горизонтальное масштабирование с текущим стеком приведёт к расхождению лимитов и потере событий. Это осознанное ограничение релиза, а не недоделка.
- **`BIZON_EXTERNAL_FETCH_ENABLED`** (default off) — внешние server-side fetch (`safeFetch`) выключены до единого egress-контура (DNS-pinning). `isUrlSafeForStorage` работает всегда (чистый DNS-check).
- **`AI_CACHE_ENABLED` / `AI_CACHE_SCHEMA_VERSION`** — кэш AI-результатов гейтва: off-флаг и версия политики в ключе (bump при смене формул/промптов). Кэшируются только реальные LLM-результаты (не heuristic-fallback).
- **CSP frame-ancestors (FIX-2026-09-15)** — iframe-allowlist песочницы (`*.space-z.ai`, `*.z.ai`) включён в dev-политику прямо в `next.config.ts` (переменная `BIZON_SANDBOX_PREVIEW` удалена: `.env` пересоздаётся загрузчиком контейнера при каждом старте, полагаться на неё нельзя). В production CSP frame-ancestors = 'self' + X-Frame-Options: SAMEORIGIN (DEF-29 не тронут).
