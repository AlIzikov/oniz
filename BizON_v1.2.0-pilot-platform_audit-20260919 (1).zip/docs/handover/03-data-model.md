# Модель данных BizON (Prisma / SQLite)

> Назначение: исчерпывающее описание модели данных BizON для внешнего AI-аудита.
> Источник истины: `prisma/schema.prisma` (1910 строк, генератор `prisma-client-js`, datasource `sqlite`, БД по env `DATABASE_URL`).
> Смежный документ: «Каталог API и сервисов BizON» — `docs/handover/04-api-catalog.md` (далее «04-каталог», ссылки вида «см. 04-каталог §2.x» / «§3.x»).
> Аудит подготовлен задачей H2-data (см. worklog.md).

**Важное замечание о числе моделей.** В задаче фигурировало «83 модели». Фактически в `schema.prisma` ровно **80** деклараций `model` (проверено автоматическим поиском `^model`). Чек-лист задачи содержит те же **80** позиций и покрыт настоящим документом на **100%**. Несоответствие «83» — ошибка исходной постановки, не схемы.

---

## 1. Конвенции схемы

### 1.1 PII-шифрование (Data Vault / 152-ФЗ / GDPR)

Центральная конвенция (комментарий в схеме «C1 этап 2»):

- **Поля `*Encrypted`** — персональные данные хранятся в виде AES-256-GCM-шифротекста (формат `base64(iv:ct:tag)`, IV 12 байт; ключ только в env `BIZON_ENCRYPTION_KEY` — см. 04-каталог §1.5).
- **`emailHash`** — HMAC-SHA256(email); уникальное поле для поиска пользователя **без раскрытия PII** (`User.emailHash @unique`). Регистрация/логин ищут пользователя только по хэшу (см. 04-каталог §1.1).
- **Plaintext-дубли PII — nullable и всегда NULL**: `User.email`, `User.bio`, `User.location`, `User.phone` и одноимённые поля `*Encrypted`. Комментарий схемы: «plaintext PII поля сделаны nullable. Значения очищены миграцией. Чтение PII — через decrypt(*Encrypted). Поля остаются в схеме для обратной совместимости кода, но всегда NULL».
- Расшифровка — `decryptOr(...)` с fallback на открытые поля при сбое ключа (04-каталог §1.2). Экспорт данных пользователя (`POST /api/me/export-data`, 40+ таблиц) применяет `decryptOr` к PII (см. 04-каталог §2.31).
- Аудит чтения/записи PII — `AuditLog` с действиями `read_pii` / `update_pii` / `delete` (см. 04-каталог §1.7).
- Классификация данных и согласия — на User: `citizenship`, `region`, `consentAiAnalysis`, `consentCrossBorder` (Sovereignty Gateway, 04-каталог §1.10): без `consentAiAnalysis` поля класса A (email/phone/name/bio/location/birthday/ip) не обрабатываются AI; без `consentCrossBorder` заблокирован внешний compute.
- GDPR/152-ФЗ удаление: `User.deletedAt` (soft-delete, физическое удаление через 30 дней cron-ом `cleanup-deleted` — каскад по `onDelete: Cascade`), плюс `POST /api/me/forget-me` — обфускация PII-полей без удаления аккаунта (см. 04-каталог §2.31).

Затронутые модели: **User** (email/bio/location/phone). Больше PII-полей с шифрованием в схеме нет — остальные «чувствительные» артефакты хэшируются (`Session.token` — opaque, `VerificationToken.tokenHash` — sha256, `User.twoFactorSecret` — AES-GCM-шифруется приложением до записи, `backupCodes` — хэши SHA-256 с солью).

### 1.2 Строковые enum-поля

Prisma `enum` для SQLite не используется ни разу — **все перечисления это `String` со значениями, зафиксированными в комментариях схемы и валидируемые zod на уровне API**. Значения каждого поля перечислены в каталоге моделей (раздел 2). Примеры канонических наборов:

- `User.level`: `basic | extended | expert` (пороги IP-score 0–30 / 31–70 / 71–100, см. 04-каталог §3.1);
- `User.accountType`: `individual | company | hr_agency`;
- `User.subscriptionTier`: `free | pro | business` (в `Subscription.tier` дополнительно `enterprise`);
- уровни доказательности (4 ступени Truth Engine): `claimed | verified | project_verified | expert_verified` — в `UserSkill.verificationLevel`, `ProfessionalEvidence.verificationLevel`, `CareerEntry.verificationLevel`;
- decay-статус навыка: `fresh | stale | decayed` — в `UserSkill.decayStatus`, `NFTSkill.decayStatus`.

### 1.3 «Списки — только через отдельные таблицы» + CSV/JSON-строки

Prisma/SQLite не поддерживает скалярные списки (комментарий в схеме: «ограничение SQLite на scalar lists», «payload JSON string (SQLite limitation)»). В схеме три приёма:

1. **Отдельные таблицы-связки** для настоящих списков с внешними ключами: UserSkill, SkillConfirmation, ProjectMember, CommunityMember, EventParticipant, PublicationAuthor, SavedPost/SavedJob/SavedAd и т.д. — это канонический способ.
2. **CSV-строки** для простых наборов токенов: `Post.tags`, `Project.tags`, `Project.requiredSkills`, `User.roles`, `User.hobbies` («Хобби пользователя (CSV)»). Парсинг в коде: `parseRequiredSkillsWithLevels` понимает формат «Skill:L» (L 1..10) — см. 04-каталог §3.32 (JobGrowthService).
3. **JSON-строки** (`String?` с комментарием JSON) для структурированных данных: `ReputationEvent.payload`, `Post.linkPreview`, `JobApplication.statusHistory`, `Claim.evidence`, `CompanyClaim.evidence`, `AiInsight.sourceData`, `CareerCompass.transferableSkills/suggestedDomains`, `Mentorship.menteeGrowth`, `SponsoredOpportunity.targeting`, `ProfessionalNarrative.sourceData`, `ResearchResult.answers/scores`, `SavedFilter.params`, `LumenTransaction.meta`, `Notification.metadata`, `ActionEvent.metadata`, `NewsCard.tags`, `Opportunity.requirements/skills`.

Единственное **настоящее поле типа `Json`** во всей схеме — `TrustIndex.factors` (SQLite хранит как TEXT/JSON-строку).

### 1.4 onDelete-каскады

Три фактических правила в схеме:

1. **`onDelete: Cascade` — доминирует.** Почти все дочерние записи каскадно удаляются вместе с владельцем-User (Session, VerificationToken, LumenTransaction, Saved*, Post/PostLike/PostComment, UserSkill, SkillConfirmation, Project/ProjectMember/ProjectConfirmation, Connection, Follow, ReputationEvent, JobApplication, AdImpression, Employee, CompanyFollower, CompanyReview, EventParticipant, Community/CommunityMember/CommunityPost, Conversation, Message, Notification, NFTSkill, DaoProposal/DaoVote, Referral (referrer), ProfessionalEvidence, ProfessionalCapital, ProfessionalNarrative, AiInsight, CoachQuestion, CoachInsight, IgnoredTopic, Claim/ClaimVerification, CareerEntry, ReputationSnapshot, ProfileView (оба конца), Resume, CareerCompass, ColleagueInquiry (все три конца), ActionEvent, CulturalSignal, CompanyClaim, Placement (hrAgency, company), HrContact (оба конца), NewsCard/NewsShare (все концы), Course/UserCourse, Publication/PublicationAuthor(publication), HrClient (оба конца), TrustIndex, SavedFilter, BirthdayPlan, ResearchResult). Это осознанная основа GDPR-удаления: `User.deletedAt` → cron → каскад физически стирает след (комментарий в схеме у `deletedAt`).
2. **`onDelete: SetNull` — для «осиротения», когда история важнее ссылки**: `Job.companyRel` и `Job.hiringManager` (вакансия переживает удаление компании/менеджера), `Event.organizer` / `Event.company`, `Placement.candidate` (анонимизация кандидата), `Referral.referred`.
3. **Отсутствие onDelete (= `Restrict`, поведение Prisma по умолчанию) — для «опорных» записей**: `User.company` (CompanyAccount), `PublicationAuthor.user`, `Recruiter.user`, `Recruiter.organization`, `ProfessionalIntent.user`, `Mentorship.mentor/.mentee`, `Subscription.user`, `SponsoredOpportunity.advertiser`, `AdPressure.user`. Удаление такой записи блокируется, пока существуют ссылки.

Отдельный класс — **«висячие» ссылки без FK** (см. §1.6): удаление цели не контролируется БД вообще.

### 1.5 Индексы и уникальность — принципы

Полный список — в разделе 4. Принципы:

- **Составные `@@unique` — защита от дубликатов и естественный upsert-ключ** почти для всех связок «пользователь × объект»: SavedPost/SavedJob/SavedAd `[userId, objId]`, PostLike `[postId, userId]`, UserSkill `[userId, skillId]`, SkillConfirmation `[userSkillId, confirmerId, projectId]`, ProjectMember/ProjectConfirmation, Connection `[fromUserId, toUserId]`, Follow, EventParticipant, CommunityMember, Employee, CompanyFollower, DaoVote, ClaimVerification, UserCourse, NewsShare `[cardId, fromUserId, toUserId]`, IgnoredTopic `[userId, topic]`, ResearchResult `[userId, testKey]`, UserCourse.
- **Квант-уникальности**: `HrContact [hrAgencyId, candidateId, weekKey]` (лимит 1 контакт/неделю, weekKey = ISO-неделя «2026-W36»), `AdPressure [userId, date]` (дневной счётчик), `LumenTransaction.refundOf @unique` (не более одного идемпотентного возврата на списание).
- **Индексы под конкретные запросы** (FIX-06 в комментариях): `Post [authorId, createdAt]` (лента автора), `JobApplication [userId, createdAt]` («мои отклики»), `Ad [active, moderationScore]` (выборка чистых объявлений), `AuditLog [ip]` (anti-fraud анализ общих IP).
- **@unique на «секретах»**: `User.emailHash`, `User.passportToken`, `Company.passportToken`, `Session.token`, `VerificationToken.tokenHash`, `Skill.name`, `Community.slug`, `NewsCard.url`, `Recruiter.userId`, `Referral.code`, `Referral.referredId`, `ProfessionalCapital.userId`, `TrustIndex.userId`.

### 1.6 «Висячие» ссылки без внешнего ключа (денормализация по осознанному решению)

Поля, которые по смыслу ссылаются на другие модели, но **не имеют `@relation`** (удаление цели не каскадируется, целостность — на коде):

| Поле | Ссылается на | Комментарий схемы |
|---|---|---|
| `ProfessionalEvidence.skillId` | Skill | «к какому навыку относится (без FK для гибкости)» |
| `Claim.projectId`, `Claim.skillId` | Project, Skill | «связь с Project (если есть)» — полиморфный evidence |
| `SkillSynonym.skillId` | Skill | синоним канонического навыка |
| `Project.companyId` | Company | поле добавлено при merge, relation нет |
| `Resume.jobId` | Job | «если под конкретную вакансию» |
| `Publication.projectId` | Project | привязка публикации к проекту |
| `NFTSkill.userSkillId` | UserSkill | «связь с UserSkill» — только `@@index` |
| `CompanyClaim.verifiedBy` | User | userId admin/moderator |
| `AuditLog.actorId` | User | «userId или system» — полиморфный |
| `Opportunity.companyId/jobId/projectId/eventId/mentorId` | Company/Job/Project/Event/User | полиморфная ссылка, «только один заполнен» |
| `JobApplication` → Job | Job | FK есть; но `rejectReason` — строка-enum + свободный текст |

### 1.7 Прочие конвенции

- **ID**: `String @id @default(cuid())` везде; whitelist `bizonId` = `^[a-zA-Z0-9_-]{1,64}$` на входе API (04-каталог §1.4).
- **Время**: `createdAt DateTime @default(now())`, `updatedAt DateTime @updatedAt`; SQLite хранит DateTime как текст — сортировки лексикографически корректны.
- **Денормализованные счётчики** — поддерживаются кодом (инкремент/декремент в той же транзакции, где меняется связка): `Post.likesCount/commentsCount`, `CommunityPost.likesCount/commentsCount`, `Community.membersCount/postsCount`, `UserSkill.confirmationsCount`, `DaoProposal.forVotes/againstVotes/abstainVotes`, `SponsoredOpportunity.impressions/clicks/spent`.
- **«Хвост» merge v5/v6**: в ряде моделей (User, Company, Project, ProjectMember, JobApplication, Claim, ClaimVerification, CareerEntry, ReputationSnapshot, AiInsight, NFTSkill, Notification) дополнительные поля физически дописаны **после** блока relations — артефакт слияния баз; семантически это обычные поля модели.
- **Честные стабы в данных**: `UserCourse.certificateNftId` (локальный ID вместо смарт-контракта), `Job.boosted/boostedUntil` (заглушка платного продвижения), `AiInsight.provider` / `ResearchResult.provider` = `llm | heuristic` (честная маркировка источника ответа).

---

## 2. Каталог моделей по доменам (89 моделей (v1.1.0: +ProjectConfirmation, +Recommendation, +9 Ai*-governance, +ResearchResult))

Формат каждой записи: **(а)** назначение; **(б)** ключевые поля и строковые enum-значения; **(в)** связи и onDelete; **(г)** кто пишет/читает (по 04-каталогу); **(д)** продуктовая роль.

### 2.1 Идентичность и доступ

#### User
- **(а)** Центральная сущность: профессионал, аккаунт компании или HR-агентства. Самая «толстая» модель — в неё слиты поля фаз MVP, v5, v6, Wave 11/14/15, Phase 2/3.
- **(б)** Ключевые поля: `id`, `emailHash @unique` (HMAC-SHA256), `emailEncrypted/bioEncrypted/locationEncrypted/phoneEncrypted` (AES-256-GCM; plaintext-пары `email/bio/location/phone` nullable и всегда NULL), `passwordHash` (PBKDF2 600k), `name`, `title`, `avatarUrl`, `ipScore Int @default(0)`, `level` (`basic|extended|expert`), `roles` (CSV, дефолт `""`; наличие `admin` даёт админ-права — 04-каталог §1.9), `accountType` (`individual|company|hr_agency`), `subscriptionTier` (`free|pro|business`), `subscriptionUntil`, `birthday`, `isVerified/verifiedAt` (для company/hr_agency), `citizenship/region`, `consentAiAnalysis/consentCrossBorder`, `twoFactorSecret/twoFactorEnabled/backupCodes`, `hobbies` (CSV), `crossDomainOptIn`, `showHobbiesToHr`, `hrInvisible` (Privacy Shield), `notificationSettings` (JSON-строка частот instant|daily|off), `dndEnabled`, `onboardingStep Int` (0–5), `deletedAt` (soft-delete GDPR), `emailNotificationsEnabled`, `lastReengagementEmailAt`, `passportToken @unique/passportEnabled/passportUpdatedAt` (публичный Professional Passport), `bizonMomentOptIn`, `professionalStatus`, `preferences` (JSON-строка), `companyPublic`, `lastVisitAt/lastSeenAt` (online-статус: <5 мин), `newsSources` (JSON — источники новостей), люмен-кошелёк: `lumenBalance/lumenRubles/lumenFraction/lumenAccruedAt` (1 ₽ = 1 люмен; дивиденды 15% годовых), `emailVerified`, `acceptedTosAt`.
- **(в)** Ссылается: `company → Company` (`CompanyAccount`, onDelete по умолчанию = Restrict). На User ссылается практически вся схема (~60 back-relations в модели: skills, projects, connections, posts, jobs, companies, communities, messages, notifications, NFT, DAO, saved*, claims, career, coach, lumens и т.д.).
- **(г)** Пишут: регистрация/логин/2FA (см. 04-каталог §2.1), onboarding (§2.2), PATCH /api/users/[id] — whitelist полей, PII шифруется (§2.3), согласия Sovereignty (§2.31 me/sovereignty-update), delete-account/forget-me/accept-tos/preferences (§2.31), passport enable (§2.31), подписки (§2.23), люмены (§2.23), admin-верификации. Читают: фактически все API — публичные проекции `toUserPublic/toUserPublicLite` (§1.2), поиск (§2.3, §2.18), формулы репутации/капитала/доверия (§3.1, §3.8, §3.9).
- **(д)** Ядро_identity: аутентификация, PII-хранилище, агрегат репутации (`ipScore` — денормализованный кэш пересчёта), тарифная модель, согласия.

#### Session
- **(а)** Opaque token-сессии (без JWT): одна строка на активную сессию.
- **(б)** `token @unique` (opaque, cookie `bizon_session`), `expiresAt` (TTL 7 дней), `createdAt`.
- **(в)** `user → User` (Cascade).
- **(г)** Пишут: login, 2FA verify, logout (удаление), delete-account (стирает все сессии) — см. 04-каталог §2.1, §2.31. Читает: `getUserFromRequest` на каждом авторизованном запросе (§1.1); истёкшая сессия удаляется на лету. `last Session` используется как прокси визита в what's-new (§2.31).
- **(д)** Аутентификация; единственный источник «кто сейчас вошёл».

#### VerificationToken
- **(а)** Одноразовые токены подтверждения email (FIX-08).
- **(б)** `tokenHash @unique` — **sha256-хэш; сырой токен существует только в ссылке письма**, `purpose` (`email_verify`, дефолт; поле расширяемо под другие типы), `expiresAt` (24ч).
- **(в)** `user → User` (Cascade).
- **(г)** Пишет: register (§2.1); потребляет и гасит: verify-email (§2.1); сервис `src/lib/services/verification-token.ts` (§3.32).
- **(д)** Подтверждение владения email; обязательное условие для реальных платежей (пополнение люменов без `emailVerified` → 403, §2.23).

#### AuditLog
- **(а)** Неизменяемый журнал аудита действий (152-ФЗ ст.19; хранение следа — 2 года по ТЗ).
- **(б)** `actorId` (userId **или** `'system'` — полиморфно, без FK), `action` (login, register, read_pii, update_pii, delete, admin_action, ANOMALY_DETECTED…), `resource`, `resourceId`, `ip`, `metadata` (JSON).
- **(в)** Ссылок нет (сознательно: лог переживает удаление пользователей).
- **(г)** Пишут: buffered writer (flush 5с / ≥100 записей) — 04-каталог §1.7; десятки роутов: auth (§2.1), PATCH users (update_pii, §2.3), claims verify (§2.12), career-entries (§2.14), passport enable (§2.31), delete-account/forget-me/export-data (§2.31), projects/confirm (§2.11), anomaly-detector (§1.5). Читают: аномали-детектор (NEW_LOCATION — новый IP за 30 дней, §1.5), анти-фрод (`[ip]`-индекс).
- **(д)** Юридический след + сырьё для fraud/аномали-детекторов.

### 2.2 Профессиональное доверие и репутация

#### Skill
- **(а)** Каталог канонических навыков.
- **(б)** `name @unique`, `category String?`.
- **(в)** На UserSkill ссылается (1:N). FK на Skill извне — только через связки; прямых ссылок-строк без FK, кроме упомянутых в §1.6.
- **(г)** Пишет: POST /api/skills — upsert по имени (§2.12); сид каталога. Читают: профили (§2.3), матчинг вакансий (§2.9), build-talent/semantic search (§2.20, §2.18, §3.29), skill-graph (§3.7).
- **(д)** Словарь навыков — фундамент всех формул «навыки × уровень».

#### UserSkill
- **(а)** Навык конкретного пользователя: уровень, доказательность, decay.
- **(б)** `level Int @default(1)` (1..5, legacy-самооценка), `confirmationsCount`, `nftEligible` (3+ подтверждений → NFT, Фаза 2), `verificationLevel` (`claimed|verified|project_verified|expert_verified`), `selfAssessment Int?` (1-100), `verifiedScore Int?` (1-100, вычисляется), `decayed Boolean`, `peakLevel Int?` (1..10, монотонно не убывает), `currentLevel Int?` (1..10, пересчитывается при изменении evidence), `confidence Float` (0..1), `lastUsedAt`, `decayStatus` (`fresh|stale|decayed`, §D.7), `formulaVersion Int @default(1)` (версия формулы для аудита).
- **(в)** `user → User` (Cascade), `skill → Skill` (Cascade); на SkillConfirmation и NFTSkill ссылается.
- **(г)** Пишут: POST /api/skills (§2.12), skills/confirm (+confirmationsCount, §2.12), claims/[id]/verify (апгрейд verificationLevel, §2.12), skills/[id]/self-assessment (§2.12), skill-graph-service persist (peakLevel/currentLevel — §3.7). Читают: профиль (§2.3), persona (§2.3), подбор менторов (§3.13: gap = currentLevel<7, ментор = peakLevel≥8), job match (§3.3), workforce (§3.27), me/skills/* (§2.31).
- **(д)** «Доказательный» профиль навыка: хранит и самооценку, и подтверждённый уровень, и возраст компетенции (decay).

#### SkillConfirmation
- **(а)** Подтверждение чужого навыка — обязательная привязка к общему проекту (FR-4).
- **(б)** `userSkillId`, `confirmerId`, `projectId` (обязательный общий проект), `comment`.
- **(в)** `userSkill → UserSkill` (Cascade), `confirmer → User` (Cascade), `project → Project` (Cascade).
- **(г)** Пишет: POST /api/skills/confirm — проверка связи (accepted-connection ИЛИ со-участие в проекте), анти-фрод canConfirm + runScoreSuspicionAsync (§2.12). Читают: skills/[id]/confirmations, evidence (§2.12), persona (§2.3), компонент C формулы IP-score `log1p(confirmations)/log1p(20)` (§3.1), skill-graph (вес 0.7, §3.7), CONFIRM_BURST-детектор (§1.5).
- **(д)** Социальное доказательство навыков; главный драйвер репутации C-компоненты.

#### SkillSynonym
- **(а)** Синонимы/алиасы навыков для семантического поиска.
- **(б)** `skillId` (канонический Skill.id, **без FK**), `synonym` (lowercase; ~119 синонимов сидом).
- **(в)** Ссылок нет (см. §1.6); индексы `[synonym]`, `[skillId]`.
- **(г)** Читают: build-talent (§3.25), semantic search (§3.29), career-compass vacancy-count (§2.14). Пишут: только сид/админ — отдельного API-роута в 04-каталоге не зафиксировано.
- **(д)** Расширение словаря matching без изменения Skill.name.

#### Connection
- **(а)** Двусторонний «контакт» (заявка в связи) — основа Trust Graph.
- **(б)** `status` (`pending|accepted|declined`), `note?`.
- **(в)** `fromUser → User` (Cascade), `toUser → User` (Cascade); `@@unique([fromUserId, toUserId])`.
- **(г)** Пишут: POST/PATCH /api/connections (при accepted — ReputationEvent connection_accepted + recompute IP обоим, §2.4), apply-via-contact (§2.9). Читают: connections GET, common-contacts, trust-graph (§2.4), feed following (§3.5), matchmaker BFS (§3.2), рекомендации «люди» (§2.5), Network Influence в professional trust (§3.9), match-explain trust (`min(15, commonContacts×5)`, §3.3), capital networkCapital (§3.8).
- **(д)** Социальный капитал: вход в «5 рукопожатий», доверие, лента подписок.

#### Follow
- **(а)** Односторонние подписки на авторов ленты (A15). Отличие от Connection: не требует взаимности, не создаёт контакт.
- **(б)** `followerId`, `followingId`.
- **(в)** Cascade с обеих сторон; `@@unique([followerId, followingId])`.
- **(г)** Пишет: POST/DELETE /api/follows (§2.4). Читают: follows GET (§2.4), FeedService following (§3.5).
- **(д)** Лёгкая социальная связь для ленты.

#### ProfessionalEvidence
- **(а)** Доказательства профессионального опыта — ядро принципа «Не говори, кто ты — докажи это» (v6).
- **(б)** `type` (`publication|project|review|certification|outcome`), `source` (URL/название), `skillId?` (без FK), STAR-поля `role/responsibility/action/result`, `verificationLevel` (`claimed|verified|project_verified|expert_verified`), `confidence Float` (0..1 — «уверенность AI в подлинности»), `status` (`active|hidden|deleted`), `date`.
- **(в)** `user → User` (Cascade).
- **(г)** Пишет: POST /api/me/evidence (§2.31). Читают: me/evidence, me/evidence-graph (§2.31), professional-trust — факторы evidenceQuality/verification/outcome/recency/consistency (§3.9), CapitalService outcomeCapital (§3.8), BizonMomentService анализ профиля (§3.19).
- **(д)** Первичный материал для многомерного доверия и капитала.

#### Claim
- **(а)** GPT Truth Engine: заявленные утверждения пользователя («Управлял командой 50 человек»).
- **(б)** `type` (`skill|experience|achievement`), `content`, `status` (`pending|verified|rejected`), `evidenceUrl`, `title`, `description`, `projectId?/skillId?` (без FK), `evidence` (JSON: projects/recommendations/verifications).
- **(в)** `user → User` (Cascade); на ClaimVerification ссылается.
- **(г)** Пишут: POST /api/claims (участие в проекте проверяется по ProjectMember), PATCH/DELETE /api/claims/[id] (§2.12). Читают: claims GET, me/evidence-graph, me/reputation/evidence, skill-graph (вес claims 0.8/1.0, §3.7), professional trust (§3.9), proof-service (§1.11).
- **(д)** Машина «заявил → подтвердили»: сырьё для верификаций и Evidence Coverage.

#### ClaimVerification
- **(а)** Верификации утверждений коллегами.
- **(б)** `verdict` (`confirm|refute|neutral`), `comment`, `status` (`pending|confirmed|rejected`), `role` (`colleague|manager|client|expert`).
- **(в)** `claim → Claim` (Cascade), `verifier → User` (Cascade); `@@unique([claimId, verifierId])`.
- **(г)** Пишет: POST /api/claims/[id]/verify — анти-фрод, при пороге подтверждений апгрейдит claim.status и UserSkill.verificationLevel (§2.12). Читает: claims/[id], skill-graph, CONFIRM_BURST-детектор (§1.5).
- **(д)** Голосование профессионального окружения по заявленным утверждениям.

#### ProfessionalCapital
- **(а)** 8 компонентов капитала профессионала (v6), пересчёт CapitalService.
- **(б)** `userId @unique` (1:1), компоненты 0..100: `verifiedExpertise, projectCapital, outcomeCapital, trustCapital, networkCapital, leadershipCapital, marketRelevance, learningVelocity`, `total` (взвешенная сумма, веса 0.20/0.15/0.15/0.15/0.10/0.10/0.10/0.05), `recomputedAt`.
- **(в)** `user → User` (Cascade); индекс `[total]` (глобальные рейтинги).
- **(г)** Пишет: POST /api/me/capital/recompute + подписчик event-bus `skill.verified` (§1.6, §2.31). Читают: GET /api/me/capital, me/career-outcome (§2.31). **Тренд — СТАБ**: снапшотов капитала нет, всегда stable/0 (§5 п.8 04-каталога).
- **(д)** Сводный числовой профиль «сколько стоит профессионал».

#### ProfessionalNarrative
- **(а)** Нарратив карьеры (Public Persona), сгенерированный из фактов; версионный.
- **(б)** `narrative` (текст), `version Int @default(1)`, `sourceData` (JSON — на каких данных построен).
- **(в)** `user → User` (Cascade); индекс `[userId, version]`.
- **(г)** Пишет/читает: MemoryService (me/memory — эволюция нарратива, §2.31, §3.32).
- **(д)** Человекочитаемая биография, объяснимая данными.

#### ReputationEvent
- **(а)** Журнал репутационных событий (Trust Stream) с весами.
- **(б)** `eventType` (комментарий схемы: `project_completed | skill_confirmed | positive_review | intro_sent | ad_clicked | connection_accepted`), `payload` (JSON string), `weight Int @default(1)` (project_completed=5), `impactScore Float` — `TrustWeight × Engagement × Relevance` (§3.1).
- **(в)** `user → User` (Cascade); индексы `[userId, createdAt]`, `[impactScore]`.
- **(г)** Пишут: connections PATCH, skills/confirm, projects/confirm|transition, auth/register (referral weight 5), ai/matchmaker (intro_sent) (§2.4, §2.12, §2.11, §2.1, §2.30). Читают: recomputeIpScore (компонент D — события за 7 дней, §3.1), лента reputation-подсекция (§3.5), what's-new deltaTrust (§2.31).
- **(д)** Событийная лента доверия — и «кирпич», и история IP-score.

#### ReputationSnapshot
- **(а)** Снапшоты динамики IP-score (v5).
- **(б)** `ipScore`, `level`, `takenAt`, + разложение: `projectsScore, ratingsScore, skillsScore, activityScore`, `evidenceCoverage Float` (0-1 — A4, процент подтверждённых утверждений).
- **(в)** `user → User` (Cascade); индекс `[userId, takenAt]`.
- **(г)** Пишет: POST /api/reputation/snapshots (админ/крон — внутри берутся claims, §2.13). Читают: GET snapshots (trend), me/trust-explain (delta30days + trend, §2.31), me/trust-state (§3.32), weekly digest нотификатора (§3.12).
- **(д)** Временные ряды доверия: тренды вместо одной цифры.

#### TrustIndex
- **(а)** Многомерный индекс доверия v6.0 (Professional Trust Service).
- **(б)** `userId @unique` (1:1 — один актуальный индекс; история в снапшотах), `score Float`, `dimension` (`overall | expertise | reliability | network | …` — комментарий схемы), `factors Json` — **единственное поле типа Json в схеме** (карта вкладов факторов), `computedAt`.
- **(в)** `user → User` (Cascade); индекс `[dimension]`.
- **(г)** Пишет: GET/POST /api/me/professional-trust (пересчёт при >24ч / форс, §2.31, §3.9). Читают: me/professional-trust, me/home-metrics, team-builder (§3.25).
- **(д)** Кэш «объяснимого доверия» с разложением по факторам.

#### NFTSkill
- **(а)** NFT-навыки (ERC-1155 на Polygon) — Фаза 2; **блокчейн — СТАБ** (минт пишет локальный статус).
- **(б)** `userSkillId` (без FK — см. §1.6), `tokenId?/contractAddress?` (on-chain), `skillName`, `level`, `endorsementsCount`, `mintedAt`, `status` (`pending`, минт → minted), `metadataUri?`, `weight Float` (вес подтверждения по Trust Graph), `lastConfirmedAt`, `decayStatus` (`fresh|stale|decayed`), `confirmerId?` (confirmer с лучшим weight — для лимита N4: не более 3 NFT от одного confirmer к target).
- **(в)** `user → User` (Cascade); индексы `[userId, status]`, `[userSkillId]`.
- **(г)** Пишут: POST /api/nft-skills (canMintNftSkill: N1 ≥1 подтверждение, N2 weight>0, N6 confirmer.ipScore>10, N4 лимит 3), POST /[id]/mint (СТАБ), stale-check (decay) (§2.25, §3.24). Читают: nft-skills GET, weight (strong ≥0.7 / moderate 0.3–0.7 / weak <0.3 / remote 0), persona (§2.3).
- **(д)** Портативный сертификат навыка с весом доверия и жизненным циклом (decay).

#### ColleagueInquiry
- **(а)** «Спроси у коллег» (R9): личный запрос коллеге о третьем человеке; замена публичной кнопки «Готов поручиться».
- **(б)** `message`, `status` (`pending|answered|declined|expired`), `response`, `isAnonymous`, `expiresAt` (**задаётся в коде** — SQLite не умеет `@default(now() + 7 days)`, комментарий схемы).
- **(в)** Три FK на User: `fromUser` (Cascade), `toUser` (Cascade), `aboutUser` (Cascade); индексы по всем трём.
- **(г)** Пишут: POST /api/colleague-inquiries (требуются общие проекты toUser∩aboutUser), /[id]/respond, jobs/[id]/apply-via-contact (§2.21, §2.9). Читают: GET-списки (§2.21).
- **(д)** Приватная верификация через общих знакомых.

#### CoachQuestion
- **(а)** Bizon Coach — вопрос дня.
- **(б)** `question`, `category` (`career|skills|projects|goals`), `answer`, `answeredAt`, `followUp` (инсайт из ответа).
- **(в)** `user → User` (Cascade).
- **(г)** Пишет/читает: CoachService.ensureDailyQuestion, POST /api/me/coach/answer (§2.19, §3.17).
- **(д)** Ежедневный AI-контакт с пользователем; ответы — топливо для инсайтов.

#### CoachInsight
- **(а)** Bizon Coach — инсайты, включая скрытый потенциал.
- **(б)** `category` (`potential|blind_spot|opportunity`), `insightType` (`fear_of_public|hidden_talent|career_shift|potential|general`), `recommendationAction`, `status` (`new|confirmed|dismissed|done`), `confidence` (0.6–0.75 по типам, §3.17), `sourceData`, `confirmedAt`.
- **(в)** `user → User` (Cascade); индексы `[userId, status]`, `[userId, createdAt]`.
- **(г)** Пишут: discover (≤3 гипотез/запуск, ≤3/сутки, карантин 7 дней), PATCH insights/[id] (confirmed → IgnoredTopic(source=coach) + ProfessionalIntent+0.1), cron /api/cron/insights (§2.19, §2.28, §3.17). Читают: insights GET; токены гипотез (job_interest/career_shift) бустят ленту рекомендаций (§2.5).
- **(д)** Проактивный AI-коуч: гипотезы о пользователе с управляемым жизненным циклом.

#### IgnoredTopic
- **(а)** Темы/сущности, которые пользователь не хочет видеть (анти-эхо-камера).
- **(б)** `topic`, `source` (`coach|feed|search|jobs`), `itemType?` (`job|person|event|company|profession` — «Не моё» в вакансиях), `reason?` (`salary|location|company|profession|level_low|level_high|travel|schedule|industry|other`), `targetId?` (id сущности; null = скрыта тема целиком).
- **(в)** `user → User` (Cascade); `@@unique([userId, topic])`.
- **(г)** Пишут: POST /api/feed/recommendations/ignore (source=feed), подтверждение инсайта коуча (source=coach) (§2.5, §2.19). Читают: анти-эхо-камера ленты рекомендаций (feed|coach), GET /api/jobs (jobs|feed) (§2.5, §2.9).
- **(д)** Управление «не показывать»: explicit negative intent.

### 2.3 Контент и сообщества

#### Post
- **(а)** Пользовательские посты — лента Trust Stream (ТЗ 4.2.1).
- **(б)** `content` (markdown-подобный), `tags` (CSV), `type` (`regular | commercial | announcement`; comment: commercial — только Business-подписка), `ctaText/ctaUrl` (для commercial), `notifyByEmail` (кнопка «Продублировать письмом»), `imageUrl`, `linkPreview` (JSON auto-detected), `likesCount/commentsCount`, `moderationScore Float` (0..1, 1=чисто; AI-Ad-Moderator для commercial: <0.4 block, <0.7 review), `isHidden`.
- **(в)** `author → User` («PostAuthor», Cascade); на PostLike/PostComment/SavedPost ссылается; индексы `[createdAt]`, `[type, createdAt]`, `[authorId, createdAt]`.
- **(г)** Пишет: POST /api/posts (лимит Free 5/день, SSRF-проверка imageUrl, EventBus post.published) (§2.6). Читают: GET /api/posts, /api/feed (impactScore поста = 0.5 + author.ipScore/200, §3.5), поиск (§2.18), счётчики (§2.28).
- **(д)** Основной контент ленты; commercial-посты — UGC-монетизация.

#### PostLike
- **(а)** Лайк поста.
- **(в)** `post` (Cascade), `user` (Cascade); `@@unique([postId, userId])`.
- **(г)** Пишет: POST /api/posts/[id]/like — toggle + likesCount±1 (§2.6).
- **(д)** Виральная механика; счётчик денормализован в Post.

#### PostComment
- **(а)** Комментарий к посту (лимит 500 в роуте).
- **(в)** `post` (Cascade), `author → User` («CommentAuthor», Cascade); индекс `[postId, createdAt]`.
- **(г)** Пишет: POST /api/posts/[id]/comment (+commentsCount, EventBus post.commented) (§2.6).
- **(д)** Обсуждение; сигнал активности.

#### SavedPost
- **(а)** Закладка поста («Избранное», правый rail).
- **(в)** `user` (Cascade), `post` (Cascade); `@@unique([userId, postId])`, индекс `[userId, createdAt]`.
- **(г)** Пишет: POST /api/posts/[id]/save toggle (§2.6). Читают: GET /api/posts/saved, подсекция feed saved (§3.5), счётчики (§2.28).
- **(д)** Личный архив ленты.

#### NewsCard
- **(а)** Карточка внешней новости (News Barter, XING-модель). BizON **не хранит полные тексты** — только метаданные og:.
- **(б)** `url @unique`, `title/description/imageUrl` (og:*), `aiSummary` (AI-резюме 50–100 симв., генерируется через z-ai-web-dev-sdk), `tags` (JSON array), `sourceDomain`, `publishedAt`, `category` (`news | ad | industry`), `advertiserId/advertiserName` (для ad, денормализовано), `erirToken` (**ФЗ-38 маркировка рекламы**), `recommendedBy`, `recommendedType` (`user | bizon | ad`), `status` (`pending | published | rejected`).
- **(в)** На NewsShare ссылается; индексы `[status, publishedAt]`, `[category, status]`.
- **(г)** Пишут: сервис сбора новостей (EventBus `news.fetched`), модерация POST /api/news/[id]/moderate (publish/reject/regenerate — regenerate перегенерирует aiSummary через AIGateway) (§2.16). Читают: GET /api/news, news/shared, news/[id]/relevance, «живой поток» компании (§2.8).
- **(д)** Внешний контент с AI-резюме и премодерацией; юридическая маркировка рекламы.

#### NewsShare
- **(а)** Адресная рекомендация NewsCard конкретному пользователю (Wave 15).
- **(б)** `message?` (≤500 симв.).
- **(в)** `card → NewsCard` (Cascade), `fromUser` (Cascade), `toUser` (Cascade); `@@unique([cardId, fromUserId, toUserId])` — защита от повторной отправки; индексы по from/to.
- **(г)** Пишет: POST /api/news/recommend (уведомление, имя в творительном падеже) (§2.16). Читает: GET /api/news/shared («поделились со мной», атрибуция «Рекомендовано {имя}»).
- **(д)** Органическое распространение контента p2p.

#### CulturalSignal
- **(а)** Company Persona (Этап 4.1): отзывы verified-сотрудников о культуре компании.
- **(б)** `rating` (1-5), `category` (`CULTURE | SALARY | GROWTH | MANAGEMENT | WORK_LIFE`), `text`, `isAnonymous`, `isVerified` (автор verified как сотрудник), `status` (`published | removed | pending`; **премодерация при rating ≤2**).
- **(в)** `company → Company` (Cascade), `author → User` (Cascade); индекс `[companyId, status]`.
- **(г)** Пишут: POST /api/companies/[id]/cultural-signals (только verified-сотрудники; пересчёт Company.culturalScore), moderate/delete админом (§2.8, §2.26). Читают: GET cultural-signals, Company Trust (сигналы ≥5 → 0.9 и т.д., §3.10), job-passport (companyFit), match-explain.
- **(д)** Внутренняя правда о компании; вход employerTrust.

#### Publication
- **(а)** Доложивущий контент: статьи, кейсы, исследования (Этап 7.3). Отличие от Post — нативные публикации или ссылки на Habr/Medium/blog, с соавторством.
- **(б)** `type` (`ARTICLE | CASE_STUDY | OPINION | RESEARCH | TUTORIAL | INTERVIEW`), `content`, `externalUrl?`, `readingTime?`, `projectId?` (без FK), `publishedAt`.
- **(в)** На PublicationAuthor ссылается; индексы `[publishedAt]`, `[type, publishedAt]`.
- **(г)** Пишет: POST /api/publications (≤50k, coAuthorIds ≤4); accept последнего со-автора → статус published (§2.15). Читают: GET /api/publications, skill-graph (публикации — вес 0.5 как evidence, §3.7).
- **(д)** Профессиональное портфолио длинной формы.

#### PublicationAuthor
- **(а)** Связка публикация↔автор с приглашением.
- **(б)** `role` (`author | co_author | contributor`), `acceptedAt` (**null = приглашён, но не принял**).
- **(в)** `publication` (Cascade), `user → User` (**без onDelete → Restrict**); `@@unique([publicationId, userId])`, индекс `[userId]`.
- **(г)** Пишет: создание публикации (инвайты + уведомления со-авторам), accept/reject (§2.15).
- **(д)** Ко-авторство до 5 человек (1 author + до 4 co_author — лимит в API, не в БД).

#### Community
- **(а)** Сообщество по профессиональным интересам.
- **(б)** `slug @unique`, `category` (`ml | frontend | backend | devops | product | design | career | other`), `minIpScore Int @default(0)` (0 = открытый), `membersCount/postsCount`, `visibility` (`public | private | secret`).
- **(в)** `owner → User` («CommunityOwner», Cascade); на members/posts ссылается; индексы `[category]`, `[visibility]`.
- **(г)** Пишут: создание через CommunityService, join/leave (membersCount±, EventBus community.joined) (§2.7). Читают: списки, карточка, подсекция feed community, поиск (§2.18).
- **(д)** Гейт-сообщества по IP-score — социальная монетизация репутации.

#### CommunityMember
- **(а)** Членство в сообществе.
- **(б)** `role` (`owner | moderator | member`), `joinedAt`.
- **(в)** Cascade с обеих сторон; `@@unique([communityId, userId])`, индекс `[userId]`.
- **(г)** Пишет: join/leave (§2.7). Читает: myMembership в списках (§2.7).
- **(д)** Разграничение модерации внутри сообществ.

#### CommunityPost
- **(а)** Пост внутри сообщества (отдельная сущность от глобального Post).
- **(б)** `tags` (CSV), `likesCount/commentsCount`, `isPinned`, `isHidden`.
- **(в)** `community` (Cascade), `author → User` (Cascade); индекс `[communityId, createdAt]`.
- **(г)** Пишет: POST /api/communities/[slug]/posts (≤5000) (§2.7).
- **(д)** Контент, привязанный к сообществу.

#### Event
- **(а)** Мероприятие (конференции/митапы и др.).
- **(б)** `format` (`online | offline | hybrid`), `category` (`conference | meetup | workshop | webinar | hackathon`), `startDate/endDate`, `location`, `organizerId?` (userId) и `companyId?` (если организатор — компания), `maxParticipants?` (null = без лимита), `trustScore Float @default(0.5)` (AI-оценка доверия для рекомендаций).
- **(в)** `organizer → User?` (SetNull), `company → Company?` (SetNull); индексы `[startDate]`, `[category, format]`.
- **(г)** Пишет: POST /api/events (§2.15). Читают: список upcoming, рекомендации событий (§2.5), me/discover (§2.31), companies stream (§2.8).
- **(д)** Офлайн/онлайн нетворкинг; организатор — пользователь или компания.

#### EventParticipant
- **(а)** RSVP участника.
- **(б)** `status` (`going | interested | not_going`).
- **(в)** Cascade; `@@unique([eventId, userId])`, индекс `[userId]`.
- **(г)** Пишет: POST /api/events/[id]/rsvp (EventService) (§2.15). Читает: attendees (§2.15).
- **(д)** Учёт посещаемости и лимитов.

#### Conversation
- **(а)** Диалог мессенджера между двумя пользователями.
- **(б)** `lastMessageAt` (денормализованный курсор сортировки).
- **(в)** `fromUser` (Cascade), `toUser` (Cascade); `@@unique([fromUserId, toUserId])` + индексы по from/to. **Замечание для аудита**: уникальность однонаправленна — схема не предотвращает два диалога A→B и B→A (защита на уровне кода upsert).
- **(г)** Пишут: POST /api/messages (только accepted-связь, upsert), posts/[id]/respond (отклик на commercial-пост), jobs/[id]/chat (§2.17, §2.6, §2.9). Читает: GET /api/messages (§2.17).
- **(д)** Инфраструктура личных коммуникаций (в т.ч. «отклик через чат»).

#### Message
- **(а)** Сообщение в диалоге (≤4000).
- **(б)** `isRead Boolean @default(false)` (read-статус на уровне схемы — флаг; каталог упоминает readAt-логику в роуте).
- **(в)** `conversation` (Cascade), `author → User` (Cascade); индекс `[conversationId, createdAt]`.
- **(г)** Пишет: POST /api/messages (30/мин) (§2.17). Читает: GET /api/messages/[conversationId] (участник-гейт).
- **(д)** Контент мессенджера.

#### Notification
- **(а)** Уведомления пользователя.
- **(б)** `type` (комментарий схемы: `connection_request | skill_confirmed | project_completed | post_liked | message | system`; сервисный банк NOTIFICATION_TYPES — 7 типов, FORBIDDEN_TYPES=['rating_drop'] — §3.12), `title`, `content?`, `link?`, `isRead`, `metadata?` (JSON).
- **(в)** `user → User` (Cascade); индекс `[userId, isRead, createdAt]`.
- **(г)** Пишет: NotificationService.notify() из десятков роутов и event-bus подписчиков (уважает частоты instant|daily|off и DND) (§3.12, §1.6). Читают: GET /api/notifications (+unreadCount), /read, SSE /stream (polling по createdAt) (§2.17).
- **(д)** Единый инбокс событийных уведомлений + еженедельный digest.

### 2.4 Вакансии и найм

#### Job
- **(а)** Вакансия.
- **(б)** `company String` (название-строка, legacy) + `companyId?` (связь с Company, «для новых вакансий»), `requiredSkills` (CSV, формат «Skill:L»), `salaryFrom/salaryTo`, `salaryMin/salaryMax/currency` (`RUB`), `growthScore Float` (0..1), `matchConfidence`, `active`, `verificationStatus` (`posted | verified | rejected`), `verifiedAt`, `vacancyTrust Float` (0..1 — индекс доверия к вакансии), `boosted/boostedUntil` (**СТАБ** платного продвижения), `exitState?` (Three States of Exit), `hiringManagerId?`, стратегический модуль v6.1: `level` (`Junior | Middle | Senior | Lead | Director`), `workFormat` (`remote | hybrid | onsite`), `industry`, `travelDaysPerMonth`, `teamSize`, `hiringStages` (этапов найма — Hiring Reality), `schedule`.
- **(в)** `companyRel → Company?` (SetNull), `hiringManager → User?` (SetNull); на JobApplication/SavedJob ссылается; индексы `[active, createdAt]`, `[companyId]`.
- **(г)** Пишут: POST /api/jobs (лимиты тарифа JOB_LIMITS: company/hr_agency free=1, pro/business=∞; individual=0), boost (СТАБ), verify (админ) (§2.9, §3.23). Читают: GET /api/jobs (738 строк, режимы quick|nl|precise|explore), match (§3.3), search semantic (§3.29), hiring-reality (§3.21), time-value (§3.22), job-passport, match-explain, related-jobs, рекомендации (§2.5), opportunities (§3.15).
- **(д)** Точка спроса на рынке труда; «паспортизируемая» и верифицируемая сущность.

#### JobApplication
- **(а)** Отклик кандидата на вакансию (career-outcome цикл).
- **(б)** `status` (комментарий схемы: `draft | preparing | submitted | viewed | reviewed | interview | offer | accepted | hired | rejected` + `withdrawn` из withdraw-роута), `matchConfidence Float` (0..1 AI match), `aiSummary?` (LLM), `rejectReason?` (`salary|location|level|experience|other` + свободный текст), `statusHistory?` (JSON: [{status, at}] — траектория для Professional Memory), `coverLetter?`, `applyPath` (`persona | chat | via_contact`), `hiringManagerResponse?`.
- **(в)** `job` (Cascade), `user` (Cascade); `@@unique([jobId, userId])`, индекс `[userId, createdAt]`.
- **(г)** Пишут: apply (считает matchConfidence), apply-via-contact, chat, withdraw, PATCH /api/applications/[id]/status (трекер с историей и идемпотентностью) (§2.9). Читают: applications GET, me/career-discovery, me/career-outcome (§2.31), hiring-reality (отклики как критерий), intent-service (фактор job_search).
- **(д)** Воронка найма и главный источник карьерной телеметрии.

#### SavedJob
- **(а)** Закладка вакансии.
- **(в)** Cascade; `@@unique([userId, jobId])`, индекс `[userId, createdAt]`.
- **(г)** Пишет: POST /api/jobs/[id]/save (§2.9). Читают: GET /api/jobs/saved (+совпадение навыков), intent-service (savedJobs ×0.05), счётчики.
- **(д)** Сигнал намерения (job_search) + избранное.

#### SavedFilter
- **(а)** Именованные фильтры-мониторы поиска (Wave 11); максимум 9 на пользователя (валидация в сервере).
- **(б)** `name` (≤60), `target` (`jobs | projects | news | people`), `params` (JSON-строка — дословно параметры GET /api/jobs: {q, location, minSalary, workFormat, level, industry, important, mode}), `monitoring Boolean` (участие в отслеживании новых совпадений; уведомления — следующие этапы), `lastRunAt?`.
- **(в)** `user → User` («SavedFilterOwner», Cascade); индекс `[userId, createdAt]`.
- **(г)** Пишет: GET/POST /api/saved-filters, PATCH/DELETE /[id] (§2.18).
- **(д)** Сохранённые поисковые сценарии; фундамент мониторинга.

#### Ad
- **(а)** Рекламное объявление платформы (классическая модель Trust-сегментированной рекламы).
- **(б)** `targetTrustSegment` (`all | basic | extended | expert`), `adTrustIndex Float` (0..1 — ATI), `moderationScore Float` (0..1, AI-Ad-Moderator, 1=clean), `active`.
- **(в)** На AdImpression/SavedAd ссылается; индекс `[active, moderationScore]` (выборка чистых активных).
- **(г)** Пишет: отдельного create-роута в 04-каталоге не зафиксировано (сид/админ). Читают: GET /api/ads (случайный active + AdImpression), подсекция feed ads (только moderationScore ≥0.7, §3.5), ads/saved (§2.24).
- **(д)** Показ рекламы, соответствующей уровню доверия сегмента.

#### AdImpression
- **(а)** Факт показа/клика объявления пользователю.
- **(б)** `clicked Boolean @default(false)`.
- **(в)** Cascade; индекс `[adId, userId]` (**без unique — повторные показы допустимы**).
- **(г)** Пишет: GET /api/ads (показ), POST /api/ads (клик — последнее impression → clicked=true) (§2.24). Читает: анти-фрод ad_clicked reputation event.
- **(д)** Телеметрия рекламы → ReputationEvent(ad_clicked, relevance 0.2).

#### SavedAd
- **(а)** Закладка объявления.
- **(в)** Cascade; `@@unique([userId, adId])`, индекс `[userId, createdAt]`.
- **(г)** Пишет: POST /api/ads/[id]/save (§2.24). Читает: GET /api/ads/saved.
- **(д)** Избранное рекламы.

#### SponsoredOpportunity
- **(а)** Спонсорская кампания компании (Phase 13 monetization), CPM-модель.
- **(б)** `type` (`job | course | event | service | product`), `budget` (₽, ≤10M по zod), `spent` (потрачено), `cpm` (цена за 1000 показов, дефолт 100, ≤10k), `status` (`pending | active | paused | completed | rejected`), `targeting` (JSON: {skills, industries, intentTypes, locations}), `impressions/clicks`.
- **(в)** `advertiser → Company` (**без onDelete → Restrict**); индекс `[status, createdAt]`.
- **(г)** Пишут: POST /api/sponsored, impression/click (списание по CPM, spent+) (§2.24). Читают: GET /api/sponsored, sponsored/feed (фильтр spent<budget, таргетинг по навыкам/интентам/локации, сортировка cpm desc + рандомизация, top-3).
- **(д)** Монетизация: показ спонсорских карточек в ленте с бюджетным контролем.

#### AdPressure
- **(а)** Дневной счётчик рекламной нагрузки пользователя (защита от переспама).
- **(б)** `adsShown/adsClicked/organicItemsShown`, `lastAdShownAt?` (cooldown 30 мин). Лимиты сервиса: MAX_ADS_PER_DAY=5, MIN_ORGANIC_BEFORE_AD=3, MIN_AD_INTERVAL_MIN=30; pressure low 0–1 / medium 2–3 / high 4–5+.
- **(в)** `user → User` (**без onDelete → Restrict**); `@@unique([userId, date])`.
- **(г)** Пишет/читает: AdPressureService.canShowAd / recordImpression / recordClick из sponsored/feed и impression/click-роутов (§2.24, §3.32).
- **(д)** Рекламная гигиена ленты.

#### Company
- **(а)** Компания (Company Hub) и аккаунт-работодатель.
- **(б)** `name/description/logoUrl/coverUrl/website`, `industry` («IT», «Finance», «E-commerce»), `size` («1-10», «11-50», «51-200», «201-1000», «1000+»), `location/foundedYear`, `adTrustIndex` (ATI, ТЗ 7.1), контакты `phone/address/email/hrEmail`, реквизиты `inn` (10-12 цифр) / `ogrn` (13-15), `isVerified/verifiedAt` (верификация — СТАБ: валидация длины вместо ЕГРЮЛ), `culturalScore?` (внутренний агрегат CulturalSignal, не публичный), **4 индекса доверия Phase 2 (0..100)**: `employerTrust` (из CulturalSignal), `businessTrust` (подтверждённые кейсы Project COMPLETED, log1p-нормализация), `deliveryTrust` (качество сдачи из Project.rating>0), `transparency` (verified + публичные зарплаты), `newsSources` (JSON), `passportToken @unique/passportEnabled` (Company Passport по /c/<token>, 64 hex энтропии).
- **(в)** На Employee/CompanyFollower/CompanyReview/Job/Event/CulturalSignal/Placement/CompanyClaim/SponsoredOpportunity и `accountUsers User[]` (CompanyAccount) ссылается; индекс `[industry]`.
- **(г)** Пишут: POST /api/companies (+Employee(owner)), verify (СТАБ), CompanyTrustService.recalculate (4 индекса), cultural-signals (culturalScore), me/company-passport enable/disable (§2.8, §2.31, §3.10). Читают: каталог компаний, карточка (сотрудники, вакансии, рейтинг, аналогичные по industry), trust (кэш 5 мин), job-passport, talent-forecast, workforce, opportunities.
- **(д)** Работодатель с многомерным профилем доверия; опора найма и монетизации.

#### Employee
- **(а)** Трудовая связь пользователь↔компания (verified-сотрудничество).
- **(б)** `position`, `isCurrent` (работает сейчас / бывший), `startDate/endDate`.
- **(в)** Cascade; `@@unique([companyId, userId])`.
- **(г)** Пишет: POST /api/companies (owner-сотрудник); наличие Employee — гейт на отзывы (403 без связи) (§2.8). Читают: карточка компании, cultural-signals (isVerified-авторы), company trust, workforce overview.
- **(д)** Право голоса о компании и верификация опыта в резюме.

#### CompanyFollower
- **(а)** Подписчик компании.
- **(в)** Cascade; `@@unique([companyId, userId])`.
- **(г)** Пишет: POST /api/companies/[id]/follow toggle (§2.8).
- **(д)** Аудитория компании.

#### CompanyReview
- **(а)** Отзыв о компании-работодателе.
- **(б)** `rating` (1-5), `title/pros/cons`, `verifiedEmployee Boolean` (подтверждение, что автор реально работал).
- **(в)** Cascade; индекс `[companyId, createdAt]`.
- **(г)** Пишет: POST /api/companies/[id]/reviews (требует Employee-связь) (§2.8). Читают: карточка компании (avg-рейтинг), Company Trust delivery-компонента (§3.10).
- **(д)** Публичная оценка работодателя.

#### CompanyClaim
- **(а)** Заявление компании о себе (P1) + цепочка верификации.
- **(б)** `type` (`project_count | employee_count | revenue | certification | partnership | award | technology`), `claimText` («140 проектов»), `claimValue`, `evidence` (JSON), `status` (`claimed | verified | disputed | rejected`), `verifiedAt`, `verifiedBy` (userId admin/moderator, **без FK**).
- **(в)** `company → Company` (Cascade); индекс `[companyId, status]`.
- **(г)** Пишут: POST claims (admin/владелец), /[claimId]/verify (admin → verified), /[claimId]/dispute (участник → disputed, снимает verified) (§2.8). Читают: claims GET, company intelligence, businessTrust (§3.10), truthScore = verified/total×100 (§3.32).
- **(д)** Проверяемые публичные обещания компании.

#### Placement
- **(а)** Placement Portfolio (Этап 4.2): фиксация HR-агентством факта трудоустройства кандидата.
- **(б)** `candidateName` (для анонимных — «Кандидат N»), `jobTitle`, `placedAt`, `confirmedByCandidate/confirmedByCompany` (закрытый placement = оба true), `isPublic`.
- **(в)** `hrAgency → User` («PlacementHrAgency», Cascade), `candidate → User?` (**SetNull** — анонимизация), `company → Company` (Cascade); индексы `[hrAgencyId]`, `[companyId]`, `[candidateId]`.
- **(г)** Пишет: POST /api/placements, /[id]/confirm (при обоих подтверждениях → пересчёт recruiterTrust) (§2.10, §3.11). Читают: hr-organizations/[id], pipeline, company intelligence, market intelligence (агрегаты 30 дней).
- **(д)** Доказательная база HR-репутации (Agency Trust).

#### HrOrganization
- **(а)** Кадровое агентство (Phase 2) с командой рекрутеров.
- **(б)** `name/inn?`, `isVerified/verifiedAt`, `specialization?`, `agencyTrust Float @default(0)` = среднее recruiterTrust активных рекрутеров.
- **(в)** На Recruiter/HrClient ссылается; индекс `[isVerified]`.
- **(г)** Пишет: POST /api/hr-organizations (создаёт рекрутер) (§2.10). Читают: GET/[id] (карточка + placements + trust), pipeline.
- **(д)** Организационная форма HR-бизнеса на платформе.

#### Recruiter
- **(а)** Рекрутер — 1:1 с User (userId @unique), членство в агентстве.
- **(б)** `recruiterTrust Float @default(0)` = log1p(closedPlacements)/log1p(20) (§3.11), `joinedAt`.
- **(в)** `user → User` (**без onDelete → Restrict**), `organization → HrOrganization` (**без onDelete → Restrict**); индекс `[organizationId]`.
- **(г)** Пишет: POST /api/hr-organizations/[id]/recruiters (role-check), пересчёт HrTrustService (§2.10, §3.11).
- **(д)** Индивидуальный доверительный рейтинг рекрутера.

#### HrClient
- **(а)** Корпоративный клиент HR-агентства (v6.0).
- **(б)** `tier` (тариф обслуживания), `seats` (оплаченные места), `validUntil?` (null = бессрочно).
- **(в)** `hrOrganization` (Cascade), `user` (Cascade) — представитель-контакт-лицо; индексы по обоим FK.
- **(г)** API-роуты в 04-каталоге не зафиксированы (модель описана в схеме v6.0); работа с сущностью на уровне сервисов не задокументирована.
- **(д)** B2B-отношения агентство↔корпорация; роль частично документирована.

#### HrContact
- **(а)** Privacy Shield (Этап 4.2): контролируемый контакт HR с кандидатом.
- **(б)** `initiatedBy` (`hr | candidate`), `message?`, `status` (`active | blocked | expired`; block → HR блокируется на 7 дней), `weekKey` (формат ISO-недели «2026-W36»).
- **(в)** `hrAgency → User` (Cascade), `candidate → User` (Cascade); `@@unique([hrAgencyId, candidateId, weekKey])` — **энфорс лимита 1 контакт/неделю на пару**; индексы `[candidateId, status]`, `[hrAgencyId, status]`.
- **(г)** Пишет: POST /api/hr-contacts (только accountType='hr_agency'; `hrInvisible` → 403), /[id]/block (§2.10). Читают: GET-списки, incoming кандидата; попадают в Professional Moments (§3.32).
- **(д)** Антиспам найма: квантированные, блокируемые контакты.

#### CareerEntry
- **(а)** Карьерные записи для таймлайна (v5).
- **(б)** `title`, `company?`, `startDate/endDate?`, `isCurrent`, `position`, `description?`, `location?`, `verificationLevel` (`claimed | verified | project_verified | expert_verified`).
- **(в)** `user → User` (Cascade); индекс `[userId, isCurrent]`.
- **(г)** Пишет: GET/POST /api/career-entries, PATCH/DELETE /[id] (AuditLog) (§2.14). Читают: persona (§2.3), cv/generate (сбор контекста резюме, §2.14).
- **(д)** Хронология опыта; вход для «Professional Memory» и резюме.

### 2.5 Карьера, развитие и AI-данные

#### CareerCompass
- **(а)** Карьерный компас — cross-domain навигатор (Этап 5.3).
- **(б)** `currentRole/currentDomain`, `transferableSkills` (JSON array of strings), `suggestedDomains` (JSON array of {domain, reason, matchPercent}), `generatedAt`.
- **(в)** `user → User` (Cascade); индекс `[userId, generatedAt]`.
- **(г)** Пишет: POST /api/cv/compass (runCareerCompass — LLM через AIGateway) (§2.14). Читает: GET последнего (§2.14); вакансий-счётчик vacancy-count (§2.14) — вспомогательный.
- **(д)** «Куда мне перейти»: переносимые навыки и целевые домены.

#### Resume
- **(а)** AI-резюме (Этап 5.3).
- **(б)** `type` (`short | long | cover_letter`), `jobId?` (под конкретную вакансию, **без FK**), `content` (JSON-строка секций: header/skills/projects/experience/cover), `aiGenerated` (true — LLM; false — отредактировано вручную), `editedAt?`.
- **(в)** `user → User` (Cascade); индекс `[userId, createdAt]`.
- **(г)** Пишет: POST /api/cv/generate (LLM, **списывает 2 люмена** LumenService.spend 'cv_generate') (§2.14). Читают: apply-роут (проверяет принадлежность resume пользователю, §2.9).
- **(д)** Генеративные документы под вакансию; первая платная AI-операция.

#### Course
- **(а)** Каталог внешних курсов (Этап 5.5 EDU).
- **(б)** `provider` (`Coursera | Udemy | Skillbox | BizON Academy`), `providerId?` (внешний ID), `url`, `durationHours?`, `category` (`IT | Design | Business | etc`).
- **(в)** На UserCourse ссылается; индекс `[category]`.
- **(г)** Пишет: POST /api/edu/courses (admin) (§2.14). Читают: каталог, edu/recommendations (LLM + фолбэк по gap-навыкам), workforce (Training), opportunities (courses 0.6 константа trust).
- **(д)** Обучение как восполнение skill gap.

#### UserCourse
- **(а)** Запись пользователя на курс + прогресс.
- **(б)** `status` (`in_progress | completed`), `startedAt/completedAt`, `certificateNftId?` (**СТАБ**: локальный ID вместо NFT-сертификата).
- **(в)** Cascade; `@@unique([userId, courseId])`, индекс `[userId, status]`.
- **(г)** Пишет: POST /api/edu/enroll/[courseId] (дубль запрещён), /complete/[userCourseId] (100% прогресса) (§2.14). Читают: intent-service (learning ×0.15), workforce.
- **(д)** Обучающая траектория; источник intent learning.

#### Mentorship
- **(а)** Наставничество (Phase 11 Mentor Graph): ментор (peakLevel ≥8) → менти (currentLevel <7 в навыке).
- **(б)** `skillId?` (без FK), `status` (`active | completed | cancelled`), `mentorRating Int?` (1-5, от менти при завершении), `menteeGrowth?` (JSON {skillBefore, skillAfter, newProjects, newRole} — для calcMentorEffectiveness).
- **(в)** `mentor → User` («MentorshipMentor», **без onDelete → Restrict**), `mentee → User` (Restrict); индексы `[mentorId]`, `[menteeId]`, `[status]`.
- **(г)** Пишет: POST /api/mentorships (запрет дубля active по паре+skill), /[id]/complete (только менти) (§2.15, §3.13). Читают: /api/mentors (подбор по гэпам), /[id]/effectiveness, me/mentorships, workforce.
- **(д)** Передача экспертизы; эффективность ментора измерима.

#### ResearchResult
- **(а)** «Исследование» (Волна D): результаты тестов-опросников — контрольные данные для ИИ-профиля.
- **(б)** `testKey` (`profession | preferences | motivators`), `answers` (JSON [{qId, optionId}]), `scores` (JSON {scaleId: 0..100}), `summary` (человеческая интерпретация), `provider` (`llm | heuristic` — «честность: не выдаём правила за AI»).
- **(в)** `user → User` (Cascade); `@@unique([userId, testKey])` (один результат на тест).
- **(г)** Пишет: POST /api/research/tests/[key] (upsert; подсчёт детерминированный, интерпретация через AIGateway) (§2.27, §3.4). Читают: research/tests GET, research/insights, **ai-co-pilot (ResearchResult как контекст)**.
- **(д)** Психометрический фундамент AI-персонализации.

#### BirthdayPlan
- **(а)** Плановые уведомления о днях рождения (Wave 11).
- **(б)** `personUserId?` (контакт из платформы, если есть) / `personName` (обязательное — в т.ч. для людей вне платформы), `dateMonth` (1..12), `dateDay` (1..31), `channel` (`in_platform | sms | call | in_person | gift`; gift — «модуль в разработке»), `comment`, `remindBefore` (0 = в день ДР), `status` (`planned | done`).
- **(в)** `owner → User` («BirthdayPlanOwner», Cascade); индексы `[ownerId, dateMonth, dateDay]`, `[status]`.
- **(г)** Пишет: GET/POST /api/birthday-plans (лимит на пользователя), PATCH/DELETE /[id] (§2.21). **Планировщик напоминаний — СТАБ** (сохраняем и сообщаем, §5 п.10).
- **(д)** Социальный CRM-мини-модуль для поддержания связей.

#### AiInsight
- **(а)** Сохранённые инсайты BizonAICore (v6) + BIZON MOMENT (Phase 2).
- **(б)** `type` (`signal | moment | blind_spot | next_action | opportunity | scenario`), `title`, `content`, `reasoning?` (объяснимость «почему AI так решил»), `confidence` (0..1), `sourceData?` (JSON), `provider?` (`llm | heuristic`), `isSeen`; поля-дублёры из merge: `insight`, `evidence` (JSON), `isRead`.
- **(в)** `user → User` (Cascade); индекс `[userId, type, createdAt]`.
- **(г)** Пишет: BizonAICore.onEvent (13 событий EVENT_TO_INSIGHT через event-bus), me/ai-analyze, BizonMomentService (≤1/7 дней, opt-in гейт, 7 паттернов с весами уверенности) (§1.10, §2.30, §2.19, §3.19). Читают: GET /api/insights/bizon-moment, dismiss/opt-in (§2.19).
- **(д)** Проактивный AI-канал «платформа заметила…».

### 2.6 Проекты, DAO, монетизация, прочее

#### Project
- **(а)** Проект: командная работа, источник опыта и подтверждений навыков.
- **(б)** `title/description`, `status` (`recruiting | active | completed | cancelled`), `rating Float` (0..5), `tags` (CSV), `startedAt/completedAt`, `fundingType?` (`self | bootstrap | vc | grant | revenue`), `visibility` (`public | private`), `budget?/equityPercent?`, `outcome?` (измеримый результат), `exitState?` (**Three States of Exit: completed/graceful/conflict**), `requiredSkills` (CSV — для AI-мэтчинга), `lookingFor?`, `ndaRequired`, `progress Int`, `companyId?` (без FK).
- **(в)** `owner → User` («Owner», Cascade); на members/confirmations/completionConfirmations ссылается; индекс `[status]`.
- **(г)** Пишут: POST/PATCH /api/projects (авто-join), /confirm (кворум: ACTIVE→COMPLETED требует подтверждения каждого активного участника → ReputationEvent project_completed weight 5 всем), /transition (state-machine), /leave (§2.11). Читают: каталог, related-jobs, persona, capital (projectCapital — completed ×15), company businessTrust (log1p), matchmaker (со-участники как соседи графа), opportunities (0.5 + owner.ipScore/200).
- **(д)** Клетка профессиональной репутации: здесь рождаются подтверждения навыков и кейсы.

#### ProjectMember
- **(а)** Участие пользователя в проекте.
- **(б)** `role` (`owner | lead | member`), `exitState` (`active | completed | graceful | conflict` — принцип №3 Three States of Exit), `exitReason?`, `exitedAt?`.
- **(в)** Cascade; `@@unique([projectId, userId])`.
- **(г)** Пишет: создание проекта (owner), PATCH auto-join, leave (§2.11). Читают: карточка проекта, common-contacts, colleague-inquiries (общие проекты — гейт), matchmaker, capital (founder-роли ×20), me/history-people.
- **(д)** Состав команды + честная фиксация способа выхода.

#### ProjectConfirmation
- **(а)** Кворум подтверждения завершения проекта (A9): запись создаётся при запросе перехода ACTIVE→COMPLETED; `confirmedAt` ставится, когда участник подтвердил результат.
- **(в)** Cascade; `@@unique([projectId, userId])`, индекс `[projectId]`.
- **(г)** Пишет/читает: POST/GET /api/projects/[id]/confirm ($transaction: при полном кворуме → project.completed → ReputationEvent ×N → recomputeIpScoresBulk → уведомления → AuditLog) (§2.11).
- **(д)** Анти-фрод закрытия проектов: никто не подтверждает за участника.

#### DaoProposal
- **(а)** Предложение DAO-голосования (Фаза 2).
- **(б)** `type` (`governance | budget | feature | partnership`), `forVotes/againstVotes/abstainVotes`, `startDate/endDate`, `status` (`active | passed | rejected | executed`; авто-закрытие истёкших в GET /api/dao), `minIpScore Int @default(31)` (порог участия — нижняя граница уровня extended).
- **(в)** `proposer → User` (Cascade); на DaoVote ссылается; индекс `[status, endDate]`.
- **(г)** Пишет: POST /api/dao (5/час), auto-close в GET (§2.22).
- **(д)** Управление платформой с IP-score-гейтом.

#### DaoVote
- **(а)** Голос в DAO.
- **(б)** `vote` (`for | against | abstain`), `weight Int` — **вес = IP-score голосующего** («чем выше доверие, тем больше вес»).
- **(в)** Cascade; `@@unique([proposalId, voterId])`, индекс `[proposalId]`.
- **(г)** Пишет: POST /api/dao/[id]/vote (10/час) (§2.22). Читают: votes GET, groupBy при авто-закрытии.
- **(д)** Плюрократия по доверию.

#### Referral
- **(а)** Реферальная программа (P2-4).
- **(б)** `code @unique` (первые 8 символов userId), `referredId? @unique` (1 приглашённый на код), `rewardGiven`, `rewardAmount` (бонус IP-score; REFERRAL_BONUS_WEIGHT=5), `status` (`pending | rewarded | expired`), `rewardedAt?`.
- **(в)** `referrer → User` («Referrer», Cascade), `referred → User?` (**SetNull**); индексы по обоим.
- **(г)** Пишет: auth/register (регистрация по коду → rewarded + ReputationEvent weight 5 обоим) (§2.1). Читает: GET /api/referral (статистика + ссылка) (§2.23).
- **(д)** Органический рост с репутационным бонусом.

#### Subscription
- **(а)** Журнал подписок (Phase 13): история транзакций/смен тарифов для биллинга и аналитики. Текущий тариф денормализован в `User.subscriptionTier` для быстрых запросов.
- **(б)** `tier` (`free | pro | business | enterprise`), `status` (`active | cancelled | expired | past_due`), `startedAt/expiresAt/cancelledAt`, `paymentMethod` (`stripe | cloudpayments | yookassa | manual` — **заглушка: пока manual/demo**), `pricePaid?`, `currency` (`RUB`). Цены: pro 499₽/мес (4990₽/год), business 1499₽/мес (14990₽/год) (§2.23).
- **(в)** `user → User` (**без onDelete → Restrict**); индекс `[userId, status]`.
- **(г)** Пишет: POST /api/subscriptions (DemoGateway — мгновенная активация), DELETE (отмена), legacy /api/subscription/upgrade (мгновенная смена tier — без реального платежа) (§2.23, §3.31). Читает: GET /api/subscription (история), /api/subscriptions (PLANS).
- **(д)** Монетизация подписками; журнал + денормализация — типовая связка.

#### LumenTransaction
- **(а)** Журнал операций с люменами (Wave 14) — «валюта ИИ-действий».
- **(б)** `type` (`topup | dividend | spend | refund`), `lumens Int` (+пополнение / −списание), `rubles?` (topup — внесено; dividend — база за период), `meta?` (JSON {action, label, note, days...}), `refundOf? @unique` — ссылка на исходный spend для **идемпотентного refund** (дубликат → P2002 → no-op).
- **(в)** `user → User` (Cascade); индекс `[userId, createdAt]`.
- **(г)** Пишет: POST /api/lumens/topup (emailVerified обязателен; пресеты 100/300/500/1000 ₽; 1₽=1 люмен), /accrue (демо-дивиденды; формула `lumenRubles × 0.15 × days/365`, CAS-guard по lumenAccruedAt, kill-switch env), LumenService.spend (career_agent=1, career_scenario=1, cv_generate=2) (§2.23, §3.30). Читает: GET /api/lumens (баланс + последние транзакции).
- **(д)** Двухконтурная монетизация: дивидендная база (lumenRubles) + расход на AI-действия (ledger).

#### ProfileView
- **(а)** Кто посмотрел профиль (Phase 3, раздел «Кто обратил внимание»).
- **(б)** `viewerId/viewedId/viewedAt`. **Дедупликация — в коде** (одна запись на viewer+viewed за 24 часа, POST /api/users/[id]/view); уникального ограничения в БД нет.
- **(в)** Оба конца Cascade; индексы `[viewedId, viewedAt]`, `[viewerId, viewedAt]`.
- **(г)** Пишет: POST /api/users/[id]/view (анонимно для Pro hidden mode) (§2.3). Читают: me/profile-views (Pro-фича), intent-service (networking/mentor_search факторы profileViewsMade) (§3.14).
- **(д)** Обратная социальная связь + сигнал намерений.

#### ProfessionalIntent
- **(а)** Явные и AI-выведенные намерения пользователя (Phase 5) — вход Opportunity Engine.
- **(б)** `type` (комментарий схемы: `job_search | promotion | project_search | learning | mentor_search | hire_specialist | partnership | career_change | skill_development | client_search`; intent-service активно использует подмножество из 7 — §3.14), `source` (`explicit` — confidence 1.0 | `inferred` — AI-вывод, confidence 0.3–0.8), `confidence Float`, `isActive` (false при удалении/истечении), `expiresAt?`.
- **(в)** `user → User` (**без onDelete → Restrict**); индексы `[userId, isActive]`, `[userId, type, isActive]`.
- **(г)** Пишет: POST /api/me/intent (explicit), intent-service (inferred по формулам: job_search = 0.3 + applications×0.15 + savedJobs×0.05 и т.д.), CoachService.confirmInsight (+0.1 cap 1.0) (§2.31, §3.14, §3.17). Читают: opportunity-service (intentAlignment), next-best-action, sponsored/feed targeting (intentTypes), coach.
- **(д)** Декларативный слой «чего хочет пользователь» — главный персонализационный сигнал.

#### Opportunity
- **(а)** Универсальная модель возможностей (Phase 5 Opportunity Engine).
- **(б)** `type` (`job | project | mentor | partnership | expert | education | event | business`), `title/description?`, полиморфные ссылки `companyId?/jobId?/projectId?/eventId?/mentorId?` (**все без FK**; обычно заполнен один), `requirements?/skills?` (JSON), `level?` (1-10), `location?/compensation?`, скоринг 0..1: `trust` (для вакансии = vacancyTrust/100, для человека = ipScore/100), `freshness` (1 = создана сегодня, 0 = >30 дней), `relevance` (skill overlap), `intentAlignment` (совпадение с активными ProfessionalIntent), `explanation?` («почему BizON показывает это»).
- **(в)** Ссылок-отношений нет вообще (полиморфия через строки); индексы `[type, createdAt]`, `[createdAt]`.
- **(г)** Пишет/читает: OpportunityService — 7 генераторов возможностей; score = `relevance × intentAlignment × trust × (0.5 + 0.5×freshness)` (§2.20, §3.15).
- **(д)** Единый интерфейс «возможностей» поверх разных доменных сущностей; запись в БД моделью предусмотрена, генераторы работают по живым таблицам.

#### ActionEvent
- **(а)** Actions Timeline (R10): хронология поступков, доступная в публичном профиле.
- **(б)** `type` (комментарий схемы: `nft_skill_received | project_completed | project_started | community_joined | article_published | claim_verified`; сервисный банк ActionEventService — 20+ типов, включая служебные `feed_dwell`, `job_viewed`), `title` (человекочитаемое), `description?`, `metadata?` (JSON, без PII), `isPublic`.
- **(в)** `user → User` (Cascade); индексы `[userId, createdAt]`, `[type, createdAt]`.
- **(г)** Пишут: feed/dwell (батч ≤50), jobs/[id]/view (дедуп 1/сутки), projects/confirm (moments), applications status, sponsored click (§2.5, §2.9, §2.11, §2.24). Читают: me/actions, me/moments (PROFESSIONAL_MOMENT_TYPES + синтетика + дедуп (type, day, title)), market intelligence, companies stream, causality engine (§2.31, §3.26, §3.28, §3.32).
- **(д)** Поведенческая телеметрия, частично публичная; сырьё причинно-следственного движка.

---

## 3. Карта отношений

### 3.1 User → (владелец/участник)

| Связка | Тип | onDelete | Куда делисходит |
|---|---|---|---|
| User → Session | 1:N | Cascade | аутентификация |
| User → VerificationToken | 1:N | Cascade | email-верификация |
| User → UserSkill | 1:N | Cascade | навыки (с Skill N:1) |
| User → SkillConfirmation (Confirmer) | 1:N | Cascade | подтверждения чужих навыков |
| User → Project (Owner) / ProjectMember | 1:N | Cascade | проекты |
| User → Connection (From/To) | 2×N | Cascade | контакты |
| User → Follow (Follower/Following) | 2×N | Cascade | подписки |
| User → ReputationEvent / ReputationSnapshot | 1:N | Cascade | репутация |
| User → JobApplication / managedJobs (hiringManager) | 1:N / 1:N | Cascade / SetNull | найм |
| User → Post (PostAuthor) / PostLike / PostComment | 1:N | Cascade | контент |
| User → SavedPost/SavedJob/SavedAd | 1:N | Cascade | избранное |
| User → Employee / CompanyFollower / CompanyReview | 1:N | Cascade | компании |
| User → Event (organizer) / EventParticipant | 1:N | SetNull / Cascade | события |
| User → Community (owner) / CommunityMember / CommunityPost | 1:N | Cascade | сообщества |
| User → Conversation (from/to) / Message | 2×N / 1:N | Cascade | мессенджер |
| User → Notification | 1:N | Cascade | уведомления |
| User → NFTSkill / DaoProposal / DaoVote / Referral (referrer/referred) | 1:N | Cascade / SetNull(referred) | Фаза 2 |
| User → Claim / ClaimVerification (Verifier) / CareerEntry | 1:N | Cascade | Truth Engine |
| User → ProfessionalEvidence / ProfessionalNarrative / ProfessionalCapital (1:1) / TrustIndex (1:1) | 1:N/1:1 | Cascade | доверие v6 |
| User → AiInsight / CoachQuestion / CoachInsight / IgnoredTopic / ResearchResult | 1:N | Cascade | AI-данные |
| User → ProfileView (viewer/viewed) / ColleagueInquiry (from/to/about) | 2×N / 3×N | Cascade | соцмеханики |
| User → ActionEvent / CulturalSignal (author) | 1:N | Cascade | таймлайны |
| User → Placement (hrAgency/candidate) | 2×N | Cascade / SetNull | HR |
| User → HrContact (hr/candidate) | 2×N | Cascade | Privacy Shield |
| User → Resume / CareerCompass / UserCourse / PublicationAuthor / Mentorship (mentor/mentee) | 1:N | Cascade / Restrict(mentorship, pubAuthor) | карьера |
| User → Recruiter (1:1) / HrClient / ProfessionalIntent / Subscription / AdPressure | 1:1/1:N | Restrict | HR-org, интенты, биллинг |
| User → HrOrganization — нет прямого FK (агентство связано через Recruiter) | — | — | — |
| User → Company (CompanyAccount) | N:1 | Restrict | аккаунты компаний/агентств |
| User → LumenTransaction | 1:N | Cascade | люмены |
| User → SavedFilter / BirthdayPlan | 1:N | Cascade | Wave 11 |
| User → NewsShare (from/to) | 2×N | Cascade | новости |

### 3.2 Company → (владелец/цель)

| Связка | onDelete |
|---|---|
| Company → Employee / CompanyFollower / CompanyReview / CulturalSignal (author=User) / CompanyClaim / Placement / Job (companyRel) / Event (company) / SponsoredOpportunity (advertiser) | Cascade (Job/Event/Sponsored — Cascade/SetNull/Restrict соответственно: Job SetNull, Event SetNull, Sponsored Restrict) |
| User.companyId → Company (CompanyAccount) | Restrict (нельзя удалить компанию с привязанными аккаунтами) |
| Project.companyId → Company | **без FK** (висячая ссылка) |

### 3.3 Job → (цель)

| Связка | onDelete |
|---|---|
| Job → JobApplication / SavedJob | Cascade |
| Job.companyId → Company / hiringManagerId → User | SetNull / SetNull |
| Resume.jobId → Job | **без FK** |

### 3.4 Проект → (цель)

| Связка | onDelete |
|---|---|
| Project → ProjectMember / SkillConfirmation / ProjectConfirmation | Cascade |
| Claim.projectId / Publication.projectId → Project | **без FK** |
| Project.companyId → Company | **без FK** |

### 3.5 Прочие владельцы

- **Community → CommunityMember / CommunityPost**: Cascade.
- **Event → EventParticipant**: Cascade.
- **Conversation → Message**: Cascade.
- **Post → PostLike / PostComment / SavedPost**: Cascade.
- **Ad → AdImpression / SavedAd**: Cascade.
- **NewsCard → NewsShare**: Cascade.
- **Course → UserCourse**: Cascade.
- **Publication → PublicationAuthor**: Cascade (а PublicationAuthor→User — Restrict).
- **HrOrganization → Recruiter / HrClient**: Restrict / Cascade.
- **Claim → ClaimVerification**: Cascade.
- **UserSkill → SkillConfirmation**: Cascade.
- **DaoProposal → DaoVote**: Cascade.
- **Skill → UserSkill**: Cascade (SkillSynonym.skillId — без FK).

---

## 4. Индексы и уникальные ограничения (полный список)

Формат: модель — ограничения (значения из схемы). Пояснение «зачем» — где очевидно.

| Модель | Ограничения | Зачем |
|---|---|---|
| User | `emailHash @unique`; `passportToken @unique` | поиск по email без PII; публичный паспорт |
| VerificationToken | `tokenHash @unique`; `@@index([userId])` | одноразовость токена; токены пользователя |
| LumenTransaction | `refundOf @unique`; `@@index([userId, createdAt])` | 1 refund на spend (P2002 → no-op); журнал кошелька |
| SavedPost | `@@unique([userId, postId])`; `@@index([userId, createdAt])` | дедуп закладок; лента избранного |
| SavedJob | `@@unique([userId, jobId])`; `@@index([userId, createdAt])` | то же |
| SavedAd | `@@unique([userId, adId])`; `@@index([userId, createdAt])` | то же |
| Post | `@@index([createdAt])`, `@@index([type, createdAt])`, `@@index([authorId, createdAt])` | глобальная лента; фильтр commercial; лента автора (FIX-06) |
| PostLike | `@@unique([postId, userId])` | 1 лайк |
| PostComment | `@@index([postId, createdAt])` | ветка комментариев |
| Skill | `name @unique` | канонический словарь |
| UserSkill | `@@unique([userId, skillId])` | 1 строка на навык у пользователя |
| SkillConfirmation | `@@unique([userSkillId, confirmerId, projectId])` | 1 подтверждение на пару в проекте (FR-4) |
| Project | `@@index([status])` | выборка recruiting/active |
| ProjectMember | `@@unique([projectId, userId])` | 1 участие |
| ProjectConfirmation | `@@unique([projectId, userId])`; `@@index([projectId])` | 1 подтверждение на участника; кворум-опрос |
| Connection | `@@unique([fromUserId, toUserId])`; `@@index([toUserId, status])` | без дублей; «входящие заявки» |
| Follow | `@@unique([followerId, followingId])`; `@@index([followingId])` | 1 подписка; «подписчики X» |
| ReputationEvent | `@@index([userId, createdAt])`; `@@index([impactScore])` | события пользователя; Trust Stream по весу |
| Job | `@@index([active, createdAt])`; `@@index([companyId])` | активные вакансии; вакансии компании |
| JobApplication | `@@unique([jobId, userId])`; `@@index([userId, createdAt])` | 1 отклик; «мои отклики» (FIX-06) |
| Ad | `@@index([active, moderationScore])` | чистые активные объявления (FIX-06) |
| AdImpression | `@@index([adId, userId])` | показы объявления (без unique — повторные показы) |
| Session | `token @unique`; `@@index([userId])` | lookup по токену; сессии пользователя |
| Company | `@@index([industry])`; `passportToken @unique` | отраслевые фильтры; Company Passport |
| Employee | `@@unique([companyId, userId])` | 1 трудовая связь |
| CompanyFollower | `@@unique([companyId, userId])` | 1 подписка |
| CompanyReview | `@@index([companyId, createdAt])` | отзывы компании |
| Event | `@@index([startDate])`; `@@index([category, format])` | upcoming; фильтры каталога |
| EventParticipant | `@@unique([eventId, userId])`; `@@index([userId])` | 1 RSVP; мои события |
| Community | `slug @unique`; `@@index([category])`; `@@index([visibility])` | URL; каталоги |
| CommunityMember | `@@unique([communityId, userId])`; `@@index([userId])` | 1 членство; мои сообщества |
| CommunityPost | `@@index([communityId, createdAt])` | лента сообщества |
| Conversation | `@@unique([fromUserId, toUserId])`; `@@index([fromUserId])`; `@@index([toUserId])` | дедуп диалога; «мои диалоги» с двух сторон |
| Message | `@@index([conversationId, createdAt])` | переписка |
| Notification | `@@index([userId, isRead, createdAt])` | инбокс + непрочитанные |
| NFTSkill | `@@index([userId, status])`; `@@index([userSkillId])` | мои NFT по статусу; связь с UserSkill |
| DaoProposal | `@@index([status, endDate])` | активные + авто-закрытие |
| DaoVote | `@@unique([proposalId, voterId])`; `@@index([proposalId])` | 1 голос; голоса предложения |
| Referral | `code @unique`; `referredId @unique`; `@@index([referrerId])`; `@@index([referredId])` | 1 код; 1 приглашённый на аккаунт |
| ProfessionalEvidence | `@@index([userId, status, date])`; `@@index([skillId])` | активные evidence; доказательства навыка |
| AuditLog | `@@index([actorId, createdAt])`; `@@index([resource, resourceId])`; `@@index([action])`; `@@index([ip])` | аудит пользователя/ресурса/действия; anti-fraud общих IP |
| ProfessionalCapital | `userId @unique`; `@@index([total])` | 1:1; рейтинги капитала |
| ProfessionalNarrative | `@@index([userId, version])` | эволюция нарратива |
| AiInsight | `@@index([userId, type, createdAt])` | свежие инсайты по типу |
| CoachQuestion | `@@index([userId, createdAt])` | вопрос дня |
| CoachInsight | `@@index([userId, status])`; `@@index([userId, createdAt])` | активные гипотезы; последние (FIX-06) |
| IgnoredTopic | `@@unique([userId, topic])` | 1 скрытие темы |
| SkillSynonym | `@@index([synonym])`; `@@index([skillId])` | поиск по алиасу; алиасы навыка |
| Claim | `@@index([userId, status])` | мои claims по статусу |
| ClaimVerification | `@@unique([claimId, verifierId])` | 1 вердикт от верификатора |
| CareerEntry | `@@index([userId, isCurrent])` | текущее место |
| ReputationSnapshot | `@@index([userId, takenAt])` | тренд |
| ProfileView | `@@index([viewedId, viewedAt])`; `@@index([viewerId, viewedAt])` | «кто смотрел»; «кого смотрел я» |
| Resume | `@@index([userId, createdAt])` | мои резюме |
| CareerCompass | `@@index([userId, generatedAt])` | последний компас |
| ColleagueInquiry | `@@index([toUserId, status])`; `@@index([fromUserId])`; `@@index([aboutUserId])` | входящие запросы; исходящие; «обо мне» |
| ActionEvent | `@@index([userId, createdAt])`; `@@index([type, createdAt])` | таймлайн; лента по типу |
| CulturalSignal | `@@index([companyId, status])` | published-сигналы компании |
| CompanyClaim | `@@index([companyId, status])` | claims по статусу |
| Placement | `@@index([hrAgencyId])`; `@@index([companyId])`; `@@index([candidateId])` | портфолио HR; наймы компании/кандидата |
| HrContact | `@@unique([hrAgencyId, candidateId, weekKey])`; `@@index([candidateId, status])`; `@@index([hrAgencyId, status])` | лимит 1 контакт/неделю; inbox/outbox |
| NewsCard | `url @unique`; `@@index([status, publishedAt])`; `@@index([category, status])` | без дублей внешних статей; модерация и лента |
| NewsShare | `@@unique([cardId, fromUserId, toUserId])`; `@@index([toUserId, createdAt])`; `@@index([fromUserId, createdAt])` | без повторной отправки; «поделились со мной» |
| Course | `@@index([category])` | каталог |
| UserCourse | `@@unique([userId, courseId])`; `@@index([userId, status])` | 1 запись; мои курсы |
| Publication | `@@index([publishedAt])`; `@@index([type, publishedAt])` | хронология; фильтр типа |
| PublicationAuthor | `@@unique([publicationId, userId])`; `@@index([userId])` | 1 роль в публикации; мои публикации |
| HrOrganization | `@@index([isVerified])` | верифицированные агентства |
| Recruiter | `userId @unique`; `@@index([organizationId])` | 1:1 с User; команда агентства |
| HrClient | `@@index([hrOrganizationId])`; `@@index([userId])` | клиенты агентства |
| ProfessionalIntent | `@@index([userId, isActive])`; `@@index([userId, type, isActive])` | активные интенты; intent-match |
| Opportunity | `@@index([type, createdAt])`; `@@index([createdAt])` | по типу; свежие |
| Mentorship | `@@index([mentorId])`; `@@index([menteeId])`; `@@index([status])` | роли; активные |
| Subscription | `@@index([userId, status])` | активная подписка |
| SponsoredOpportunity | `@@index([status, createdAt])` | активные кампании |
| AdPressure | `@@unique([userId, date])` | 1 счётчик в день |
| TrustIndex | `userId @unique`; `@@index([dimension])` | 1:1; по измерению |
| SavedFilter | `@@index([userId, createdAt])` | мои фильтры |
| BirthdayPlan | `@@index([ownerId, dateMonth, dateDay])`; `@@index([status])` | календарь планировщика |
| ResearchResult | `@@unique([userId, testKey])` | 1 результат на тест |

---

## 5. Мост к формулам: какие поля питают ключевые вычисления

Формулы подробно описаны в 04-каталоге §3; здесь — таблица «формула → таблицы/поля → где считается».

| Формула / вычисление | Таблицы / поля-источники | Где считается (файл) |
|---|---|---|
| **IP-score** = round((A×0.4 + B×0.3 + C×0.2 + D×0.1)×100); A = completed/max(3,total) проектов; B = avgRating/5; C = log1p(confirmations)/log1p(20); D = min(events_7d/7,1) | `Project` (status, rating), `ProjectMember`, `SkillConfirmation` (count), `ReputationEvent` (createdAt, 7-дневное окно); результат — `User.ipScore`, `User.level` | `src/lib/reputation.ts:3-117` (см. 04-каталог §3.1); вызовы — connections PATCH, skills/confirm, projects/confirm, auth/register, /api/reputation/* |
| **Impact Score** (Trust Stream) = TrustWeight × Engagement × Relevance | `ReputationEvent.impactScore` (пишется при создании; relevance по типу: project_completed 1.0 … ad_clicked 0.2) | `src/lib/reputation.ts:194-220` (§3.1) |
| **Job match** = skillMatch×0.6 + (ipScore/100)×0.25 + growthScore×0.15; пустые requiredSkills → 0.3 | `Job.requiredSkills` (CSV «Skill:L»), `Job.growthScore`, `UserSkill` (уровни), `User.ipScore`; результат — `JobApplication.matchConfidence` | `src/lib/ai.ts:234-248` (§3.3); пишут apply/match-роуты |
| **Match explainable**: skills = matched/required×100; trust = clamp(ipScore + min(15, commonContacts×5)); candidateFit = skills×0.6 + trust×0.25 + growth×0.15; companyFit = culturalFit + min(6, verifiedProjects/2) | `UserSkill`, `User.ipScore`, `Connection` (commonContacts), `CulturalSignal` (companyFit; null если нет — честный режим), `Project` (verified) | `src/lib/ai.ts:413-468` + `jobs/[id]/match-explain/route.ts:347-381` (§3.3) |
| **Skill Level Formula (§D.6/D.7)**: 4 бакета (projects 1.0/40, confirmations 0.7/30, results 0.8/20, recommendations+certificates 0.5/10), saturatingSum; level = ceil(total/10); confidence = avg(verifierTrust×recency×diversity); decay 12/24 мес (1.0/0.8/0.6); peakLevel не убывает | `ProjectMember/Project` (даты, result), `SkillConfirmation` (+verifierTrust из `User.ipScore`/`User.level`), `ProfessionalEvidence` (result), `Publication`; запись — `UserSkill.peakLevel/currentLevel/confidence/decayStatus/lastUsedAt/formulaVersion` | `src/lib/skills/level-formula.ts:15-200`, `src/lib/services/skill-graph-service.ts:240-408` (§3.6, §3.7) |
| **Professional Capital** (8 компонентов, веса 0.20/0.15/0.15/0.15/0.10/0.10/0.10/0.05): verifiedExpertise = verified-навыки×15; projectCapital = completed×15; outcomeCapital = verified evidence×20; trustCapital = ipScore/5 + бонус уровня; networkCapital = connections×2; leadershipCapital = founder-роли×20; marketRelevance = навыки с >5 вакансий×20; learningVelocity = навыки за 30 дней×10; total = Σ comp×weight | `UserSkill.verificationLevel`, `Project`/`ProjectMember` (completed, owner-роль), `ProfessionalEvidence.verificationLevel/confidence`, `User.ipScore/level`, `Connection`, `Job` (активные по навыкам); запись — `ProfessionalCapital.*` | `src/lib/services/capital-service.ts:28-129` (§3.8); триггер — event-bus `skill.verified` |
| **Professional Trust** (6 факторов): evidenceQuality = 0.6×starFilledAvg + 0.4×confidenceAvg; verification = 0.8×evidence + 0.2×claims (веса уровней claimed 0.1 → expert_verified 1.0); outcome = 0.6×resultShare + 0.4×completedShare; recency (кривая §D.7); consistency = 0.5×(1−0.25×contradictions) + 0.5×multiConfirmationShare | `ProfessionalEvidence` (STAR-поля, confidence, verificationLevel, date), `Claim`/`ClaimVerification` (verdict, role), `Project`; запись — `TrustIndex.score/dimension/factors/computedAt` | `src/lib/services/professional-trust-service.ts:105-535` (§3.9) |
| **Company Trust** (4 индекса, веса 0.35/0.25/0.25/0.15): employer (CulturalSignal: ≥5 → 0.9…), business (verified CompanyClaim, log1p(20)), delivery (CompanyReview rating / Project.rating), transparency (isVerified + публичные зарплаты) | `CulturalSignal` (status, count), `CompanyClaim.status`, `CompanyReview.rating`, `Project.rating`, `Company.isVerified`, `Job.salaryMin/Max`; запись — `Company.employerTrust/businessTrust/deliveryTrust/transparency/culturalScore` | `src/lib/services/company-trust-service.ts:39-224` (§3.10) |
| **HR Trust**: recruiterTrust = log1p(closedPlacements)/log1p(20); agencyTrust = среднее по рекрутерам; закрытый placement = confirmedByCandidate && confirmedByCompany | `Placement` (оба флага), запись — `Recruiter.recruiterTrust`, `HrOrganization.agencyTrust` | `src/lib/services/hr-trust-service.ts:20-140` (§3.11) |
| **NFT weight / canMint**: прямая связь (accepted ИЛИ общий проект) = 1.0, через 1 рукопожатие = 0.3; общий проект ×1.5 (cap 1.0); N6 confirmer.ipScore > 10; N4 лимит 3 NFT confirmer→target | `Connection.status`, `ProjectMember`, `User.ipScore`; запись — `NFTSkill.weight/decayedStatus/confirmerId` | `src/lib/services/nft-skills-service.ts:37-278,413-510` (§3.24) |
| **Recommendations (лента)**: decay `1/(1+days×0.1)`; implicit-буст просмотров ≤+0.25; coach-буст (job_interest +0.2, career_shift +0.15); dwell-буст ≤+0.15; вакансии 70/20/10 (exact/synonym/surprise); анти-эхо через IgnoredTopic; итог matchConfidence = min(1, match+implicit+coach+dwell) | `ActionEvent` (feed_dwell, job_viewed), `CoachInsight` (токены гипотез), `IgnoredTopic` (source feed/coach/jobs), `SkillSynonym`, `User.ipScore` (фолбэк), `Follow`/`Connection` (following), `Event.startDate`, `Company.culturalScore` | `src/app/api/feed/recommendations/route.ts:59-933` (§2.5) |
| **Люмены**: дивиденды = `lumenRubles × 0.15 × (days/365)`, целый люмен кредитуется, дробный — в `lumenFraction`, CAS-guard `lumenAccruedAt`; spend-прайс: career_agent=1, career_scenario=1, cv_generate=2; refund идемпотентный (refundOf @unique) | `User.lumenBalance/lumenRubles/lumenFraction/lumenAccruedAt`, запись — `LumenTransaction` (topup/dividend/spend/refund) | `src/lib/services/lumen-service.ts:28-410` (§2.23, §3.30) |
| **Opportunity score** = relevance × intentAlignment × trust × (0.5 + 0.5×freshness); trust: jobs = vacancyTrust/100, люди = ipScore/100, проекты = 0.5+ipScore/200, courses 0.6, companies isVerified?0.8:0.5 | `Job.vacancyTrust`, `User.ipScore`, `ProfessionalIntent` (тип/isActive/confidence), `Company.isVerified`; запись — `Opportunity.trust/freshness/relevance/intentAlignment` | `src/lib/services/opportunity-service.ts:415-1318` (§3.15) |
| **Intent inferred** (окно 30 дней, cap 0.3–0.7): job_search = 0.3 + applications×0.15 + savedJobs×0.05; project_search = 0.3 + projects×0.2; networking = 0.3 + connectionsInitiated×0.1 + profileViewsMade×0.02; learning = 0.3 + courses×0.15; hire_specialist = 0.4 + jobs×0.1 | `JobApplication`, `SavedJob`, `ProjectMember`, `Connection`, `ProfileView`, `UserCourse`, `Job`; запись — `ProfessionalIntent` | `src/lib/services/intent-service.ts:36-326` (§3.14) |
| **Mentor matching / effectiveness**: гэп = currentLevel < 7; ментор = peakLevel ≥ 8; score = effectiveness×0.5 + trust×0.3 + mentorLevel×2×0.2; эффективность = mentee/10×30 + growth×30 + newRole×15 + rating/5×25 | `UserSkill.peakLevel/currentLevel`, `Mentorship` (menteeCount, mentorRating, menteeGrowth JSON) | `src/lib/services/mentor-service.ts:31-480` (§3.13) |
| **Anti-fraud Suspicion Score** (CONFIRM_SPEED +25, NIGHT_HOUR +20, IP_SHARED +30, NO_REPUTATION +25, DEVICE_SHARED +30, RECIPROCAL +40; заморозка ≥70 на 24ч) | `SkillConfirmation`/`ClaimVerification` (скорость), `AuditLog.ip` (общие IP), `User.ipScore`/`createdAt` | `src/lib/security/anti-fraud.ts:24-37` (§1.5) |
| **trust-explain 6 осей + deltaTrust** (base: project_completed 22, skill_confirmed 9, intro_sent 4, connection_accepted 3; k = 0.5+impact) | `ReputationSnapshot` (trend), `User.ipScore`, `ReputationEvent` | `src/app/api/me/trust-explain/route.ts:33-254`, `src/app/api/me/whats-new/route.ts:290-400` (§2.31) |
| **Vacancy Verification** (8 критериев; ≥70 verified, ≥50 posted) / **Hiring Reality** (11 критериев; ≥70 high, ≥40 medium) / **Time Value** (APPLY match>80 && hr>70; SKIP match<60 || hr<40) | `Job.*` (hiringStages, salary, responseTimeHours…), `JobApplication` (отклики), `Company` (активность), `CulturalSignal`; запись — `Job.verificationStatus/vacancyTrust` | `src/lib/services/vacancy-verification-service.ts`, `hiring-reality-service.ts`, `time-value-service.ts` (§3.21–3.23) |
| **Build Talent** score = 0.55×skills + 0.25×trust + 0.20×activity; компонент навыка = 0.6×levelFit + 0.4×verificationWeight | `UserSkill` (уровни, verificationLevel), `User.ipScore`, `ActionEvent` (активность), `SkillSynonym` | `src/lib/services/build-talent-service.ts:43-216` (§3.25) |
| **Evidence Coverage** (A4) — процент подтверждённых утверждений | `Claim.status` (verified share); запись — `ReputationSnapshot.evidenceCoverage` | `src/app/api/reputation/snapshots/route.ts` (§2.13) |

---

## 6. Сводка нестандартных решений (для аудитора)

1. **PII**: plaintext-поля User всегда NULL; истина — в `*Encrypted` + `emailHash` (§1.1).
2. **Строковые enum вместо Prisma enum** — значения живут в комментариях схемы и zod-схемах; рассинхрон схемы и сервиса возможен (пример: `ProfessionalIntent.type` — 10 значений в схеме, 7 активных в intent-service; `Notification.type` — 6 в комментарии схемы, 7 в сервисе).
3. **Висячие ссылки без FK** (11 полей, §1.6) — целостность на коде; удаление цели не каскадируется.
4. **Три режима onDelete** (Cascade/SetNull/Restrict по умолчанию) — перечислены в §1.4; Restrict осознанно стоит на биллинге (Subscription), организации (Recruiter), интентах и менторствах.
5. **Уникальность как бизнес-правило**: weekKey-лимит HR-контактов, дневной AdPressure, идемпотентный refundOf — инварианты на уровне БД, а не кода.
6. **Дедуп без unique**: `ProfileView` (24-часовое окно), `AdImpression` (повторные показы) — множественность допустима намеренно.
7. **Conversation `@@unique([fromUserId, toUserId])` однонаправленна** — теоретически возможны два диалога A→B и B→A; защита — upsert-логика в коде.
8. **Денормализованные счётчики** (likesCount, membersCount, forVotes, impressions/spent) поддерживаются кодом — при баге расходятся с фактом; отдельного reconcile-механизма в каталоге нет.
9. **СТАБы в данных**: `UserCourse.certificateNftId`, `Job.boosted*`, `Company.isVerified` (без ЕГРЮЛ), `Subscription.paymentMethod` (demo/manual), тренд CapitalService (нет снапшотов капитала) — полный список стабов в 04-каталоге §5.
10. **`TrustIndex.factors` — единственное поле `Json`**; все остальные «JSON» — String-колонки, парсинг ручной.
11. **Soft-delete User.deletedAt** + каскадное физическое удаление cron-ом через 30 дней; замечание из 04-каталога §5 п.17: `auth.ts` пока не фильтрует `deletedAt` при выдаче сессий (TODO) — важный аудит-факт.
12. **`expiresAt` в `ColleagueInquiry` задаётся кодом** (SQLite не умеет default-выражения с now()+7d) — аналогичные вычисляемые значения ищите в сервисах, а не в схеме.
