# ADR-002: Store MVP — StoreItem/StoreBooking + люменный эскроу

Принят: 18.09.2026 · Волна 2 (S-029…S-045) · Авто-режим (владелец: «продолжай Wave 2… пока не достигнешь конечной Wave N точки», trace 1a0b636a2ef3e351)
Статус: ПРИНЯТ. Отклонённые альтернативы зафиксированы с причинами.

## Контекст

§18 оверлея: Store — единственный статус **MISSING** (нет StoreItem, /api/store, booking). Фундамент готов к REUSE:

- `LumenService` — атомарный race-safe бухгалтерия люменов: spend (guard-декремент + ledger в одной $transaction), refund (идемпотент через `LumenTransaction.refundOf @unique`), topup, getWallet (FIX-06).
- `PaymentGateway`-абстракция (payment-service): `DemoGateway` (песочник, честный) + `ExternalGatewayAdapter` (структурированный `NOT_CONFIGURED_IN_SANDBOX`, успех не имитируется).
- `Subscription`-тиры (free/pro/business), `Complaint` (7 категорий, Wave 1), `velocity.ts` (тиры лимитов), action-registry (`SPEND_MONEY` = critical/manual уже зарегистрирован), AuditLog, NotificationService.
- Требование Плана-v2: деньги → только через гейт KYC/реального шлюза (чек-пойнт владельца); в песочнице — люмены/мок.

## 14-вопросный Decision Rule (протокол §4)

1. **Какая проблема?** Экспертные услуги/цифровые товары не sellable: нет витрины, заказа, эскроу — монетизация платформы не запускается.
2. **Кто выигрывает?** Владельцы профилей (продажа «Как со мной работать»), покупатели (эскроу-защита), платформа (люменная экономика).
3. **Что уже есть?** LumenService, PaymentGateway, Subscription, Complaint, velocity, AuditLog, action-registry. Дублей Store-логики нет (grep src/lib/services).
4. **Изменения данных?** 2 новые additive-модели (StoreItem, StoreBooking) + 3 back-relation на User. Изменения существующих моделей — нет. db:push, откат = отключение роутов (модели безвредны).
5. **API?** /api/store/items (GET/POST), /api/store/items/[id] (PATCH), /api/store/items/[id]/book (POST), /api/store/bookings (GET), /api/store/bookings/[id]/{fulfil,decline,release,cancel} (POST). Всё через withRoute + zod + rateLimit + velocity.
6. **UI?** view `store` (витрина + мои товары + заказы), секция «Как со мной работать» в профиле продавца.
7. **Latency?** Витрина = 1 индексированный запрос (status+type); booking = 1 транзакция списания (~десятки мс). Не в горячем пути ленты/поиска.
8. **Memory/нагрузка?** Пренебрежимо (SQLite, индексы на ownerId / status,type / isPremium,createdAt).
9. **Security?** Эскроу идемпотентен (refundOf @unique, guard-статусы в updateMany); self-purchase BLOCKED; velocity STORE_BOOK (тиры); люмены ≠ доверие (см. п.13); audit на каждую смену статуса.
10. **Observability?** AuditLog STORE_ITEM_CREATED/STORE_BOOKING_*, LumenTransaction ledger (escrow=true в meta), ReputationEvent STORE_FULFILLED (внутренний сигнал).
11. **Failure?** Недостаточно люменов → структурированный 402-подобный отказ; краш между статусом и ledger невозможен (одна $transaction); decline/cancel всегда возвращает люмены; FAIL-OPEN не применим (это деньги, а не детектор).
12. **Rollback?** Отключение /api/store/* и view — модели additive, существующий код не затронут.
13. **Проверка?** Юнит: атомарность эскроу/идемпотентность refund/self-purchase/insufficient. Adversarial: «купленная рекомендация не влияет на trust» (нет Connection/Recommendation от сделок; matchmaker-результат пары не меняется), velocity-эскалация. E2E: витрина → покупка → исполнение → релиз, балансы сходятся.
14. **Почему недостаточно существующего?** Ad/AdImpression — показы, а не сделки (нет эскроу/жизненного цикла); Subscription — тариф, а не товар; люменные действия — фиксированный каталог без цены продавца.

## Конкурс A/B/C (протокол §19) — сравнение по 6 измеримым свойствам

Свойства: (1) время закрытия MISSING; (2) деньги-безопасность (идемпотентность/эскроу); (3) соответствие §3.3 (нет публичных чисел) и Data Guard; (4) governance-совместимость; (5) стоимость/риск внедрения; (6) откатываемость.

- **OPTION A — реюз `Ad` как витрина + прямое списание люменов.** (1) быстро; (2) **провал**: нет жизненного цикла сделки и эскроу, спор = потерянные люмены; (5) низкая. → **ОТКЛОНЕН**: свойство (2) ниже допустимого, дубль бизнес-правила поверх объявлений.
- **OPTION B — StoreItem/StoreBooking additive + люменный эскроу через EXTEND LumenService; реальный шлюз = существующий ExternalGatewayAdapter, включается только после KYC-гейта (S-044).** (1) быстро; (2) идемпотентность унаследована от FIX-06-паттерна + guard-статусы; (3) цена в люменах видна, рейтингов/чисел доверия нет; (4) SPEND_MONEY (critical/manual) покрывает покупку; (6) чистый откат. → **ПРИНЯТ**.
- **OPTION C — marketplace-микросервис + внешний провайдер (ЮKassa) прямо сейчас.** (2) выше теоретически, но (4) **провал**: приём реальных денег = обязательный чек-пойнт владельца (KYC, юридическая валидация), в песочнице недостижим; (5) высокий; §28 — преждевременный масштаб. → **ОТКЛОНЕН** как несвоевременный; каркас сохранён в ExternalGatewayAdapter.

## Решение

1. `StoreItem` (type: services|digital|expert-access; priceLumens; deliveryMode; evidenceRefs JSON; verificationStatus: self-attested|evidence-backed; isPremium; slotsTotal/slotsBooked; status: active|paused|archived) + `StoreBooking` (status: held→fulfilled→released | declined|refunded|cancelled; spendTxId; releaseTxId @unique; slotAt; notes).
2. `LumenService` EXTEND: `spendVar` (произвольная цена, тот же guard-паттерн), `refundVar` (идемпотент по refundOf), `credit` (зачисление продавцу в $transaction со сменой статуса booking).
3. Публичная политика: комиссия платформы в MVP = 0% (честно: продавец получает полную сумму; ввод комиссии — отдельное решение владельца, decision queue). Публичных чисел доверия от сделок — нет: STORE_FULFILLED только внутренний сигнал.
4. Реальные деньги: запрещены до выполнения `docs/KYC-REAL-GATEWAY-GATE.md` (S-044) и явного решения владельца на чек-пойнте (S-045).

## Последствия

- +2 модели, +8 API-эндпоинтов, +1 view, EXTEND LumenService (без изменения существующих сигнатур).
- Риск: гонки бронирования последнего слота → закрыт guard-апдейтом slotsBooked в транзакции.
- Риск: «купленное доверие» → закрыт adversarial-гейтом S-042 (сделки не создают рёбер графа).
