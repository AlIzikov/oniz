# ADR-001: Цикл IntroductionRequest (Wave 1 «Кольцо доверия»)
Статус: ACCEPTED · Дата: 18.09.2026 · Шаг S-004 · Конкурс §19 протокола (A/B/C) · Decision Rule §4 пройден (S-003)

## Контекст
План-v2 §7 требует цикла: поиск → путь (BFS≤5) → интро-запрос → согласие посредника → контролируемое сообщение → подтверждение контекста → рекомендация с provenance. Сейчас есть только безадресный matchmaker (`src/lib/matchmaker.ts`) с шаблоном интро — состояние цикла не хранится, согласий нет, лимитов нет, абьюз не отслеживается.

## Опции

**OPTION A — минимальный:** запросы хранить в существующих Notification-данных (payload JSON), состояния в тексте сообщения.
+ ноль миграций. − нет истории/статусов/экспирации в запросах; невозможен анти-абьюз по данным; аудит нечестный; UX тупиковый. **ОТКЛОНЁН** (решение «нельзя построить доверие на payload-строках»).

**OPTION B — production (выбран):** выделенная модель `IntroductionRequest` (requesterId, introducerId, targetId, purpose, message, status pending/accepted/declined/expired, expiresAt) + `intro-service.ts` (единый владельец жизненного цикла) + `sarafan-guard.ts` (детекторы абьюза) + действие REQUEST_INTRO в action-registry + API через withRoute. Путь считает существующий matchmaker (REUSE), новое — только состояние и согласия.
+ честный аудит, экспирация, rate-limit, консент посредника; additive к схеме; 14 вопросов дали убедительные ответы. **ПРИНЯТ.**

**OPTION C — scalable-future:** выделенный graph-микросервис (socket.io-канал, in-memory граф graphology, отдельная БД) + очередь событий.
+ горизонтальное масштабирование. − в песочнице 1 узел; преждевременный шард; новый транспорт поверх уже выбранного Направления А/Б; migration cost высокий. **ОТКЛОНЁН как преждевременный** (§28: architect for 10B, pay for current load). Пересмотр — при >1 инстанса Next (P3 scale-prep).

## Сравнение по измеримым свойствам
| Критерий | A | B | C |
|---|---|---|---|
| Correctness статусов цикла | нет | да | да |
| Security/consent | слабо | да (guard+registry) | да |
| Operational complexity | низкая | низкая | высокая (2 сервиса) |
| Testing difficulty | высокая (неявные состояния) | средняя | высокая (интеграция) |
| Migration costfuture | переписывание | нулевой | заранее платим |
| Vendor/infra lock-in | нет | нет | да (отдельная БД) |

## Последствия
1. Схема: `IntroductionRequest` + расширения `Recommendation`/`Connection` (S-005…S-007), только additive.
2. `intro-service.ts` — единственный писатель статусов; API-роуты тонкие (S-015).
3. `REQUEST_INTRO` в action-registry: risk=medium, externalSideEffect=true, defaultModes=NO_AUTOPILOT (S-015).
4. Путь и confidence — REUSE из matchmaker; decay-веса рёбер добавляются (S-014) как внутренний сигнал ранжирования, публично не показываются (§3.3).
5. Rollback: модель additive, отключение API-роутов возвращает систему к текущему поведению без миграций данных.
6. ML-эскалация (graphology/GNN) — через интерфейс `TrustPropagationModel` (S-008), не через переписывание intro-service.

## Риски
Массовые интро (rate-limit + sarafan-guard MASS) · обход согласия посредника (сообщение отправляется ТОЛЬКО после accept) · кольца рекомендаций (RING_DFS) — все три в adversarial-наборе S-026.
