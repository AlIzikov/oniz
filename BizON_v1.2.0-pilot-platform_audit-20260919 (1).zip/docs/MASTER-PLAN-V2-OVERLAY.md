# BizON — Оверлей MASTER PLATFORM BLUEPRINT V2 на текущий код
Дата: 18.09.2026 · Источник: `upload/Pasted Content_1789752069885.txt` (BIZON MASTER PLATFORM, 18.09.2026, V2)
Метод: построчная сверка 48 секций плана с физическим состоянием репозитория (сервисы, схемы Prisma, API, UI, governance) + результаты закрытых кампаний (worklog: мастер-кампания 17-09, adversarial 43 BLOCKED/0 EXPLOITED, Направления А/Б/В/Г — ALL MET).

Статусы по протоколу §44 плана: **READY** (работает, есть доказательства) · **PARTIAL** (каркас есть, до целевой формы не дотянуто) · **MISSING** (нет) · **?** (требует живой проверки).

---

## 1. СВОДНЫЙ ВЕРДИКТ

| Блок плана | Статус | Главное |
|---|---|---|
| §25-26 Код-реальность / REUSE | **READY** | 59 сервисов, 13 platform-модулей — план прямо подтверждает «эволюция, не рестарт» |
| §5.1 Person Profile | **READY** | Профиль+паспорт+память+интент+капитал; вкладки «Моё лицо/Анализ/Навыки/Коуч» |
| §5.3 Company Profile | **READY** | Паспорт компании, claims, культурные сигналы, интеллект; проверено живьём (демо-юрлицо) |
| §5.4-5.5 HR Workspace / Agency | **PARTIAL** | HR-панель, team-builder, workforce-гейты, HrOrganization/Recruiter/HrClient есть; tenant-изоляция агентства требует ревизии |
| §5.2 Expert/Premium Profile | **PARTIAL** | Тарифы free/pro/business есть; витрина эксперта (кейсы, услуги, booking) — нет |
| §6 Sarafan Radio | **PARTIAL** | Recommendation (author/subject/context/projectId/revoked) есть; нет relationshipType, scope, expiresAt, COI, анти-гейминга |
| §7 5 Handshakes | **PARTIAL** | matchmaker.ts: BFS≤5 + confidence + AI-шаблон интро; нет IntroductionRequest-цикла, типизированных рёбер, согласий, лимитов |
| §8 Opportunity Engine | **PARTIAL** | Opportunity-модель + match-объяснимость; типы вакансия/проект; план требует 12 типов |
| §9-10 Work / Projects=Proof | **PARTIAL** | Вакансии+отклики+placements+verified-vacancy; ProjectConfirmation есть; полный цикл DRAFT→…→VERIFIED требует сквозной проверки |
| §11-13 AI-инструменты (~35) | **READY(60%)** | career agent/compass/scenario, resume, edu, skill-futures, blind-spots, NBA, moments, market/company intelligence, talent-forecast, hiring-reality, causality, coach |
| §14 Diversity Engine | **PARTIAL** | IgnoredTopic + «не интересно» есть; decay/квоты exploration/семантическое расширение — не найдены |
| §15-16 Agents / AI Cost | **PARTIAL** | ai-core gateway + llm-client; реестра операций, semantic-cache по source_hash, метринга стоимости — нет |
| §17 Hidden Insights | **PARTIAL** | bizon-signal + AiInsight + coach-карточки; флоу «гипотеза→подтвердил→интент изменился» сверить |
| §18 Store / Commerce | **MISSING** | Нет StoreItem, checkout, booking, экспертных услуг |
| §19 Monetization | **READY(каркас)** | Subscription + люмены (topup/accrue/transfer) + ads/sponsored + payment-service |
| §21 News Bridge | **READY(каркас)** | NewsCard/NewsShare + news-score + news-relevance + источники; «News→Opportunity» цепочка — PARTIAL |
| §22 Product Design | **READY(80%)** | Light-first, Intelligence-домашняя, News Intelligence, единый поиск (Г), три лица; Project Room tabs — PARTIAL |
| §30 Data Guard | **READY** | data-vault (AES-256 PII, HMAC-поиск), sovereignty-гейт, согласия, region/citizenship, audit |
| §31-36 Governance / GPT-1000 | **READY(70%)** | Action-registry (12 действий с рисками как в §38.1), Policy Engine, Decision Inbox (API+UI), AiAgent/Authority/Policy/Action/Approval/AuditLog/Budget/Incident, autopilot=off |
| Реалтайм-слой (наши А-Г) | **READY** | Чат :3003 через :81, live-уведомления <2с, события, единый поиск — ALL MET |
| Щиты (§44 No-fake) | **READY** | GATES-леджеры unlazy, adversarial 43/0, юнит 44, lint/tsc — инфраструктура честной приёмки |

**Вывод:** план V2 ложится на наш код как эволюция. Из 26 продуктовых семейств: ~9 READY, ~14 PARTIAL, 1 MISSING (Store). Критическая дифференциация плана (§6+§7 — «кольцо доверия») — самая недоделанная часть и должна стать волной №1.

---

## 2. ДЕТАЛЬНАЯ СВЕРКА КЛЮЧЕВЫХ СЕКЦИЙ

### §6 Sarafan Radio — ядро продукта
Есть: модель `Recommendation` (authorId, subjectId, context, text, skills CSV, projectId, status/revokedAt, unique author+subject+project), API `/api/recommendations`, связь с проектом как evidence.
Нет до целевой формы (§6.1): `relationshipType` (работали вместе/клиент/наставник), `evidenceIds[]`, `scope/visibility`, `expiresAt`, `conflictOfInterest`, полная цепочка provenance.
Нет (§6.4 анти-гейминг): детектор круговых рекомендаций/колец, детектор взаимности «ты мне — я тебе», разнообразие рекомендателей, аномалии, возраст аккаунта как сигнал.

### §7 5 Handshakes — транспорт сарафанного радио
Есть: `src/lib/matchmaker.ts` — BFS по accepted-связям + участникам общих проектов, MAX_DEPTH=5, confidence, AI-шаблон интро; `/api/ai/matchmaker`; UI-упоминания в лендинге и me-view.
Нет: сущность `IntroductionRequest` (requester/introducer/target/purpose/expiresAt) и цикл «запросить → Анна видит → [Представить/Отказать/Уточнить] → контролируемое сообщение» (§7.4); типизированные рёбра с consent/discoverability/provenance/lastVerifiedAt/revocation (§7.1) — модель `Connection` бинарная (pending/accepted); rate-limit и abuse-контроль поиска путей (§38.2 production requirements); кэш путей.

### §31-36 Governance — наша сильная сторона
Есть: `ai-governance/action-registry.ts` — 12 действий, риск-уровни read/low/medium/high/critical, reversible/externalSideEffect, lumenCost, defaultModes (NO_AUTOPILOT для high, manual-only для critical) — практически дословно §38.1 плана. `policy-engine.ts`, `governance-service.ts`, модели AiGoal/AiAgent/AiAuthority/AiPolicy/AiAction/AiApproval/AiAuditLog/AiBudget/AiIncident, `/api/ai/decisions` + UI `decision-inbox.tsx` (Decision Inbox §34), autopilot выключен по умолчанию (BIZON_AUTOPILOT_ENABLED=0, режимы manual/collaborative).
Дотянуть: подпись/версионирование политик (§31.9), 2-of-N авторизации критических действий (§31.8), immutable-audit с внешней проверкой целостности (§31.6), kill-switch как отдельный от AI контур с документацией процедуры (§31.5), memory-security для агентских записей (§31.11).

### §14 Diversity — защита от «проблемы Яндекс.Музыки»
Есть: `IgnoredTopic`, «Не интересно» в каруселях, /api/feed/recommendations/ignore, SavedFilter.
Нет: decay-кривая давности, квоты 75/15/10 (relevance/adjacent/exploration), семантическое расширение через SkillSynonym (модель есть!), капы «max 3 от одной компании/темы».

### §18 Store — единственный MISSING-блок
Нет модели StoreItem, нет /api/store, нет booking. При этом фундамент готов: payment-service, люмены, Subscription, ExpertIntents. Вход через §5.2 «Как со мной работать» на премиум-профиле.

### §22 Project Room
Проект сейчас — карточка + участники + evidence-сервис. До формы плана: табы Overview/Team/Roles/Proof/Milestones/Discussion/Results и клиент-одобряемые поля (problem/context/solution/result/confirmer/visibility/NDA).

---

## 3. ПРОГНОЗ: ВОЛНЫ РЕАЛИЗАЦИИ

Порядок выбран по правилу плана: сначала замыкание сильнейшего контура (§20 «Company Need → … → Evidence» и §46 «финальная петля»), потом монетизация поверх доверия, потом расширение AI-экономии и масштаб. Каждая волна = unlazy-этап со своим `specs/<dir>/GATES.md`, кодом, браузерной E2E и записью в worklog.

### Волна 1 — «Кольцо доверия» (Sarafan Radio × 5 Handshakes). P0 DIFFERENTIATION плана
Цель: замкнуть цепочку §7.6 — поиск → путь → интро → подтверждение контекста → рекомендация с provenance.
1. **Схема (additive, db:push):** расширить `Recommendation` (relationshipType, evidenceIds JSON, scope, expiresAt, conflictOfInterest); расширить `Connection` (type, provenance, discoverable, lastVerifiedAt); новая модель `IntroductionRequest` (requesterId, introducerId, targetId, purpose, message, status pending/accepted/declined/expired, expiresAt).
2. **Сервисы:** `intro-service.ts` (создание/приём/отказ/экспирация; отправка контролируемого сообщения только после accept; ссылки на Conversation из чата); `safan-guard.ts` — анти-гейминг §6.4 (взаимность, кольца через DFS по рекомендациям, массовость, возраст).
3. **API:** POST/GET `/api/intros`, POST `/api/intros/[id]/accept|decline`; rate-limit (переиспользовать rate-limiter), audit через AuditLog.
4. **UI:** карточка «Путь: Вы → Анна → Игорь, запросить знакомство» в профилях/матчмейкере; интро-запросы в колокольчик уведомлений (транспорт Направления Б — мгновенно) + блок в network-view.
5. **AI:** шаблон интро уже есть в matchmaker; зарегистрировать операцию в action-registry (risk: medium, externalSideEffect: true, requiresApproval по режиму).
6. **Щиты:** юнит-тесты анти-гейминга; новые adversarial-пробы (массовые интро, self-intro, интро к самому себе, обход consent); браузерная E2E полного цикла с двумя сессиями (паттерн rt-peer-b).

### Волна 2 — Store MVP (§18). Закрытие единственного MISSING
1. **Схема:** `StoreItem` (ownerId, type services/digital/expert-access, title, description, price, currency, deliveryMode, evidenceRefs, verificationStatus, status) + `StoreBooking` (itemId, buyerId, slot/status).
2. **API:** GET/POST `/api/store`, POST `/api/store/[id]/book`; оплата — через существующие люмены/payment-service (мок-режим), чек → LumenTransaction.
3. **UI:** раздел «Магазин» (NAV_MORE), витрина эксперта «Как со мной работать» на премиум-профиле (§18.3).
4. **Принцип §18.4:** оплата меняет доступ, не доверие — проверки в коде + adversarial-проба «купленная рекомендация не влияет на trust».

### Волна 3 — Diversity Engine + AI-экономика (§14, §16)
1. `diversity-service.ts`: decay-веса по датам событий, квоты 75/15/10 (конфиг), семантическое расширение через SkillSynonym, капы по компании/теме; интеграция в feed/news/jobs подборки.
2. ai-core: реестр операций (operationId, model class, cache policy), semantic cache по source_hash (§16 пример PROFILE_ANALYSIS_v3), таблица метринга (operation, tokens, cost, cacheHit) → AiBudget.
3. Переключение люмен-списаний action-registry ↔ метринг.

### Волна 4 — Project Room + Evidence-цикл (§10, §22.3)
Табы комнаты (Overview/Team/Roles/Proof/Milestones/Discussion/Results), клиент-одобряемые поля, явный статус evidence UNVERIFIED/VERIFIED с подтверждателем; правило плана «COMPLETED ≠ verified» — проверка в UI и API.

### Волна 5 — Opportunity Engine: 12 типов + News→Opportunity (§8, §21.1)
Расширить типы Opportunity (partership/cofounder/mentor/supplier/investor/education…), единый match-pipeline (need→intent→candidates→evidence→relationship→availability→ranking→explanation→next action); новость → топики → навыки → gap → компании/возможности (фундамент news-score/relevance уже есть).

### Волна 6 — Governance hardening (§31) + Scale-prep (§28-29)
2-of-N для critical, подпись политик, immutable-audit c хэш-цепочкой, kill-switch-процедура документированно вне AI-контура; outbox через event-bus для уведомлений/аналитики; публичные индустриальные SEO-страницы (§21.2) на базе p/[token], c/[token], sitemap.

### Не трогаем (WAITING-зоны и принципы)
- Project.rating/ipScore как публичный числовой скор — противоречит §3.3 плана; оставить как внутреннюю метрику, не показывать «Maria trust score 93» (§6.2).
- Тексты GPT-аудита; P2-кандидаты №16 (Virtuoso/NumberFlow/cmdk) — вне приоритетов волн.
- Никаких микросервисов без необходимости (§27): modular monolith, выделение только chat-сервиса как уже сделано.

---

## 4. КАК РЕАЛИЗУЕМ (методология, накопленная в проекте)

1. **Unlazy-протокол на каждую волну:** `specs/<wave>/GATES.md` (гейты: схема/сервис/API/UI/E2E/щиты) → `tools/unlazy/scripts/gate-check.mjs` → ALL MET → запись в worklog (Task ID/Agent/Work Log/Stage Summary) → доклад.
2. **REUSE→EXTEND→REFACTOR→REPLACE (§26):** новые поля — только additive через `bun run db:push`; дубликаты сервисов запрещены (перед каждой задачей — grep по `src/lib/services`, 59 файлов).
3. **API-first с готовыми обёртками:** `with-route`/api-helpers, rate-limiter, `AuditLog.log`, zod-валидация; realtime — только поверх транспорта Направления А/Б (:3003 через :81, XTransformPort), REST остаётся каноном.
4. **AI через governance:** любая новая AI-операция = запись в action-registry (риск/режимы/lumenCost) + запрос через policy-engine; LLM только для смысла/текста/объяснений (§12): поиск/фильтры/ранжирование — детерминированно.
5. **Доказательства, а не слова:** юнит-щит `bun test`, `bunx tsc --noEmit`, `bun run lint`; adversarial-харнесс расширяется на каждую новую поверхность (интро-абьюз, стор-платежи, diversity-отравление); браузерная E2E agent-browser по золотому пути + мобильная вёрстка 390px.
6. **Масштаб-дисциплина (§28):** «architect for 10B, pay for current load» — stable IDs, region/tenant-поля уже в схеме; никаких преждевременных шардов.

## 5. ОЦЕНКА ОБЪЁМА
- Волна 1: крупнейшая (схема+2 сервиса+3 API+UI+E2E+анти-абьюз) — 1 полный цикл.
- Волна 2: средняя (модель+2 API+витрина) — половина цикла.
- Волны 3-6: серии малых этапов по unlazy-протоколу, каждая независимо закрываемая и проверяемая.

## 6. АДДЕНДУМ: PROTOCOL v2 НА КАЖДУЮ ВОЛНУ (18.09.2026, после создания оверлея)
Протокол: `docs/GITHUB-ENGINEERING-PROTOCOL-v2.md`. Оверлей — живой документ (обновляется),
План-v2 (`docs/План-v2.md`) — НЕИЗМЕННЫЙ инвариант архитектора; правкам не подлежит.

Обязательства, добавляемые к каждому этапу любой волны (поверх §4):
1. **Конкурс A/B/C + ADR** (§19) — до крупной реализации: Option A (минимальное) / B (production) / C (scalable), выбор по измеримым свойствам, итог в `docs/adr/`.
2. **14-вопросный Decision Rule** (§4) — для любой новой технологии/зависимости; нет убедительного ответа = не внедряем.
3. **AI-eval бенчмарки** (§12) — до статуса READY: для волны 1 минимум `MATCHMAKER_EVAL` + `SARAFAN_RECOMMENDATION_EVAL` (precision/recall/groundedness/hallucination/latency/cost); инструменты — promptfoo/Langfuse-подход, реализация в tools/evals.
4. **Dependency-чеклист 10 пунктов** (§14) + currentness-политика (§18) — перед каждым новым пакетом.
5. **Формат приёмки §21** — отчёт по волне обязан содержать: BIZON-ID, objective, files changed (file:line), DB/API/UI changes, tests/E2E/security, migration, rollback, known risks; статус только из: READY/PARTIAL/BLOCKED/MISSING/MOCK/DOCUMENTED/DOC-MISMATCH/DEPRECATED/REVIEW.
6. **AI не изобретает данные BizON** (§6) — Recommendation/Connection/Intro содержат только факты из DB/evidence-графа; LLM — только интерпретация/объяснение/шаблон текста (уже так в matchmaker — сохранить).
7. **Security-pipeline** (§15) — на новую поверхность (intro/store): rate-limit, adversarial-пробы, проверка обхода consent; приоритет REUSE→EXTEND (§17) — существующие rate-limiter/AuditLog/action-registry переиспользуем, не дублируем.

Порядок старта Wave 1 (уточнённый): изучение референсов (§1: graph-репо — graphology/networkx; §2 deep-read) → 14 вопросов по IntroductionRequest → конкурс A/B/C → ADR → схема → сервисы → API → UI → щиты + eval → §21-отчёт → worklog.

## 7. ВОССТАНОВЛЕНО ИЗ ПЕРВОГО ТЗ (сверка V6-документа 08.09 с Планом-v2 и кодом, 18.09.2026)
Источник: `docs/V6-IMPLEMENTATION-STATUS-AND-ROADMAP.md` (свод 3 PDF: масштабирование/26 доменов/гибридный AI + UX-спека).
Подтверждено grep'ом кода и Плана-v2: перечисленное ниже отсутствует И в коде, И в волнах 1-6 — при прямом следовании Плану-v2 было бы утеряно.

| № | Из первого ТЗ | Статус | Куда возвращаем |
|---|---|---|---|
| 1 | Proof Granularity: Role→Responsibility→Action→Result (глубина доказательства) | ❌ код/план | **Wave 4** (Project Room/Proof-таб) — вместе со статусом UNVERIFIED/VERIFIED |
| 2 | Company Persona (голос компании-автора) + Company Memory (какие компетенции накопила) | ❌ код/план | **Wave 4** (Evidence-цикл) + Wave 6 (SEO-страницы) |
| 3 | Платёжный шлюз реальных денег (ЮKassa/CloudPayments: checkout, вебхуки, CPM) | ❌ код/план (Store Wave 2 = люмены-мок) | **Wave 2**: явно зафиксировать этап «мок → реальный шлюз» отдельным гейтом до приёма денег |
| 4 | AuthorChip + уровневые цвета аватаров (Lighthouse золотой / Authority бирюзовый / Established синий / Builder серый / Newcomer нейтральный) | ❌ код/план (только CSS-комментарий «Lighthouse accent: TEAL») | **Wave 1 UI** — маленькая быстрая победа (S), усиливает визуальную идентичность доверия |
| 5 | W3C Verifiable Credentials — экспорт Claim/Evidence в VC-формат (портативность правды) | ❌ код/план | **Wave 6** (после VERIFIED-evidence в Wave 4) — стратегический актив паспорта |
| 6 | Web-push (VAPID) — 4-й канал (in-app/SSE/email есть, push нет) | ❌ код/план | **Wave 6** (каналы доставки) |
| 7 | Cron-гипотезы «Помогите нам понять вас лучше»: ActionEvent за 30 дней → гипотезы, лимит 3/сутки, скрытие 7 дней после 2 закрытий | 🟡 каркас confirm/dismiss есть (`bizon-coach-card`, PATCH insights), генератора нет | **Wave 3** (Diversity+AI-экономика) — поверх реестра операций |
| 8 | Opportunity Graph как навигация: PERSON→SKILL→PROOF→OPPORTUNITY→RESULT | 🟡 causality-service есть, граф-навигация нет | **Wave 5** — дополнить match-pipeline переходом по цепочке |
| 9 | Инфраструктура: PostgreSQL/Redis queue+cache/Scaling Controller/Predictive Autoscaling | 🟡 в План-v2 §24.11 PLATFORM + Wave 6 scale-prep | Считать перенесённым (принцип PDF-1: «архитектурная совместимость с будущим, строить по мере роста») |
| 10 | Load/chaos tests (k6), CDN/WAF/DDoS | ❌ вне песочницы | P3 — при выходе за песочницу (протокол §15 security-pipeline покрывает статическую часть) |

Осознанно НЕ возвращаем (первое ТЗ само запретило в PDF-2 §65, План-v2 согласен): DAO/токены, XP/streak/leaderboard, геймификация, большой AI-чат, React Native, «граф ради графа». Календарь Google/Outlook + AI-Time-Manager — P3 (не блокер доверия, вернём после Store/Project Room).

## 8. НАЛОЖЕНИЕ ИСХОДНОГО ТЗ BZN-TS-10.0-2025 (глава 1-91, 16.4k строк; сверка 18.09.2026)
Источник: `upload/Pasted Content_1789754209914.txt` — оригинальная идея (Trust Graph/IP-Score/tTRUST/NFT/Digital Twin/91 глава). ~70% глав уже покрыто кодом или Планом-v2 (Truth-ядро, Trust Stream, Matchmaker BFS≤5, Career Agent, Team Builder, Governance, Sovereignty). Ниже — досконально проработанные места, которые НАКЛАДЫВАЕМ на реализацию.

| Из ТЗ-10.0 | Что конкретно | Проверка кода | Куда накладываем |
|---|---|---|---|
| §45 Trust Graph | Экспоненциальное затухание веса связи `W=W0·exp(−λΔt)`, λ=0.05/мес + восстановление до максимума при новом взаимодействии | decay есть для навыков/рекомендаций, для Connection — нет (связь бинарная) | **Wave 1**: математика веса типизированного ребра (lastVerifiedAt + decay + re-strengthening) |
| §45.8 | Анти-гейминг: детектор trust ring → маркировка fraud_suspect; лимит 10 подтверждений/сутки; fraud_detected −вес | anti-fraud.ts есть; кольца по рекомендациям — нет | **Wave 1** `sarafan-guard` (совпадает с §6.4 Плана-v2) — берём пороги и маркировку |
| §45.6 | Событие intro_success (+вес доверия, контекстно) | события event-bus есть, интро появится в Wave 1 | **Wave 1**: интро успешное → ReputationEvent (без публичных чисел) |
| §71 Opportunity Radar | Прогноз возможностей 3/7/30/90 дней; RMI=(Δактивность/Δt)×TrustDensity; метрики Precision@Top3≥0.85, Lead Time≥5 дней; ограничение: только верифицированные сигналы | skill-futures/talent-forecast — эвристики без Lead Time | **Wave 5**: проактивный слой поверх 12 типов; метрики Radar = готовые eval-пороги для protocol §12 |
| §81 Career Risk Matrix | Вероятности: выгорание, потеря квалификации, угроза автоматизации, конкуренция рынка; предупреждение «через 8 мес навык устареет» | burnout/риск-матрица — нет | **Wave 3**: расширение career-scenario/skill-futures |
| §82 Team Builder | 5 Fit-измерений (Skill/Trust/Culture/Cognitive/Tempo) + Leadership Emergence Score (5 типов лидеров) | team-builder-service есть, Fit-глубины нет | **P2** после Wave 4 — только с явным консентом на поведенческие сигналы (Data Guard) |
| §84 MAOK | Уровни автономии L0–L3; explainable reasoning (причины+метаданные+вероятности+fallback); trust-rank самого агента | governance: manual/collaborative (L0/L1), action-registry с рисками — каркас есть | **Wave 6**: L2/L3 как расширение governance (только через явное согласие), формат объяснений решений |
| §85.11 AEE | Initiative Level 0–100 (слайдер пользователя вместо 2 режимов); Ego Boundary Protector — отклонение манипулятивных предложений с объяснением | /api/me/autonomy есть (2 режима) | **Wave 6**: IL как градуировка autonomyLevel; EBP-правила в policy-engine |
| §85.12 DIL | Decision Integrity Layer: пре-чек каждого решения (репутационный риск, COI, ценности) → блок или ручной режим | policy-engine делает риск-чек; COI-поле появится в Wave 1 | **Wave 1+6**: переиспользовать как обоснование архитектуры policy-engine; COI-чек рекомендаций |
| §88 EMDL | Неизменяемый журнал решений с хэш-цепью (blockchain-light), подпись пользователя+агента, хранение rejected_variants (альтернативы), запреты пользователя («никогда не делай X»), Audit Mode | AuditLog есть; hash-chain, альтернативы, запреты — нет | **Wave 6**: immutable-audit (совпадает с План-v2 §31.6) + user-prohibitions в policy-engine |
| §89 PEE | Пре-прогноз этических/юридических рисков ДО действия: NDA/non-compete, конфликт интересов, вторичные эффекты | нет | **P3**: чек-листы в переговорных агентах/Store-сделках; COI-поле Wave 1 — первый шаг |
| §90 HOP | 4 режима (Manual/Assisted/Delegated/Emergency); **защита от «ползучей автономии»**: любое расширение = явное согласие + срок + периметр; Kill-Switch Controller (остановка+изоляция+запись инцидента); Intent Verifier (команда не результат манипуляции) | kill-switch-процедуры нет, emergency нет | **Wave 6**: прямо совпадает с План-v2 §31.5 kill-switch и протоколом §10 «агент не расширяет права сам» — берём формулировки режимов и anti-creeping-правило |
| §3 KPI | Культура метрик: XAI 100% объяснимость, Precision/Recall цели у каждого модуля | eval-бенчмарков нет | **Все волны**: цели §71.8/§45.9 образцы для eval-таблиц протокола v2 §12 |

НЕ переносим из ТЗ-10.0 (конфликт с зафиксированными позже принципами — PDF-2 §65, План-v2 §3.3/§6.2, протокол v2 §14): tTRUST-токеномика/DAO/NFT-экспорт/on-chain (главы 7,13,20,29,36,49,59,64,77,78) — монетизация остаётся подписки+люмены+реклама; публичный IP-Score 0–1000 и уровни L1–L5 с привилегиями — контекст вместо цифр, ipScore только внутренний сигнал ранжирования; Career Score 0–200 как допуск к «премиальным вакансиям» — только внутренний; психоархитектура Digital Twin (PMX/CSE/ISL, Emotion Recognition из переписки) — PII-риск против Data Guard; React Native (глава 22) — запрещено аудитом.

### 8.1. ML-СТЕК ТЗ-10.0 — ПРИНЯТО К ВНЕДРЕНИЮ (решение владельца 18.09.2026: «GNN/LSTM/Career BERT — настаиваю внедрить»)
Исключён из списка «НЕ переносим» по решению владельца продукта. Целевой стек ТЗ-10.0 (TensorFlow/PyTorch/Neo4j) НЕ форкает наш стек: внедряем модельно-агностично через интерфейсы (REUSE→EXTEND→REPLACE), эвристика v0 → ML v1+, обучение — по мере накопления данных (принцип PDF-1 «стрелим по мере роста»). GNN-главы-источники: §34–35 (DIL/UTG), §71 (Radar), §78 (анти-фрауд), §81.5 (Career ML), §82.9 (Talent Graph).

| Модель ТЗ-10.0 | Что даёт | Куда накладываем | Гейт |
|---|---|---|---|
| GNN Trust Propagation / Trust Forecast (§34, §35.4, §78) | передача доверия по графу, прогноз динамики рёбер, «точки схождения» — будущие коллаборации | **Wave 1**: интерфейс `TrustPropagationModel` поверх matchmaker BFS≤5; v0=BFS-эвристика, v1=graphology-эмбеддинги, v2=обученный GNN | ADR-trust-graph-ml + eval до READY |
| GNN анти-фрауд + LSTM+Isolation Forest (§78) | детект trust ring/соц-ферм по форме графа, маркировка рёбер «infected» | **Wave 1** `sarafan-guard` v1 (правила) → **Wave 3** v2 (аномалии) | eval: precision анти-фрауда, FPR ≤ 2% |
| LSTM / Prophet (§33.2, §71, §81.5 Market Trend LSTM) | тренды профессий, сезонность, прогноз всплесков активности, карьерные траектории UC-601 | **Wave 3**: skill-futures/career-scenario v1 — данные уже копит ActionEvent/ReputationEvent | eval: Lead Time ≥ 5 дней (§71.8) |
| Reputation Estimator (LSTM+GAT, §35.4) | прогноз репутации по динамике графа | **Wave 3** поверх истории ReputationEvent | после ≥ 90 дней данных |
| Career BERT / NLP Engine (§33.2, §41.2, §81.5) | семантический матчинг резюме↔вакансии↔проекты | **Wave 5** match-pipeline: v1=готовые sentence-embeddings (инференс ONNX/transformers.js, без своего обучения) → v2=дообучение на наших данных | eval: Precision@Top3 ≥ 0.85 (§71.8) |
| Role2Vec / Income Prediction NN / Social Capital Model (§81.5) | прогноз дохода, соц-капитал | **Wave 5+** — только после реальных сделок Store/Project Room (иначе нечем учить) | данные ≥ 6 мес |
| Team Performance Predictor (GNN подграфов, §35.4/§82) | прогноз эффективности команды | **P2 после Wave 4** — вместе с Fit-глубинами Team Builder (§8), только с консентом | Data Guard |

Правила внедрения (обязательные): (1) Wave 1 фиксирует модель-агностичные интерфейсы `TrustPropagationModel`/`AnomalyDetector`/`TrendForecastModel` — эвристика v0 и ML v1+ реализуют один интерфейс, замена без переписывания сервисов; (2) лог обучающих данных (фичевый пайплайн) закладываем СРАЗУ в Wave 1 — без него в Wave 3+ нечем обучать, это часть «щитов+eval» §6; (3) каждый переход эвристика→ML = отдельный ADR + AI-eval, ML не меняет READY-статус, пока eval не сравнил его с эвристикой на одинаковых данных; (4) XAI 100% — каждое ML-решение выдаёт объяснение через evidence (принцип §3 ТЗ-10.0 совпадает с План-v2); (5) инференс малых моделей — внутри нашего стека (ONNX/transformers.js/wasm), PyTorch/Neo4j/GPU-обучение — вне песочницы, P3 в scale-prep (§24.11).

### 8.2. АНТИ-ФРОД-МАТРИЦА — 6 УСИЛИТЕЛЕЙ (решение владельца 18.09.2026, trace 1a0b5c895b87cb51: «да, добавить»)
Контекст: базовый контур уже в проде — `src/lib/security/anti-fraud.ts` (SEC-1, Suspicion Score 0–100: RECIPROCAL+40, IP_SHARED/DEVICE_SHARED+30, CONFIRM_SPEED+25, NO_REPUTATION+25, NIGHT_HOUR+20, авто-заморозка ≥70) + конструкция без публичных чисел (IP-Score скрыт, XP/лидербордов нет) + decay рёбер. Ниже — 6 усилителей против организованных схем (фермы, боты, казино-скам), которых в плане не было. Decision Rule: вопрос 1 решён владельцем; совместимость с REUSE/Data Guard/монетизацией — усилители не создают новых данных о пользователе сверх существующих сигналов (кроме тиров верификации — явный консент). Целевая метрика контура: cost of attack >> return, FPR ≤ 2%.

| # | Усилитель | Что даёт | Куда накладываем | Гейт |
|---|---|---|---|---|
| 1 | Тиры верификации phone/email | дешёвый фильтр масс-регистрации; неверифицированный аккаунт = урезанные лимиты (не «второй сорт», а тир доверия) | **Wave 1** (регистрация/онбординг): `verificationTier` в профиле; связка с NO_REPUTATION-весом | консент-флоу, Data Guard |
| 2 | Device fingerprint + honeypot-поля | кластеризация ферм по железу/поведению формы; ловушка для ботов на регистрации | **Wave 1**: расширение DEVICE_SHARED (анти-фрод видит fingerprint-кластеры, не сырые отпечатки) | fingerprint — только хэш, PII не храним |
| 3 | Velocity-чеки на ВСЕ действия | CONFIRM_SPEED-эвристика обобщается: лимиты/скоринг на посты, интро, заявки, сделки | **Wave 1** (каркас в with-route) → **Wave 2** (сделки Store) | eval: FPR ≤ 2% на легитимных пользователях |
| 4 | Кросс-аккаунтная текстовая синхронность | фермы копипастят одинаковые тексты — ловится эмбеддингами; переиспользует инфраструктуру Career BERT (§8.1) | **Wave 3** (с появлением embedding-слоя) | ADR + eval precision анти-фрауда |
| 5 | KYC для высоких ставок | айдентити-проверка при крупных сделках Store / Enterprise-онбординге; против «доверия, купленного у фермы» | **Wave 2** (гейт реального шлюза: KYC до приёма денег сверх порога) + **Wave 6** (Enterprise) | юридическая валидация до запуска (§19.5-подход) |
| 6 | Red team каждую волну | adversarial-сценарии для нового контура каждой волны (не только разовая проверка) | **Все волны**: расширение протокола v2 §15 security-pipeline — каждая волна сдаёт свои 10+ adversarial-кейсов | формат приёмки §21: BLOCKED-счётчик только растёт |

Правила: (a) усилители 1–3 — Wave 1 как часть «щитов» (§6 аддендум, п.7); (b) все детекторы работают как наблюдение → скоринг → заморозка с апелляцией, FAIL-OPEN для легитимных действий (принцип SEC-1 сохраняется); (c) GNN-эскалация W3 (§8.1) строит фичи поверх логов усилителей 1–4 — данные копим с первого дня; (d) честная граница: 100% защиты не существует ни у кого, критерий успеха — экономика атаки дороже отдачи + FPR ≤ 2% + 0 exploited в adversarial-наборе.

## 9. МОДУЛЬНЫЕ ТЗ ВЛАДЕЛЬЦА — ПОЛНЫЙ КОМПЛЕКТ 4.2/4.3/4.4/4.6/4.7/4.8/4.9 — НАЛОЖЕНИЕ НА ПЛАН-V2 (сверка 18.09.2026, trace 1a0b5c89…серия; довнесение 4.3/4.7/4.9 — 18.09.2026, trace 1a0b5d764305bd25)
Источник: `upload/ТЗ_{Новости,Поиск_работы,Контакты,Сообщества,Мероприятия,Визитка}_для_z.ai.pdf` + `upload/ТЗ_Модуль_Проекты.pdf` (ТЗ-ПР-4.9-2026, формат старого образца — без реестра API) — **7 исполнительных контрактов**: 115 экранов (Новости 35+, Контакты 9, Сообщества 19, Визитка 4, Мероприятия 10, Поиск работы 20, Проекты 18), 39 модалок, 65 API-контрактов (в шести ТЗ нового формата), ER-модели, Given/When/Then-сценарии, AC-чек-листы, протокол Specify→Plan→Tasks→Implement. Макеты именуют платформу «VINGS» с токенами #69B9C7/Roboto+Inter. Протокол ТЗ (границы 3 уровней, no-fake-completion, LLM-как-судья, STATUS.md) — родственен нашему v2: принимаем как детализацию для модульных работ; наш §21-формат шире (eval/бенчмарки). По протоколу REUSE→EXTEND: берём модель данных, API-контракты, сценарии, AC; дизайн-токены ТЗ мапим на нашу тему (новые цвета/шрифты не вводим); имя «VINGS» и «рейтинг VINGS» не переносим (публичных чисел нет — принцип §3.3 Плана-v2; сортировки «по рейтингу» = внутренний сигнал).

| Модуль ТЗ | Куда в План-v2 | Статус кода vs ТЗ | Что берём для реализации |
|---|---|---|---|
| **4.8 Контакты** | **Wave 1** — Sarafan Radio × 5 Handshakes (§6) | Connection есть (pending/accepted, note), но нет: kind-тегов срезов, CONTACT_RECO (reason-словарь + score), relationship-режима UI, дней рождения, QR-визитки на связи | kind (friend/colleague/partner/former/common) на Connection; CONTACT_RECO: причина из словаря (worked_together/work_together/recommendation/common_hobby) + score — это наш XAI «почему рекомендую» и provenance связей (§3.16); два режима страницы профиля (contact/stranger) по relationship с бэкенда; примечания (изоляция автора); дни рождения в календарь |
| **4.4 Визитка** | **Wave 1–2** (быстрая победа S) + предтеча VC-экспорта (§7 → Wave 6) | `BIZCARD` нет; но `/p/[token]` (публичная страница) уже есть — мы концептуально впереди, ТЗ добавляет продукт-обвязку | BIZCARD-модель (1:1 на пользователя, qr_includes-чекбоксы, public_slug); QR server-side генерация; PDF-экспорт A6; карточный компонент единый (в карточке/попапе/полноэкранном); «Обо мне» с прогрессом заполнения; share = общий компонент с 4.8 |
| **4.2 Новости** | **Wave 3** — News Bridge + Bizon Recommends (§21); Premium-поверхности → Wave 2 | `/api/news/sources` (PARTIAL), Post/PostComment/SavedPost есть; нет: 5 типов POST c JSONB details, POLL+POLL_VOTE, SUBSCRIPTION (9 source_type), TERM-справочник, жалоб 7 категорий, лимита 300/вложенности/is_blocked у комментариев | Единый POST (type news/article/poll/project/event + JSONB details); SUBSCRIPTION source_type (9 категорий) — персональная лента; TERM-словарь (topic/industry/event_format/event_type) с usage_count; COMPLAINT 7 категорий — единый компонент модерации для ВСЕХ модулей (→ щит Wave 1); комментарии ≤300 + 1 уровень + is_blocked; опросы 2–10 вариантов/1–10 дней; ленивые порции по 20; 4 системных состояния списков |
| **4.7 Мероприятия** | **Wave 3** — вместе с Новости 4.2: EVENT прямо «совместим с POST type=event», общий TERM (event_format 296 / event_type 6 / topic 50+), общие компоненты создания; Premium-таргетинг → Wave 2-поверхности | `Event`+`EventParticipant` есть (going/interested/not_going, maxParticipants, trustScore внутренний — ТЗ этого не имеет) ≈30% ТЗ: нет спикеров, цены, lifecycle-отмены, регистрации по ссылке, напоминаний, избранного/просмотров | Разделение «тип доступа ≠ цена» (participation free/paid + price); registration_url — двойной контур участия (внешняя регистрация организатора + внутренний календарь); SPEAKER (упорядоченный, external_id, photo); status draft/published/cancelled + бейдж «ОТМЕНЕНО» + уведомление участников; reminder_at = starts_at−5 мин (API-12); FAVORITE_EVENT + EVENT_VIEW (недавние); расширенный поиск 5 полей + фильтры со сводкой чипов; таргетинг JSONB (10 фильтров — сохраняем, применение = W2); out-of-scope ТЗ (трансляции/билеты у организатора) совпадает с нашим гейтом денег W2 |
| **4.6 Сообщества** | **Wave 3–4** (Diversity/Project-экосистема); moderation-слой → Wave 1 щит | Community/CommunityMember/CommunityPost есть (visibility public/private/secret, minIpScore — даже сильнее ТЗ); нет: ролевой матрицы (member/editor/admin/blocked), posting-прав (disabled/enabled/restricted/author), BAN_WORD+422 post_filtered, greeting, members_visibility, 2-этапного lifecycle, INVITE | Роли-чипы + матрица прав публикации (enforce клиент+сервер); фильтр слов BAN_WORD → 422 post_filtered со списком (усиливает анти-фрод §8.2); авто-приветствие; видимость списка подписчиков; 2-этапное удаление (деактивация на срок → подтверждение); invites c 409; COMMUNITY_POST = POST + community_id + moderation_state (не дублируем контент-ядро); «Монетизация/Реклама» скрыты до Wave 2 (совпадает с Q-06 ТЗ) |
| **4.9 Проекты** | **Wave 4** — Project Room: витрина проектов, участники, заявки, отзывы; «Биржа проектов» (LOT с бюджетом/сроками) = каталог заказов без эквайринга → предтеча Store-сделок (деньги только через гейт шлюза W2/W6); is_premium авторотация → W2 Premium | `Project` (status recruiting/active/completed/cancelled) + `ProjectMember` + `ProjectConfirmation` есть; ⚠ `Project.rating Float 0..5` — публичное число, противоречит §3.3; ≈25–30% ТЗ: нет лот-биржи, заявок, отзывов, галереи | PROJECT-витрина (gallery ≤20 фото/видео, promo_annotation 150, visibility public/private, is_premium); «Над проектом работали» — участники с ролями в карточке; заявки на участие (сопроводительное письмо, счётчик непрочитанных, принять → участник); отзывы + форма комментария; LOT: budget (nullable «по договоренности»), duration, accept_until, work_format remote/onsite, details.blocks[9] (обязательны what_to_do/essence/requirements), отклики; **rating → внутренний сигнал сортировки, публично = верифицированные отзывы/evidence** (паттерн «контекст вместо цифр»); удаление = 30-дневный период восстановления |
| **4.3 Поиск работы** | **Wave 5** — Opportunity Engine (тип job в 12 типах); SEARCH_PREF/автопоиск = проактивный слой Radar (§8.1 W5); «Совместимость +N%» ТЗ сознательно вынес из модуля — это ровно наш match-pipeline (Career BERT, Precision@Top3 ≥ 0.85, §8.1) | `Job` (CSV-скиллы, salaryFrom/To, growthScore/matchConfidence — внутренние сигналы, которых в ТЗ нет) + `JobApplication` + `Resume` (JSON-секции, aiGenerated, CareerCompass) ≈30–35% ТЗ | VACANCY (employment_type 6 / schedule 6 / part_time 5, flags JSONB {disability, age14, age16, students, pensioners, verified, agency}, salary nullable «по собеседованию», status draft/active/paused/closed); RESUME-конструктор блоками (about ≤5000, EXPERIENCE kind job/education c start_ym/end_ym, QUALIFICATION qualification/award, SKILL ≤5 главных is_primary); RESPONSE (vacancy_id nullable + company_id = CTA «направить резюме», статусы new/viewed/invited/declined, portfolio_media/link/message); SEARCH_PREF (seeker/employer, query/skills/regions/filters, is_active — автопоиск = персональная лента); VIEW_LOG (календарь просмотров по датам); фильтры 10 секций с фактическими агрегациями-счётчиками (API-01); «Проверенный работодатель» = признак из тиров верификации §8.2-1 (модерация вне модуля — совпадает); мессенджер вне модуля — переход в наш Messages |

Оценка разрыва (честно, по всем 7 ТЗ): по доверительному ядру (anti-fraud SEC-1, decay, Proof/Evidence, 43 adversarial → 0, eval) наша реализация СИЛЬНЕЕ ТЗ — ТЗ-модули этого слоя не имеют вовсе; по ML-сигналам тоже сильнее (trustScore на Event, growthScore/matchConfidence на Job, aiGenerated-резюме + CareerCompass — ТЗ этого не имеет, а «Совместимость %» прямо вынесено за границы модуля). По продуктовым поверхностям код ≈ 25–35% от ТЗ-полноты (каркасы Event/Job/Resume/Project/Opportunity есть, операционной глубины — lifecycle, справочники TERM, фильтры со счётчиками, коллекции, статусы откликов, лот-биржа — нет): статус PARTIAL, не «хуже», а недописано; ТЗ закрывают ровно эту разницу как готовые спецификации к EXTEND. Открытые вопросы Q-xx ТЗ закрываются в ADR модуля; блокирующие для нас сняты: «рейтинг VINGS» и rating LOT/Project → внутренний сигнал (нет публичных чисел), «Скрыть рекомендацию» → dismissed_at (паттерн совпадает с CoachQuestion), модерация вакансий → тиры верификации §8.2-1, биллинг/билеты → гейт W2.

Порядок работ добавки (в дополнение к §6-порядку Wave 1): AuthorChip → визитка-BIZCARD (QR+PDF) → kind+reason на Connection → жалобы 7 категорий + комментарии ≤300 (щиты) → [Wave 2] Premium-поверхности (таргетинг мероприятий, is_premium-авторотация, KYC-гейт лотов с бюджетом) → [Wave 3] POST 5 типов + SUBSCRIPTION + TERM + Мероприятия (цена/спикеры/lifecycle/поиск) → [Wave 3–4] роли/фильтр слов/lifecycle сообществ → [Wave 4] Проекты-витрина (галерея/участники с ролями/заявки/отзывы) + LOT-биржа (9 блоков, accept_until) → [Wave 5] Поиск работы (VACANCY flags / RESUME-блоки / RESPONSE / SEARCH_PREF / VIEW_LOG / агрегации-счётчики) — таймлайн-сущности стыкуются с Radar/Автопоиском §8.1.

## 10. РЕЖИМ ИСПОЛНЕНИЯ ПЛАНА-V2 (18.09.2026, требование владельца, trace 1a0b5eb17a58d8d9)
- **Свод всех правил** для ручного и автоматического исполнения: `docs/PROJECT-RULES.md` — обязателен к прочтению в начале каждой сессии; объединяет GITHUB-ENGINEERING-PROTOCOL-v2 (§1–21), правила кода среды, Data Guard, приёмку §21, иерархию документов.
- **Счётчик шагов** (требование владельца «шаг X из Y»): `docs/PLAN-V2-STEPS.md` — сквозная нумерация S-001…S-155, статусы PENDING/IN_PROGRESS/DONE/BLOCKED/SKIPPED; Wave 1 детализирована (28 шагов, 7 фаз), волны 2–6 — скелет (~127 шагов, детализируются при старте волны). Формат каждого отчёта: «Шаг S-xxx из ~155 · Волна N · Фаза M · прогресс XX%».
- **Авто-режим**: триггер «Возобнови работу согласно План-v2 в автоматическом режиме»; шаги идут подряд без остановок; чек-пойнты владельца обязательны только на: конец волны (§21-отчёт), переход эвристика→ML, приём денег (W2), KYC, расширение прав агента; нерешённые 14-вопросы → decision queue (шаг BLOCKED-DECISION, идут независимые, решения пакетом).
