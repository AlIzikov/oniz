# BizON v6 — Статус реализации и дорожная карта (аудит по 3 PDF + UX-спеке)

**Дата:** 2026-02 (аудит в песочнице v6, после слияния Tasks 1–10-e)
**Источники:**
1. `upload/у меня вопррос какт в версии 6 заложитьосновы маштабирования… .pdf` (40 стр) — масштабирование, DATA/COMPUTE separation, РФ Data Plane, суверенитет, Phase 0 (42 пункта), стратегия V5.1→V6.x (этапы 1–14).
2. `upload/а.pdf` (41 стр) — аудит v5.0.1: реализовано/не реализовано, оценки 8.5/10…4.5/10, P0/P1/P2, Phase 13 Intelligence Integration.
3. `upload/У меня вопрос дальше по реолизации я саздаю аи агентов… .pdf` (41 стр) — ИИ vs фильтры, LLM-фасад (3 слоя), 5 стратегий экономии, epsilon-greedy/Decay/Exploration/Interleaving, «Помогите нам понять вас лучше» (ТЗ с cron/AJAX).
4. Сообщение пользователя — детальная UX-спека v6 (5 блоков главного экрана, Public/Private split, Trust Stream, AuthorChip, напоминания и т.д.).

**Базовое состояние кода:** 207 API-роутов (`src/app/api/**/route.ts`), 44 сервиса (`src/lib/services/`), 72 модели (`prisma/schema.prisma`), приложение на SQLite (`provider = "sqlite"`, `.env: DATABASE_URL=file:…/db/custom.db`).

---

## 1. Методика

- Каждый вердикт проверен поиском по исходникам: `rg`/`ls` по `src/`, `prisma/schema.prisma`, `scripts/`, `deploy/`, `.github/` — ключевые слова фичи (компоненты, сервисы, роуты, модели).
- Отправная точка — worklog.md (Tasks 1–10): в v6-песочницу слита схема v5 (72 модели), реконструированы event-bus/compute-router/ai-core-gateway (Task 10-c), 4 UI-компонента (10-d), seed/скрипты + Docker/CI/Helm (10-e).
- PDF-суждения о v5 сверены с текущим v6-кодом: часть «отсутствий» из PDF-2 уже закрыта реконструкцией, часть багов v5 мигрировала в v6 (например, AdPressure `24*60*1000`).
- Тезисы PDF, которые не проверяются кодом (уровни 0–5, Multi-Cluster, прогнозные ступени Stage A–H), помечены как «концепция» и отнесены к roadmap.

Примеры проверочных запросов (воспроизводимость аудита):

```bash
rg -il "claim|proof|evidence|truth" src/                 # Professional Truth
rg -n "24 \* 60 \* 1000" src/                            # баг AdPressure (4 совпадения)
rg -l "@ts-nocheck" src/                                 # 3 файла (proof/skill-graph/opportunity)
rg -n "epsilon|exploration|interleav" src/lib/           # разнообразие PDF-3 (не найдено)
rg -n "citizenship|consentAiAnalysis" prisma/schema.prisma
rg -n "provider" prisma/schema.prisma                    # sqlite vs postgresql
find src -name "*.test.ts" -o -name "*.spec.ts"          # тесты (0 файлов)
ls deploy/ deploy/helm/templates/ .github/workflows/     # инфраструктура
```

Легенда: ✅ реализовано · 🟡 частично · ❌ отсутствует.

---

## 2. Сводная таблица по доменам (PDF-2 «a.pdf»)

| Домен | Статус в v6 | Доказательство | Что осталось |
|---|---|---|---|
| Professional Truth (Claim/Proof/Evidence) | ✅ | `src/app/api/claims/[id]/verify/route.ts`, `src/lib/skills/proof-service.ts`, `src/lib/security/anti-fraud.ts` (rate limit, self-confirm запрещён), компоненты `src/components/truth/*` | Снять `@ts-nocheck` с `proof-service.ts`; Proof Granularity (Role→Responsibility→Action→Result) |
| Truth Profile + Truth Gap | ✅ | `src/components/truth/truth-profile.tsx`, `src/app/api/skills/[id]/self-assessment/route.ts` (`truthGap = verifiedScore − selfAssessment`) | — |
| Skill Graph + Decay + Resurrection | ✅ | `src/lib/services/skill-graph-service.ts`, `src/lib/skills/level-formula.ts` (decay, diversityScore), `src/app/api/me/skills/graph/route.ts`, `…/[skillId]/resurrect/route.ts`, `skill-graph-view.tsx` | Снять `@ts-nocheck`; нормализовать CSV-навыки (PDF-2 §45) |
| Mentor Graph | ✅ | `src/lib/services/mentor-service.ts`, `src/app/api/mentors/`, `src/app/api/mentorships/` | effectiveness/рост учеников — сверить формулы с PDF-2 §8 |
| Professional Intent | ✅ | `src/lib/services/intent-service.ts`, `src/app/api/me/intent/` | — |
| Opportunity Engine | ✅ | `src/lib/services/opportunity-service.ts` (relevance/trust/freshness/explain), `src/app/api/opportunities/` | Снять `@ts-nocheck`; Opportunity Graph (цепочка PERSON→…→NEXT) — P1 |
| Bizon Discover | ✅ | `src/components/me/bizon-discover.tsx`, `src/app/api/me/discover/` | — |
| Hiring Reality | ✅ | `src/lib/services/hiring-reality-service.ts`, `src/components/jobs/hiring-reality-badge.tsx` | — |
| Job Passport | ✅ | `src/app/api/jobs/[id]/job-passport/route.ts`, `src/components/jobs/job-passport.tsx` | — |
| Time Value | ✅ | `src/lib/services/time-value-service.ts`, `src/app/api/jobs/[id]/time-value/route.ts` | — |
| Career Discovery | ✅ | `src/app/api/me/career-discovery/route.ts` | — |
| Professional Passport | ✅ | `src/app/p/[token]/page.tsx` (QR, без PII, level вместо числа), `src/lib/services/passport-service.ts`, `profession-template-service.ts` (6 шаблонов профессий) | — |
| Company Trust / Claim / Stream | ✅ | `src/lib/services/company-claim-service.ts`, `company-trust-service.ts`, `src/app/api/companies/[id]/stream/route.ts` (news/project/job/review/achievement) | Company Intelligence (компетенции/дефицит) — P1 |
| Bizon Signal | ✅ | `src/lib/services/bizon-signal-service.ts`, `src/components/me/bizon-signal-card.tsx`, `src/app/api/me/signals/` | Объединение Signal+News+Salaries → Market Intelligence (P1) |
| News Relevance | ✅ | `src/lib/services/news-relevance-service.ts`, `src/app/api/news/` | Company News Bridge: `scripts/cron-fetch-news.js` всё ещё фиксированные RSS (vc.ru/habr/rb.ru), `Company.newsSources` (schema:151,589) читается только в company stream — нужна синхронизация RSS компаний (P1) |
| Blind Spots | ✅ | `src/lib/services/blind-spots-service.ts`, `src/app/api/me/blind-spots/` | Перевести эвристику ключевых слов в AI-inference (P2) |
| Next Best Action | ✅ | `src/lib/services/next-best-action-service.ts`, `src/app/api/me/next-best-action/`, `next-best-action-card.tsx` | — |
| Career Scenario | ✅ | `src/lib/services/career-scenario-service.ts`, `src/app/api/me/career-scenario/` | Заменить эвристику «длина названия навыка» на Skill Futures + Learning Difficulty (P1) |
| Professional Capital | ✅ | `src/lib/services/capital-service.ts` (8 компонентов, веса 0.20…0.05), `src/components/me/capital-dashboard.tsx`, `scripts/cron-capital.js` | Снапшоты для тренда (сейчас только текущий расчёт) |
| Professional Memory | ✅ | `src/lib/services/memory-service.ts`, `src/components/me/professional-memory.tsx` (нарратив v N + таймлайн версий), `scripts/cron-memory.js` | Company Memory — отсутствует (P1) |
| Who Viewed | ✅ | `src/app/api/me/profile-views/route.ts`, модель `ProfileView` (schema, Task 10-b) | — |
| Professional Status | 🟡 | `src/lib/services/trust-state-service.ts`, `src/app/api/me/trust-state/` | Явный статус «Открыт к предложениям» на главном экране — нет |
| While You Were Away | ✅ | `src/app/api/me/whats-new/route.ts` (Phase 3: счётчики с прошлого визита), `src/components/me/whats-new-tab.tsx` | — |
| Monetization (PaymentService) | 🟡 | `src/lib/services/payment-service.ts` (тарифы Free/Pro/Business 0/499/1499 ₽), `src/app/api/subscription/`, `src/app/api/ads/`, AdPressure/SponsoredOpportunity | **Платёжного шлюза нет** — начисление/списание не интегрировано (заглушка); CPM-биллинг ручной |
| Security (2FA, AES, anti-fraud, audit) | ✅ | `src/app/api/auth/2fa/{enable,confirm,verify,disable}/`, `src/lib/services/totp-service.ts`, `src/lib/security/crypto.ts` (AES-256-GCM), `anti-fraud.ts`, `anomaly-detector.ts`, `ssrf.ts`, `rate-limiter.ts`, `src/lib/data-vault/audit-log.ts` | Security Gate + red team перед продом (P1) |
| Build Talent / Workforce Intelligence / Skill Futures | 🟡 | `src/app/api/companies/[id]/talent-forecast/route.ts`, `…/workforce-gap/route.ts`, `src/app/api/skills/[id]/forecast/route.ts`, `talent-forecast-service.ts`, `workforce-service.ts`, `skill-futures-service.ts` | API есть, нет UI и нет прогнозной модели (сейчас эвристика); Team Builder отсутствует |
| Scaling / Infrastructure | 🟡 | см. раздел 3 (событийный слой и Docker/CI есть; очередь/кеш/PostgreSQL/автоскейл — нет) | см. раздел 3 |

Итог по PDF-2: 24 из 26 доменов имеют код в v6-песочнице (благодаря слиянию v5-базы и реконструкции), главные пробелы — монетизация без шлюза, половинчатые Build Talent/Workforce, News Bridge не от компаний.

### 2.1. Сверка оценок PDF-2 (§66) с фактом v6

| Область | Оценка в PDF-2 (для v5) | Что изменилось в v6-песочнице |
|---|---|---|
| Professional Truth | 8.5/10 | Без изменений: ядро то же, Evidence Layer уже в коде |
| Skill Graph | 8/10 | Без изменений; @ts-nocheck остался |
| Proof | 7/10 | Proof Granularity по-прежнему отсутствует (Role→Result) |
| Mentor | 8/10 | Без изменений |
| Opportunity Engine | 8/10 | Без изменений; Opportunity Graph — P1 |
| Job Search | 8/10 | Compare/Passport/Time Value на месте; semantic-слой по-прежнему слаб |
| Company Intelligence | 6.5/10 | Company Stream/Claim есть; Company Memory/Persona — нет |
| News | 7.5/10 | News Relevance работает; News Bridge от компаний не сделан (cron-fetch-news фиксированный) |
| AI | 6.5/10 | Улучшено: появился настоящий AI Core (gateway + compute router + event bus, Task 10-c) |
| UX | 6/10 | Улучшено: 4 v6-компонента подключены (Task 10-d); музей карточек частично решён табами /me |
| Monetization | 5/10 | Без изменений: шлюза нет |
| Security | 6.5/10 | Без изменений: база сильная, Security Gate не проводился |
| Production readiness | 4.5/10 | Улучшено: Docker/CI/Helm/backup (Task 10-e); но SQLite, 0 тестов, in-memory состояние |
| Strategic moat | 8/10 потенциал | Professional Capital + Memory + Coach уже живут в /me |

---

## 3. Архитектура масштабирования и суверенитета (PDF-1)

| Компонент | Статус | Доказательство | Как реализовать для этого кода |
|---|---|---|---|
| Data Sovereignty Gateway (классы A/B/C, 152-ФЗ/GDPR, minimizeForAI) | ✅ | `src/lib/sovereignty/gateway.ts` (`DataClass='A'\|'B'\|'C'`, `regulationFor()` → `'152-FZ'\|'GDPR'`, класс A при 152-ФЗ → minimizationRequired), подключён в `src/lib/ai-core/gateway.ts` | Пропустить остальные сервисы (news, signal, matchmaker) через `sovereigntyCheck` перед любым экспортом данных |
| Суверенитет-поля пользователя | ✅ | `prisma/schema.prisma:48-52` — `citizenship`, `region`, `consentAiAnalysis`, `consentCrossBorder` | UI-согласия в settings-view (чекбоксы → PATCH /api/users) |
| РФ Data Plane (региональное хранение) | ❌ | В коде только маппинг гражданства; единственная БД `file:…/db/custom.db` | Модель `DataResidence`/env `DATA_PLANE=RU`; при `region=RU` — отдельный `DATABASE_URL_RU` и роутинг записи через репозиторий-фабрику (`src/lib/db-plane.ts`), запрет cross-border без `consentCrossBorder` в gateway |
| Data Minimization (AI не получает PII) | ✅ | `sovereignty/gateway.ts` `minimizeForAI` (FIELD_CLASS: avatarUrl='C' и т.д.), вызывается из `ai-core/gateway.ts` перед LLM | Добавить golden-тесты: ни один промпт не содержит Class A полей |
| Compute Router (7 провайдеров, приоритеты, дедлайн) | ✅ | `src/lib/compute/router.ts` (zai-llm, zai-llm-fast, heuristic-local, cache, template, external-api, ensemble; Cost Optimizer-цепочки по critical/high/normal/low) | Реализовать провайдер `external-api` (сейчас заглушка, `router.ts:35,216`) — внешние.embedding/ranking API |
| Cost Optimizer (дешёвый compute для фоновых задач) | ✅ | цепочки low → cache/template/heuristic без LLM в `compute/router.ts` | Прокинуть cron-скрипты (`scripts/cron-*.js`) через роутер вместо прямых расчётов |
| Event Bus (типизированные события, DLQ) | ✅ | `src/lib/event-bus/index.ts` (29 типов, wildcard, DLQ cap 100), публикации из `/api/feed`, `/api/posts`, `/api/jobs`, `/api/me/capital/recompute`, `/api/me/coach/*` | Перенести in-process шину на очередь при multi-instance (см. Queue) |
| AI Gateway (rate limit, кеш, model router, sovereignty) | ✅ | `src/lib/ai-core/gateway.ts` (30/час на user+операцию, SHA-256 кеш TTL 1ч, routeModel critical→zai-llm, normal→zai-llm-fast, low→heuristic) | Вынести кеш/лимиты из in-memory в Redis (сейчас сбрасываются при рестарте) |
| Stateless API | 🟡 | Сессии в БД (`Session`, cookie `bizon_session`) — ок; но `rate-limiter.ts:11` (`private store = new Map`) и `cache.ts` — in-memory в процессе | Убрать локальное состояние: Redis-backed rate-limiter/cache, иначе балансировка ломает лимиты и кеш |
| BizON Scaling Controller (решения по 15+ метрикам) | ❌ | Только статичные `replicas: 2` в `deploy/helm/values.yaml` | Новый `src/lib/scaling/controller.ts`: сбор метрик (RPS, p95/p99, queue depth, DB latency из `/api/metrics`) → таблица решений Scale API/Workers/Search; экспорт custom metrics для HPA |
| Predictive Autoscaling (прогноз пика) | ❌ | — | Cron `scripts/cron-load-forecast.js`: скользящее среднее по ActionEvent/`/api/metrics` за 7 дней → pre-scale за 15 мин (позже — LLM-forecast поверх) |
| Queue Infrastructure | ❌ | Только in-memory EventBus + DLQ; персистентной очереди нет | BullMQ на Redis (уже в `deploy/docker-compose.yml`): очередь `ai-tasks` (202 Accepted → worker → Event → уведомление), тяжёлые LLM-задачи из `ai-core` уводить в worker |
| Distributed Cache | 🟡 | Redis в `deploy/docker-compose.yml` и helm-шаблонах, но `rg "redis" src/lib` — только комментарии («In-memory реализация для MVP (в продакшене — Redis)») | Заменить `cache.ts` и хранилище `rate-limiter.ts` на ioredis (интерфейс тот же get/setTtl/incr) |
| PostgreSQL-миграция | 🟡 | `deploy/docker-compose.yml` (postgres:16 + `init-postgres.sh` + `DATABASE_URL=postgresql://…` в контейнере), `scripts/backup-db.sh` умеет pg_dump; НО `prisma/schema.prisma:11 provider="sqlite"`, `.env` — `file:` | Поменять provider на `postgresql`, прогнать миграции, заменить SQLite-специфику (Json-поля ок, `mode: 'insensitive'` и т.д.), переключить `.env`; compose уже готов |
| Shard-Ready Architecture | ❌ | Нет hash-роутинга по user_id | Абстракция репозитория (`src/lib/repositories/`), все запросы через `db.user…` → единая точка для будущего consistent-hash по user_id/conversation_id |
| CDN / WAF / DDoS | ❌ | `rg "waf|ddos|cdn" src/ deploy/` — пусто | Cloudflare/ру-аналог перед ingress (helm `ingress.yaml` уже есть); rate-limiter на edge + существующий `ssrf.ts` для исходящих |
| Observability | 🟡 | Самописные `src/app/api/metrics/route.ts`, `src/app/api/admin/metrics/route.ts`, `deploy/grafana-dashboard.json` (в scripts/) | Sentry SDK + OpenTelemetry-обёртка в `event-bus`/`compute-router` (там уже есть метрики per-provider) |
| Backup / Restore | ✅ | `scripts/backup-db.sh` (sqlite .backup→gzip, pg_dump, retention 7 дней, crontab в шапке) | Ежедневный cron в compose/helm + проверка восстановления |
| Disaster Recovery / Regional Failover | ❌ | — | После PostgreSQL: pg_basebackup/Patroni, DNS-failover между RU/EU кластерами (этап LEVEL 3–4) |
| CI/CD | ✅ | `.github/workflows/ci.yml` (install→prisma generate→lint→tsc→build), `deploy.yml` (buildx→registry) | Добавить в CI шаг тестов (когда появятся) и миграций против postgres-сервиса |
| Load / Chaos testing | ❌ | `find *.test.ts *.spec.ts` — 0 файлов | k6/autocannon сценарий на /api/feed, /api/jobs, /api/search; chaos-эксперименты в helm (kill pod, latency injection) |
| Docker / Kubernetes | ✅ | `deploy/Dockerfile` (multi-stage, standalone, non-root, HEALTHCHECK /api/health), `docker-compose.yml`, `deploy/helm/*` (deployment/service/ingress/networkpolicy с egress 443) | — |

Вывод по PDF-1: фундамент «в одном процессе» (Gateway, Router, Event Bus, AI Gateway, Docker/CI/Helm) — готов; всё, что требует нескольких процессов/машин (очередь, distributed cache, PostgreSQL, Scaling Controller, автоскейл) — отсутствует и является Phase 0-минимумом перед ростом.

### 3.1. Phase 0 «Global Scale Foundation» — чек-лист PDF-1 (42 пункта) → статус v6

| # | Пункт | # | Пункт | # | Пункт | # | Пункт |
|---|---|---|---|---|---|---|---|
| 1 | Data Sovereignty Layer ✅ `sovereignty/gateway.ts` | 12 | Horizontal Autoscaling ❌ | 23 | DDoS protection ❌ | 34 | Graceful degradation 🟡 (fallback-цепочки compute-router) |
| 2 | Regional Data Plane ❌ | 13 | Node Autoscaling ❌ | 24 | Observability 🟡 `/api/metrics` | 35 | AI fallback ✅ `ai-core/gateway.ts` |
| 3 | Global Compute Plane ❌ | 14 | Multi-Cluster ❌ | 25 | Cost Optimizer ✅ `compute/router.ts` | 36 | Provider fallback ✅ `compute/router.ts` |
| 4 | Compute Router ✅ | 15 | Read Replicas ❌ | 26 | Capacity Forecasting ❌ | 37 | Infrastructure abstraction 🟡 (helm-чарт, нет абстракции провайдера) |
| 5 | Data Classification ✅ (A/B/C) | 16 | Partitioning ❌ | 27 | Disaster Recovery ❌ | 38 | IaC 🟡 (helm, без Terraform) |
| 6 | Data Minimization Gateway ✅ `minimizeForAI` | 17 | Shard-Ready ❌ | 28 | Backup/Restore ✅ `backup-db.sh` | 39 | CI/CD ✅ `.github/workflows/` |
| 7 | AI Gateway ✅ | 18 | Distributed Cache 🟡 (redis не подключён) | 29 | Regional Failover ❌ | 40 | Load testing ❌ |
| 8 | Event Bus ✅ | 19 | Search Cluster ❌ (semantic-search в процессе) | 30 | Automated Health Checks ✅ (`/api/health`, HEALTHCHECK) | 41 | Chaos testing ❌ |
| 9 | Queue Infrastructure ❌ | 20 | Object Storage ❌ | 31 | Circuit Breakers 🟡 (deadlineMs в router) | 42 | Security Gate ❌ |
| 10 | Stateless API 🟡 | 21 | CDN ❌ | 32 | Rate Limits ✅ (`rate-limiter.ts`) | | |
| 11 | Kubernetes 🟡 (helm готов, кластера нет) | 22 | WAF ❌ | 33 | Backpressure 🟡 (DLQ в event-bus) | | |

**Счёт Phase 0: 12 ✅ / 8 🟡 / 22 ❌.** Готовность фундамента ≈ 38% — соответствует цели «ядро в одном процессе готово, распределённый слой впереди».

### 3.2. Стратегия V5.1 → V6.x (этапы 1–14 из PDF-1) → что уже сделано в v6-песочнице

| Этап | Название из PDF-1 | Статус в v6 | Комментарий |
|---|---|---|---|
| V5.1 | Production hardening | 🟡 | Сделано: CI, Docker, backup, seed-скрипты (Task 10-e). Не сделано: PostgreSQL, миграции, тесты, Security Gate, db push → migrations |
| V5.2 | Professional Evidence Layer | ✅ | `ProfessionalEvidence` модель + `src/app/api/me/evidence/`, `scripts/migrate-evidence.js` |
| V5.3 | Skill Graph 2.0 | ✅ | `skill-graph-service.ts`, `level-formula.ts`, resurrect/explain/proofs API |
| V5.4 | Professional Search Engine | 🟡 | `semantic-search-service.ts` + `SkillSynonym` (119 сид); нет intent-extraction и онтологии |
| V5.5 | Opportunity Engine 2.0 (Opportunity Graph) | 🟡 | Engine есть, графа-навигации нет (P1) |
| V5.6 | BizON Learns You | 🟡 | Механика confirm/dismiss есть (`bizon-coach-card`), cron-гипотез нет (раздел 4) |
| V5.7 | Professional Memory | ✅ | `memory-service.ts` + нарратив-версии + `cron-memory.js` |
| V5.8 | BIZON AI CORE | ✅ | `ai-core/index.ts` + `gateway.ts`: единый вход, Model Router, ни один сервис не выбирает модель сам |
| V5.9 | Data Sovereignty Layer | ✅ | `sovereignty/gateway.ts` + поля User + проверка перед LLM |
| V6.0 | Distributed Architecture | 🟡 | Docker/compose/helm/CI готовы; очередь, distributed cache, multi-cluster — нет |
| V6.1 | Predictive Autoscaling | ❌ | P1 (раздел 6) |
| V6.2 | Global Compute Fabric | ❌ | Зависит от очереди + PostgreSQL + региональных кластеров |
| V6.3 | Skill Futures | 🟡 | `skill-futures-service.ts` + `/api/skills/[id]/forecast` — эвристика, не прогноз |
| V6.4 | Build Talent | 🟡 | `talent-forecast`/`workforce-gap` API без UI |

---

## 4. Гибридная AI-архитектура (PDF-3)

| Принцип | Статус | Доказательство | Как реализовать |
|---|---|---|---|
| Фильтр для простых запросов (80% без LLM) | 🟡 | Эвристики в `ai-core/index.ts` (heuristicInsight), матчинг в `matchmaker.ts`, SQL-фильтры в `/api/jobs` | Явный pre-filter: длина запроса ≤10 слов и наличие тегов → SQL/Elastic-путь; LLM только для сложных (длина >10 слов, 0 результатов, сессия >5 мин) |
| LLM-фасад: Слой1-алгоритм → Слой2-текст → Слой3-кнопки | 🟡 | `ai-core/index.ts`: `analyze()` собирает контекст алгоритмом → `buildPrompt` → LLM переформулирует; fallback heuristic | Зафиксировать правило «ИИ не выбирает контент, только текст»: все рекомендации — результат SQL/скоринга; LLM получает готовый JSON-список и пишет объяснение («Почему вам») |
| Epsilon-greedy 10–20% (разнообразие) | ❌ | `rg "epsilon|exploration|interleav" src/` — только diversityScore верификаторов в `level-formula.ts` | В `feed-service.ts` и `opportunity-service.ts`: `if (Math.random() < 0.15) → случайные trending из смежной категории`, помечать `source: 'exploration'` |
| Decay старых интересов | ❌ | Decay есть только для навыков (`skill-graph-service.ts:236`); в ленте/рекомендациях веса статичны (`feed-service.ts:129 weight: p.type==='commercial'?2:1`, `impactScore=0.5+ipScore/200`) | Формула из PDF-3: `weight = views / (1 + daysSince * 0.1)` на историю просмотров (ActionEvent/ProfileView); пересчёт в `feed-service.getFeed` |
| Exploration-вставки / Interleaving | 🟡 | Кнопка «Случайные новости» — Fisher-Yates shuffle (`feed-service.ts:150-160`, `random=true`); карусель `feed-recommendations.tsx` | Автоматически: 12 точных + 3 новых, перемешать; ротация источников рекомендаций (history/collaborative/trending) |
| Кнопка «Не интересно» / IgnoredTopic | 🟡 | `src/components/feed/recommendations-carousel.tsx:178-179` — кнопка есть, но скрывает карточку только локально (`локально скрытые карточки (по id)`, стр. 264); `IgnoredTopic` в схеме пишется только `coach-service.ts:132` | POST `/api/me/ignored-topics` → сохранить topic в `IgnoredTopic`; фильтр в `feed-service`/`opportunity-service` через `db.ignoredTopic.findMany` (паттерн уже есть в coach-service:136) |
| Семантический кеш | ✅ | `ai-core/gateway.ts` (SHA-256(оп+payload+контекст), TTL 1ч, LRU 1000), клиентский кеш ответов в `semantic-search-bar.tsx` | Переезд на Redis (см. 3) — чтобы кеш был общим для реплик |
| Rate limit AI | ✅ | `gateway.ts` (30/час на user+операцию), `checkUserRateLimit` в `src/app/api/search/semantic/route.ts:4` | Redis-backed счётчики для multi-instance |
| «Помогите нам понять вас лучше» (AI-гипотезы Да/Нет) | 🟡 | `bizon-coach-card.tsx`: вопрос дня + инсайты confirm/dismiss (PATCH `/api/me/coach/insights/[id]`, статусы new/confirmed/dismissed) — механика подтверждения гипотез есть; `IgnoredTopic` фильтрует discovery (`coach-service.ts:191`); НЕТ: cron-генерации поведенческих гипотез из просмотров/хобби и модального потока «до 3 карточек» | Cron (по образцу `scripts/cron-coach.js`): ActionEvent за 30 дней → гипотезы (смотрит курсы педагогики, не откликается на вакансии учителя → «страх публичных выступлений»); лимит 3/сутки, скрытие на 7 дней после 2 закрытий (из ТЗ PDF-3 §7) |
| Ad Pressure ≤1/10 | 🟡 | `ad-pressure-service.ts` (уровни low/medium/high) + 1 спонсор на страницу ленты (`feed-service.ts:170` `allItems.splice(5,0,…)`), комментарий `trust-stream.tsx:3` «каждые 10 постов»; **баг ИСПРАВЛЕН в этой сессии:** все 4 строки заменены на `24*60*60*1000` (было 24 минуты вместо суток) | Исправить 4 строки на `24*60*60*1000`; вставку рекламы привязать к счётчику organicItemsShown (≤1 на 10 органических) |

Вывод по PDF-3: инфраструктура гибрида (кеш, лимиты, эвристики, суверенитет перед LLM) готова; отсутствует именно «математика разнообразия» (Decay/Exploration/Interleaving) и устойчивая обратная связь (IgnoredTopic из UI).

---

## 5. UX-спецификация (из сообщения пользователя)

| Решение | Статус | Доказательство в коде | Что делать |
|---|---|---|---|
| Главный экран 5 блоков (Что изменилось / Что важно / Что делать / Какие возможности / Что произошло на рынке) | 🟡 | «Что изменилось» + «Что произошло с последнего визита»: `whats-new-tab.tsx:577,633`, `truth-dashboard-tab.tsx:451`; «Что делать»: `next-best-action-card.tsx`; «На рынке»: `bizon-signal-card.tsx`; дашборд: `dashboard-view.tsx` (daily-brief, interested-companies, monthly-calendar, predictive-flow) | Собрать композицию `HomeFiveBlocks` в `dashboard-view.tsx` в порядке спеки, остальное — контекстно ниже; убрать дубли AI-карточек (PDF-2 §50) |
| Профиль = Public Persona (`/p/[token]`, нарратив без чисел) + Private Truth (`/me`: IP-score, Trust Level, Skill Graph, Truth Gap) | 🟡 | `/p/[token]/page.tsx` — паспорт без PII, IP-score только level («нарратив» частично); `/me` — табы whats-new/persona/truth/skills/ai-coach/actions (`me-view.tsx:73-96`); Truth Gap в self-assessment | Нарративный Public Persona (текстовая история, без метрик) — новая секция на `/p/[token]` из ProfessionalNarrative |
| Чужой профиль: общие контакты + цепочка доверия | 🟡 | `profile-view.tsx`, `trust-graph/`, `/api/connections`, `/api/trust-graph`, `trust-explain` | Добавить блок «Общие контакты» (пересечение связей + путь доверия 2-hop) |
| Календарь (CompactCalendar в rail, MonthlyCalendar, AI-Time-Manager, Google/Outlook sync) | 🟡 | `feed/compact-calendar.tsx` (rail), `dashboard/monthly-calendar.tsx`; интеграции — только `src/app/api/integrations/{github,linkedin,telegram}` | Google/Outlook: OAuth + `/api/integrations/google-calendar`; AI-Time-Manager — позже (P2) |
| AuthorChip / UserAvatar с уровневыми цветами (Lighthouse золотой, Authority бирюзовый, Established синий, Builder серый, Newcomer без цвета) | 🟡 | `user-avatar.tsx` — только инициалы + зелёная точка «Онлайн»; уровневых цветов нет (`rg "lighthouse\|authority" src/` — пусто); `trust-badge.tsx` — IP-score бейдж | Создать `AuthorChip` (аватар + имя + уровень + verified); палитру уровней — в `user-avatar.tsx`/`trust-badge.tsx` по спеке |
| Напоминания: While You Were Away | ✅ | `whats-new/route.ts` Phase 3 + `whats-new-tab.tsx:83` | — |
| 7-day Onboarding Mission | ✅ | `onboarding/onboarding-mission.tsx` (day1…day7), `onboarding-flow.tsx`, `/api/onboarding/{status,complete-step,skip}` | — |
| Email re-engagement 7/30/90 + Weekly Digest | ✅ | `email-service.ts` (Этап 8.6, 3 типа писем), `scripts/cron-email-reengagement.js`, `scripts/cron-weekly-digest.js` | Расписания 7/30/90 сверить с cron-логикой |
| Каналы: in-app / SSE / email / push | 🟡 | in-app: `/api/notifications`; SSE: `/api/notifications/stream` (Этап 5.7, keepalive 15с); email: `email-service.ts`; push: только Service Worker (`use-pwa.ts`), web-push нет | Добавить web-push (VAPID) в `notification-service` |
| Настройки уведомлений | ✅ | `notification-service.ts` (`instant/daily/off` по 5 типам + DND 22:00–08:00, FORBIDDEN_TYPES=['rating_drop']) | — |
| Лента Trust Stream: формула веса, 5 табов XING-стиль, 4 типа контента, карусель рекомендаций, Ad ≤1/10, «Не интересно» | 🟡 | `feed/trust-stream.tsx` (режимы mini/vk, 3 таба `all/posts/achievements`, 7 subsections rail, спонсор каждые 10), `feed-recommendations.tsx`, `recommendations-carousel.tsx` («Не интересно» локально); формулы веса нет (`weight:1/2`, см. раздел 4) | Веса по формуле раздела 4; состав табов по спеке (свернуть до 2 базовых + остальные в rail); карусель — ✅; «Не интересно» — персист в IgnoredTopic |
| 5+3 навигация | 🟡 | `shell/app-shell.tsx` — NAV_MAIN_INDIVIDUAL / NAV_MAIN_COMPANY + нижняя мобильная навигация | Сверить состав (5 основных + 3 доп.) со спекой |
| PROJ-статусы | 🟡 | `projects/project-next-steps.tsx` (PROJ-2), статусы проектов в `nft-skills-service`/`projects` | Ввести явные статусы pipeline (планируется/идёт/завершён) в UI проектов |
| Three States of Exit (completed/graceful/conflict) | ✅ | `schema.prisma` (`Job.exitState`, `Project.exitState`), `src/app/api/projects/[id]/leave/route.ts` (валидация 3 состояний, `exitReason` обязателен при conflict), `…/transition/route.ts` | — |
| R9 «Спроси у коллег» | ✅ | `colleague-inquiries/colleague-inquiry-dialog.tsx`, `incoming-inquiries-dialog.tsx`, `/api/colleague-inquiries(/respond)` | — |
| R10 Actions Timeline | ✅ | `me/actions-timeline-tab.tsx`, `/api/me/actions`, `action-event-service.ts` | — |
| Company Persona | ❌ | Company Passport (`company-passport-service.ts`) и Company Stream есть; «Company Persona» (голос компании как автора) — нет | Нарратив-секция в company stream из CompanyClaim + проектов компании |
| UX-принципы: зелёный ≤3 применений; чипсы с количеством; pipeline-навигация вакансий; 2 таба ленты; скринридер | 🟡 | зелёный — только индикатор онлайн (`user-avatar.tsx`), `green-500` в globals.css/landing отсутствует; счётчики — unreadCount в app-shell; pipeline вакансий — не найдено; скринридер — `common/skip-to-content.tsx`, aria-labels по компонентам | Pipeline-навигация вакансий (этапы отклика) — новая; чипсы-счётчики на все пункты меню |

### 5.1. Trust Stream: текущая механика vs спецификация

| Элемент спеки | В коде сейчас | Gap |
|---|---|---|
| Формула веса контента | `feed-service.ts:129` — `weight: p.type === 'commercial' ? 2 : 1`, `impactScore: 0.5 + ipScore/200`; события берут `e.weight` из БД | Нет доверия/свежести/реляционности в весе — заменить на формулу спеки (связь × trust × fresh × impact) |
| 5 табов XING-стиль | 3 таба `feedMode` (all/posts/achievements) + 7 subsections правого rail | Свернуть до 2 базовых табов (спека), остальное — в rail |
| 4 типа контента | посты + reputation-события + sponsored + рекомендации | Совпадает по составу, нужен единый веситель |
| Карусель рекомендаций (Vings-стиль) | `recommendations-carousel.tsx` + `feed-recommendations.tsx` | Готово, добавить персист «Не интересно» |
| Ad Pressure ≤1/10 | 1 спонсор на страницу (`splice(5,0)`), комментарий «каждые 10 постов» | Привязать к `organicItemsShown` через AdPressureService (после фикса 24-минутного бага) |
| Кнопка «Не интересно» | локальное скрытие карточки | Запись в `IgnoredTopic` + фильтрация на сервере |

---

## 6. Приоритетный план P0/P1/P2 (объединённый)

Оценки: S ≤ 0.5 дня, M ≈ 1–3 дня, L > 3 дня.

### P0 — блокеры (делать до любых новых фич)

| Задача | Зачем | Как | Оценка |
|---|---|---|---|
| ~~Исправить AdPressure `24*60*1000`~~ ✅ ВЫПОЛНЕНО (эта сессия) | PDF-2 §40 | 4 замены сделаны; осталось: тест давления за сутки | — |
| SQLite → PostgreSQL | PDF-1 §5, PDF-2 §46; compose/init уже готовы | provider в schema.prisma → postgresql, миграции, прогон seed, переключение `.env`, убрать sqlite-специфику | M |
| Персистентная очередь (BullMQ + Redis) для AI-задач | PDF-1 §19: тяжёлые LLM — async 202→worker→Event; сейчас LLM в HTTP-запросе | Очередь `ai-tasks`, worker-процесс в compose/helm, уведомление через EventBus | M |
| Distributed cache + rate-limiter на Redis | PDF-1 §6 (Stateless); `cache.ts`/`rate-limiter.ts` in-memory ломают multi-instance | Интерфейс тот же, реализация ioredis (Redis уже в compose/helm) | M |
| Внедрить IgnoredTopic из кнопки «Не интересно» | PDF-3 (User Control), UX-спека | POST `/api/me/ignored-topics` + фильтры в feed/opportunity/coach (паттерн в `coach-service.ts:136`) | S |
| Убрать `@ts-nocheck` (proof-service, skill-graph-service, opportunity-service) | PDF-2 §49: типобезопасность критичного кода | Постепенная типизация, tsc strict | M |
| Тесты (unit/API критичного ядра) | PDF-2 §48: 0 тест-файлов — главный блокер | Vitest: auth, claims verify, anti-fraud, ad-pressure, sovereignty, feed | L |
| База 5 блоков главного экрана | PDF-2 §51–52 + UX-спека | Композиция в `dashboard-view.tsx` из готовых карточек (whats-new, signal, next-best-action, opportunities) | M |
| Kнопка «Не интересно» + Decay/Exploration в ленте | PDF-3 (Эхо-камера) | См. раздел 4: pre-filter → 12 точных + 3 exploration, weight-формула | M |

### P1 — после P0

| Задача | Зачем | Как | Оценка |
|---|---|---|---|
| BizON Scaling Controller + Predictive Autoscaling | PDF-1 §8, §12 | Метрики → решения; pre-scale по прогнозу; экспорт custom metrics для HPA | L |
| Компания-центричный News Bridge | PDF-2 §15: cron-fetch-news.js всё ещё vc.ru/habr/rb.ru | По `Company.newsSources` (схема готова) — RSS/API компании → NewsCard + Traffic Back | M |
| Professional Trust вместо IP-score | PDF-2 §41: activity ≠ expertise | Формула Evidence Quality × Verification × Outcome × Recency × Independence × Consistency; Network Influence отдельно | L |
| Opportunity Graph + Causality | PDF-2 §55–56 | Цепочка PERSON→SKILL→PROOF→OPPORTUNITY→RESULT в `opportunity-service` + лог ActionEvent | L |
| Build Talent / Workforce UI | PDF-2 §34–35, §58 | API уже есть (`talent-forecast`, `workforce-gap`) — сделать дашборд компании: pipeline, дефицит, наставники | M |
| AuthorChip + уровневые цвета аватаров | UX-спека | Компонент + палитра Lighthouse/Authority/Established/Builder/Newcomer | S |
| Google/Outlook календарь + pipeline вакансий | UX-спека | `/api/integrations/google-calendar` (OAuth), этапы отклика в jobs-view | M |
| Semantic Search Engine (Professional Query) | PDF-1 Этап 4, PDF-2 §43–44 | Intent-extraction из запроса → фильтры; SkillSynonym (119 seed) + embeddings | L |
| Observability (Sentry + трейсинг AI-слоя) | PDF-2 §62 | SDK + связка с метриками compute-router/event-bus | M |
| Security Gate + red team + load tests (k6) | PDF-2 §62, PDF-1 п. 40–41 | Чек-лист, внешние сценарии, пороги p95 | L |
| Платёжный шлюз | PDF-2 §38 | ЮKassa/CloudPayments: checkout, вебхуки, биллинг подписок и CPM | L |
| Company Persona + Company Memory | UX-спека, PDF-2 §33 | Нарратив компании из stream; агрегат «какие компетенции накопила» | M |

### P2 — стратегическое

| Задача | Зачем | Как | Оценка |
|---|---|---|---|
| РФ Data Plane + regional routing | PDF-1 §2, §9 (152-ФЗ) | Репозиторий-фабрика + второй кластер, failover | L |
| Shard-Ready (consistent hash по user_id) | PDF-1 §17 | Абстракция репозиториев, партиционирование ActionEvent/News | L |
| Multi-cluster / Global Compute Fabric | PDF-1 §10, Этапы 10–13 | Helm per-region, ComputeRouter выбирает регион | L |
| Skill Futures 2.0 (прогноз рынка) | PDF-2 §37 | Данные Signal + зарплаты + время освоения → прогноз 12–36 мес | L |
| Team Builder («собери команду») | PDF-2 §36 | Поверх Professional Graph, вероятность успеха проекта | L |
| W3C Verifiable Credentials | PDF-2 §64 | Экспорт Claim/Evidence в VC-формат | M |
| Web-push + AI-Time-Manager | UX-спека | VAPID; планировщик календаря | M |
| Blind Spots через LLM | PDF-2 §24 | Поведение → Pattern → AI inference вместо ключевых слов | M |

### Что НЕ делать сейчас (согласно PDF-2 §65)
DAO/токены, XP/streak/leaderboard, геймификация, огромный AI-чат, React Native, «граф ради графа», музей AI-карточек на главной.

---

## 7. Открытые риски

1. **SQLite в проде** — `provider="sqlite"`, `.env` указывает на `db/custom.db`; любые конкурентные записи и масштабирование упираются в файл. Compose-конфиг PostgreSQL готов, но не включён.
2. **~~AdPressure 24-минутный баг~~ ИСПРАВЛЕН** (эта сессия: 4 замены на `24*60*60*1000`); остаётся пункт «привязать вставку рекламы к organicItemsShown».
3. **0 тестов** — ни одного `*.test.ts`/`*.spec.ts`; CI зелёный только на lint+tsc+build (PDF-2: «Build passing ≠ product tested»).
4. **PaymentService — заглушка** — тарифы описаны (`payment-service.ts`), но шлюза и вебхуков нет: реальных денег платформа не принимает.
5. **`external-api` в compute-router — заглушка** (`router.ts:35,216`): внешний compute-провайдер, ключевой для дешёвых вычислений PDF-1, не реализован.
6. **In-memory состояние процесса** — `rate-limiter.ts` (`Map`), `cache.ts`, EventBus с DLQ: рестарт теряет лимиты/кеш/события; горизонтальное масштабирование невозможно без Redis/очереди.
7. **`@ts-nocheck` в 3 критичных файлах** — `proof-service.ts`, `skill-graph-service.ts`, `opportunity-service.ts` (ядро правды и рекомендаций).
8. **News Bridge не от компаний** — `cron-fetch-news.js` жёстко зашит на vc.ru/habr/rb.ru; `Company.newsSources` хранится, но cron'ом не используется.
9. **Рекомендации без разнообразия** — нет Decay/Exploration/Interleaving (PDF-3): лента «прилипает» к ipScore-весам; «Не интересно» не сохраняется.
10. **Единая точка отказа AI-стоимости** — rate limit 30/час в `gateway.ts` in-memory: после рестарта счётчики обнуляются → всплеск расходов на LLM.
11. **Нет резервного сценария восстановления** — `backup-db.sh` есть, но не запускается по расписанию и restore не проверялся; Disaster Recovery/Failover отсутствуют.
12. **cd/CDN/WAF/DDoS отсутствуют** — перед ingress нет защиты; публикуемые `/p/[token]`/`/c/[token]` и SSE-стрим уязвимы к скрейпингу/флуду на edge.
13. **Пустые домены схемы** — слитые v5-модели (Placement, Recruiter, HrContact, CulturalSignal и др.) пока без сервисов/API: мёртвый код схемы до соответствующих фаз.
14. **Демо-доступы в seed** — `ivan@bizon.ru/password` работает; перед публичным запуском обязательна ротация и запрет demo-логинов (PDF-1 Этап 1, п.1).

---

### Приоритет №1 на следующую итерацию (сводка)
`P0`: AdPressure-фикс (S) → PostgreSQL (M) → Redis cache/queue (M) → IgnoredTopic (S) → тесты ядра (L) → 5 блоков Home (M).
Это закрывает «1000 настоящих пользователей — не боюсь» (цель V5.1 из PDF-1) и переводит ядро v6 из «работает в песочнице» в «готово к первым реальным нагрузкам».

### Порядок выполнения и зависимости

1. **Неделя 1:** AdPressure-фикс + IgnoredTopic + AuthorChip — мелкие, мгновенный UX-эффект.
2. **Неделя 1–2:** PostgreSQL-миграция (блокирует всё инфраструктурное) → сразу за ней Redis-backed cache/rate-limiter.
3. **Неделя 2–3:** BullMQ-очередь + вынос тяжёлых AI-задач в worker; EventBus продолжает работать как шина событий поверх очереди.
4. **Неделя 3–4:** тесты ядра (Vitest) + поднятие @ts-nocheck; в CI добавляются шаги test и миграций.
5. **Неделя 4–5:** 5 блоков Home + Decay/Exploration в ленте — первый ощутимый продукт-эффект по PDF-2 §52 и PDF-3.
6. **Дальше (P1):** Scaling Controller (нужны метрики из п.2–3), News Bridge от компаний, Professional Trust, платёжный шлюз.
7. **P2 запускается только после Stage B/C из PDF-1** (1 000 → 10 000 пользователей): региональность, sharding, multi-cluster — строить по мере роста, не заранее.

Правило из PDF-1, которому следуем дословно: «создать архитектурную совместимость с будущим, но физически строить инфраструктуру по мере роста» — поэтому P0 чинит ядро, P1 добавляет интеллект и деньги, P2 — только география и распределённость.

