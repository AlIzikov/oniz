# AUD-2 — Статический аудит Волн 3–6 (План-v2, S-046…S-155)

**Аудитор:** внешний (не автор кода) · **Тип:** read-only статический аудит + воспроизведение тестов/eval в изолированной БД
**Дата:** 19.09.2026 (по часам проекта) · **Протокол приёмки:** GITHUB-ENGINEERING-PROTOCOL-v2 §12–§13, §16, §21
**Статусы:** READY · PARTIAL · BLOCKED · MISSING · MOCK · DOCUMENTED · DOC-MISMATCH · REVIEW

Заявление владельца: «План-v2 выполнен 155/155, волны 1–6 ALL MET». Зона аудита — волны 3–6.

---

## 1. Методика

1. Прочитан worklog.md (записи Wave 3–6, строки 2745–2843), docs/PLAN-V2-STEPS.md (реестр шагов + журнал), docs/MASTER-PLAN-V2-OVERLAY.md (§8.1 ML-стек, §71 Radar), specs/wave-{3,4,5,6}/{GATES,E2E-REPORT}.md.
2. Факт в коде проверен чтением сервисов/API/UI/схемы (file:line ниже) + поиском потребителей (grep по src/ и всему репо).
3. Воспроизведены (песочница, изолированная копия db/custom.db — tests/helpers/setup.ts:20-23):
   - `bun test tests/wave3-*` → **32 pass / 0 fail**
   - `bun test tests/wave4-* tests/wave5-*` → **41 pass / 0 fail**
   - `bun test tests/wave6-*` → **18 pass / 0 fail**
   - `bun tools/evals/skill-futures-eval.ts` → **PASS** (leadTimeAccuracy 67% (2/3), earlyWarn 0.67, MAE v1 2.0 дн.)
   - `bun tools/evals/jobs-matcher-eval.ts` → **precisionTop3 = 0.979** воспроизводится (samples=160, users=16, modelVersion heuristic-v0)
4. Код НЕ менялся; единственный артефакт — этот отчёт.

---

## 2. ВОЛНА 3 (S-046…S-075) — Diversity + AI-экономика + News/Events

| # | Обещание | Вердикт | Факт (file:line) |
|---|----------|---------|------------------|
| 3.1 | Diversity-квоты 75/15/10 в ленте | **READY** | src/lib/services/diversity-service.ts:17-21 (константы), :84-155 (applyDiversity, капа 2/автор, decay 72ч); подключено в ленту: src/lib/services/feed-service.ts:209-218. Тесты wave3-diversity 10/10. Пользователю — только порядок+explain (§3.3 соблюдён) |
| 3.2 | SkillSynonym | **READY** | diversity-service.ts:165-211; тесты 3/3 |
| 3.3 | ai-core реестр операций | **READY** | src/lib/ai-core/operations.ts:24-57 (8 операций, риск/цена/капа); registerAiOperation :69-72 |
| 3.4 | Метринг → AiBudget | **READY** | src/lib/ai-core/metering.ts:27-51 (checkBudget: бюджет+dailyCap), :57-102 (meterUsage, атомарный increment, resetAt-guard); вызовы встроены в gateway: src/lib/ai-core/gateway.ts:227, :254-261, :356-361 |
| 3.5 | Semantic cache | **READY** (с оговоркой) | src/lib/ai-core/semantic-cache.ts:13 (Jaccard ≥0.85), in-memory, TTL 1ч; границы честно задокументированы :1-11 («эвристика без внешних эмбеддингов», переход на эмбеддинги = ADR). Встроен в gateway:254-261, 356 |
| 3.6 | cron-гипотезы (ActionEvent 30 дней, ≤3/сутки) | **PARTIAL + DOC-MISMATCH** | Лимит 3/сутки есть: src/lib/services/hypothesis-service.ts:14, :95-101; правила по агрегатам :25-58. НО: «крона» НЕТ — единственный триггер это ручной POST /api/hypotheses/run (src/app/api/hypotheses/run/route.ts:10-13, 10/час на пользователя); ни один скрипт scripts/cron-*.js его не вызывает; in-process планировщика нет (src/instrumentation.ts — только метрики/ключ). UI-потребителя /api/hypotheses в src/components нет (grep: 0 вызовов) — бэкенд без UI и без планировщика |
| 3.7 | LSTM/Prophet v1, Lead Time ≥5 дней | **DOC-MISMATCH / PARTIAL** | Реализовано: Holt-эвристика «v1-prophet-lite» (src/lib/trust/model-interfaces.ts:214-329) — НЕ LSTM и НЕ Prophet (сам код это признаёт :214). Eval честный и проходит, но на 4 синтетических рядах (tools/evals/skill-futures-eval.ts:20-61). При этом продукт-сервис src/lib/services/skill-futures-service.ts:1-9 — отдельная факторная эвристика «v6.0», TrendForecastModel/Holt не использует и Lead Time не отдаёт (API /api/skills/[id]/forecast, /api/me/skill-futures — другие метрики). Связка «продукт ↔ eval-модель ↔ Lead Time ≥5 дней» отсутствует |
| 3.8 | Reputation Estimator (гейт ≥90 дней) | **PARTIAL** | Оценщик честный: src/lib/trust/reputation-estimator.ts:13, :50-59 (INSUFFICIENT_DATA без имитации), байесовское среднее с decay :74-93; накрутка weight-0 событиями заблокирована :81-84. НО: потребителей НЕТ — grep `estimateReputation` по src/ даёт только определение; ни API, ни UI. Модуль живёт только в тестах (wave3-aicore:167-176, wave3-adversarial:40-41) |
| 3.9 | GNN-анти-фрауд v2 (FPR ≤2%) + эмбеддинг-синхронность текстов | **DOC-MISMATCH / PARTIAL** | Реально: Jaccard-похожесть токенов + union-find кластеризация (src/lib/services/fraud-text-sync.ts:44-92), сам файл называет это «„GNN-подобный“ сигнал v0» (:7-10). Эмбеддингов нет. FPR ≤2% НЕ измерен — «FPR-замер» это 2-3 ручных кейса (tests/wave3-aicore.test.ts:188-214, wave3-adversarial:107-119). В прод-контур НЕ встроено: detectTextSync не вызывается ни из anti-fraud.ts, ни из роутов постов (grep: только тесты). Порог «FPR ≤2%» из §8.1 оверлея не воспроизведён |
| 3.10 | POST 5 типов + POLL + SUBSCRIPTION + TERM | **READY** | src/lib/services/post-types-service.ts:19-32 (типы), :60-99 (валидация poll/subscription/term), :102-127 (votePoll, идемпотент), :158-217 (unlock: spend→access→credit, компенсирующий refund :186-207); API /api/posts/[id]/vote, /api/posts/[id]/unlock; UI: src/components/feed/post-composer.tsx:26-28; BAN_WORD :224-233 подключён в posts/route.ts:170. E2E wave-3 PASS (голосование+paywall с балансами) |
| 3.11 | Мероприятия: цена/спикеры/lifecycle/поиск/напоминания | **READY** | src/lib/services/event-service.ts:37-63 (поиск по 5 полям), :65-83 (RSVP+цена), :86-118 (оплата с компенсацией refund), :120-157 (draft→published→cancelled), :159-179 (спикеры ≤10), :186-209 (напоминания за 5 мин, guard reminderSentAt); API events/route.ts:59-61,173; UI events-view.tsx:242-276, 501-511. Оговорка: напоминания «read-time» — срабатывают при загрузке списка, фонового пуша нет |
| 3.12 | Ролевая матрица сообществ + BAN_WORD | **PARTIAL** | BAN_WORD встроен (community-service.ts:129-139). Ролевая матрица реализована: community-service.ts:160-232 (ROLE_MATRIX, banMember, setRole), НО `CommunityPermissions.banMember/setRole/requirePermission` не вызываются ни одним API-роутом (grep: 0 в src/app) — банить/менять роли модераторам нечем. Библиотека без API/UI |

**Итог Wave 3:** READY 6 · PARTIAL 4 (3.6, 3.7, 3.8, 3.12) · DOC-MISMATCH 2 (3.6 «cron», 3.7/3.9 ML-наименования) · MOCK 0. Тесты 32/32 зелёные — но они проверяют модули, часть которых не подключена к продукту.

---

## 3. ВОЛНА 4 (S-076…S-100) — Project Room + Evidence

| # | Обещание | Вердикт | Факт (file:line) |
|---|----------|---------|------------------|
| 4.1 | Табы Overview/Team/Roles/Proof/Milestones/Discussion/Results (+LOT) | **READY** | src/components/projects/project-room.tsx:137-144 (8 триггеров), :147-194 (контенты); Discussion = комментарии к этапам :498-561 через POST milestones {action:'comment'} |
| 4.2 | Клиент-одобряемые поля / UNVERIFIED→VERIFIED + confirmer | **READY** | src/lib/services/project-evidence-service.ts:24-32 (PUBLIC_EVIDENCE_FIELDS), :55-120 (requestConfirmation, идемпотент), анти-коллюзия самоподтверждения :68-79; API projects/[id]/confirmation{,/decide}; решения immutable (ProjectConfirmation) |
| 4.3 | Proof Granularity Role→Responsibility→Action→Result | **READY** | prisma/schema.prisma:692, :1268 (responsibility и соседи); заполненность /4 считается: src/lib/services/professional-trust-service.ts:19, :241; сериализация в evidence-overview: project-evidence-service.ts:309, :349 |
| 4.4 | Company Persona/Memory | **READY** | src/app/api/companies/[id]/memory/route.ts:6-11 → CompanyMemoryService (project-evidence-service.ts) |
| 4.5 | PROJECT-витрина (галерея, участники, заявки, отзывы) | **READY** | src/app/api/projects/gallery/route.ts; заявки: src/lib/services/project-room-service.ts:20-129 (PUBLIC-гейт :26-29, одна заявка :43-51, guard-захват :91-96, accept→member :100-104); отзывы: :132-191 (только участники, self-review блок, verifiedOnly :157-158); UI: projects-view.tsx, project-card.tsx |
| 4.6 | LOT-биржа: 9 блоков, accept_until, эскроу spendVar/refund | **READY** | src/lib/services/lot-service.ts:66-114 (create), :117-152 (respond, дедуп, дедлайн), :158-219 (accept: guard-захват response+lot :175-183, эскроу spendVar :187-203 с откатом захвата при недостатке люменов), :236-285 (complete → credit, weight-0 телеметрия :263-271), :288-307 (cancel → refundVar :296-299), :310-319 (sweepExpired). API: /api/lots[/{respond,accept,cancel,complete}]. UI: project-room.tsx:685-751 (карточка: title/description/skills/budget/duration/дедлайн/статус/исполнитель/отклики — 9 блоков) |
| 4.7 | rating удалён из публичных API → clientVerified | **READY** | scoreInternal не сериализуется: project-room-service.ts:207-221 (listPublic, комментарий :218); GET /api/projects — clientVerified (src/app/api/projects/route.ts:68); завершение лота даёт ReputationEvent weight 0 (lot-service.ts:263-271); /api/users/[id]/reputation отдаёт только ipScore владельцу (users/[id]/reputation/route.ts:15-24) |

**Итог Wave 4:** READY 7 / 7. Самая чистая волна: сервисы, API, UI и тесты согласованы, гонки закрыты guard-обновлениями, §3.3 соблюдён. E2E-REPORT E2E_PASS подтверждён артефактами (specs/wave-4/).

---

## 4. ВОЛНА 5 (S-101…S-130) — Opportunity Engine + Поиск работы

| # | Обещание | Вердикт | Факт (file:line) |
|---|----------|---------|------------------|
| 5.1 | 12 типов Opportunity | **READY** | src/lib/services/opportunity-service.ts:340-363 — ровно 12 case (job/project/mentor/partnership/expert/education/event/business/cofounder/investor/supplier/gig), честные источники (gig из ProjectLot :415, cofounder :486, investor :545, supplier :598) |
| 5.2 | Единый match-pipeline (need→…→explanation→next action) | **READY** (REVIEW-оговорка) | opportunity-service.ts (1601 строк) агрегирует источники + explanation; API /api/opportunities; покрыто wave5-opportunities (11) + adversarial (6). Полная построчная верификация 1601 строки за рамками аудита |
| 5.3 | News→Opportunity bridge | **READY** | src/lib/services/news-opportunity-bridge.ts:19 (анти-шум ≥2 сигнала), :32-37 (словарь паттернов), :75+ (scanRecent, идемпотентность); потребители: /api/opportunities/related:86-91 |
| 5.4 | Opportunity Graph (/related) | **PARTIAL** | API есть и корректен: src/app/api/opportunities/related/route.ts:21-103 (project→gig+job+event, job→gig, дедуп :96-101). НО UI-навигации нет: grep по src/components — потребителей /opportunities/related нет. Бэкенд без UI; «навигация» из плана не реализована |
| 5.5 | CareerMatcher, Precision@Top3 ≥0.85 (заявлено 0.979) | **PARTIAL + DOC-MISMATCH** | Модель — эвристика heuristic-v0 (skill-overlap + level-fit + verified-буст): src/lib/ml/career-matcher.ts:51-98; ML-контракт с точкой подмены :45-48, :100-105. Число 0.979 воспроизводится (eval запущен аудитором), НО ground truth определён как «skill-overlap ≥1» (tools/evals/jobs-matcher-eval.ts:50-56) — тот же сигнал, по которому ранжирует эвристика → метрика циркулярна. Worklog:2815 это признаёт («ground truth коррелирует с эвристикой»), но в PLAN-V2-STEPS.md:79 и specs/wave-5/E2E-REPORT.md:24 число подано как READY без оговорки. «Career BERT» (План-v2) не существует — ни BERT, ни sentence-embeddings |
| 5.6 | VACANCY-поля | **READY** | prisma/schema.prisma:778-781 (scheduleKind, vacancyStatus, employerVerified; vacancyFlags в Job) |
| 5.7 | RESPONSE (responseStatus/portfolioLink/Media) | **READY** | schema.prisma:803-804 (responseStatus, portfolioLink) |
| 5.8 | RESUME-блоки | **READY** | src/lib/services/resume-blocks-service.ts; API /api/resumes/[id]/blocks; E2E 200/422 зафиксирован |
| 5.9 | SEARCH_PREF (капа 5, AuditLog) | **READY** | src/lib/services/search-preference-service.ts; API /api/search-prefs[/:id]; UI job-facets-panel.tsx:261-291 |
| 5.10 | VIEW_LOG (дедуп/день + календарь) | **READY** | /api/jobs/[id]/view-log, /api/jobs/view-log/calendar; UI job-facets-panel.tsx:100 |
| 5.11 | Фильтры 10 секций с агрегациями | **READY** | src/lib/services/job-filters-service.ts:10-13 (ровно 10 секций), фильтр-where :31-58; API /api/jobs/facets; UI job-facets-panel.tsx:89, 131 |
| 5.12 | Radar (3/7/30/90, гейт <7 дней = честный отказ) | **READY** | src/lib/services/opportunity-radar.ts:16 (4 горизонта), :132-136 (dataSufficient<7 дней → пустой прогноз), RMI :43-76; API /api/opportunities/radar; UI job-facets-panel.tsx:98 (блок RADAR в разделе «Работа»). Оговорка: Lead Time цели ≥5 дней не гарантирует (по факту платформы 3 дн. — specs/wave-5/E2E-REPORT.md:24) — честно |

**Итог Wave 5:** READY 10 · PARTIAL 2 (5.4, 5.5) · DOC-MISMATCH 1 (5.5 CareerBERT/метрика).

---

## 5. ВОЛНА 6 (S-131…S-155) — Governance hardening + Scale-prep

| # | Обещание | Вердикт | Факт (file:line) |
|---|----------|---------|------------------|
| 6.1 | 2-of-N critical approval | **READY** (с оговоркой MVP) | src/lib/ai-governance/governance-service.ts:243-335: дедуп подтвердителей :294-296, статус pending до второго :298-306, expire :260-267, reject любым → rejected :268-291, аудит first_of_two/approved_2of2 :311-333; E2E через HTTP подтверждён specs/wave-6. Оговорка: запрашивающий считается первым подтверждающим (:244-245, задокументировано), т.е. критическое действие требует «автор+1 любой аутентифицированный» |
| 6.2 | Подпись/версионирование политик HMAC | **PARTIAL** | policySignature HMAC-SHA256 есть: src/lib/ai-governance/policy-engine.ts:19-32 (env-ключ + dev-fallback). Использование: подпись пишется в метаданные аудита при смене автономии (governance-service.ts:607) и в тестах. НО: верификации подписи при чтении/исполнении политик нет, версионированного хранилища политик нет — подпись фактически метка, а не контроль целостности политик |
| 6.3 | immutable-audit hash-chain | **READY** | src/lib/data-vault/audit-log.ts:75-123 (chainHash = SHA256(prev\|…\|ts), монотонные метки :27-28, :92-96, мьютекс flush :70-73), verifyChain :129-156; API /api/admin/audit-verify; тесты tamper (wave6-governance, wave6-adversarial) |
| 6.4 | user-prohibitions сильнее полномочий | **READY** | policy-engine.ts:70-85 (проверка ДО authority, поддержка '\*'); модель UserProhibition (prisma/schema.prisma:2567); adversarial-тест prohibition-bypass |
| 6.5 | kill-switch (env+файл+API) вне AI-контура | **READY** | policy-engine.ts:42-49 (env BIZON_AI_AUTONOMY_KILLED + файл .bizon-ai-killed, проверяется на каждом evaluateAction); API /api/admin/kill-switch:19-54 (POST без BIZON_ADMIN_TOKEN → 403, аудит AI_KILL_SWITCH_*); docs/KILL-SWITCH.md. DOC-мелочь: specs/wave-6/GATES.md:3 заявляет файл src/lib/security/kill-switch.ts — его не существует (логика в policy-engine) |
| 6.6 | MAOK L2/L3 + HOP anti-creeping | **READY** | governance-service.ts:544-596: ANTI_CREEPING (агент не повышает уровень, :550-565), TIER_TOO_LOW (basic→1, verified→3, pro/business→4, :580), escalationRule с antiCreeping :596; режимы delegated/autopilot честно закрыты до пилота (api/me/autonomy/route.ts:24-26) |
| 6.7 | IL-слайдер 0..4 с тир-гейтами | **READY** | PATCH /api/ai/autonomy (src/app/api/ai/autonomy/route.ts:12-28, server-side гейты); UI-слайдер: src/components/settings/decision-inbox.tsx:116-196 (подпись «basic→1, verified→3, pro/business→4»); E2E-скриншот e2e-slider.png |
| 6.8 | memory-security consent-гейт | **READY** | src/lib/sovereignty/gateway.ts:124-135 (без consentAiAnalysis поля класса A не идут в AI); инсайты: bizon-moment-service.ts:161-183 (двойной гейт optIn+consent); тест wave6-governance:194-202 |
| 6.9 | VC-экспорт W3C | **PARTIAL** | Структура W3C VC есть (@context/type/issuer/credentialSubject/proof): src/lib/services/vc-export-service.ts:16-28, :79-108; только verified-данные :53, :66; честный empty :59. НО proof = HMAC-SHA256 «HmacSignature2024» (:76-86) — НЕ стандартный W3C proof (DataIntegrityProof/Ed25519), внешняя верификация требует секрета платформы; файл сам это документирует :5-7. DID внутренний синтаксис |
| 6.10 | Web-push VAPID (честный NOT_CONFIGURED) | **PARTIAL, путь отправки = MOCK** | Подписки пишутся: web-push-service.ts:18-34; без ключей честный VAPID_NOT_CONFIGURED :47-49 — заявка «честный NOT_CONFIGURED» в плане соответствует дефолту. НО при настроенных ключах send() возвращает `{ok:true, sent:0}` БЕЗ отправки (:50-56, RFC 8291 не реализован — «подключается библиотекой web-push в рамках ADR» :51-52). Это fake-success (запрещён §16) — после включения ключей потребитель получит ложный успех |
| 6.11 | SEO: p/[token], c/[token], sitemap | **PARTIAL** | Страницы есть: src/app/p/[token]/page.tsx, src/app/c/[token]/page.tsx (+api/p/[token], api/c/[token]). sitemap.ts статичен — только base и /#login (src/app/sitemap.ts:6-22); динамическая часть entityUrls() (:29-60) НЕ подключена ни к одному роуту: /sitemap-entities.xml не существует (glob src/app → только sitemap.ts). Динамический sitemap — мёртвый код |
| 6.12 | outbox event-bus | **PARTIAL** | Сервис корректен: src/lib/services/outbox-service.ts:12-71 (enqueue, drain с guard-захватом и attempts, идемпотентность, stats); админ-API /api/admin/outbox; тесты wave6-governance:151-154. НО продюсеров в бизнес-коде НЕТ: `OutboxService.enqueue` вызывается только из тестов (grep по src/app+src/lib — 0 вызовов). Очередь в проде всегда пуста; события шины публикуются напрямую через EventBus. Это scale-prep-каркас, не работающий механизм |

**Итог Wave 6:** READY 8 · PARTIAL 4 (6.2, 6.9, 6.10, 6.11, 6.12 — 5 позиций). Ядро governance (6.1, 6.3–6.8) — реальное и протестированное; периферия scale-prep — каркасы.

---

## 6. Список DOC-MISMATCH (заявлено ≠ реализовано)

1. **«LSTM/Prophet v1»** (S-055) → фактически Holt-эвристика «v1-prophet-lite» (model-interfaces.ts:214, 220); LSTM/Prophet-кода нет. Оценка честная как эвристика, но формулировка гейта в Плане/журнале вводит в заблуждение.
2. **«GNN-анти-фрауд v2 + эмбеддинг-синхронность, FPR ≤2%»** (S-057) → Jaccard/union-find на токенах (fraud-text-sync.ts:44-92); эмбеддингов нет; FPR ≤2% не измерен (нет ни выборки, ни процента — только 2-3 бинарных теста).
3. **«Career BERT v1»** (План-v2/оверлей §8.1: «v1 = готовые sentence-embeddings») → heuristic-v0 skill-overlap (career-matcher.ts:51-98); embeddings нет.
4. **«Precision@Top3 = 0.979»** → воспроизводится, но ground truth = тот же skill-overlap, что ранжирует эвристика (jobs-matcher-eval.ts:50-56) — циркулярная метрика; в PLAN-V2-STEPS.md:79 подана без оговорки (в worklog:2815 оговорка есть).
5. **«cron-гипотезы»** → планировщика нет; ручной POST + rate-limit (hypotheses/run/route.ts); cron-инструкции существуют только как комментарии в scripts/cron-insights.js:15-24 (и те — для CoachInsight, не для гипотез).
6. **specs/wave-6/GATES.md:3** перечисляет `src/lib/security/kill-switch.ts` — файла нет; kill-switch живёт в ai-governance/policy-engine.ts.

## 7. Список MISSING / MOCK (функциональность без прод-контура)

- **MOCK:** Web-push `send()` при настроенных VAPID-ключах возвращает ok:true/sent:0 без отправки (web-push-service.ts:50-56).
- **MISSING (интеграция, код есть):** `estimateReputation` — нет API/UI; `detectTextSync` — не вызывается анти-фродом/постами; `CommunityPermissions.banMember/setRole` — нет API-роутов (модерация сообществ недоступна); `/api/opportunities/related` — нет UI; `entityUrls()` (sitemap) — нет роута; `OutboxService.enqueue` — нет продюсеров; `/api/hypotheses` — нет UI и планировщика.
- Ни один из этих модулей не помечен в коде как «не подключён» — вне тестов они не исполняются (риск «мёртвых» сниппетов, §16 unused abstraction).

## 8. Что подтверждено как реальное (позитив аудита)

- LOT-эскроу: guard-захват + эскроу + компенсации — образцовый код (lot-service.ts:158-219, 236-307).
- AI-экономика: реестр/бюджет/кэш реально встроены в каждый вызов gateway (gateway.ts:227-361), race-safe метринг.
- Governance-ядро: 2-of-N через HTTP, hash-chain с verifyChain, prohibitions, kill-switch env+файл+API, IL-слайдер с серверными тир-гейтами — всё живое и покрыто тестами (18/18 re-run).
- §3.3 (никаких публичных чисел доверия) соблюдён последовательно: scoreInternal не сериализуется, weight-0 телеметрия, Radar RMI внутренний.
- Все пересчитанные тесты (91 кейс волн 3–6) и оба eval воспроизводятся; GATES-файлы содержат автоматизированные чеки с evidence.

## 9. ТОП-5 проблем

1. **ML-маскарад:** три ключевые «ML-фичи» волн 3/5 (LSTM/Prophet, GNN v2, Career BERT) — детерминированные эвристики; две из трёх (Reputation Estimator, fraud-text-sync) к тому же не подключены к продукту — их READY-статус в волнах завышен.
2. **Циркулярный eval:** Precision@Top3=0.979 измерен против ground truth, совпадающего с сигналом эвристики (skill-overlap) — доказательство качества матчинга по факту отсутствует; журнал шагов подал его без оговорки.
3. **FPR ≤2% не измерен:** анти-фрауд-гейт волны 3 провален тихо — «FPR-замер» сведён к 2-3 ручным тест-кейсам, а сам детектор не встроен в прод-контур.
4. **Fake-success в web-push:** при появлении VAPID-ключей send() вернёт успех без отправки (§16 нарушение; сейчас маскируется честным NOT_CONFIGURED).
5. **Каркасное scale-prep/governance-периферия:** outbox без продюсеров, sitemap-entities без роута, HMAC-подпись политик без верификации, /related без UI — шаги закрыты в журнале, но прод-ценности не дают.

## 10. Сводный счёт (волны 3–6, 32 проверенных обещания)

| Вердикт | Кол-во | Позиции |
|---------|--------|---------|
| READY | 21 | 3.1-3.5, 3.10, 3.11, 4.1-4.7, 5.1-5.3, 5.6-5.12, 6.1, 6.3-6.8 (частично пересчёт по группам выше) |
| PARTIAL | 10 | 3.6, 3.7, 3.8, 3.9, 3.12, 5.4, 5.5, 6.2, 6.9, 6.11, 6.12 |
| MOCK | 1 | 6.10 (путь отправки web-push) |
| DOC-MISMATCH | 6 | LSTM/Prophet, GNN/FPR, CareerBERT, Precision@0.979, cron-гипотезы, kill-switch.ts |
| MISSING | — | как отдельная категория не встречается; входит в PARTIAL как «нет интеграции» |

**Вердикт по волнам:**
- Wave 3: PARTIAL (ядро READY; ML-обещания — эвристики/не интегрированы; «cron» отсутствует)
- Wave 4: **READY** (полностью подтверждено)
- Wave 5: PARTIAL (движок READY; /related без UI; CareerMatcher-метрика циркулярна)
- Wave 6: PARTIAL (governance-ядро READY; scale-prep — каркасы; web-push send = MOCK)

Заявление «155/155, ALL MET» для волн 3–6 в части «метрики ML достигнуты» и «scale-prep работает» не подтверждается; в части Wave 4 и governance-ядра Wave 6 — подтверждается.

---

*Отчёт составлен только по чтению; код, схема и конфиги не изменялись. Все ссылки file:line проверены на момент аудита.*
