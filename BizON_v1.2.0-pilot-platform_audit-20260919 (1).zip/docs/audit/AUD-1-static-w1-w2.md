# AUD-1 — Статический аудит Волн 1–2 (План-v2) — ВНЕШНИЙ АУДИТОР

- Дата аудита: только чтение кода/схемы/доков; код, схема и конфиги НЕ менялись.
- Зона: **Wave 1 «Кольцо доверия» (S-001…S-028)** и **Wave 2 «Store MVP» (S-029…S-045)**.
- Эталон: `docs/PLAN-V2-STEPS.md` (строки 7–56), `docs/План-v2.md` §6–§7 (Sarafan), §18 (Store), `docs/GITHUB-ENGINEERING-PROTOCOL-v2.md` §12, §13, §16, §21.
- Вердикты строго по §21: READY / PARTIAL / BLOCKED / MISSING / MOCK / DOCUMENTED / DOC-MISMATCH / REVIEW.
- Метод: сопоставление «обещание (worklog + реестр шагов) → факт в коде (file:line)». Тесты НЕ запускались (статический аудит), оценивалось наличие/полнота/связность кода и доказательств.

---

## 1. Источники заявлений (что владелец заявил)

- `worklog.md` (Task wave1-S001-S004 / wave1-S005-S019 / wave1-S020-S028): «S-001…S-028 = 28/28 DONE, гейты 9/9 ALL MET», статус волны «READY (ядро) + PARTIAL (eval-статистика, мобильная визуальная проверка)».
- `worklog.md` (Task wave2-S029-S045): «S-029…S-045 = 17/17 DONE, гейты 9/9 ALL MET, E2E PASS».
- `docs/PLAN-V2-STEPS.md:75-76` — журнал статусов: обе волны DONE, ALL MET 9/9.

---

## 2. ВЕРДИКТЫ — ВОЛНА 1 «Кольцо доверия» (28 шагов)

| Шаг(и) | Обещание | Вердикт | Доказательство (file:line) |
|---|---|---|---|
| S-001 | specs/wave-1/GATES.md (unlazy-гейты) | **READY** | `specs/wave-1/GATES.md:1-60` — G1…G9 в CHECK/EXPECT-формате с SHA256-evidence |
| S-002 | REFERENCE_PATTERN-карточки (graphology/networkx) | **DOCUMENTED** | только `worklog.md` (строки ~2668–2669); отдельного файла карточек нет — DoD допускает worklog |
| S-003 | 14 вопросов по IntroductionRequest | **DOCUMENTED** | `worklog.md` (~2670) — все 14 ответов в тексте |
| S-004 | ADR-001 цикл интро | **READY** | `docs/adr/adr-intro-cycle.md` существует; конкурсы/причины отклонения в шапке |
| S-005 | Recommendation + relationshipType/evidenceIds/scope/expiresAt/conflictOfInterest | **READY** | `prisma/schema.prisma:2195-2199` (все 5 полей) |
| S-006 | Connection + type/provenance/discoverable/lastVerifiedAt | **READY** (с задокументированным отклонением) | `prisma/schema.prisma:713-716`; поле названо `kind` вместо `type` (коллизия с Recommendation.type), отклонение помечено в схеме и worklog |
| S-007 | Модель IntroductionRequest + индексы | **READY** | `prisma/schema.prisma:259-280` (3 FK, 4 индекса, expiresAt) |
| S-008 | TrustPropagationModel v0 (BFS + decay + XAI) | **READY** | `src/lib/trust/model-interfaces.ts:30-85`; decay-перевзвешивание :51-77 |
| S-009 | AnomalyDetector / TrendForecastModel интерфейсы | **READY** | `src/lib/trust/model-interfaces.ts:114-142` (rules), :159-209 (v0-linear) |
| S-010 | Фичевый пайплайн (лог с первого дня) | **READY** | `src/lib/trust/feature-log.ts:30,69,89`; модель `TrainingExample` `schema.prisma:285-295`; вызовы из `intro-service.ts:129` и `sarafan-guard.ts:69` |
| S-011 | intro-service: create/accept/decline/expireSweep | **READY** | `src/lib/services/intro-service.ts:45-149` (гварды self/dup/404/guard), :152-214 (accept: сообщение ТОЛЬКО после accept :167-176; ReputationEvent :198-206), :217-242 (decline, текст не уходит), :245-259 (sweep) |
| S-012 | sarafan-guard: взаимность ≤24ч, кольца DFS, массовость, возраст; FAIL-OPEN | **READY** | `src/lib/services/sarafan-guard.ts:43-63` (взаимность 24ч + скорость + возраст/тир), :103-134 (DFS колец ≤4), FAIL-OPEN :87-91 и :130-133. «Массовость» покрыта счётчиками час/день — приемлемо |
| S-013 | kind-теги + CONTACT_RECO (reason-словарь + score) | **DOC-MISMATCH** | Словарь/скор есть: `src/lib/trust/contact-reasons.ts:9-97`; НО `computeContactReasons` не вызывается НИГДЕ в `src/` (grep: единственное вхождение — сам файл) → dead code (§16 запрещает unused abstraction). DoD «причина рекомендации из словаря [видна]» не выполнен |
| S-014 | Decay W=W0·exp(−λΔt) + re-strengthening | **READY** | `src/lib/trust/decay.ts:11,31-48`; re-strengthening API `src/app/api/connections/[id]/verify/route.ts:27-30`; тесты полураспада `tests/wave1-trust.test.ts:26-45` |
| S-015 | /api/intros POST/GET + accept/decline + registry/audit/rate-limit | **READY** | `src/app/api/intros/route.ts:19-34,36-71`; `.../[id]/accept/route.ts`, `.../[id]/decline/route.ts`; velocity :25-27; REQUEST_INTRO в `src/lib/ai-governance/action-registry.ts:64` |
| S-016 | verificationTier + консент-флоу + NO_REPUTATION | **READY** | `schema.prisma:247`; `src/app/api/auth/verify-email/route.ts:41` (tier=contact_verified); `src/lib/security/anti-fraud.ts:469` (NO_REPUTATION только для basic) |
| S-017 | Honeypot + device fingerprint (хэш, без PII) | **READY** | `src/app/api/auth/register/route.ts:37-40` (тихий fake-ok боту), :99-104 (sha256(UA\|lang\|/24) → AuditLog REGISTER_DEVICE) |
| S-018 | Velocity-чеки с тирами | **READY** | `src/lib/security/velocity.ts:26-30` (basic = /4); применено в intros (`route.ts:25`), store book (`book/route.ts:21`), complaints (`route.ts:27`) |
| S-019 | Единый компонент жалоб (7 категорий): компонент + API + тесты | **DOC-MISMATCH** (PARTIAL) | API реален: `schema.prisma:300-316`, `src/app/api/complaints/route.ts:13-75` (7 категорий, дедуп :32-36, admin-гейт :60-63). НО: (а) UI-компонента, вызывающего `/api/complaints`, не существует — единственная кнопка «Пожаловаться» показывает тост «Жалоба отправлена» БЕЗ вызова API (`src/components/common/three-dots-menu.tsx:35`) = fake success (запрещено §16); (б) тестов на Complaint нет (grep по `tests/` — 0). DoD выполнен на 1/3 |
| S-020 | AuthorChip + уровневые цвета | **READY** | `src/components/trust/author-chip.tsx`; `src/lib/trust/author-level.ts`; подключение: `src/lib/services/passport-service.ts:386`, `src/app/p/[token]/page.tsx:930`; тесты `wave1-trust.test.ts:50-60` |
| S-021 | Карточка «Путь: Вы → Анна → Игорь, **запросить знакомство**» + интро в уведомления + блок network-view | **DOC-MISMATCH** (PARTIAL) | IntroInbox (сторона посредника) реален и смонтирован: `src/components/trust/intro-inbox.tsx:36-61`, `network-view.tsx:18,90`. Путь рисуется: `src/components/profile/public-persona.tsx:928-1022` (TrustChainBlock, «Через N можно попросить интро» :1019-1021). НО: **ни один клиентский компонент не вызывает POST /api/intros** (grep `/api/intros` в `src/` — только intro-inbox GET/accept/decline) → кнопки «Запросить знакомство» нет, полный цикл в UI НЕ видим (DoD нарушен) |
| S-022 | BIZCARD: QR server-side + «PDF A6» | **PARTIAL** | API: `src/app/api/me/bizcard/route.ts:47-48` (QR server-side, email только подтверждённый :56); UI: `src/components/trust/bizcard-dialog.tsx:85` (print:a6), смонтирован `network-view.tsx:213`. «Скачивается» именно PDF-файл — нет: реализован `window.print()`; план говорил «QR+PDF» — трактовка через печать, отклонение нигде не помечено |
| S-023 | Два режима профиля (contact/stranger), режим определяет СЕРВЕР | **DOC-MISMATCH** (PARTIAL) | API реален и серверный: `src/app/api/me/relationship/[userId]/route.ts:10-35` (verifiedRecently словами :31). НО клиент нигде не вызывает `/api/me/relationship` (grep — только сам роут) → двухрежимного профиля в UI не существует |
| S-024 | Юнит-тесты intro/guard/decay | **READY** | `tests/wave1-trust.test.ts` — 16 кейсов по описи worklog (decay :18-46, author-level :50-60, forecast :64-78, anomaly :82-95, гварды :99-154) |
| S-025 | MATCHMAKER_EVAL + SARAFAN_RECOMMENDATION_EVAL в tools/evals; метрики измерены | **PARTIAL** | `tools/evals/matchmaker-eval.ts` существует (recall/FPR/latency/XAI :56-64); числа в worklog (38 сэмплов, recall 1.0, FPR 0.389, p50 4мс/p95 23мс), статус честно NOT READY по §12. НО: (а) **SARAFAN_RECOMMENDATION_EVAL как файл отсутствует** (`ls tools/evals/` — только matchmaker/jobs-matcher/skill-futures; имя упомянуто лишь в заголовке matchmaker-eval.ts:1 как «shared»); (б) precision/cost/groundedness не измерены; (в) результаты нигде не сохранены как артефакт (только worklog) |
| S-026 | Adversarial: массовые интро, self-intro, обход consent, фейковые кольца — BLOCKED | **READY** (с оговоркой) | `tests/wave1-adversarial.test.ts` — 5 проб: кольца DFS :35-46, 6 интро/час :50-72, reciprocal observe :74-88, velocity-тиры :92-102. Само-intro/consent покрыты в `wave1-trust.test.ts:111-129`. Оговорка: honeypot-кейс заявлен в шапке файла :5, но теста на него нет |
| S-027 | Браузерная E2E золотого пути + мобильная 390px | **PARTIAL** | Скрипт/отчёт E2E Wave-1 НЕ сохранены (`specs/wave-1/` — только GATES.md; в `tests/e2e/` лишь smoke-тесты). Доказательства — только подробный текст в worklog (201/400/409/200, сообщение после accept, ReputationEvent ×1). Мобильная 390px честно признана незавершённой. Слабее доказательной базы Wave 2 |
| S-028 | gate-check ALL MET → §21-отчёт | **READY** (с оговоркой к качеству гейтов) | `specs/wave-1/GATES.md` — все G1…G9 [x] с EVIDENCE-строками. Оговорка: G9 проверяет только grep-наличие компонентов (`GATES.md:57-59`) — интеграционные дыры S-019/S-021/S-023 гейт по построению не ловит |

**Итог Wave 1:** 19 READY · 2 DOCUMENTED · 3 PARTIAL (S-022, S-025, S-027) · 4 DOC-MISMATCH (S-013, S-019, S-021, S-023) · 0 MOCK · 0 MISSING. Заявление worklog «S-013/S-019/S-021/S-023 DONE» — завышено; собственная оговорка волны «READY (ядро) + PARTIAL» точнее, но PARTIAL-перечень неполон.

---

## 3. ВЕРДИКТЫ — ВОЛНА 2 «Store MVP» (17 шагов, 9 блоков)

| Блок | Обещание | Вердикт | Доказательство (file:line) |
|---|---|---|---|
| S-029 | ADR-002 + GATES Wave-2 | **READY** | `docs/adr/adr-store-item.md` (14-вопрос, отклонённые A/C с причинами); `specs/wave-2/GATES.md` G1…G9 с EVIDENCE |
| S-030…S-033 | Схема StoreItem/StoreBooking + Event.targeting | **READY** | `prisma/schema.prisma:354-378` (StoreItem: type/priceLumens/deliveryMode/evidenceRefs/verificationStatus/isPremium/slots), :384-408 (StoreBooking: held→…, spendTxId, releaseTxId @unique :392, slotAt), :1002 (Event.targeting) |
| S-034…S-037 | API + люмены/payment-service (мок), эскроу FIX-06 | **READY** | `src/lib/services/store-service.ts`: requestBooking :274-360 (self-purchase :287, 402 insufficient :322-324, гонка слотов updateMany :331-359), release :438-470 (credit+guard в одной $transaction), decline/cancel :501-585, sweepStale :645+. LumenService: `spendVar` :505 (escrow=true в ledger :528), `refundVar` :545 (refundOf @unique :558), `credit` :601. 8 роутов `/api/store/**` существуют (items, items/[id], items/[id]/book, bookings, bookings/[id]/{fulfil,decline,release,cancel}), все через withRoute+zod+velocity (пример: `book/route.ts:14-23`); SPEND_MONEY governance: `store-service.ts:282`. **Payment-мок честный**: `payment-service.ts:146-214` DemoGateway (песочник, paymentMethod='manual'), :223-253 ExternalGatewayAdapter — структурированный `unavailable`, успех не имитируется |
| S-038…S-040 | UI: витрина + Мои товары + Заказы + «Как со мной работать» | **READY** | `src/components/store/store-view.tsx` (все вызовы к реальным API: :145, :232, :247, :330, :431, :444); `store-section.tsx:70` (book), :192-235 («Как со мной работать»); смонтировано: `src/app/page.tsx:143`, `src/components/profile/profile-view.tsx:507-508`; статус кассы UI: `store-view.tsx:83` → `/api/cashier/status` (`src/app/api/cashier/status/route.ts:16-24`) |
| S-041 | Premium-поверхности (is_premium, таргетинг мероприятий) | **READY** | `store-service.ts:148-153` (premium-гейт Pro/Business + капа 20), premium-first `listItems` :183; `src/app/api/events/route.ts:20,98,119-121` (targeting-схема + sanitize) |
| S-042 | Adversarial «купленная рекомендация не влияет на trust» | **READY** | `tests/wave2-adversarial.test.ts` — 4 пробы: 3 цикла сделок не создают Connection/Recommendation и не меняют matchmaker :50-88; ipScore не растёт :90-104; velocity basic-третья покупка BLOCKED :106-119; деньги только после release покупателя :121-145. Пробы реально существуют, не «слова» |
| S-043 | E2E браузером, балансы сходятся | **READY** | `specs/wave-2/E2E-REPORT.md` (10 шагов, балансы 500→380 / 0→120, anti-fake шаг 8); артефакты: `specs/wave-2/e2e-1-myitems.png`, `e2e-2-mobile-390.png`, cookie-jar'ы `seller.jar`/`buyer.jar` (Netscape cookies — реальные сессии) |
| S-044 | KYC-гейт реального шлюза (документация) | **READY** | `docs/KYC-REAL-GATEWAY-GATE.md` (8 условий + порядок включения + запреты); код-гейт: `virtual-cashier-service.ts:147-179` (realMoneyGate, conditionsMet всегда false), kill-switch STORE_REAL_MONEY_ENABLED :112 |
| S-045 | §21-отчёт, gate-check ALL MET | **READY** | `specs/wave-2/GATES.md` G1…G9 [x] + EVIDENCE; задокументирован пойманный гейтом баг RateLimiter.reset |

**Итог Wave 2:** 9/9 блоков READY (17/17 шагов подтверждено по существу). Wave 2 — самая честно доказанная часть: схема+сервис+API+UI+adversarial+E2E-артефакты согласованы между собой. Претензий по существу нет; замечание одно — комиссия 0% и фиат-эскроу осознанно в decision queue (не блокирует).

---

## 4. DOC-MISMATCH (заявлено DONE — фактически X)

1. **S-019 (жалобы)**: заявлено «DONE» → UI-компонент жалоб отсутствует; `three-dots-menu.tsx:35` имитирует успех тостом без вызова `/api/complaints` (fake success, §16); тестов нет. DoD «компонент + API + тесты» выполнен на 1/3.
2. **S-021 (интро-UI)**: заявлено «DONE, полный цикл виден в UI» → в UI невозможно СОЗДАТЬ интро-запрос: нет кнопки «Запросить знакомство», POST /api/intros не вызывается ни из одного компонента. Виден только путь (TrustChainBlock) и инбокс посредника. «Путь: Вы → Анна → Игорь» есть, «запросить знакомство» — нет.
3. **S-023 (contact/stranger)**: заявлено «DONE» → API-режим определяет сервер корректно, но UI его не потребляет (`/api/me/relationship` не вызывается нигде в `src/components`) — двухрежимного профиля нет.
4. **S-013 (CONTACT_RECO)**: заявлено «DONE» → `computeContactReasons` — dead code без единого потребителя; «причина из словаря» пользователю нигде не показывается.
5. **S-025 (evals)**: заявлено «MATCHMAKER_EVAL + SARAFAN_RECOMMENDATION_EVAL в tools/evals» → SARAFAN_RECOMMENDATION_EVAL-файла нет; precision/cost не измерены; результаты прогона не сохранены как артефакт.
6. **S-022 (BIZCARD «PDF A6»)**: реализована печать (window.print), файла PDF нет — отклонение от буквы плана не помечено.
7. **Wave-1 заголовок `tests/wave1-adversarial.test.ts:5`** обещает honeypot-пробу — самого теста в файле нет (5-й тест — velocity).
8. **Связность intro→Connection (не шаг, но обещание §7.6)**: цепочка «RELATIONSHIP CREATED → recommendation carries provenance» не замкнута: `Connection.provenance` нигде не устанавливается в 'intro'/'sarafan' (`src/app/api/connections/route.ts:88-90` создаёт связи с дефолтом 'manual'), поэтому ветка веса 0.7 (`model-interfaces.ts:67`) и поле provenance в relationship-роуте — мёртвые ветки; после accept интро Connection вообще не создаётся (только Conversation).

## 5. MISSING / MOCK

- **MOCK в рантайме: 0.** Демо-шлюзы честно помечены (`payment-service.ts:12-16`, `virtual-cashier-service.ts:267-295`); External — unavailable, успех не имитируется (соответствует §16/§21).
- MISSING-элементы (подмножества шагов, а не целые шаги):
  - UI-создание интро-запроса (S-021);
  - UI-компонент жалоб, подключённый к API (S-019);
  - UI-потребитель relationship-режима (S-023);
  - SARAFAN_RECOMMENDATION_EVAL как отдельный бенчмарк (S-025);
  - persist-артефакты E2E Wave 1 (скрипт/отчёт/скриншоты) и мобильная проверка 390px (S-027);
  - присвоение provenance='intro'/'sarafan' при создании связей.

## 6. ТОП-5 проблем (по серьёзности)

1. **Fake success в модерации**: кнопка «Пожаловаться» рапортует «Жалоба отправлена» без вызова API — пользователь считает жалобу поданной, а единого модерационного контура для него фактически не существует (three-dots-menu.tsx:35; прямой запрет §16).
2. **Главный UX-цикл Волны 1 не замкнут в UI**: создать IntroductionRequest можно только прямым API-вызовом; ключевая кнопка волны «Запросить знакомство» в интерфейсе отсутствует — дифференциация «5 Handshakes» недоступна обычному пользователю без devtools.
3. **Dead-код/не замкнутый провенанс доверия**: computeContactReasons и provenance='intro'/'sarafan' не подключены — XAI-«почему рекомендован контакт» и вес intro-ребра никогда не срабатывают (contact-reasons.ts; connections/route.ts:88-90).
4. **API без UI (S-023)**: серверный contact/stranger-гейт построен по принципу «решает сервер», но фронтенд его не использует — обещанный двухрежимный профиль отсутствует.
5. **Доказательная база Wave 1 слабее заявленной**: SARAFAN_RECOMMENDATION_EVAL отсутствует, результаты eval не сохранены, E2E-отчёт/скрипты Wave 1 не persisted (в отличие от Wave 2), honeypot-проба декларирована, но не написана.

## 7. Замечания к процессу приёмки

- Гейты G9 (обе волны) проверяют интеграцию UI grep'ом по файлам (`specs/wave-1/GATES.md:57-59`) — «компонент импортирован» ≠ «цикл работает»; поэтому 4 DOC-MISMATCH прошли через «ALL MET 9/9». Рекомендация: гейт UI-интеграции = хотя бы один Playwright-тест на пользовательское действие (создание интро, подача жалобы, смена режима профиля).
- Положительные образцы честности: собственная пометка волны «READY + PARTIAL, не завышаем» (worklog), NOT READY eval по §12, ExternalGatewayAdapter без имитации успеха, E2E-отчёт Wave 2 с anti-fake-шагами и артефактами.

## 8. Сводка

| Метрика | Wave 1 | Wave 2 |
|---|---|---|
| Шагов проверено | 28 | 17 (9 блоков) |
| READY | 19 | 9 блоков (17 шагов) |
| PARTIAL | 3 | 0 |
| DOC-MISMATCH | 4 | 0 |
| DOCUMENTED | 2 | 0 |
| MOCK / MISSING / BLOCKED | 0 / 0 / 0 | 0 / 0 / 0 |
| Вердикт аудита | **PARTIAL** (ядро бэкенда READY; UI-интеграция и eval-контур недоукомплектованы) | **READY** |
