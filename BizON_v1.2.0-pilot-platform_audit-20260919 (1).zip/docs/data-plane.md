# BizON v6 — Data Plane: Shard-Ready + RU Data Plane (152-ФЗ)

Task 9-e · doc_scaling п.9 (Shard-Ready) и п.13 (Региональный роутинг данных / RU Data Plane) · закрытые аудитом пробелы `/tmp/audit_scaling.md` №9 и №13 (оба были «❌ НЕ НАЙДЕНО»).

## 1. Что это и зачем

Стратегия doc_scaling требует двух фундаментов:

- **DATA → где хранится**: данные граждан РФ хранятся и первично обрабатываются на территории РФ (ст. 18 ч. 5 152-ФЗ), публичные/обезличенные данные и тяжёлые batch-вычисления могут уходить на дешёвые внешние мощности.
- **SHARD → где находится его данные**: база проектируется Shard-Ready с первого дня («v6 должен сразу проектироваться с учётом будущего sharding, даже если на старте будет один PostgreSQL cluster»), чтобы до миллиардов пользователей можно было дорасти без переделки Data Plane.

Модули (все новые файлы, существующий код не изменялся):

| Файл | Роль |
|---|---|
| `src/lib/data-plane/shard.ts` | Consistent-hash ring: SHA-256, 160 виртуальных узлов на единицу веса шарда; чистые функции `buildRing` / `resolveShard` / `shardDistribution` / `redistributeStats`; shard-ключи `userId` / `companyId` / `jobId` |
| `src/lib/data-plane/config.ts` | Топология: плоскости `ru-primary` / `global-compute`, шарды (id, weight, plane, target), таблица residency-правил, флаг `sandbox.localBinding=true` |
| `src/lib/data-plane/region-router.ts` | Политика residency: `(dataClass, владелец, operation) → плоскость` с явным решением (ruleId + причина), fail-closed, in-memory журнал решений с TTL, обезличивание через Sovereignty (read-only) |
| `src/lib/data-plane/repository.ts` | Фасад `DataPlaneRepository` (get/set/delete с контекстом `entity/id/dataClass/owner`) + `LocalSqliteBinding` — единственная реализация |
| `src/app/api/admin/data-plane/route.ts` | `GET` — статус: топология, статистика ring, активная политика, журнал решений, самотест политики |
| `scripts/dataplane-ring-check.ts` | Ops-проверка ring (детерминизм ×1000, равномерность, ~1/N перераспределение, веса, обезличивание) |

## 2. Архитектура

```
вызов get/set/delete(entity, id, dataClass, owner)
        │
        ▼
region-router.decidePlane          ← residency-политика (152-ФЗ/GDPR/none × класс A/B/C × операция)
        │  решение: plane + ruleId + причина  (+ журнал решений, TTL 1 ч)
        ▼
ring = per-plane consistent hash   ← shard.ts (SHA-256, 160 vnodes/шард)
        │  shardKey = makeShardKey(kind, id); shard = resolveShard(ring, shardKey)
        ▼
binding выбранной плоскости        ← ПЕСОЧНИЦА: LocalSqliteBinding → db/custom.db
```

Ключевые принципы (дословно из doc_scaling):

1. **152-ФЗ ст. 18 ч. 5** — запись, систематизация, накопление, хранение, изменение и извлечение ПДн граждан РФ — только с использованием баз данных в РФ. Класс A граждан РФ → `ru-primary` для `storage | processing | batch` (согласие `consentCrossBorder` требование первичного хранения в РФ не отменяет — правило `RU-A-STORAGE`).
2. **Классы B/C и тяжёлые batch** — могут уходить на `global-compute` (дешёвые внешние мощности) при выполнении условий: класс B — только после обезличивания (`pseudonymized: true`); не выполнено → **fail-closed на `ru-primary`** (технически предотвращаем неправильный маршрут, а не надеемся на ручное соблюдение).
3. **Класс C** (публичное/агрегированное) — свободно на `global-compute` («для C и части B — более дешёвые мощности, не вытаскивая Restricted Data»).
4. **Каждое решение явное**: ruleId, человекочитаемая причина, crossBorder-флаг, псевдоним владельца вместо raw userId (privacy by design в самом журнале).

### Классы данных (совместно с `src/lib/sovereignty/gateway.ts`)

- **A — RESTRICTED**: email, phone, name, bio, location, birthday, ip, passwordHash → хранение/обработка по строгим правилам региона.
- **B — PROFESSIONAL**: навыки, проекты, карьерная история, verified evidence → наружу только обезличенно.
- **C — PUBLIC/AGGREGATED**: рыночная статистика, тренды навыков, публичные метаданные → дешёвые мощности.

Классы и обезличивание берутся из существующего Sovereignty Gateway **read-only** (файл не изменялся): `minimizeForAI()` удаляет email/phone/birthday/ip/passwordHash, `pseudonymizeUser()` (v6.1, Task 9-d) даёт детерминированный `anonymous_user_XXXXX` в формате doc_scaling — тот же псевдоним, что видит LLM через AIGateway, поэтому аналитика на внешней плоскости сквозная и без раскрытия личности.

### Shard-ключи (doc_scaling §17: «не все таблицы надо шардировать одинаково»)

| Сущность | Ключ | Комментарий |
|---|---|---|
| User, Post | `userId` | «User — shard by user_id» |
| Company, Project, Skill | `companyId` | «Projects — shard by company_id/project_id» |
| Job | `jobId` | вакансии принадлежат компании, но резолвятся по своему id |
| Conversation | `userId` | отдельной сущности Conversation в v6 нет; сообщения ключуются владельцем диалога |
| Events/News/Market data | вне фасада | «partition by time + region» / «глобально/регионально» / «отдельное хранилище» — когда дойдёт до шардирования, это отдельные плоскости, не generic CRUD |

## 3. Residency-правила (активная политика)

Первое сматчировшее правило выигрывает; полный текст причин — в конфиге и в ответе `GET /api/admin/data-plane`.

| ruleId | когда | плоскость | условия |
|---|---|---|---|
| `RU-A-STORAGE/PROCESSING/BATCH` | 152-ФЗ, класс A, любая операция | `ru-primary` | безусловно (ст. 18 ч. 5) |
| `RU-B-STORAGE` | 152-ФЗ, класс B, storage | `ru-primary` | первичная копия — в РФ |
| `RU-B-PROCESSING/BATCH` | 152-ФЗ, класс B | `global-compute` | **только после обезличивания**, иначе fail-closed |
| `RU-C-ALL` | 152-ФЗ, класс C | `global-compute` | публичное |
| `GDPR-A-PROCESSING` | GDPR, класс A | `global-compute` | после минимизации (ст. 5 GDPR) |
| `GDPR-REST` | GDPR, класс B/C | `global-compute` | SCC/adequacy (в песочнице — метаданные) |
| `NONE-A-CONSERVATIVE` | регулятор не определён, класс A | `ru-primary` | консервативный fail-closed |
| `NONE-REST` | регулятор не определён, B/C | `global-compute` | — |

Fail-closed по умолчанию: нет правила → `ru-primary`. Регулятор выводится из `citizenship/region` владельца (RU → 152-ФЗ, EU/EEA-префиксы → GDPR, иначе none — зеркало `regulationFor()` из Sovereignty Gateway; дублирование осознанное, файл 9-d не правится).

## 4. Repository-фасад

```ts
import { getDataPlaneRepository } from '@/lib/data-plane/repository';

const repo = getDataPlaneRepository();

// Маршрут без I/O (превью): плоскость, шард, правило, причина
const route = repo.route({ entity: 'User', id: userId, dataClass: 'A', owner: { userId, citizenship: 'RU', region: 'Москва' } });

// Чтение/запись/удаление с контекстом; каждый ответ — конверт с маршрутом
const got = await repo.get(ref);                       // { ok, route, value | null, error? }
const put = await repo.set(ref, data);                 // upsert по id; payload валидирует Prisma
const del = await repo.delete(ref);                    // идемпотентно: {deleted: false}, если нет записи
```

Инварианты:

- Ошибки — честный канал `error: { code, message }` в конверте (`prisma:P2002/P2003/P2025`, `prisma-validation`, `internal`); поля молча не отбрасываются.
- `set` на `global-compute` для класса B без `pseudonymized: true` маршрутизируется fail-closed на `ru-primary` — данные физически не покинут РФ-плоскость (в проде; в песочнице обе плоскости локальны, но решение и причина фиксируются).
- Facade НЕ подключён к существующим бизнес-потокам принудительно (`wiredIntoBusinessFlows: false` в статусе) — обратная совместимость всех API сохранена на 100%.

## 5. Ограничения песочницы (честно)

1. **Физического разделения плоскостей нет.** `sandbox.localBinding = true`: обе плоскости и все 4 шарда (`shard-ru-01/02`, `shard-gc-01/02`) биндятся на единственную локальную SQLite `db/custom.db` через существующий Prisma-клиент. Реальные RU PG-кластеры и внешние compute-мощности в песочнице НЕ поднимаются.
2. **Маршрутизация — метаданные**: плоскость/шард/правило/причина в каждом ответе и в журнале решений; данные при этом не покидают локальную БД.
3. **Журнал решений in-memory** (TTL 1 ч, максимум 200 записей, globalThis-guard против hot-reload): переживает только процесс. Пока фасад не подключён к бизнес-потокам, `recentDecisions` в статусе честно пуст (`wiredIntoBusinessFlows: false` + notice).
4. **GDPR/SCC-гарантии** — декларативные: правила маркируют плоскость, договорные механизмы вне кода.
5. **160 vnodes/шард** — статистический разброс доли шарда несколько п.п. (см. вывод `scripts/dataplane-ring-check.ts`); прод-ручка — увеличить `virtualNodesPerShard`.

## 6. Как мигрировать с local-binding на реальные плоскости

### Шаг 1. RU-плоскость: SQLite → RU PostgreSQL-кластер

1. Поднять PG-кластер в РФ (RU-регион облака/ДЦ; базовая подготовка уже есть: `prisma/migrations/0001_baseline` + `migration_lock.toml` от Task 9-d, compose с postgres:16).
2. В `config.ts` заменить `target` шардов `shard-ru-*` на DSN RU-кластера (шард 1/2 — два логических шарда на одном кластере до реального партиционирования).
3. Реализовать `RuPrimaryPostgresBinding implements DataPlaneRepository` по образцу `LocalSqliteBinding` (тот же Prisma-клиент, другой `datasources`): контракты фасада не меняются.
4. Перенос данных: `pg_dump`-совместимый экспорт через Prisma → импорт; сверка residency-журнала до/после.

### Шаг 2. Global-compute: внешние дешёвые мощности

1. Поднять внешние CPU/GPU workers (batch-кластер) вне РФ.
2. Реализовать `GlobalComputeBinding`: для `set` — обязательная приёмка только обезличенных payload'ов (серверная проверка: отсутствие полей класса A по карте `FIELD_CLASS` + наличие `anonymousId` формата `anonymous_user_XXXXX`; иначе отказ, не запись).
3. `shard-gc-*` → DSN внешнего хранилища.

### Шаг 3. Подключение потребителей (постепенно, по одному потоку)

1. Заменить прямые `db.<model>.findUnique/update/delete` на `repo.get/set/delete` в ОДНОМ сервисе (например, feed) с контекстом `dataClass/owner`.
2. Сверить behavior: ответы API не меняются (те же записи из локальной SQLite), в `/api/admin/data-plane` начинают появляться реальные residency-решения.
3. Повторить для остальных потоков; после полного переключения — резолв шарда становится физической адресацией.

### Шаг 4. Включение cross-plane маршрутизации

- RU-владельцы: класс A — всегда `ru-primary`; класс B — `global-compute` только после `pseudonymizeForGlobalCompute()` (готов в `region-router.ts`).
- Регион-роутинг HTTP: пользователь → ближайший региональный API-кластер (doc_scaling LEVEL 4-5), данные — по residency, вычисления — по ComputeRouter (`src/lib/compute/router.ts`, классы REAL-TIME/INTERACTIVE/BATCH от Task 9-d).

## 7. Админ-статус: `GET /api/admin/data-plane`

Auth (паттерн `/api/metrics` v6.1 и admin-роутов проекта):

- Bearer `DATA_PLANE_TOKEN` (env) — ops/cron;
- сессия + роль `admin` в `user.roles` (CSV — существующая модель ролей);
- dev-релаксация песочницы: `NODE_ENV !== 'production'` → любой валидный session-пользователь (demo-пользователь не admin); в production релаксация отключается; без сессии → 401.

Ответ: `sandbox`, `topology` (плоскости + шарды с vnodes/target), `ringStats` (распределение 600 тестовых ключей на плоскость, макс. отклонение от равномерного, probe детерминизма 5×200), `redistribution` (2→3 шарда, ~1/(N+1)), `residency` (правила, журнал + честный empty-state notice, `recentDecisions`, самотест 9 канонических контекстов, демо обезличивания), `repository` (интерфейс/binding/сущности/`wiredIntoBusinessFlows: false`).

## 8. Верификация

- `bunx eslint src/lib/data-plane src/app/api/admin/data-plane` → 0 проблем.
- `bunx tsc --noEmit` → 0 ошибок (strict, без `any`).
- `bun scripts/dataplane-ring-check.ts` → ALL CHECKS PASSED: детерминизм 1000×, равномерность (макс. отклонение 0.42 п.п.), перераспределение 2→3 шарда ≈ 1/3, веса 1:2, формат `anonymous_user_XXXXX`.
- `curl` см. worklog Task 9-e.
