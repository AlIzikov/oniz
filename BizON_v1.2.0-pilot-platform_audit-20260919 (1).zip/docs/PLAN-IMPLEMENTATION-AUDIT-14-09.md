# План реализации по отчёту внешнего аудита → BizON v1.0.0-rc.2 → v1.1.0
**Основание**: docs/audits/2026-09-14-GPT-FULL-AUDIT-REPORT.txt (независимый балл 6.0/10; «RC для закрытого пилота, НЕ production»)
**Дата**: 2026-09-14 · **Принцип внедрения**: REUSE → EXTEND → REFACTOR → REPLACE; всё существующее продолжает работать
**Проверка отчёта**: ключевые P0-находки (DEF-15 deletedAt, DEF-06 companyFit=88 на ai.ts:464, DEF-07 random :39-40, DEF-24 auto-confirmed, DEF-18 0 governance-моделей, счётчики 77/239, withRoute 21/239) подтверждены нашим кодом независимо — аудиту можно доверять.

---

## §1. Вердикт по аудиту

**Аудит полноценный, как запрашивали.** Все 14 обязательных разделов на месте; матрица A–J полная (270 пунктов, внутренне согласована); код в ключевых REC готов к вставке (диффы REC-SEC-01/REC-TRUTH-01/REC-TRUTH-02/REC-PROJECT-03 + полные файлы REC-GOV-01..07, REC-PROJECT-01..02, REC-DOC-01); тест-кейсы формул; комплаенс РФ (152-ФЗ/161-ФЗ/реклама); план из 10 этапов с чек-листами; вердикт по нашему плану v5 (P0–P5); честная самопроверка с [НЕ ПРОВЕРЕНО В СРЕДЕ].

**Три некритических пробела** (закрываются в этом плане, §4):
1. Арифметическая опечатка в §0.2 отчёта (28/73/153/11) — правильные числа в §3: **16 READY / 70 PARTIAL / 166 MISSING / 13 DANGEROUS / 5 UNNECESSARY** (пересчитано независимо, сумма 270 ✓).
2. Часть UX-DEF (DEF-08, DEF-09…DEF-14) не получила готовых диффов — нарушение собственного правила отчёта «код обязателен».
3. Recommendation Engine (P2) и News-слой (P4) получили вердикты, но не получили ни кода, ни места в 10-этапном плане; ResearchResult (этап 4) без кода модели; миграция plaintext email (DEF-20) без кода.

---

## §2. Целевая версия и логика волн

Версия: **v1.0.0-rc.2 → rc.3 → rc.4 → v1.1.0 «Pilot Ready»** → закрытый пилот (этап 8 GPT).
Каждая волна = отдельные сессии разработки, гейт в конце: ESLint 0 errors, tsc 0, dev.log без 5xx, браузерная проверка золотых сценариев, worklog, коммит, обновление docs/handover. Откат = git revert + db:push.

| Волна | Версия | Этапы GPT | Содержание |
|---|---|---|---|
| W1 | rc.2 | Этап 1–2 | STOP THE BLEEDING: security/truth P0 + контракт API + тесты |
| W2 | rc.3 | Этап 3 (+P2 v5) | Project Evidence Engine + Recommendation Engine |
| W3 | rc.4 | Этап 5 | Governance Layer (код аудита) + Decision Inbox |
| W4 | rc.5 | Этап 4 (+P4 v5) | Intent/Research (ResearchResult) + News-слой |
| W5 | v1.1.0 | Этап 6–7 | Truthful UX завершение + Release hardening |
| W6 | pilot | Этап 8–10 | Закрытый пилот → публичный запуск → масштаб |

---

## §3. ВОЛНА 1 (rc.2) — STOP THE BLEEDING + контракт API

Гейт перехода по GPT: «только когда P0 security/product truth закрыты».

### 1.1 P0-фиксы по готовым диффам аудита (код уже в отчёте — вставляем)
1. **REC-SEC-01 (DEF-15, P0)**: `src/lib/auth.ts` — проверка `session.user.deletedAt` → удалить сессию, вернуть null. *Diff готов.*
2. **REC-TRUTH-01 (DEF-06, P0)**: `src/lib/ai.ts` — `companyFit: number | null` вместо fallback 88; `totalMatch = candidateFit` при null; правка `explainable-match-dialog.tsx` («—» вместо 88%). Заодно: строка :505 `(input.culturalFitScore ?? 88) >= 80` в whatYouGet — согласовать с null. *Diff готов + наше расширение.*
3. **REC-TRUTH-02 (DEF-07, P0)**: `interested-companies.tsx` — убрать random matchScore/openJobs; реальные `activeJobsCount` из существующего `/api/companies`. *Diff готов.*
4. **REC-PROJECT-03 (DEF-24, P0)**: `transition/route.ts` — убрать «auto-confirmed» формулировку; завершение ≠ верификация. *Diff готов.*
5. **DEF-20 (P0) — миграция plaintext email** *(пробел аудита — код наш)*: скрипт `scripts/migrate-email-encrypt.ts`: для 11/32 User с plaintext → `emailEncrypted` + `emailHash` через существующий crypto-контур (см. scripts/migrate-pii-hashes.ts как образец); запрет новых plaintext-writes; acceptance: в БД 0 plaintext email.

### 1.2 Документация и каталог (DEF-01/02/28)
6. **REC-DOC-01**: `scripts/check-audit-catalog.mjs` — код готов в отчёте; включить в lint-гейт. База: ожидаемые 77 моделей / 239 роутов в снапшоте релиза (файл `docs/audits/catalog-snapshot.json`), генерировать скриптом, не руками.
7. Обновить `docs/handover/00-README.md`, `03-data-model.md`, `04-api-catalog.md`, `06-ai-integration.md`: 80→77, 249→239 (после волны пересчитать), 15→12 SDK-refs. Правило впредь: числа только из скрипта.

### 1.3 AI-контур (DEF-17, DEF-25)
8. **REC-AI-01**: перевести 5 прямых вызовов SDK (transferable, news moderate, news-relevance, bizon-moment, career-scenario) на AIGateway. Acceptance: `rg "z-ai-web-dev-sdk" src` — только ai-core internals.
9. **DEF-25**: AI-кэш только для детерминированных операций: hash(input+policyVersion) → ответ, TTL, отключаемый env-флагом. (Не входит в диффы аудита — реализуем в ai-core.)

### 1.4 Контракт API (DEF-16, этап 2)
10. Миграция роутов на withRoute + zod + rateLimit + safe errors — **порядок аудита: auth → money → PII → AI → mutations** (218 роутов, не все в этой волне: волна 1 = auth/lumens/PII/2FA/AI-группа; остальные — W5). Acceptance: 401 без auth, 400 на malformed, 409 на P2002, unknown fields stripped.
11. **DEF-21 SSRF**: feature flag external previews OFF + acceptance аудита (resolved IP фиксируется, redirects запрещены). Полный pinning — W3.
12. **DEF-22 rate-limit**: релизный конфиг с фиксацией `instances=1` (документировать ограничение); Redis — только при >1 воркера (этап 10).
13. **DEF-29 CSP**: production/preview split в `next.config.ts` — убрать wildcard preview и localhost frame-ancestors из production-политики.
14. **DEF-19 тесты (REC-TEST-01)** *(пробел аудита: GPT не знал про Bun)*: harness = встроенный `bun test` (никаких новых библиотек). Минимум 12 тестов из отчёта: deleted user→401; register email hash; 2FA login; IP-score границы; Professional Trust zero-factor; job match empty skills; companyFit null; lumen spend; refund idempotency; HR weekly quota; project client approve/reject (после W2 — заглушка до неё); AI approval expiry (после W3 — отложить). Итого в W1: 9–10 тестов, остальные добавляются в своих волнах.

### 1.5 Проверенные сильные стороны — НЕ ТРОГАТЬ (§11 отчёта)
HttpOnly сессии; AI gateway + honest fallback + refund; Trust formula + formulaVersion; Sovereignty Gateway/PII; EventBus локальный; unified/semantic search; NewsShare; refund idempotency; SPA-шелл аутентифицированной зоны; антифрод до измерения false-positive.

---

## §4. ВОЛНА 2 (rc.3) — Project Evidence Engine + Recommendation Engine

### 2.1 Evidence (этап 3 GPT + наш P1, код аудита готов)
1. **REC-PROJECT-01**: схема — Project: +problem/context/solution/result/clientCompanyId/confidentiality/clientStatus; ProjectMember: +participantRole/responsibility/contribution/memberResult; модель ProjectConfirmation. Существующий `status` не трогаем (два ортогональных статуса). `db:push` после backup.
2. **REC-PROJECT-02**: `project-evidence-service.ts` — полный файл в отчёте (запрос подтверждения, решение клиента approve/approve_with_changes/reject, публичная проекция ТОЛЬКО approvedFields).
3. **API**: POST `/api/projects/[id]/confirmation` (запрос клиенту: notification + EventBus), POST `/api/projects/[id]/confirmation/decide`, GET `/api/projects/[id]/evidence`. Запретить `clientStatus=verified` вне сервиса (acceptance аудита).
4. **UI**: карточка проекта — блок «ЗАКАЗЧИК», бейдж «Подтверждено заказчиком», дрилл-даун «кто и что подтвердил»; мастер-поля problem/context/solution/result опциональны.
5. Анти-коллизион меры GPT (10.1 P1): подтверждение только от authenticated relationship компании-клиента; immutable decision record (ProjectConfirmation не редактируется после decide).

### 2.2 Recommendation Engine (наш P2 v5 + исправления GPT из 10.1: P2)
6. Модель `Recommendation` (type personal/professional/client, context, text, skills, evidence-ссылки, status; projectId? — связь с подтверждённым проектом). **Без скрытого числа** (RecommendationStrength — мультипликативный, серверный, буст в матч; принцип «только реальные данные»: счётчики с дрилл-дауном).
7. API: POST `/api/recommendations`; GET `/api/users/[id]/recommendations` (группировка «Рекомендуют для: X — N, из них M по подтверждённым проектам»); POST `/api/recommendations/[id]/revoke`.
8. `recommendation-strength.ts` — буст-сигнал в matchmaker/jobs match; веса 0.6/0.25/0.15 не переписываем (см. 04-каталог, формула фиксируется с file:line).
9. Проактивные подсказки: подписчик EventBus `project.confirmed` → «Кого готовы рекомендовать?» с предзаполненной основой из ProjectMember.
10. Дифф с SkillConfirmation/ProjectConfirmation зафиксировать в 03/04-каталоге (три разные сущности).

### 2.3 UX-зачистка (DEF-08…14) — диффы, которых не дал аудит *(наш код)*
11. **DEF-08 (P0)**: search/page.tsx + semantic-search-bar — результаты ведут на entity (людей/вакансии/компании), не на «/».
12. **DEF-09**: claim-card «Выбрать верификатора» → подключить POST `/api/claims/[id]/verify` или скрыть.
13. **DEF-10**: 2FA UI — реальный enable/disable/confirm через существующие `/api/auth/2fa/*`.
14. **DEF-11/13**: убрать «Скоро»-блоки (HR отзывы, Compare) из launch-поверхности.
15. **DEF-12**: TrustExplainCard — скрыть вложенный stub Next Best Actions.
16. **DEF-14**: sponsor click → безопасный outbound (allowlist URL, rel=noopener, attribution через собственный редирект-роут с rate-limit).
17. **DEF-27**: единый query source для tile и dialog счётчиков профиля.

---

## §5. ВОЛНА 3 (rc.4) — Governance Layer (код аудита готов)

1. **REC-GOV-01**: 9 моделей (AiGoal, AiAgent, AiAuthority, AiPolicy, AiAction, AiApproval, AiAuditLog, AiBudget, AiIncident) — без relations, не трогают доменные графы. db:push после backup.
2. **REC-GOV-02/03**: action-registry.ts (11 действий с risk/reversible/externalSideEffect/defaultModes) + policy-engine.ts (POLICY_BLOCKED / approval / allowed) — файлы целиком в отчёте.
3. **REC-GOV-04/05**: `/api/ai/decisions` GET + PATCH approve/reject с транзакцией и AiAuditLog — файлы целиком.
4. **REC-GOV-06**: `/api/me/autonomy` — только manual/collaborative на старте (Q2: ответ владельца по умолчанию ДА).
5. **REC-GOV-07**: Decision Inbox UI (полный файл) + бейдж в app-shell через существующие notifications; мобильная версия.
6. **Важно (примечание аудита)**: inbox намеренно НЕ исполняет действия. Executor — только после action handlers + verify + rollback, отдельной волной, не «if approved → send».
7. **AiBudget** (пробел аудита — сервис наш): daily limit + canSpend перед billable-операцией, интеграция с lumen spend (двойной предохранитель).
8. **DEF-21 полный**: SSRF DNS pinning в src/lib/security/ssrf.ts (acceptance аудита) или egress через единый резолвер; потом flag ON.
9. Правило «1000 операций → 20 исключений»: batch-approvals для low-risk, risk tiers, expiry — из T10-вердикта.

## §6. ВОЛНА 4 (rc.5) — Intent/Research + News-слой

1. **ResearchResult** *(пробел аудита — код наш)*: модель (source=test, version, score, confidence, consent, capturedAt, expiresAt) + API + сверка research-view/research-tests.ts с реальным хранилищем (DEF-04). Результаты тестов ≠ hard facts.
2. **Unified Intent Snapshot** (этап 4 GPT): один сервис-снимок намерения (ProfessionalIntent + preferences + ResearchResult + observed ActionEvent), потребляемый search/career/feed. Один UX-поток: «Совпадения» = потребность+выборка; «Исследовать» = понять себя; убрать дубли-поверхности.
3. **News-слой (T11, наш P4)**: BizON News Score 20/20/20/15/15/10 — EXTEND news-relevance-service (константы с комментарием); карточка «Что есть на BizON» (4 счётчика через unified-search-service); редакционная заметка через ai-core с честной маркировкой; 1 scheduled job (рой 50 агентов — НЕ делать).
4. **SEO /industry/[slug]** — только после ответа владельца на Q1 (по умолчанию: отложить до v1.2).

## §7. ВОЛНА 5 (v1.1.0 «Pilot Ready») — Truthful UX + Release hardening

1. Завершить withRoute-миграцию оставшихся мутаций (DEF-16 acceptance).
2. §8 отчёта целиком: у каждой кнопки состояние actionable/disabled-with-reason/hidden; у каждого счётчика source query + drill-down; safe error map вместо e.message; empty state различает «нет данных/ошибка/AI не нашёл»; единый AI-state компонент CONFIDENT/UNCERTAIN/INSUFFICIENT_DATA/REQUIRES_HUMAN/POLICY_BLOCKED; mobile 390px, 44px targets, keyboard.
3. PRE-LAUNCH.md закрыть построчно: CORS runtime-тест, bearer token runtime-тест (partialize), OG, бэкап+restore drill, мониторинг 5xx/latency, incident runbook, legal docs опубликованы (privacy notice, правила люменов-бонусов, moderation).
4. Runtime-гейт CI (DEF-30): build + tsc + lint + 401-smoke защищённых роутов + bun test — обязательны к выпуску.
5. Обновить docs/handover 00–08 полностью (числа из скрипта), пересобрать аудиторский пакет `build-audit-archive.sh`, промт → ре-аудит v1.1.0 (P5 аудита ОБЯЗАТЕЛЕН).

## §8. Решения владельца (не блокируют W1–W2, нужны к W3–W4)

| # | Вопрос (из §12 отчёта) | Рекомендация GPT | Рекомендация наша |
|---|---|---|---|
| Q1 | SSR-страницы /industry/[slug] при сохранении SPA-шелла? | ДА | ДА, но после пилота (W4+/v1.2) |
| Q2 | Автономия на старте: только MANUAL+COLLABORATIVE? | ДА | ДА (DELEGATED/AUTOPILOT после пилот-метрик) |
| Q3 | Публичны только явно одобренные клиентом поля проекта? | ДА | ДА |
| Q4 | Люмены = service credits/bonus без P2P-перевода и cash-out до legal memo? | ДА | ДА (статус-кво кода) |
| Q5 | Скрыть DAO/NFT/спонсор-сложное из launch-навигации? | на решение | ДА, скрыть до пилота |
| Q6 | Приоритет cold-start: work history vs referrals vs тесты? | на решение | work history + verified onboarding |
| Q7 | AI-рекомендации для HR/компаний: opt-in или collaborative by default? | на решение | collaborative by default + явный отказ |
| Q8 | Подтверждение evidence только после верификации отношения к компании? | на решение | ДА (анти-коллюзия) |

## §9. Порядок старта

W1 стартует немедленно (все диффы готовы, решений владельца не требует). К концу W1: security/truth P0 закрыты, тестовая защита работает, каталог автоматизирован. Оценка трудозатрат: W1 ≈ 2–3 сессии, W2 ≈ 3 сессии, W3 ≈ 2–3 сессии, W4 ≈ 2–3 сессии, W5 ≈ 2–3 сессии.
