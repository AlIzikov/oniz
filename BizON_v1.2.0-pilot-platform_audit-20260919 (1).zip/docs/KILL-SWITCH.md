# Kill-Switch автономии (Wave 6, S-136) — вне AI-контура

Аварийная остановка AI-автономии выполняется **только оператором/владельцем**,
без участия AI и без вызовов модели. Три независимых контура (срабатывает любой):

1. **env-флаг** (до рестарта процесса):
   ```bash
   BIZON_AI_AUTONOMY_KILLED=1 bun run dev
   ```

2. **файл-флаг** (runtime, без рестарта):
   ```bash
   touch .bizon-ai-killed     # включить тормоз
   rm .bizon-ai-killed        # снять
   ```
   Проверяется `PolicyEngine` при каждом evaluate — см.
   `src/lib/ai-governance/policy-engine.ts` (`.bizon-ai-killed`).

3. **персистентная политика** (БД, переживает рестарты):
   ```
   PATCH /api/ai/governance/status  { "global_autonomy": false }
   ```
   (AiPolicy.global_autonomy.enabled=false — читается GovernanceService.isAutonomyKilled).

Дополнительно (Wave 6, S-135): **user-prohibitions** — пользователь может
запретить конкретные AI-действия для себя (`UserProhibition`), что сильнее
любых полномочий и режимов (`PROHIBITED_BLOCKED`).

## Проверка, что тормоз активен

```bash
test -f .bizon-ai-killed && echo "файл-флаг активен"
grep BIZON_AI_AUTONOMY_KILLED .env 2>/dev/null
```

## Гарантии

- Решение kill-switch принимается ВНЕ AI (никакие вызовы модели не нужны).
- Политика сильнее промпта: заблокированные действия не доходят до executor'а.
- Каждое срабатывание логируется в AiAuditLog (`AUTONOMY_KILLED`).
