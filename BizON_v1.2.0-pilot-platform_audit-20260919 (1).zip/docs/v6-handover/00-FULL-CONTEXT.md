# BizON v6.0 — ПОЛНЫЙ КОНТЕКСТНЫЙ ДОКУМЕНТ ДЛЯ НОВОГО ЧАТА

> **Цель:** новый чат, прочитав этот документ, становится полным "клоном" — понимает что сделано, как, куда двигаться дальше.
> **Дата:** 2026-09-08
> **Версия:** v6.0 (post-audit, post-fixes)

---

## 1. ЧТО ТАКОЕ BizON

**BizON** — профессиональная соцсеть нового поколения. Принцип: «Не говори, кто ты — докажи это» (BUSINESS ON. TRUTH ON.).

Заменяет декларативные профили (LinkedIn-стиль) на **доказательную модель**: каждое утверждение подтверждается проектом, отзывом, доказательством.

### Философия (10 принципов)
1. Доверие ≠ деньги (нет платного доверия)
2. Public Persona (нарратив) vs Private Truth Profile (числа)
3. Three States of Exit (completed / graceful / conflict)
4. 4 уровня навыков: claimed → verified → project_verified → expert_verified
5. AI не решает за пользователя (предлагает, объясняет)
6. Время — главная валюта (BIZON TIME VALUE)
7. Intent Advertising (деньги не гарантируют показ)
8. peakLevel монотонно не убывает
9. PII только зашифрованный (AES-256-GCM)
10. Все AI-выводы объяснимы

---

## 2. ТЕХНИЧЕСКИЙ СТЕК

- **Frontend:** Next.js 16.1.3 (App Router, Turbopack), React 19, TypeScript 5, Tailwind CSS 4, shadcn/ui, Zustand
- **Backend:** Next.js API Routes (208 endpoints), Prisma ORM 6.19, SQLite (dev) / PostgreSQL-ready (prod)
- **AI:** z-ai-web-dev-sdk (LLM, VLM, TTS, ASR)
- **Security:** AES-256-GCM PII, PBKDF2 600k, 2FA TOTP, SSRF protection, rate limiting
- **PWA:** manifest + service worker
- **Build:** Standalone, strict TypeScript (0 ошибок)

---

## 3. ЧТО БЫЛО ИЗНАЧАЛЬНО (v5.0.1)

- 52 Prisma модели
- 137 API endpoints
- 126 React компонентов
- 18 сервисов
- SQLite БД
- In-memory cache
- `@ts-nocheck` в 3 файлах
- AdPressure баг (24 минуты вместо 24 часов)
- `prisma db push --accept-data-loss` в deploy
- Demo auto-login с хардкодом `IS_DEV = true`
- Blind Spots — keyword matching (не AI)
- Career Scenario — эвристика длины названия навыка

---

## 4. ЧТО СДЕЛАЛИ В v6.0

### 4.1. Bug fixes (6 из 9)
- ✅ BUG-1: AdPressure `24 * 60 * 1000` → `24 * 60 * 60 * 1000` (4 места)
- ✅ BUG-2: deploy.sh → `prisma migrate deploy` (вместо `db push --accept-data-loss`)
- ✅ BUG-3: `@ts-nocheck` удалён из 3 файлов
- ✅ BUG-5: Career Scenario → реальная формула (category multiplier + mentor -30%)
- ✅ BUG-6: Blind Spots → BizonAICore AI inference (вместо keyword matching)
- ✅ BUG-7: `IS_DEV = true` хардкод → `process.env.NODE_ENV !== 'production'`

### 4.2. Новые Prisma модели (+19)
- ProfessionalEvidence, TrustIndex, SkillSynonym
- CoachQuestion, CoachInsight, IgnoredTopic
- ProfessionalCapital, ProfessionalNarrative, AiInsight
- AdPressure, SponsoredOpportunity, CompanyClaim
- HrOrganization, HrClient, Recruiter, Mentorship
- ProfessionalIntent, ProfileView, Subscription

### 4.3. Sovereignty поля в User
- citizenship, region, consentAiAnalysis, consentCrossBorder

### 4.4. Новые сервисы (26 новых, всего 44)
- **ai-core/gateway.ts** — AI Gateway (cache, rate limit, fallback, model router)
- **ai-core/index.ts** — BizonAICore (единый entry, event-driven, context cache)
- **sovereignty/gateway.ts** — Data Sovereignty (3 класса данных, minimization)
- **event-bus/index.ts** — EventBus (in-process, 26 типов событий, DLQ)
- **compute/router.ts** — ComputeRouter (7 провайдеров, 4 приоритета)
- **coach-service.ts** — Bizon Coach (вопросы, инсайты, discovery)
- **capital-service.ts** — Professional Capital (8 компонентов)
- **memory-service.ts** — Professional Memory (нарратив эволюции)
- **semantic-search-service.ts** — Semantic Search (синонимы, intent parsing)
- **talent-forecast-service.ts** — Talent Forecast (pipeline найма)
- **workforce-service.ts** — Workforce Intelligence (gap analysis)
- **skill-futures-service.ts** — Skill Futures (прогноз рынка)
- + восстановленные: ad-pressure, bizon-moment, bizon-signal, blind-spots, career-scenario, company-claim, company-passport, company-trust, hiring-reality, hr-trust, intent, mentor, news-relevance, next-best-action, opportunity, profession-template, skill-graph, time-value, vacancy-verification

### 4.5. Новые API endpoints (+15)
- `/api/me/coach/daily-question` (GET)
- `/api/me/coach/answer` (POST)
- `/api/me/coach/discover` (POST)
- `/api/me/coach/insights` (GET)
- `/api/me/coach/insights/[id]` (PATCH)
- `/api/me/evidence` (GET, POST)
- `/api/me/capital` (GET)
- `/api/me/capital/recompute` (POST)
- `/api/me/memory` (GET)
- `/api/search/semantic` (POST)
- `/api/me/sovereignty/check` (POST)
- `/api/me/ai-analyze` (POST)
- `/api/companies/[id]/talent-forecast` (POST)
- `/api/companies/[id]/workforce-gap` (GET)
- `/api/skills/[id]/forecast` (GET)

### 4.6. UI компоненты (4 новых)
- `BizonCoachCard` — вопрос дня / инсайт (в /me)
- `CapitalDashboard` — 8 компонентов + trend (в /me)
- `ProfessionalMemory` — таймлайн карьеры (в /me)
- `SemanticSearchBar` — natural language поиск (в /search)

### 4.7. Infrastructure (15 файлов)
- Dockerfile (multi-stage, non-root, healthcheck)
- docker-compose.yml (app + postgres + redis + pgadmin)
- .dockerignore
- .github/workflows/ci.yml (lint+typecheck+test+build+security)
- .github/workflows/deploy.yml (build→push→staging→production+rollback)
- deploy/helm/bizon/ (Chart.yaml + values.yaml + 4 templates)
- scripts/backup-db.sh (PostgreSQL + SQLite, retention 30 дней)
- scripts/init-postgres.sh
- src/lib/cache.ts (Redis + in-memory fallback)
- Sentry integration в instrumentation.ts

### 4.8. Cron скрипты (3 новых + 7 существующих)
- cron-coach-questions.js (ежедневно 8:00)
- cron-capital-recompute.js (еженедельно 2:00)
- cron-memory-narrative.js (ежемесячно 1:00)

### 4.9. Seed/миграции
- seed-skill-synonyms.js (119 синонимов)
- migrate-evidence.js (SkillConfirmation + Publication + CareerEntry → ProfessionalEvidence)

### 4.10. Security fixes
- IDOR в CoachService (answerQuestion + confirmInsight) — добавлен userId
- Rate limit на 4 AI endpoints
- SovereigntyGateway интегрирован в AI Gateway (PII фильтрация перед LLM)
- ComputeRouter интегрирован в AI Gateway (routing decision)

### 4.11. EventBus интеграция
- `project.completed` — в /api/projects/[id]/transition
- `skill.verified` — в /api/skills/confirm
- `job.applied` — в /api/jobs/[id]/apply
- `user.created` — в /api/auth/register

---

## 5. ПОТОКИ ДАННЫХ

### 5.1. AI Pipeline
```
Пользователь → API endpoint → BizonAICore.analyze()
  → buildUserContext (cache 5 мин) — загружает profile, skills, projects, evidence, intent
  → AIGateway.execute()
    → Rate limit check
    → Cache check (SHA-256 ключ)
    → ComputeRouter.route() — выбирает провайдера
    → SovereigntyGateway.check() — проверяет легальность
    → SovereigntyGateway.minimizeForAI() — обезличивает PII
    → LLM call (z-ai-web-dev-sdk)
    → Fallback на эвристику при ошибке
    → Cache result (TTL 1 час)
  → Сохранение в AiInsight (БД)
  → Возврат BizonInsight
```

### 5.2. Event-driven flow
```
Действие пользователя → API endpoint
  → БД операция
  → EventBus.publish(event, payload, { userId })
    → Параллельный вызов всех подписчиков
    → Ошибки изолированы (try/catch в каждом handler)
    → DLQ для failed events
```

### 5.3. Data Sovereignty flow
```
AI запрос → SovereigntyGateway.check(userId, operation, fields)
  → Классификация полей (A=Restricted, B=Professional, C=Public)
  → Проверка гражданства (RU→152-ФЗ, EU→GDPR)
  → Если Class A и region ≠ RU → blocked
  → Если minimizationRequired → minimizeForAI()
    → name → anonymousId
    → email → удаляется
    → phone → удаляется
    → location → region only
```

### 5.4. Professional Capital flow
```
Cron (еженедельно) → CapitalService.recompute(userId)
  → 8 компонентов:
    1. verifiedExpertise — count verified skills × 15
    2. projectCapital — count completed projects × 15
    3. outcomeCapital — count verified evidence × 20
    4. trustCapital — TrustIndex.professionalTrust
    5. networkCapital — count connections × 2
    6. leadershipCapital — founder roles × 20 + mentorships × 15
    7. marketRelevance — skills in high demand (jobs count > 5)
    8. learningVelocity — recent skill events × 10
  → total = взвешенная сумма (веса = 0.20+0.15+0.15+0.15+0.10+0.10+0.10+0.05)
  → upsert в ProfessionalCapital
  → EventBus.publish('capital.recomputed')
```

---

## 6. ГДЕ ЗАГЛУШКИ (известные)

| Компонент | Что заглушка | Решение |
|---|---|---|
| CapitalService.getTrend | Возвращает stable/0 если нет snapshots | Нужна таблица ProfessionalCapitalSnapshot |
| CapitalService.marketRelevance | Считает от jobs count (упрощённо) | Нужен Bizon Signal + external market data |
| ComputeRouter | `local` и `external` провайдеры не реализованы | Нужны real local model (Llama) + external API |
| EventBus | In-process (не Redis/Kafka) | Заменить на Redis Streams при масштабировании |
| Cache | In-memory fallback (Redis не подключён в sandbox) | `npm install ioredis` уже сделано, нужен REDIS_URL |
| Sentry | Только server-side (нет withSentryConfig) | Добавить sentry.client.config.ts + withSentryConfig |
| CI/CD | `continue-on-error: true` на lint/typecheck | Убрать после фикса всех TS ошибок |
| Professional Causality Engine | Event chain logging есть, traceChain/attribute — нет | Реализовать causality-service.ts |
| BIZON RADAR | Service есть, UI не подключён | Добавить RadarDashboard в /me |
| Talent Forecast UI | Компонент есть, не подключён к company-dashboard | Импортировать в company-view.tsx |
| Workforce Gap UI | Компонент есть, не подключён | Импортировать в company-view.tsx |
| Skill Futures UI | Компонент есть, не подключён | Импортировать в skill-graph-view.tsx |

---

## 7. ИЗВЕСТНЫЕ БАГИ И РЕШЕНИЯ

### P0 — Критические
1. **Sandbox OOM** — сервер падает при LLM вызовах (256MB RAM). Решение: production с 512MB+.
2. **Cookie Secure flag** — curl не отправляет Secure cookie по HTTP. Решение: в dev убрать Secure, или тестировать через браузер.

### P1 — Высокие
3. **deploy.sh всё ещё имеет `db:push` скрипт в package.json** — переименовать в `db:push:dev`
4. **prisma/migrations/ содержит placeholder** — нужна реальная миграция через `prisma migrate dev`
5. **Helm NetworkPolicy блокирует HTTPS egress (443)** — добавить egress rule для 443
6. **Helm CronJobs не прокидывают BIZON_ENCRYPTION_KEY** — добавить secretKeyRef
7. **3 cron скрипта в Helm values.yaml** — файлы существуют, но нужно проверить пути

### P2 — Средние
8. **119 SkillSynonym загружены, но 0 в БД** — seed скрипт упал на `mode: 'insensitive'` (исправлено, нужно перезапустить)
9. **12 ProfessionalEvidence мигрированы** — миграция прошла, но больше данных можно мигрировать
10. **UI компоненты подключены в me-view.tsx** — но нужно проверить что они рендерятся после build

---

## 8. СТАТИСТИКА v6.0

| Метрика | Значение |
|---|---|
| Prisma моделей | 71 |
| API endpoints | 208 |
| React компонентов | 156 |
| Сервисов | 44 |
| AI Core файлов | 2 (gateway + index) |
| Sovereignty | 1 |
| Event Bus | 1 |
| Compute Router | 1 |
| Cron скриптов | 10 (7 старых + 3 новых) |
| Infrastructure файлов | 15 |
| TS ошибок | 0 |
| Build | ✅ Passing |

---

## 9. КАК ЗАПУСТИТЬ

```bash
# 1. Распаковать архив
unzip bizon-v6.0-final.zip -d bizon
cd bizon

# 2. Установить зависимости
npm install

# 3. Настроить .env
cp .env.example .env
# Заполнить BIZON_ENCRYPTION_KEY (python3 -c "import secrets; print(secrets.token_hex(32))")

# 4. БД
npx prisma generate
npx prisma db push

# 5. Seed
node scripts/seed-skill-synonyms.js
node scripts/migrate-evidence.js

# 6. Build
npm run build

# 7. Запуск
NODE_ENV=production node .next/standalone/server.js
# Или dev: npm run dev

# 8. Demo login
# email: ivan@bizon.ru
# password: password
```

---

## 10. ЧТО ДЕЛАТЬ ДАЛЬШЕ (roadmap v6.1 → v7.0)

### v6.1 — Predictive Autoscaling
- ML-модель прогноза нагрузки
- Pre-scaling перед пиками

### v6.2 — Global Compute Fabric
- Multi-region compute
- Cost Optimizer
- Task Priority Routing

### v6.3 — Skill Futures (полная)
- External data (hh.ru API, Rosstat)
- 12мес/36мес прогноз

### v6.4 — Build Talent / Workforce
- Talent pipeline
- Team Builder (AI собирает команду)

### v6.5 — Monetization
- Real payment gateway (ЮKassa/Stripe)
- B2B Intelligence

### v6.6 — Security Gate
- Red Team test
- Load test 100k users
- Chaos testing

### v7.0 — PRODUCTION LAUNCH
- K8s deployment
- Multi-region
- Public launch

---

**Конец контекстного документа.**
