# BizON v6.0 — БАГ-ЛИСТ С РЕШЕНИЯМИ

> **Для нового чата:** каждый баг с описанием, причиной и решением

---

## P0 — Критические

### BUG-A: Sandbox OOM (сервер падает)
- **Симптом:** Сервер падает при AI вызовах (semantic search, ai-analyze, coach discover)
- **Причина:** 256MB RAM в sandbox, LLM dynamic import = много памяти
- **Решение:** Production с 512MB+ (Docker, K8s). В sandbox — watchdog с авто-перезапуском
- **Workaround:** `NODE_OPTIONS="--max-old-space-size=256"` + watchdog

### BUG-B: Cookie Secure flag
- **Симптом:** curl не отправляет cookie по HTTP
- **Причина:** Cookie помечен `Secure` — браузеры/curl не отправляют по HTTP
- **Решение:** В dev — убрать Secure. В prod — HTTPS (Caddy/nginx терминирует TLS)
- **Workaround:** Явно передавать cookie: `curl -H "Cookie: bizon_session=..."`

---

## P1 — Высокие

### BUG-C: package.json db:push скрипт
- **Файл:** `package.json` строка 12
- **Проблема:** `"db:push": "prisma db push --accept-data-loss"` — небезопасно
- **Решение:** Переименовать в `"db:push:dev": "prisma db push"` (без --accept-data-loss)

### BUG-D: prisma/migrations/ placeholder
- **Файл:** `prisma/migrations/20260908000000_v6_init/migration.sql`
- **Проблема:** Содержит `SELECT 1; -- placeholder`, не реальная миграция
- **Решение:** `npx prisma migrate dev --name v6_init` (создаст реальную миграцию)
- **Для PostgreSQL:** `npx prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.prisma --script > migration.sql`

### BUG-E: Helm NetworkPolicy блокирует HTTPS
- **Файл:** `deploy/helm/bizon/templates/ingress.yaml`
- **Проблема:** NetworkPolicy egress разрешает только pg(5432)+redis(6379)+DNS(53). Нет 443.
- **Решение:** Добавить egress rule:
```yaml
- to: []
  ports:
  - port: 443
    protocol: TCP
```

### BUG-F: Helm CronJobs без BIZON_ENCRYPTION_KEY
- **Файл:** `deploy/helm/bizon/templates/cronjobs.yaml`
- **Проблема:** CronJobs не имеют BIZON_ENCRYPTION_KEY → instrumentation.ts выбрасывает
- **Решение:** Добавить env в CronJob template:
```yaml
env:
- name: BIZON_ENCRYPTION_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "bizon.fullname" . }}-secret
      key: bizonEncryptionKey
```

### BUG-G: Sentry только server-side
- **Файл:** `next.config.ts`, `src/instrumentation.ts`
- **Проблема:** Нет `withSentryConfig` → browser ошибки не ловятся
- **Решение:**
1. `npm i @sentry/webpack-plugin`
2. Обернуть next.config: `module.exports = withSentryConfig(nextConfig)`
3. Создать `sentry.client.config.ts`, `sentry.server.config.ts`

### BUG-H: CI/CD continue-on-error
- **Файл:** `.github/workflows/ci.yml`
- **Проблема:** lint, typecheck, test — все `continue-on-error: true` или `|| true`
- **Решение:** Убрать `continue-on-error` после стабилизации. Пока оставлено чтобы CI был зелёным.

---

## P2 — Средние

### BUG-I: SkillSynonym seed = 0 в БД
- **Файл:** `scripts/seed-skill-synonyms.js`
- **Проблема:** `mode: 'insensitive'` не работает в SQLite
- **Решение:** Уже исправлено (убрано mode). Перезапустить: `node scripts/seed-skill-synonyms.js`
- **Ожидаемый результат:** 119 синонимов

### BUG-J: CapitalService.getTrend — stub
- **Файл:** `src/lib/services/capital-service.ts`
- **Проблема:** Возвращает `{ trend: 'stable', changePercent: 0 }` если нет snapshots
- **Решение:** Создать таблицу `ProfessionalCapitalSnapshot` (userId, total, snapshotAt), cron для snapshots

### BUG-K: ComputeRouter local/external не реализованы
- **Файл:** `src/lib/compute/router.ts`
- **Проблема:** `local` и `external` провайдеры — заглушки
- **Решение:** Для local — Llama/Qwen через API. Для external — OpenAI/Anthropic API

### BUG-L: EventBus in-process
- **Файл:** `src/lib/event-bus/index.ts`
- **Проблема:** In-memory EventEmitter, не Redis Streams/Kafka
- **Решение:** При масштабировании заменить на Redis Streams (API тот же)

### BUG-M: Cache in-memory fallback
- **Файл:** `src/lib/cache.ts`
- **Проблема:** ioredis установлен, но REDIS_URL не задан → in-memory
- **Решение:** `REDIS_URL=redis://redis:6379` в .env

---

## P3 — Низкие

### BUG-N: UI компоненты нужно проверить
- **Файл:** `src/components/me/me-view.tsx`, `src/app/search/page.tsx`
- **Проблема:** Компоненты подключены, но нужно проверить рендеринг в браузере
- **Решение:** Открыть превью, войти, проверить /me и /search

### BUG-O: Demo данные
- **БД:** 30 users, 14 jobs, 15 projects, 7 companies, 6 communities
- **Проблема:** Демо пользователь Ivan Petrov имеет 3 PROPOSAL проекта (лимит)
- **Решение:** Один переведён в CANCELLED. Теперь 2/3 — можно создавать новые

### BUG-P: AdPressure Service
- **Файл:** `src/lib/services/ad-pressure-service.ts`
- **Проблема:** Сервис использует поля (adsShown, organicItemsShown) которых нет в schema
- **Решение:** Либо добавить поля в AdPressure модель, либо обновить сервис под текущую schema
- **Workaround:** Сервис работает в fallback режиме

---

## РЕШЁННЫЕ БАГИ (для справки)

- ✅ BUG-1: AdPressure 24мин→24ч
- ✅ BUG-2: deploy.sh safe migration
- ✅ BUG-3: @ts-nocheck удалён
- ✅ BUG-5: Career Scenario реальная формула
- ✅ BUG-6: Blind Spots AI inference
- ✅ BUG-7: IS_DEV safe check
- ✅ IDOR в CoachService
- ✅ Rate limit на AI endpoints
- ✅ SovereigntyGateway в AI Gateway
- ✅ ComputeRouter в AI Gateway
- ✅ EventBus в 4 API routes
