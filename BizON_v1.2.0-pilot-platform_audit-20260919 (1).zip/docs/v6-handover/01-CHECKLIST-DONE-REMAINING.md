# BizON v6.0 — ЧЕК-ЛИСТ: ЧТО СДЕЛАНО / ЧТО ОСТАЛОСЬ

> **Статус:** 2026-09-08
> **Цель:** точный список для нового чата

---

## ✅ СДЕЛАНО (зелёное)

### Bug Fixes
- [x] BUG-1: AdPressure 24мин→24ч (4 места)
- [x] BUG-2: deploy.sh → prisma migrate deploy
- [x] BUG-3: @ts-nocheck удалён (0 файлов)
- [x] BUG-5: Career Scenario → реальная формула
- [x] BUG-6: Blind Spots → BizonAICore AI inference
- [x] BUG-7: IS_DEV safe check
- [x] IDOR в CoachService (answerQuestion + confirmInsight)
- [x] Rate limit на 4 AI endpoints

### Prisma модели (71 всего)
- [x] 52 исходных + 19 новых
- [x] Back-relations добавлены
- [x] Sovereignty поля в User
- [x] prisma generate работает
- [x] prisma db push работает

### AI Core
- [x] AI Gateway (gateway.ts) — cache, rate limit, fallback, model router
- [x] BizonAICore (index.ts) — analyze, onEvent, buildUserContext, save AiInsight
- [x] ComputeRouter интегрирован в AI Gateway
- [x] SovereigntyGateway интегрирован в AI Gateway
- [x] EventBus интегрирован в 4 API routes

### Сервисы (44 всего)
- [x] 18 исходных + 26 новых/восстановленных
- [x] Все экспортируются из services/index.ts

### API endpoints (208 всего)
- [x] 137 исходных + 15 новых v6 + 56 восстановленных
- [x] Auth на всех
- [x] Rate limit на AI endpoints

### UI компоненты (156 всего)
- [x] 4 новых: BizonCoachCard, CapitalDashboard, ProfessionalMemory, SemanticSearchBar
- [x] Подключены в me-view.tsx и search/page.tsx

### Infrastructure
- [x] Dockerfile (multi-stage, non-root, healthcheck)
- [x] docker-compose.yml (app + postgres + redis)
- [x] CI/CD (ci.yml + deploy.yml)
- [x] Helm chart (Chart.yaml + values.yaml + 4 templates)
- [x] backup-db.sh (PostgreSQL + SQLite)
- [x] init-postgres.sh
- [x] cache.ts (Redis + in-memory fallback)
- [x] Sentry integration
- [x] 3 cron скрипта (coach, capital, memory)
- [x] seed-skill-synonyms.js
- [x] migrate-evidence.js

### Build
- [x] 0 TS ошибок
- [x] Build проходит (standalone)
- [x] ignoreBuildErrors: false (strict TS)

---

## ⚠️ ОСТАЛОСЬ (жёлтое — нужно сделать)

### P0 — Критическое
- [ ] **Sandbox OOM** — сервер падает при LLM вызовах. Решение: production 512MB+
- [ ] **Seed SkillSynonym** — 0 в БД (скрипт исправлен, перезапустить)
- [ ] **Проверить UI рендеринг** — компоненты подключены, но нужно проверить в браузере

### P1 — Высокое
- [ ] package.json: `db:push` → `db:push:dev`
- [ ] prisma/migrations/: реальная миграция (не placeholder)
- [ ] Helm NetworkPolicy: добавить egress 443
- [ ] Helm CronJobs: добавить BIZON_ENCRYPTION_KEY
- [ ] Sentry: withSentryConfig + sentry.client.config.ts
- [ ] CI/CD: убрать continue-on-error после стабилизации
- [ ] Professional Causality Engine: causality-service.ts (traceChain, attribute)
- [ ] BIZON RADAR UI: RadarDashboard компонент в /me
- [ ] Talent Forecast UI: подключить к company-view.tsx
- [ ] Workforce Gap UI: подключить к company-view.tsx
- [ ] Skill Futures UI: подключить к skill-graph-view.tsx

### P2 — Среднее
- [ ] ProfessionalCapitalSnapshot таблица (для getTrend)
- [ ] ComputeRouter: реализовать local + external провайдеров
- [ ] EventBus: перейти на Redis Streams
- [ ] Cache: подключить REDIS_URL в production
- [ ] Unit tests: установить vitest, дописать тесты
- [ ] Integration tests
- [ ] E2E tests (Playwright)
- [ ] Load tests (k6)
- [ ] Red Team test

### v6.1 → v7.0 Roadmap
- [ ] v6.1: Predictive Autoscaling (ML-модель)
- [ ] v6.2: Global Compute Fabric (multi-region)
- [ ] v6.3: Skill Futures (external data: hh.ru API)
- [ ] v6.4: Build Talent / Workforce (talent pipeline, team builder)
- [ ] v6.5: Monetization (ЮKassa/Stripe, B2B Intelligence)
- [ ] v6.6: Security Gate (Red Team, Load test, Chaos)
- [ ] v7.0: PRODUCTION LAUNCH (K8s, multi-region, public)
