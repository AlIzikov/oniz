# План внедрения: Project Evidence Engine + Autonomy Layer + News-слой
**Источник**: переговоры с GPT по v5 (upload/продолдение.pdf, 60 стр.) — применимы к BizON v1.0.0-rc.1
**Дата**: 2026-09-14 · **Принцип внедрения (по самому GPT)**: REUSE → EXTEND → REFACTOR → REPLACE, все существующие функции продолжают работать

---

## §1. Четыре блока в PDF

| Блок | Стр. | Суть |
|---|---|---|
| **A. Project Evidence Engine + Recommendation Engine** | 1–19 | Проект = главный объект доказательства; заказчик подтверждает по полям; структурированные рекомендации 3 уровней; сарафанное радио с доказательной базой; Prisma-модели и API готовые |
| **B. Human–AI Autonomy Layer** | 20–41 | Ядро автономности: Goal→Policy→Agent→Action→Approval→Verify→Audit→Rollback; Policy Engine; Action Registry; Decision Inbox; Autopilot; бюджет AI; health-monitor; MY BIZON AI |
| **C. Аудит по матрице** | 41–50 | 7 уровней управления; 200–300 контрольных пунктов (A–J); критерий «10 млн пользователей и тысячи агентов — кто кем управляет» |
| **D. News-слой «BizON Рекомендует»** | 51–60 | BizON News Score (20/20/20/15/15/10); карточка «Что есть на BizON»; редакционный слой; 1 отрасль = 1 живая SEO-страница; 80% внешние ссылки / 20% своя аналитика |

## §2. Кросс-анализ: предложение GPT ↔ текущая версия (факты по коду)

| Предложение GPT | Что есть сейчас (file) | Стратегия |
|---|---|---|
| BizonProject (problem/context/solution/result, clientCompanyId) | `Project` — schema.prisma:417: title, description, outcome, companyId, budget, visibility, exitState, requiredSkills | **EXTEND**: добавить nullable-поля problem/context/solution/result, clientCompanyId, confidentiality, clientStatus |
| ProjectStatus enum (DRAFT/PENDING_CLIENT/...) | `Project.status` — строковый: recruiting/active/completed/cancelled | **EXTEND**: НЕ трогать существующий статус; добавить ортогональный `clientStatus` (none/pending_client/client_changes/verified/client_rejected) — два статуса живут независимо, старый UI не ломается |
| ProjectParticipant (роль→зона ответственности→результат) | `ProjectMember` — :452: role owner/lead/member, exitState | **EXTEND**: + participantRole (10 проф. ролей GPT), + responsibility/contribution/memberResult |
| ProjectConfirmation (approvedFields/rejectedFields) | НЕТ (проектов/[id]/confirm нет) | **ADD** модель + API + workflow |
| ProjectDeliverable, ProjectProof | НЕТ; но есть ProfessionalEvidence + skill-proofs (другой контур) | **ADD**; ProjectProof связываем с существующим evidence-контуром (мост, не дубликат) |
| Recommendation (type personal/professional/client, evidence) | НЕТ модели (0 совпадений). Referral (P2-4) — это инвайт-коды, другое | **ADD**; referral не трогаем |
| RecommendationStrength (мультипликативная, скрытая) | НЕТ; есть match 0.6/0.25/0.15 (ai.ts) | **ADD** сервис; в матчинг — как доп. сигнал-буст, веса 0.6/0.25/0.15 не переписываем |
| «Кого порекомендовать?» после проекта | EventBus (index.ts+subscribers.ts) + notification-service | **ADD** подписчик на project.confirmed |
| AiGoal/AiAgent/AiAction/AiApproval/AiPolicy/AiBudget | НЕТ; люмены = оплата AI-действий (ai-core) | **ADD**; AiBudget = дневные лимиты, ДОПОЛНЯЕТ люмены |
| AiAuditLog | AuditLog — :1006 (платформенные события) | **ADD** отдельно: разные цели (AI-трассировка vs платформа); зафиксировать в 04-каталоге |
| policy-engine / action-registry / executor / approval | НЕТ; есть ai-core gateway + ai-co-pilot + next-best-action | **ADD** в src/lib/ai/; co-pilot = лицо оркестратора |
| Decision Inbox | НЕТ; есть notifications | **ADD** API+UI, колокольчик через существующие notifications |
| Autopilot | НЕТ | **ADD**, env-флаг BIZON_AUTOPILOT_ENABLED=0 (OFF по умолчанию) |
| health-monitor → AiIncident | /api/health есть | **EXTEND** + AiIncident |
| BizON News Score | news-relevance-service есть | **EXTEND** веса 20/20/20/15/15/10 |
| «Что есть на BizON» (счётчики по теме) | unified-search-service: групповые счётчики «Поняли запрос как» | **REUSE** напрямую |
| Редакционная заметка + «Обсудить на BizON» | NewsShare «Рекомендовано…» (окно 7 дней, T3) | **EXTEND** + ai-core для заметки (честная маркировка provider) |
| Тематические SEO-страницы (1 отрасль = 1 живая страница) | SPA: одна страница «/» — осознанное решение | **РЕШЕНИЕ ВЛАДЕЛЬЦА**: SSR-роуты /industry/[slug] ломают правило «одной страницы» для публичных SEO-поверхностей |
| 50 отраслевых агентов | cron fetch-news уже собирает новости | **НЕ ДЕЛАТЬ сейчас**; 1 scheduled job; рой агентов — после прод-данных |

## §3. Зачем это нужно (анализ)

**Блок A — главная продуктовая ценность.** GPT: «одна из центральных идей всего BizON». Мы уже построили контур доверия (IP-score, Professional Trust 6 факторов, SkillConfirmation, ProfessionalEvidence, паспорт, капитал) — но у него слабый вход: навыки подтверждают коллеги, а факт работы никто. Подтверждение заказчиком по полям = самый сильный сигнал в системе, невозможный на LinkedIn/HH. Это не замена сделанного — это **качественное топливо** для всего контура: каждый verified-проект автоматически питает паспорт, skill graph, Proof-of-Skill, рекомендации, матчинг. Инвестиции в доверие начинают окупаться.

**Блок B — governance для автономии.** Владелец требует «BizON работает практически сам». У нас есть экономика AI (люмены: 1 действие = 1 лумен, kill-switch) — но нет полномочий и тормоза: что AI может сам, что через человека, что никогда; кто и что сделал (аудит); как откатить; как остановить всё. Policy Engine + Registry + Decision Inbox + Kill Switch — обязательный фундамент до раздачи агентам реальных действий. Согласуется с нашими принципами: LLM только предлагает (честный fallback), Policy решает, человек владеет критическим.

**Блок C — обновление критериев аудита.** Не код, а апгрейд GPT-промпта: добавить матрицу A–J (200–300 пунктов), гипотезы T9–T11, критерий «10 млн пользователей / тысячи агентов». Наш пакет аудита уже готов — это его второй том.

**Блок D — канал роста без хранения контента.** News-модуль уже собирает и модерирует новости; GPT добавляет недостающие 20%: скоринг, кросс-ссылки в экосистему («23 компании, 47 специалистов, 12 проектов, 18 вакансий по этой теме»), редакционный слой, SEO-поверхности. Новость = вход в экосистему BizON.

## §4. Как не убить сделанное — принципы

1. **Только additive-схема**: новые поля nullable, новые модели — `bun run db:push` безопасен, существующие данные и UI не затрагиваются.
2. **Два ортогональных статуса проекта**: существующий `status` (recruiting/active/completed) не трогаем; клиентское подтверждение — отдельный `clientStatus`. Никакой миграции смысловых значений.
3. **Feature-флаги**: Autopilot OFF; режимы автономии на старте только MANUAL/COLLABORATIVE; всё новое включается по env.
4. **Волны с гейтами**: lint 0 / tsc 0 / dev.log без 5xx / E2E волны / worklog / откат = git revert + db:push.
5. **Никаких дубликатов**: карта соответствий (§2) — обязательна к исполнению; каждое новое имя модели/роута сверяется с 04-api-catalog.
6. **Правило «нажал → увидел»**: рекомендации показываются счётчиками с дрилл-дауном («3 подтверждённые рекомендации, от кого и на каком основании»); RecommendationStrength скрыт (не 87/100) — принцип «только реальные данные» соблюдён.
7. **Формулы документируем**: любые изменения матчинга — в 04-api-catalog §2–3 с file:line (анти-DOC-MISMATCH).
8. **Разводим похожие сущности**: SkillConfirmation (коллега подтверждает навык) ≠ ProjectConfirmation (заказчик подтверждает проект) ≠ Recommendation (структурированная рекомендация человека) — все три питают Evidence, назначение разное.

## §5. Волны внедрения

### P0 — Критерии аудита + карта соответствий (½ дня, нулевой риск)
- Обновить `docs/handover/GPT-ANALYSIS-PROMPT.txt`: +T9 (Project Evidence Engine), +T10 (Autonomy Layer), +T11 (News-слой), матрица A–J, критерий масштаба.
- Зафиксировать §2 (карту соответствий) как обязательную для всех будущих агентов.

### P1 — Project Evidence Engine (2–3 сессии)
- **P1.1 Схема (additive)**: Project: +problem/context/solution/result/clientCompanyId/confidentiality/clientStatus; ProjectMember: +participantRole/responsibility/contribution/memberResult; NEW: ProjectDeliverable, ProjectProof, ProjectConfirmation. `db:push`.
- **P1.2 API**: EXTEND POST /api/projects (новые опц. поля; жёсткая валидация длин только для пути к verified); ADD POST /api/projects/[id]/confirmation (запрос клиенту: notification + EventBus); ADD POST /api/projects/[id]/confirmation/decide (approve / approve_with_changes / reject + approvedFields/rejectedFields → clientStatus=verified); ADD GET /api/projects/[id]/evidence (граф доказательств).
- **P1.3 Серверная проекция полей**: единый резолвер `src/lib/services/project-evidence-service.ts` — публичный payload содержит ТОЛЬКО поля, разрешённые заказчиком (GPT: «публиковать автоматически только те поля, которые заказчик явно разрешил»).
- **P1.4 UI**: мастер создания (9 шагов GPT); карточка проекта: ЗАКАЗЧИК сверху, бейдж «Подтверждено заказчиком», дрилл-даун «от кого и что подтверждено»; старый быстрый роадмап создания остаётся (draft).

### P2 — Recommendation Engine (2 сессии)
- **P2.1 Модель** Recommendation (type/context/text/skills/evidence/status/projectId?).
- **P2.2 API**: POST /api/recommendations (контекст + основание + «что конкретно сделал хорошо»); GET /api/users/[id]/recommendations (группировка «Рекомендуют для: X — N, из них M по подтверждённым проектам» + дрилл-даун); POST /api/recommendations/[id]/revoke.
- **P2.3** recommendation-strength.ts (мультипликативная формула GPT, скрытая) → буст-сигнал в matchmaker/jobs match (веса 0.6/0.25/0.15 не переписываем).
- **P2.4** Проактивные подсказки: EventBus subscriber project.confirmed → «Вы завершили проект N с K специалистами — кого готовы рекомендовать?» с предзаполненной основой (роль/зона/результат из ProjectMember).
- **P2.5 UI**: профиль — блок «Рекомендуют для:»; карточки вакансий/людей — «2 рекомендации связаны с подтверждёнными проектами».

### P3 — Human–AI Autonomy Layer (2–3 сессии)
- **P3.1 Модели**: AiGoal, AiAgent (seed: co-pilot, matchmaker, news-scout, system), AiAction, AiApproval, AiAuditLog, AiPolicy, AiBudget.
- **P3.2 Ядро**: policy-engine.ts (ALWAYS_HUMAN/HIGH_RISK по GPT + реальные типы действий), action-registry.ts, actions.ts (реальные привязки: SEARCH_JOBS, SEARCH_PEOPLE→unified-search, ANALYZE_CANDIDATE→matchmaker, CREATE_DRAFT_MESSAGE, PUBLISH_CONTENT=HIGH), action-executor.ts, approval.ts (approve/reject/rollback).
- **P3.3 Decision Inbox**: /api/ai/decisions (+approve/reject) + панель в «Мне» + бейдж в app-shell (через существующие notifications).
- **P3.4 Настройки автономии**: /api/me/autonomy; режимы manual/collaborative (delegated/autopilot — флагом позже).
- **P3.5 Бюджет**: AiBudget (дневные лимиты) + люмены (оплата) = двойной предохранитель; canSpend перед выполнением.
- **P3.6 Autopilot**: runAutopilot по cron, BIZON_AUTOPILOT_ENABLED=0; planGoal через ai-core (LLM предлагает только зарегистрированные действия).
- **P3.7 health-monitor**: EXTEND /api/health → AiIncident + зарегистрированные recovery-действия (RETRY_FAILED_JOB…; shell — никогда).

### P4 — News-слой «BizON Рекомендует» (2 сессии + 1 решение)
- **P4.1** BizON News Score 20/20/20/15/15/10 — EXTEND news-relevance-service (константы с комментарием).
- **P4.2** Карточка: «Почему это важно», источник, «Что есть на BizON» (4 счётчика через unified-search-service), «Обсудить на BizON» → пост с привязкой (NewsShare уже есть).
- **P4.3** Редакционный слой: originalAnalysis через ai-core (маркировка provider, honest fallback).
- **P4.4** Тематические страницы /industry/[slug] (SSR + sitemap) — только после решения владельца (ломает «одну страницу» для публичных SEO-поверхностей).
- **P4.5** Рой из 50 агентов — НЕ сейчас; 1 scheduled job с отраслевым параметром; расширение по прод-данным.

### P5 — Пере-аудит v1.1.0
- После P1–P4: обновить docs/handover (00–08 + 04-каталог формул), пересобрать ZIP, обновить GPT-промпт → внешний аудит 2.0 по матрице A–J.

## §6. Решения владельца (не блокируют P1–P2)

1. **Тематические SEO-страницы**: делать SSR-роуты /industry/[slug] (публичные поверхности вне SPA) — да/нет?
2. **Публикация после подтверждения**: только явно разрешённые заказчиком поля (рекомендация GPT и моя — ДА).
3. **Глубина автономии на старте**: рекомендую только MANUAL + COLLABORATIVE; DELEGATED/AUTOPILOT — после прод-статистики.
