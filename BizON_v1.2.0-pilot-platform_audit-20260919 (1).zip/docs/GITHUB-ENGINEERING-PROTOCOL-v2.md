# BIZON — GITHUB ENGINEERING LEARNING PROTOCOL v2
Принят: 18.09.2026 (trace 1a0b5997b03754f5) · Статус: ДЕЙСТВУЮЩИЙ ИНЖЕНЕРНЫЙ ПРОТОКОЛ
Применяется ко всем работам поверх Плана-v2 (docs/План-v2.md) и оверлея (docs/MASTER-PLAN-V2-OVERLAY.md).

---

## ЦЕЛЬ
Ты не должен использовать GitHub как источник случайных готовых решений.
Твоя задача — изучать лучшие open-source проекты как инженерные эталоны, извлекать из них архитектурные паттерны, понимать причины их решений, ограничения, failure modes, тестирование, security и эксплуатацию, а затем применять только те решения, которые реально улучшают BizON.

## ГЛАВНОЕ ПРАВИЛО
- НЕ ДЕЛАЙ РАБОТУ РАДИ РАБОТЫ.
- НЕ ДОБАВЛЯЙ ЗАВИСИМОСТЬ РАДИ ЗНАКОМОЙ ТЕХНОЛОГИИ.
- НЕ ДЕЛАЙ REFACTOR, ЕСЛИ ОН НЕ ДАЁТ ДОКАЗУЕМОГО УЛУЧШЕНИЯ.
- НЕ ПЕРЕПИСЫВАЙ РАБОТАЮЩИЙ КОД ТОЛЬКО ПОТОМУ, ЧТО ДРУГОЙ ПРОЕКТ ДЕЛАЕТ ИНАЧЕ.
- НЕ СЧИТАЙ РЕШЕНИЕ ПРАВИЛЬНЫМ ТОЛЬКО ПОТОМУ, ЧТО ОНО ЕСТЬ В ПОПУЛЯРНОМ GITHUB-РЕПОЗИТОРИИ.

---

## 1. REFERENCE REPOSITORIES

ИЗУЧИТЬ ГЛУБОКО:
vercel/next.js · facebook/react · prisma/prisma · shadcn-ui/ui · tailwindlabs/tailwindcss · microsoft/playwright · testing-library/react-testing-library

AI:
vercel/ai · langchain-ai/langgraph · microsoft/agent-framework · openai/openai-agents-python · modelcontextprotocol/modelcontextprotocol · a2aproject/A2A

WORKFLOWS:
triggerdotdev/trigger.dev · temporalio/temporal · taskforcesh/bullmq

SEARCH / DATA / GRAPH:
pgvector/pgvector · opensearch-project/OpenSearch · meilisearch/meilisearch · typesense/typesense · graphology/graphology · networkx/networkx · neo4j/neo4j

AI OBSERVABILITY / EVALS:
promptfoo/promptfoo · langfuse/langfuse · open-telemetry/opentelemetry-js · getsentry/sentry

SECURITY:
OWASP/ASVS · OWASP/CheatSheetSeries · semgrep/semgrep · ossf/scorecard · google/osv-scanner · gitleaks/gitleaks · aquasecurity/trivy · ossf/malicious-packages

PRODUCTION SaaS REFERENCES:
twentyhq/twenty · calcom/cal.diy · makeplane/plane · outline/outline

## 2. HOW TO STUDY EACH REPOSITORY
Для каждого репозитория не просто читай README. Изучи:
1. архитектуру; 2. directory structure; 3. dependency model; 4. database layer; 5. API layer; 6. frontend architecture; 7. state management; 8. async processing; 9. caching; 10. permissions; 11. authentication; 12. authorization; 13. security; 14. tests; 15. E2E; 16. CI/CD; 17. observability; 18. error handling; 19. retry strategy; 20. migrations; 21. rollback; 22. performance; 23. scalability; 24. release process; 25. AGENTS.md / CLAUDE.md / skills / agent instructions; 26. changelog; 27. recent pull requests; 28. security advisories; 29. known limitations.

Для каждого проекта — внутреннее исследование:
REFERENCE_PATTERN · WHY_IT_EXISTS · WHEN_IT_WORKS · WHEN_IT_FAILS · BIZON_RELEVANCE · BIZON_APPLICATION · BIZON_REJECTION_REASON

## 3. НЕ КОПИРОВАТЬ — СРАВНИВАТЬ
Если существует несколько решений, сравни:
- **A** = минимальное решение
- **B** = production-grade решение
- **C** = scalable solution
- **D** = наиболее современное решение

Критерии сравнения: correctness, security, performance, latency, memory, operational complexity, developer complexity, testing difficulty, failure recovery, observability, future migration cost, vendor lock-in, cost.

Выбор — по измеримым инженерным свойствам, не по популярности/stars/сложности.

## 4. BIZON DECISION RULE (14 вопросов)
Для каждой новой технологии или архитектурного решения обязательно ответь:
1. Какую проблему BizON оно решает?
2. Какая конкретная функция BizON выиграет?
3. Что изменится в коде?
4. Что изменится в БД?
5. Что изменится в API?
6. Что изменится в UI?
7. Что изменится в latency?
8. Что изменится в memory/CPU?
9. Что изменится в security?
10. Что изменится в observability?
11. Как будет происходить failure?
12. Как сделать rollback?
13. Как проверить результат?
14. Почему существующего решения BizON недостаточно?

Нет убедительного ответа — НЕ ВНЕДРЯТЬ.

## 5. AI ARCHITECTURE
Никогда не строить BizON вокруг одного LLM provider.
BizON AI CORE → AI ORCHESTRATOR → MODEL ROUTER → MODEL PROVIDERS.
Поддерживать: large reasoning / fast / cheap / local open-weight / specialized модели.
Выбор модели по: task complexity, latency, cost, privacy, security, required reasoning, context size, availability.

## 6. AI MUST NOT INVENT BIZON DATA
LLM может: interpret, infer intent, classify, summarize, reason, explain, rerank, generate natural language.
LLM НЕ МОЖЕТ придумывать: vacancy, company, person, skill, project, recommendation, evidence, salary, credential, relationship, verification, news fact.
Factual entities — только из: database, search index, external verified source, evidence graph, trusted API.
LLM объясняет найденные данные, но не является источником истины.

## 7. HYBRID SEARCH
Не использовать LLM для простого exact filtering.
Сначала: structured filters → SQL/indexes → lexical → semantic/vector → reranking → business constraints → result explanation.
Для NL-интента: intent parser → structured search plan → deterministic retrieval → semantic retrieval → reranker → LLM explanation.
Изучить pgvector и hybrid search.

## 8. FIVE HANDSHAKES
Поиск пути к человеку = graph problem:
source → relationship graph → bounded traversal depth ≤ 5 → relationship quality → privacy checks → best path → Introduction Request → human consent.
НИКОГДА: не раскрывать приватный контакт без разрешения; не считать любое connection равным доверию; не создавать искусственный relationship; не использовать LLM как источник graph truth.

## 9. SARAFAN RADIO
Recommendation ≠ rating. Recommendation хранит:
recommender · subject · relationship · context · skills · projects · evidence · text · scope · visibility · createdAt · expiresAt · revokedAt · conflictOfInterest · provenance.
Запрещены: paid recommendation, mass fake, reciprocal rings, circular abuse, anonymous reputation farming, context-free spam.
Путь: работал вместе → видел результат → может подтвердить → рекомендует → доверие → новый контакт.
Five Handshakes и Sarafan Radio связаны.

## 10. AGENT AUTONOMY
У каждого AI agent: Goal, Tools, Authority, Policy, Budget, Memory, Audit, Kill switch, Allowed actions, Approval rules, Rollback strategy.
Цепочка: Intent → Action Registry → Policy Check → Authority Check → Risk classification → Execution OR Human Approval → Audit → Result verification.
Агент никогда не расширяет свои права сам.

## 11. GPT-1000 SECURITY MODEL
AI — potentially hostile execution principal. AI НЕ имеет напрямую: DB root, filesystem root, production shell, cloud root credentials, secret vault root, billing authority, deployment authority, identity administration.
Использовать: least privilege, capability-based permissions, short-lived credentials, sandboxing, network restrictions, tool allowlists, policy checks, human approval, audit trails, automatic rollback, kill switch.
Даже очень сильный AI получает только capabilities, необходимые для конкретной задачи.

## 12. AI EVALUATION
Любой AI feature имеет benchmark: SEARCH_JOBS_EVAL, MATCHMAKER_EVAL, CAREER_AGENT_EVAL, NEWS_RELEVANCE_EVAL, SARAFAN_RECOMMENDATION_EVAL, PROJECT_EVIDENCE_EVAL.
Измерять: precision, recall, groundedness, hallucination, latency, cost, failure rate, unsafe action rate, user success.
Идеи: promptfoo / Langfuse / OpenTelemetry.
До benchmark — НЕ НАЗЫВАТЬ FEATURE READY.

## 13. TESTING
Критическая функция: unit + integration + API + security + E2E + failure + authorization + rate-limit + rollback тесты.
E2E — Playwright. Регрессия = existing + new + security + performance.

## 14. DEPENDENCY DISCIPLINE
Перед добавлением dependency: 1) существующий код; 2) стандартная библиотека; 3) уже установленные; 4) можно ли проще; 5) security history; 6) maintenance activity; 7) license; 8) migration cost; 9) lockfile; 10) vulnerability databases.
Не добавлять популярное ради популярного.

## 15. SECURITY PIPELINE
Применять: OWASP ASVS, OWASP Cheat Sheets, Semgrep, OSV Scanner, Gitleaks, Trivy, OpenSSF Scorecard, malicious package intelligence.
Security работает: before commit → CI → before merge → before deployment → runtime.

## 16. PRODUCTION CODE QUALITY
Код: typed, testable, observable, idempotent, retry-safe, failure-aware, secure by default, explicit, modular, maintainable.
Запрещено: any без причины, silent catch, fake success, TODO как реализация, mock как production, unused abstraction, duplicate service/DB logic/business rule, dead feature flag, magic number, hidden authorization, implicit privilege escalation.

## 17. REFACTOR POLICY
REUSE → EXTEND → REFACTOR → REPLACE. Никаких массовых rewrite без доказательств.

## 18. CURRENTNESS POLICY
Перед реализацией: current stable release, security advisories, migration notes, breaking changes, latest docs, latest GitHub releases.
Maintenance mode / официальный successor → старый проект historical reference, новый — primary (пример: AutoGen → historical, Microsoft Agent Framework → current).

## 19. ARCHITECTURE COMPETITION
Для крупных функций — не первое решение, а конкурс:
OPTION A (simplest) / OPTION B (production) / OPTION C (scalable-future) → техническое сравнение → выбор по measurable engineering properties → ADR → implementation → tests → benchmark → accept/reject.

## 20. MOST IMPORTANT RULE
Если текущее решение BizON уже работает, безопасно, быстро, тестируется, наблюдаемо, масштабируется достаточно — НЕ ТРОГАТЬ БЕЗ СЕРЬЁЗНОЙ ПРИЧИНЫ.
ЦЕЛЬ НЕ «сделать больше изменений», ЦЕЛЬ «создать лучший работающий результат».

## 21. FINAL ACCEPTANCE (формат отчёта)
Перед отчётом обязательно показать:
BIZON-ID · objective · problem solved · architecture chosen · alternatives rejected · files changed · file:line · DB changes · API changes · UI changes · tests · E2E · security verification · performance impact · migration · rollback · known risks.
Статус только один из: READY · PARTIAL · BLOCKED · MISSING · MOCK · DOCUMENTED · DOC-MISMATCH · DEPRECATED · REVIEW.
НЕ объявлять READY, если: только описано, mock, API без реального execution, UI без backend behavior.

---

## FINAL PRINCIPLE
Учись у GitHub. Не копируй GitHub. Не поклоняйся GitHub. Не усложняй BizON ради GitHub.
Критерий успеха: МИНИМУМ НЕНУЖНОГО КОДА + МАКСИМУМ РЕАЛЬНОЙ ФУНКЦИОНАЛЬНОСТИ + БЕЗОПАСНОСТЬ + ИЗМЕРИМОЕ КАЧЕСТВО + ВОЗМОЖНОСТЬ ЭВОЛЮЦИИ БЕЗ REWRITE.

KEEP BIZON ON PLAN. KEEP BIZON HONEST. KEEP BIZON MEASURABLE. KEEP BIZON SECURE.
DON'T WORK FOR WORK'S SAKE.
