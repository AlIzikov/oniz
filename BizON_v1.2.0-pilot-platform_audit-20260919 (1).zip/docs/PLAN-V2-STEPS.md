# BIZON — РЕЕСТР ШАГОВ ПЛАНА-V2 (PLAN-V2-STEPS) v1.0
Принят: 18.09.2026 (trace 1a0b5eb17a58d8d9, требование владельца: счётчик шагов «X из Y»)
Правила ведения: см. `docs/PROJECT-RULES.md` §3–§4. Статусы: PENDING/IN_PROGRESS/DONE/BLOCKED/SKIPPED. Каждый шаг = запись в worklog. Итого оценочно **~155 шагов** (волны 2–6 уточняются при старте — детализация волны = первый её шаг).

---

## ВОЛНА 1 — «Кольцо доверия» (Sarafan Radio × 5 Handshakes) — 28 шагов

### Фаза 0 — Подготовка (4)
- **S-001** PENDING — Прочитать PROJECT-RULES.md + GITHUB-PROTOCOL + оверлей §3–§9; создать `specs/wave-1/GATES.md` (unlazy-гейты: схема/сервис/API/UI/E2E/щиты). *DoD: GATES.md создан, все разделы оверлея перечитаны.*
- **S-002** PENDING — Deep-read граф-референсов (graphology, networkx; §1–§2 протокола). *DoD: REFERENCE_PATTERN-карточки с BIZON_RELEVANCE/REJECTION_REASON.*
- **S-003** PENDING — 14-вопросный Decision Rule по IntroductionRequest. *DoD: ответы на 14 вопросов зафиксированы (worklog).*
- **S-004** PENDING — Конкурс A/B/C цикла интро → выбор → `docs/adr/adr-intro-cycle.md`. *DoD: ADR принят, альтернативы отклонены с причинами.*

### Фаза 1 — Схема (additive, db:push) (3)
- **S-005** PENDING — `Recommendation` + relationshipType, evidenceIds JSON, scope, expiresAt, conflictOfInterest. *DoD: схема обновлена, db:push прошёл, tsc чист.*
- **S-006** PENDING — `Connection` + type, provenance, discoverable, lastVerifiedAt. *DoD: аналогично S-005.*
- **S-007** PENDING — Новая модель `IntroductionRequest` (requesterId, introducerId, targetId, purpose, message, status pending/accepted/declined/expired, expiresAt). *DoD: модель + индексы + db:push.*

### Фаза 2 — ML-интерфейсы и лог данных (§8.1) (3)
- **S-008** PENDING — Интерфейс `TrustPropagationModel` + реализация v0 (BFS≤5 поверх matchmaker). *DoD: интерфейс типизирован, v0 работает, XAI-объяснение пути.*
- **S-009** PENDING — Интерфейсы `AnomalyDetector` / `TrendForecastModel` (эвристики v0). *DoD: один интерфейс для будущих ML-замен.*
- **S-010** PENDING — Фичевый пайплайн: лог обучающих данных (ActionEvent/ReputationEvent → единый лог). *DoD: данные пишутся с первого дня.*

### Фаза 3 — Сервисы (4)
- **S-011** PENDING — `intro-service.ts`: создание/приём/отказ/экспирация; сообщение только после accept; связь с Conversation. *DoD: юнит-тесты зелёные.*
- **S-012** PENDING — `sarafan-guard.ts`: анти-гейминг §6.4 (взаимность ≤24ч, кольца DFS, массовость, возраст) поверх anti-fraud.ts (без дублей). *DoD: детекторы покрыты тестами, FAIL-OPEN.*
- **S-013** PENDING — kind-теги + CONTACT_RECO (reason-словарь + score) на Connection (§9 ТЗ 4.8). *DoD: причина рекомендации из словаря.*
- **S-014** PENDING — Decay веса ребра W=W0·exp(−λΔt) + re-strengthening (§8 ТЗ-10.0). *DoD: формула в сервисе, тест на затухание/восстановление.*

### Фаза 4 — API (1)
- **S-015** PENDING — POST/GET `/api/intros`, POST `/api/intros/[id]/accept|decline`; rate-limit, AuditLog, action-registry (risk medium, externalSideEffect). *DoD: API живой, governance-запись есть.*

### Фаза 5 — Щиты Wave 1 (§8.2) (4)
- **S-016** PENDING — `verificationTier` (phone/email) + консент-флоу. *DoD: тир в профиле, связка с NO_REPUTATION.*
- **S-017** PENDING — Device fingerprint (только хэш) + honeypot-поля на регистрации. *DoD: кластеры видны анти-фроду, PII не хранится.*
- **S-018** PENDING — Velocity-чеки: каркас в with-route на все действия. *DoD: лимиты работают, FPR-замер заложен.*
- **S-019** PENDING — Единый компонент жалоб (7 категорий COMPLAINT) — щит для всех модулей (§9). *DoD: компонент + API + тесты.*

### Фаза 6 — UI (4)
- **S-020** PENDING — AuthorChip + уровневые цвета аватаров (быстрая победа, §7-4). *DoD: чип на рекомендациях/профилях.*
- **S-021** PENDING — Карточка «Путь: Вы → Анна → Игорь, запросить знакомство» + интро-запросы в уведомления + блок network-view. *DoD: полный цикл виден в UI.*
- **S-022** PENDING — BIZCARD визитка: модель, QR server-side, PDF A6 (§9 ТЗ 4.4). *DoD: карточка генерируется и скачивается.*
- **S-023** PENDING — Два режима страницы профиля (contact/stranger) по relationship с бэкенда. *DoD: режим определяется сервером.*

### Фаза 7 — Доказательства (5)
- **S-024** PENDING — Юнит-тесты: intro-service, sarafan-guard, decay. *DoD: bun test зелёный, покрытие новых сервисов.*
- **S-025** PENDING — MATCHMAKER_EVAL + SARAFAN_RECOMMENDATION_EVAL в `tools/evals`. *DoD: precision/recall/groundedness/latency/cost измерены.*
- **S-026** PENDING — Adversarial-пробы: массовые интро, self-intro, обход consent, фейковые кольца. *DoD: все BLOCKED, счётчик растёт.*
- **S-027** PENDING — Браузерная E2E полного цикла (2 сессии, паттерн rt-peer-b) + мобильная 390px. *DoD: golden path пройден агент-браузером.*
- **S-028** PENDING — gate-check ALL MET → §21-отчёт Wave 1 → worklog → **чек-пойнт владельца**. *DoD: отчёт по формату §21, статус волны.*

---

## ВОЛНА 2 — Store MVP (§18) — скелет ~17 шагов (S-029…S-045)
- S-029 Детализация Wave 2: GATES.md + Decision Rule + ADR StoreItem · S-030…S-033 схема (StoreItem, StoreBooking) · S-034…S-037 API + люмены/payment-service (мок) · S-038…S-040 UI витрина + «Как со мной работать» · S-041 Premium-поверхности (таргетинг мероприятий, is_premium) · S-042 adversarial «купленная рекомендация не влияет на trust» · S-043 E2E · S-044 KYC-гейт реального шлюза (документация, до приёма денег) · S-045 §21-отчёт → **чек-пойнт владельца (деньги)**.

## ВОЛНА 3 — Diversity + AI-экономика + News/Events — скелет ~30 шагов (S-046…S-075)
- diversity-service (квоты 75/15/10, decay, SkillSynonym, капы) · ai-core реестр операций + semantic cache + метринг → AiBudget · cron-гипотезы (ActionEvent 30 дней, лимит 3/сутки) · LSTM/Prophet v1 skill-futures (Lead Time ≥ 5 дней) · Reputation Estimator (после ≥90 дней данных) · GNN-анти-фрауд v2 (FPR ≤ 2%) + эмбеддинг-синхронность текстов · POST 5 типов + POLL + SUBSCRIPTION + TERM · Мероприятия (цена/спикеры/lifecycle/поиск/напоминания) · ролевая матрица сообществ + BAN_WORD · §21-отчёт.

## ВОЛНА 4 — Project Room + Evidence — скелет ~25 шагов (S-076…S-100)
- Табы Overview/Team/Roles/Proof/Milestones/Discussion/Results · клиент-одобряемые поля · UNVERIFIED/VERIFIED evidence + confirmer · Proof Granularity Role→Responsibility→Action→Result · Company Persona/Memory · PROJECT-витрина (галерея, участники с ролями, заявки, отзывы) · LOT-биржа (9 блоков, accept_until) · rating → внутренний сигнал · §21-отчёт.

## ВОЛНА 5 — Opportunity Engine 12 типов + Поиск работы — скелет ~30 шагов (S-101…S-130)
- 12 типов Opportunity · единый match-pipeline (need→…→explanation→next action) · News→Opportunity bridge · Opportunity Graph навигация · Career BERT v1 (Precision@Top3 ≥ 0.85) · VACANCY/RESUME-блоки/RESPONSE/SEARCH_PREF/VIEW_LOG · фильтры с агрегациями · Radar-слой (Lead Time) · §21-отчёт.

## ВОЛНА 6 — Governance hardening + Scale-prep — скелет ~25 шагов (S-131…S-155)
- 2-of-N critical · подпись/версионирование политик · immutable-audit hash-chain (EMDL) · user-prohibitions · kill-switch вне AI-контура · MAOK L2/L3 + HOP anti-creeping · IL-слайдер автономии · memory-security · VC-экспорт (W3C) · Web-push VAPID · SEO-страницы (p/[token], c/[token], sitemap) · outbox event-bus · §21-отчёт → **финальный чек-пойнт**.

---

## ЖУРНАЛ СТАТУСОВ (обновлять при каждом шаге)
| Шаг | Статус | Дата | Примечание |
|---|---|---|---|
| S-001…S-028 | DONE | 18.09.2026 | Wave 1 выполнена полностью (auto-режим), ALL MET 9/9 гейтов |
| S-029…S-045 | DONE | 18.09.2026 | Wave 2 Store MVP выполнена (auto-режим, приказ владельца «продолжай Wave 2…до конечной точки», trace 1a0b636a2ef3e351): ALL MET 9/9, E2E PASS (балансы сходятся), adversarial 4/4 «купленное ≠ доверие», KYC-гейт задокументирован, реальные деньги НЕ включены (External unavailable) |
| S-046…S-075 | DONE | 18.09.2026 | Wave 3 Diversity+AI-экономика+News/Events: ALL MET 9/9; Diversity-квоты 75/15/10 в ленте; AI-реестр+метринг AiBudget+semantic cache; гипотезы ≤3/сутки; trend v1 Holt (eval PASS, Lead Time); Reputation Estimator (гейт 90 дней); fraud-text-sync (FPR-контроль); POST 5 типов+POLL/SUBSCRIPTION/TERM (E2E: голосование UI + paywall балансы); Мероприятия цена/спикеры/lifecycle/поиск/напоминания; сообщества ролевая матрица + BAN_WORD |
| S-076…S-100 | DONE | 18.09.2026 | Wave 4 Project Room+Evidence: ALL MET 9/9; LOT-биржа (эскроу spendVar/refund/credit, acceptUntil, velocity lot_respond, гонки guard-обновлениями); Milestones+Discussion (переходы, участники-only); заявки (PUBLIC-гейт, accept→member); отзывы (verifiedOnly, scoreInternal не публикуется); галерея ≤20 (groupBy lot-счётчик); Company Memory; Project Room UI 8 табов + LOT 9 блоков (E2E PASS, найден и исправлен мобильный баг табов); §3.3: rating удалён из публичных API/UI → clientVerified |
| S-101…S-130 | DONE | 18.09.2026 | Wave 5 Opportunity Engine 12 типов + Поиск работы: ALL MET 9/9; 12 типов (+cofounder/supplier/investor/gig, честные источники: LOT-биржа/декларации проектов/bridge); News→Opportunity bridge (анти-шум ≥2 сигнала, идемпотентный sync, pending-новости исключены); Opportunity Graph (/related: project→gig+job+event, job→gig по скиллам); CareerMatcher ML-контракт (эвристика v0 + eval READY: Precision@Top3 0.979 ≥ 0.85, XAI 1.0); VACANCY-поля (employmentType/scheduleKind/vacancyFlags/vacancyStatus/employerVerified); RESPONSE (responseStatus/portfolioLink/Media); RESUME-блоки (валидатор ТЗ: about≤5000, YYYY-MM, SKILL≤5/1 primary, E2E 200/422); SEARCH_PREF (капа 5, AuditLog); VIEW_LOG (дедуп/день + календарь); фильтры 10 секций с фактическими агрегациями (UI-панель); Radar §71 (3/7/30/90, RMI внутренний, гейт <7дн = честный отказ); E2E PASS (скриншоты), adversarial 6/6 |
| S-131…S-155 | DONE | 19.09.2026 | Wave 6 Governance hardening + Scale-prep выполнена (восстановление после разрыва сессии + верификация кода): 2-of-N critical (найден и исправлен блокирующий FORBIDDEN-баг), подпись/версионирование политик HMAC, audit hash-chain + tamper-evidence (монотонные метки + мьютекс flush), user-prohibitions сильнее полномочий, kill-switch env+файл+API вне AI-контура, HOP anti-creeping, IL-слайдер 0..4 с тир-гейтами (UI + честные 403), memory-security consent-гейт, VC-экспорт W3C, Web-push VAPID честный NOT_CONFIGURED, sitemap SEO, outbox event-bus; юнит 9/9 + adversarial 9/9 BLOCKED; регрессия W1/W4/W5 зелёная; E2E PASS (2 сессии, 2-of-N через HTTP, IL-слайдер 3→2 в браузере, 390px NO_HSCROLL); найден и исправлен дашборд-краш BizonDiscover (контракт /radar); tsc 0, lint 0/0; gate-check ALL MET 9/9. **ПЛАН-V2: 155/155. ВСЁ ГОТОВО.** |
