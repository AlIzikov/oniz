# Аудит после исправлений: было → стало

> Документ-ответ на `docs/AUDIT-2026-09-10.pdf` (Полный аудит платформы BizON, v1.0).
> Фикс-волна FIX-01…FIX-09, 10 сентября 2026. Все проверки — живой dev-сервер :3000
> (`bun run lint`, `bunx tsc --noEmit`, curl-матрица безопасности, браузерная E2E через agent-browser).
> Детальные журналы работ — `worklog.md` (Task ID FIX-01…FIX-09), план — `docs/FIX-PLAN-2026-09-10.md`.

---

## Сводка

| Статус | Кол-во | Пункты |
|---|---|---|
| **ИСПРАВЛЕНО** | **25 из 38** | Выводы 1–4; дизайн §4.1–4.6 (6); код #1, #2, #5, #6, #7; P0×4; P2 №3–№6; продукт §7.2, §7.4 |
| **ЧАСТИЧНО** | **9** | Вывод 7 (системные слабости — по составляющим); код #3, #4, #8, #10; P1-5, P1-6, P1-7; §7.3 (терминология) |
| **ОТЛОЖЕНО (осознанно)** | **4** | P1-8 (ротация ключа), P2 №1 (anomaly-detector), P2 №2 (SSRF pin), код #9 (ai.ts) |

Подсчёт: 38 проверяемых пунктов = выводы 1–4,7 (5) + дизайн §4.1–4.6 (6) + код #1–#10 (10) + безопасность P0×4 + P1×4 + P2×6 (14) + продукт §7.2/§7.3/§7.4 (3). Выводы 5 и 6 — позитивные констатации аудита, не требовали фикса.

**Gates после волны:** `bun run lint` → **0 errors** (1 pre-existing warning `jobs-view.tsx:217` — известный, вне скоупа). `bunx tsc --noEmit` → **0 ошибок**, включая ужесточённый `noImplicitAny: true` (в `tsconfig.json`; единственная ошибка — отсутствие `@types/nodemailer` — устранена установкой dev-зависимости). В `next.config.ts` выставлен **`ignoreBuildErrors: false`** (код #10 / P2 №6) — сборка больше не проходит мимо type-ошибок. `dev.log` — без 5xx и unhandled-ошибок.

---

## 1. Выводы резюме (раздел 1 аудита)

| № | Находка | Было | Что сделано (файлы) | Статус | Проверка |
|---|---|---|---|---|---|
| 1 | Демо-бэкдор авторизации (§1.1, P0-1) | middleware без cookie подставлял сессию «Иван Петров» в любом окружении; в `page.tsx` захардкожен `IS_DEV=true` | `src/middleware.ts`: инъекция только при `process.env.BIZON_DEMO_AUTH === '1'` (строка 86, комментарии «never in production»); `src/app/page.tsx`: bypass удалён; дефект с потерянной cookie (повторное присваивание `res`) устранен попутно | **ИСПРАВЛЕНО** | grep: единственная точка входа — env-гейт. curl `/api/auth/me` без cookie → 200 демо (потому что в sandbox `.env` сознательно `BIZON_DEMO_AUTH=1`, см. №6 матрицы) — это явный demo-режим, не бэкдор |
| 2 | Эскалация привилегий через PATCH roles (§1.1, P0-2) | `PATCH /api/users/[id]` принимал `body.roles`; admin-проверки читали то же поле → 200 от `/api/admin/metrics` | `src/app/api/users/[id]/route.ts`: `roles` вырезан, строгий whitelist полей; `src/lib/admin-guard.ts` — `isAdminRole` (строгое `'admin'`) + `requireAdmin`, применён в 16+ admin-роутах (FIX-02, FIX-03 снял dev-релаксации) | **ИСПРАВЛЕНО** | PATCH своего профиля `{"roles":["admin"]}` → 200, но в БД `roles = "Data Engineer,Mentor"` (не изменился); `GET /api/admin/metrics` с той же cookie → **403** «Доступ только для администратора» |
| 3 | Утечка PII без аутентификации (§1.1, P0-3) | анонимный `GET /api/users/[id]` отдавал расшифрованные email/телефон/др/локацию через `toUserPublic` | `src/app/api/users/[id]/route.ts` + `src/lib/api-helpers.ts`: auth обязателен (401); full-проекция — только владелец и accepted-связи; остальным — `toUserPublicLite` без email/phone/birthday/location/bio/roles и без `decrypt()`; старый self-view переименован в `toUserSelfView` (4 auth-роута) | **ИСПРАВЛЕНО** | невалидная cookie → **401**; demo-cookie на «чужого» (Мария Иванова, нет accepted-связи) → 200, ключи ответа: только `id,name,title,avatarUrl,ipScore,level,accountType,companyId,isVerified,subscriptionTier,createdAt,stats,emailVerified,tosAccepted` — **0 PII-полей** |
| 4 | Денежная логика без транзакций (§1.1, код #1–#2) | двойное начисление дивидендов при параллельных чтениях; списание и ledger раздельны; refund не идемпотентен; 2 вызова `$transaction` на проект | `src/lib/services/lumen-service.ts` (FIX-06): CAS-цикл `updateMany where {userId, lumenAccruedAt: old}` + ledger в одной `$transaction` (таймаут 15с); атомарный spend (guard-декремент + ledger); идемпотентный refund через `LumenTransaction.refundOf @unique`; spend возвращает `transactionId` (5 callers обновлены) | **ИСПРАВЛЕНО** | 2 чтения `/api/lumens` → оба 200, `accrual.credits=0`, баланс стабилен (622); FIX-06 дополнительно: race-тест 6 параллельных чтений после backdate → ровно 1 начисление, ledger сходится с балансом; повторный refund → no-op |
| 5 | Ядро продукта — реальное (позитив) | — | — | **подтверждено** (не требует фикса) | E2E FIX-09: дашборд, лента с карточками «Рекомендовано вам», вакансии с intent-поиском, мессенджер (диалоги + отправка), кошелёк люменов — всё рендерится на живых данных |
| 6 | Инженерные практики образцовые (позитив) | — | — | **подтверждено** | — |
| 7 | Системные слабости (§1.3): валидация 3/228, 84 роута без try/catch, 33 утечки `e.message`, 0 тестов, ключ в архиве, ноль заголовков/TLS, primary 2,26:1, обязательства монетизации, PRE-LAUNCH не отработан | см. соответствующие строки: P1-5, P1-6, P1-8, код #3/#4, §4.1, §7.2/7.4 | по составляющим: заголовки добавлены (FIX-01), primary-пара исправлена (FIX-04), withRoute+валидация на ключевых мутирующих роутах (FIX-07), оферта/email-верификация/флаг дивидендов (FIX-08), PRE-LAUNCH частично закрыт и актуализирован | **ЧАСТИЧНО** | остатки — см. раздел «Отложено осознанно»: 0 автотестов (Vitest), ротация ключа, TLS/HSTS/CSP, полное покрытие withRoute |

## 2. Дизайн (разделы 3–4 аудита)

| Пункт | Было | Что сделано (файлы) | Статус | Проверка |
|---|---|---|---|---|
| §4.1 Тёмная тема: primary-пара (P0 дизайна) | `--primary-foreground` #020B1B на #005459 → **2,26:1**, кнопки нечитаемы | `src/app/globals.css` (.dark): `--primary-foreground: oklch(0.97 0.005 220)` (FIX-04) | **ИСПРАВЛЕНО** | E2E: `html.dark`, primary-кнопка `bg=lab(31%)`, `text=lab(96,5%)` → контраст ≈8–12:1 (AA/AAA); скриншот `/tmp/e2e-03-dark.png` |
| §4.2 Статусные бейджи success (P1) | `text-success` на белом 2,97:1 в 9 местах | `globals.css`: `--success-text` (светлая oklch(0.45 0.09 195), тёмная oklch(0.77 0.11 195)) + замена `text-success` → `text-success-text` в 8 файлах (hr/intel-shared, build-talent, team-builder, company-intelligence, project-card, dao-view) | **ИСПРАВЛЕНО** | `rg text-success-text src` → 8 файлов; токен в обеих темах |
| §4.3 Мобильная навигация 5+1 + FAB (P1) | 6 колонок на 320px (53px/пункт), подписи 10px обрезались, FAB `bottom-6` перекрывал «Ещё» | `app-shell.tsx`: мобильный таб-бар `grid-cols-5` (4 раздела + «Ещё», sheet без дублей), подписи `text-xs`, FAB `bottom-20 right-4 md:bottom-6 md:right-6` (FIX-05) | **ИСПРАВЛЕНО** | E2E 390px: таб-бар = Главная/Новости/Профиль/Компании + «Ещё», label **12px**, FAB (bottom 764) выше таб-бара (top 794) — **без перекрытия** |
| §4.4 Кольцо IP-score на токенах (P1) | литералы #22c55e/#00AEEF/#f59e0b, cyan 2,53:1 | `trust-badge.tsx`: цвета кольца → `var(--lighthouse)/--success/--warning`, подписи на токенах (FIX-04) | **ИСПРАВЛЕНО** | в файле нет hex-литералов палитры (grep) |
| §4.5 Публичный профиль: унификация (P2) | `bg-white` без dark: (profile-view:385), `focus:bg-white focus:text-black` в skip-ссылке | `profile-view.tsx` → `bg-card text-card-foreground border-border`; `skip-to-content.tsx` → токены; skip-link **подключён** в layout (FIX-04) | **ИСПРАВЛЕНО** | E2E: в снапшоте присутствует link «Перейти к содержимому» |
| §4.6 Плотность текста 40+ (P2) | 509 вхождений `text-[9/10/11]px` (аудит считал ~486) | одноразовый скрипт FIX-05: все → `text-xs`; правило минимумов в CSS (44px touch сохранён адресно, `button.h-8` компактные) | **ИСПРАВЛЕНО** | `rg 'text-\[(9|10|11)px\]' src` → **0** |
| Таблица 5, остаток | «второй синий» #1e3a8a ≈50 мест, CTA emerald-600, 837 хардкод-цветов, ~20 мёртвых shadcn-компонентов, мёртвый tailwind.config.ts | точечные замены FIX-04 (IP-кольцо, bg-white, success); массовая замена бренда — **не делалась** | **ЧАСТИЧНО** (учтено в «Отложено») | `rg 1e3a8a src` → 48 вхождений (email-service, icon, search, публичные страницы, landing, app-shell…); `emerald-600` в landing/shell → 13 |

## 3. Качество кода (раздел 5, топ-10)

| # | Было | Что сделано (файлы) | Статус | Проверка |
|---|---|---|---|---|
| 1 | Гонка двойного начисления дивидендов (lumen-service 56–113) | CAS + `$transaction` + ledger-строка в той же транзакции (FIX-06) | **ИСПРАВЛЕНО** | `/api/lumens` ×2 → credited=0; race-тест FIX-06: 1 начисление из 6 параллельных |
| 2 | Списание/ledger не атомарны; refund не идемпотентен | guard-декремент + ledger в `$transaction`; `refund(spendTransactionId?)` + `refundOf @unique` (FIX-06; схема → `db:push`) | **ИСПРАВЛЕНО** | sqlite_master: `LumenTransaction_refundOf_key` **UNIQUE**; spend 322→320→refund 322→повтор no-op |
| 3 | 84 роута без try/catch; P2002-гонки → сырой 500 | `src/lib/with-route.ts`: withRoute(handler, {auth, schema, rateLimit}) — единый try/catch, маппинг BizonError/P2002→409/P2025→404; применён к **21 хендлеру в 18 файлах** (posts, messages, likes, comments, boost, apply, moderate, verify, join/leave, subscriptions, topup, preferences, career-scenario, cv, ai/career, referral, publications) | **ЧАСТИЧНО** (паттерн задокументирован в FIX-PLAN; остальные ~200 роутов — при касании) | curl-верификация FIX-07: валид → 201, мусор → 400 clean, неизвестные поля вырезаются; dev.log без [withRoute]-500 |
| 4 | 33 роута отдают сырой `e.message`; 173 `catch(e:any)` | в покрытых withRoute-роутах 5xx → «Внутренняя ошибка сервера», `catch(e:unknown)`; CommunityService → BizonError | **ЧАСТИЧНО** (вне 18 файлов — по прежнему старому паттерну) | grep по затронутым файлам: `catch (e: any)` → 0 |
| 5 | N+1 в репутации (8 запросов × участник, копипаста в 3 файлах) | `reputation.ts`: `computeIpScoreFromAggregates` + `recomputeIpScoresBulk`; `ReputationService.awardBulk`; рефактор 6 мест (projects complete/transition, connections, posts, jobs apply, matchmaker) (FIX-06) | **ИСПРАВЛЕНО** | 3 запроса на N пользователей; дубликаты удалены |
| 6 | N+1: паспорт (20/паспорт), авторы публикаций, аудит-логи по IP, dwell-цикл | passport-service — findMany `in:` + Map; publications GET — авторы одним запросом; anti-fraud — один запрос + distinct в JS; dwell — `createMany` (FIX-06) | **ИСПРАВЛЕНО** | compile/render в dev.log без деградаций; правки изолированные |
| 7 | Нет индексов под реальные where | `prisma/schema.prisma`: `@@index` Post(authorId,createdAt), JobApplication(userId,createdAt), AuditLog(ip), Ad(active,moderationScore), CoachInsight(userId,createdAt); `db:push` выполнен (FIX-06) | **ИСПРАВЛЕНО** | sqlite_master: все 5 индексов на месте |
| 8 | Дублирование auth-guard ×247, PLANS в двух файлах, мёртвый `/api/subscription/upgrade` | `admin-guard.ts` централизовал admin-проверки (16 файлов); user-auth дубликаты — не консолидированы (withRoute `auth:true` — путь вперёд); PLANS и legacy-роут не тронуты | **ЧАСТИЧНО** | `rg "includes\\('admin'\\)"` → 0; `src/app/api/subscription/upgrade/route.ts` существует |
| 9 | `ai.ts` 1255 строк, 7 копий `getZai` мимо gateway | — | **ОТЛОЖЕНО** (осознанно, см. ниже) | rg: прямые импорты остались |
| 10 | SPA-монолит, `IS_DEV=true`, `ignoreBuildErrors:true`, `noImplicitAny:false`, кеш Next 16 не используется | `IS_DEV` удалён (FIX-01); **FIX-09**: `tsconfig.json` → `noImplicitAny: true` (+`@types/nodemailer`), `next.config.ts` → `ignoreBuildErrors: false` | **ЧАСТИЧНО** (типизация закрыта; SPA-разделение и `use cache` — отложено) | `bunx tsc --noEmit` → **0 ошибок** при strict + noImplicitAny |

## 4. Безопасность (раздел 6, реестр находок)

| Ур. | Было | Что сделано (файлы) | Статус | Проверка (curl, 10.09) |
|---|---|---|---|---|
| **P0-1** | Демо-бэкдор сессии для всех без cookie | env-гейт `BIZON_DEMO_AUTH` (middleware.ts:86), `IS_DEV` удалён | **ИСПРАВЛЕНО** | без cookie → 200 демо **только** при `BIZON_DEMO_AUTH=1` (явный demo-режим); grep — других точек инъекции нет |
| **P0-2** | Эскалация до admin одним PATCH | roles вырезан из PATCH; `requireAdmin`/`isAdminRole` (admin-guard) в 16+ роутах; dev-релаксации сняты | **ИСПРАВЛЕНО** | PATCH `{"roles":["admin"]}` → в БД без изменений; `GET /api/admin/metrics` → **403** |
| **P0-3** | PII-утечка анонимно | 401 без сессии; Lite-проекция без PII для не-владельцев; full — владелец/accepted | **ИСПРАВЛЕНО** | invalid cookie → 401; demo-cookie, чужой профиль → **0 PII-полей** в JSON |
| **P0-4** | 2FA обходится на логине | login: `twoFactorEnabled` → `{twoFactorRequired, tempToken}` **без сессии**; `/api/auth/2fa/verify` (TOTP/backup, одноразовый tempToken TTL 5 мин); UI-шаг в auth-screen | **ИСПРАВЛЕНО** | e2e: register → set 2FA → login с верным паролем → `{"twoFactorRequired":true,"tempToken":…}`, **set-cookie отсутствует**; verify `code:"000000"` → **401** «Неверный код» (set-cookie в ответе — это demo-инъекция middleware для cookieless-запроса, не сессия тест-юзера) |
| **P1-5** | Валидация в 3 роутах из 228 | `withRoute` + zod-схемы (`validation.ts` расширен) на 21 мутирующий хендлер; политика «нет схемы — нет мерджа» на остальные не распространена | **ЧАСТИЧНО** | POST /api/posts: `{"text":123}` → 400; 6000 символов → 400; unknown-поле вырезано |
| **P1-6** | Ноль security-заголовков, HTTP без TLS | `next.config.ts headers()`: X-Frame-Options SAMEORIGIN, X-Content-Type-Options nosniff, Referrer-Policy strict-origin-when-cross-origin, Permissions-Policy; HSTS/CSP — на реверс-прокси Caddy при prod (задокументировано в next.config.ts) | **ЧАСТИЧНО** | curl `GET /` → все 4 заголовка присутствуют; TLS 443 + HSTS + строгий CSP — при деплое |
| **P1-7** | Rate-limiter in-memory, слепой XFF, lockout-DoS по email | `rate-limiter.ts`: getClientIp с TRUST_PROXY (X-Real-IP/последний XFF), LoginBackoff — экспоненциальный backoff 1с→2с→…кап 15 мин на IP+email-hash, само-затухающий; lockout-by-email убран | **ЧАСТИЧНО** (Redis-бэкенд — отложено) | 3× неверный пароль (ivan@bizon.ru/WrongPass123): 401 «через 1 с» → 429 (backoff) → 401 «через 2 с»; другой email с того же IP не затронут (FIX-03); блокировки демо-юзера нет |
| **P1-8** | `BIZON_ENCRYPTION_KEY` закоммичен в .env/bizon-config.env | — (процедура ротации и пересборки emailHash не выполнена) | **ОТЛОЖЕНО** (осознанно) | ключ по-прежнему в .env sandbox; обязательный шаг перед prod |
| **P2-1** | anomaly-detector — мёртвый код | — | **ОТЛОЖЕНО** | `detectAnomalies` не импортируется никем |
| **P2-2** | SSRF: DNS-rebinding (pin IP отсутствует) | — | **ОТЛОЖЕНО** | ssrf.ts проверяет resolved IP, но не пинает его на сокет |
| **P2-3** | Backup-коды на Math.random() | `totp-service.ts`: `randomInt(0, 100_000_000)` из node:crypto + padStart(8) | **ИСПРАВЛЕНО** | код FIX-03; 8-значный backup распознаётся полем `code` |
| **P2-4** | 2fa/disable без rate-limit; enable не требует пароль | enable: тело {password} через AuthService.login + rate 5/мин; disable: строго пароль-only + rate 5/мин | **ИСПРАВЛЕНО** | curl-цепочки FIX-03: 422/401/200; flood disable → 429 на 6-м |
| **P2-5** | Dev-релаксация в admin/metrics (NODE_ENV) | NODE_ENV-ветки удалены из metrics, data-plane, causality; только роль/ops-токен | **ИСПРАВЛЕНО** | demo-cookie (не admin) → 403 от admin/metrics |
| **P2-6** | `ignoreBuildErrors: true` | → **false** + tsc-гейт (strict, noImplicitAny) | **ИСПРАВЛЕНО** | `next.config.ts:9`; `bunx tsc --noEmit` → 0 |

## 5. Продукт (раздел 7)

| Пункт | Было | Что сделано (файлы) | Статус | Проверка |
|---|---|---|---|---|
| §7.2 «Только реальные данные»: email не верифицируется, оферты нет | регистрация проверяла email только `includes('@')`; VerificationToken отсутствовал; `rg tos` по src — пусто | FIX-08: модель **VerificationToken** (sha256-хэш, TTL 24ч, одноразовый), `User.emailVerified` + `User.acceptedTosAt`; GET `/api/auth/verify-email` (302 /; повтор/просрочка → 400); DEV EMAIL STUB письмо; гейт `lumens/topup` → 403 EMAIL_NOT_VERIFIED; страница **`/legal`** (условия люмен-программы, ст. 32 ЗоЗПП); обязательный чекбокс ToS в AuthScreen + баннер в app-shell + `PATCH /api/me/accept-tos` | **ИСПРАВЛЕНО** | e2e FIX-08: register(acceptedTos:false) → 400; verify-токен → 302, повтор → 400; неподтверждённый → topup 403; демо-юзер: emailVerified=true, tosAccepted=false → баннер в UI (виден в E2E FIX-09); `/legal` → 200. Осталось из минимального контура §7.2: очередь модерации постов по жалобам, anomaly на регистрации — отложено |
| §7.3 «Рекомендации на 7 дней» — ПОДТВЕРЖДЕНА аудитом | механика работала (окно 7·24ч + NewsShare с атрибуцией); оговорка: ipScore-поток подписан как «рекомендации» | фикс не требовался (теория подтверждена); терминологическая подпись «высокое доверие» для ipScore-потока — не сделана | **ЧАСТИЧНО** (косметика) | E2E: лента показывает «Рекомендовано вам» только для адресных NewsShare — соответствует механике; подпись потока не менялась |
| §7.4 «Люмены» с отклонениями от ТЗ | дивиденды 15% вопреки собственной юрэкспертизе (ст. 13 395-1 / ст. 172 УК РФ); возврат 100% вместо 0,7 не задокументирован; оферта отсутствовала | FIX-08: **kill-switch `LUMEN_DIVIDENDS_ENABLED`** (default = текущее поведение; `0` → credited=0 мгновенно) с BIZON-комментарием и юр-ссылками; **docs/DECISIONS.md** — 3 решения: возврат 100% (осознанно), дивиденды → бонусная программа + флаг, email-верификация до реальных платежей; гонки закрыты (FIX-06, P0-4-таблица выше); оферта `/legal` + акцепт (см. §7.2) | **ИСПРАВЛЕНО** | flag=0 → accrueDemoMonth credited=0 (FIX-08); `/api/lumens` ×2 → credited=0, без двойных начислений (CAS) |

---

## Отложено осознанно (с обоснованием)

1. **SPA-разделение на настоящие роуты** (код #10, остаток) — перестройка единственной страницы и 25+ view с риском регрессий по всему UI; не блокирует текущий запуск (единственный экран — осознанное архитектурное решение проекта, зафиксированное в CHECKPOINT.md). Вынести в отдельную волну вместе с `use cache`/ISR.
2. **Расщепление `ai.ts` (1255 строк) и консолидация 7 копий `getZai` на AIGateway** (код #9) — массовый рефакторинг при **нуле автотестов** небезопасен; правильный порядок: Vitest на AI- и денежные пути → потом резать. 
3. **Ротация `BIZON_ENCRYPTION_KEY` + пересборка `emailHash` + secret-manager** (P1-8) — координированная офлайн-миграция всех PII-колонок (AES-256-GCM) и HMAC-хэшей; требует окно простоя и план отката; обязательно до приёма реальных платежей/прода.
4. **TLS 443 + HSTS + строгий CSP + Redis rate-limit** (P1-6/P1-7, остаток) — инфраструктурные вещи: в sandbox нет TLS-терминации (plain HTTP :81, приложение встраивается в iframe песочницы — строгий CSP/HSTS сломали бы превью; комментарий в next.config.ts). Настраивается на Caddy + Redis при прод-деплое. In-memory rate-limiter/backoff не шарится между воркерами — приемлемо для одного воркера dev.
5. **Vitest на денежные операции и репутацию** (вывод 7) — 0 → N тестов; предложено аудит-планом «неделя 4»; до этого страхует идемпотентность `refundOf @unique` и CAS.
6. **Полное покрытие withRoute всех ~228 роутов** (код #3/#4) — покрыты 21 ключевой мутирующий хендлер; остальные переводятся «при касании» по правилу из FIX-PLAN.
7. **Утилизация legacy `/api/subscription/upgrade` и единого источника PLANS** (код #8) — мёртвый роут не вызывается UI; удаление — низкорискованная уборка следующей волны.
8. **anomaly-detector подключить к audit-log или удалить; SSRF pin resolved IP на сокет** (P2-1/P2-2) — сложность средняя, эксплойт-путь требует внутренней сети; зафиксировано в бэклоге.
9. **Дизайн-косметика**: 48 вхождений #1e3a8a, 13 emerald-600 в landing/shell, ~20 мёртвых shadcn-компонентов, мёртвый tailwind.config.ts, ESLint-запрет `bg-white/text-black` — не влияет на контраст ключевых пар (все P0/P1 дизайна закрыты).
10. **Терминология ленты §7.3** («высокое доверие» для ipScore-потока вместо «рекомендации») — подпись UI, не механика.
11. **Модерация постов/профилей по жалобам** (остаток §7.2) — есть только премодерация NewsCard/рекламы; очередь жалоб — отдельная фича.

---

## Итоговые баллы после фиксов (таблица 9 аудита → сейчас)

| Ось | Было | Стало | Обоснование |
|---|---|---|---|
| Функциональность | 7 / 10 | **7,5** | +2FA реально встроена в логин и UI (была «заглушка в UI»), +email-верификация и ToS-контур, +флаг дивидендов. Остались прежние вычеты: Co-Pilot без LLM, минт NFT pseudo-token, оплата буста не подключена, нет WebSocket |
| Дизайн | 6 / 10 | **8** | Критическая primary-пара тёмной темы 2,26:1 → ~12:1; success-text AA; 509 микротекста <12px → 0; FAB/таб-бар 5+1 работают на 320–390px (проверено в браузере); IP-кольцо и белые пятна на токенах; skip-link подключён. Осталось: 48+13 хардкодов бренда, мёртвые компоненты |
| Код | 5 / 10 | **6,5** | Деньги — в `$transaction` (CAS, идемпотентный refund), индексы, N+1 устранены (6 блоков), withRoute+валидация на 21 хендлере, admin-guard вместо дублей, tsc strict + noImplicitAny + ignoreBuildErrors=false. Осталось: большинство роутов вне withRoute, 0 тестов, god-файлы (1772), SPA-монолит |
| Безопасность | 3 / 10 | **7,5** | Все 4 P0 закрыты и воспроизведением подтверждены как закрытые (бэкдор env-gated, эскалация 403, PII-проекция чистая, 2FA-ветка с tempToken); экспоненциальный backoff вместо lockout-DoS; CSPRNG backup-коды; re-auth на 2fa enable/disable; 4 security-заголовка. Осталось: ключ в .env (ротация), Redis rate-limit, TLS/HSTS/CSP-строгий, anomaly/SSRF — всё задокументировано как pre-prod блокеры |
| Продукт | 6 / 10 | **7,5** | Email-верификация end-to-end + оферта `/legal` + акцепт ToS (регистрация-чекбокс, баннер, БД-флаг) — главный пробел «теории 2» закрыт; дивиденды получили юр-коридор (kill-switch + DECISIONS.md); решение «возврат 100%» задокументировано. Осталось: разделение люмены/искры, модерация контента, терминология рекомендаций |
| **Итог** | **5,4 / 10** | **7,4 / 10** | Среднее по осям: (7,5 + 8 + 6,5 + 7,5 + 7,5) / 5 = 7,4. Аудиторский вердикт «релиз запрещён» снят для demo/закрытой беты: блокеры безопасности закрыты и верифицированы; **перед реальным prod** остаются обязательными: ротация ключа (P1-8), TLS/HSTS/CSP + Redis (P1-6/7), Vitest на деньги, прогон PRE-LAUNCH.md до конца |

---

## Приложение: матрица безопасности FIX-09 (сырые результаты)

```
1. GET /            → 200; X-Frame-Options: SAMEORIGIN; X-Content-Type-Options: nosniff;
                      Referrer-Policy: strict-origin-when-cross-origin;
                      Permissions-Policy: camera=(), microphone=(), geolocation=()
2. GET /api/users/[id] (чужой):
   invalid cookie   → 401 {"error":"Не авторизован: требуется сессия"}
   demo cookie      → 200; поля email/phone/birthday/location/bio/roles ОТСУТСТВУЮТ
3. PATCH /api/users/[id] (свой) {"roles":["admin"]} → 200; roles в БД = "Data Engineer,Mentor"
   GET /api/admin/metrics (та же cookie) → 403
   PATCH чужого профиля → 403 «Можно редактировать только свой профиль»
4. POST /api/auth/login (ivan@bizon.ru, WrongPass123):
   #1 → 401 «…Следующая попытка через 1 с.»
   #2 (сразу) → 429 «Повторите через 1 секунд.»
   #3 (через 4 с) → 401 «…Следующая попытка через 2 с.» (экспоненциальный backoff, само-затухающий)
5. 2FA: register fix09-2fa-<ts>@test.ru (Fix09!QzXw, acceptedTos:true) → 200
   login → 200 {"twoFactorRequired":true,"tempToken":…} БЕЗ set-cookie сессии
   verify {tempToken, code:"000000"} → 401 «Неверный код» (set-cookie — demo-инъекция middleware, не сессия)
   cleanup: тест-юзер удалён (каскад)
6. grep BIZON_DEMO_AUTH src/middleware.ts → env-гейт `process.env.BIZON_DEMO_AUTH === '1'` (:86)
   /api/auth/me без cookie → 200 демо «Иван Петров» (явный demo-режим при env=1, не бэкдор)
7. sqlite_master: Post(authorId,createdAt) ✓, JobApplication(userId,createdAt) ✓, AuditLog(ip) ✓,
   Ad(active,moderationScore) ✓, CoachInsight(userId,createdAt) ✓,
   LumenTransaction.refundOf UNIQUE ✓, User.emailVerified ✓, User.acceptedTosAt ✓, VerificationToken ✓
8. GET /api/lumens ×2 → 200/200, balance 622, accrual.credited=0 в обоих (нет двойного начисления)
```

Браузерная E2E (agent-browser, 1280×900 и 390×844): приложение рендерится без error-boundary; дашборд «Добрый вечер, Иван» с контентом; лента — композер + карточка «Рекомендовано вам» (атрибуция Мария Иванова); «Работа» — intent-поиск (4 режима) + список вакансий; «Сообщения» — 2 диалога, открытие чата и поле ввода; «Настройки» — кошелёк 622 Л (совпадает с API), пакеты пополнения, дисклеймер демо-шлюза; тёмная тема — primary-кнопка читаема (light text on dark, ≈8–12:1); мобильный 390px — таб-бар `grid-cols-5` (4 раздела + «Ещё»), подписи 12px, FAB выше таб-бара без перекрытия. Ошибок в консоли нет (единственное benign-предупреждение Radix о `aria-describedby`).
