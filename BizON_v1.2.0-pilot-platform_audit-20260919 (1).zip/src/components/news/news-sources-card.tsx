// BizON — NewsSourcesCard (9-c, doc_a §14-15 «News Bridge: прозрачность источников»)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 📰 ИСТОЧНИКИ ЛЕНТЫ                                           │
//   │ Какие компании и медиа питают ваши новости                    │
//   │                                                              │
//   │ ПОСЛЕДНЕЕ В ЛЕНТЕ                                            │
//   │ [GreenAI] Docker и контейнеризация: как…          →          │
//   │ [vc.ru]   TypeScript 6.0: строгие типы…           →          │
//   │                                                              │
//   │ КОМПАНИИ-ИСТОЧНИКИ                                           │
//   │ [GreenAI · 2 RSS] [CareerPath · 1 RSS] …                     │
//   │ ВАШИ ИСТОЧНИКИ                                               │
//   │ [blog.example.com] …                                         │
//   │ ПУЛ BIZON                                                    │
//   │ [vc.ru] [Хабр] [rb.ru]                                       │
//   └──────────────────────────────────────────────────────────────┘
//
// Источники:
//   • GET /api/news/sources → { sources, active: { own, companies, platform }, companyDomains }
//     (расширен read-only; companies — Company.newsSources, platform — пул cron-fetch-news)
//   • GET /api/news?limit=8   → последние карточки (бейдж источника по sourceDomain)
//
// Принципы: только read-only (подписка/отписка не входит в скоуп 9-c);
// бейджи компаний — только реальное совпадение домена новости с Company.newsSources;
// полные тексты всегда на сайте источника (Traffic Back, doc_a §14).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Newspaper,
  ChevronDown,
  Building2,
  Rss,
  Globe,
  ExternalLink,
  UserRound,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы ===
// ============================================================================

interface ActiveCompany {
  id: string;
  name: string;
  domains: string[];
  sourceCount: number;
}

interface SourcesResponse {
  sources: string[]; // прежнее поле — свои источники (обратная совместимость)
  active?: {
    own: string[];
    companies: ActiveCompany[];
    platform: { domain: string; label: string }[];
  };
  companyDomains?: { domain: string; companyId: string; companyName: string }[];
}

interface NewsItem {
  id: string;
  url: string;
  title: string;
  aiSummary: string;
  sourceDomain: string;
  publishedAt: string;
  category: string;
}

interface NewsResponse {
  items: NewsItem[];
  total: number;
}

// ============================================================================
// === Хелперы ===
// ============================================================================

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

function findCompanyForDomain(
  domain: string,
  companyDomains: SourcesResponse['companyDomains'],
): { companyId: string; companyName: string } | null {
  if (!companyDomains) return null;
  const d = domain.toLowerCase();
  const direct = companyDomains.find((c) => c.domain === d);
  if (direct) return { companyId: direct.companyId, companyName: direct.companyName };
  // Новость может быть на поддомене источника (www., news.)
  const suffix = companyDomains.find((c) => d.endsWith(`.${c.domain}`));
  if (suffix) return { companyId: suffix.companyId, companyName: suffix.companyName };
  return null;
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function NewsSourcesCard({ className }: { className?: string }) {
  const [sources, setSources] = React.useState<SourcesResponse | null>(null);
  const [news, setNews] = React.useState<NewsItem[] | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [failed, setFailed] = React.useState(false);
  const [open, setOpen] = React.useState(true);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setFailed(false);
    Promise.allSettled([
      api<SourcesResponse>('/api/news/sources'),
      api<NewsResponse>('/api/news?limit=8'),
    ])
      .then(([s, n]) => {
        if (cancelled) return;
        if (s.status === 'fulfilled') setSources(s.value);
        if (n.status === 'fulfilled') {
          // Реклама (category=ad) — не «новости от источников», исключаем.
          setNews((n.value.items ?? []).filter((i) => i.category !== 'ad').slice(0, 5));
        }
        if (s.status === 'rejected' && n.status === 'rejected') {
          setFailed(true);
          console.error('[NewsSourcesCard] оба источника недоступны');
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const active = sources?.active;
  const companies = active?.companies ?? [];
  const own = active?.own ?? [];
  const platform = active?.platform ?? [];

  return (
    <Card className={cn('overflow-hidden', className)}>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger
          className="w-full text-left"
          aria-label={open ? 'Свернуть блок «Источники ленты»' : 'Развернуть блок «Источники ленты»'}
        >
          <CardContent className="p-4 pb-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
                <Newspaper className="w-4 h-4 text-lighthouse" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold leading-tight">Источники ленты</div>
                <div className="text-xs text-muted-foreground truncate">
                  Какие компании и медиа питают ваши новости
                </div>
              </div>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground transition-transform flex-shrink-0',
                  open && 'rotate-180',
                )}
              />
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="p-4 pt-3">
            {/* Загрузка — скелетоны */}
            {loading && (
              <div className="space-y-3" aria-busy="true" aria-live="polite">
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            )}

            {/* Ошибка — не крашим вкладку */}
            {!loading && failed && (
              <div className="text-xs text-muted-foreground py-3 text-center" role="alert">
                Не удалось загрузить источники. Попробуйте обновить страницу позже.
              </div>
            )}

            {!loading && !failed && (
              <div className="space-y-4">
                {/* === Последнее в ленте + бейджи источников === */}
                <section aria-label="Последние новости с бейджами источников">
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-2">
                    Последнее в ленте
                  </h3>
                  {news !== null && news.length === 0 && (
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Пока нет данных — новости появятся после ближайшего обновления ленты.
                    </p>
                  )}
                  {news && news.length > 0 && (
                    <ul className="space-y-1.5">
                      {news.map((item) => {
                        const company = findCompanyForDomain(item.sourceDomain, sources?.companyDomains);
                        return (
                          <li key={item.id}>
                            <a
                              href={item.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-start gap-2 p-2 rounded-lg hover:bg-accent transition group"
                            >
                              {/* Бейдж источника: компания или домен */}
                              {company ? (
                                <Badge
                                  variant="outline"
                                  className="text-xs font-medium gap-1 border-lighthouse/40 text-lighthouse flex-shrink-0 mt-0.5"
                                  title={`Источник: компания ${company.companyName}`}
                                >
                                  <Building2 className="w-3 h-3" />
                                  <span className="max-w-24 truncate">{company.companyName}</span>
                                </Badge>
                              ) : (
                                <Badge
                                  variant="secondary"
                                  className="text-xs font-normal gap-1 flex-shrink-0 mt-0.5"
                                  title={`Источник: ${item.sourceDomain}`}
                                >
                                  <Globe className="w-3 h-3" />
                                  <span className="max-w-24 truncate">{item.sourceDomain}</span>
                                </Badge>
                              )}
                              <span className="flex-1 min-w-0">
                                <span className="block text-xs font-medium leading-snug line-clamp-2 group-hover:underline">
                                  {item.title}
                                </span>
                                {item.aiSummary && (
                                  <span className="block text-xs text-muted-foreground leading-snug line-clamp-1 mt-0.5">
                                    {item.aiSummary}
                                  </span>
                                )}
                              </span>
                              <ExternalLink className="w-3 h-3 text-muted-foreground flex-shrink-0 mt-1 opacity-60" />
                            </a>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </section>

                {/* === Компании-источники === */}
                <section aria-label="Компании-источники">
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-2">
                    Компании-источники
                  </h3>
                  {companies.length === 0 ? (
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Компании ещё не подключили свои RSS — ленту питает пул BizON.
                      Когда компания подключит официальный источник, её новости
                      появятся в ленте с бейджем компании.
                    </p>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {companies.map((c) => (
                        <Badge
                          key={c.id}
                          variant="outline"
                          className="text-xs font-medium gap-1 border-lighthouse/40 text-lighthouse"
                          title={`Домены: ${c.domains.join(', ')}`}
                        >
                          <Building2 className="w-3 h-3" />
                          {c.name} · {c.sourceCount} RSS
                        </Badge>
                      ))}
                    </div>
                  )}
                </section>

                {/* === Ваши источники === */}
                <section aria-label="Ваши источники">
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-2">
                    Ваши источники
                  </h3>
                  {own.length === 0 ? (
                    <p className="text-xs text-muted-foreground leading-relaxed flex items-start gap-1.5">
                      <UserRound className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                      Вы не подключали личные источники — в профиле можно указать до 5 своих RSS.
                    </p>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {own.map((u) => (
                        <Badge key={u} variant="outline" className="text-xs font-normal gap-1">
                          <Rss className="w-3 h-3" />
                          <span className="max-w-48 truncate">{hostOf(u)}</span>
                        </Badge>
                      ))}
                    </div>
                  )}
                </section>

                {/* === Пул BizON === */}
                {platform.length > 0 && (
                  <section aria-label="Пул BizON">
                    <h3 className="text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-2">
                      Пул BizON
                    </h3>
                    <div className="flex flex-wrap gap-1.5">
                      {platform.map((p) => (
                        <Badge key={p.domain} variant="secondary" className="text-xs font-normal gap-1">
                          <Globe className="w-3 h-3" />
                          {p.label}
                        </Badge>
                      ))}
                    </div>
                  </section>
                )}

                {/* Traffic Back — принцип News Bridge (doc_a §14) */}
                <p className="text-xs text-muted-foreground/80 leading-relaxed pt-1">
                  Полные тексты всегда остаются на сайте источника — BizON показывает
                  только краткое AI-резюме и ведёт трафик обратно.
                </p>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
