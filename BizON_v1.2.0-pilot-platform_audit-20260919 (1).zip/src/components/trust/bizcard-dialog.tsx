// BizON — BizCardDialog (Wave 1 S-022): цифровая визитка с QR и печатью A6.
// QR ведёт на публичную страницу-паспорт /p/[token] (REUSE существующей).
// PDF — через системную печать браузера (A6 @media print) — без новых зависимостей.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { IdCard, Printer, QrCode as QrIcon } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface BizCardData {
  displayName: string;
  headline: string | null;
  qrDataUrl: string;
  publicToken: string;
  includes: { email: boolean; phone: boolean; skills: boolean };
  contactEmail?: string | null;
  contactPhone?: string | null;
  skills?: string[];
}

export function BizCardDialog({ trigger }: { trigger?: React.ReactNode }) {
  const { user } = useAppStore();
  const [open, setOpen] = React.useState(false);
  const [data, setData] = React.useState<BizCardData | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [displayName, setDisplayName] = React.useState('');
  const [includes, setIncludes] = React.useState({ email: true, phone: false, skills: true });

  async function load() {
    setLoading(true);
    try {
      const res = await api<BizCardData>('/api/me/bizcard', {
        method: 'POST',
        body: JSON.stringify({ displayName: displayName || undefined, includes }),
      });
      setData(res);
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось собрать визитку', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  React.useEffect(() => {
    if (open && user) {
      setDisplayName(user.name ?? '');
      void load();
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="outline" size="sm">
            <IdCard className="w-4 h-4 mr-2" /> Моя визитка
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md" aria-label="Цифровая визитка">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><QrIcon className="w-4 h-4" /> Цифровая визитка</DialogTitle>
          <DialogDescription>QR ведёт на вашу публичную страницу. Данные включаются по вашему выбору.</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Имя на визитке" aria-label="Имя на визитке" />
          <div className="grid grid-cols-3 gap-2 text-sm">
            {([['email', 'Email'], ['phone', 'Телефон'], ['skills', 'Навыки']] as const).map(([k, label]) => (
              <label key={k} className="flex items-center gap-2 cursor-pointer">
                <Checkbox checked={includes[k]} onCheckedChange={(v) => setIncludes((s) => ({ ...s, [k]: v === true }))} />
                {label}
              </label>
            ))}
          </div>

          {data && (
            <div id="bizcard-a6" className="mx-auto w-[300px] rounded-xl border bg-background p-4 print:a6-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{data.displayName}</div>
                  {data.headline && <div className="text-xs text-muted-foreground truncate">{data.headline}</div>}
                </div>
                <img src={data.qrDataUrl} alt={`QR визитки ${data.displayName}`} className="w-20 h-20 rounded-md border" />
              </div>
              <div className="mt-2 space-y-0.5 text-xs text-muted-foreground">
                {data.includes.email && data.contactEmail && <div>{data.contactEmail}</div>}
                {data.includes.phone && data.contactPhone && <div>{data.contactPhone}</div>}
                {data.includes.skills && data.skills && data.skills.length > 0 && (
                  <div className="truncate">Навыки: {data.skills.slice(0, 5).join(', ')}</div>
                )}
                <div className="text-[10px] opacity-70">BizON · p/{data.publicToken}</div>
              </div>
            </div>
          )}

          <div className="flex gap-2">
            <Button className="flex-1" onClick={load} disabled={loading}>
              {loading ? 'Собираем…' : 'Обновить'}
            </Button>
            <Button variant="outline" onClick={() => window.print()} disabled={!data}>
              <Printer className="w-4 h-4 mr-2" /> Печать A6
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
