// BizON — IntroInbox (Wave 1 S-021): входящие/исходящие интро-запросы.
// Посредник принимает/отклоняет; сообщение уходит цели ТОЛЬКО при accept.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Handshake, Check, X, Clock } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface IntroRow {
  id: string;
  purpose: string;
  status: string;
  createdAt: string;
  expiresAt: string;
  role: 'introducer' | 'requester' | 'target';
  requester: { id: string; name: string; title?: string | null; avatarUrl?: string | null };
  introducer: { id: string; name: string; avatarUrl?: string | null };
  target: { id: string; name: string; title?: string | null; avatarUrl?: string | null };
}

const PURPOSE_LABELS: Record<string, string> = {
  job: 'работа', project: 'проект', mentorship: 'менторство',
  partnership: 'партнёрство', other: 'другое',
};

export function IntroInbox() {
  const { user } = useAppStore();
  const [intros, setInput] = React.useState<IntroRow[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [busy, setBusy] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ intros: IntroRow[] }>('/api/intros?box=incoming');
      setInput(res.intros.filter((i) => i.status === 'pending'));
    } catch {
      // 401 для гостей — тихо; инбокс приватный
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => { if (user) void load(); else setLoading(false); }, [user, load]);

  async function act(id: string, action: 'accept' | 'decline') {
    setBusy(id);
    try {
      await api(`/api/intros/${id}/${action}`, { method: 'POST' });
      toast({ title: action === 'accept' ? 'Знакомство передано' : 'Запрос отклонён' });
      await load();
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось', variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  if (loading || intros.length === 0) return null;

  return (
    <Card className="p-4 space-y-3 border-primary/30 bg-primary/5" aria-label="Запросы на знакомство">
      <div className="flex items-center gap-2 text-sm font-semibold">
        <Handshake className="w-4 h-4 text-primary" />
        Запросы на знакомство через вас
        <Badge variant="secondary">{intros.length}</Badge>
      </div>
      <div className="space-y-2">
        {intros.map((i) => (
          <div key={i.id} className="flex items-center gap-3 rounded-lg border bg-background p-3">
            <div className="flex-1 min-w-0 text-sm">
              <span className="font-medium">{i.requester.name}</span>
              <span className="text-muted-foreground"> просит представить его: </span>
              <span className="font-medium">{i.target.name}</span>
              <span className="ml-2 text-xs text-muted-foreground">
                ({PURPOSE_LABELS[i.purpose] ?? i.purpose})
              </span>
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                <Clock className="w-3 h-3" />
                до {new Date(i.expiresAt).toLocaleDateString('ru-RU')}
              </div>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button size="sm" onClick={() => act(i.id, 'accept')} disabled={busy === i.id} aria-label="Передать знакомство">
                <Check className="w-4 h-4 mr-1" /> Передать
              </Button>
              <Button size="sm" variant="outline" onClick={() => act(i.id, 'decline')} disabled={busy === i.id} aria-label="Отклонить запрос">
                <X className="w-4 h-4 mr-1" /> Отклонить
              </Button>
            </div>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">
        При передаче сообщение автора уйдёт адресату и откроется диалог. Текст при отклонении не пересылается.
      </p>
    </Card>
  );
}
