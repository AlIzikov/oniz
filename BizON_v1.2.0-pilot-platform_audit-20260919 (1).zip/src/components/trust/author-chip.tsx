// BizON — AuthorChip (Wave 1 S-020): визуальный уровень автора рекомендации.
// Уровень приходит с бэкенда (computeAuthorLevel) — числа не показываются.
import { AUTHOR_LEVEL_META, type AuthorLevel } from '@/lib/trust/author-level';
import { cn } from '@/lib/utils';

export function AuthorChip({ level, className }: { level: AuthorLevel; className?: string }) {
  const meta = AUTHOR_LEVEL_META[level] ?? AUTHOR_LEVEL_META.newcomer;
  return (
    <span
      className={cn('inline-flex items-center px-1.5 py-0.5 rounded-full border text-[10px] font-semibold uppercase tracking-wide', meta.className, className)}
      title={`Уровень автора: ${meta.label}`}
    >
      {meta.label}
    </span>
  );
}
