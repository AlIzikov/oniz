// BizON — Trust Graph (визуализация графа доверия как «созвездие»)
'use client';
import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { Network as NetworkIcon } from 'lucide-react';

export function TrustGraphView() {
  const { setProfileUserId } = useAppStore();
  const [data, setData] = React.useState<{nodes: any[], edges: any[]} | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    api<{ nodes: any[]; edges: any[] }>('/api/trust-graph')
      .then(setData)
      .catch(e => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) return <Skeleton className="h-96 w-full rounded-xl" />;

  // Расчёт позиций узлов по кругу
  const center = { x: 200, y: 200 };
  const radius = 140;
  const nodes = data.nodes.map((n, i) => {
    if (n.isCenter) return { ...n, x: center.x, y: center.y };
    const angle = ((i - 1) / (data.nodes.length - 1)) * 2 * Math.PI;
    return { ...n, x: center.x + radius * Math.cos(angle), y: center.y + radius * Math.sin(angle) };
  });
  const nodeMap = new Map(nodes.map(n => [n.id, n]));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><NetworkIcon className="w-6 h-6 text-lighthouse" /> Граф доверия</h1>
        <p className="text-sm text-muted-foreground">Ваша сеть как созвездие — чем больше связей, тем ярче звёзды</p>
      </div>
      <Card>
        <CardContent className="p-4">
          <svg viewBox="0 0 400 400" className="w-full max-w-md mx-auto">
            {/* Рёбра */}
            {data.edges.map((e, i) => {
              const from = nodeMap.get(e.from);
              const to = nodeMap.get(e.to);
              if (!from || !to) return null;
              return <line key={i} x1={from.x} y1={from.y} x2={to.x} y2={to.y} stroke="oklch(0.55 0.10 200)" strokeWidth={e.weight > 0.5 ? 2 : 1} opacity={e.weight > 0.5 ? 0.6 : 0.3} />;
            })}
            {/* Узлы */}
            {nodes.map(n => (
              <g key={n.id} onClick={() => !n.isCenter && setProfileUserId(n.id)} style={{ cursor: n.isCenter ? 'default' : 'pointer' }}>
                <circle cx={n.x} cy={n.y} r={n.isCenter ? 24 : 16} fill={n.isCenter ? 'oklch(0.23 0.06 255)' : 'oklch(0.55 0.10 200)'} opacity={0.9} />
                <text x={n.x} y={n.y + (n.isCenter ? 40 : 32)} textAnchor="middle" fontSize="10" fill="currentColor" className="text-foreground">{n.name.split(' ')[0]}</text>
                <text x={n.x} y={n.y + 4} textAnchor="middle" fontSize="9" fill="white" fontWeight="bold">{n.ipScore}</text>
              </g>
            ))}
          </svg>
          <div className="flex items-center justify-center gap-4 mt-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-primary" /> Вы</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-lighthouse" /> Ваши связи</span>
            <span className="flex items-center gap-1"><span className="w-4 h-0.5 bg-lighthouse/60" /> Прямая связь</span>
            <span className="flex items-center gap-1"><span className="w-4 h-0.5 bg-lighthouse/30" /> Через друга</span>
          </div>
        </CardContent>
      </Card>
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-4 text-center">
          <p className="text-xs text-muted-foreground">Каждая линия — реальная связь, подтверждённая через общий проект или запрос. Накрутка невозможна.</p>
        </CardContent>
      </Card>
    </div>
  );
}
