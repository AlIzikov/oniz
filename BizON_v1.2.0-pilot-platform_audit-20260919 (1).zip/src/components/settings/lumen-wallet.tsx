// BizON — Кошелёк люменов (волна 14, монетизация)
// Люмен — внутренняя валюта ИИ-действий:
//   • пополнение 1 ₽ = 1 люмен (демо-шлюз, честная пометка)
//   • 1 люмен = 1 ИИ-действие (клик по ИИ-кнопке в Free-тарифе)
//   • дивиденды: 15% годовых на внесённые рубли, начисляются люменами
//     в реальном времени при чтении кошелька; округление до целого люмена,
//     дробный остаток копится и не сгорает
//   • Pro/Business — ИИ безлимит, люмены не тратятся
// Вся бухгалтерия открыта: журнал операций на 25 последних записей.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { TermInfo } from '@/components/common/term-tooltip';
import {
  Zap, Loader2, TrendingUp, Wallet, Plus, History, Sparkles, RefreshCw, Info,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface LumenTransactionItem {
  id: string;
  type: 'topup' | 'dividend' | 'spend' | 'refund';
  lumens: number;
  rubles: number | null;
  meta: { note?: string; label?: string; simulated?: boolean } | null;
  createdAt: string;
}

interface LumenWalletData {
  balance: number;
  rublesDeposited: number;
  pendingFraction: number;
  apy: number;
  subscriptionTier: string;
  projections: { month: number; year: number };
  lastAccrualAt: string | null;
  actions: Array<{ id: string; cost: number; label: string }>;
  topupAmounts: readonly number[];
  transactions: LumenTransactionItem[];
}

const TX_META: Record<string, { label: string; className: string; sign: string }> = {
  topup: { label: 'Пополнение', className: 'text-emerald-600', sign: '+' },
  dividend: { label: 'Дивиденды', className: 'text-emerald-600', sign: '+' },
  refund: { label: 'Возврат люменов', className: 'text-emerald-600', sign: '+' },
  spend: { label: 'ИИ-действие', className: 'text-amber-600', sign: '−' },
};

export function LumenWallet() {
  const [wallet, setWallet] = React.useState<LumenWalletData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [topping, setTopping] = React.useState<number | null>(null);
  const [accruing, setAccruing] = React.useState(false);

  const load = React.useCallback(async () => {
    try {
      const res = await api<LumenWalletData>('/api/lumens');
      setWallet(res);
    } catch (e: any) {
      toast({ title: 'Не удалось загрузить кошелёк', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  async function handleTopup(amount: number) {
    setTopping(amount);
    try {
      const res = await api<{ balance: number; credited: number; note: string }>(
        '/api/lumens/topup',
        { method: 'POST', body: JSON.stringify({ amount }) }
      );
      toast({ title: `Кошелёк пополнен: +${res.credited} люменов`, description: res.note });
      await load();
    } catch (e: any) {
      toast({ title: 'Не удалось пополнить', description: e?.message, variant: 'destructive' });
    } finally {
      setTopping(null);
    }
  }

  async function handleAccrueDemo() {
    setAccruing(true);
    try {
      const res = await api<{ credited: number; pendingFraction: number; note: string }>(
        '/api/lumens/accrue',
        { method: 'POST' }
      );
      toast({
        title: res.credited > 0 ? `Начислено: +${res.credited} люменов` : 'Начислено меньше 1 люмена',
        description:
          res.credited > 0
            ? res.note
            : `${res.note} Дробный остаток (${res.pendingFraction.toFixed(2)} Л) копится и не сгорает.`,
      });
      await load();
    } catch (e: any) {
      toast({ title: 'Не удалось начислить', description: e?.message, variant: 'destructive' });
    } finally {
      setAccruing(false);
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Wallet className="w-4 h-4 text-amber-500" /> Кошелёк люменов
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-9 w-full" />
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!wallet) return null;

  const isPro = wallet.subscriptionTier !== 'free';
  const hasDeposit = wallet.rublesDeposited > 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Wallet className="w-4 h-4 text-amber-500" />
          Кошелёк люменов
          <TermInfo k="lumen" />
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* === Баланс === */}
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="text-center">
              <div className="text-4xl font-extrabold tabular-nums leading-none flex items-center gap-1.5">
                <Zap className="w-7 h-7 text-amber-500 fill-amber-500" />
                {wallet.balance}
              </div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">люменов</div>
            </div>
            <Separator orientation="vertical" className="h-10" />
            <div className="text-xs text-muted-foreground">
              внесено: <strong className="text-foreground">{wallet.rublesDeposited} ₽</strong>
              {wallet.pendingFraction > 0 && (
                <div className="text-xs mt-0.5">
                  копится до целого: {wallet.pendingFraction.toFixed(2)} Л
                </div>
              )}
            </div>
          </div>
          <Badge variant="outline" className={cn('gap-1', isPro ? 'border-emerald-600/40 text-emerald-600' : 'border-amber-600/40 text-amber-600')}>
            <Sparkles className="w-3 h-3" />
            {isPro ? 'ИИ безлимит — люмены не тратятся' : 'ИИ-действия за люмены'}
          </Badge>
        </div>

        {/* === Пополнение === */}
        <div>
          <div className="text-xs font-medium mb-2 flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" /> Пополнить (1 ₽ = 1 люмен)
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {wallet.topupAmounts.map((amount) => (
              <Button
                key={amount}
                variant="outline"
                size="sm"
                disabled={topping !== null}
                onClick={() => handleTopup(amount)}
                className="gap-1 flex-col h-auto py-2"
              >
                {topping === amount ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <span className="text-sm font-semibold">{amount} ₽</span>
                )}
                <span className="text-xs text-muted-foreground">→ {amount} Л</span>
              </Button>
            ))}
          </div>
          <div className="flex items-start gap-1.5 text-xs text-muted-foreground mt-1.5">
            <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
            Демо-шлюз: реальные деньги не списываются. В проде — YooKassa / CloudPayments.
          </div>
        </div>

        {/* === Дивиденды 15% годовых === */}
        <div className="rounded-lg border bg-muted/30 p-3 space-y-2">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="text-sm font-medium flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Дивиденды {Math.round(wallet.apy * 100)}% годовых
              <TermInfo k="lumen" />
            </div>
            <Button
              size="sm"
              variant="outline"
              disabled={accruing || !hasDeposit}
              onClick={handleAccrueDemo}
              className="gap-1.5 text-xs h-7"
              title={hasDeposit ? 'Честное демо-ускорение для наглядности' : 'Сначала пополните кошелёк'}
            >
              {accruing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              Начислить как за месяц (демо)
            </Button>
          </div>
          <div className="text-xs text-muted-foreground leading-relaxed">
            Начисляются люменами на внесённые рубли, в реальном времени.
            {hasDeposit ? (
              <>
                {' '}Проекция: <strong className="text-foreground">~{wallet.projections.month.toFixed(1)} Л/мес</strong>,
                {' '}<strong className="text-foreground">~{wallet.projections.year.toFixed(0)} Л/год</strong>
                {' '}на текущую базу {wallet.rublesDeposited} ₽.
              </>
            ) : (
              ' Пополни кошелёк — проекция появится здесь.'
            )}
            {' '}Округление до целого люмена, дробный остаток копится и не сгорает.
          </div>
        </div>

        {/* === ИИ-действия за люмены === */}
        <div>
          <div className="text-xs font-medium mb-2">ИИ-действия за люмены (1 клик = списание)</div>
          <div className="flex flex-wrap gap-1.5">
            {wallet.actions.map((a) => (
              <Badge key={a.id} variant="secondary" className="gap-1 text-xs font-normal">
                {a.label}
                <span className="font-semibold text-amber-600">{a.cost} Л</span>
              </Badge>
            ))}
            <Badge variant="outline" className="text-xs font-normal text-muted-foreground">
              Pro / Business — безлимит
            </Badge>
          </div>
        </div>

        {/* === Журнал операций === */}
        <div>
          <div className="text-xs font-medium mb-2 flex items-center gap-1.5">
            <History className="w-3.5 h-3.5" /> Операции
          </div>
          {wallet.transactions.length === 0 ? (
            <div className="text-xs text-muted-foreground bg-muted/30 rounded-md p-3">
              Операций пока нет — это честно: пополните кошелёк или запустите ИИ-действие.
            </div>
          ) : (
            <div className="max-h-96 overflow-y-auto rounded-md border">
              <div className="divide-y">
                {wallet.transactions.map((t) => {
                  const meta = TX_META[t.type] ?? TX_META.spend;
                  return (
                    <div key={t.id} className="flex items-start justify-between gap-3 p-2.5 text-xs">
                      <div className="min-w-0">
                        <div className="font-medium">{meta.label}{t.meta?.label ? `: ${t.meta.label}` : ''}</div>
                        {t.meta?.note && (
                          <div className="text-muted-foreground mt-0.5 leading-snug">{t.meta.note}</div>
                        )}
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {new Date(t.createdAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                      <div className={cn('font-semibold tabular-nums flex-shrink-0', meta.className)}>
                        {meta.sign}{Math.abs(t.lumens)} Л
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
