// BizON — Decision Inbox (W3.4, REC-GOV-07)
// Панель решений человека по предложенным AI-действиям.
//
// Правило (мастер-задание §38): inbox НЕ исполнитель. Кнопки фиксируют решение
// (approved/rejected) в AiApproval/AiAction + AiAuditLog; реальное исполнение —
// отдельный контур с re-check политики/бюджета и rollback.
//
// Каждый элемент показывает (§37): что хочет сделать AI, риск, цену (люмены),
// обратимость, внешнее ли действие, срок на решение.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { Bot, ShieldCheck, Clock, Undo2, ExternalLink, Loader2 } from 'lucide-react';

type Decision = {
  id: string;
  actionId: string;
  actionKey: string;
  title: string;
  risk: string;
  reversible: boolean;
  externalSideEffect: boolean;
  lumenCost: number;
  createdAt: string;
  expiresAt: string;
};

type AutonomyState = {
  mode: 'manual' | 'collaborative';
  autonomyLevel: number;
  allowedModes: readonly string[];
  killed: boolean;
};

// === Wave 6 (S-138): IL-слайдер автономии 0..4 ===
// 0 — ручной (каждое действие через подтверждение); 1 — совместный;
// 2–4 — повышенная автономия (доступна только verified/pro по гейтам тира).
// HOP anti-creeping: повышение — ТОЛЬКО явное действие пользователя здесь;
// никакой автоэскалации (сервер отклоняет agent-вызовы с повышением).
const IL_LEVELS: Record<number, { title: string; hint: string }> = {
  0: { title: 'Ручной', hint: 'AI только предлагает — вы подтверждаете каждое действие' },
  1: { title: 'Совместный', hint: 'AI сам делает безопасное (чтение/черновики), рискованное — через вас' },
  2: { title: 'Делегированный', hint: 'AI выполняет привычные действия сам, все внешние эффекты — через вас' },
  3: { title: 'Поднадзорный', hint: 'AI действует свободнее, вы просматриваете журнал задним числом' },
  4: { title: 'Автономный', hint: 'Максимум автономии; критические действия всё равно требуют 2-of-N' },
};

const RISK_META: Record<string, { label: string; className: string }> = {
  read: { label: 'Чтение', className: 'bg-muted text-muted-foreground' },
  low: { label: 'Низкий', className: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400' },
  medium: { label: 'Средний', className: 'bg-amber-500/10 text-amber-700 dark:text-amber-400' },
  high: { label: 'Высокий', className: 'bg-orange-500/10 text-orange-700 dark:text-orange-400' },
  critical: { label: 'Критический', className: 'bg-destructive/10 text-destructive' },
};

export function DecisionInbox() {
  const [items, setItems] = React.useState<Decision[] | null>(null);
  const [autonomy, setAutonomy] = React.useState<AutonomyState | null>(null);
  const [busyId, setBusyId] = React.useState<string | null>(null);
  const [levelBusy, setLevelBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setError(null);
    try {
      const res = await api<{ decisions: Decision[]; autonomy: AutonomyState }>('/api/ai/decisions');
      setItems(res.decisions ?? []);
      setAutonomy(res.autonomy ?? null);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить решения');
      setItems([]);
    }
  }, []);

  React.useEffect(() => {
    void load();
  }, [load]);

  async function decide(id: string, decision: 'approved' | 'rejected') {
    setBusyId(id);
    try {
      await api(`/api/ai/decisions/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ decision }),
      });
      toast({
        title: decision === 'approved' ? 'Действие разрешено' : 'Действие отклонено',
        description: 'Решение зафиксировано в журнале. Исполнение — отдельный контролируемый контур.',
      });
      await load();
    } catch (e: any) {
      toast({ title: 'Решение не применено', description: e?.message, variant: 'destructive' });
    } finally {
      setBusyId(null);
    }
  }

  async function toggleAutonomy(mode: 'manual' | 'collaborative') {
    try {
      await api('/api/me/autonomy', { method: 'PATCH', body: JSON.stringify({ mode }) });
      toast({ title: mode === 'manual' ? 'Режим: ручной' : 'Режим: совместный' });
      await load();
    } catch (e: any) {
      toast({ title: 'Не удалось изменить режим', description: e?.message, variant: 'destructive' });
    }
  }

  // IL-слайдер: PATCH /api/ai/autonomy (тир-гейты на сервере: basic→1, verified→3, pro/business→4).
  // Ошибку тира показываем честно — уровень не «подкручивается» на клиенте.
  async function setLevel(level: number) {
    if (!autonomy || level === autonomy.autonomyLevel) return;
    setLevelBusy(true);
    try {
      await api('/api/ai/autonomy', { method: 'PATCH', body: JSON.stringify({ level }) });
      toast({ title: `Уровень автономии: ${level} — ${IL_LEVELS[level]?.title ?? ''}` });
      await load();
    } catch (e: any) {
      toast({ title: 'Уровень не применён', description: e?.message, variant: 'destructive' });
    } finally {
      setLevelBusy(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Bot className="w-4 h-4 text-lighthouse" />
          Решения AI (Decision Inbox)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Режим автономии */}
        {autonomy && (
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="min-w-0">
              <div className="text-sm font-medium flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Режим автономии
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {autonomy.mode === 'manual'
                  ? 'Ручной: AI предлагает — вы подтверждаете каждое действие.'
                  : 'Совместный: AI выполняет безопасное (чтение/черновики) сам, рискованное — через вас.'}
                {autonomy.killed && ' Автономия глобально остановлена оператором.'}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <span className="text-xs text-muted-foreground">Ручной</span>
              <Switch
                checked={autonomy.mode === 'collaborative'}
                onCheckedChange={(v) => void toggleAutonomy(v ? 'collaborative' : 'manual')}
                aria-label="Режим автономии: ручной/совместный"
              />
              <span className="text-xs text-muted-foreground">Совместный</span>
            </div>
          </div>
        )}

        {/* IL-слайдер автономии (Wave 6, S-138): явное повышение пользователем,
            гейты тира на сервере, anti-creeping — агент повысить не может */}
        {autonomy && (
          <div className="rounded-lg border p-3 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="text-sm font-medium">Уровень автономии (IL)</div>
              <Badge variant="outline" className="text-xs">
                сейчас: {autonomy.autonomyLevel} · {IL_LEVELS[autonomy.autonomyLevel]?.title ?? '—'}
              </Badge>
            </div>
            <Slider
              value={[autonomy.autonomyLevel]}
              min={0}
              max={4}
              step={1}
              disabled={levelBusy || autonomy.killed}
              aria-label="Уровень автономии AI от 0 до 4"
              onValueChange={(v) => void setLevel(v[0] ?? autonomy.autonomyLevel)}
            />
            <div className="flex justify-between text-[10px] text-muted-foreground">
              {Object.entries(IL_LEVELS).map(([k, v]) => (
                <span key={k} className={Number(k) === autonomy.autonomyLevel ? 'font-semibold text-foreground' : ''}>
                  {k}
                </span>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              {IL_LEVELS[autonomy.autonomyLevel]?.hint}. Повышение — только вручную здесь
              (anti-creeping); тир ограничивает максимум: basic→1, verified→3, pro/business→4.
            </p>
          </div>
        )}

        {/* Загрузка / ошибка / пусто */}
        {items === null && !error && (
          <div className="space-y-2">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        )}
        {error && (
          <div className="text-sm text-destructive" role="alert">
            {error}{' '}
            <button className="underline" onClick={() => void load()}>
              Повторить
            </button>
          </div>
        )}
        {items !== null && !error && items.length === 0 && (
          <div className="text-sm text-muted-foreground">
            Нет действий, ожидающих вашего решения.
          </div>
        )}

        {/* Список решений */}
        <div className="space-y-2">
          {items?.map((item) => {
            const risk = RISK_META[item.risk] ?? RISK_META.read!;
            const expiresSoon = new Date(item.expiresAt).getTime() - Date.now() < 5 * 60_000;
            return (
              <div key={item.id} className="rounded-lg border p-3 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="text-sm font-medium">{item.title}</div>
                  <Badge variant="outline" className={`text-xs ${risk.className}`}>
                    {risk.label} риск
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <Undo2 className="w-3 h-3" />
                    {item.reversible ? 'Обратимо' : 'Необратимо'}
                  </span>
                  {item.externalSideEffect && (
                    <span className="inline-flex items-center gap-1">
                      <ExternalLink className="w-3 h-3" /> Внешний эффект
                    </span>
                  )}
                  {item.lumenCost > 0 && <span>Цена: {item.lumenCost} ЛМ</span>}
                  <span className={`inline-flex items-center gap-1 ${expiresSoon ? 'text-destructive' : ''}`}>
                    <Clock className="w-3 h-3" />
                    до {new Date(item.expiresAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={() => void decide(item.id, 'approved')} disabled={busyId === item.id}>
                    {busyId === item.id && <Loader2 className="w-3 h-3 mr-1 animate-spin" />}
                    Разрешить
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => void decide(item.id, 'rejected')} disabled={busyId === item.id}>
                    Отклонить
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
