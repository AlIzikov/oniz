// BizON — Settings View (переработан по UX-аудиту)
// Правило цветов: Navy = информация (читать), Зелёный = действие (нажать)
// 'Пересчитать' = серая (техническая операция, не карьерный рост)
// 'Сменить тариф' = зелёная (путь к улучшениям)
// IP-score — крупная зелёная цифра наверху (главный KPI)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { useTheme } from 'next-themes';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { DataSovereigntySection } from '@/components/settings/data-sovereignty-section';
import { DecisionInbox } from '@/components/settings/decision-inbox';
import { LumenWallet } from '@/components/settings/lumen-wallet';
import {
  Moon, Sun, Monitor, RefreshCw, LogOut, Info, ShieldCheck, Crown, Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function SettingsView() {
  const { user, logout, setUser } = useAppStore();
  const { theme, setTheme } = useTheme();
  const [recalculating, setRecalculating] = React.useState(false);

  async function handleRecalculate() {
    setRecalculating(true);
    try {
      const res = await api<{ ipScore: number; level: string }>('/api/reputation/recalculate', { method: 'POST' });
      if (user) setUser({ ...user, ipScore: res.ipScore, level: res.level as any });
      toast({ title: 'IP-score пересчитан', description: `${res.ipScore}/100 · уровень: ${res.level}` });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setRecalculating(false);
    }
  }

  async function handleLogout() {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
    logout();
    toast({ title: 'Вы вышли' });
  }

  if (!user) return null;

  const tierLabel = user.subscriptionTier === 'free' ? 'Free' : user.subscriptionTier === 'pro' ? 'Pro' : 'Business';
  const isFree = user.subscriptionTier === 'free';

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Настройки</h1>
        <p className="text-sm text-muted-foreground">Управление аккаунтом и предпочтениями</p>
      </div>

      {/* === IP-SCORE HERO — главный KPI наверх, крупным числом (Navy) === */}
      <Card className="bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-blue-950/30 border-primary/30">
        <CardContent className="p-5">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              {/* Крупная цифра IP-score — Navy (информация), не зелёный */}
              <div className="text-center">
                <div className="text-5xl font-extrabold tabular-nums text-[#1e3a8a] dark:text-blue-400 leading-none">
                  {user.ipScore}
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">из 100</div>
              </div>
              <div className="h-12 w-px bg-border" />
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Ваш индекс доверия</div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-semibold">{user.level === 'basic' ? 'Базовый' : user.level === 'extended' ? 'Проверенный' : 'Эксперт'}</span>
                  {user.level === 'expert' && (
                    <Badge variant="outline" className="gap-1 border-border text-foreground bg-muted/50">
                      <ShieldCheck className="w-3 h-3 text-[#1e3a8a] dark:text-blue-400" /> Эксперт
                    </Badge>
                  )}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">Репутация — ваша валюта</div>
              </div>
            </div>
            {/* Серая кнопка «Пересчитать» — техническая операция, не зелёная */}
            <div className="flex flex-col items-end gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRecalculate}
                disabled={recalculating}
                className="text-muted-foreground"
                title="Пересчёт может занять до 1 минуты и временно изменить ваш IP-score"
              >
                <RefreshCw className={cn('w-3.5 h-3.5 mr-1.5', recalculating && 'animate-spin')} />
                Пересчитать
              </Button>
              <span className="text-xs text-muted-foreground/70 max-w-[180px] text-right">
                ⚠ Может временно изменить значение
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* === Тариф — кнопка «Сменить тариф» ЗЕЛЁНАЯ (путь к улучшениям) === */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Crown className="w-4 h-4 text-amber-500" />
            Тариф
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              {/* Название тарифа — Navy жирным */}
              <div className="text-sm">
                Текущий тариф: <strong className="text-[#1e3a8a] dark:text-blue-400 text-base">{tierLabel}</strong>
              </div>
              {user.subscriptionUntil && (
                <div className="text-xs text-muted-foreground mt-0.5">
                  до {new Date(user.subscriptionUntil).toLocaleDateString('ru-RU')}
                </div>
              )}
            </div>
            {/* Кнопка «Сменить тариф» — ЗЕЛЁНАЯ (ведёт к улучшениям) */}
            {isFree && (
              <Button
                size="sm"
                onClick={() => useAppStore.getState().setView('subscription')}
                className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
              >
                <Zap className="w-3.5 h-3.5" />
                Сменить тариф
              </Button>
            )}
            {!isFree && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => useAppStore.getState().setView('subscription')}
              >
                Управление
              </Button>
            )}
          </div>
          {/* Ограничения Free — мягче, со словом «Pro» зелёным как «свет в конце тоннеля» */}
          {isFree && (
            <div className="text-xs text-muted-foreground bg-muted/40 p-3 rounded-md leading-relaxed">
              На Free-тарифе: до 5 постов в день; ИИ-действия — за люмены (1 клик = 1–2 люмена,
              1 ₽ = 1 люмен). Перейдите на <strong className="text-[#1e3a8a] dark:text-blue-400">Pro</strong> — ИИ безлимит, люмены не тратятся.
            </div>
          )}
        </CardContent>
      </Card>

      {/* === Кошелёк люменов (волна 14: 1 ₽ = 1 люмен, 1 люмен = 1 ИИ-действие) === */}
      <LumenWallet />

      {/* === Внешний вид — тема === */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Внешний вид</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm font-medium mb-2">Тема оформления</div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <ThemeButton current={theme} value="light" onClick={() => setTheme('light')} icon={<Sun className="w-4 h-4" />} label="Светлая" />
            <ThemeButton current={theme} value="dark" onClick={() => setTheme('dark')} icon={<Moon className="w-4 h-4" />} label="Тёмная" />
            <ThemeButton current={theme} value="system" onClick={() => setTheme('system')} icon={<Monitor className="w-4 h-4" />} label="Системная" />
          </div>
        </CardContent>
      </Card>

      {/* === Безопасность === */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#1e3a8a] dark:text-blue-400" />
            Безопасность аккаунта
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* W2.4 (DEF-10): реальный UI 2FA — backend TOTP уже реализован
              (/api/auth/2fa/enable|confirm|disable|verify), «Скоро»-заглушка
              противоречила коду. */}
          <TwoFactorSection />
          {/* P1-11: убраны disabled-тумблеры "Фаза 2" (DAO, NFT-Skills, Trust Economy)
              — они вызывали frustration у пользователя. Будут добавлены когда функции готовы. */}
        </CardContent>
      </Card>

      {/* === W3.4: Decision Inbox + режим автономии === */}
      <DecisionInbox />

      {/* === Данные и суверенитет (152-ФЗ/GDPR: citizenship/region/согласия) === */}
      <DataSovereigntySection />

      {/* === О системе — отдельный раздел внизу === */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Info className="w-4 h-4" /> О системе</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <div className="flex justify-between"><span>Версия</span><span className="font-mono">v10.0 MVP (Фаза 1)</span></div>
          <div className="flex justify-between"><span>Документ ТЗ</span><span className="font-mono">BZN-TS-10.0-2025</span></div>
          <div className="flex justify-between"><span>Стек</span><span className="font-mono">Next.js 16 · Prisma · TypeScript</span></div>
          <div className="flex justify-between"><span>AI</span><span className="font-mono">z-ai-web-dev-sdk</span></div>
        </CardContent>
      </Card>

      {/* === Выход === */}
      <Card className="border-destructive/30">
        <CardContent className="p-4">
          <Button variant="destructive" onClick={handleLogout} className="w-full">
            <LogOut className="w-4 h-4 mr-2" /> Выйти из BizON
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function ThemeButton({ current, value, onClick, icon, label }: {
  current?: string;
  value: string;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  const isActive = current === value;
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex flex-col items-center gap-1.5 p-3 border-2 rounded-lg transition',
        isActive
          ? 'border-[#1e3a8a] dark:border-blue-400 bg-primary/5 text-[#1e3a8a] dark:text-blue-400'
          : 'border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'
      )}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

function FlagRow({ label, desc, enabled }: { label: string; desc: string; enabled: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={enabled} disabled />
    </div>
  );
}


// ===========================================================================
// W2.4 (DEF-10): реальная секция 2FA — enable (QR+confirm) / disable.
// Контракты бэкенда: POST /api/auth/2fa/enable {password} → {qrUrl, secret,
// backupCodes}; POST /api/auth/2fa/confirm {token} → {ok}; POST
// /api/auth/2fa/disable {password} → {ok}.
// ===========================================================================
function TwoFactorSection() {
  const { user, setUser } = useAppStore();
  const enabled = user?.twoFactorEnabled === true;
  const [busy, setBusy] = React.useState(false);
  const [password, setPassword] = React.useState('');
  const [setup, setSetup] = React.useState<{ qrUrl: string; secret: string; backupCodes: string[] } | null>(null);
  const [code, setCode] = React.useState('');
  const [disableOpen, setDisableOpen] = React.useState(false);

  async function startEnable() {
    if (!password) {
      toast({ title: 'Введите текущий пароль', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      const res = await api<{ qrUrl: string; secret: string; backupCodes: string[] }>(
        '/api/auth/2fa/enable',
        { method: 'POST', body: JSON.stringify({ password }) },
      );
      setSetup(res);
      setPassword('');
    } catch (e: any) {
      toast({ title: 'Не удалось начать настройку', description: e?.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  async function confirmEnable() {
    if (!/^\d{6}$/.test(code)) {
      toast({ title: 'Код должен состоять из 6 цифр', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      await api('/api/auth/2fa/confirm', { method: 'POST', body: JSON.stringify({ token: code }) });
      if (user) setUser({ ...user, twoFactorEnabled: true });
      setSetup(null);
      setCode('');
      toast({ title: '2FA включена', description: 'Теперь вход требует код из приложения.' });
    } catch (e: any) {
      toast({ title: 'Код не принят', description: e?.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  async function disable2fa() {
    if (!password) {
      toast({ title: 'Введите текущий пароль', variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      await api('/api/auth/2fa/disable', { method: 'POST', body: JSON.stringify({ password }) });
      if (user) setUser({ ...user, twoFactorEnabled: false });
      setDisableOpen(false);
      setPassword('');
      toast({ title: '2FA отключена' });
    } catch (e: any) {
      toast({ title: 'Не удалось отключить', description: e?.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="p-3 rounded-lg border bg-card space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <ShieldCheck className={enabled ? 'w-5 h-5 text-emerald-600' : 'w-5 h-5 text-muted-foreground'} />
          <div>
            <div className="text-sm font-medium flex items-center gap-2">
              2FA — двухфакторная аутентификация
              <Badge
                variant={enabled ? 'default' : 'outline'}
                className={enabled ? 'text-xs bg-emerald-600 text-white' : 'text-xs text-muted-foreground'}
              >
                {enabled ? 'Включена' : 'Выключена'}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">
              Дополнительная защита через TOTP (Google Authenticator и совместимые).
            </div>
          </div>
        </div>
        {!enabled && (
          <Button size="sm" onClick={() => { setSetup(setup ? null : setup); setPassword(''); }} disabled={busy}>
            {setup ? 'Отмена' : 'Включить'}
          </Button>
        )}
        {enabled && (
          <Button size="sm" variant="outline" onClick={() => setDisableOpen(!disableOpen)} disabled={busy}>
            Отключить
          </Button>
        )}
      </div>

      {/* Enable flow: password → QR/secret + backupCodes → confirm code */}
      {!enabled && !setup && (
        <div className="space-y-2">
          <Input
            type="password"
            placeholder="Текущий пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />
          <Button size="sm" variant="outline" onClick={startEnable} disabled={busy}>
            Продолжить
          </Button>
        </div>
      )}

      {setup && (
        <div className="space-y-3 rounded-lg border p-3 bg-muted/20">
          <div className="text-sm font-medium">Шаг 1. Отсканируйте QR в приложении-аутентификаторе</div>
          <div className="flex flex-col sm:flex-row items-start gap-3">
            {/* QR встроен в otpauth-URL; рендерим ссылку + секрет для ручного ввода */}
            <img src={setup.qrUrl} alt="QR-код для приложения-аутентификатора" className="w-40 h-40 bg-white p-1 rounded-md" />
            <div className="text-xs space-y-1 min-w-0">
              <div className="text-muted-foreground">Ручной ввод (секрет):</div>
              <code className="block break-all font-mono text-[11px] bg-background border rounded px-2 py-1">{setup.secret}</code>
            </div>
          </div>
          <div className="text-sm font-medium">Шаг 2. Резервные коды (покаж один раз — сохраните)</div>
          <div className="flex flex-wrap gap-1.5">
            {setup.backupCodes.map((c, i) => (
              <code key={i} className="text-[11px] font-mono bg-background border rounded px-1.5 py-0.5">{c}</code>
            ))}
          </div>
          <div className="text-sm font-medium">Шаг 3. Введите первый код из приложения</div>
          <div className="flex gap-2">
            <Input
              inputMode="numeric"
              placeholder="000000"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
              className="max-w-[140px] font-mono"
            />
            <Button size="sm" onClick={confirmEnable} disabled={busy || code.length !== 6}>
              Подтвердить
            </Button>
          </div>
        </div>
      )}

      {enabled && disableOpen && (
        <div className="space-y-2 rounded-lg border border-destructive/30 p-3 bg-destructive/5">
          <div className="text-sm font-medium text-destructive">Отключение 2FA</div>
          <Input
            type="password"
            placeholder="Текущий пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />
          <div className="flex gap-2">
            <Button size="sm" variant="destructive" onClick={disable2fa} disabled={busy}>
              Отключить 2FA
            </Button>
            <Button size="sm" variant="ghost" onClick={() => { setDisableOpen(false); setPassword(''); }}>
              Отмена
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
