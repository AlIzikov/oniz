// BizON — Subscription View (3 тарифа: Free / Pro / Business)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';
import type { SubscriptionPlan, SubscriptionTier } from '@/lib/types';
import { Check, Loader2, Crown, Building2, Sparkles, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const TIER_ICONS: Record<SubscriptionTier, React.ReactNode> = {
  free: <Sparkles className="w-5 h-5" />,
  pro: <Crown className="w-5 h-5" />,
  business: <Building2 className="w-5 h-5" />,
};

const TIER_LABELS: Record<SubscriptionTier, string> = {
  free: 'Бесплатно',
  pro: 'Pro',
  business: 'Business',
};

export function SubscriptionView() {
  const { user, setUser } = useAppStore();
  const [plans, setPlans] = React.useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [subscribing, setSubscribing] = React.useState<SubscriptionTier | null>(null);
  const [period, setPeriod] = React.useState<'monthly' | 'yearly'>('monthly');

  React.useEffect(() => {
    api<{ plans: SubscriptionPlan[] }>('/api/subscriptions')
      .then((res) => setPlans(res.plans))
      .catch((e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, []);

  async function handleSubscribe(tier: SubscriptionTier) {
    if (tier === 'free') {
      // отменить подписку
      setSubscribing(tier);
      try {
        const res = await api<{ user: any; message: string }>('/api/subscriptions', { method: 'DELETE' });
        setUser(res.user);
        toast({ title: 'Подписка отменена', description: 'Вы на бесплатном тарифе' });
      } catch (e: any) {
        toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
      } finally {
        setSubscribing(null);
      }
      return;
    }
    setSubscribing(tier);
    try {
      const res = await api<{ user: any; message: string }>('/api/subscriptions', {
        method: 'POST',
        body: JSON.stringify({ tier, period }),
      });
      setUser(res.user);
      toast({ title: 'Подписка активирована', description: res.message });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSubscribing(null);
    }
  }

  if (loading) return <div className="p-8 text-center text-muted-foreground">Загрузка...</div>;
  if (!user) return null;

  const currentTier = user.subscriptionTier;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">Тарифы BizON</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Обычные посты и базовые функции — <strong>бесплатно навсегда</strong>.
          Подписка нужна только для коммерческой выгоды и продвинутых AI-возможностей.
        </p>
      </div>

      {/* Period toggle */}
      <div className="flex justify-center">
        <div className="inline-flex rounded-lg border p-1 bg-muted/50">
          <button
            onClick={() => setPeriod('monthly')}
            className={cn(
              'px-4 py-1.5 text-sm rounded-md transition',
              period === 'monthly' ? 'bg-background shadow-sm font-medium' : 'text-muted-foreground'
            )}
          >
            Помесячно
          </button>
          <button
            onClick={() => setPeriod('yearly')}
            className={cn(
              'px-4 py-1.5 text-sm rounded-md transition flex items-center gap-1',
              period === 'yearly' ? 'bg-background shadow-sm font-medium' : 'text-muted-foreground'
            )}
          >
            Годовой <Badge className="bg-emerald-500 text-white text-xs">−17%</Badge>
          </button>
        </div>
      </div>

      {/* Current plan banner */}
      {currentTier !== 'free' && (
        <Card className="bg-gradient-to-r from-primary/10 to-emerald-500/10 border-primary/30">
          <CardContent className="p-4 flex items-center justify-between flex-wrap gap-3">
            <div>
              <div className="text-sm text-muted-foreground">Ваш текущий тариф</div>
              <div className="text-xl font-bold flex items-center gap-2">
                {TIER_ICONS[currentTier]} {TIER_LABELS[currentTier]}
                {user.subscriptionUntil && (
                  <span className="text-sm font-normal text-muted-foreground">
                    · до {new Date(user.subscriptionUntil).toLocaleDateString('ru-RU')}
                  </span>
                )}
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => handleSubscribe('free')} disabled={subscribing === 'free'}>
              {subscribing === 'free' ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Отменить подписку'}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Plans grid */}
      <div className="grid md:grid-cols-3 gap-4">
        {plans.map((plan) => {
          const isCurrent = currentTier === plan.id;
          const price = period === 'yearly' ? plan.priceYearly : plan.priceMonthly;
          const periodLabel = period === 'yearly' ? '/ год' : '/ мес';

          return (
            <Card
              key={plan.id}
              className={cn(
                'relative flex flex-col',
                plan.highlight && 'border-primary shadow-lg md:scale-105',
                isCurrent && 'ring-2 ring-primary'
              )}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">Популярный</Badge>
                </div>
              )}
              <CardContent className="p-6 flex flex-col flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center', plan.ctaColor)}>
                    {TIER_ICONS[plan.id]}
                  </div>
                  <h2 className="text-2xl font-bold">{plan.name}</h2>
                </div>
                <p className="text-sm text-muted-foreground mb-4 min-h-[40px]">{plan.description}</p>

                <div className="mb-4">
                  {plan.priceMonthly === 0 ? (
                    <div className="text-3xl font-bold">0 ₽</div>
                  ) : (
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-bold">{price.toLocaleString('ru-RU')} ₽</span>
                      <span className="text-sm text-muted-foreground">{periodLabel}</span>
                    </div>
                  )}
                </div>

                <Separator className="my-4" />

                <ul className="space-y-2 flex-1 mb-4">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={cn('w-full', plan.ctaColor)}
                  variant={plan.id === 'free' ? 'outline' : 'default'}
                  disabled={isCurrent || subscribing === plan.id}
                  onClick={() => handleSubscribe(plan.id)}
                >
                  {subscribing === plan.id ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-1" />
                  ) : isCurrent ? (
                    <>
                      <Check className="w-4 h-4 mr-1" /> Текущий тариф
                    </>
                  ) : plan.id === 'free' ? (
                    'Перейти на Free'
                  ) : (
                    `Оформить ${plan.name}`
                  )}
                </Button>

                {!isCurrent && plan.id !== 'free' && (
                  <p className="text-xs text-center text-muted-foreground mt-2">
                    Отмена в любой момент
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* P2-6: Сравнительная таблица тарифов */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-semibold mb-4 text-lg">Сравнение тарифов</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-3 font-medium text-muted-foreground">Возможность</th>
                  <th className="text-center py-2 px-3 font-semibold">Free</th>
                  <th className="text-center py-2 px-3 font-semibold text-primary">Pro</th>
                  <th className="text-center py-2 px-3 font-semibold text-primary">Business</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Посты в ленте', '5/день', 'Безлимит', 'Безлимит'],
                  ['Кошелёк люменов (1 ₽ = 1 люмен)', '✓', '✓', '✓'],
                  ['Дивиденды на кошелёк · 15% годовых люменами', '✓', '✓', '✓'],
                  ['AI-Matchmaker', '5/час', '50/час', '500/час'],
                  ['AI-Career-Agent', '1 люмен/запуск', 'Безлимит', 'Безлимит'],
                  ['ИИ-резюме и сопроводительные письма', '2 люмена', 'Безлимит', 'Безлимит'],
                  ['Карьерные сценарии «что если»', '1 люмен', 'Безлимит', 'Безлимит'],
                  ['Commercial посты (CTA)', '—', '—', '✓'],
                  ['Публикация вакансий', '—', '—', 'Безлимит'],
                  ['Навыки', 'До 5', 'Безлимит', 'Безлимит'],
                  ['AI-Ad-Moderator', '—', '—', '✓'],
                  ['Аналитика кандидатов', '—', '—', '✓'],
                  ['Приоритетная поддержка', '—', '✓', '✓'],
                  ['14 дней возврата', '—', '✓', '✓'],
                ].map((row, i) => (
                  <tr key={i} className="border-b last:border-0">
                    <td className="py-2 px-3 font-medium">{row[0]}</td>
                    <td className="text-center py-2 px-3 text-muted-foreground">{row[1]}</td>
                    <td className="text-center py-2 px-3 text-primary font-medium">{row[2]}</td>
                    <td className="text-center py-2 px-3 text-primary font-medium">{row[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* FAQ */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-semibold mb-3 text-lg">Частые вопросы</h3>
          <div className="space-y-3 text-sm">
            <div>
              <div className="font-medium mb-1">Что такое люмены?</div>
              <div className="text-muted-foreground">
                Внутренняя валюта ИИ-действий: 1 ₽ = 1 люмен, 1 люмен = 1 действие ИИ (один клик).
                Люмены не сгорают, а на внесённую сумму начисляются дивиденды — 15% годовых люменами.
                Если ИИ вернул не-AI-результат — люмен возвращается.
              </div>
            </div>
            <div>
              <div className="font-medium mb-1">Можно ли публиковать посты бесплатно?</div>
              <div className="text-muted-foreground">
                Да, на Free-тарифе можно публиковать до 5 постов в день. Безлимит — на Pro и Business.
              </div>
            </div>
            <div>
              <div className="font-medium mb-1">Что такое Commercial-пост?</div>
              <div className="text-muted-foreground">
                Это пост с CTA-кнопкой (например, «Записаться» или «Купить») — для продажи услуг, рекламы вакансий, набора на курс. Доступен только на Business.
              </div>
            </div>
            <div>
              <div className="font-medium mb-1">AI-Career-Agent работает на Free?</div>
              <div className="text-muted-foreground">
                Да — за люмены: 1 люмен за запуск (1 ₽ = 1 люмен). Не хватает — откроется диалог пополнения.
                На Pro и Business — безлимит, люмены не тратятся.
              </div>
            </div>
            <div>
              <div className="font-medium mb-1">Можно ли вернуть деньги?</div>
              <div className="text-muted-foreground">
                Да, в течение 14 дней — полный возврат без вопросов. Напишите в поддержку.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Идеология */}
      <Card className="bg-gradient-to-br from-primary/5 to-emerald-500/5 border-primary/20">
        <CardContent className="p-6">
          <h3 className="font-semibold mb-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" /> Наша идеология
          </h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            BizON не продаёт внимание пользователя — мы вознаграждаем доверие.
            Если вы просто делитесь знаниями и строите сеть — это <strong>бесплатно навсегда</strong>.
            Платить стоит только тогда, когда вы получаете пользу: запуск ИИ стоит 1–2 люмена
            (1 ₽ = 1 люмен, люмены не сгорают, дивиденды 15% годовых люменами),
            а Pro снимает все лимиты. Это честная модель, которая усиливает доверие в сети, а не разрушает его.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
