// BizON v6 — Секция «Данные и суверенитет» на экране настроек
// PDF «doc_scaling» §2-4, 27: сбор citizenship/region/согласий,
// без которых Data Sovereignty Gateway (152-ФЗ/GDPR) не применяет правила.
'use client';

import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { api } from '@/stores/app-store';
import { Globe, Sparkles, AlertTriangle, Loader2, ShieldCheck, PlaneTakeoff } from 'lucide-react';
import { cn } from '@/lib/utils';

type Citizenship = 'RU' | 'EU' | 'BRICS' | 'OTHER';
type Regulation = '152-FZ' | 'GDPR' | 'none';

type SovereigntyState = {
  citizenship: Citizenship | null;
  region: string | null;
  consentAiAnalysis: boolean;
  consentCrossBorder: boolean;
  regulation: Regulation;
};

type SovereigntyUpdateResponse = {
  citizenship: Citizenship | null;
  region: string | null;
  consentAiAnalysis: boolean;
  consentCrossBorder: boolean;
  decision: { allowed: boolean; regulation: Regulation };
};

const CITIZENSHIP_LABELS: Record<Citizenship, string> = {
  RU: 'Российская Федерация',
  EU: 'Европейский союз (ЕС)',
  BRICS: 'БРИКС',
  OTHER: 'Другое',
};

const REGULATION_LABELS: Record<Regulation, string> = {
  '152-FZ': '152-ФЗ',
  GDPR: 'GDPR',
  none: 'Не определён',
};

export function DataSovereigntySection() {
  const [state, setState] = React.useState<SovereigntyState | null>(null);
  const [regionDraft, setRegionDraft] = React.useState('');
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await api<SovereigntyState>('/api/me/sovereignty/update');
        if (cancelled) return;
        setState(data);
        setRegionDraft(data.region ?? '');
      } catch (e: unknown) {
        if (!cancelled) {
          toast({
            title: 'Не удалось загрузить настройки суверенитета',
            description: e instanceof Error ? e.message : undefined,
            variant: 'destructive',
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  async function handleSave() {
    if (!state) return;
    setSaving(true);
    try {
      const trimmedRegion = regionDraft.trim();
      const data = await api<SovereigntyUpdateResponse>('/api/me/sovereignty/update', {
        method: 'PATCH',
        body: JSON.stringify({
          citizenship: state.citizenship,
          region: trimmedRegion.length > 0 ? trimmedRegion : null,
          consentAiAnalysis: state.consentAiAnalysis,
          consentCrossBorder: state.consentCrossBorder,
        }),
      });
      setState((prev) => prev ? {
        ...prev,
        citizenship: data.citizenship,
        region: data.region,
        consentAiAnalysis: data.consentAiAnalysis,
        consentCrossBorder: data.consentCrossBorder,
        regulation: data.decision.regulation,
      } : prev);
      setRegionDraft(data.region ?? '');
      toast({
        title: 'Настройки суверенитета сохранены',
        description: data.decision.regulation === '152-FZ'
          ? 'Gateway применяет правила 152-ФЗ: персональные данные (класс A) не покидают РФ'
          : data.decision.regulation === 'GDPR'
            ? 'Gateway применяет правила GDPR: требуется минимизация PII'
            : 'Gateway: регуляторный режим не определён',
      });
    } catch (e: unknown) {
      toast({
        title: 'Ошибка сохранения',
        description: e instanceof Error ? e.message : 'Попробуйте ещё раз',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  }

  const ruCrossBorderWarning = state?.citizenship === 'RU' && state.consentCrossBorder;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Globe className="w-4 h-4 text-[#1e3a8a] dark:text-blue-400" />
          Данные и суверенитет
          {state && (
            <Badge variant="outline" className="ml-auto gap-1 border-border text-foreground bg-muted/50">
              <ShieldCheck className="w-3 h-3 text-[#1e3a8a] dark:text-blue-400" />
              {REGULATION_LABELS[state.regulation]}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
            <Loader2 className="w-4 h-4 animate-spin" /> Загрузка настроек…
          </div>
        ) : state ? (
          <>
            {/* Гражданство */}
            <div className="space-y-1.5">
              <Label htmlFor="sovereignty-citizenship" className="text-sm">Гражданство</Label>
              <Select
                value={state.citizenship ?? undefined}
                onValueChange={(v) => setState((prev) => prev ? { ...prev, citizenship: v as Citizenship } : prev)}
              >
                <SelectTrigger id="sovereignty-citizenship" className="w-full sm:w-64">
                  <SelectValue placeholder="Не указано" />
                </SelectTrigger>
                <SelectContent>
                  {(Object.keys(CITIZENSHIP_LABELS) as Citizenship[]).map((c) => (
                    <SelectItem key={c} value={c}>{CITIZENSHIP_LABELS[c]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Определяет регуляторный режим Gateway: 152-ФЗ (РФ), GDPR (ЕС) или базовая политика.
              </p>
            </div>

            {/* Регион хранения данных */}
            <div className="space-y-1.5">
              <Label htmlFor="sovereignty-region" className="text-sm">Регион хранения данных</Label>
              <Input
                id="sovereignty-region"
                value={regionDraft}
                onChange={(e) => setRegionDraft(e.target.value)}
                maxLength={50}
                placeholder="Например: Москва"
                className="max-w-xs"
              />
              <p className="text-xs text-muted-foreground">До 50 символов. Используется при проверке трансграничной передачи.</p>
            </div>

            {/* Согласие на AI-анализ */}
            <div className="flex items-start justify-between gap-4 p-3 rounded-lg border bg-muted/20">
              <div className="space-y-0.5">
                <div className="text-sm font-medium flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-[#1e3a8a] dark:text-blue-400" />
                  Согласие на AI-анализ профиля
                </div>
                <p className="text-xs text-muted-foreground">
                  Позволяет BizON анализировать ваш профиль для рекомендаций. Персональные данные при этом анонимизируются.
                </p>
              </div>
              <Switch
                checked={state.consentAiAnalysis}
                onCheckedChange={(v) => setState((prev) => prev ? { ...prev, consentAiAnalysis: v } : prev)}
                aria-label="Согласие на AI-анализ профиля"
              />
            </div>

            {/* Согласие на трансграничную передачу */}
            <div className="flex items-start justify-between gap-4 p-3 rounded-lg border bg-muted/20">
              <div className="space-y-0.5">
                <div className="text-sm font-medium flex items-center gap-1.5">
                  <PlaneTakeoff className="w-4 h-4 text-[#1e3a8a] dark:text-blue-400" />
                  Согласие на трансграничную передачу
                </div>
                <p className="text-xs text-muted-foreground">
                  Для граждан РФ отключено по умолчанию — данные класса A (персональные) не покидают РФ согласно 152-ФЗ.
                </p>
              </div>
              <Switch
                checked={state.consentCrossBorder}
                onCheckedChange={(v) => setState((prev) => prev ? { ...prev, consentCrossBorder: v } : prev)}
                aria-label="Согласие на трансграничную передачу"
              />
            </div>

            {/* Inline-warning: РФ + трансграничная передача */}
            {ruCrossBorderWarning && (
              <Alert variant="destructive" className="border-amber-500/50 text-amber-700 dark:text-amber-400 [&>svg]:text-amber-600 dark:[&>svg]:text-amber-400">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>
                  ⚠️ При гражданстве РФ трансграничная передача персональных данных ограничена 152-ФЗ. Gateway будет блокировать вывоз данных класса A.
                </AlertDescription>
              </Alert>
            )}

            {/* Сохранить — зелёная (действие, как «Сменить тариф») */}
            <div className="flex justify-end">
              <Button
                size="sm"
                onClick={handleSave}
                disabled={saving}
                className={cn('bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5')}
              >
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                {saving ? 'Сохранение…' : 'Сохранить'}
              </Button>
            </div>
          </>
        ) : (
          <div className="text-sm text-muted-foreground">Настройки недоступны. Попробуйте перезагрузить страницу.</div>
        )}
      </CardContent>
    </Card>
  );
}
