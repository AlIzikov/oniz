// BizON — CompaniesWithOpenJobs (компании с открытыми вакансиями)
// Блок на дашборде: реальные компании и их реальные открытые вакансии.
// W1.3 (REC-TRUTH-02): удалены фейковые matchScore (random 70-95) и random
// openJobs; показываются только реальные счётчики из /api/companies
// (activeJobsCount, followersCount). Заголовок блока тоже честный — прежний
// «Компании, которым вы интересны» не соответствовал логике выборки.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Building2, ChevronRight } from 'lucide-react';

interface Company {
  id: string;
  name: string;
  logoUrl: string | null;
  activeJobsCount: number;
  followersCount: number;
}

export function InterestedCompanies() {
  const setView = useAppStore((s) => s.setView);
  const setSelectedCompanyId = useAppStore((s) => s.setSelectedCompanyId);
  const [companies, setCompanies] = React.useState<Company[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function load() {
      try {
        const res = await api<{ companies: any[] }>('/api/companies');
        // Только реальные данные: компании с ≥1 открытой вакансией,
        // сортировка по реальному количеству вакансий
        const mapped: Company[] = (res.companies ?? [])
          .map((c: any) => ({
            id: c.id,
            name: c.name,
            logoUrl: c.logoUrl ?? null,
            activeJobsCount: Number(c.activeJobsCount ?? 0),
            followersCount: Number(c.followersCount ?? 0),
          }))
          .filter((c) => c.activeJobsCount > 0)
          .sort((a, b) => b.activeJobsCount - a.activeJobsCount)
          .slice(0, 6);
        setCompanies(mapped);
      } catch {
        // ошибка загрузки — показываем пустой список (блок скроется)
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <Skeleton className="h-4 w-48" />
          </div>
          <div className="flex gap-2 flex-wrap">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="w-12 h-12 rounded-lg" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (companies.length === 0) return null;

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold flex items-center gap-2">
            <span className="w-1 h-3.5 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
            Компании с открытыми вакансиями
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView('companies')}>
            Все <ChevronRight className="w-3 h-3" />
          </Button>
        </div>

        {/* Compact grid из логотипов компаний */}
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {companies.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCompanyId(c.id)}
              className="group relative flex flex-col items-center gap-1.5 p-2 rounded-lg hover:bg-accent transition"
              title={`${c.name} · ${c.activeJobsCount} открытых вакансий · ${c.followersCount} подписчиков`}
            >
              {/* Логотип */}
              <div className="w-12 h-12 rounded-lg overflow-hidden border bg-muted flex items-center justify-center flex-shrink-0">
                {c.logoUrl ? (
                  <img
                    src={c.logoUrl}
                    alt={c.name}
                    className="w-full h-full object-cover"
                    onError={(e) => { e.currentTarget.style.display = 'none'; }}
                  />
                ) : (
                  <Building2 className="w-5 h-5 text-muted-foreground" />
                )}
              </div>
              {/* Название — truncate */}
              <span className="text-xs font-medium text-center truncate max-w-full">{c.name}</span>
              {/* Реальное число вакансий */}
              <span className="text-xs text-muted-foreground font-medium tabular-nums">
                {c.activeJobsCount}{" "}
                {c.activeJobsCount === 1
                  ? 'вакансия'
                  : c.activeJobsCount >= 2 && c.activeJobsCount <= 4
                    ? 'вакансии'
                    : 'вакансий'}
              </span>
            </button>
          ))}
        </div>

        {/* Подсказка — реальная основа выборки */}
        <div className="text-xs text-muted-foreground mt-3 text-center">
          Компании BizON с активными вакансиями
        </div>
      </CardContent>
    </Card>
  );
}
