// BizON — DashboardView (5-блочная структура doc_a §51-52, задача 4-g)
//
// ДО 4-g: старый дашборд (IP-ring, AI-рекомендации, calendar, quick-stats) без
// блоков doc_a; 5-блочный Home жил только в MeView → whats-new-tab.
// ПОСЛЕ 4-g (порядок блоков именно 1-5 сверху вниз):
//   Приветствие «Доброе утро/день/вечер, {имя}» + профессиональный статус
//   Блок 1 «Что изменилось»                — дельты из GET /api/me/whats-new
//   Блок 2 «Что важно»                     — Professional Trust (primary, «новый
//     стандарт доверия», doc_a §41) + отдельные метрики Network Influence и
//     Activity + IP-score ring (легаси-вторичный) + TrustBadge + Evidence Coverage
//   Блок 3 «Что делать»                    — NextBestActionCard (self-fetch, как в whats-new-tab)
//   Блок 4 «Какие возможности появились»   — BizonDiscover (self-fetch)
//   Блок 5 «Что произошло на рынке»        — BizonSignalCard (self-fetch)
//   — ниже — вспомогательные блоки (перенесены, не удалены): InfoBanner, BizON
//     рекомендует, ActionCards, MonthlyCalendar, InterestedCompanies, QuickStats,
//     превью ленты, ближайшие события, «Репутация — ваша валюта».
//
// Task 10-c (doc_a п.1, HOME-метрики): в Блок 2 добавлен Professional Trust —
// первичная метрика доверия (6-факторная формула, «новый стандарт доверия»);
// IP-score остаётся легаси-вторичным (помечен). Network Influence и Activity —
// ОТДЕЛЬНЫЕ метрики рядом (в формулу Trust сознательно не входят — см. шапку
// professional-trust-service.ts). Данные — GET /api/me/home-metrics; пустые
// состояния честные (без выдуманных цифр).
//
// Сигнатура НЕ изменена: page.tsx:113 рендерит <DashboardView /> (без пропсов).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge, IpScoreRing } from '@/components/common/trust-badge';
import type { UserPublic } from '@/lib/types';
import {
  Sparkles, Brain, Briefcase, Users, FolderKanban,
  ChevronRight, Award, ArrowUp, ArrowDown, Target, Lightbulb,
  TrendingUp, ShieldCheck, Activity, CheckCircle2,
} from 'lucide-react';
import { InfoBanner } from '@/components/common/info-banner';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';
import { MonthlyCalendar } from './monthly-calendar';
import { InterestedCompanies } from './interested-companies';
import { NextBestActionCard } from '@/components/truth/next-best-action-card';
import { BizonDiscover } from '@/components/me/bizon-discover';
import { BizonSignalCard } from '@/components/me/bizon-signal-card';

// ============================================================================
// === Типы ===
// ============================================================================

/** Используемые поля ответа GET /api/me/whats-new (см. route.ts) */
interface WhatsNewLite {
  trustDelta30: number | null;
  trustHero?: {
    score: number;
    evidenceCoverage: number | null;
  };
  deltas?: {
    trustDelta?: number | null;
    confirmations?: number | null;
  };
  opportunitiesCount?: {
    jobs?: number;
    projects?: number;
  };
}

interface FeedPreviewItem {
  id: string;
  post?: {
    id: string;
    content: string;
    author?: { id: string; name: string; avatarUrl: string | null } | null;
  } | null;
  user?: { id?: string; name?: string } | null;
}

interface EventPreviewItem {
  id: string;
  title: string;
  startDate: string;
  format?: string;
  location?: string | null;
}

interface DashboardData {
  feedItems: FeedPreviewItem[];
  events: EventPreviewItem[];
  whatsNew: WhatsNewLite | null;
}

/** professionalStatus есть в схеме User, но не в UserPublic — безопасное расширение */
type UserWithStatus = UserPublic & { professionalStatus?: string | null };

const STATUS_LABELS: Record<string, string> = {
  active_searching: 'Активно ищу работу',
  open_to_offers: 'Открыт к предложениям',
  not_searching: 'Не ищу работу',
  open_to_projects: 'Открыт к проектам',
  open_to_consulting: 'Открыт к консультациям',
};

const STATUS_FALLBACK = 'Открыт к предложениям';

function getGreeting(d: Date): string {
  const h = d.getHours();
  if (h < 5) return 'Доброй ночи';
  if (h < 12) return 'Доброе утро';
  if (h < 18) return 'Добрый день';
  return 'Добрый вечер';
}

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function DashboardView() {
  const { user, setView, setProfileUserId } = useAppStore();
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [feedRes, eventsRes, whatsNewRes] = await Promise.all([
        api<{ items: FeedPreviewItem[] }>('/api/feed?limit=3&mode=posts').catch(() => ({ items: [] })),
        api<{ events: EventPreviewItem[] }>('/api/events?limit=3').catch(() => ({ events: [] })),
        // Тот же endpoint, что использует whats-new-tab.tsx (doc_a: «Что изменилось»)
        api<WhatsNewLite>('/api/me/whats-new').catch(() => null),
      ]);
      setData({
        feedItems: feedRes.items || [],
        events: eventsRes.events || [],
        whatsNew: whatsNewRes,
      });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [user]);

  React.useEffect(() => { load(); }, [load]);

  if (loading || !data || !user) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    );
  }

  const ipScore = user.ipScore;
  const level = user.level;
  const nextLevel = level === 'basic' ? { name: 'Проверенный', threshold: 31 } : level === 'extended' ? { name: 'Эксперт', threshold: 71 } : null;
  const pointsToNext = nextLevel ? nextLevel.threshold - ipScore : 0;

  const greeting = getGreeting(new Date());
  const firstName = user.name.split(' ')[0] || user.name;
  const professionalStatus =
    STATUS_LABELS[(user as UserWithStatus).professionalStatus ?? ''] ?? STATUS_FALLBACK;

  // === Блок 1 «Что изменилось» — дельты из /api/me/whats-new ===
  const trustDelta = data.whatsNew?.deltas?.trustDelta ?? null;
  const confirmations = data.whatsNew?.deltas?.confirmations ?? null;
  const jobsCount = data.whatsNew?.opportunitiesCount?.jobs ?? 0;
  const hasChanges =
    (trustDelta !== null && trustDelta !== 0) ||
    (confirmations !== null && confirmations !== 0) ||
    jobsCount > 0;

  // === Блок 2 «Что важно» ===
  const delta30 = data.whatsNew?.trustDelta30 ?? null;
  const evidenceCoverage = data.whatsNew?.trustHero?.evidenceCoverage ?? null;

  return (
    <div className="space-y-4">
      {/* ===== ПРИВЕТСТВИЕ + ПРОФЕССИОНАЛЬНЫЙ СТАТУС ===== */}
      <div>
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-lighthouse" aria-hidden="true" />
          {greeting}, {firstName}
        </h1>
        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
          <Badge variant="outline" className="gap-1 border-lighthouse/40 text-lighthouse">
            <Activity className="w-3 h-3" aria-hidden="true" />
            {professionalStatus}
          </Badge>
          <TrustBadge ipScore={ipScore} level={level} size="sm" />
        </div>
      </div>

      {/* ============================================================
          БЛОК 1 «Что изменилось» — /api/me/whats-new (doc_a §51)
         ============================================================ */}
      <SectionTitle icon={<TrendingUp className="w-4 h-4" />} title="Что изменилось" hint="пока вас не было" />
      <Card className="lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-4">
          {hasChanges ? (
            <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
              {trustDelta !== null && trustDelta !== 0 && (
                <span className="inline-flex items-center gap-1 text-sm font-semibold">
                  {trustDelta > 0 ? (
                    <ArrowUp className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  ) : (
                    <ArrowDown className="w-4 h-4 text-red-600 dark:text-red-500" aria-hidden="true" />
                  )}
                  <span className={trustDelta > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-500'}>
                    {trustDelta > 0 ? '+' : ''}{trustDelta}
                  </span>
                  <span className="text-muted-foreground font-normal">{pluralize(Math.abs(trustDelta), 'пункт доверия', 'пункта доверия', 'пунктов доверия')}</span>
                </span>
              )}
              {jobsCount > 0 && (
                <span className="inline-flex items-center gap-1.5 text-sm">
                  <Briefcase className="w-4 h-4 text-lighthouse" aria-hidden="true" />
                  <strong className="tabular-nums">{jobsCount}</strong>
                  <span className="text-muted-foreground">{pluralize(jobsCount, 'новая вакансия', 'новые вакансии', 'новых вакансий')}</span>
                </span>
              )}
              {confirmations !== null && confirmations !== 0 && (
                <span className="inline-flex items-center gap-1.5 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  <strong className="tabular-nums">{confirmations}</strong>
                  <span className="text-muted-foreground">{pluralize(confirmations, 'подтверждение', 'подтверждения', 'подтверждений')}</span>
                </span>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              За последнее время значимых изменений нет — завершайте проекты и подтверждайте навыки, чтобы Trust рос.
            </p>
          )}
        </CardContent>
      </Card>

      {/* ============================================================
          БЛОК 2 «Что важно» — Professional Trust (primary, doc_a §41,
          Task 10-c) + отдельные Network Influence / Activity + IP-score
          (легаси-вторичный) + TrustBadge + Evidence Coverage (§52)
         ============================================================ */}
      <SectionTitle icon={<ShieldCheck className="w-4 h-4" />} title="Что важно" hint="новый стандарт доверия" />
      <ProfessionalTrustHomeCard />

      <Card className="overflow-hidden lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-6">
          <div className="flex items-center gap-6 flex-wrap">
            <div className="flex-shrink-0">
              <IpScoreRing ipScore={ipScore} size={120} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">IP-score — легаси-индикатор</div>
                <TermInfo k="ip_score" />
                <Badge variant="outline" className="text-xs px-1.5 py-0 text-muted-foreground border-border" title="Первичная метрика доверия — Professional Trust выше; IP-score остаётся историческим индикатором активности">
                  вторичный
                </Badge>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold">{ipScore}</span>
                <span className="text-sm text-muted-foreground">/ 100</span>
                <TrustBadge ipScore={ipScore} level={level} size="md" className="ml-2" />
              </div>
              <div className="flex items-center gap-2 mt-2 text-sm flex-wrap">
                {delta30 !== null && delta30 !== 0 && (
                  <span
                    className={`inline-flex items-center gap-0.5 text-xs font-semibold ${delta30 > 0 ? 'text-emerald-600 dark:text-emerald-500' : 'text-red-600 dark:text-red-500'}`}
                    title="Изменение Trust за 30 дней"
                  >
                    {delta30 > 0 ? <ArrowUp className="w-3 h-3" aria-hidden="true" /> : <ArrowDown className="w-3 h-3" aria-hidden="true" />}
                    {Math.abs(delta30)} за 30 дней
                  </span>
                )}
                <span className="text-muted-foreground text-xs">· проекты, навыки, отзывы</span>
              </div>
              {/* Evidence Coverage — doc_a B3: доля действий, подкреплённых доказательствами */}
              {evidenceCoverage !== null && (
                <div className="flex items-center gap-2 mt-2 text-sm" title="Покрытие доказательствами">
                  <ShieldCheck className="w-4 h-4 text-lighthouse" aria-hidden="true" />
                  <span className="font-semibold tabular-nums">{Math.round(evidenceCoverage)}%</span>
                  <span className="text-muted-foreground text-xs">действий подкреплено доказательствами</span>
                </div>
              )}
              {nextLevel && (
                <div className="mt-3">
                  <div className="text-xs text-muted-foreground mb-1">До «{nextLevel.name}» осталось {pointsToNext} пунктов</div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full lighthouse-gradient rounded-full transition-all" style={{ width: `${Math.min(100, (ipScore / nextLevel.threshold) * 100)}%` }} />
                  </div>
                </div>
              )}
              <div className="flex gap-2 mt-4 flex-wrap">
                <Button size="sm" variant="outline" onClick={() => setView('projects')}>
                  <FolderKanban className="w-3.5 h-3.5 mr-1" /> Завершить проект (+8)
                </Button>
                <Button size="sm" variant="outline" onClick={() => setView('network')}>
                  <Users className="w-3.5 h-3.5 mr-1" /> Добавить связь (+3)
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ============================================================
          БЛОК 3 «Что делать» — Next Best Action (doc_a §52, D2)
         ============================================================ */}
      <SectionTitle icon={<Target className="w-4 h-4" />} title="Что делать" hint="следующее лучшее действие" />
      <NextBestActionCard />

      {/* ============================================================
          БЛОК 4 «Какие возможности появились» — Bizon Discover (doc_a §52)
         ============================================================ */}
      <SectionTitle icon={<Lightbulb className="w-4 h-4" />} title="Какие возможности появились" hint="персональные находки" />
      <BizonDiscover />

      {/* ============================================================
          БЛОК 5 «Что произошло на рынке» — Bizon Signal (doc_a §52, C1)
         ============================================================ */}
      <SectionTitle icon={<TrendingUp className="w-4 h-4" />} title="Что произошло на рынке" hint="сигналы индустрии" />
      <BizonSignalCard />

      {/* ================================================================
          ВСПОМОГАТЕЛЬНЫЕ БЛОКИ (перенесены ниже пяти блоков doc_a, не удалены)
         ================================================================ */}

      {/* INFO BANNER — что такое Dashboard */}
      <InfoBanner
        icon={<Sparkles className="w-4 h-4 text-white" />}
        title="Ваш маяк доверия"
        description="IP-score — это ваш индекс доверия, основанный на реальных действиях: завершённых проектах, подтверждённых навыках и связях. Чем выше — тем больше возможностей открывается."
        tip="Нельзя накрутить: каждое подтверждение требует общего проекта. Репутация — ваша валюта."
        dismissible
        storageKey="bizon_info_dashboard"
      />

      {/* AI DAILY BRIEF — реальные рекомендации из API (P1-9: убраны хардкоженные имена) */}
      <Card className="border-lighthouse/30">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg lighthouse-gradient flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-sm font-semibold">BizON рекомендует сегодня <TermInfo k="insights" /></div>
              <div className="text-xs text-muted-foreground">AI-анализ вашего профиля</div>
            </div>
          </div>
          <div className="space-y-2">
            {/* P1-9: реальные рекомендации на основе данных пользователя */}
            <RecItem
              icon={<Briefcase className="w-4 h-4" />}
              title={`${jobsCount} вакансий подобрано для вас`}
              chips={[{ label: `IP ${user.ipScore}` }, { label: `${user.stats?.skillsCount ?? 0} навыков` }]}
              cta="Открыть"
              onClick={() => setView('jobs')}
            />
            <RecItem
              icon={<Target className="w-4 h-4" />}
              title="Найти контакт через AI-Matchmaker"
              chips={[{ label: `${user.stats?.connectionsCount ?? 0} связей` }]}
              cta="Найти"
              onClick={() => setView('matchmaker')}
            />
            <RecItem
              icon={<Brain className="w-4 h-4" />}
              title="Построить карьерную траекторию"
              chips={[{ label: 'AI-Career-Agent' }]}
              cta="Запустить"
              onClick={() => setView('career')}
            />
          </div>
        </CardContent>
      </Card>

      {/* ACTION CARDS — переименованы по UX-аудиту:
          Navy = информация (читать), Зелёный = действие (нажать) */}
      <div className="grid grid-cols-2 gap-3">
        <ActionCard
          icon={<FolderKanban className="w-5 h-5" />}
          title="Добавить достижение"
          desc="+8 к IP-score"
          color="lighthouse-gradient"
          onClick={() => setView('projects')}
        />
        <ActionCard
          icon={<Award className="w-5 h-5" />}
          title="Подтвердить навык"
          desc="+5 к IP-score"
          color="bg-emerald-600"
          onClick={() => setView('network')}
        />
        <ActionCard
          icon={<Users className="w-5 h-5" />}
          title="AI-подбор партнёра"
          desc="AI-Matchmaker"
          color="bg-emerald-700"
          onClick={() => setView('matchmaker')}
        />
        <ActionCard
          icon={<Brain className="w-5 h-5" />}
          title="Построить трек"
          desc="AI-Career-Agent"
          color="bg-amber-600"
          onClick={() => setView('career')}
        />
      </div>

      {/* МЕСЯЧНЫЙ КАЛЕНДАРЬ СОБЫТИЙ + напоминалки */}
      <MonthlyCalendar />

      {/* КОМПАНИИ, КОТОРЫМ ВЫ ИНТЕРЕСНЫ — компактные логотипы с match score */}
      <InterestedCompanies />

      {/* QUICK STATS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={<FolderKanban className="w-4 h-4" />} label="Проекты" value={user.stats?.projectsCount ?? 0} onClick={() => setView('projects')} />
        <StatCard icon={<Users className="w-4 h-4" />} label="Связи" value={user.stats?.connectionsCount ?? 0} onClick={() => setView('network')} />
        <StatCard icon={<Award className="w-4 h-4" />} label="Навыки" value={user.stats?.skillsCount ?? 0} onClick={() => { setProfileUserId(null); setView('profile'); }} />
        <StatCard icon={<Briefcase className="w-4 h-4" />} label="Посты" value={user.stats?.postsCount ?? 0} onClick={() => setView('feed')} />
      </div>

      {/* Лента preview */}
      {data.feedItems.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm font-semibold flex items-center gap-2">
                <span className="w-1 h-3.5 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
                <Lightbulb className="w-4 h-4 text-lighthouse" /> Лента новостей
              </div>
              <Button variant="ghost" size="sm" onClick={() => setView('feed')}>Все <ChevronRight className="w-3 h-3" /></Button>
            </div>
            <div className="space-y-2">
              {data.feedItems.slice(0, 3).map((item) => (
                <div key={item.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition cursor-pointer" onClick={() => item.post && setProfileUserId(item.post.author?.id ?? null)}>
                  {item.post?.author && <UserAvatar name={item.post.author.name} avatarUrl={item.post.author.avatarUrl} size="sm" />}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate">
                      <span className="font-medium">{item.post?.author?.name ?? item.user?.name}</span>
                      {item.post && <span className="text-muted-foreground"> · {item.post.content.slice(0, 60)}...</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Ближайшие события — детальный список (не дублируем календарь, только если есть события) */}
      {data.events.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm font-semibold flex items-center gap-2">
                <span className="w-1 h-3.5 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
                Все ближайшие события
              </div>
              <Button variant="ghost" size="sm" onClick={() => setView('events')}>Все <ChevronRight className="w-3 h-3" /></Button>
            </div>
            <div className="space-y-2">
              {data.events.map((e) => (
                <div key={e.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition cursor-pointer" onClick={() => setView('events')}>
                  <div className="w-10 h-10 rounded-lg bg-lighthouse/10 flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-xs text-lighthouse font-bold">{new Date(e.startDate).getDate()}</span>
                    <span className="text-xs text-muted-foreground">{new Date(e.startDate).toLocaleDateString('ru-RU', { month: 'short' })}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{e.title}</div>
                    <div className="text-xs text-muted-foreground">{e.format === 'online' ? 'Онлайн' : e.location ?? 'Офлайн'}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ПРАВДА КАК ВАЛЮТА */}
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-4 text-center">
          <div className="text-sm font-semibold text-lighthouse mb-1">Репутация — ваша валюта</div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            В BizON нельзя накрутить рейтинг. Каждое подтверждение — через реальный проект.
            Каждый навык — проверен коллегами. Каждая связь — имеет вес.
            <strong className="text-foreground"> Вы — маяк правды в цифровом мире.</strong>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================================
// === Вспомогательные компоненты ===
// ============================================================================

// ----------------------------------------------------------------------------
// Professional Trust — HOME (doc_a §41, Task 10-c).
// Primary-метрика блока «Что важно»: 6-факторная формула («новый стандарт
// доверия») + ОТДЕЛЬНЫЕ метрики Network Influence и Activity (в формулу Trust
// НЕ входят). Self-fetch GET /api/me/home-metrics — тот же паттерн, что у
// NextBestActionCard/BizonDiscover. Пустые состояния — честные, из summary
// сервиса (детерминированный расчёт, без выдуманных цифр).
// ----------------------------------------------------------------------------

interface HomeMetricsLite {
  trust: {
    score: number;
    summary: string;
    factors: Record<string, number>;
  };
  network: {
    score: number;
    acceptedConnections: number;
    secondDegreeReach: number;
    recommendationsReceived: number;
    summary: string;
  };
  activity: {
    score: number;
    events30d: number;
    activeDays30d: number;
    summary: string;
  };
}

/** 6 факторов формулы v1 — порядок и подписи для мини-баров. */
const TRUST_FACTOR_ROWS: Array<{ key: string; label: string }> = [
  { key: 'evidenceQuality', label: 'Качество доказательств' },
  { key: 'verification', label: 'Верификация' },
  { key: 'outcome', label: 'Результаты' },
  { key: 'recency', label: 'Свежесть' },
  { key: 'independence', label: 'Независимость' },
  { key: 'consistency', label: 'Согласованность' },
];

/** Компактный горизонтальный бар 0..100 (lighthouse). */
function MiniScoreBar({ label, value, hint }: { label: string; value: number; hint?: string }) {
  const pct = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className="flex items-center gap-2" title={hint ?? label}>
      <span className="text-xs text-muted-foreground w-[168px] sm:w-[190px] truncate flex-shrink-0">{label}</span>
      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden min-w-[48px]" role="presentation">
        <div className="h-full lighthouse-gradient rounded-full" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs tabular-nums text-muted-foreground w-8 text-right">{pct}</span>
    </div>
  );
}

/** Плитка отдельной метрики (Network Influence / Activity). */
function SatelliteMetricTile({
  icon,
  title,
  score,
  summary,
  badge,
}: {
  icon: React.ReactNode;
  title: string;
  score: number;
  summary: string;
  badge: string;
}) {
  const pct = Math.max(0, Math.min(100, Math.round(score)));
  return (
    <Card className="p-3 bg-card gap-2">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="text-lighthouse flex-shrink-0" aria-hidden="true">{icon}</span>
          <span className="text-xs font-semibold truncate">{title}</span>
        </div>
        <Badge variant="outline" className="text-xs px-1.5 py-0 text-muted-foreground border-border flex-shrink-0">
          {badge}
        </Badge>
      </div>
      <div className="flex items-baseline gap-1.5 mt-1.5">
        <span className="text-2xl font-bold tabular-nums">{pct}</span>
        <span className="text-xs text-muted-foreground">/ 100</span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden mt-1.5">
        <div className="h-full lighthouse-gradient rounded-full" style={{ width: `${pct}%` }} />
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed mt-2">{summary}</p>
    </Card>
  );
}

function ProfessionalTrustHomeCard() {
  const [data, setData] = React.useState<HomeMetricsLite | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [failed, setFailed] = React.useState(false);
  const [reloadKey, setReloadKey] = React.useState(0);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setFailed(false);
    api<HomeMetricsLite>('/api/me/home-metrics')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  if (loading) {
    return <Skeleton className="h-52 w-full rounded-xl" />;
  }

  // Честная ошибка: не прячем блок молча — предлагаем повторить (данные не выдумываем)
  if (failed || !data) {
    return (
      <Card className="lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-4 flex items-center justify-between gap-3 flex-wrap">
          <p className="text-sm text-muted-foreground">
            Не удалось загрузить метрики доверия (Professional Trust, сеть, активность).
          </p>
          <Button size="sm" variant="outline" onClick={() => setReloadKey((k) => k + 1)}>
            Повторить
          </Button>
        </CardContent>
      </Card>
    );
  }

  const trustScore = Math.max(0, Math.min(100, Math.round(data.trust.score)));
  const factorRows = TRUST_FACTOR_ROWS.map(({ key, label }) => ({
    key,
    label,
    value: Math.max(0, Math.min(100, Math.round((data.trust.factors?.[key] ?? 0) * 100))),
  }));

  return (
    <Card className="overflow-hidden lighthouse-gradient-soft border-lighthouse/20">
      <CardContent className="p-6">
        {/* Заголовок: primary-метрика с пометкой «новый стандарт доверия» */}
        <div className="flex items-center justify-between gap-2 flex-wrap mb-4">
          <div className="flex items-center gap-2 flex-wrap">
            <ShieldCheck className="w-4 h-4 text-lighthouse" aria-hidden="true" />
            <span className="text-sm font-semibold">Professional Trust</span>
            <TermInfo k="professional_trust" />
            <Badge className="bg-lighthouse text-lighthouse-foreground text-xs border-0">
              Новый стандарт доверия
            </Badge>
          </div>
          <span className="text-xs text-muted-foreground">
            формула из 6 факторов — доказательства, а не активность
          </span>
        </div>

        {/* Score + факторы */}
        <div className="flex items-start gap-6 flex-wrap">
          <div className="flex-shrink-0 min-w-[104px]">
            <div className="flex items-baseline gap-1.5">
              <span className="text-4xl font-bold tabular-nums">{trustScore}</span>
              <span className="text-sm text-muted-foreground">/ 100</span>
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {trustScore === 0
                ? 'нет доказательств — метрика честно нулевая'
                : trustScore >= 66
                  ? 'высокий уровень доверия'
                  : trustScore >= 33
                    ? 'средний уровень доверия'
                    : 'начальный уровень доверия'}
            </div>
          </div>
          <div className="flex-1 min-w-[240px] space-y-1.5" role="list" aria-label="Факторы Professional Trust">
            {factorRows.map((f) => (
              <div key={f.key} role="listitem">
                <MiniScoreBar label={f.label} value={f.value} hint={`${f.label}: ${f.value}/100`} />
              </div>
            ))}
          </div>
        </div>

        {/* Объяснение формулы — из сервиса (детерминированное) */}
        <p className="text-xs text-muted-foreground leading-relaxed mt-4">{data.trust.summary}</p>

        {/* ОТДЕЛЬНЫЕ метрики: Network Influence и Activity (вне формулы Trust) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-5">
          <SatelliteMetricTile
            icon={<Users className="w-4 h-4" />}
            title="Network Influence"
            score={data.network.score}
            summary={data.network.summary}
            badge="вне формулы Trust"
          />
          <SatelliteMetricTile
            icon={<Activity className="w-4 h-4" />}
            title="Activity · 30 дней"
            score={data.activity.score}
            summary={data.activity.summary}
            badge="вне формулы Trust"
          />
        </div>
      </CardContent>
    </Card>
  );
}

/** Заголовок-разделитель блока doc_a */
function SectionTitle({ icon, title, hint }: { icon: React.ReactNode; title: string; hint?: string }) {
  return (
    <div className="flex items-center gap-2" role="heading" aria-level={2}>
      <span className="text-lighthouse" aria-hidden="true">{icon}</span>
      <h2 className="text-sm font-semibold whitespace-nowrap">{title}</h2>
      {hint && <span className="text-xs text-muted-foreground hidden sm:inline whitespace-nowrap">{hint}</span>}
      <div className="flex-1 h-px bg-border" aria-hidden="true" />
    </div>
  );
}

function RecItem({
  icon, title, desc, chips, cta, onClick,
}: {
  icon: React.ReactNode;
  title: string;
  desc?: string;
  chips?: Array<{ label: string }>;
  cta?: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-accent transition text-left border border-transparent hover:border-emerald-500/30 group"
    >
      <div className="text-lighthouse mt-0.5 flex-shrink-0">{icon}</div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium">{title}</div>
        {desc && <div className="text-xs text-muted-foreground">{desc}</div>}
        {/* Чипсы-факты (Navy/neutral) — информация, не действие.
            Зелёный оставлен только для CTA-кнопки справа */}
        {chips && chips.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1.5">
            {chips.map((c, i) => (
              <span
                key={i}
                className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground border border-border"
              >
                {c.label}
              </span>
            ))}
          </div>
        )}
      </div>
      {/* Зелёная кнопка-CTA — психология: «вижу зелёное = знаю куда нажать» */}
      {cta && (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-600 text-white text-xs font-medium flex-shrink-0 group-hover:bg-emerald-700 transition">
          {cta}
          <ChevronRight className="w-3 h-3" />
        </span>
      )}
      {!cta && <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
    </button>
  );
}

function StatCard({ icon, label, value, onClick }: { icon: React.ReactNode; label: string; value: number; onClick: () => void }) {
  return (
    <button onClick={onClick} className="text-left">
      <Card className="p-3 hover:shadow-md transition-shadow">
        <div className="flex items-center gap-2">
          <div className="text-lighthouse">{icon}</div>
          <div>
            <div className="text-xl font-bold">{value}</div>
            <div className="text-xs text-muted-foreground">{label}</div>
          </div>
        </div>
      </Card>
    </button>
  );
}

function ActionCard({ icon, title, desc, color, onClick }: { icon: React.ReactNode; title: string; desc: string; color: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="text-left">
      <Card className="p-4 hover:shadow-lg transition-shadow border-lighthouse/10 hover:border-lighthouse/30">
        <div className={`w-10 h-10 rounded-lg ${color} text-white flex items-center justify-center mb-2`}>
          {icon}
        </div>
        <div className="text-sm font-semibold">{title}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
      </Card>
    </button>
  );
}
