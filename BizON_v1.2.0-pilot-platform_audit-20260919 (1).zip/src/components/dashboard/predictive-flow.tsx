// BizON — Predictive Flow (контекстные подсказки после действий)
// ТЗ 4.4 паттерн 3: AI предугадывает следующие действия
// После завершения проекта → «Добавить навык»
// После создания связи → «Порекомендовать коллегу»
// После подтверждения навыка → «Запросить отзыв»
'use client';
import * as React from 'react';
import { useAppStore } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Award, Users, Star, FolderKanban } from 'lucide-react';

// Отслеживает последнее действие пользователя и предлагает следующее
export function PredictiveFlow() {
  const { view, user } = useAppStore();
  const lastViewRef = React.useRef<string>('');
  const shownRef = React.useRef<Set<string>>(new Set());

  React.useEffect(() => {
    if (!user) return;
    const prevView = lastViewRef.current;
    lastViewRef.current = view;

    // Не показываем повторно одно и то же
    if (shownRef.current.has(`${prevView}->${view}`)) return;

    // Переход на Projects после возможного завершения проекта
    if (prevView === 'projects' && view === 'dashboard') {
      shownRef.current.add(`${prevView}->${view}`);
      setTimeout(() => {
        toast({
          title: 'Завершили проект? Подтвердите навык! ↑',
          description: 'Подтверждение навыка у коллеги поднимет ваш IP-score на 5 пунктов',
        });
      }, 1000);
    }

    // Переход на Network после создания связи
    if (prevView === 'network' && view === 'dashboard') {
      shownRef.current.add(`${prevView}->${view}`);
      setTimeout(() => {
        toast({
          title: 'Новая связь! Порекомендуйте коллегу',
          description: 'AI-Matchmaker найдёт тех, кто будет вам полезен',
        });
      }, 1000);
    }

    // Переход на Profile — проверка заполнения
    if (view === 'profile' && prevView !== 'profile') {
      shownRef.current.add(`${prevView}->${view}`);
      const completion = user.profileCompletion ?? 0;
      if (completion < 80) {
        setTimeout(() => {
          toast({
            title: `Профиль заполнен на ${completion}%`,
            description: 'Добавьте фото, био и день рождения — это повысит доверие к вам',
          });
        }, 1500);
      }
    }

    // Первый вход в день — совет
    if (prevView === '' && view === 'dashboard') {
      shownRef.current.add(`${prevView}->${view}`);
      const hour = new Date().getHours();
      if (hour < 12) {
        setTimeout(() => {
          toast({
            title: 'Доброе утро! Проверьте AI-рекомендации',
            description: 'BizON нашёл 3 действия, которые поднимут ваш IP-score',
          });
        }, 2000);
      }
    }
  }, [view, user]);

  return null; // невидимый компонент — только показывает toasts
}
