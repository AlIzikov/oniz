// BizON — Monthly Calendar (календарь событий на месяц)
// Показывает все мероприятия пользователя и напоминалки
// Поддержка: навигация по месяцам, клик на день → список событий дня
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  ChevronLeft, ChevronRight, Calendar as CalendarIcon, MapPin, Video, Users, Plus,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface CalendarEvent {
  id: string;
  title: string;
  startDate: string; // ISO
  endDate: string | null;
  format: 'online' | 'offline' | 'hybrid';
  category: string;
  location: string | null;
  participantsCount: number;
  myStatus: string | null;
}

const WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const MONTHS = [
  'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь',
];

// Цвет для категории события
const CATEGORY_COLORS: Record<string, string> = {
  meetup:    'bg-emerald-500',
  workshop:  'bg-blue-500',
  webinar:   'bg-purple-500',
  conference:'bg-orange-500',
  hackathon: 'bg-red-500',
  other:     'bg-muted-foreground',
};

export function MonthlyCalendar() {
  const { setView } = useAppStore();
  const [events, setEvents] = React.useState<CalendarEvent[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [currentMonth, setCurrentMonth] = React.useState(() => new Date());
  const [selectedDay, setSelectedDay] = React.useState<Date | null>(null);

  // Загрузка событий — все события пользователя (RSVP + организованные)
  const loadEvents = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ events: any[] }>('/api/events?limit=100');
      setEvents(res.events.map((e: any) => ({
        id: e.id,
        title: e.title,
        startDate: e.startDate,
        endDate: e.endDate,
        format: e.format,
        category: e.category,
        location: e.location,
        participantsCount: e.participantsCount ?? 0,
        myStatus: e.myStatus,
      })));
    } catch (e) {
      console.error('[calendar] load error', e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => { loadEvents(); }, [loadEvents]);

  // Группировка событий по дням (ключ = YYYY-MM-DD)
  const eventsByDay = React.useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const e of events) {
      const d = new Date(e.startDate);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(e);
    }
    return map;
  }, [events]);

  // Генерация сетки месяца
  const days = React.useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    // Понедельник = 0, воскресенье = 6 (русская неделя)
    const firstDayOfWeek = (firstDay.getDay() + 6) % 7;

    const result: (Date | null)[] = [];
    // Пустые ячейки до первого дня
    for (let i = 0; i < firstDayOfWeek; i++) result.push(null);
    // Дни месяца
    for (let d = 1; d <= lastDay.getDate(); d++) {
      result.push(new Date(year, month, d));
    }
    // Дополняем до 6 рядов (42 ячейки) — для ровной сетки
    while (result.length < 42) result.push(null);
    return result;
  }, [currentMonth]);

  // События выбранного дня
  const selectedDayEvents = React.useMemo(() => {
    if (!selectedDay) return [];
    const key = `${selectedDay.getFullYear()}-${String(selectedDay.getMonth() + 1).padStart(2, '0')}-${String(selectedDay.getDate()).padStart(2, '0')}`;
    return eventsByDay.get(key) ?? [];
  }, [selectedDay, eventsByDay]);

  // Сегодняшний день
  const today = new Date();
  const isToday = (d: Date) =>
    d.getDate() === today.getDate() &&
    d.getMonth() === today.getMonth() &&
    d.getFullYear() === today.getFullYear();

  // События на ближайшие 7 дней (для списка напоминалок)
  const upcomingEvents = React.useMemo(() => {
    const now = Date.now();
    const weekLater = now + 7 * 24 * 60 * 60 * 1000;
    return events
      .filter(e => {
        const t = new Date(e.startDate).getTime();
        return t >= now && t <= weekLater;
      })
      .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
  }, [events]);

  function prevMonth() {
    setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() - 1, 1));
  }
  function nextMonth() {
    setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() + 1, 1));
  }
  function goToday() {
    setCurrentMonth(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDay(today);
  }

  return (
    <Card className="border-lighthouse/20">
      <CardContent className="p-4">
        {/* Заголовок с навигацией по месяцам */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-lighthouse" />
            <h3 className="font-semibold text-base">
              {MONTHS[currentMonth.getMonth()]} {currentMonth.getFullYear()}
            </h3>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" onClick={prevMonth} title="Предыдущий месяц">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={goToday} className="text-xs" title="К текущему месяцу">
              Сегодня
            </Button>
            <Button variant="ghost" size="sm" onClick={nextMonth} title="Следующий месяц">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {loading ? (
          <Skeleton className="h-64 w-full rounded-lg" />
        ) : (
          <>
            {/* Сетка календаря */}
            <div className="grid grid-cols-7 gap-1 mb-1">
              {WEEKDAYS.map(d => (
                <div key={d} className="text-center text-xs font-semibold text-muted-foreground uppercase py-1">
                  {d}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {days.map((day, i) => {
                if (!day) return <div key={i} className="aspect-square" />;
                const key = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, '0')}-${String(day.getDate()).padStart(2, '0')}`;
                const dayEvents = eventsByDay.get(key) ?? [];
                const isSelected = selectedDay && isSameDay(selectedDay, day);
                const isCurrent = isToday(day);
                const isPast = day.getTime() < today.getTime() && !isCurrent;
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedDay(day)}
                    className={cn(
                      'aspect-square rounded-md flex flex-col items-center justify-start p-1 transition border',
                      isSelected
                        ? 'border-primary bg-primary/10'
                        : 'border-transparent hover:border-lighthouse/30 hover:bg-accent/50',
                      isCurrent && !isSelected && 'border-lighthouse/50 bg-lighthouse/5',
                      isPast && 'opacity-40'
                    )}
                  >
                    <span className={cn(
                      'text-xs font-medium tabular-nums',
                      isCurrent && 'text-lighthouse font-bold'
                    )}>
                      {day.getDate()}
                    </span>
                    {/* Точки событий (до 3-х, остальные +N) */}
                    {dayEvents.length > 0 && (
                      <div className="flex flex-wrap gap-0.5 mt-0.5 justify-center">
                        {dayEvents.slice(0, 3).map((e, idx) => (
                          <span
                            key={e.id + idx}
                            className={cn('w-1.5 h-1.5 rounded-full', CATEGORY_COLORS[e.category] ?? CATEGORY_COLORS.other)}
                            title={e.title}
                          />
                        ))}
                        {dayEvents.length > 3 && (
                          <span className="text-[8px] text-muted-foreground">+{dayEvents.length - 3}</span>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* События выбранного дня */}
            {selectedDay && (
              <div className="mt-4 pt-3 border-t">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  {selectedDay.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'long' })}
                </div>
                {selectedDayEvents.length === 0 ? (
                  <p className="text-xs text-muted-foreground italic">В этот день событий нет</p>
                ) : (
                  <div className="space-y-2">
                    {selectedDayEvents.map(e => <EventRow key={e.id} event={e} />)}
                  </div>
                )}
              </div>
            )}

            {/* Напоминалки — ближайшие события (7 дней) */}
            {!selectedDay && upcomingEvents.length > 0 && (
              <div className="mt-4 pt-3 border-t">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Напоминалки · ближайшие 7 дней</span>
                  <Badge variant="secondary" className="text-xs">{upcomingEvents.length}</Badge>
                </div>
                <div className="space-y-2">
                  {upcomingEvents.slice(0, 4).map(e => <EventRow key={e.id} event={e} compact />)}
                </div>
                {upcomingEvents.length > 4 && (
                  <Button variant="ghost" size="sm" className="w-full mt-2 text-xs" onClick={() => setView('events')}>
                    Ещё {upcomingEvents.length - 4} событий →
                  </Button>
                )}
              </div>
            )}

            {/* Если нет ни выбранных дней, ни напоминалок — показываем подсказку */}
            {!selectedDay && upcomingEvents.length === 0 && !loading && (
              <div className="mt-4 pt-3 border-t text-center">
                <p className="text-xs text-muted-foreground mb-2">
                  На ближайшую неделю событий нет
                </p>
                <Button variant="outline" size="sm" onClick={() => setView('events')} className="text-xs">
                  <Plus className="w-3 h-3 mr-1" /> Создать событие
                </Button>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function EventRow({ event, compact }: { event: CalendarEvent; compact?: boolean }) {
  const date = new Date(event.startDate);
  const formatIcon = event.format === 'online'
    ? <Video className="w-3 h-3" />
    : event.format === 'hybrid'
      ? <Users className="w-3 h-3" />
      : <MapPin className="w-3 h-3" />;
  const formatLabel = event.format === 'online' ? 'Онлайн' : event.format === 'hybrid' ? 'Гибрид' : 'Офлайн';

  return (
    <div className={cn('flex items-start gap-2 rounded-md p-2 hover:bg-accent/50 transition', !compact && 'border')}>
      {/* Дата-индикатор */}
      <div className="flex-shrink-0 w-9 h-9 rounded-md bg-lighthouse/10 flex flex-col items-center justify-center">
        <span className="text-xs font-bold text-lighthouse tabular-nums">{date.getDate()}</span>
        <span className="text-[8px] text-muted-foreground uppercase">
          {date.toLocaleDateString('ru-RU', { month: 'short' })}
        </span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-medium truncate">{event.title}</div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
          <span className="flex items-center gap-0.5">
            {formatIcon} {formatLabel}
          </span>
          <span className="tabular-nums">
            {date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
          </span>
          {event.myStatus === 'going' && (
            <Badge variant="secondary" className="text-xs py-0 px-1 h-3.5">Вы идёте</Badge>
          )}
        </div>
        {!compact && event.location && (
          <div className="text-xs text-muted-foreground mt-0.5 truncate">{event.location}</div>
        )}
      </div>
    </div>
  );
}

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate();
}
