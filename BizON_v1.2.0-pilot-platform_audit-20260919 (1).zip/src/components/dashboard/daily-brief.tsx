// BizON — Daily Brief Popup (показывается 1 раз в день при первом входе)
// ТЗ 4.4: "AI-рекомендации выводятся в нижнем блоке (обновляются раз в сутки)"
// Hook Model: Trigger (утро) → Action (открыть BizON) → Reward (бриф) → Investment (действия)
//
// Task 10-c (doc_a п.1): Professional Trust — primary-метрика брифа («новый
// стандарт доверия», GET /api/me/home-metrics); IP-score остаётся легаси-вторичным.
// При ошибке загрузки — блок Trust не показывается (честно, без выдуманных цифр),
// бриф продолжает работать на легаси-данных юзера.
'use client';
import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Sparkles, TrendingUp, Users, Briefcase, FolderKanban, X, ArrowUp, Award, ShieldCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';

export function DailyBrief() {
  const { user, setView } = useAppStore();
  const [open, setOpen] = React.useState(false);
  const [feedCount, setFeedCount] = React.useState(0);
  const [connCount, setConnCount] = React.useState(0);
  // Task 10-c: Professional Trust для primary-акцента брифа (number | null —
  // null = не загрузилось, блок честно не рендерим)
  const [trustScore, setTrustScore] = React.useState<number | null>(null);

  React.useEffect(() => {
    if (!user) return;
    // Проверяем — показывали ли уже бриф сегодня
    const lastShown = localStorage.getItem('bizon_daily_brief_date');
    const today = new Date().toDateString();
    if (lastShown === today) return;

    // Загружаем данные для брифа
    Promise.all([
      api<{ items: any[] }>('/api/feed?limit=5&mode=posts').catch(() => ({ items: [] })),
      api<{ connections: any[] }>('/api/connections?direction=incoming').catch(() => ({ connections: [] })),
      // Task 10-c: метрики доверия (не критичны для брифа — .catch → null)
      api<{ trust: { score: number } }>('/api/me/home-metrics')
        .then((res) => ({ trust: res.trust }))
        .catch(() => null),
    ]).then(([feed, conns, metrics]) => {
      setFeedCount(feed.items?.length ?? 0);
      setConnCount(conns.connections?.filter((c: any) => c.status === 'pending').length ?? 0);
      if (metrics && typeof metrics.trust?.score === 'number') {
        setTrustScore(Math.max(0, Math.min(100, Math.round(metrics.trust.score))));
      }
      // Показываем бриф
      setTimeout(() => {
        setOpen(true);
        localStorage.setItem('bizon_daily_brief_date', today);
      }, 1500);
    }).catch(() => {});
  }, [user]);

  if (!user) return null;

  const briefs = [
    {
      icon: <TrendingUp className="w-4 h-4 text-lighthouse" />,
      title: `Ваш IP-score: ${user.ipScore}`,
      desc: user.level === 'expert' ? 'Вы эксперт! Доступны все функции BizON.' : `Растёт — уровень «${user.level === 'extended' ? 'Проверенный' : 'Новичок'}». Завершите проект для роста.`,
      action: 'К проектам',
      onClick: () => { setView('projects'); setOpen(false); },
    },
    {
      icon: <Briefcase className="w-4 h-4 text-lighthouse" />,
      title: `${feedCount} новых постов в ленте`,
      desc: 'Коллеги делятся инсайтами и достижениями',
      action: 'Читать',
      onClick: () => { setView('feed'); setOpen(false); },
    },
    {
      icon: <Users className="w-4 h-4 text-lighthouse" />,
      title: connCount > 0 ? `${connCount} запросов на связь` : 'Расширяйте сеть',
      desc: connCount > 0 ? 'Новые люди хотят познакомиться' : 'AI-Matchmaker нашёл подходящие контакты',
      action: connCount > 0 ? 'Посмотреть' : 'Найти',
      onClick: () => { setView(connCount > 0 ? 'network' : 'matchmaker'); setOpen(false); },
    },
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg lighthouse-gradient flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            Доброе утро, {user.name.split(' ')[0]}!
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">Ваш утренний бриф от BizON на {new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}</p>

          {/* Professional Trust — PRIMARY (новый стандарт доверия, doc_a §41;
              не рендерится, если метрика не загрузилась — честно) */}
          {trustScore !== null && (
            <div className="flex items-center gap-3 p-3 rounded-lg lighthouse-gradient-soft border border-lighthouse/20" data-testid="daily-brief-trust">
              <div className="flex items-center gap-1 text-lighthouse">
                <ShieldCheck className="w-4 h-4" />
                <span className="text-2xl font-bold tabular-nums">{trustScore}</span>
              </div>
              <div className="min-w-0">
                <div className="text-sm font-medium">Professional Trust · новый стандарт доверия <TermInfo k="professional_trust" /></div>
                <div className="text-xs text-muted-foreground">
                  {trustScore === 0
                    ? 'Доказательств пока нет — добавьте первое достижение с результатом'
                    : 'Доказательства, верификация и результаты — 6-факторная формула'}
                </div>
              </div>
            </div>
          )}

          {/* IP-Score highlight — легаси-вторичный (после нового стандарта) */}
          <div className="flex items-center gap-3 p-3 rounded-lg lighthouse-gradient-soft border border-lighthouse/20">
            <div className="flex items-center gap-1 text-lighthouse">
              <ArrowUp className="w-4 h-4" />
              <span className="text-2xl font-bold">{user.ipScore}</span>
            </div>
            <div>
              <div className="text-sm font-medium">IP-score · легаси-индикатор <TermInfo k="ip_score" /></div>
              <div className="text-xs text-muted-foreground">Репутация — ваша валюта</div>
            </div>
          </div>

          {/* Brief items */}
          {briefs.map((b, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-lg border hover:border-lighthouse/20 transition">
              <div className="mt-0.5">{b.icon}</div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium">{b.title}</div>
                <div className="text-xs text-muted-foreground">{b.desc}</div>
              </div>
              <Button size="sm" variant="ghost" onClick={b.onClick} className="text-xs">{b.action}</Button>
            </div>
          ))}

          {/* CTA */}
          <div className="flex items-center gap-2 pt-2 border-t">
            <Button size="sm" className="flex-1" onClick={() => setOpen(false)}>
              Начать день
            </Button>
          </div>

          <p className="text-xs text-center text-muted-foreground">
            Бриф показывается 1 раз в день. «Вы — маяк правды в цифровом мире»
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
