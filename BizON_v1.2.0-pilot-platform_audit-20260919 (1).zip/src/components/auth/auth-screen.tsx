// BizON — Auth Screen (регистрация + вход)
// 3 типа: Частное лицо / Юридическое лицо / HR-агентство
// Архитектура: каждый тип — отдельная форма, готовая к разделению на отдельные экраны
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import { Loader2, Shield, Network, Brain, Lightbulb, ChevronDown, Building2, User, Briefcase, Info, Check } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';

type AccountType = 'individual' | 'company' | 'hr_agency';

const ACCOUNT_TYPES: Array<{
  id: AccountType;
  label: string;
  icon: React.ReactNode;
  description: string;
  hint: string;
  features: string[];
}> = [
  {
    id: 'individual',
    label: 'Частное лицо',
    icon: <User className="w-5 h-5" />,
    description: 'Для специалистов, фрилансеров и самозанятых',
    hint: 'Бесплатно навсегда. Подходит для: инженеров, дизайнеров, поваров, строителей, преподавателей и всех профессий.',
    features: ['Профиль с IP-score', 'Публикация постов (до 5 в день)', 'Граф доверия и связи', 'AI-Matchmaker', 'Участие в проектах'],
  },
  {
    id: 'company',
    label: 'Юридическое лицо',
    icon: <Building2 className="w-5 h-5" />,
    description: 'Для компаний и организаций',
    hint: 'Включает: ООО, АО, ИП с сотрудниками, НКО, госкорпорации. Создавайте Company Page, публикуйте вакансии, нанимайте через AI-рекрутинг.',
    features: ['Company Page с отзывами', 'Вакансии с AI-подбором', 'Commercial-посты с CTA', 'Аналитика рынка', 'API-доступ'],
  },
  {
    id: 'hr_agency',
    label: 'HR-агентство',
    icon: <Briefcase className="w-5 h-5" />,
    description: 'Для кадровых и рекрутинговых агентств',
    hint: 'Включает: кадровые агентства, рекрутинговые платформы, фриланс-биржи. Управляйте вакансиями клиентов, подбирайте кандидатов через AI.',
    features: ['Управление вакансиями клиентов', 'AI-подбор кандидатов', 'Мульти-аккаунт для команды', 'Аналитика воронки найма', 'Branded профиль агентства'],
  },
];

export function AuthScreen() {
  const setUser = useAppStore((s) => s.setUser);
  const setView = useAppStore((s) => s.setView);
  const [mode, setMode] = React.useState<'login' | 'register'>('login');
  const [loading, setLoading] = React.useState(false);
  // FIX-08: согласие с условиями люмен-программы (/legal) — обязательно
  // до отправки формы регистрации (API отклоняет запрос без acceptedTos:true).
  const [tosAccepted, setTosAccepted] = React.useState(false);

  // --- FIX-03: шаг 2FA при входе ---
  // Если /api/auth/login вернул { twoFactorRequired: true, tempToken } — сессия
  // НЕ создана: показываем поле ввода TOTP/backup-кода и подтверждаем через
  // POST /api/auth/2fa/verify (там выдаётся настоящий session cookie).
  const [twoFactorTempToken, setTwoFactorTempToken] = React.useState<string | null>(null);
  const [twoFactorCode, setTwoFactorCode] = React.useState('');

  // --- Login --- (FIX-01: предзаполнение demo-креденшелов удалено,
  // форма входа всегда начинается с пустых полей)
  const [loginEmail, setLoginEmail] = React.useState('');
  const [loginPassword, setLoginPassword] = React.useState('');

  // --- Register shared ---
  const [accountType, setAccountType] = React.useState<AccountType>('individual');
  const [typeDropdownOpen, setTypeDropdownOpen] = React.useState(false);

  // --- Register individual ---
  const [indName, setIndName] = React.useState('');
  const [indEmail, setIndEmail] = React.useState('');
  const [indTitle, setIndTitle] = React.useState('');
  const [indPassword, setIndPassword] = React.useState('');

  // --- Register company ---
  const [compName, setCompName] = React.useState(''); // название компании
  const [compContactName, setCompContactName] = React.useState(''); // имя контактного лица
  const [compEmail, setCompEmail] = React.useState('');
  const [compLegalForm, setCompLegalForm] = React.useState(''); // ООО, АО, ИП...
  const [compWebsite, setCompWebsite] = React.useState('');
  const [compPassword, setCompPassword] = React.useState('');

  // --- Register HR agency ---
  const [hrName, setHrName] = React.useState(''); // название агентства
  const [hrContactName, setHrContactName] = React.useState('');
  const [hrEmail, setHrEmail] = React.useState('');
  const [hrSpecialization, setHrSpecialization] = React.useState('');
  const [hrPassword, setHrPassword] = React.useState('');

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      // C5: token не возвращается, только HttpOnly cookie
      const res = await api<{ user?: any; twoFactorRequired?: boolean; tempToken?: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });
      // FIX-03: у пользователя включена 2FA → показываем шаг ввода кода.
      // Сессии ещё нет — она будет создана только после /api/auth/2fa/verify.
      if (res?.twoFactorRequired && res?.tempToken) {
        setTwoFactorTempToken(res.tempToken);
        setTwoFactorCode('');
        toast({ title: 'Двухфакторная аутентификация', description: 'Введите код из приложения-аутентификатора' });
        return;
      }
      if (!res?.user) throw new Error('Некорректный ответ сервера');
      setUser(res.user);
      toast({ title: `Добро пожаловать, ${res.user.name}!` });
    } catch (e: any) {
      toast({ title: 'Ошибка входа', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  // FIX-03: подтверждение 2FA-кода → полноценная сессия
  async function handle2FAVerify(e: React.FormEvent) {
    e.preventDefault();
    if (!twoFactorTempToken) return;
    setLoading(true);
    try {
      const res = await api<{ user: any }>('/api/auth/2fa/verify', {
        method: 'POST',
        body: JSON.stringify({ tempToken: twoFactorTempToken, code: twoFactorCode }),
      });
      setUser(res.user);
      setTwoFactorTempToken(null);
      setTwoFactorCode('');
      toast({ title: `Добро пожаловать, ${res.user.name}!` });
    } catch (e: any) {
      toast({ title: 'Ошибка подтверждения', description: e.message, variant: 'destructive' });
      // tempToken одноразовый: если он истёк/испорчен — возвращаем к шагу «Вход»
      if (e?.status === 401 && String(e?.message || '').includes('истекла')) {
        setTwoFactorTempToken(null);
        setTwoFactorCode('');
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      // FIX-08: юридический контур — без согласия регистрация не отправляется
      if (!tosAccepted) throw new Error('Необходимо принять условия люмен-программы');

      let body: any = {};

      if (accountType === 'individual') {
        if (!indName || !indEmail || !indPassword) throw new Error('Заполните все поля');
        body = { name: indName, email: indEmail, title: indTitle, password: indPassword, accountType: 'individual' };
      } else if (accountType === 'company') {
        if (!compName || !compContactName || !compEmail || !compPassword) throw new Error('Заполните все поля');
        body = { name: compName, email: compEmail, title: compContactName, password: compPassword, accountType: 'company', legalForm: compLegalForm, website: compWebsite };
      } else {
        if (!hrName || !hrContactName || !hrEmail || !hrPassword) throw new Error('Заполните все поля');
        body = { name: hrName, email: hrEmail, title: hrContactName, password: hrPassword, accountType: 'hr_agency', specialization: hrSpecialization };
      }
      body.acceptedTos = true;

      const res = await api<{ user: any }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(body),
      });
      setUser(res.user);
      toast({ title: `Добро пожаловать в BizON, ${res.user.name}!` });
    } catch (e: any) {
      toast({ title: 'Ошибка регистрации', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  const selectedType = ACCOUNT_TYPES.find(t => t.id === accountType)!;

  return (
    <div className="min-h-screen flex items-stretch bg-background">
      {/* === LEFT: Brand panel === */}
      <div className="hidden lg:flex flex-1 flex-col justify-between p-12 lighthouse-gradient text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-25" style={{
          backgroundImage: 'radial-gradient(circle at 15% 20%, white 1.5px, transparent 1.5px), radial-gradient(circle at 85% 60%, white 1px, transparent 1px), radial-gradient(circle at 50% 80%, white 2px, transparent 2px)',
          backgroundSize: '50px 50px, 70px 70px, 90px 90px'
        }} />
        <div className="absolute top-0 right-0 w-1/3 h-full" style={{
          background: 'linear-gradient(115deg, transparent 30%, oklch(0.65 0.13 195 / 0.25) 50%, transparent 70%)',
          pointerEvents: 'none'
        }} />

        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl overflow-hidden bg-white/15 backdrop-blur flex items-center justify-center border border-white/20">
              <img src="/lighthouse-logo.jpg" alt="BizON" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">BizON</h1>
              <p className="text-sm text-white/80">Маяк в цифровом мире</p>
            </div>
          </div>
        </div>

        <div className="relative space-y-8">
          <div>
            <h2 className="text-4xl font-bold leading-tight mb-4">
              Не сеть контактов.<br />
              <span className="text-white/90">Сеть правды.</span>
            </h2>
            <p className="text-lg text-white/80 max-w-md leading-relaxed">
              В холодном цифровом море BizON — это маяк. Мы направляем, освещаем правду и согреваем теплом реального доверия.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 max-w-md">
            <FeatureRow icon={<Lightbulb className="w-5 h-5" />} title="Свет правды" desc="IP-score, подтверждённый действиями — а не лайками" />
            <FeatureRow icon={<Network className="w-5 h-5" />} title="Направление" desc="AI-агенты ведут через граф доверия" />
            <FeatureRow icon={<Shield className="w-5 h-5" />} title="Тепло" desc="Награды за реальные свершения, не за скролл" />
          </div>
        </div>

        <div className="relative text-sm text-white/60">
          v10.0 · Фаза 1+2 · «Правда — это маяк, что светит сквозь туман шума»
        </div>
      </div>

      {/* === RIGHT: Auth forms === */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl overflow-hidden lighthouse-gradient flex items-center justify-center">
              <img src="/lighthouse-logo.jpg" alt="BizON" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">BizON</h1>
              <p className="text-xs text-muted-foreground">Маяк в цифровом мире</p>
            </div>
          </div>

          <Tabs value={mode} onValueChange={(v) => setMode(v as any)} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Вход</TabsTrigger>
              <TabsTrigger value="register">Регистрация</TabsTrigger>
            </TabsList>

            {/* ========== LOGIN ========== */}
            <TabsContent value="login">
              {twoFactorTempToken ? (
                /* === FIX-03: шаг 2FA — ввод TOTP/backup-кода === */
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-lighthouse" />
                      Подтверждение входа
                    </CardTitle>
                    <CardDescription>Введите код двухфакторной аутентификации</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handle2FAVerify} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="2fa-code">Код (6 цифр из приложения или backup-код)</Label>
                        <Input
                          id="2fa-code"
                          inputMode="numeric"
                          autoComplete="one-time-code"
                          placeholder="000000"
                          value={twoFactorCode}
                          onChange={(e) => setTwoFactorCode(e.target.value)}
                          required
                        />
                      </div>
                      <Button type="submit" disabled={loading} className="w-full">
                        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Подтвердить'}
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full"
                        disabled={loading}
                        onClick={() => { setTwoFactorTempToken(null); setTwoFactorCode(''); }}
                      >
                        Назад ко входу
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              ) : (
              <Card>
                <CardHeader>
                  <CardTitle>С возвращением</CardTitle>
                  <CardDescription>Войдите в свою сеть доверия</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Пароль</Label>
                      <Input id="password" type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} required />
                    </div>
                    <Button type="submit" disabled={loading} className="w-full">
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Войти'}
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      Демо: ivan@bizon.ru · пароль: password
                    </p>
                  </form>
                </CardContent>
              </Card>
              )}
            </TabsContent>

            {/* ========== REGISTER ========== */}
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Создать аккаунт</CardTitle>
                  <CardDescription>Бесплатно для всех типов аккаунтов</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleRegister} className="space-y-4">

                    {/* === TYPE SELECTOR (dropdown) === */}
                    <div className="space-y-2">
                      <Label>Тип аккаунта</Label>
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => setTypeDropdownOpen(v => !v)}
                          className="w-full flex items-center gap-3 p-3 border rounded-lg hover:border-primary transition text-left"
                        >
                          <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0', selectedType.id === 'individual' ? 'bg-primary text-primary-foreground' : selectedType.id === 'company' ? 'bg-success text-success-foreground' : 'bg-warning text-warning-foreground')}>
                            {selectedType.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm">{selectedType.label}</div>
                            <div className="text-xs text-muted-foreground truncate">{selectedType.description}</div>
                          </div>
                          <ChevronDown className={cn('w-4 h-4 text-muted-foreground transition', typeDropdownOpen && 'rotate-180')} />
                        </button>

                        {typeDropdownOpen && (
                          <>
                            <div className="fixed inset-0 z-10" onClick={() => setTypeDropdownOpen(false)} />
                            <div className="absolute top-full left-0 right-0 mt-1 bg-card border rounded-lg shadow-xl z-20 soft-fade-in overflow-hidden">
                              {ACCOUNT_TYPES.map(t => (
                                <button
                                  key={t.id}
                                  type="button"
                                  onClick={() => { setAccountType(t.id); setTypeDropdownOpen(false); }}
                                  className={cn(
                                    'w-full flex items-start gap-3 p-3 hover:bg-accent transition text-left border-b last:border-0',
                                    accountType === t.id && 'bg-accent'
                                  )}
                                >
                                  <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0', t.id === 'individual' ? 'bg-primary text-primary-foreground' : t.id === 'company' ? 'bg-success text-success-foreground' : 'bg-warning text-warning-foreground')}>
                                    {t.icon}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2">
                                      <span className="font-medium text-sm">{t.label}</span>
                                      {accountType === t.id && <Check className="w-3.5 h-3.5 text-lighthouse" />}
                                    </div>
                                    <div className="text-xs text-muted-foreground">{t.description}</div>
                                  </div>
                                </button>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    {/* === HINT for selected type === */}
                    <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border border-muted">
                      <Info className="w-4 h-4 text-lighthouse flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs text-foreground/80 leading-relaxed">{selectedType.hint}</p>
                      </div>
                    </div>

                    {/* === INDIVIDUAL FORM === */}
                    {accountType === 'individual' && (
                      <div className="space-y-3 soft-fade-in">
                        <div className="space-y-1">
                          <Label htmlFor="ind-name">Имя и фамилия</Label>
                          <Input id="ind-name" value={indName} onChange={e => setIndName(e.target.value)} placeholder="Иван Петров" required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="ind-email">Email</Label>
                          <Input id="ind-email" type="email" value={indEmail} onChange={e => setIndEmail(e.target.value)} placeholder="ivan@example.ru" required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="ind-title">Профессия <span className="text-muted-foreground">(необязательно)</span></Label>
                          <Input id="ind-title" value={indTitle} onChange={e => setIndTitle(e.target.value)} placeholder="Data Engineer, Шеф-повар, Архитектор..." />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="ind-pass">Пароль</Label>
                          <Input id="ind-pass" type="password" value={indPassword} onChange={e => setIndPassword(e.target.value)} placeholder="Мин. 8 символов, заглавная + цифра" required />
                        </div>
                      </div>
                    )}

                    {/* === COMPANY FORM === */}
                    {accountType === 'company' && (
                      <div className="space-y-3 soft-fade-in">
                        <div className="space-y-1">
                          <Label htmlFor="comp-name">Название компании</Label>
                          <Input id="comp-name" value={compName} onChange={e => setCompName(e.target.value)} placeholder='ООО "ГринАИ"' required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="comp-form">Правовая форма</Label>
                          <select
                            id="comp-form"
                            value={compLegalForm}
                            onChange={e => setCompLegalForm(e.target.value)}
                            className="w-full p-2 border rounded-md bg-background text-sm"
                          >
                            <option value="">Выберите...</option>
                            <option value="ООО">ООО</option>
                            <option value="АО">АО (акционерное общество)</option>
                            <option value="ИП">ИП (с сотрудниками)</option>
                            <option value="самозанятое">Самозанятое (с командой)</option>
                            <option value="НКО">НКО</option>
                            <option value="госкорпорация">Госкорпорация</option>
                            <option value="другое">Другое</option>
                          </select>
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="comp-contact">Контактное лицо</Label>
                          <Input id="comp-contact" value={compContactName} onChange={e => setCompContactName(e.target.value)} placeholder="Иван Петров, HR-директор" required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="comp-email">Email компании</Label>
                          <Input id="comp-email" type="email" value={compEmail} onChange={e => setCompEmail(e.target.value)} placeholder="hr@greenai.ru" required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="comp-site">Сайт <span className="text-muted-foreground">(необязательно)</span></Label>
                          <Input id="comp-site" value={compWebsite} onChange={e => setCompWebsite(e.target.value)} placeholder="https://greenai.ru" />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="comp-pass">Пароль</Label>
                          <Input id="comp-pass" type="password" value={compPassword} onChange={e => setCompPassword(e.target.value)} placeholder="Мин. 8 символов, заглавная + цифра" required />
                        </div>
                      </div>
                    )}

                    {/* === HR AGENCY FORM === */}
                    {accountType === 'hr_agency' && (
                      <div className="space-y-3 soft-fade-in">
                        <div className="space-y-1">
                          <Label htmlFor="hr-name">Название агентства</Label>
                          <Input id="hr-name" value={hrName} onChange={e => setHrName(e.target.value)} placeholder='Кадровое агентство "Перспектива"' required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="hr-contact">Контактное лицо</Label>
                          <Input id="hr-contact" value={hrContactName} onChange={e => setHrContactName(e.target.value)} placeholder="Мария Иванова, рекрутер" required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="hr-email">Email агентства</Label>
                          <Input id="hr-email" type="email" value={hrEmail} onChange={e => setHrEmail(e.target.value)} placeholder="info@perspectiva-hr.ru" required />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="hr-spec">Специализация</Label>
                          <Input id="hr-spec" value={hrSpecialization} onChange={e => setHrSpecialization(e.target.value)} placeholder="IT, финансы, производство..." />
                        </div>
                        <div className="space-y-1">
                          <Label htmlFor="hr-pass">Пароль</Label>
                          <Input id="hr-pass" type="password" value={hrPassword} onChange={e => setHrPassword(e.target.value)} placeholder="Мин. 8 символов, заглавная + цифра" required />
                        </div>
                      </div>
                    )}

                    {/* === FEATURES for selected type === */}
                    <div className="pt-2 border-t">
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                        Что входит:
                      </div>
                      <div className="space-y-1">
                        {selectedType.features.map(f => (
                          <div key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Check className="w-3 h-3 text-lighthouse flex-shrink-0" />
                            {f}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* FIX-08: согласие с условиями люмен-программы — required */}
                    <div className="flex items-start gap-2">
                      <Checkbox
                        id="register-tos"
                        checked={tosAccepted}
                        onCheckedChange={(v) => setTosAccepted(v === true)}
                        className="mt-0.5"
                      />
                      <label htmlFor="register-tos" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                        Принимаю{' '}
                        <a
                          href="/legal"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="underline underline-offset-2 hover:text-foreground"
                        >
                          условия люмен-программы
                        </a>{' '}
                        (пополнение по курсу 1 ₽ = 1 люмен, бонусы, возвраты)
                      </label>
                    </div>

                    <Button type="submit" disabled={loading} className="w-full">
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Зарегистрироваться'}
                    </Button>

                    <p className="text-xs text-muted-foreground text-center">
                      Регистрируясь, вы принимаете условия и политику конфиденциальности. PII шифруется (AES-256).
                    </p>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

function FeatureRow({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-10 h-10 rounded-lg bg-white/15 flex items-center justify-center flex-shrink-0">
        {icon}
      </div>
      <div>
        <div className="font-semibold">{title}</div>
        <div className="text-sm text-white/70">{desc}</div>
      </div>
    </div>
  );
}
