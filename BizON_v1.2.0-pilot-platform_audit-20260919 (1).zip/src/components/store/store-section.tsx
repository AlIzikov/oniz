// BizON — Store: секция «Как со мной работать» в профиле продавца (Wave 2, S-039).
// Витрина владельца + покупка/бронирование через эскроу на люменах (ADR-002).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ShoppingBag, Crown, Clock, Package, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export type StoreItemDto = {
  id: string;
  ownerId: string;
  ownerName: string | null;
  ownerTitle: string | null;
  ownerAvatar: string | null;
  ownerLevel: string | null;
  type: string;
  title: string;
  description: string;
  priceLumens: number;
  currency: string;
  deliveryMode: string;
  evidenceRefs: string[];
  verificationStatus: string;
  isPremium: boolean;
  status: string;
  slotsTotal: number;
  slotsLeft: number | null;
  createdAt: string;
};

export const STORE_TYPE_LABELS: Record<string, string> = {
  services: 'Услуга',
  digital: 'Цифровой товар',
  'expert-access': 'Доступ к эксперту',
};

const DELIVERY_LABELS: Record<string, string> = {
  'online-meeting': 'Онлайн-встреча',
  async: 'Асинхронно',
  'file-delivery': 'Передача файла',
};

/** Диалог покупки: сообщение продавцу + слот времени для expert-access. */
export function BookItemDialog({
  item,
  onBooked,
  trigger,
}: {
  item: StoreItemDto;
  onBooked?: () => void;
  trigger?: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(false);
  const [notes, setNotes] = React.useState('');
  const [slotAt, setSlotAt] = React.useState('');
  const [busy, setBusy] = React.useState(false);

  async function handleBook() {
    setBusy(true);
    try {
      await api(`/api/store/items/${item.id}/book`, {
        method: 'POST',
        body: JSON.stringify({
          ...(slotAt ? { slotAt: new Date(slotAt).toISOString() } : {}),
          ...(notes.trim() ? { notes: notes.trim() } : {}),
        }),
      });
      toast({
        title: 'Заказ оформлен',
        description: `${item.priceLumens} люменов заморожено в эскроу. Продавец получил заказ.`,
      });
      setOpen(false);
      setNotes('');
      setSlotAt('');
      onBooked?.();
    } catch (e) {
      toast({ title: 'Не удалось оформить заказ', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  const soldOut = item.slotsLeft !== null && item.slotsLeft <= 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm" disabled={soldOut} aria-label={`Заказать ${item.title}`}>
            {soldOut ? 'Слотов нет' : 'Заказать'}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{item.title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <Badge variant="outline">{STORE_TYPE_LABELS[item.type] ?? item.type}</Badge>
            <Badge variant="outline">{DELIVERY_LABELS[item.deliveryMode] ?? item.deliveryMode}</Badge>
            {item.verificationStatus === 'evidence-backed' && (
              <Badge variant="outline" className="border-success text-success">С подтверждениями</Badge>
            )}
            <span className="flex items-center gap-1 font-semibold text-foreground">
              <Package className="w-4 h-4" /> {item.priceLumens} люменов
            </span>
          </div>
          {item.description && <p className="text-sm whitespace-pre-wrap max-h-40 overflow-y-auto">{item.description}</p>}
          {item.type === 'expert-access' && (
            <div className="space-y-1.5">
              <Label htmlFor="store-slot">Время сессии (необязательно)</Label>
              <Input id="store-slot" type="datetime-local" value={slotAt} onChange={(e) => setSlotAt(e.target.value)} />
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="store-notes">Сообщение продавцу (необязательно)</Label>
            <Textarea
              id="store-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Опишите задачу или вопрос"
              rows={3}
            />
          </div>
          <p className="text-xs text-muted-foreground">
            Оплата люменами уходит в эскроу: продавец получит их только после вашего подтверждения. До исполнения возможен возврат.
          </p>
        </div>
        <DialogFooter>
          <Button onClick={handleBook} disabled={busy} className="w-full sm:w-auto">
            {busy ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Package className="w-4 h-4 mr-1" />}
            Оплатить {item.priceLumens} люменов
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Карточка товара (общая для витрины и профиля). */
export function StoreItemCard({
  item,
  onBooked,
  compact,
}: {
  item: StoreItemDto;
  onBooked?: () => void;
  compact?: boolean;
}) {
  return (
    <div className={cn('rounded-lg border p-4 space-y-2', item.isPremium && 'border-primary/40 bg-primary/5')}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-medium text-sm truncate">{item.title}</span>
            {item.isPremium && (
              <Badge className="bg-primary text-primary-foreground text-[10px] px-1.5 py-0">
                <Crown className="w-3 h-3 mr-0.5" /> Premium
              </Badge>
            )}
          </div>
          {!compact && item.description && (
            <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{item.description}</p>
          )}
        </div>
        <span className="shrink-0 text-sm font-semibold tabular-nums">{item.priceLumens} <span className="text-xs font-normal text-muted-foreground">люм.</span></span>
      </div>
      <div className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
        <Badge variant="outline" className="text-[10px]">{STORE_TYPE_LABELS[item.type] ?? item.type}</Badge>
        <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" /> {DELIVERY_LABELS[item.deliveryMode] ?? item.deliveryMode}</span>
        {item.slotsLeft !== null && <span>· свободно {item.slotsLeft} из {item.slotsTotal}</span>}
        {item.ownerName && <span>· {item.ownerName}</span>}
      </div>
      <div className="flex justify-end">
        <BookItemDialog item={item} onBooked={onBooked} />
      </div>
    </div>
  );
}

/** Секция «Как со мной работать» — витрина продавца внутри профиля (S-039). */
export function StoreSection({ userId, isOwn }: { userId: string; isOwn: boolean }) {
  const { setView } = useAppStore();
  const [items, setItems] = React.useState<StoreItemDto[] | null>(null);

  const load = React.useCallback(async () => {
    try {
      const res = await api<{ items: StoreItemDto[] }>(`/api/store/items?ownerId=${userId}`);
      setItems(res.items);
    } catch {
      setItems([]);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (items === null) return null;
  if (items.length === 0) {
    if (!isOwn) return null;
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ShoppingBag className="w-4 h-4 text-primary" /> Как со мной работать
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Опубликуйте услуги или экспертные сессии в Store — покупатели будут заказывать прямо из профиля.
          </p>
          <Button size="sm" variant="outline" onClick={() => setView('store')}>
            <ShoppingBag className="w-4 h-4 mr-1" /> Открыть Store
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <ShoppingBag className="w-4 h-4 text-primary" /> Как со мной работать
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-3 sm:grid-cols-2 max-h-96 overflow-y-auto pr-1">
          {items.map((item) => (
            <StoreItemCard key={item.id} item={item} onBooked={load} />
          ))}
        </div>
        {isOwn && (
          <div className="mt-3">
            <Button size="sm" variant="outline" onClick={() => setView('store')}>
              <ShoppingBag className="w-4 h-4 mr-1" /> Управлять витриной в Store
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
