// BizON — StoreView (Wave 2, S-038/S-040): витрина, моя витрина, заказы.
// Эскроу на люменах: покупатель платит вперёд, продавец получает после подтверждения.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { StoreItemCard, STORE_TYPE_LABELS, type StoreItemDto } from '@/components/store/store-section';
import {
  ShoppingBag, Crown, Package, Loader2, Plus, Search, Wallet,
  CheckCircle2, XCircle, Archive, Pause, Play, Coins, Landmark,
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

type WalletInfo = { balance: number } | null;

type CashierStatus = {
  module: string;
  mode: 'virtual' | 'real';
  currency: string;
  commissionPercent: number;
  realMoneyGate: { conditionsMet: boolean };
  ports: { total: number; active: number; ready: number };
};

type BookingDto = {
  id: string;
  role: 'sale' | 'purchase';
  status: 'held' | 'fulfilled' | 'released' | 'declined' | 'refunded' | 'cancelled';
  priceLumens: number;
  itemTitle: string;
  itemType: string;
  counterpart: string;
  slotAt: string | null;
  notes: string | null;
  createdAt: string;
};

const STATUS_LABELS: Record<BookingDto['status'], string> = {
  held: 'В эскроу',
  fulfilled: 'Исполнено',
  released: 'Завершено',
  declined: 'Отклонено',
  refunded: 'Возвращено',
  cancelled: 'Отменено',
};

export function StoreView() {
  return (
    <div className="space-y-4">
      <StoreHeader />
      <Tabs defaultValue="market" className="space-y-4">
        <TabsList className="w-full sm:w-auto flex-wrap h-auto">
          <TabsTrigger value="market" className="gap-1.5"><Search className="w-4 h-4" /> Витрина</TabsTrigger>
          <TabsTrigger value="mine" className="gap-1.5"><Package className="w-4 h-4" /> Мои товары</TabsTrigger>
          <TabsTrigger value="orders" className="gap-1.5"><ShoppingBag className="w-4 h-4" /> Заказы</TabsTrigger>
        </TabsList>
        <TabsContent value="market"><MarketTab /></TabsContent>
        <TabsContent value="mine"><MyItemsTab /></TabsContent>
        <TabsContent value="orders"><OrdersTab /></TabsContent>
      </Tabs>
    </div>
  );
}

function StoreHeader() {
  const [wallet, setWallet] = React.useState<WalletInfo>(null);
  const [cashier, setCashier] = React.useState<CashierStatus | null>(null);

  React.useEffect(() => {
    api<Record<string, unknown>>('/api/lumens')
      .then((w) => setWallet({ balance: Number(w.balance ?? 0) }))
      .catch(() => setWallet(null));
    api<CashierStatus>('/api/cashier/status')
      .then(setCashier)
      .catch(() => setCashier(null));
  }, []);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between gap-2 text-lg">
          <span className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-primary" /> Store
          </span>
          <span className="flex items-center gap-1.5 text-sm font-normal text-muted-foreground">
            <Wallet className="w-4 h-4" />
            {wallet ? (
              <span className="font-semibold text-foreground tabular-nums">{wallet.balance} люменов</span>
            ) : (
              '…'
            )}
          </span>
        </CardTitle>
        {cashier && (
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <Badge variant="outline" className="gap-1 text-xs font-normal">
              <Landmark className="w-3 h-3" /> Виртуальная касса · {cashier.currency}
            </Badge>
            <Badge variant="secondary" className="text-xs font-normal">
              комиссия платформы: {cashier.commissionPercent}%
            </Badge>
            {!cashier.realMoneyGate.conditionsMet && (
              <Badge variant="outline" className="text-xs font-normal text-muted-foreground">
                реальные деньги: выключены (KYC-гейт)
              </Badge>
            )}
            <Badge variant="outline" className="text-xs font-normal text-muted-foreground">
              порты кассы: {cashier.ports.ready} из {cashier.ports.total} готовы
            </Badge>
          </div>
        )}
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        Экспертные услуги и цифровые товары с защитой эскроу: оплата замораживается и уходит продавцу только после вашего подтверждения.
      </CardContent>
    </Card>
  );
}

// ============================== Витрина ==============================

function MarketTab() {
  const [items, setItems] = React.useState<StoreItemDto[] | null>(null);
  const [q, setQ] = React.useState('');
  const [type, setType] = React.useState<string | null>(null);
  const [premiumOnly, setPremiumOnly] = React.useState(false);

  const load = React.useCallback(async () => {
    setItems(null);
    try {
      const sp = new URLSearchParams();
      if (q.trim()) sp.set('q', q.trim());
      if (type) sp.set('type', type);
      if (premiumOnly) sp.set('premiumOnly', '1');
      const res = await api<{ items: StoreItemDto[] }>(`/api/store/items?${sp.toString()}`);
      setItems(res.items);
    } catch {
      setItems([]);
    }
  }, [q, type, premiumOnly]);

  React.useEffect(() => {
    const t = setTimeout(load, 250); // debounce поиска
    return () => clearTimeout(t);
  }, [load]);

  return (
    <div className="space-y-3">
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск услуг и товаров…"
            className="pl-8"
            aria-label="Поиск по витрине"
          />
        </div>
        <Button
          size="sm"
          variant={premiumOnly ? 'default' : 'outline'}
          onClick={() => setPremiumOnly((v) => !v)}
          className="gap-1.5"
        >
          <Crown className="w-4 h-4" /> Premium
        </Button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        <TypeChip active={type === null} onClick={() => setType(null)}>Все</TypeChip>
        {Object.entries(STORE_TYPE_LABELS).map(([key, label]) => (
          <TypeChip key={key} active={type === key} onClick={() => setType(key)}>{label}</TypeChip>
        ))}
      </div>

      {items === null ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
        </div>
      ) : items.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            Ничего не найдено. Витрина наполняется — опубликуйте свою услугу во вкладке «Мои товары».
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {items.map((item) => (
            <StoreItemCard key={item.id} item={item} onBooked={load} />
          ))}
        </div>
      )}
    </div>
  );
}

function TypeChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'rounded-full border px-3 py-1 text-xs transition min-h-[28px]',
        active ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-accent',
      )}
    >
      {children}
    </button>
  );
}

// ============================== Мои товары ==============================

function MyItemsTab() {
  const [items, setItems] = React.useState<StoreItemDto[] | null>(null);
  const [createOpen, setCreateOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    try {
      // mine=1: собственная витрина со всеми статусами (роут разветвляет по сессии)
      const res = await api<{ items: StoreItemDto[] }>('/api/store/items?mine=1');
      setItems(res.items);
    } catch {
      setItems([]);
    }
  }, []);

  React.useEffect(() => {
    // Отдельный эндпоинт моих товаров: /api/store/items?mine=1 требует auth —
    // StoreService.myItems возвращает и неактивные; публичный GET активные по ownerId.
    load();
  }, [load]);

  async function setStatus(id: string, status: 'active' | 'paused' | 'archived') {
    try {
      await api(`/api/store/items/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
      toast({ title: status === 'active' ? 'Товар активен' : status === 'paused' ? 'Товар на паузе' : 'Товар архивирован' });
      load();
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="w-4 h-4 mr-1" /> Добавить товар/услугу</Button>
          </DialogTrigger>
          <CreateItemDialog onCreated={() => { setCreateOpen(false); load(); }} />
        </Dialog>
      </div>

      {items === null ? (
        <Skeleton className="h-28" />
      ) : items.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            Витрина пуста. Опубликуйте услугу, консультацию или цифровой товар.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
          {items.map((item) => (
            <div key={item.id} className="rounded-lg border p-3 flex flex-wrap items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-1.5 text-sm">
                  <span className="font-medium truncate">{item.title}</span>
                  {item.isPremium && <Crown className="w-3.5 h-3.5 text-primary" />}
                  <Badge variant="outline" className="text-[10px]">
                    {item.status === 'active' ? 'Активен' : item.status === 'paused' ? 'На паузе' : 'В архиве'}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {STORE_TYPE_LABELS[item.type] ?? item.type} · {item.priceLumens} люменов
                  {item.slotsLeft !== null && <> · свободно {item.slotsLeft}/{item.slotsTotal}</>}
                </div>
              </div>
              <div className="flex gap-1">
                {item.status === 'active' ? (
                  <Button size="icon" variant="ghost" aria-label="Пауза" onClick={() => setStatus(item.id, 'paused')}>
                    <Pause className="w-4 h-4" />
                  </Button>
                ) : item.status === 'paused' ? (
                  <Button size="icon" variant="ghost" aria-label="Возобновить" onClick={() => setStatus(item.id, 'active')}>
                    <Play className="w-4 h-4" />
                  </Button>
                ) : null}
                {item.status !== 'archived' && (
                  <Button size="icon" variant="ghost" aria-label="В архив" onClick={() => setStatus(item.id, 'archived')}>
                    <Archive className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CreateItemDialog({ onCreated }: { onCreated: () => void }) {
  const [form, setForm] = React.useState({
    type: 'services',
    title: '',
    description: '',
    priceLumens: '50',
    deliveryMode: 'online-meeting',
    slotsTotal: '0',
    isPremium: false,
  });
  const [busy, setBusy] = React.useState(false);

  async function handleCreate() {
    setBusy(true);
    try {
      await api('/api/store/items', {
        method: 'POST',
        body: JSON.stringify({
          type: form.type,
          title: form.title,
          description: form.description,
          priceLumens: Number(form.priceLumens),
          deliveryMode: form.deliveryMode,
          slotsTotal: Number(form.slotsTotal) || 0,
          ...(form.isPremium ? { isPremium: true } : {}),
        }),
      });
      toast({ title: 'Товар опубликован' });
      onCreated();
    } catch (e) {
      toast({ title: 'Не удалось опубликовать', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  const valid = form.title.trim().length > 0 && Number(form.priceLumens) >= 1;

  return (
    <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>Новый товар или услуга</DialogTitle>
      </DialogHeader>
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="si-type">Тип</Label>
            <select
              id="si-type"
              value={form.type}
              onChange={(e) => setForm({ ...form, type: e.target.value })}
              className="w-full rounded-md border bg-transparent px-3 py-2 text-sm"
            >
              {Object.entries(STORE_TYPE_LABELS).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="si-delivery">Формат</Label>
            <select
              id="si-delivery"
              value={form.deliveryMode}
              onChange={(e) => setForm({ ...form, deliveryMode: e.target.value })}
              className="w-full rounded-md border bg-transparent px-3 py-2 text-sm"
            >
              <option value="online-meeting">Онлайн-встреча</option>
              <option value="async">Асинхронно</option>
              <option value="file-delivery">Передача файла</option>
            </select>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="si-title">Название</Label>
          <Input id="si-title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Например: Консультация по карьере, 60 минут" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="si-desc">Описание</Label>
          <Textarea id="si-desc" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="si-price" className="flex items-center gap-1"><Coins className="w-3.5 h-3.5" /> Цена, люменов</Label>
            <Input id="si-price" type="number" min={1} value={form.priceLumens} onChange={(e) => setForm({ ...form, priceLumens: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="si-slots">Квота сессий (0 = безлимит)</Label>
            <Input id="si-slots" type="number" min={0} value={form.slotsTotal} onChange={(e) => setForm({ ...form, slotsTotal: e.target.value })} />
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={form.isPremium}
            onChange={(e) => setForm({ ...form, isPremium: e.target.checked })}
            className="h-4 w-4"
          />
          Premium-размещение (выше в витрине; тарифы Pro/Business)
        </label>
      </div>
      <DialogFooter>
        <Button onClick={handleCreate} disabled={!valid || busy}>
          {busy && <Loader2 className="w-4 h-4 mr-1 animate-spin" />} Опубликовать
        </Button>
      </DialogFooter>
    </DialogContent>
  );
}

// ============================== Заказы ==============================

function OrdersTab() {
  const [data, setData] = React.useState<{ sales: BookingDto[]; purchases: BookingDto[] } | null>(null);

  const load = React.useCallback(async () => {
    try {
      const res = await api<{ sales: BookingDto[]; purchases: BookingDto[] }>('/api/store/bookings');
      setData(res);
    } catch {
      setData({ sales: [], purchases: [] });
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  async function action(id: string, kind: 'fulfil' | 'decline' | 'release' | 'cancel') {
    try {
      await api(`/api/store/bookings/${id}/${kind}`, { method: 'POST' });
      toast({ title: 'Готово' });
      load();
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    }
  }

  if (data === null) return <Skeleton className="h-40" />;

  return (
    <div className="space-y-4">
      <section className="space-y-2">
        <h3 className="text-sm font-semibold">Продажи ({data.sales.length})</h3>
        {data.sales.length === 0 ? (
          <p className="text-sm text-muted-foreground">Пока нет заказов на ваши товары.</p>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {data.sales.map((b) => (
              <BookingRow key={b.id} b={b}>
                {b.status === 'held' && (
                  <>
                    <Button size="sm" onClick={() => action(b.id, 'fulfil')} className="gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Исполнено
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => action(b.id, 'decline')} className="gap-1">
                      <XCircle className="w-4 h-4" /> Отказать
                    </Button>
                  </>
                )}
              </BookingRow>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-2">
        <h3 className="text-sm font-semibold">Покупки ({data.purchases.length})</h3>
        {data.purchases.length === 0 ? (
          <p className="text-sm text-muted-foreground">Вы пока ничего не заказывали.</p>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {data.purchases.map((b) => (
              <BookingRow key={b.id} b={b}>
                {b.status === 'held' && (
                  <Button size="sm" variant="outline" onClick={() => action(b.id, 'cancel')} className="gap-1">
                    <XCircle className="w-4 h-4" /> Отменить
                  </Button>
                )}
                {b.status === 'fulfilled' && (
                  <Button size="sm" onClick={() => action(b.id, 'release')} className="gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Подтвердить получение
                  </Button>
                )}
              </BookingRow>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function BookingRow({ b, children }: { b: BookingDto; children?: React.ReactNode }) {
  return (
    <div className="rounded-lg border p-3 flex flex-wrap items-center justify-between gap-2">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-1.5 text-sm">
          <span className="font-medium truncate">{b.itemTitle}</span>
          <Badge variant="outline" className="text-[10px]">{STATUS_LABELS[b.status]}</Badge>
        </div>
        <div className="text-xs text-muted-foreground mt-0.5">
          {b.role === 'sale' ? 'Покупатель' : 'Продавец'}: {b.counterpart} · {b.priceLumens} люменов
          {b.slotAt && <> · сессия {new Date(b.slotAt).toLocaleString('ru-RU')}</>}
        </div>
        {b.notes && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">Сообщение: {b.notes}</p>}
      </div>
      <div className="flex flex-wrap gap-1.5">{children}</div>
    </div>
  );
}
