// BizON — Three-Dots Menu (поделиться/сохранить/пожаловаться)
'use client';
import * as React from 'react';
import { MoreHorizontal, Share2, Bookmark, Flag } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function ThreeDotsMenu({ itemName }: { itemName: string }) {
  const [open, setOpen] = React.useState(false);

  return (
    <div className="relative">
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(v => !v); }}
        className="p-1.5 rounded-lg hover:bg-accent transition text-muted-foreground"
      >
        <MoreHorizontal className="w-4 h-4" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={(e) => { e.stopPropagation(); setOpen(false); }} />
          <div className="absolute right-0 top-full mt-1 bg-card border rounded-lg shadow-lg p-1 min-w-[160px] z-20 soft-fade-in">
            <button
              onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(window.location.href); toast({ title: 'Ссылка скопирована' }); setOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-accent text-sm transition"
            >
              <Share2 className="w-3.5 h-3.5" /> Поделиться
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); toast({ title: 'Сохранено в закладки' }); setOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-accent text-sm transition"
            >
              <Bookmark className="w-3.5 h-3.5" /> Сохранить
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); toast({ title: 'Жалоба отправлена', description: 'AI-модератор проверит контент' }); setOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-accent text-sm text-destructive transition"
            >
              <Flag className="w-3.5 h-3.5" /> Пожаловаться
            </button>
          </div>
        </>
      )}
    </div>
  );
}
