// BizON — Trust Badge (визуализация IP-score по ТЗ 4.6)
// Цвет меняется по IP-score: basic (0-30), extended (31-70), expert (71-100)
'use client';

import { cn } from '@/lib/utils';
import type { TrustLevel } from '@/lib/types';

export function TrustBadge({
  ipScore,
  level,
  size = 'md',
  showScore = true,
  className,
}: {
  ipScore: number;
  level: TrustLevel | string;
  size?: 'sm' | 'md' | 'lg';
  showScore?: boolean;
  className?: string;
}) {
  const lvl = level as TrustLevel;
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };
  const dotSize = {
    sm: 'w-1.5 h-1.5',
    md: 'w-2 h-2',
    lg: 'w-2.5 h-2.5',
  };
  const label = lvl === 'expert' ? 'Эксперт' : lvl === 'extended' ? 'Проверенный' : 'Новичок';
  const dotClass = lvl === 'expert' ? 'trust-badge-expert' : lvl === 'extended' ? 'trust-badge-extended' : 'trust-badge-basic';

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full font-medium bg-muted text-foreground',
        sizeClasses[size],
        className
      )}
    >
      <span className={cn('rounded-full', dotSize[size], dotClass)} />
      {showScore && <span className="font-semibold">{ipScore}</span>}
      <span className="text-muted-foreground">{label}</span>
    </span>
  );
}

export function IpScoreRing({ ipScore, size = 64 }: { ipScore: number; size?: number }) {
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (ipScore / 100) * circumference;
  // FIX-04 (P1): семантика уровней по палитре «Маяк» вместо out-of-palette
  // зелёного/голубого/янтарного литералов: рост (expert ≥71) → --lighthouse,
  // плато (extended 31–70) → --success, спад (basic <31) → --warning.
  const strokeClass =
    ipScore >= 71 ? 'stroke-lighthouse' : ipScore >= 31 ? 'stroke-success' : 'stroke-warning';

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="4"
          className="text-muted"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className={cn('transition-colors duration-500', strokeClass)}
          style={{ transition: 'stroke-dashoffset 0.5s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-lg font-bold leading-none text-success-text">{ipScore}</span>
        <span className="text-xs text-muted-foreground">IP-score</span>
      </div>
    </div>
  );
}
