// Этап 8.3 A11Y — Skip-to-content link (WCAG 2.4.1 Bypass Blocks, Level A).
//
// Первая фокусируемая ссылка на странице. Скрыта визуально (sr-only),
// но появляется при фокусе с клавиатуры (Tab). Позволяет пользователям
// скринридеров и клавиатуры пропустить навигационные меню и перейти
// сразу к основному контенту (#main-content в AppShell).
//
// Используется в src/app/layout.tsx как первый фокусируемый элемент <body>.

export function SkipToContent() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-background focus:text-foreground focus:rounded"
    >
      Перейти к содержимому
    </a>
  );
}
