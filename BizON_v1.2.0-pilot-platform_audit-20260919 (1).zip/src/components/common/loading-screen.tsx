// BizON — Loading Screen с маяком
'use client';
export function LoadingScreen() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6">
      {/* Анимированный маяк */}
      <div className="relative w-24 h-24">
        {/* Лучи маяка */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="absolute w-32 h-32 rounded-full lighthouse-gradient opacity-20 animate-ping" style={{ animationDuration: '2s' }} />
        </div>
        {/* Лого маяка */}
        <div className="relative w-24 h-24 rounded-2xl overflow-hidden shadow-lg">
          <img src="/lighthouse-logo.jpg" alt="BizON" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
        </div>
      </div>
      {/* Текст */}
      <div className="text-center">
        <div className="text-lg font-bold">BizON</div>
        <div className="text-sm text-muted-foreground">Маяк в цифровом мире</div>
      </div>
      {/* Индикатор загрузки */}
      <div className="w-32 h-1 bg-muted rounded-full overflow-hidden">
        <div className="h-full lighthouse-gradient rounded-full animate-pulse" style={{ width: '60%' }} />
      </div>
    </div>
  );
}
