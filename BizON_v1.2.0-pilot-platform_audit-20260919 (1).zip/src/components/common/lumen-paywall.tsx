// BizON — LumenPaywallDialog (волна 14, монетизация)
// Единый диалог «не хватает люменов» для всех ИИ-действий за люмены.
// Открывается, когда ИИ-роут вернул 402 { need, have }.
// Внутри — быстрое пополнение (1 ₽ = 1 люмен, демо-шлюз) и честные подписи.
// После успешного пополнения вызывает onToppedUp(balance) — вызывающий код
// может сразу повторить ИИ-действие (клик = активация, −1 люмен уже учтён).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import { Zap, Loader2, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

const TOPUP_AMOUNTS = [100, 300, 500, 1000] as const;

export function LumenPaywallDialog({
  open,
  onOpenChange,
  need,
  have,
  onToppedUp,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  need: number;
  have: number;
  /** Вызывается после успешного пополнения — можно повторить ИИ-действие */
  onToppedUp?: (balance: number) => void;
}) {
  const [topping, setTopping] = React.useState<number | null>(null);

  async function handleTopup(amount: number) {
    setTopping(amount);
    try {
      const res = await api<{ balance: number; credited: number; note: string }>(
        '/api/lumens/topup',
        { method: 'POST', body: JSON.stringify({ amount }) }
      );
      toast({
        title: `Кошелёк пополнен: +${res.credited} люменов`,
        description: `Баланс: ${res.balance} Л · ${res.note}`,
      });
      onOpenChange(false);
      onToppedUp?.(res.balance);
    } catch (e: any) {
      toast({ title: 'Не удалось пополнить', description: e?.message, variant: 'destructive' });
    } finally {
      setTopping(null);
    }
  }

  const missing = Math.max(need - have, 0);
  const quickAmount = TOPUP_AMOUNTS.find((a) => a >= missing) ?? TOPUP_AMOUNTS[0];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500" />
            Не хватает люменов
          </DialogTitle>
          <DialogDescription>
            Для этого ИИ-действия нужно {need} Л, на балансе {have} Л.
            {missing > 0 && ` Докупить минимум ${missing} Л.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="text-xs leading-relaxed text-muted-foreground bg-muted/40 rounded-md p-3">
            <strong>1 ₽ = 1 люмен</strong> · люмены не сгорают · на внесённую сумму
            начисляются дивиденды — <strong>15% годовых люменами</strong> ·
            1 люмен = 1 ИИ-действие
          </div>

          <div className="grid grid-cols-2 gap-2">
            {TOPUP_AMOUNTS.map((amount) => (
              <Button
                key={amount}
                variant={amount === quickAmount ? 'default' : 'outline'}
                disabled={topping !== null}
                onClick={() => handleTopup(amount)}
                className={cn('gap-1.5', amount === quickAmount && 'bg-emerald-600 hover:bg-emerald-700 text-white')}
              >
                {topping === amount ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Zap className="w-4 h-4" />
                )}
                {amount} ₽ → {amount} Л
              </Button>
            ))}
          </div>

          <div className="flex items-start gap-1.5 text-xs text-muted-foreground">
            <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
            Демо-шлюз: реальные деньги не списываются. История операций — в кошельке
            люменов (Настройки).
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Хелпер для вызова ИИ-роутов под люменным гейтом:
 * при 402 возвращает { need, have } чтобы открыть paywall, иначе — rethrow.
 */
export function extractLumenNeed(e: unknown): { need: number; have: number } | null {
  const err = e as { status?: number; data?: { need?: unknown; have?: unknown } } | null;
  if (err && err.status === 402 && err.data) {
    const need = Number(err.data.need);
    const have = Number(err.data.have);
    if (Number.isFinite(need) && Number.isFinite(have)) return { need, have };
  }
  return null;
}
