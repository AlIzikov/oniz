// BizON — InfoBanner: контекстное описание + подсказка для каждого раздела
// Единый стиль: иконка + заголовок + описание + (опционально) подсказка
'use client';
import { Sparkles, Lightbulb, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import * as React from 'react';

export function InfoBanner({
  icon,
  title,
  description,
  tip,
  dismissible = false,
  storageKey,
}: {
  icon?: React.ReactNode;
  title: string;
  description: string;
  tip?: string;
  dismissible?: boolean;
  storageKey?: string;
}) {
  const [dismissed, setDismissed] = React.useState(false);

  React.useEffect(() => {
    if (dismissible && storageKey) {
      const d = localStorage.getItem(storageKey);
      if (d === 'dismissed') setDismissed(true);
    }
  }, [storageKey, dismissible]);

  function dismiss() {
    setDismissed(true);
    if (storageKey) localStorage.setItem(storageKey, 'dismissed');
  }

  if (dismissed) return null;

  return (
    <div className="rounded-xl border border-lighthouse/20 bg-lighthouse-gradient-soft p-3 soft-fade-in">
      <div className="flex items-start gap-3">
        {icon && (
          <div className="w-8 h-8 rounded-lg lighthouse-gradient flex items-center justify-center flex-shrink-0">
            {icon}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="text-sm font-semibold text-foreground">{title}</div>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{description}</p>
          {tip && (
            <div className="flex items-start gap-1.5 mt-2 p-2 rounded-md bg-background/50">
              <Lightbulb className="w-3.5 h-3.5 text-lighthouse flex-shrink-0 mt-0.5" />
              <span className="text-xs text-muted-foreground">{tip}</span>
            </div>
          )}
        </div>
        {dismissible && (
          <button onClick={dismiss} className="p-1 rounded hover:bg-background/50 transition flex-shrink-0">
            <X className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        )}
      </div>
    </div>
  );
}
