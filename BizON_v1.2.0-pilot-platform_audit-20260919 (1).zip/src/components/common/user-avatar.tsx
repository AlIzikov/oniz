// BizON — Avatar (fallback на инициалы + опциональный зелёный индикатор "Онлайн")
// UX-правило: зелёный = «он сейчас здесь, можно писать» (LinkedIn-стиль)
'use client';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

export function UserAvatar({
  name,
  avatarUrl,
  size = 'md',
  className,
  online = false,
}: {
  name: string;
  avatarUrl?: string | null;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  /** Показать зелёную точку "Онлайн" (как в LinkedIn/messengers) */
  online?: boolean;
}) {
  const sizeClass = {
    xs: 'w-6 h-6 text-xs',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base',
    xl: 'w-20 h-20 text-xl',
  }[size];

  // Размеры точки "Онлайн" — пропорционально аватарке
  const dotSize = {
    xs: 'w-1.5 h-1.5',
    sm: 'w-2 h-2',
    md: 'w-2.5 h-2.5',
    lg: 'w-3.5 h-3.5',
    xl: 'w-4 h-4',
  }[size];

  // Позиция точки — нижний-правый угол
  const dotPos = {
    xs: 'bottom-0 right-0',
    sm: 'bottom-0 right-0',
    md: 'bottom-0.5 right-0.5',
    lg: 'bottom-1 right-1',
    xl: 'bottom-1.5 right-1.5',
  }[size];

  const initials = name
    .split(' ')
    .map((s) => s[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className={cn('relative inline-flex', className)}>
      <Avatar className={sizeClass}>
        <AvatarImage src={avatarUrl ?? undefined} alt={name} />
        <AvatarFallback className="bg-primary/10 text-primary font-semibold">
          {initials}
        </AvatarFallback>
      </Avatar>
      {online && (
        <span
          className={cn(
            'absolute rounded-full bg-emerald-500 border-2 border-background ring-1 ring-emerald-500/30',
            dotSize,
            dotPos
          )}
          title="Сейчас онлайн"
          aria-label="Онлайн"
        />
      )}
    </div>
  );
}
