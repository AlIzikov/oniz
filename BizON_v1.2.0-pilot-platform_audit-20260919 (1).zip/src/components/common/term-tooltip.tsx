// BizON — TermTooltip: подсказка-термин по всей системе (Wave 11, отзыв
// пользователя: «не хватает подсказок — что это, как управляется, для чего
// нужен, кто и зачем создал»).
//
// Использование:
//   <TermTooltip k="career_scenario" />                     — иконка ℹ рядом с текстом
//   <TermTooltip k="career_scenario" term="Карьерные сценарии" /> — своим словом
//   <TermInfo k="career_scenario" />                        — только иконка без слова
//
// Данные термина — в src/lib/glossary.ts (что / кто / зачем / как управлять).
// Radix Tooltip работает и на десктопе (hover), и на тач-устройствах (tap = focus).
'use client';

import * as React from 'react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Info } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getGlossaryEntry } from '@/lib/glossary';

interface TermTooltipProps {
  /** Ключ из GLOSSARY (src/lib/glossary.ts) */
  k: string;
  /** Свое слово для триггера (по умолчанию — term из глоссария) */
  term?: string;
  /** Показывать ли слово-триггер (по умолчанию true — слово + ℹ) */
  showTerm?: boolean;
  className?: string;
}

export function TermTooltip({ k, term, showTerm = true, className }: TermTooltipProps) {
  const entry = getGlossaryEntry(k);
  if (!entry) {
    // Неизвестный ключ — не роняем UI, рендерим слово без подсказки
    return showTerm ? <span className={className}>{term ?? k}</span> : null;
  }
  const label = term ?? entry.term;

  return (
    <Tooltip>
      <TooltipTrigger
        asChild
        // Триггер — inline-элемент с кнопкой-иконкой: не ломает строку заголовка
      >
        <span className={cn('inline-flex items-center gap-1 cursor-help align-baseline', className)}>
          {showTerm && <span>{label}</span>}
          <Info
            className="w-3.5 h-3.5 text-muted-foreground/70 hover:text-lighthouse transition-colors shrink-0"
            aria-hidden="true"
          />
          <span className="sr-only">{label} — что это и как управляется</span>
        </span>
      </TooltipTrigger>
      <TooltipContent
        role="tooltip"
        side="bottom"
        align="start"
        className="max-w-[300px] p-3 space-y-1.5 text-left"
      >
        <div className="font-semibold text-xs">{entry.term}</div>
        <div className="text-xs leading-relaxed opacity-90">{entry.what}</div>
        <div className="text-xs leading-relaxed opacity-75">
          <span className="font-medium">Кто создаёт:</span> {entry.who}
        </div>
        <div className="text-xs leading-relaxed opacity-75">
          <span className="font-medium">Зачем:</span> {entry.why}
        </div>
        <div className="text-xs leading-relaxed opacity-75">
          <span className="font-medium">Как управлять:</span> {entry.how}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

/** Только иконка ℹ — когда слово уже есть в заголовке рядом */
export function TermInfo({ k, className }: { k: string; className?: string }) {
  return <TermTooltip k={k} showTerm={false} className={className} />;
}
