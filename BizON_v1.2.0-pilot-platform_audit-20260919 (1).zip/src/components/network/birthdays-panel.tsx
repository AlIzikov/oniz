// BizON — Панель «Дни рождения» (правая панель контактов)
// Данные: GET /api/network/birthdays (честно из User.birthday — без даты контакт не показывается).
// Секция «Сегодня» с кнопкой «Отправить поздравление» (POST /api/messages),
// секция «В этом месяце», плановые уведомления (BirthdayPlan) с done/delete.
'use client';

import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { UserAvatar } from '@/components/common/user-avatar';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import {
  Cake, Plus, Send, Check, Trash2, CalendarClock, Loader2, PartyPopper,
  Gift, MessageSquare, Smartphone, Phone, HeartHandshake,
} from 'lucide-react';
import {
  BirthdayPlanDialog, CHANNEL_META, type PlanChannel,
} from '@/components/network/birthday-plan-dialog';
import { cn } from '@/lib/utils';

export interface BirthdayEntry {
  userId: string;
  name: string;
  title: string | null;
  company: string | null;
  avatarUrl: string | null;
  birthday: string;
  month: number;
  day: number;
  isToday: boolean;
  daysLeft: number;
}

interface BirthdaysResponse {
  today: BirthdayEntry[];
  thisMonth: BirthdayEntry[];
  total: number;
}

export interface BirthdayPlanItem {
  id: string;
  personUserId: string | null;
  personName: string;
  dateMonth: number;
  dateDay: number;
  channel: PlanChannel;
  comment: string;
  remindBefore: number;
  status: 'planned' | 'done';
}

const MONTHS_SHORT = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

function daysLeftText(daysLeft: number): string {
  if (daysLeft <= 0) return 'сегодня';
  if (daysLeft === 1) return 'завтра';
  return `через ${daysLeft} дн.`;
}

function dateLabel(month: number, day: number): string {
  return `${day} ${MONTHS_SHORT[month - 1] ?? ''}`;
}

export function BirthdaysPanel({ onUserClick }: { onUserClick: (id: string) => void }) {
  const [data, setData] = React.useState<BirthdaysResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [plans, setPlans] = React.useState<BirthdayPlanItem[]>([]);
  const [plansLoading, setPlansLoading] = React.useState(true);
  const [congratulate, setCongratulate] = React.useState<{ userId: string; name: string } | null>(null);
  const [planDialogOpen, setPlanDialogOpen] = React.useState(false);
  const [presetPerson, setPresetPerson] = React.useState<{ userId?: string; name: string } | null>(null);

  const loadBirthdays = React.useCallback(async () => {
    try {
      const res = await api<BirthdaysResponse>('/api/network/birthdays');
      setData(res);
    } catch {
      // честно: панель остаётся с пустыми состояниями, без выдуманных данных
      setData({ today: [], thisMonth: [], total: 0 });
    } finally {
      setLoading(false);
    }
  }, []);

  const loadPlans = React.useCallback(async () => {
    try {
      const res = await api<{ plans: BirthdayPlanItem[] }>('/api/birthday-plans');
      setPlans(res.plans);
    } catch {
      setPlans([]);
    } finally {
      setPlansLoading(false);
    }
  }, []);

  React.useEffect(() => {
    loadBirthdays();
    loadPlans();
  }, [loadBirthdays, loadPlans]);

  async function handlePlanDone(id: string) {
    try {
      await api(`/api/birthday-plans/${id}`, { method: 'PATCH', body: JSON.stringify({ status: 'done' }) });
      setPlans((prev) => prev.map((p) => (p.id === id ? { ...p, status: 'done' } : p)));
      toast({ title: 'План выполнен' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handlePlanDelete(id: string) {
    try {
      await api(`/api/birthday-plans/${id}`, { method: 'DELETE' });
      setPlans((prev) => prev.filter((p) => p.id !== id));
      toast({ title: 'План удалён' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  const today = data?.today ?? [];
  const thisMonth = data?.thisMonth ?? [];

  return (
    <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
      <CardContent className="p-4 space-y-3">
        {/* Шапка панели */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Cake className="w-5 h-5 text-lighthouse flex-shrink-0" aria-hidden />
            <div className="min-w-0">
              <div className="text-sm font-semibold leading-tight">Дни рождения</div>
              <div className="text-xs text-muted-foreground">Среди ваших контактов</div>
            </div>
          </div>
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs flex-shrink-0"
            onClick={() => { setPresetPerson(null); setPlanDialogOpen(true); }}
          >
            <Plus className="w-3.5 h-3.5 mr-0.5" aria-hidden /> Запланировать
          </Button>
        </div>

        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-16 w-full rounded-lg" />
            <Skeleton className="h-10 w-full rounded-lg" />
          </div>
        ) : (
          <>
            {/* Сегодня */}
            {today.length > 0 && (
              <section aria-label="Дни рождения сегодня">
                <div className="text-xs font-semibold uppercase tracking-wider text-lighthouse mb-1.5">
                  Сегодня 🎉
                </div>
                <div className="flex gap-2 overflow-x-auto scroll-area-thin pb-1 lg:flex-col lg:overflow-visible lg:pb-0">
                  {today.map((b) => (
                    <div
                      key={b.userId}
                      className="min-w-[230px] lg:min-w-0 rounded-lg border border-lighthouse/30 bg-card p-2.5"
                    >
                      <button
                        onClick={() => onUserClick(b.userId)}
                        className="flex items-center gap-2 w-full text-left min-w-0 group"
                      >
                        <UserAvatar name={b.name} avatarUrl={b.avatarUrl} size="sm" />
                        <span className="flex-1 min-w-0">
                          <span className="block text-sm font-medium truncate group-hover:text-lighthouse transition-colors">
                            {b.name}
                          </span>
                          <span className="block text-xs text-muted-foreground truncate">
                            {b.title ?? '—'}
                          </span>
                        </span>
                        <PartyPopper className="w-4 h-4 text-lighthouse flex-shrink-0" aria-hidden />
                      </button>
                      <Button
                        size="sm"
                        className="w-full mt-2 h-8 text-xs"
                        onClick={() => setCongratulate({ userId: b.userId, name: b.name })}
                      >
                        <Send className="w-3.5 h-3.5 mr-1" aria-hidden />
                        Отправить поздравление
                      </Button>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* В этом месяце */}
            <section aria-label="Дни рождения в этом месяце">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
                В этом месяце
              </div>
              {thisMonth.length === 0 ? (
                <div className="rounded-lg border border-dashed p-3 text-center">
                  <p className="text-xs text-muted-foreground">
                    Среди контактов нет дней рождения в этом месяце
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Заполните дни рождения в профилях контактов
                  </p>
                </div>
              ) : (
                <div className="flex gap-2 overflow-x-auto scroll-area-thin pb-1 lg:flex-col lg:overflow-visible lg:pb-0">
                  {thisMonth.map((b) => (
                    <div key={b.userId} className="min-w-[220px] lg:min-w-0 flex items-center gap-2 rounded-lg border bg-card p-2">
                      <button onClick={() => onUserClick(b.userId)} className="flex items-center gap-2 flex-1 min-w-0 text-left group">
                        <UserAvatar name={b.name} avatarUrl={b.avatarUrl} size="sm" />
                        <span className="flex-1 min-w-0">
                          <span className="block text-xs font-medium truncate group-hover:text-lighthouse transition-colors">
                            {b.name}
                          </span>
                          <span className="block text-xs text-muted-foreground">
                            {dateLabel(b.month, b.day)}
                          </span>
                        </span>
                      </button>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span
                          className={cn(
                            'text-xs font-medium',
                            b.isToday ? 'text-lighthouse' : 'text-muted-foreground'
                          )}
                        >
                          {daysLeftText(b.daysLeft)}
                        </span>
                        <button
                          title={`Запланировать уведомление для ${b.name}`}
                          aria-label={`Запланировать уведомление для ${b.name}`}
                          onClick={() => { setPresetPerson({ userId: b.userId, name: b.name }); setPlanDialogOpen(true); }}
                          className="p-1.5 rounded-md hover:bg-muted transition min-h-[28px] min-w-[28px] inline-flex items-center justify-center"
                        >
                          <CalendarClock className="w-3.5 h-3.5 text-muted-foreground" aria-hidden />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </>
        )}

        {/* Плановые уведомления */}
        <section aria-label="Плановые уведомления" className="pt-1 border-t border-lighthouse/20">
          <div className="flex items-center justify-between mt-2 mb-1.5">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Плановые уведомления
            </div>
            {!plansLoading && plans.length > 0 && (
              <span className="text-xs text-muted-foreground">{plans.length}/50</span>
            )}
          </div>

          {plansLoading ? (
            <Skeleton className="h-10 w-full rounded-lg" />
          ) : plans.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              Пока нет планов. Нажмите «Запланировать» — и не пропустите важную дату.
            </p>
          ) : (
            <ul className="space-y-1.5 max-h-48 overflow-y-auto scroll-area-thin">
              {plans.map((p) => (
                <li
                  key={p.id}
                  title={p.comment}
                  className={cn(
                    'flex items-center gap-2 rounded-lg border bg-card p-2',
                    p.status === 'done' && 'opacity-60'
                  )}
                >
                  <span className="flex-shrink-0 inline-flex items-center justify-center w-6 h-6 rounded-md bg-muted" aria-hidden title={CHANNEL_META[p.channel]?.hint}>
                    {p.channel === 'gift' ? (
                      <GiftIcon />
                    ) : p.channel === 'in_platform' ? (
                      <PlatformIcon />
                    ) : p.channel === 'sms' ? (
                      <SmsIcon />
                    ) : p.channel === 'call' ? (
                      <CallIcon />
                    ) : (
                      <PersonIcon />
                    )}
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="flex items-center gap-1.5">
                      <span className="text-xs font-medium truncate">{p.personName}</span>
                      {p.status === 'done' && (
                        <Badge variant="secondary" className="text-xs px-1 py-0 flex-shrink-0">выполнен</Badge>
                      )}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {dateLabel(p.dateMonth, p.dateDay)}
                      {p.remindBefore > 0 && ` · напомнить за ${p.remindBefore} дн.`}
                    </span>
                  </span>
                  {p.status === 'planned' && (
                    <button
                      title="Отметить выполненным"
                      aria-label={`Отметить выполненным: ${p.personName}`}
                      onClick={() => handlePlanDone(p.id)}
                      className="p-1.5 rounded-md hover:bg-muted transition min-h-[28px] min-w-[28px] inline-flex items-center justify-center"
                    >
                      <Check className="w-3.5 h-3.5 text-lighthouse" aria-hidden />
                    </button>
                  )}
                  <button
                    title="Удалить план"
                    aria-label={`Удалить план: ${p.personName}`}
                    onClick={() => handlePlanDelete(p.id)}
                    className="p-1.5 rounded-md hover:bg-muted transition min-h-[28px] min-w-[28px] inline-flex items-center justify-center"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-muted-foreground" aria-hidden />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <p className="text-xs text-muted-foreground mt-2 leading-snug">
            Напоминания придут в уведомлениях платформы — отправка по каналам в следующих версиях
          </p>
        </section>
      </CardContent>

      {/* Диалог поздравления */}
      <CongratulateDialog
        target={congratulate}
        onClose={() => setCongratulate(null)}
      />

      {/* Диалог планового уведомления */}
      <BirthdayPlanDialog
        open={planDialogOpen}
        onOpenChange={setPlanDialogOpen}
        presetPerson={presetPerson}
        onCreated={loadPlans}
      />
    </Card>
  );
}

/** Диалог «Отправить поздравление»: шаблонный текст + POST /api/messages */
function CongratulateDialog({ target, onClose }: {
  target: { userId: string; name: string } | null;
  onClose: () => void;
}) {
  const [text, setText] = React.useState('');
  const [sending, setSending] = React.useState(false);

  React.useEffect(() => {
    if (target) {
      setText(`🎉 ${target.name}, с днём рождения! Здоровья, ярких событий и профессиональных побед!`);
    }
  }, [target]);

  async function send() {
    if (!target || sending || !text.trim()) return;
    setSending(true);
    try {
      await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId: target.userId, content: text.trim() }),
      });
      toast({ title: 'Поздравление отправлено', description: `${target.name} получит ваше сообщение` });
      onClose();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  return (
    <Dialog open={!!target} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Отправить поздравление</DialogTitle>
          <DialogDescription>
            {target ? `Для ${target.name} — сообщение придёт в переписку BizON` : ''}
          </DialogDescription>
        </DialogHeader>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={4}
          maxLength={2000}
          aria-label="Текст поздравления"
        />
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={sending}>Отмена</Button>
          <Button onClick={send} disabled={sending || !text.trim()}>
            {sending && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
            <Send className="w-4 h-4 mr-1" aria-hidden />
            Отправить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* Иконки каналов для списка планов */
function GiftIcon() { return <Gift className="w-3.5 h-3.5 text-muted-foreground" aria-hidden />; }
function PlatformIcon() { return <MessageSquare className="w-3.5 h-3.5 text-lighthouse" aria-hidden />; }
function SmsIcon() { return <Smartphone className="w-3.5 h-3.5 text-muted-foreground" aria-hidden />; }
function CallIcon() { return <Phone className="w-3.5 h-3.5 text-muted-foreground" aria-hidden />; }
function PersonIcon() { return <HeartHandshake className="w-3.5 h-3.5 text-lighthouse" aria-hidden />; }
