// BizON — Диалог планового уведомления о дне рождения (BirthdayPlan)
// Требование пользователя: ставишь ДР человека — сразу составляешь плановое уведомление
// с обязательным комментарием: направить СМС / позвонить / поздравить лично / подарок («модуль позже»).
'use client';

import * as React from 'react';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import {
  MessageSquare, Smartphone, Phone, Handshake, Gift, Loader2, Lock,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export const MONTHS_RU = [
  'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь',
];

export type PlanChannel = 'in_platform' | 'sms' | 'call' | 'in_person' | 'gift';

export const CHANNEL_META: Record<PlanChannel, { label: string; hint: string }> = {
  in_platform: { label: 'В платформе', hint: 'Сообщение в BizON' },
  sms: { label: 'Направить SMS', hint: 'СМС на телефон' },
  call: { label: 'Позвонить', hint: 'Звонок' },
  in_person: { label: 'Поздравить лично', hint: 'Личная встреча' },
  gift: { label: 'Направить подарок', hint: 'этот модуль мы сделаем позже' },
};

const CHANNEL_ORDER: PlanChannel[] = ['in_platform', 'sms', 'call', 'in_person', 'gift'];

export interface BirthdayPlanDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Предзаполнение из карточки контакта (personUserId + имя) */
  presetPerson?: { userId?: string; name: string } | null;
  onCreated: () => void;
}

export function BirthdayPlanDialog({ open, onOpenChange, presetPerson, onCreated }: BirthdayPlanDialogProps) {
  const [personName, setPersonName] = React.useState('');
  const [month, setMonth] = React.useState<string>('');
  const [day, setDay] = React.useState<string>('');
  const [channel, setChannel] = React.useState<PlanChannel>('in_platform');
  const [comment, setComment] = React.useState('');
  const [remindBefore, setRemindBefore] = React.useState<string>('0');
  const [submitting, setSubmitting] = React.useState(false);

  // Предзаполнение при открытии
  React.useEffect(() => {
    if (open) {
      setPersonName(presetPerson?.name ?? '');
      setMonth('');
      setDay('');
      setChannel('in_platform');
      setComment('');
      setRemindBefore('0');
    }
  }, [open, presetPerson]);

  const daysInMonth = month ? new Date(2024, Number(month) - 1, 0).getDate() : 31;

  const valid = personName.trim().length > 0 && month && day && comment.trim().length > 0;

  async function submit() {
    if (!valid || submitting) return;
    setSubmitting(true);
    try {
      const res = await api<{ scheduled: boolean; note: string }>('/api/birthday-plans', {
        method: 'POST',
        body: JSON.stringify({
          personName: personName.trim(),
          dateMonth: Number(month),
          dateDay: Number(day),
          channel,
          comment: comment.trim(),
          remindBefore: Number(remindBefore),
          ...(presetPerson?.userId ? { personUserId: presetPerson.userId } : {}),
        }),
      });
      toast({ title: 'Плановое уведомление сохранено', description: res.note });
      onCreated();
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto scroll-area-thin">
        <DialogHeader>
          <DialogTitle>Плановое уведомление</DialogTitle>
          <DialogDescription>
            Запланируйте напоминание о дне рождения — и комментарий, что сделать в этот день
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-1">
          {/* Человек */}
          <div className="space-y-1.5">
            <Label htmlFor="bp-person">Человек *</Label>
            <Input
              id="bp-person"
              value={personName}
              onChange={(e) => setPersonName(e.target.value)}
              placeholder="Егоров Александр"
              maxLength={80}
            />
            <p className="text-xs text-muted-foreground">
              Можно указать и человека вне платформы — просто впишите имя
            </p>
          </div>

          {/* Дата */}
          <div className="space-y-1.5">
            <Label>Дата рождения *</Label>
            <div className="grid grid-cols-2 gap-2">
              <Select value={month} onValueChange={(v) => { setMonth(v); setDay(''); }}>
                <SelectTrigger aria-label="Месяц">
                  <SelectValue placeholder="Месяц" />
                </SelectTrigger>
                <SelectContent>
                  {MONTHS_RU.map((m, i) => (
                    <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={day} onValueChange={setDay} disabled={!month}>
                <SelectTrigger aria-label="День">
                  <SelectValue placeholder="День" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((d) => (
                    <SelectItem key={d} value={String(d)}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Канал — сегментированные кнопки */}
          <div className="space-y-1.5">
            <Label>Канал *</Label>
            <div className="grid grid-cols-2 gap-1.5" role="group" aria-label="Канал планового уведомления">
              {CHANNEL_ORDER.map((key) => {
                const meta = CHANNEL_META[key];
                const isGift = key === 'gift';
                const selected = channel === key;
                return (
                  <button
                    key={key}
                    type="button"
                    disabled={isGift}
                    title={isGift ? 'этот модуль мы сделаем позже' : meta.hint}
                    aria-pressed={selected}
                    onClick={() => !isGift && setChannel(key)}
                    className={cn(
                      'flex items-center gap-2 rounded-md border px-2.5 py-2 text-left text-xs transition min-h-[44px]',
                      isGift && 'opacity-50 cursor-not-allowed bg-muted/40',
                      !isGift && selected
                        ? 'border-primary bg-primary/10 text-primary font-medium'
                        : !isGift && 'hover:border-primary/50 text-foreground'
                    )}
                  >
                    {isGift ? (
                      <Lock className="w-3.5 h-3.5 flex-shrink-0 text-muted-foreground" aria-hidden />
                    ) : (
                      React.createElement(CHANNEL_ICONS[key], { className: 'w-3.5 h-3.5 flex-shrink-0', 'aria-hidden': true })
                    )}
                    <span className="flex-1 min-w-0">
                      <span className="block truncate">{meta.label}</span>
                      {isGift && <span className="block text-xs text-muted-foreground">этот модуль мы сделаем позже</span>}
                    </span>
                    {isGift && <Badge variant="outline" className="text-xs px-1 py-0 flex-shrink-0">модуль позже</Badge>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Комментарий — обязательный */}
          <div className="space-y-1.5">
            <Label htmlFor="bp-comment">Комментарий *</Label>
            <Textarea
              id="bp-comment"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Например: позвонить и поздравить лично, заодно обсудить проект"
              maxLength={500}
              rows={3}
            />
            <p className="text-xs text-muted-foreground">{comment.trim().length}/500</p>
          </div>

          {/* Напомнить за N дней */}
          <div className="space-y-1.5">
            <Label>Напомнить за N дней</Label>
            <Select value={remindBefore} onValueChange={setRemindBefore}>
              <SelectTrigger aria-label="Напомнить за сколько дней">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0">В сам день рождения</SelectItem>
                <SelectItem value="1">За 1 день</SelectItem>
                <SelectItem value="3">За 3 дня</SelectItem>
                <SelectItem value="7">За 7 дней</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
            Отмена
          </Button>
          <Button onClick={submit} disabled={!valid || submitting}>
            {submitting && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
            Сохранить план
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

const CHANNEL_ICONS: Record<Exclude<PlanChannel, 'gift'>, React.ComponentType<{ className?: string; 'aria-hidden'?: boolean | 'true' | 'false' }>> = {
  in_platform: MessageSquare,
  sms: Smartphone,
  call: Phone,
  in_person: Handshake,
};
