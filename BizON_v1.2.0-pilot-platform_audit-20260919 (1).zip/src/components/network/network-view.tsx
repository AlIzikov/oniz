// BizON — Network View (контакты: список/таблица + правая панель «Дни рождения»)
// Отзыв пользователя (волна 11): панель ДР справа (сегодня + этот месяц + плановые
// уведомления), два вида отображения контактов — «Список» и «Таблица».
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from '@/components/ui/table';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { BirthdaysPanel } from '@/components/network/birthdays-panel';
import { IntroInbox } from '@/components/trust/intro-inbox';
import { BizCardDialog } from '@/components/trust/bizcard-dialog';
import { toast } from '@/hooks/use-toast';
import type { ConnectionPublic } from '@/lib/types';
import { Check, X, UserPlus, Users, List, Table as TableIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

type ContactsViewMode = 'list' | 'table';

export function NetworkView() {
  const { setProfileUserId, user } = useAppStore();
  const [connections, setConnections] = React.useState<ConnectionPublic[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<'all' | 'incoming' | 'outgoing'>('all');
  // Вид отображения связей: сохраняем в localStorage (hydration после монтирования — без SSR-мисматча)
  const [viewMode, setViewMode] = React.useState<ContactsViewMode>('list');

  React.useEffect(() => {
    const saved = window.localStorage.getItem('bizon.contactsView');
    if (saved === 'table' || saved === 'list') setViewMode(saved);
  }, []);

  function changeViewMode(mode: ContactsViewMode) {
    setViewMode(mode);
    try { window.localStorage.setItem('bizon.contactsView', mode); } catch { /* приватный режим — не критично */ }
  }

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const q = filter === 'all' ? '' : `?direction=${filter}`;
      const res = await api<{ connections: ConnectionPublic[] }>(`/api/connections${q}`);
      setConnections(res.connections);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [filter]);

  React.useEffect(() => { load(); }, [load]);

  async function handleAction(connId: string, action: 'accept' | 'decline') {
    try {
      await api('/api/connections', {
        method: 'PATCH',
        body: JSON.stringify({ connectionId: connId, action }),
      });
      toast({ title: action === 'accept' ? 'Связь принята' : 'Связь отклонена' });
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  const incoming = connections.filter((c) => c.direction === 'incoming' && c.status === 'pending');
  const accepted = connections.filter((c) => c.status === 'accepted');
  const outgoing = connections.filter((c) => c.direction === 'outgoing' && c.status === 'pending');

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Контакты</h1>
        <p className="text-sm text-muted-foreground">Ваш граф доверия</p>
      </div>

      {/* Двухколоночный layout: слева контакты, справа панель ДР (sticky на desktop,
          сверху компактной каруселью на мобильном) */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-4 items-start">
        {/* Основная колонка */}
        <div className="min-w-0 space-y-4 order-2 lg:order-1">
          {/* Wave 1: интро-запросы на согласие (Кольцо доверия) */}
          <IntroInbox />

          {/* Tabs */}
          <div className="flex gap-1 border-b">
            {([['all', `Все (${accepted.length})`], ['incoming', `Входящие (${incoming.length})`], ['outgoing', `Исходящие (${outgoing.length})`]] as const).map(([f, label]) => (
              <button
                key={f}
                onClick={() => setFilter(f as any)}
                className={`px-3 py-1.5 text-sm border-b-2 -mb-px transition ${
                  filter === f ? 'border-primary text-primary font-medium' : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}
            </div>
          ) : filter === 'incoming' ? (
            incoming.length === 0 ? (
              <Card className="p-8 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-muted-foreground">Нет входящих запросов</p>
              </Card>
            ) : (
              <div className="space-y-2">
                {incoming.map((c) => (
                  <ConnectionRow
                    key={c.id}
                    conn={c}
                    currentUserId={user?.id}
                    onUserClick={setProfileUserId}
                    onAction={handleAction}
                  />
                ))}
              </div>
            )
          ) : filter === 'outgoing' ? (
            outgoing.length === 0 ? (
              <Card className="p-8 text-center">
                <UserPlus className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-muted-foreground">Нет исходящих запросов</p>
              </Card>
            ) : (
              <div className="space-y-2">
                {outgoing.map((c) => (
                  <ConnectionRow key={c.id} conn={c} currentUserId={user?.id} onUserClick={setProfileUserId} />
                ))}
              </div>
            )
          ) : (
            <>
              {incoming.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Запросы на связь</div>
                  {incoming.map((c) => (
                    <ConnectionRow key={c.id} conn={c} currentUserId={user?.id} onUserClick={setProfileUserId} onAction={handleAction} />
                  ))}
                </div>
              )}
              <div className="space-y-2">
                {/* Шапка «Мои связи» + переключатель вида Список/Таблица */}
                <div className="flex items-center justify-between gap-2">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                    Мои связи ({accepted.length})
                  </div>
                  <div className="flex items-center gap-0.5 rounded-md border p-0.5" role="group" aria-label="Вид отображения контактов">
                    <button
                      type="button"
                      aria-pressed={viewMode === 'list'}
                      aria-label="Вид: список"
                      title="Список"
                      onClick={() => changeViewMode('list')}
                      className={cn(
                        'inline-flex items-center justify-center w-8 h-7 rounded transition min-w-[32px]',
                        viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                      )}
                    >
                      <List className="w-4 h-4" aria-hidden />
                    </button>
                    <button
                      type="button"
                      aria-pressed={viewMode === 'table'}
                      aria-label="Вид: таблица"
                      title="Таблица"
                      onClick={() => changeViewMode('table')}
                      className={cn(
                        'inline-flex items-center justify-center w-8 h-7 rounded transition min-w-[32px]',
                        viewMode === 'table' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
                      )}
                    >
                      <TableIcon className="w-4 h-4" aria-hidden />
                    </button>
                  </div>
                </div>

                {accepted.length === 0 ? (
                  <Card className="p-8 text-center">
                    <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-muted-foreground">Пока нет связей. Найдите коллег через поиск или AI-Matchmaker.</p>
                  </Card>
                ) : viewMode === 'table' ? (
                  <ConnectionsTable connections={accepted} currentUserId={user?.id} onUserClick={setProfileUserId} />
                ) : (
                  <div className="space-y-2">
                    {accepted.map((c) => (
                      <ConnectionRow key={c.id} conn={c} currentUserId={user?.id} onUserClick={setProfileUserId} />
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        {/* Правая панель «Дни рождения» */}
        <aside className="order-1 lg:order-2 lg:sticky lg:top-4 self-start" aria-label="Панель дней рождения">
          <BirthdaysPanel onUserClick={setProfileUserId} />
          {/* Wave 1: цифровая визитка (QR → публичный паспорт) */}
          <div className="mt-3 flex justify-center">
            <BizCardDialog />
          </div>
        </aside>
      </div>
    </div>
  );
}

/** Табличный вид принятых связей: аватарка, ФИО, должность, компания, trust */
function ConnectionsTable({ connections, currentUserId, onUserClick }: {
  connections: ConnectionPublic[];
  currentUserId?: string;
  onUserClick: (id: string) => void;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto scroll-area-thin">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[35%]">Имя</TableHead>
              <TableHead>Должность</TableHead>
              <TableHead className="hidden sm:table-cell">Компания</TableHead>
              <TableHead className="text-right pr-4">Trust</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {connections.map((c) => {
              const u = c.fromUser.id === currentUserId ? c.toUser : c.fromUser;
              return (
                <TableRow
                  key={c.id}
                  onClick={() => onUserClick(u.id)}
                  className="cursor-pointer"
                  aria-label={`Открыть профиль: ${u.name}`}
                >
                  <TableCell>
                    <div className="flex items-center gap-2 min-w-0">
                      <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="xs" />
                      <span className="text-sm font-medium truncate max-w-[160px]">{u.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="text-xs text-muted-foreground block truncate max-w-[150px]">
                      {u.title ?? '—'}
                    </span>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <span className="text-xs text-muted-foreground block truncate max-w-[150px]">
                      {u.company ?? '—'}
                    </span>
                  </TableCell>
                  <TableCell className="text-right pr-4">
                    <TrustBadge ipScore={u.ipScore} level={u.level} size="sm" />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}

function ConnectionRow({ conn, currentUserId, onUserClick, onAction }: {
  conn: ConnectionPublic;
  currentUserId?: string;
  onUserClick: (id: string) => void;
  onAction?: (id: string, action: 'accept' | 'decline') => void;
}) {
  const otherUser = conn.fromUser.id === currentUserId ? conn.toUser : conn.fromUser;
  const isIncoming = conn.direction === 'incoming' && conn.status === 'pending';

  return (
    <Card className="hover:shadow-sm transition-shadow">
      <CardContent className="p-3 flex items-center gap-3">
        <button onClick={() => onUserClick(otherUser.id)}>
          <UserAvatar name={otherUser.name} avatarUrl={otherUser.avatarUrl} size="md" />
        </button>
        <button onClick={() => onUserClick(otherUser.id)} className="flex-1 min-w-0 text-left">
          <div className="font-medium text-sm truncate">{otherUser.name}</div>
          <div className="text-xs text-muted-foreground truncate">{otherUser.title ?? '—'}</div>
          {conn.note && <div className="text-xs text-muted-foreground italic mt-0.5 truncate">«{conn.note}»</div>}
        </button>
        <div className="flex items-center gap-2 flex-shrink-0">
          <TrustBadge ipScore={otherUser.ipScore} level={otherUser.level} size="sm" />
          {isIncoming && onAction && (
            <>
              <Button size="sm" onClick={() => onAction(conn.id, 'accept')}>
                <Check className="w-3 h-3 mr-1" /> Принять
              </Button>
              <Button size="sm" variant="outline" onClick={() => onAction(conn.id, 'decline')}>
                <X className="w-3 h-3" />
              </Button>
            </>
          )}
          {conn.status === 'accepted' && <Badge variant="secondary" className="text-xs">Связь</Badge>}
          {conn.status === 'pending' && !isIncoming && <Badge variant="outline" className="text-xs">Ожидает</Badge>}
        </div>
      </CardContent>
    </Card>
  );
}
