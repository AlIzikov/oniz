// BizON v6.2 — Workforce panel «Ворота найма» (doc_a §35, Task 10-b)
// ============================================================================
// Полная цепочка Workforce Intelligence одним ответом:
//   demand → gap → Training (обучение) → Mentoring (менторские пары) →
//   → Pipeline (воронка source→screen→interview→offer→hired с конверсиями)
//   GET /api/workforce/overview?companyId=...  (Task 9-g)
//
// companyId: по умолчанию User.companyId; аккаунты без привязки (sandbox:
// HR-агентства) выбирают компанию из справочника /api/companies.
// Секция видна ТОЛЬКО сессиям company | hr_agency (individual → null).
// Дизайн: navy + teal; отклонённые из воронки — нейтральный muted (не red).
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
  Funnel, GraduationCap, HeartHandshake, TrendingUp,
  Users, ArrowDown, Building2, Filter,
} from 'lucide-react';
import {
  useCompanyHrSession,
  IntelCard,
  IntelEmptyState,
  IntelErrorState,
  Spinner,
} from './intel-shared';

// ============================================================================
// === Типы ответа /api/workforce/overview ===
// ============================================================================

type WorkforceOverview = {
  companyId: string | null;
  companyName?: string;
  generatedAt: string;
  chain: string[];
  demand: { activeJobs: number; gapSkills: number; criticalGaps: number };
  gap: Array<{
    skill: string;
    have: number;
    need: number;
    gap: number;
    severity: 'low' | 'medium' | 'high' | 'critical';
    note: string;
  }>;
  training: {
    recommendations: Array<{
      skill: string;
      need: number;
      have: number;
      severity: string;
      courses: Array<{ id: string; title: string; provider: string; url: string | null; category: string | null; durationHours: number | null; matchedBecause: string }>;
      note: string | null;
    }>;
    employeeEnrollments: Array<{ courseId: string; courseTitle: string; category: string; inProgress: number; completed: number }>;
    catalogSize: number;
    note: string | null;
  };
  mentoring: {
    activeMentorships: Array<{
      id: string;
      mentor: { id: string; name: string; title: string | null };
      mentee: { id: string; name: string; title: string | null };
      skillName: string | null;
      startedAt: string;
      mentorIsEmployee: boolean;
      menteeIsEmployee: boolean;
    }>;
    recommendations: Array<{
      menteeId: string;
      menteeName: string;
      menteeTitle: string | null;
      skillName: string;
      currentLevel: number;
      targetLevel: number;
      mentors: Array<{ mentorId: string; name: string; title: string | null; peakLevel: number; internal: boolean; why: string }>;
      note: string | null;
    }>;
    note: string | null;
  };
  pipeline: {
    jobs: { total: number; active: number };
    stages: { source: number; screen: number; interview: number; offer: number; hired: number; lost: number; preparing: number };
    conversions: { screenRate: number | null; interviewRate: number | null; offerRate: number | null; hireRate: number | null };
    placements: { total: number; confirmedByCompany: number; recent: Array<{ candidateName: string; jobTitle: string; placedAt: string; confirmedByCompany: boolean }> };
    note: string | null;
  } | null;
  hrAgencyOutreach: { total: number; active: number; blocked: number } | null;
};

type CompanyLite = { id: string; name: string; logoUrl?: string | null; industry?: string | null };

// ============================================================================
// === Панель ===
// ============================================================================

export function WorkforceGatesPanel() {
  const isCompanyHr = useCompanyHrSession();
  const user = useAppStore((s) => s.user);

  const [companies, setCompanies] = React.useState<CompanyLite[] | null>(null);
  const [companyId, setCompanyId] = React.useState<string>(user?.companyId ?? '');
  const [data, setData] = React.useState<WorkforceOverview | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // Аккаунт без привязки к компании (sandbox: HR-агентства) — даём выбор компании
  const needsPicker = isCompanyHr && !user?.companyId;

  React.useEffect(() => {
    if (!needsPicker) return;
    let cancelled = false;
    api<{ companies: CompanyLite[] }>('/api/companies?limit=50')
      .then((res) => {
        if (!cancelled) setCompanies(res.companies);
      })
      .catch(() => {
        if (!cancelled) setCompanies([]);
      });
    return () => {
      cancelled = true;
    };
  }, [needsPicker]);

  const load = React.useCallback(async (cid: string) => {
    if (!cid) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api<WorkforceOverview>(`/api/workforce/overview?companyId=${encodeURIComponent(cid)}`);
      setData(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Не удалось загрузить обзор персонала');
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    if (isCompanyHr && user?.companyId) void load(user.companyId);
  }, [isCompanyHr, user?.companyId, load]);

  if (!isCompanyHr) return null; // individual / нет сессии → секция скрыта

  return (
    <IntelCard
      icon={<Funnel className="w-4 h-4 text-lighthouse" aria-hidden="true" />}
      title="Ворота найма — Workforce Intelligence"
      subtitle="Воронка найма с конверсиями, менторские пары и обучение под дефициты навыков — цепочка demand → gap → training → mentoring → pipeline."
      actions={data?.generatedAt ? <Spinner label={`обновлено ${new Date(data.generatedAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`} /> : undefined}
    >
      {/* === Выбор компании (для аккаунтов без привязки) === */}
      {needsPicker && (
        <div className="space-y-2">
          <Label htmlFor="wf-company-select">Компания</Label>
          {companies === null ? (
            <Skeleton className="h-9 w-full" />
          ) : companies.length === 0 ? (
            <p className="text-xs text-muted-foreground">Справочник компаний пуст.</p>
          ) : (
            <div className="flex gap-2">
              <select
                id="wf-company-select"
                value={companyId}
                onChange={(e) => setCompanyId(e.target.value)}
                className="flex-1 min-w-0 p-2 border rounded-md bg-background text-sm"
                aria-label="Выберите компанию для обзора персонала"
              >
                <option value="">Выберите компанию…</option>
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                    {c.industry ? ` · ${c.industry}` : ''}
                  </option>
                ))}
              </select>
              <ButtonLike onClick={() => void load(companyId)} disabled={!companyId || loading}>
                Показать
              </ButtonLike>
            </div>
          )}
        </div>
      )}

      {error && <IntelErrorState message={error} onRetry={() => void load(companyId || (user?.companyId ?? ''))} />}
      {loading && (
        <div className="space-y-2" aria-busy="true">
          <Skeleton className="h-16 w-full rounded-lg" />
          <Skeleton className="h-24 w-full rounded-lg" />
          <Skeleton className="h-24 w-full rounded-lg" />
        </div>
      )}

      {!loading && data && (
        <div className="space-y-4 soft-fade-in">
          {/* === Demand: сводка === */}
          <div className="grid grid-cols-3 gap-2">
            <StatBlock label="Активных вакансий" value={data.demand.activeJobs} />
            <StatBlock label="Дефицитов навыков" value={data.demand.gapSkills} />
            <StatBlock label="Критичных дефицитов" value={data.demand.criticalGaps} tone={data.demand.criticalGaps > 0 ? 'attention' : 'normal'} />
          </div>
          {data.companyName && (
            <p className="text-xs text-muted-foreground flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 flex-shrink-0" aria-hidden="true" />
              Компания: <strong className="text-foreground/80">{data.companyName}</strong>
            </p>
          )}

          {/* === HR-агентство: outreach === */}
          {data.hrAgencyOutreach && (
            <p className="text-xs text-muted-foreground">
              Контакты агентства: всего {data.hrAgencyOutreach.total} · активных {data.hrAgencyOutreach.active} · заблокированных {data.hrAgencyOutreach.blocked}
            </p>
          )}

          {/* === Воронка найма === */}
          {data.pipeline ? (
            <FunnelSection pipeline={data.pipeline} />
          ) : (
            <p className="text-xs text-muted-foreground">
              Компания не привязана к аккаунту и companyId не указан — выберите компанию выше.
            </p>
          )}

          {/* === Менторские пары === */}
          <MentoringSection mentoring={data.mentoring} />

          {/* === Обучение === */}
          <TrainingSection training={data.training} />
        </div>
      )}

      {!loading && !data && !error && !needsPicker && (
        <IntelEmptyState
          icon={<Funnel className="w-8 h-8" aria-hidden="true" />}
          title="Нет данных для отображения"
          note="Компания не привязана к аккаунту — укажите companyId."
        />
      )}
    </IntelCard>
  );
}

// ============================================================================
// === Воронка ===
// ============================================================================

const FUNNEL_STAGES: Array<{ key: 'source' | 'screen' | 'interview' | 'offer' | 'hired'; label: string; hint: string }> = [
  { key: 'source', label: 'Отклики', hint: 'все поданные отклики' },
  { key: 'screen', label: 'Скрининг', hint: 'просмотрен / изучен' },
  { key: 'interview', label: 'Интервью', hint: 'собеседования' },
  { key: 'offer', label: 'Оффер', hint: 'предложения (вкл. принятые)' },
  { key: 'hired', label: 'Наняты', hint: 'вышли на работу' },
];

function FunnelSection({ pipeline }: { pipeline: NonNullable<WorkforceOverview['pipeline']> }) {
  const { stages, conversions } = pipeline;
  const source = stages.source;
  const convToNext: Record<string, number | null> = {
    source: conversions.screenRate,
    screen: conversions.interviewRate,
    interview: conversions.offerRate,
    offer: conversions.hireRate,
    hired: null,
  };

  if (source === 0 && stages.preparing === 0) {
    return (
      <div className="space-y-1">
        <SectionTitle icon={<Filter className="w-3.5 h-3.5" aria-hidden="true" />}>Воронка найма</SectionTitle>
        <p className="text-xs text-muted-foreground p-2">
          {pipeline.note ?? 'Откликов на вакансии компании пока нет — воронка пустая.'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <SectionTitle icon={<Filter className="w-3.5 h-3.5" aria-hidden="true" />}>Воронка найма</SectionTitle>
      <ol className="space-y-1.5" aria-label="Воронка найма по этапам">
        {FUNNEL_STAGES.map((s, idx) => {
          const count = stages[s.key];
          const widthPct = source > 0 ? Math.max(4, Math.round((count / source) * 100)) : 0;
          const conv = convToNext[s.key];
          return (
            <li key={s.key} className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="w-20 sm:w-24 text-xs text-muted-foreground flex-shrink-0">{s.label}</span>
                <div className="flex-1 min-w-0">
                  <div
                    className="h-6 rounded-md bg-lighthouse/15 border border-lighthouse/30 flex items-center"
                    style={{ width: `${widthPct}%`, minWidth: '2.5rem' }}
                    aria-hidden="true"
                  >
                    <span className="px-1.5 text-xs font-semibold tabular-nums text-lighthouse whitespace-nowrap">
                      {count}
                    </span>
                  </div>
                </div>
                {conv !== null && conv !== undefined && (
                  <span className="text-xs text-muted-foreground tabular-nums flex-shrink-0 flex items-center gap-0.5">
                    <ArrowDown className="w-3 h-3" aria-hidden="true" />
                    {conv}% →
                  </span>
                )}
              </div>
              {idx === 0 && (
                <p className="text-xs text-muted-foreground pl-[5.5rem] sm:pl-[6rem]">{s.hint}</p>
              )}
            </li>
          );
        })}
      </ol>
      {/* Отклонённые — нейтральный muted (не red), подготовка — вне воронки */}
      <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
        <span>Выпали из воронки (отклонены): <strong className="text-foreground/70 tabular-nums">{stages.lost}</strong></span>
        {stages.preparing > 0 && (
          <span>Готовят отклик (ещё не отправлен): <strong className="text-foreground/70 tabular-nums">{stages.preparing}</strong></span>
        )}
        {pipeline.placements.total > 0 && (
          <span>
            Placement'ов через HR-канал: <strong className="text-foreground/70 tabular-nums">{pipeline.placements.total}</strong> (подтверждено компанией: {pipeline.placements.confirmedByCompany})
          </span>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// === Менторские пары ===
// ============================================================================

function MentoringSection({ mentoring }: { mentoring: WorkforceOverview['mentoring'] }) {
  const active = mentoring.activeMentorships;
  const recs = mentoring.recommendations;

  if (active.length === 0 && recs.length === 0) {
    return (
      <div className="space-y-1">
        <SectionTitle icon={<HeartHandshake className="w-3.5 h-3.5" aria-hidden="true" />}>Менторские пары</SectionTitle>
        <p className="text-xs text-muted-foreground p-2">{mentoring.note ?? 'Активных наставничеств и рекомендаций пар нет.'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <SectionTitle icon={<HeartHandshake className="w-3.5 h-3.5" aria-hidden="true" />}>
        Менторские пары {active.length > 0 && <Badge variant="secondary" className="text-xs ml-1">активных: {active.length}</Badge>}
      </SectionTitle>

      {active.length > 0 && (
        <ul className="space-y-1.5 max-h-40 overflow-y-auto scroll-area-thin pr-1" aria-label="Активные наставничества">
          {active.map((m) => (
            <li key={m.id} className="flex items-start gap-2 text-xs p-2 rounded-lg border bg-muted/20">
              <Users className="w-3.5 h-3.5 text-lighthouse flex-shrink-0 mt-0.5" aria-hidden="true" />
              <span className="min-w-0">
                <strong>{m.mentor.name}</strong> → <strong>{m.mentee.name}</strong>
                {m.skillName ? ` · «${m.skillName}»` : ''}
                <span className="text-muted-foreground"> · с {new Date(m.startedAt).toLocaleDateString('ru-RU')}</span>
              </span>
            </li>
          ))}
        </ul>
      )}

      {recs.length > 0 && (
        <ul className="space-y-2 max-h-56 overflow-y-auto scroll-area-thin pr-1" aria-label="Рекомендуемые пары наставник-ментируемый">
          {recs.map((r) => (
            <li key={`${r.menteeId}-${r.skillName}`} className="p-2.5 rounded-lg border space-y-1.5">
              <div className="text-xs">
                <strong>{r.menteeName}</strong>
                <span className="text-muted-foreground"> — рост «{r.skillName}» с {r.currentLevel}/10 до {r.targetLevel}/10</span>
              </div>
              {r.mentors.length > 0 ? (
                <div className="space-y-1" role="list" aria-label="Кандидаты в наставники">
                  {r.mentors.map((m) => (
                    <div key={m.mentorId} className="flex items-start gap-1.5 text-xs text-foreground/80">
                      <TrendingUp className="w-3 h-3 text-success flex-shrink-0 mt-0.5" aria-hidden="true" />
                      <span>
                        <strong>{m.name}</strong>
                        {m.internal ? ' (сотрудник компании)' : ' (внешний эксперт)'} — {m.why}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                r.note && <p className="text-xs text-muted-foreground">{r.note}</p>
              )}
            </li>
          ))}
        </ul>
      )}

      {mentoring.note && active.length > 0 && recs.length === 0 && (
        <p className="text-xs text-muted-foreground">{mentoring.note}</p>
      )}
    </div>
  );
}

// ============================================================================
// === Обучение ===
// ============================================================================

function TrainingSection({ training }: { training: WorkforceOverview['training'] }) {
  const recs = training.recommendations;

  // Честный empty: каталог пуст / гэпов нет / зачислений нет — всё приходит в note
  if (recs.length === 0) {
    return (
      <div className="space-y-1">
        <SectionTitle icon={<GraduationCap className="w-3.5 h-3.5" aria-hidden="true" />}>Рекомендуемое обучение</SectionTitle>
        <p className="text-xs text-muted-foreground p-2">
          {training.note ?? 'Обучение под дефициты не требуется.'}
          {training.catalogSize > 0 && ` Курсов в каталоге: ${training.catalogSize}.`}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <SectionTitle icon={<GraduationCap className="w-3.5 h-3.5" aria-hidden="true" />}>
        Рекомендуемое обучение
        <Badge variant="secondary" className="text-xs ml-1">каталог: {training.catalogSize}</Badge>
      </SectionTitle>
      <ul className="space-y-2 max-h-56 overflow-y-auto scroll-area-thin pr-1" aria-label="Рекомендованные курсы под гэпы">
        {recs.map((r) => (
          <li key={r.skill} className="p-2.5 rounded-lg border space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-semibold">{r.skill}</span>
              <SeverityBadge severity={r.severity} />
              <span className="text-xs text-muted-foreground">
                потребность {r.need} · в команде {r.have}
              </span>
            </div>
            {r.courses.length > 0 ? (
              <div className="space-y-1">
                {r.courses.map((c) => (
                  <div key={c.id} className="text-xs p-1.5 rounded bg-muted/40">
                    <span className="font-medium">{c.title}</span>
                    <span className="text-muted-foreground"> · {c.provider}</span>
                    {c.durationHours != null && <span className="text-muted-foreground"> · {c.durationHours} ч</span>}
                    <div className="text-xs text-muted-foreground">{c.matchedBecause}</div>
                  </div>
                ))}
              </div>
            ) : (
              r.note && <p className="text-xs text-muted-foreground">{r.note}</p>
            )}
          </li>
        ))}
      </ul>
      {training.note && <p className="text-xs text-muted-foreground">{training.note}</p>}
    </div>
  );
}

// ============================================================================
// === Мелкие блоки ===
// ============================================================================

function SeverityBadge({ severity }: { severity: string }) {
  // navy + teal + amber для внимания; red не используем (кроме ошибок)
  const map: Record<string, string> = {
    critical: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
    high: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
    medium: 'bg-lighthouse/10 text-lighthouse border-lighthouse/30',
    low: 'bg-muted text-muted-foreground border-border',
  };
  const label: Record<string, string> = { critical: 'критично', high: 'высокий', medium: 'средний', low: 'низкий' };
  return (
    <Badge variant="outline" className={cn('text-xs', map[severity] ?? map.low)}>
      {label[severity] ?? severity}
    </Badge>
  );
}

function StatBlock({ label, value, tone = 'normal' }: { label: string; value: number; tone?: 'normal' | 'attention' }) {
  return (
    <div className="p-2.5 rounded-lg border bg-muted/20 text-center sm:text-left">
      <div className={cn('text-xl font-bold tabular-nums', tone === 'attention' && 'text-amber-600 dark:text-amber-400')}>
        {value}
      </div>
      <div className="text-xs text-muted-foreground leading-tight">{label}</div>
    </div>
  );
}

function SectionTitle({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
      {icon}
      {children}
    </h4>
  );
}

function ButtonLike({ onClick, disabled, children }: { onClick: () => void; disabled?: boolean; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-9 px-3"
    >
      {children}
    </button>
  );
}
