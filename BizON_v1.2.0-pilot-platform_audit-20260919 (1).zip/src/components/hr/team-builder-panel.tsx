// BizON v6.2 — Team Builder panel «Собрать команду» (doc_a §36, Task 10-b)
// ============================================================================
// Форма требований (роли + навыки, размер команды) → POST /api/team-builder/compose
// → детерминированный состав: покрытие навыков, гапы, пересечения, вероятность
// успеха и объяснение выбора (why на участника и роль).
// Кнопка «Пересобрать» повторяет ТОТ ЖЕ запрос — тот же вход даёт тот же состав
// (deterministic: true, без LLM и RNG).
// DTO приходит с persisted:false → честно показываем persistNote (сохранения в
// v6.1-sandbox нет — нет модели «Команда» в схеме).
// Секция видна ТОЛЬКО сессиям company | hr_agency (individual → null).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { UserAvatar } from '@/components/common/user-avatar';
import { cn } from '@/lib/utils';
import {
  Users, Loader2, Plus, Trash2, RotateCcw, ShieldQuestion, CircleDashed, Info, Target, CheckCircle2, Scissors,
} from 'lucide-react';
import type { ComposeResult, TeamRoleInput } from '@/lib/services/team-builder-service';
import {
  useCompanyHrSession,
  IntelCard,
  IntelEmptyState,
  IntelErrorState,
  IntelSkeleton,
  scoreToneClass,
  VERIFICATION_RU,
} from './intel-shared';

type RoleFormRow = { title: string; skills: string; count: string };

const DEFAULT_ROWS: RoleFormRow[] = [{ title: '', skills: '', count: '1' }];

export function TeamBuilderPanel() {
  const isCompanyHr = useCompanyHrSession();

  const [rows, setRows] = React.useState<RoleFormRow[]>(DEFAULT_ROWS);
  const [maxSize, setMaxSize] = React.useState('');
  const [composing, setComposing] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [result, setResult] = React.useState<ComposeResult | null>(null);
  const lastPayloadRef = React.useRef<{ roles: TeamRoleInput[]; maxSize: number | null } | null>(null);

  function updateRow(idx: number, patch: Partial<RoleFormRow>) {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  }

  function addRow() {
    if (rows.length < 6) setRows((prev) => [...prev, { title: '', skills: '', count: '1' }]);
  }

  function removeRow(idx: number) {
    setRows((prev) => (prev.length === 1 ? DEFAULT_ROWS : prev.filter((_, i) => i !== idx)));
  }

  async function compose(useForm: boolean) {
    setError(null);

    // Пересборка (useForm=false) повторяет ТОТ ЖЕ сохранённый payload —
    // детерминизм: одинаковый вход → одинаковый состав.
    const payloadFromForm = ((): { roles: TeamRoleInput[]; maxSize: number | null } | null => {
      const source = useForm ? rows : null;
      if (!source) return null;
      const roles: TeamRoleInput[] = source
        .map((r) => ({
          title: r.title.trim(),
          skills: r.skills.split(',').map((s) => s.trim()).filter(Boolean),
          count: Math.max(1, Math.min(5, Number(r.count) || 1)),
        }))
        .filter((r) => r.title.length > 0 && r.skills.length > 0);
      if (roles.length === 0) return null;
      const parsedMax = Number(maxSize);
      return { roles, maxSize: Number.isFinite(parsedMax) && parsedMax > 0 ? Math.round(parsedMax) : null };
    })();

    const payload = payloadFromForm ?? lastPayloadRef.current;
    if (!payload) {
      setError('Заполните хотя бы одну роль: название и навыки через запятую.');
      return;
    }
    if (payloadFromForm) lastPayloadRef.current = payloadFromForm;

    setComposing(true);
    try {
      const res = await api<ComposeResult>('/api/team-builder/compose', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      setResult(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Не удалось собрать команду');
    } finally {
      setComposing(false);
    }
  }

  if (!isCompanyHr) return null; // individual / нет сессии → секция скрыта

  return (
    <IntelCard
      icon={<Target className="w-4 h-4 text-lighthouse" aria-hidden="true" />}
      title="Собрать команду — Team Builder"
      subtitle="Задайте роли и навыки — алгоритм жадного назначения с локальным поиском соберёт состав с максимальным покрытием. Детерминированно: тот же вход → тот же состав."
    >
      {/* === Форма ролей === */}
      <div className="space-y-3" aria-label="Требования к команде">
        {rows.map((row, idx) => (
          <div key={idx} className="p-3 rounded-lg border space-y-2 bg-muted/20">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex-shrink-0">
                Роль {idx + 1}
              </span>
              <Input
                value={row.title}
                onChange={(e) => updateRow(idx, { title: e.target.value })}
                placeholder="Backend Engineer"
                className="h-8 text-sm"
                aria-label={`Название роли ${idx + 1}`}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => removeRow(idx)}
                aria-label={`Удалить роль ${idx + 1}`}
                className="text-muted-foreground flex-shrink-0 w-8 h-8 p-0"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_5.5rem] gap-2">
              <Input
                value={row.skills}
                onChange={(e) => updateRow(idx, { skills: e.target.value })}
                placeholder="Навыки: TypeScript:8, Node.js:7"
                className="h-8 text-sm"
                aria-label={`Навыки роли ${idx + 1}`}
              />
              <Input
                type="number"
                min={1}
                max={5}
                value={row.count}
                onChange={(e) => updateRow(idx, { count: e.target.value })}
                placeholder="Кол-во"
                className="h-8 text-sm"
                aria-label={`Сколько человек на роль ${idx + 1} (1–5)`}
              />
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-end gap-2 flex-wrap">
        <Button type="button" variant="outline" size="sm" onClick={addRow} disabled={rows.length >= 6}>
          <Plus className="w-3.5 h-3.5 mr-1" aria-hidden="true" />
          Добавить роль
        </Button>
        <div className="space-y-1">
          <label htmlFor="tb-max-size" className="text-xs text-muted-foreground">
            Макс. размер команды (необязательно)
          </label>
          <Input
            id="tb-max-size"
            type="number"
            min={1}
            value={maxSize}
            onChange={(e) => setMaxSize(e.target.value)}
            placeholder="5"
            className="h-8 text-sm w-28"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <Button onClick={() => compose(true)} disabled={composing} className="w-full sm:w-auto">
          {composing ? (
            <Loader2 className="w-4 h-4 mr-1 animate-spin" aria-hidden="true" />
          ) : (
            <Users className="w-4 h-4 mr-1" aria-hidden="true" />
          )}
          Собрать команду
        </Button>
        {result && (
          <Button onClick={() => compose(false)} disabled={composing} variant="outline" className="w-full sm:w-auto">
            <RotateCcw className="w-4 h-4 mr-1" aria-hidden="true" />
            Пересобрать
          </Button>
        )}
      </div>
      {result && (
        <p className="text-xs text-muted-foreground">
          «Пересобрать» повторяет тот же запрос — состав совпадёт (детерминизм проверяется самим алгоритмом: deterministic: {String(result.deterministic)}).
        </p>
      )}

      {error && <IntelErrorState message={error} />}

      {composing && <IntelSkeleton lines={2} />}

      {/* === Результат === */}
      {!composing && result && (
        <ComposeResultView result={result} />
      )}
    </IntelCard>
  );
}

function ComposeResultView({ result }: { result: ComposeResult }) {
  const teamEmpty = result.team.length === 0;

  if (teamEmpty && result.note) {
    return (
      <div className="space-y-2 soft-fade-in">
        <IntelEmptyState
          icon={<Users className="w-8 h-8" aria-hidden="true" />}
          title="Команда не собрана"
          note={result.note}
        />
        {result.rolesReport.map((r) => (
          <div key={r.roleTitle} className="flex items-center gap-2 text-xs text-muted-foreground">
            <CircleDashed className="w-3.5 h-3.5 flex-shrink-0" aria-hidden="true" />
            <span>
              <strong className="text-foreground/80">{r.roleTitle}</strong> — {r.why}
            </span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4 soft-fade-in" aria-label="Состав команды">
      {/* Сводка */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <SummaryStat
          label="Покрытие навыков"
          value={`${result.coverage.percent}%`}
          hint={`${result.coverage.covered} из ${result.coverage.total} (роль, навык)`}
        />
        <SummaryStat
          label="Вероятность успеха"
          value={`${result.successProbability.value}%`}
          hint="эвристика, не ML-прогноз"
        />
        <SummaryStat
          label="Состав"
          value={`${result.team.length}`}
          hint={`человек · формулa ${result.formulaVersion}`}
        />
      </div>

      {/* Прогресс покрытия */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Покрытие требуемых навыков</span>
          <span className="font-medium tabular-nums">{result.coverage.percent}%</span>
        </div>
        <Progress value={result.coverage.percent} aria-label={`Покрытие навыков ${result.coverage.percent}%`} />
      </div>

      {/* Участники */}
      <ol className="space-y-2 max-h-[26rem] overflow-y-auto scroll-area-thin pr-1" aria-label="Участники команды">
        {result.team.map((m) => (
          <li key={`${m.userId}-${m.roleTitle}`} className="p-3 rounded-lg border bg-card">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0">
                <UserAvatar name={m.name} avatarUrl={m.avatarUrl} size="sm" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium truncate">{m.name}</span>
                  <Badge variant="secondary" className="text-xs">{m.roleTitle}</Badge>
                </div>
                <div className="text-xs text-muted-foreground truncate mt-0.5">{m.title ?? '—'}</div>
                <div className="flex flex-wrap gap-1 mt-1.5" role="list" aria-label="Навыки, которые закрывает участник">
                  {m.coveredSkills.map((s) => (
                    <Badge
                      key={`${m.userId}-${s.name}`}
                      variant="outline"
                      className={cn(
                        'text-xs max-w-full',
                        s.ok ? 'bg-success/10 text-success-text border-success/30' : 'bg-muted text-muted-foreground border-border',
                      )}
                      title={`${s.name}: ${VERIFICATION_RU[s.verificationLevel] ?? s.verificationLevel}, уровень ${s.candidateLevel ?? '—'}/10 (нужно ${s.requiredLevel ?? '—'})`}
                    >
                      <span className="truncate">
                        {s.name} · {s.candidateLevel ?? '—'}/10
                      </span>
                    </Badge>
                  ))}
                </div>
                {m.why.length > 0 && (
                  <ul className="mt-1.5 space-y-0.5" aria-label="Почему выбран">
                    {m.why.map((w, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-xs text-foreground/80 leading-relaxed">
                        <CheckCircle2 className="w-3 h-3 text-lighthouse flex-shrink-0 mt-0.5" aria-hidden="true" />
                        <span>{w}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="flex-shrink-0">
                <Badge variant="outline" className={cn('text-sm font-bold tabular-nums', scoreToneClass(m.roleFit))}>
                  {m.roleFit}
                </Badge>
                <div className="text-xs text-muted-foreground mt-1 text-right">roleFit</div>
              </div>
            </div>
          </li>
        ))}
      </ol>

      {/* Отчёт по ролям */}
      <div className="space-y-1">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Роли</h4>
        {result.rolesReport.map((r) => (
          <div key={r.roleTitle} className="flex items-start gap-2 text-xs">
            <Badge
              variant="outline"
              className={cn(
                'text-xs flex-shrink-0 tabular-nums',
                r.filled >= r.requested ? 'bg-success/10 text-success-text border-success/30' : 'bg-muted text-muted-foreground border-border',
              )}
            >
              {r.filled}/{r.requested}
            </Badge>
            <span className="text-foreground/80">
              <strong>{r.roleTitle}</strong> — {r.why}
            </span>
          </div>
        ))}
      </div>

      {/* Гапы */}
      {result.gaps.length > 0 && (
        <div className="space-y-1.5">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Гапы — что не закрыто
          </h4>
          <ul className="space-y-1" aria-label="Гапы навыков">
            {result.gaps.map((g) => (
              <li key={`${g.roleTitle}-${g.skill}`} className="flex items-start gap-2 text-xs p-2 rounded-lg bg-muted/40">
                <ShieldQuestion className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" aria-hidden="true" />
                <span>
                  <strong>{g.skill}</strong>
                  {g.requiredLevel ? ` (нужно ${g.requiredLevel}/10)` : ''} · роль «{g.roleTitle}» — {g.reason}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Пересечения */}
      {result.overlaps.length > 0 && (
        <div className="space-y-1.5">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Пересечения компетенций
          </h4>
          {result.overlaps.map((o) => (
            <div key={o.skill} className="flex items-start gap-2 text-xs p-2 rounded-lg bg-muted/40">
              <Scissors className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" aria-hidden="true" />
              <span>
                «{o.skill}» закрывают несколько участников: {o.coveredBy.join(', ')}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Объяснение вероятности успеха */}
      <p className="text-xs text-muted-foreground leading-relaxed">{result.successProbability.explanation}</p>

      {/* persistNote: честное пояснение, что команда не сохраняется */}
      <div className="flex items-start gap-2 p-2.5 rounded-lg border border-dashed text-xs text-muted-foreground leading-relaxed">
        <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" aria-hidden="true" />
        <span>
          Состав возвращён как черновик (persisted: {String(result.persisted)}). {result.persistNote}
        </span>
      </div>
    </div>
  );
}

function SummaryStat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="p-3 rounded-lg border bg-muted/20">
      <div className="text-lg font-bold tabular-nums">{value}</div>
      <div className="text-xs font-medium">{label}</div>
      <div className="text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}
