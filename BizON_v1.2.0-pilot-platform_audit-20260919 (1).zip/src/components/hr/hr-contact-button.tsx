// BizON — HR Contact Button (Этап 4.2 — Privacy Shield)
// Кнопка «Связаться» для HR-агентства при просмотре профиля кандидата.
// Лимит 1 контакт/неделю от одного HR к одному кандидату (энфорсится бэкендом).
// Privacy Shield: если кандидат hrInvisible=true → кнопка disabled с тултипом.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { Briefcase, Loader2, MessageSquare, ShieldOff } from 'lucide-react';

interface HrContactButtonProps {
  candidateId: string;
  candidateName: string;
  candidateHrInvisible?: boolean;
  disabled?: boolean;
}

export function HrContactButton({
  candidateId,
  candidateName,
  candidateHrInvisible,
  disabled,
}: HrContactButtonProps) {
  const [open, setOpen] = React.useState(false);
  const [message, setMessage] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);

  // Privacy Shield: если кандидат отключил контакты от HR
  if (candidateHrInvisible) {
    return (
      <Button
        size="sm"
        variant="outline"
        disabled
        title="Кандидат отключил контакты от HR-агентств (Privacy Shield)"
        className="gap-1.5 opacity-60"
      >
        <ShieldOff className="w-3.5 h-3.5" />
        Связаться
      </Button>
    );
  }

  if (disabled) {
    return (
      <Button size="sm" variant="outline" disabled className="gap-1.5">
        <Briefcase className="w-3.5 h-3.5" />
        Связаться
      </Button>
    );
  }

  async function handleSend() {
    setSubmitting(true);
    try {
      await api('/api/hr-contacts', {
        method: 'POST',
        body: JSON.stringify({
          candidateId,
          message: message.trim() || null,
        }),
      });
      toast({
        title: 'Контакт отправлен',
        description: `Сообщение для ${candidateName} отправлено. Лимит — 1 контакт в неделю.`,
      });
      setMessage('');
      setOpen(false);
    } catch (e: any) {
      // Распространённые ошибки от бэкенда:
      // 429 — лимит 1/неделю
      // 403 — Privacy Shield / блок
      toast({
        title: e.message?.includes('Privacy Shield')
          ? 'Кандидат отключил HR-контакты'
          : e.message?.includes('лимит') || e.message?.includes('заблокир')
            ? 'Не удалось отправить'
            : 'Ошибка',
        description: e.message,
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <Button size="sm" variant="outline" onClick={() => setOpen(true)} className="gap-1.5">
        <Briefcase className="w-3.5 h-3.5" />
        Связаться
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-lighthouse" />
              Связаться с {candidateName}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-lg bg-muted/40 border border-muted p-3 text-xs text-muted-foreground flex items-start gap-2">
              <Briefcase className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-lighthouse" />
              <div>
                <p>
                  Вы инициируете контакт от имени HR-агентства. Лимит —
                  <strong className="text-foreground"> 1 контакт в неделю</strong> на одного кандидата.
                </p>
                <p className="mt-1">
                  Кандидат увидит ваше агентство и сможет ответить или заблокировать вас на 7 дней.
                </p>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-muted-foreground">
                Сообщение <span className="text-muted-foreground/60">(необязательно)</span>
              </label>
              <Textarea
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={`Здравствуйте, ${candidateName.split(' ')[0]}! У меня есть вакансия, подходящая под ваш профиль…`}
                maxLength={2000}
              />
              <div className="text-xs text-muted-foreground text-right">
                {message.length} / 2000
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Badge variant="outline" className="text-xs gap-1">
                <ShieldOff className="w-3 h-3" />
                Кандидат может заблокировать вас
              </Badge>
            </div>

            <div className="flex gap-2 pt-1">
              <Button variant="outline" onClick={() => setOpen(false)} className="flex-1">
                Отмена
              </Button>
              <Button onClick={handleSend} disabled={submitting} className="flex-1">
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Отправить'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
