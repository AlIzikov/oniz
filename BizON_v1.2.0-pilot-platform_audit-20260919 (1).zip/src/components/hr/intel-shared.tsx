// BizON v6.2 — Shared helpers для HR/Company intelligence-панелей (Task 10-b)
// ============================================================================
// Общие строительные блоки панелей «Поиск кандидатов» (Build Talent),
// «Собрать команду» (Team Builder) и «Ворота найма» (Workforce).
//
// Дизайн: navy (доверие, primary) + teal (рост, lighthouse/success).
// Красный — только для ошибок загрузки; отклонённые статусы воронки — muted.
'use client';

import * as React from 'react';
import { useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Роль сессии ===
// ============================================================================

/**
 * Возвращает true, только если сессия — company или hr_agency.
 * individual / нет сессии → false (панели скрываются, API всё равно вернёт 403).
 */
export function useCompanyHrSession(): boolean {
  const accountType = useAppStore((s) => s.user?.accountType);
  return accountType === 'company' || accountType === 'hr_agency';
}

// ============================================================================
// === Карточка-секция панели ===
// ============================================================================

export function IntelCard({
  icon,
  title,
  subtitle,
  actions,
  children,
  className,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-start justify-between gap-2 flex-wrap">
          <div className="min-w-0">
            <CardTitle className="flex items-center gap-2 text-base">
              {icon}
              <span className="min-w-0">{title}</span>
            </CardTitle>
            {subtitle && (
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{subtitle}</p>
            )}
          </div>
          {actions && <div className="flex-shrink-0 flex items-center gap-2">{actions}</div>}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">{children}</CardContent>
    </Card>
  );
}

// ============================================================================
// === Честные состояния ===
// ============================================================================

export function IntelEmptyState({
  icon,
  title,
  note,
}: {
  icon: React.ReactNode;
  title: string;
  note?: string | null;
}) {
  return (
    <div className="text-center py-6 px-2">
      <div className="flex justify-center mb-2 text-muted-foreground/50">{icon}</div>
      <p className="text-sm font-medium">{title}</p>
      {note && <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{note}</p>}
    </div>
  );
}

export function IntelErrorState({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div className="text-center py-4" role="alert">
      <p className="text-sm text-destructive">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry} className="mt-2">
          <RefreshCw className="w-3.5 h-3.5 mr-1" aria-hidden="true" />
          Повторить
        </Button>
      )}
    </div>
  );
}

export function IntelSkeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="space-y-2" aria-busy="true" aria-label="Загрузка данных">
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} className="h-12 w-full rounded-lg" />
      ))}
    </div>
  );
}

// ============================================================================
// === Чипы навыков (input с тегами) ===
// ============================================================================

export function SkillChipInput({
  skills,
  onChange,
  placeholder,
  id,
  ariaLabel,
}: {
  skills: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  id?: string;
  ariaLabel?: string;
}) {
  const [draft, setDraft] = React.useState('');

  function addFromDraft() {
    const parts = draft
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (parts.length === 0) return;
    const next = [...skills];
    for (const p of parts) {
      if (!next.some((x) => x.toLowerCase() === p.toLowerCase())) next.push(p);
    }
    onChange(next.slice(0, 12)); // разумный предел UI
    setDraft('');
  }

  return (
    <div className="space-y-2">
      <div
        className="flex flex-wrap gap-1.5 min-h-[2rem]"
        role="list"
        aria-label={ariaLabel ?? 'Требуемые навыки'}
      >
        {skills.length === 0 && (
          <span className="text-xs text-muted-foreground/70 italic py-1">Навыки не заданы</span>
        )}
        {skills.map((s) => (
          <Badge key={s} variant="secondary" className="gap-1 pr-1 max-w-full">
            <span className="truncate max-w-[14rem]">{s}</span>
            <button
              type="button"
              onClick={() => onChange(skills.filter((x) => x !== s))}
              className="rounded-full hover:bg-muted-foreground/20 w-4 h-4 flex items-center justify-center flex-shrink-0"
              aria-label={`Убрать навык ${s}`}
            >
              ×
            </button>
          </Badge>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          id={id}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ',') {
              e.preventDefault();
              addFromDraft();
            }
          }}
          onBlur={addFromDraft}
          placeholder={placeholder ?? 'Навык или «Навык:уровень» (1–10), Enter — добавить'}
          className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          aria-label={ariaLabel ?? 'Добавить навык'}
        />
      </div>
    </div>
  );
}

// ============================================================================
// === Верификация / тона ===
// ============================================================================

/** Человекочитаемая верификация навыка (шкала ProfessionalEvidence). */
export const VERIFICATION_RU: Record<string, string> = {
  expert_verified: 'подтверждён экспертом',
  project_verified: 'подтверждён проектом',
  verified: 'подтверждён',
  claimed: 'заявлен',
};

/** Тона скоринга: teal — рост/сила, muted — нейтрально. Красный не используется. */
export function scoreToneClass(score: number): string {
  if (score >= 70) return 'bg-success/10 text-success-text border-success/30';
  if (score >= 40) return 'bg-lighthouse/10 text-lighthouse border-lighthouse/30';
  return 'bg-muted text-muted-foreground border-border';
}

export function ActivityBadge({ status }: { status: string | null }) {
  if (!status) return null;
  const map: Record<string, { label: string; className: string }> = {
    fresh: { label: 'активен недавно', className: 'bg-success/10 text-success-text border-success/30' },
    stale: { label: 'навык остывает', className: 'bg-muted text-muted-foreground border-border' },
    decayed: { label: 'навык без практики', className: 'bg-muted text-muted-foreground border-border' },
  };
  const t = map[status];
  if (!t) return null;
  return (
    <Badge variant="outline" className={cn('text-xs gap-1', t.className)}>
      {t.label}
    </Badge>
  );
}

// ============================================================================
// === Утилиты ===
// ============================================================================

export function formatRelative(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (Number.isNaN(days)) return '';
  if (minutes < 1) return 'только что';
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  if (days < 7) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function Spinner({ label }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
      <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
      {label}
    </span>
  );
}
