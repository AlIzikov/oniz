// BizON — HrOrganizationDashboard (Phase 2: HR Organization)
//
// Структура:
//   ┌──────────────────────────────────────────────────────┐
//   │  ШАПКА                                                │
//   │  Название · INN · verified · specialization          │
//   │  Agency Trust (крупно, % от 0..1)                    │
//   ├──────────────────────────────────────────────────────┤
//   │  3 ТАБА: Clients / Pipeline / Recruiters             │
//   └──────────────────────────────────────────────────────┘
//
// Источники:
//   • GET /api/hr-organizations/[id]  → organization + recruiters + placements
//   • GET /api/hr-organizations/[id]/pipeline → pipeline по статусам
//
// Рендерится в HrView как опциональный блок (если у пользователя есть организация).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Building2, ShieldCheck, BadgeCheck, Users, Briefcase,
  TrendingUp, CheckCircle2, Loader2, Plus, UserPlus, Sparkles,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы данных ===
// ============================================================================

interface HrOrganizationInfo {
  id: string;
  name: string;
  inn: string | null;
  isVerified: boolean;
  verifiedAt: string | null;
  specialization: string | null;
  agencyTrust: number;
  createdAt: string;
}

interface RecruiterInfo {
  id: string;
  userId: string;
  recruiterTrust: number;
  joinedAt: string;
  user: {
    id: string;
    name: string;
    avatarUrl: string | null;
    title: string | null;
    isVerified: boolean;
  };
}

interface PlacementItem {
  id: string;
  candidateName: string;
  jobTitle: string;
  placedAt: string;
  confirmedByCandidate: boolean;
  confirmedByCompany: boolean;
  isPublic: boolean;
  hrAgency: { id: string; name: string; avatarUrl: string | null };
  company: { id: string; name: string; logoUrl: string | null; industry: string | null };
  candidate: { id: string; name: string; avatarUrl: string | null; title: string | null } | null;
}

interface OrgDetailsResponse {
  organization: HrOrganizationInfo;
  isMember: boolean;
  recruiters: RecruiterInfo[];
  placements: PlacementItem[];
}

interface PipelineResponse {
  isMember: boolean;
  counts: {
    confirmed: number;
    pendingCandidate: number;
    pendingCompany: number;
    total: number;
  };
  pipeline: {
    confirmed: PlacementItem[];
    pendingCandidate: PlacementItem[];
    pendingCompany: PlacementItem[];
  };
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function HrOrganizationDashboard({ organizationId }: { organizationId: string }) {
  const [details, setDetails] = React.useState<OrgDetailsResponse | null>(null);
  const [pipeline, setPipeline] = React.useState<PipelineResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState('clients');

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const [d, p] = await Promise.all([
        api<OrgDetailsResponse>(`/api/hr-organizations/${organizationId}`),
        api<PipelineResponse>(`/api/hr-organizations/${organizationId}/pipeline`),
      ]);
      setDetails(d);
      setPipeline(p);
    } catch (e: any) {
      console.error('[HrOrganizationDashboard] load error:', e);
    } finally {
      setLoading(false);
    }
  }, [organizationId]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading || !details) {
    return (
      <Card>
        <CardContent className="p-6 space-y-4">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  const { organization, recruiters, isMember } = details;
  const trustPercent = Math.round(organization.agencyTrust * 100);

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        {/* ============================================================ */}
        {/* ШАПКА: название, INN, verified, specialization              */}
        {/* ============================================================ */}
        <div className="p-5 sm:p-6 bg-gradient-to-br from-lighthouse/5 via-transparent to-transparent border-b">
          <div className="flex items-start gap-4 flex-wrap">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <Building2 className="w-5 h-5 text-lighthouse flex-shrink-0" />
                <h2 className="text-xl font-bold truncate">{organization.name}</h2>
                {organization.isVerified ? (
                  <Badge className="bg-emerald-600 text-white gap-1">
                    <BadgeCheck className="w-3 h-3" />
                    Верифицировано
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    На проверке
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                {organization.inn && (
                  <span>ИНН: <span className="font-mono">{organization.inn}</span></span>
                )}
                {organization.specialization && (
                  <>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      {organization.specialization}
                    </span>
                  </>
                )}
                <span>·</span>
                <span>{recruiters.length} рекрутеров</span>
              </div>
            </div>

            {/* Agency Trust — крупно */}
            <div className="flex-shrink-0 text-right">
              <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                Agency Trust
              </div>
              <div className={cn(
                'text-4xl font-extrabold tabular-nums leading-none',
                trustPercent >= 70 ? 'text-emerald-600 dark:text-emerald-400'
                  : trustPercent >= 30 ? 'text-amber-600 dark:text-amber-400'
                  : 'text-muted-foreground',
              )}>
                {trustPercent}<span className="text-lg text-muted-foreground">%</span>
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                из закрытых placements
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 3 ТАБА: Clients / Pipeline / Recruiters                     */}
        {/* ============================================================ */}
        <div className="p-4 sm:p-5">
          <Tabs value={tab} onValueChange={setTab} className="w-full">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="clients" className="gap-1.5">
                <Building2 className="w-3.5 h-3.5" />
                Клиенты
              </TabsTrigger>
              <TabsTrigger value="pipeline" className="gap-1.5">
                <Briefcase className="w-3.5 h-3.5" />
                Pipeline
              </TabsTrigger>
              <TabsTrigger value="recruiters" className="gap-1.5">
                <Users className="w-3.5 h-3.5" />
                Рекрутеры
              </TabsTrigger>
            </TabsList>

            {/* === Clients === */}
            <TabsContent value="clients" className="mt-4">
              <ClientsTab placements={details.placements} />
            </TabsContent>

            {/* === Pipeline === */}
            <TabsContent value="pipeline" className="mt-4">
              {pipeline ? (
                <PipelineTab pipeline={pipeline} />
              ) : (
                <Skeleton className="h-40 w-full" />
              )}
            </TabsContent>

            {/* === Recruiters === */}
            <TabsContent value="recruiters" className="mt-4">
              <RecruitersTab
                recruiters={recruiters}
                isMember={isMember}
                organizationId={organizationId}
                onAdded={load}
              />
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// === Clients Tab ===
// ============================================================================

function ClientsTab({ placements }: { placements: PlacementItem[] }) {
  // Уникальные клиенты (компании) из placements
  const clientsMap = React.useMemo(() => {
    const m = new Map<string, PlacementItem['company'] & { placementsCount: number }>();
    placements.forEach((p) => {
      const existing = m.get(p.company.id);
      if (existing) {
        existing.placementsCount += 1;
      } else {
        m.set(p.company.id, { ...p.company, placementsCount: 1 });
      }
    });
    return Array.from(m.values()).sort((a, b) => b.placementsCount - a.placementsCount);
  }, [placements]);

  if (clientsMap.length === 0) {
    return (
      <div className="text-center py-8">
        <Building2 className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
        <p className="text-sm text-muted-foreground">
          Список клиентов появится после добавления первого placement.
        </p>
      </div>
    );
  }

  return (
    <div className="grid sm:grid-cols-2 gap-2">
      {clientsMap.map((c) => (
        <div
          key={c.id}
          className="flex items-center gap-3 p-3 rounded-lg border hover:border-lighthouse/40 hover:bg-accent/30 transition"
        >
          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
            {c.logoUrl ? (
              <img src={c.logoUrl} alt={c.name} className="w-full h-full object-cover" />
            ) : (
              <Building2 className="w-5 h-5 text-muted-foreground" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-medium truncate">{c.name}</div>
            {c.industry && (
              <div className="text-xs text-muted-foreground truncate">{c.industry}</div>
            )}
          </div>
          <Badge variant="secondary" className="text-xs flex-shrink-0">
            {c.placementsCount}{' '}
            {c.placementsCount === 1 ? 'placement' : 'placements'}
          </Badge>
        </div>
      ))}
    </div>
  );
}

// ============================================================================
// === Pipeline Tab ===
// ============================================================================

function PipelineTab({ pipeline }: { pipeline: PipelineResponse }) {
  return (
    <div className="space-y-4">
      {/* Метрики по статусам */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <PipelineStat
          icon={<CheckCircle2 className="w-3.5 h-3.5" />}
          label="Закрыто"
          count={pipeline.counts.confirmed}
          accent="text-emerald-600 dark:text-emerald-400 bg-emerald-500/10"
        />
        <PipelineStat
          icon={<Loader2 className="w-3.5 h-3.5" />}
          label="Ждёт кандидата"
          count={pipeline.counts.pendingCandidate}
          accent="text-amber-600 dark:text-amber-400 bg-amber-500/10"
        />
        <PipelineStat
          icon={<Loader2 className="w-3.5 h-3.5" />}
          label="Ждёт компанию"
          count={pipeline.counts.pendingCompany}
          accent="text-sky-600 dark:text-sky-400 bg-sky-500/10"
        />
        <PipelineStat
          icon={<TrendingUp className="w-3.5 h-3.5" />}
          label="Всего"
          count={pipeline.counts.total}
          accent="text-lighthouse bg-lighthouse/10"
        />
      </div>

      {/* Список confirmed */}
      {pipeline.pipeline.confirmed.length > 0 && (
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-2">
            Закрытые placement'ы ({pipeline.pipeline.confirmed.length})
          </div>
          <div className="space-y-1.5">
            {pipeline.pipeline.confirmed.slice(0, 10).map((p) => (
              <PlacementRow key={p.id} placement={p} />
            ))}
          </div>
        </div>
      )}

      {pipeline.pipeline.pendingCandidate.length > 0 && (
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-2">
            Ожидают подтверждения кандидатом ({pipeline.pipeline.pendingCandidate.length})
          </div>
          <div className="space-y-1.5">
            {pipeline.pipeline.pendingCandidate.slice(0, 10).map((p) => (
              <PlacementRow key={p.id} placement={p} />
            ))}
          </div>
        </div>
      )}

      {pipeline.counts.total === 0 && (
        <div className="text-center py-8">
          <Briefcase className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
          <p className="text-sm text-muted-foreground">
            Пока нет placement'ов в pipeline.
          </p>
        </div>
      )}
    </div>
  );
}

function PipelineStat({
  icon, label, count, accent,
}: {
  icon: React.ReactNode; label: string; count: number; accent: string;
}) {
  return (
    <div className="rounded-lg border p-3">
      <div className={cn('inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wider', accent)}>
        {icon}
        {label}
      </div>
      <div className="text-2xl font-bold tabular-nums mt-1">{count}</div>
    </div>
  );
}

// ============================================================================
// === Recruiters Tab ===
// ============================================================================

function RecruitersTab({
  recruiters, isMember, organizationId, onAdded,
}: {
  recruiters: RecruiterInfo[];
  isMember: boolean;
  organizationId: string;
  onAdded: () => void;
}) {
  const [addOpen, setAddOpen] = React.useState(false);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          Рекрутеры организации. Их закрытые placements формируют Agency Trust.
        </p>
        {isMember && (
          <Button size="sm" variant="outline" onClick={() => setAddOpen(true)}>
            <UserPlus className="w-3.5 h-3.5 mr-1" />
            Добавить
          </Button>
        )}
      </div>

      {recruiters.length === 0 ? (
        <div className="text-center py-6">
          <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
          <p className="text-sm text-muted-foreground">Рекрутеры ещё не добавлены.</p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {recruiters.map((r) => {
            const trustPercent = Math.round(r.recruiterTrust * 100);
            return (
              <div
                key={r.id}
                className="flex items-center gap-3 p-3 rounded-lg border hover:bg-accent/30 transition"
              >
                <UserAvatar
                  name={r.user.name}
                  avatarUrl={r.user.avatarUrl}
                  size="sm"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-medium truncate">{r.user.name}</span>
                    {r.user.isVerified && (
                      <BadgeCheck className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                    )}
                  </div>
                  {r.user.title && (
                    <div className="text-xs text-muted-foreground truncate">{r.user.title}</div>
                  )}
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-xs text-muted-foreground uppercase">Recruiter Trust</div>
                  <div className={cn(
                    'text-sm font-bold tabular-nums',
                    trustPercent >= 70 ? 'text-emerald-600 dark:text-emerald-400'
                      : trustPercent >= 30 ? 'text-amber-600 dark:text-amber-400'
                      : 'text-muted-foreground',
                  )}>
                    {trustPercent}%
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {addOpen && (
        <AddRecruiterDialog
          organizationId={organizationId}
          onClose={() => setAddOpen(false)}
          onAdded={() => {
            setAddOpen(false);
            onAdded();
          }}
        />
      )}
    </div>
  );
}

// ============================================================================
// === Добавление рекрутера ===
// ============================================================================

function AddRecruiterDialog({
  organizationId, onClose, onAdded,
}: {
  organizationId: string;
  onClose: () => void;
  onAdded: () => void;
}) {
  const [userId, setUserId] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);

  async function handleSubmit() {
    if (!userId.trim()) {
      toast({ title: 'Укажите ID пользователя', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      await api(`/api/hr-organizations/${organizationId}/recruiters`, {
        method: 'POST',
        body: JSON.stringify({ userId: userId.trim() }),
      });
      toast({ title: 'Рекрутер добавлен' });
      setUserId('');
      onAdded();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="bg-background border rounded-lg shadow-lg w-full max-w-md p-5 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h3 className="text-base font-semibold flex items-center gap-2">
            <UserPlus className="w-4 h-4 text-lighthouse" />
            Добавить рекрутера
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            Введите ID пользователя (accountType=hr_agency). Он получит уведомление.
          </p>
        </div>

        <div className="space-y-1">
          <Label htmlFor="recruiter-user-id">ID пользователя</Label>
          <Input
            id="recruiter-user-id"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="cus_..."
          />
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>Отмена</Button>
          <Button size="sm" onClick={handleSubmit} disabled={submitting}>
            {submitting ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> : <Plus className="w-3.5 h-3.5 mr-1" />}
            Добавить
          </Button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// === Строка placement'а (используется в Pipeline tab) ===
// ============================================================================

function PlacementRow({ placement }: { placement: PlacementItem }) {
  const fullyConfirmed = placement.confirmedByCandidate && placement.confirmedByCompany;

  return (
    <div className="flex items-start gap-3 p-2.5 rounded-lg border bg-card hover:bg-accent/30 transition">
      <div className="flex-shrink-0 mt-0.5">
        <UserAvatar
          name={placement.candidateName}
          avatarUrl={placement.candidate?.avatarUrl ?? null}
          size="sm"
        />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium truncate">{placement.candidateName}</div>
        <div className="text-xs text-foreground/80 truncate">{placement.jobTitle}</div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5 flex-wrap">
          <span className="flex items-center gap-1">
            <Building2 className="w-3 h-3" />
            {placement.company.name}
          </span>
          <span>·</span>
          <span>{new Date(placement.placedAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}</span>
        </div>
      </div>
      <div className="flex-shrink-0">
        {fullyConfirmed ? (
          <Badge className="bg-emerald-600 text-white gap-1 text-xs">
            <CheckCircle2 className="w-2.5 h-2.5" />
            Закрыт
          </Badge>
        ) : (
          <Badge variant="outline" className="text-amber-600 border-amber-600/40 gap-1 text-xs">
            <Loader2 className="w-2.5 h-2.5" />
            В работе
          </Badge>
        )}
      </div>
    </div>
  );
}
