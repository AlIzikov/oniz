// BizON — HR View (для accountType='hr_agency')
// Этап 4.2 — HR Persona + Privacy Shield.
// Содержит:
//   • СПЕЦИАЛИЗАЦИЯ — теги (IT / Product / Data / Design)
//   • PLACEMENT PORTFOLIO — список placements с confirmed бейджами
//   • КЛИЕНТЫ — список companies (уникальные компании из placements)
//   • ОТЗЫВЫ КАНДИДАТОВ — пока заглушка (placeholder)
//
// Рендерится в ProfileView для hr_agency при просмотре собственного профиля.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Briefcase, Building2, CheckCircle2, Plus, Loader2, MessageSquare,
  ShieldCheck, Sparkles, TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { HrOrganizationDashboard } from './hr-organization-dashboard';
import { BuildTalentPanel } from './build-talent-panel';
import { TeamBuilderPanel } from './team-builder-panel';
import { WorkforceGatesPanel } from './workforce-gates-panel';

// === Доступные специализации ===
const SPECIALIZATIONS = ['IT', 'Product', 'Data', 'Design', 'Finance', 'Marketing', 'Sales', 'Operations'] as const;

interface Placement {
  id: string;
  candidateName: string;
  jobTitle: string;
  placedAt: string;
  confirmedByCandidate: boolean;
  confirmedByCompany: boolean;
  isPublic: boolean;
  hrAgency: { id: string; name: string; avatarUrl: string | null; title: string | null };
  company: { id: string; name: string; logoUrl: string | null; industry: string | null };
  candidate: { id: string; name: string; avatarUrl: string | null; title: string | null } | null;
}

interface CompanyLite {
  id: string;
  name: string;
  logoUrl: string | null;
  industry: string | null;
}

export function HrView() {
  const { user, setView, setSelectedCompanyId } = useAppStore();
  const [placements, setPlacements] = React.useState<Placement[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [createOpen, setCreateOpen] = React.useState(false);

  // Специализации хранятся в localStorage (т.к. это настройки HR)
  // Можно расширить через user.roles в будущем
  const [specs, setSpecs] = React.useState<string[]>([]);
  const [specsLoaded, setSpecsLoaded] = React.useState(false);

  // Загрузка специализаций
  React.useEffect(() => {
    if (!user) return;
    try {
      const stored = localStorage.getItem(`bizon_hr_specs_${user.id}`);
      setSpecs(stored ? JSON.parse(stored) : []);
    } catch {
      setSpecs([]);
    }
    setSpecsLoaded(true);
  }, [user?.id]);

  function toggleSpec(s: string) {
    setSpecs((prev) => {
      const next = prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s];
      if (user) {
        localStorage.setItem(`bizon_hr_specs_${user.id}`, JSON.stringify(next));
      }
      return next;
    });
  }

  const load = React.useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await api<{ placements: Placement[] }>('/api/placements');
      setPlacements(res.placements);
    } catch (e: any) {
      // Тихая ошибка — не прерываем рендеринг страницы
      console.error('[HrView] load error:', e);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (!user) return null;

  // Уникальные клиенты (компании) из placements
  const clientsMap = new Map<string, CompanyLite>();
  placements.forEach((p) => {
    if (!clientsMap.has(p.company.id)) {
      clientsMap.set(p.company.id, p.company);
    }
  });
  const clients = Array.from(clientsMap.values());

  // Метрики
  const confirmedCount = placements.filter(
    (p) => p.confirmedByCandidate && p.confirmedByCompany,
  ).length;
  const pendingCount = placements.length - confirmedCount;

  return (
    <>
      {/* === PHASE 2: HR Organization Dashboard (если у пользователя есть организация) === */}
      <HrOrganizationSection />

      {/* === INTELLIGENCE: Build Talent + Team Builder + Workforce (doc_a §34/§35/§36, Task 10-b) ===
          Панели сами проверяют роль сессии: company/hr_agency — видят,
          individual — секции скрыты. HrView рендерится только для hr_agency. === */}
      <section aria-label="Intelligence найма: поиск кандидатов, сборка команды, ворота найма" className="space-y-4">
        <BuildTalentPanel />
        <TeamBuilderPanel />
        <WorkforceGatesPanel />
      </section>

      {/* === СПЕЦИАЛИЗАЦИЯ === */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Sparkles className="w-4 h-4 text-lighthouse" />
            Специализация
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Отметьте отрасли, в которых вы специализируетесь. Это поможет кандидатам и работодателям найти вас.
          </p>
          {specsLoaded && (
            <div className="flex flex-wrap gap-2">
              {SPECIALIZATIONS.map((s) => {
                const active = specs.includes(s);
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggleSpec(s)}
                    className={cn(
                      'px-3 py-1.5 rounded-full border-2 text-sm font-medium transition',
                      active
                        ? 'border-lighthouse bg-lighthouse/10 text-lighthouse'
                        : 'border-border text-muted-foreground hover:border-lighthouse/50 hover:text-foreground',
                    )}
                  >
                    {s}
                  </button>
                );
              })}
            </div>
          )}
          {specs.length === 0 && specsLoaded && (
            <p className="text-xs text-muted-foreground/70 italic">
              Не выбрано ни одной специализации
            </p>
          )}
        </CardContent>
      </Card>

      {/* === PLACEMENT PORTFOLIO === */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <CardTitle className="flex items-center gap-2 text-base">
              <Briefcase className="w-4 h-4 text-primary" />
              Placement Portfolio
            </CardTitle>
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="w-3.5 h-3.5 mr-1" /> Добавить placement
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Метрики */}
          <div className="flex items-center gap-4 mb-4 text-sm">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span className="font-medium">{confirmedCount}</span>
              <span className="text-muted-foreground">подтверждено</span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-1.5">
              <Loader2 className="w-4 h-4 text-amber-500" />
              <span className="font-medium">{pendingCount}</span>
              <span className="text-muted-foreground">ожидает подтверждения</span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-lighthouse" />
              <span className="font-medium">{placements.length}</span>
              <span className="text-muted-foreground">всего</span>
            </div>
          </div>

          {loading ? (
            <div className="space-y-2">
              <Skeleton className="h-16 w-full rounded-lg" />
              <Skeleton className="h-16 w-full rounded-lg" />
            </div>
          ) : placements.length === 0 ? (
            <div className="text-center py-8">
              <Briefcase className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
              <p className="text-sm text-muted-foreground">
                Пока нет placement'ов. Добавьте первый — зафиксируйте факт трудоустройства кандидата.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {placements.map((p) => (
                <PlacementRow key={p.id} placement={p} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* === КЛИЕНТЫ === */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Building2 className="w-4 h-4 text-primary" />
            Клиенты
            {clients.length > 0 && (
              <Badge variant="secondary" className="ml-1">{clients.length}</Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {clients.length === 0 ? (
            <div className="text-center py-6">
              <Building2 className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
              <p className="text-sm text-muted-foreground">
                Список компаний-клиентов появится после добавления первого placement'а.
              </p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-2">
              {clients.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    if (setSelectedCompanyId) setSelectedCompanyId(c.id);
                    setView('company');
                  }}
                  className="flex items-center gap-3 p-3 rounded-lg border hover:border-primary/50 hover:bg-accent transition text-left"
                >
                  <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                    {c.logoUrl ? (
                      <img src={c.logoUrl} alt={c.name} className="w-full h-full object-cover" />
                    ) : (
                      <Building2 className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium truncate">{c.name}</div>
                    {c.industry && (
                      <div className="text-xs text-muted-foreground truncate">{c.industry}</div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* === Диалог: создать placement === */}
      <CreatePlacementDialog
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreated={() => {
          setCreateOpen(false);
          load();
        }}
      />
    </>
  );
}

// === Строка списка placements ===
function PlacementRow({ placement }: { placement: Placement }) {
  const fullyConfirmed = placement.confirmedByCandidate && placement.confirmedByCompany;
  const partialConfirmed = placement.confirmedByCandidate || placement.confirmedByCompany;

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/30 transition">
      {/* Аватар кандидата */}
      <div className="flex-shrink-0 mt-0.5">
        <UserAvatar
          name={placement.candidateName}
          avatarUrl={placement.candidate?.avatarUrl ?? null}
          size="sm"
        />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm font-medium truncate">{placement.candidateName}</span>
          {placement.candidate && (
            <Badge variant="outline" className="text-xs text-muted-foreground">
              верифицирован
            </Badge>
          )}
          {!placement.candidate && (
            <Badge variant="outline" className="text-xs text-muted-foreground">
              аноним
            </Badge>
          )}
        </div>
        <div className="text-sm text-foreground/80 mt-0.5">
          {placement.jobTitle}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 flex-wrap">
          <span className="flex items-center gap-1">
            <Building2 className="w-3 h-3" />
            {placement.company.name}
          </span>
          <span>·</span>
          <span>{new Date(placement.placedAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
        </div>
      </div>

      {/* Статус подтверждения */}
      <div className="flex-shrink-0 flex flex-col items-end gap-1">
        {fullyConfirmed ? (
          <Badge className="bg-emerald-600 text-white gap-1 text-xs">
            <CheckCircle2 className="w-3 h-3" />
            Подтверждён
          </Badge>
        ) : partialConfirmed ? (
          <Badge variant="outline" className="text-amber-600 border-amber-600/40 gap-1 text-xs">
            <Loader2 className="w-3 h-3" />
            Частично
          </Badge>
        ) : (
          <Badge variant="outline" className="text-muted-foreground text-xs">
            Ожидает
          </Badge>
        )}
        {!placement.isPublic && (
          <Badge variant="secondary" className="text-xs">приватный</Badge>
        )}
      </div>
    </div>
  );
}

// === Диалог: создать placement ===
function CreatePlacementDialog({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}) {
  const [jobTitle, setJobTitle] = React.useState('');
  const [companyId, setCompanyId] = React.useState('');
  const [companies, setCompanies] = React.useState<CompanyLite[]>([]);
  const [loadingCompanies, setLoadingCompanies] = React.useState(false);
  const [isAnonymous, setIsAnonymous] = React.useState(false);
  const [candidateId, setCandidateId] = React.useState('');
  const [candidateName, setCandidateName] = React.useState('');
  const [isPublic, setIsPublic] = React.useState(true);
  const [submitting, setSubmitting] = React.useState(false);

  // Загружаем список компаний для select
  React.useEffect(() => {
    if (!open) return;
    setLoadingCompanies(true);
    api<{ companies: CompanyLite[] }>('/api/companies?limit=50')
      .then((res) => setCompanies(res.companies))
      .catch(() => setCompanies([]))
      .finally(() => setLoadingCompanies(false));
  }, [open]);

  function reset() {
    setJobTitle('');
    setCompanyId('');
    setIsAnonymous(false);
    setCandidateId('');
    setCandidateName('');
    setIsPublic(true);
  }

  async function handleSubmit() {
    if (!jobTitle.trim() || !companyId) {
      toast({ title: 'Заполните должность и выберите компанию', variant: 'destructive' });
      return;
    }
    if (!isAnonymous && !candidateId.trim()) {
      toast({ title: 'Укажите ID кандидата или выберите анонимный placement', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      await api('/api/placements', {
        method: 'POST',
        body: JSON.stringify({
          candidateId: isAnonymous ? null : candidateId.trim() || null,
          candidateName: isAnonymous ? candidateName.trim() || null : null,
          companyId,
          jobTitle: jobTitle.trim(),
          isPublic,
        }),
      });
      toast({ title: 'Placement добавлен' });
      reset();
      onCreated();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Добавить placement</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Должность</Label>
            <Input
              value={jobTitle}
              onChange={(e) => setJobTitle(e.target.value)}
              placeholder="Senior ML Engineer"
            />
          </div>

          <div className="space-y-1">
            <Label>Компания-работодатель</Label>
            {loadingCompanies ? (
              <Skeleton className="h-9 w-full" />
            ) : (
              <select
                value={companyId}
                onChange={(e) => setCompanyId(e.target.value)}
                className="w-full p-2 border rounded-md bg-background text-sm"
              >
                <option value="">Выберите компанию…</option>
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}{c.industry ? ` · ${c.industry}` : ''}
                  </option>
                ))}
              </select>
            )}
            <p className="text-xs text-muted-foreground">
              Нет нужной компании в списке? Зарегистрируйте её как аккаунт-юр.лицо.
            </p>
          </div>

          <Separator />

          <div className="flex items-center gap-2">
            <Checkbox
              id="anon-placement"
              checked={isAnonymous}
              onCheckedChange={(v) => setIsAnonymous(!!v)}
            />
            <Label htmlFor="anon-placement" className="text-sm font-normal cursor-pointer">
              Анонимный placement (без указания кандидата)
            </Label>
          </div>

          {!isAnonymous ? (
            <div className="space-y-1">
              <Label>ID кандидата</Label>
              <Input
                value={candidateId}
                onChange={(e) => setCandidateId(e.target.value)}
                placeholder="cuid пользователя (можно скопировать из URL профиля)"
              />
              <p className="text-xs text-muted-foreground">
                Кандидат получит уведомление и сможет подтвердить placement.
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <Label>Имя кандидата <span className="text-muted-foreground">(необязательно)</span></Label>
              <Input
                value={candidateName}
                onChange={(e) => setCandidateName(e.target.value)}
                placeholder='По умолчанию: «Кандидат N»'
              />
            </div>
          )}

          <div className="flex items-center gap-2">
            <Checkbox
              id="public-placement"
              checked={isPublic}
              onCheckedChange={(v) => setIsPublic(!!v)}
            />
            <Label htmlFor="public-placement" className="text-sm font-normal cursor-pointer">
              Публичный (виден в портфолио)
            </Label>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Отмена
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !jobTitle.trim() || !companyId}
              className="flex-1"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Создать'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// === Phase 2: HR Organization Section — обёртка с подгрузкой organization ID ===
// Если у пользователя нет организации — показывает CTA «Создать организацию».
// Если есть — рендерит HrOrganizationDashboard.
// ============================================================================
function HrOrganizationSection() {
  const { user } = useAppStore();
  const [orgId, setOrgId] = React.useState<string | null | undefined>(undefined); // undefined = loading
  const [createOpen, setCreateOpen] = React.useState(false);
  const [creating, setCreating] = React.useState(false);
  const [form, setForm] = React.useState({ name: '', inn: '', specialization: '' });

  const load = React.useCallback(async () => {
    if (!user) return;
    try {
      const res = await api<{ organization: { id: string } | null }>('/api/hr-organizations');
      setOrgId(res.organization?.id ?? null);
    } catch {
      setOrgId(null);
    }
  }, [user?.id]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (orgId === undefined) {
    return <Skeleton className="h-32 w-full rounded-lg" />;
  }

  if (orgId === null) {
    // У пользователя нет организации — показываем CTA
    return (
      <Card className="border-dashed">
        <CardContent className="p-5">
          <div className="flex items-start gap-3 flex-wrap">
            <div className="w-10 h-10 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
              <Building2 className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold">Создать HR-организацию</div>
              <p className="text-xs text-muted-foreground mt-0.5">
                Объедините команду рекрутеров. Agency Trust рассчитывается из закрытых placements всех участников.
              </p>
            </div>
            <Button size="sm" onClick={() => setCreateOpen(true)}>
              <Plus className="w-3.5 h-3.5 mr-1" />
              Создать
            </Button>
          </div>

          {createOpen && (
            <div className="mt-4 pt-4 border-t space-y-3">
              <div className="space-y-1">
                <Label>Название организации *</Label>
                <Input
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="ООО «Рекрут-Про»"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label>ИНН</Label>
                  <Input
                    value={form.inn}
                    onChange={(e) => setForm((f) => ({ ...f, inn: e.target.value }))}
                    placeholder="7701234567"
                  />
                </div>
                <div className="space-y-1">
                  <Label>Специализация</Label>
                  <Input
                    value={form.specialization}
                    onChange={(e) => setForm((f) => ({ ...f, specialization: e.target.value }))}
                    placeholder="IT, Product"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => setCreateOpen(false)}>Отмена</Button>
                <Button
                  size="sm"
                  disabled={creating || !form.name.trim()}
                  onClick={async () => {
                    setCreating(true);
                    try {
                      await api('/api/hr-organizations', {
                        method: 'POST',
                        body: JSON.stringify({
                          name: form.name.trim(),
                          inn: form.inn.trim() || null,
                          specialization: form.specialization.trim() || null,
                        }),
                      });
                      toast({ title: 'Организация создана' });
                      setCreateOpen(false);
                      setForm({ name: '', inn: '', specialization: '' });
                      load();
                    } catch (e: any) {
                      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
                    } finally {
                      setCreating(false);
                    }
                  }}
                >
                  {creating ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> : null}
                  Создать
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return <HrOrganizationDashboard organizationId={orgId} />;
}

