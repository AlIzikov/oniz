// BizON v6.2 — Build Talent panel «Поиск кандидатов» (doc_a §34, Task 10-b)
// ============================================================================
// HR-дашборд: talent pool по набору навыков (чипы) или по вакансии компании.
//   • GET /api/build-talent/candidates?skills=CSV | ?jobId=...  (Task 9-g)
//   • Каждый кандидат — ранг, скор 0..100, explainable «why» (2–3 причины),
//     верификация навыков и честные matched/missing.
// Секция видна ТОЛЬКО сессиям company | hr_agency (individual → null).
// Дизайн: navy + teal; red — только ошибки; никакой выдумки (note из API).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import {
  CheckCircle2, Search, Users, Loader2, Sparkles, BriefcaseBusiness, MinusCircle, Info,
} from 'lucide-react';
import type { TalentPoolResult, TalentCandidate } from '@/lib/services/build-talent-service';
import {
  useCompanyHrSession,
  IntelCard,
  IntelEmptyState,
  IntelErrorState,
  IntelSkeleton,
  SkillChipInput,
  scoreToneClass,
  ActivityBadge,
  VERIFICATION_RU,
} from './intel-shared';

type OwnJob = { id: string; title: string; requiredSkills: string[]; active: boolean };

export function BuildTalentPanel() {
  const isCompanyHr = useCompanyHrSession();

  // Вакансии компании (GET /api/jobs для company/hr отдаёт свои вакансии)
  const [jobs, setJobs] = React.useState<OwnJob[] | null>(null);
  const [jobsError, setJobsError] = React.useState<string | null>(null);

  // Форма поиска
  const [mode, setMode] = React.useState<'skills' | 'job'>('skills');
  const [skills, setSkills] = React.useState<string[]>([]);
  const [jobId, setJobId] = React.useState<string>('');

  // Результаты
  const [result, setResult] = React.useState<TalentPoolResult | null>(null);
  const [searching, setSearching] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!isCompanyHr) return;
    let cancelled = false;
    api<{ jobs: OwnJob[] }>('/api/jobs')
      .then((res) => {
        if (!cancelled) setJobs(res.jobs);
      })
      .catch((e: unknown) => {
        if (!cancelled) setJobsError(e instanceof Error ? e.message : 'Не удалось загрузить вакансии');
      });
    return () => {
      cancelled = true;
    };
  }, [isCompanyHr]);

  function pickJob(id: string) {
    setJobId(id);
    const job = jobs?.find((j) => j.id === id);
    if (job) {
      // Префилл чипов из вакансии (токены могут содержать «Навык:уровень» — API понимает)
      setSkills(job.requiredSkills.slice(0, 12));
    }
  }

  async function handleSearch() {
    setError(null);
    setResult(null);
    const cleanSkills = skills.map((s) => s.trim()).filter(Boolean);
    if (mode === 'skills' && cleanSkills.length === 0) {
      setError('Добавьте хотя бы один навык (например «TypeScript:8» или «Python»).');
      return;
    }
    if (mode === 'job' && !jobId) {
      setError('Выберите вакансию компании или переключитесь в режим «По навыкам».');
      return;
    }
    setSearching(true);
    try {
      const query =
        mode === 'job'
          ? `jobId=${encodeURIComponent(jobId)}`
          : `skills=${encodeURIComponent(cleanSkills.join(','))}`;
      const res = await api<TalentPoolResult>(`/api/build-talent/candidates?${query}&limit=25`);
      setResult(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Не удалось загрузить talent pool');
    } finally {
      setSearching(false);
    }
  }

  if (!isCompanyHr) return null; // individual / нет сессии → секция скрыта

  return (
    <IntelCard
      icon={<Users className="w-4 h-4 text-lighthouse" aria-hidden="true" />}
      title="Поиск кандидатов — Build Talent"
      subtitle={`Кто уже есть на платформе под ваши требования: ранжирование score = 0.55×навыки + 0.25×trust + 0.20×активность, без LLM. Контакты не передаются — только публичные поля профиля.`}
    >
      {/* === Режим поиска === */}
      <div className="flex gap-2" role="tablist" aria-label="Режим поиска кандидатов">
        <ModeButton active={mode === 'skills'} onClick={() => setMode('skills')}>
          По навыкам
        </ModeButton>
        <ModeButton active={mode === 'job'} onClick={() => setMode('job')}>
          По вакансии
        </ModeButton>
      </div>

      {mode === 'skills' && (
        <div className="space-y-2">
          <Label htmlFor="bt-skills-input">Требуемые навыки</Label>
          <SkillChipInput
            id="bt-skills-input"
            skills={skills}
            onChange={setSkills}
            placeholder="TypeScript:8, Python, Docker — Enter или запятая"
            ariaLabel="Требуемые навыки для поиска кандидатов"
          />
        </div>
      )}

      {mode === 'job' && (
        <div className="space-y-2">
          <Label htmlFor="bt-job-select">Вакансия компании</Label>
          {jobs === null && !jobsError ? (
            <div className="h-9 rounded-md bg-muted animate-pulse" aria-hidden="true" />
          ) : jobsError ? (
            <p className="text-xs text-destructive">{jobsError}</p>
          ) : (jobs?.length ?? 0) === 0 ? (
            <p className="text-xs text-muted-foreground">
              У вас ещё нет вакансий — создайте вакансию в панели выше и вернитесь, либо ищите по навыкам.
            </p>
          ) : (
            <select
              id="bt-job-select"
              value={jobId}
              onChange={(e) => pickJob(e.target.value)}
              className="w-full p-2 border rounded-md bg-background text-sm"
              aria-label="Выберите вакансию для подбора"
            >
              <option value="">Выберите вакансию…</option>
              {jobs?.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.title}
                  {j.active ? '' : ' (закрыта)'}
                </option>
              ))}
            </select>
          )}
          {jobId && (
            <p className="text-xs text-muted-foreground">
              Навыки вакансии подставлены ниже — при необходимости уберите лишние.
            </p>
          )}
          <SkillChipInput
            skills={skills}
            onChange={setSkills}
            placeholder="Корректировка навыков (необязательно)"
            ariaLabel="Корректировка требуемых навыков"
          />
        </div>
      )}

      <div className="flex items-center gap-3 flex-wrap">
        <Button onClick={handleSearch} disabled={searching} className="w-full sm:w-auto">
          {searching ? (
            <Loader2 className="w-4 h-4 mr-1 animate-spin" aria-hidden="true" />
          ) : (
            <Search className="w-4 h-4 mr-1" aria-hidden="true" />
          )}
          Найти кандидатов
        </Button>
        {result && (
          <span className="text-xs text-muted-foreground">
            Формула: {result.formulaVersion} · найдено {result.totalCandidates}
          </span>
        )}
      </div>

      {error && <IntelErrorState message={error} />}

      {/* === Результаты === */}
      {searching && <IntelSkeleton lines={3} />}

      {!searching && result && result.totalCandidates === 0 && (
        <IntelEmptyState
          icon={<Users className="w-8 h-8" aria-hidden="true" />}
          title="Кандидатов с такими навыками пока нет"
          note={result.note ?? 'Попробуйте смежные навыки или снизьте требуемый уровень.'}
        />
      )}

      {!searching && result && result.totalCandidates > 0 && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 flex-shrink-0" aria-hidden="true" />
            {result.privacy.note}
          </p>
          <ol className="space-y-2 max-h-[28rem] overflow-y-auto scroll-area-thin pr-1" aria-label="Ранжированный список кандидатов">
            {result.candidates.map((c, i) => (
              <CandidateRow key={c.userId} candidate={c} rank={i + 1} />
            ))}
          </ol>
        </div>
      )}
    </IntelCard>
  );
}

function ModeButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={cn(
        'px-3 py-1.5 rounded-full border-2 text-sm font-medium transition',
        active
          ? 'border-lighthouse bg-lighthouse/10 text-lighthouse'
          : 'border-border text-muted-foreground hover:border-lighthouse/50 hover:text-foreground',
      )}
    >
      {children}
    </button>
  );
}

function CandidateRow({ candidate: c, rank }: { candidate: TalentCandidate; rank: number }) {
  return (
    <li className="p-3 rounded-lg border bg-card hover:bg-accent/30 transition soft-fade-in">
      <div className="flex items-start gap-3">
        {/* Ранг */}
        <div
          className="flex-shrink-0 w-7 h-7 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center"
          aria-label={`Ранг ${rank}`}
        >
          {rank}
        </div>
        <div className="flex-shrink-0">
          <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-medium truncate">{c.name}</span>
            <TrustBadge ipScore={c.ipScore} level={c.level} size="sm" />
            {c.trust && (
              <Badge variant="outline" className="text-xs text-lighthouse border-lighthouse/40">
                Trust {c.trust.score}/100
              </Badge>
            )}
            <ActivityBadge status={c.activity?.status ?? null} />
          </div>
          <div className="text-xs text-muted-foreground truncate mt-0.5">
            {c.title ?? '—'}
            {c.location ? ` · ${c.location}` : ''}
          </div>

          {/* Совпавшие навыки */}
          {c.matchedSkills.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5" role="list" aria-label="Совпавшие навыки">
              {c.matchedSkills.map((m) => (
                <Badge
                  key={m.name}
                  variant="outline"
                  className={cn(
                    'text-xs gap-1 max-w-full',
                    m.ok ? 'bg-success/10 text-success-text border-success/30' : 'bg-muted text-muted-foreground border-border',
                  )}
                  title={
                    m.ok
                      ? `${m.name}: ${VERIFICATION_RU[m.verificationLevel] ?? m.verificationLevel}, уровень ${m.candidateLevel ?? '—'}/10`
                      : `Уровень ${m.candidateLevel ?? 0}/10 ниже требуемого ${m.requiredLevel ?? '—'}`
                  }
                >
                  {m.ok ? (
                    <CheckCircle2 className="w-3 h-3 flex-shrink-0" aria-hidden="true" />
                  ) : (
                    <MinusCircle className="w-3 h-3 flex-shrink-0" aria-hidden="true" />
                  )}
                  <span className="truncate">
                    {m.name} · {m.candidateLevel ?? '—'}/10
                  </span>
                </Badge>
              ))}
            </div>
          )}

          {/* Незакрытые навыки */}
          {c.missingSkills.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1" role="list" aria-label="Незакрытые навыки">
              {c.missingSkills.map((s) => (
                <Badge key={s} variant="outline" className="text-xs text-muted-foreground/80 border-dashed">
                  нет: {s}
                </Badge>
              ))}
            </div>
          )}

          {/* Explainable why */}
          {c.why.length > 0 && (
            <ul className="mt-1.5 space-y-0.5" aria-label="Почему подходит">
              {c.why.map((w, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs text-foreground/80 leading-relaxed">
                  <Sparkles className="w-3 h-3 text-lighthouse flex-shrink-0 mt-0.5" aria-hidden="true" />
                  <span>{w}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Скор */}
        <div className="flex-shrink-0 text-right">
          <Badge variant="outline" className={cn('text-sm font-bold tabular-nums', scoreToneClass(c.score))}>
            {c.score}
          </Badge>
          <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1 justify-end">
            <BriefcaseBusiness className="w-3 h-3" aria-hidden="true" />
            match
          </div>
        </div>
      </div>
    </li>
  );
}
