// BizON — Career Scenario Card (P1: «Что если получить навык X»)
// Поле ввода → POST /api/me/career-scenario { skillName }
// Результат: «Откроется N новых возможностей. Роли: A → B. Зарплата: +M%»
// Кнопка «Начать развитие» → переход к Mentor или EDU
// Task 10-d: тип и trade-off-утилиты — из career-simulator/scenario-shared.ts
// (единый контракт с Career Simulator в AI-Career-Agent); trade-off «остаться
// vs освоить» строится из метрик ответа; дисклеймер «эвристическая модель»;
// палитра приведена к navy+teal (lighthouse), без violet.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles,
  Loader2,
  ArrowRight,
  TrendingUp,
  Briefcase,
  Wallet,
  Clock,
  GraduationCap,
  Users,
  AlertCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
// Волна 14: paywall люменов (Free: 1 люмен за сценарий)
import { LumenPaywallDialog, extractLumenNeed } from '@/components/common/lumen-paywall';
import {
  type CareerScenarioResponse,
  buildTradeOff,
  formatMoney,
  SCENARIO_DISCLAIMER,
} from '@/components/career-simulator/scenario-shared';

// === Популярные навыки-подсказки (для быстрых пресетов) ===
const POPULAR_SKILLS = [
  'TypeScript', 'Python', 'React', 'System Design',
  'Machine Learning', 'Product Management', 'Kubernetes', 'Figma',
];

export function CareerScenarioCard({ className }: { className?: string }) {
  const setView = useAppStore((s) => s.setView);
  const user = useAppStore((s) => s.user);
  const isFree = user?.subscriptionTier === 'free';
  // Волна 14: paywall — открывается при 402 (не хватает люменов)
  const [paywall, setPaywall] = React.useState<{ need: number; have: number } | null>(null);
  const [skillName, setSkillName] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState<CareerScenarioResponse | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  // Последний запрошенный навык — для повтора после пополнения (волна 14)
  const lastSkillRef = React.useRef<string>('');

  /** Общая обработка ошибок обоих путей запуска (форма + пресеты) */
  function handleScenarioError(e: any, fallbackSkill: string) {
    // Волна 14: 402 — не хватает люменов → диалог пополнения (после — повтор)
    const lumenNeed = extractLumenNeed(e);
    if (lumenNeed) {
      setPaywall(lumenNeed);
      lastSkillRef.current = fallbackSkill;
      return;
    }
    setError(e?.message ?? 'Не удалось построить сценарий');
    toast({
      title: 'Не удалось построить сценарий',
      description: e?.message,
      variant: 'destructive',
    });
  }

  async function handleSimulate(e?: React.FormEvent) {
    e?.preventDefault();
    const trimmed = skillName.trim();
    if (!trimmed) {
      toast({ title: 'Введите название навыка', variant: 'destructive' });
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      lastSkillRef.current = trimmed;
      const res = await api<CareerScenarioResponse>('/api/me/career-scenario', {
        method: 'POST',
        body: JSON.stringify({ skillName: trimmed }),
      });
      setResult(res);
    } catch (e: any) {
      handleScenarioError(e, trimmed);
    } finally {
      setLoading(false);
    }
  }

  function handlePreset(skill: string) {
    setSkillName(skill);
    // Авто-сабмит после выбора пресета
    setTimeout(() => {
      // Используем ref-like трюк — храним skill в замыкании и сразу вызываем API
      simulateSkill(skill);
    }, 0);
  }

  // Версия handleSimulate с явным аргументом (для пресетов)
  async function simulateSkill(skill: string) {
    const trimmed = skill.trim();
    if (!trimmed) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      lastSkillRef.current = trimmed;
      const res = await api<CareerScenarioResponse>('/api/me/career-scenario', {
        method: 'POST',
        body: JSON.stringify({ skillName: trimmed }),
      });
      setResult(res);
    } catch (e: any) {
      handleScenarioError(e, trimmed);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className={cn('overflow-hidden', className)}>
      {/* Волна 14: paywall — не хватает люменов на ИИ-сценарий */}
      <LumenPaywallDialog
        open={paywall !== null}
        onOpenChange={(o) => { if (!o) setPaywall(null); }}
        need={paywall?.need ?? 1}
        have={paywall?.have ?? 0}
        onToppedUp={() => {
          setPaywall(null);
          if (lastSkillRef.current) simulateSkill(lastSkillRef.current);
        }}
      />
      <CardHeader className="bg-gradient-to-br from-lighthouse/10 to-transparent">
        <CardTitle className="text-base flex items-center gap-2">
          <span className="text-base">🔮</span>
          Career Scenario
          <span className="text-xs text-muted-foreground font-normal ml-1">
            «Что если я получу навык…»
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {/* === Поле ввода === */}
        <form onSubmit={handleSimulate} className="space-y-2">
          <div className="flex gap-2">
            <Input
              value={skillName}
              onChange={(e) => setSkillName(e.target.value)}
              placeholder="Например: Machine Learning, Kubernetes, Figma…"
              maxLength={80}
              disabled={loading}
              className="flex-1"
            />
            <Button
              type="submit"
              disabled={loading || !skillName.trim()}
              className="bg-lighthouse hover:bg-lighthouse/90 text-lighthouse-foreground gap-1.5"
            >
              {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              {isFree ? 'Симулировать · 1 Л' : 'Симулировать'}
            </Button>
          </div>
          {/* Популярные навыки-пресеты */}
          <div className="flex flex-wrap gap-1.5 items-center">
            <span className="text-xs text-muted-foreground">популярное:</span>
            {POPULAR_SKILLS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => handlePreset(s)}
                disabled={loading}
                className="px-2 py-0.5 rounded-full text-xs border border-border hover:border-lighthouse hover:bg-lighthouse/5 transition disabled:opacity-50"
              >
                {s}
              </button>
            ))}
          </div>
        </form>

        {/* === Загрузка === */}
        {loading && (
          <div className="space-y-2">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        )}

        {/* === Ошибка === */}
        {error && !loading && (
          <div
            role="alert"
            className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive flex items-start gap-2"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-medium">Не удалось построить сценарий</div>
              <div className="text-xs opacity-80 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        {/* === Результат === */}
        {result && !loading && (
          <div className="space-y-3 animate-in fade-in duration-300">
            {/* Заголовок-резюме */}
            <div className="rounded-lg border border-lighthouse/30 bg-lighthouse/5 p-3">
              <div className="text-xs font-medium text-lighthouse mb-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Сценарий: «{result.targetSkill}»
              </div>
              <p className="text-sm text-foreground/90 leading-relaxed">
                {result.reasoning}
              </p>
              {result.engine === 'fallback' && (
                <p className="text-xs text-muted-foreground mt-2 italic">
                  LLM недоступен — показана эвристика по вашим навыкам и вакансиям
                </p>
              )}
            </div>

            {/* Метрики в grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <MetricCard
                icon={<Briefcase className="w-3.5 h-3.5" />}
                label="Новых возможностей"
                value={result.newOpportunitiesCount > 0 ? `+${result.newOpportunitiesCount}` : '0'}
                hint={`из ${result.totalRelevantJobs} вакансий`}
                positive={result.newOpportunitiesCount > 0}
              />
              <MetricCard
                icon={<TrendingUp className="w-3.5 h-3.5" />}
                label="Рост з/п"
                value={
                  result.salaryGrowthPct != null
                    ? `${result.salaryGrowthPct > 0 ? '+' : ''}${result.salaryGrowthPct}%`
                    : '—'
                }
                hint={
                  result.projectedAvgSalaryMax != null
                    ? `до ${result.projectedAvgSalaryMax.toLocaleString('ru-RU')} ₽`
                    : undefined
                }
                positive={(result.salaryGrowthPct ?? 0) > 0}
              />
              <MetricCard
                icon={<Clock className="w-3.5 h-3.5" />}
                label="Время"
                value={result.estimatedMonths != null ? `~${result.estimatedMonths} мес` : '—'}
                hint="на освоение"
              />
              <MetricCard
                icon={<Sparkles className="w-3.5 h-3.5" />}
                label="Уже подходило"
                value={String(result.currentMatchesCount)}
                hint="вакансий"
              />
            </div>

            {/* Role Transition */}
            {result.roleTransition && (
              <div className="rounded-md border p-3 bg-muted/30">
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                  Трансформация роли
                </div>
                <div className="flex items-center gap-2 flex-wrap text-sm">
                  <span className="font-medium">{result.roleTransition.from || 'Текущая роль'}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-lighthouse" />
                  <span className="font-medium text-lighthouse">
                    {result.roleTransition.to || 'новая роль'}
                  </span>
                </div>
              </div>
            )}

            {/* Recommended roles */}
            {result.recommendedRoles.length > 0 && (
              <div className="space-y-1.5">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">
                  Открывающиеся роли
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {result.recommendedRoles.map((r, i) => (
                    <Badge key={`${r}-${i}`} variant="secondary" className="text-xs">
                      {r}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Trade-off «остаться vs освоить навык» — из метрик ответа (Task 10-d) */}
            {(() => {
              const tradeOff = buildTradeOff(result);
              if (!tradeOff) return null;
              return (
                <div className="rounded-md border p-3 space-y-2">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">
                    Trade-off: остаться vs освоить
                  </div>
                  <div className="grid grid-cols-[1fr_auto_1fr] items-stretch gap-2">
                    <div className="rounded-md border p-2.5 min-w-0 bg-muted/20">
                      <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Остаться</div>
                      <div className="text-sm font-semibold tabular-nums">{tradeOff.stay.jobs} вакансий</div>
                      <div className="text-xs text-muted-foreground mt-0.5 truncate">
                        {tradeOff.stay.salaryMax != null ? `з/п до ${formatMoney(tradeOff.stay.salaryMax)}` : 'з/п: мало данных'}
                      </div>
                    </div>
                    <div className="flex items-center" aria-hidden="true">
                      <ArrowRight className="w-4 h-4 text-lighthouse" />
                    </div>
                    <div className="rounded-md border p-2.5 min-w-0 bg-lighthouse/5 border-lighthouse/40">
                      <div className="text-xs uppercase tracking-wider text-lighthouse mb-1">Освоить навык</div>
                      <div className="text-sm font-semibold tabular-nums">{tradeOff.after.jobs} вакансий</div>
                      <div className="text-xs text-muted-foreground mt-0.5 truncate">
                        {tradeOff.after.salaryMax != null ? `з/п до ${formatMoney(tradeOff.after.salaryMax)}` : 'з/п: мало данных'}
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Сравнение построено из метрик сценария: подходящие вакансии (match ≥ 50%) и средняя верхняя граница з/п по ним.
                  </p>
                </div>
              );
            })()}

            {/* CTA: Начать развитие */}
            <div className="flex flex-wrap gap-2 pt-1">
              <Button
                size="sm"
                onClick={() => setView('mentor')}
                className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
              >
                <Users className="w-3.5 h-3.5" />
                Найти ментора
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setView('me')}
                className="gap-1.5"
                title="EDU рекомендации — раздел «Я»"
              >
                <GraduationCap className="w-3.5 h-3.5" />
                Курсы (EDU)
              </Button>
            </div>

            {/* Дисклеймер эвристической модели (Task 10-d) */}
            <p className="text-xs text-muted-foreground/80 border-t pt-2">
              {SCENARIO_DISCLAIMER}
            </p>
          </div>
        )}

        {/* === Empty state === */}
        {!result && !loading && !error && (
          <div className="text-center py-4 text-xs text-muted-foreground">
            Введите навык или выберите из популярных — построим сценарий
            «что изменится в вашей карьере, если вы его освоите».
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// === Локальный мини-компонент: Метрика ===

function MetricCard({
  icon,
  label,
  value,
  hint,
  positive,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint?: string;
  positive?: boolean;
}) {
  return (
    <div className="rounded-md border p-2.5 bg-muted/20">
      <div className="flex items-center gap-1 text-xs text-muted-foreground uppercase tracking-wider mb-1">
        <span className="opacity-70">{icon}</span>
        <span className="truncate">{label}</span>
      </div>
      <div
        className={cn(
          'text-base font-bold tabular-nums',
          positive === true && 'text-emerald-700 dark:text-emerald-400',
          positive === false && 'text-muted-foreground',
        )}
      >
        {value}
      </div>
      {hint && (
        <div className="text-xs text-muted-foreground mt-0.5 truncate">{hint}</div>
      )}
    </div>
  );
}
