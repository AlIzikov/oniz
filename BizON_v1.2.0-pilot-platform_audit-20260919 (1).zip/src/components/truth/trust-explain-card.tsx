// BizON — TrustExplainCard (P0-2: Explainable Trust)
//
// Крупный score + breakdown по 6 категориям + основание Trust.
// Принципы (ЧАСТЬ 9 AUDIT):
//   • IP-score НЕ публичный — только владелец видит число.
//   • Trust обязан быть explainable: «почему 824», а не абстрактный балл.
//
// Источник: GET /api/me/trust-explain
// Используется:
//   • В me-view.tsx Tab «Моя правда» (вверху)
//   • В whats-new-tab.tsx — Trust Hero кликабельный → открывает карточку в диалоге
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import {ShieldCheck, TrendingUp, TrendingDown, HelpCircle, Lightbulb, Award, FolderCheck, Users, Sparkles, ChevronDown, Brain, Target, HeartHandshake, Crown, Gauge} from 'lucide-react';

// === Тип ответа /api/me/trust-explain ===
interface TrustTrendPoint {
  id: string;
  ipScore: number;
  level: string;
  createdAt: string;
}

interface TrustExplainResponse {
  score: number;
  level: 'basic' | 'extended' | 'expert' | string;
  breakdown: {
    competence: number;
    reliability: number;
    delivery: number;
    leadership: number;
    collaboration: number;
    expertise: number;
  };
  basis: {
    verifiedProjects: number;
    verifiedSkills: number;
    recommendations: number;
    verifiedResults: number;
    professionalInteractions: number;
  };
  delta30days: number;
  trend: TrustTrendPoint[];
  explainable: true;
}

// === Метаданные категорий breakdown ===
const CATEGORIES: Array<{
  key: keyof TrustExplainResponse['breakdown'];
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  hint: string;
  // Полные литеральные классы для Tailwind JIT
  indicatorClass: string;
}> = [
  {
    key: 'competence',
    label: 'Компетентность',
    icon: Brain,
    hint: 'Подтверждённые навыки',
    indicatorClass: '[&_[data-slot=progress-indicator]]:bg-emerald-500',
  },
  {
    key: 'reliability',
    label: 'Надёжность',
    icon: FolderCheck,
    hint: 'Завершённые проекты',
    indicatorClass: '[&_[data-slot=progress-indicator]]:bg-teal-500',
  },
  {
    key: 'delivery',
    label: 'Delivery',
    icon: Gauge,
    hint: 'Средний рейтинг проектов',
    indicatorClass: '[&_[data-slot=progress-indicator]]:bg-cyan-500',
  },
  {
    key: 'leadership',
    label: 'Leadership',
    icon: Crown,
    hint: 'Роль основателя / кофаундера',
    indicatorClass: '[&_[data-slot=progress-indicator]]:bg-amber-500',
  },
  {
    key: 'collaboration',
    label: 'Коллаборация',
    icon: HeartHandshake,
    hint: 'Уникальные коллеги',
    indicatorClass: '[&_[data-slot=progress-indicator]]:bg-rose-500',
  },
  {
    key: 'expertise',
    label: 'Экспертиза',
    icon: Award,
    hint: 'NFT-навыки',
    indicatorClass: '[&_[data-slot=progress-indicator]]:bg-violet-500',
  },
];

const LEVEL_LABEL: Record<string, string> = {
  basic: 'Старт',
  extended: 'Проверенный',
  expert: 'Эксперт',
};

const LEVEL_COLOR: Record<string, string> = {
  basic: 'text-amber-600 dark:text-amber-500',
  extended: 'text-cyan-600 dark:text-cyan-500',
  expert: 'text-emerald-600 dark:text-emerald-500',
};

// === Как повысить доверие (статичные советы; числа-влияния не фейковы — убраны) ===
const NEXT_BEST_ACTIONS = [
  {
    icon: FolderCheck,
    title: 'Завершите ещё 1 проект',
    description: 'Завершённый проект — главный источник Trust.',
  },
  {
    icon: Users,
    title: 'Запросите подтверждение навыка',
    description: 'Коллега по проекту может подтвердить ваш навык.',
  },
  {
    icon: Crown,
    title: 'Станьте основателем проекта',
    description: 'Создайте проект и соберите команду.',
  },
  {
    icon: Award,
    title: 'Получите NFT-навык',
    description: '3+ подтверждения навыка → минт NFT.',
  },
];

interface TrustExplainCardProps {
  /** Показывать breakdown развёрнутым по умолчанию */
  defaultOpen?: boolean;
  /** Компактный режим (для диалогов) */
  compact?: boolean;
  className?: string;
}

export function TrustExplainCard({
  defaultOpen = false,
  compact = false,
  className,
}: TrustExplainCardProps) {
  const [data, setData] = React.useState<TrustExplainResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [breakdownOpen, setBreakdownOpen] = React.useState(defaultOpen);
  const [actionsOpen, setActionsOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<TrustExplainResponse>('/api/me/trust-explain');
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить');
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return <TrustExplainSkeleton compact={compact} className={className} />;
  }

  if (error || !data) {
    return (
      <Card className={className}>
        <CardContent className="p-6 text-center">
          <ShieldCheck className="size-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            {error ?? 'Не удалось загрузить объяснение Trust.'}
          </p>
          <Button variant="outline" size="sm" className="mt-3" onClick={load}>
            Повторить
          </Button>
        </CardContent>
      </Card>
    );
  }

  const levelLabel = LEVEL_LABEL[data.level] ?? data.level;
  const levelColor = LEVEL_COLOR[data.level] ?? 'text-foreground';
  const delta = data.delta30days;

  return (
    <Card className={cn('overflow-hidden border-lighthouse/20', className)}>
      <CardContent className={cn(compact ? 'p-4' : 'p-6')}>
        {/* ====== HERO: score + level + delta ====== */}
        <div className="flex items-start gap-5 flex-wrap">
          {/* Крупный score */}
          <div className="flex-shrink-0 text-center">
            <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1">
              Ваш Trust
            </div>
            <div className="text-5xl font-extrabold leading-none tabular-nums">
              {data.score}
            </div>
            <div className="text-xs text-muted-foreground mt-1">/ 100</div>
          </div>

          {/* Level + delta + basis */}
          <div className="flex-1 min-w-0 space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge
                variant="secondary"
                className={cn('text-sm font-semibold gap-1.5', levelColor)}
              >
                <ShieldCheck className="size-3.5" />
                {levelLabel}
              </Badge>
              {delta !== 0 && (
                <span
                  className={cn(
                    'inline-flex items-center gap-0.5 text-xs font-medium',
                    delta > 0
                      ? 'text-emerald-600 dark:text-emerald-500'
                      : 'text-red-600 dark:text-red-500'
                  )}
                >
                  {delta > 0 ? (
                    <TrendingUp className="size-3.5" />
                  ) : (
                    <TrendingDown className="size-3.5" />
                  )}
                  {delta > 0 ? '+' : ''}
                  {delta} за 30 дней
                </span>
              )}
            </div>

            {/* Основание Trust */}
            <div className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">Основание:</span>{' '}
              {data.basis.verifiedProjects} проектов,{' '}
              {data.basis.verifiedSkills} навыков,{' '}
              {data.basis.recommendations} рекомендаций
            </div>

            {/* Расширенное основание (basis details) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <BasisPill
                icon={FolderCheck}
                value={data.basis.verifiedProjects}
                label="Проекты"
              />
              <BasisPill
                icon={Brain}
                value={data.basis.verifiedSkills}
                label="Навыки"
              />
              <BasisPill
                icon={Users}
                value={data.basis.recommendations}
                label="Реком."
              />
              <BasisPill
                icon={Target}
                value={data.basis.verifiedResults}
                label="Результаты"
              />
            </div>
          </div>
        </div>

        {/* ====== Кнопки: Почему? / Как повысить? ====== */}
        <div className="flex items-center gap-2 mt-4 flex-wrap">
          <Collapsible open={breakdownOpen} onOpenChange={setBreakdownOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5">
                <HelpCircle className="size-3.5" />
                Почему {data.score}?
                <ChevronDown
                  className={cn(
                    'size-3.5 transition-transform',
                    breakdownOpen && 'rotate-180'
                  )}
                />
              </Button>
            </CollapsibleTrigger>
          </Collapsible>

          <Collapsible open={actionsOpen} onOpenChange={setActionsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5">
                <Lightbulb className="size-3.5" />
                Как повысить?
                <ChevronDown
                  className={cn(
                    'size-3.5 transition-transform',
                    actionsOpen && 'rotate-180'
                  )}
                />
              </Button>
            </CollapsibleTrigger>
          </Collapsible>

          <div className="ml-auto text-xs text-muted-foreground inline-flex items-center gap-1">
            <Sparkles className="size-3" />
            Trust explainable
          </div>
        </div>

        {/* ====== Breakdown (6 категорий) — раскрывается по «Почему?» ====== */}
        <Collapsible open={breakdownOpen} onOpenChange={setBreakdownOpen}>
          <CollapsibleContent>
            <div className="mt-4 pt-4 border-t space-y-3">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Из чего состоит Trust
              </div>
              <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3">
                {CATEGORIES.map((cat) => {
                  const value = data.breakdown[cat.key];
                  const Icon = cat.icon;
                  return (
                    <div key={cat.key} className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <Icon className="size-3.5 text-muted-foreground shrink-0" />
                          <span className="text-sm font-medium truncate">
                            {cat.label}
                          </span>
                        </div>
                        <span className="text-sm font-bold tabular-nums">
                          {value}
                        </span>
                      </div>
                      <Progress
                        value={value}
                        className={cn('h-1.5', cat.indicatorClass)}
                      />
                      <div className="text-xs text-muted-foreground">
                        {cat.hint}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* ====== Next Best Actions — раскрывается по «Как повысить?» ====== */}
        <Collapsible open={actionsOpen} onOpenChange={setActionsOpen}>
          <CollapsibleContent>
            <div className="mt-4 pt-4 border-t space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Как повысить доверие
              </div>
              <div className="grid sm:grid-cols-2 gap-2">
                {NEXT_BEST_ACTIONS.map((action, i) => {
                  const Icon = action.icon;
                  return (
                    <div
                      key={i}
                      className="rounded-lg border bg-muted/30 p-3 flex items-start gap-2"
                    >
                      <div className="size-7 rounded-md bg-emerald-600/10 flex items-center justify-center shrink-0">
                        <Icon className="size-3.5 text-emerald-600 dark:text-emerald-500" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium">
                          {action.title}
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {action.description}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>
  );
}

// === Подкомпоненты ===

function BasisPill({
  icon: Icon,
  value,
  label,
}: {
  icon: React.ComponentType<{ className?: string }>;
  value: number;
  label: string;
}) {
  return (
    <div className="rounded-md border bg-muted/30 px-2 py-1.5 flex items-center gap-1.5">
      <Icon className="size-3 text-muted-foreground" />
      <span className="font-semibold tabular-nums">{value}</span>
      <span className="text-muted-foreground truncate">{label}</span>
    </div>
  );
}

function TrustExplainSkeleton({
  compact,
  className,
}: {
  compact?: boolean;
  className?: string;
}) {
  return (
    <Card className={className}>
      <CardContent className={cn(compact ? 'p-4' : 'p-6')}>
        <div className="flex items-start gap-5 flex-wrap">
          <div className="text-center">
            <Skeleton className="h-3 w-16 mx-auto mb-2" />
            <Skeleton className="h-12 w-16 mx-auto" />
            <Skeleton className="h-3 w-10 mx-auto mt-1" />
          </div>
          <div className="flex-1 min-w-0 space-y-3">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-4 w-full" />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-8" />
              ))}
            </div>
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          <Skeleton className="h-8 w-28" />
          <Skeleton className="h-8 w-32" />
        </div>
      </CardContent>
    </Card>
  );
}
