// BizON — Professional Moments (P0-5, ЧАСТЬ 14)
// Список последних Professional Moments из Professional Change Loop:
//   🔵 Trust ↑
//   ✅ Evidence added
//   🎓 Skill verified
//   ⭐ Recommendation
//   🚀 Project verified
//   💼 New opportunity
//   👁 Company viewed profile
//   📩 Recruiter invitation
//   🔮 Blind spot discovered
//
// Источник: GET /api/me/moments
// Используется в Truth Dashboard (whats-new-tab.tsx) и потенциально в me-view.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import {
  TrendingUp, CheckCircle2, GraduationCap, Star, Rocket,
  Briefcase, Eye, Mail, Lightbulb, ShieldCheck, Award,
  Sparkles, ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// === Типы ===
type MomentType =
  | 'trust_up'
  | 'evidence_added'
  | 'skill_verified'
  | 'recommendation_received'
  | 'project_verified'
  | 'new_opportunity'
  | 'company_viewed_profile'
  | 'recruiter_invitation'
  | 'blind_spot_discovered'
  // «тяжёлые» подтверждения тоже считаются моментами (для Change Loop)
  | 'project_completed'
  | 'claim_verified'
  | 'nft_skill_received';

interface Moment {
  type: MomentType;
  title: string;
  description: string | null;
  timestamp: string;
  metadata: Record<string, unknown> | null;
}

interface MomentsResponse {
  moments: Moment[];
  total: number;
}

const MOMENT_META: Record<
  MomentType,
  { label: string; icon: React.ReactNode; color: string; emoji: string }
> = {
  trust_up: {
    label: 'Trust ↑',
    icon: <TrendingUp className="w-3.5 h-3.5" />,
    color: 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10',
    emoji: '🔵',
  },
  evidence_added: {
    label: 'Доказательство',
    icon: <CheckCircle2 className="w-3.5 h-3.5" />,
    color: 'text-sky-700 dark:text-sky-400 bg-sky-500/10',
    emoji: '✅',
  },
  skill_verified: {
    label: 'Навык подтверждён',
    icon: <GraduationCap className="w-3.5 h-3.5" />,
    color: 'text-violet-700 dark:text-violet-400 bg-violet-500/10',
    emoji: '🎓',
  },
  recommendation_received: {
    label: 'Рекомендация',
    icon: <Star className="w-3.5 h-3.5" />,
    color: 'text-amber-700 dark:text-amber-400 bg-amber-500/10',
    emoji: '⭐',
  },
  project_verified: {
    label: 'Проект верифицирован',
    icon: <Rocket className="w-3.5 h-3.5" />,
    color: 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10',
    emoji: '🚀',
  },
  new_opportunity: {
    label: 'Новая возможность',
    icon: <Briefcase className="w-3.5 h-3.5" />,
    color: 'text-lighthouse bg-lighthouse/10',
    emoji: '💼',
  },
  company_viewed_profile: {
    label: 'Профиль просмотрен',
    icon: <Eye className="w-3.5 h-3.5" />,
    color: 'text-slate-700 dark:text-slate-300 bg-slate-500/10',
    emoji: '👁',
  },
  recruiter_invitation: {
    label: 'Приглашение',
    icon: <Mail className="w-3.5 h-3.5" />,
    color: 'text-rose-700 dark:text-rose-400 bg-rose-500/10',
    emoji: '📩',
  },
  blind_spot_discovered: {
    label: 'Blind spot',
    icon: <Lightbulb className="w-3.5 h-3.5" />,
    color: 'text-amber-700 dark:text-amber-400 bg-amber-500/10',
    emoji: '🔮',
  },
  // «Тяжёлые» подтверждения
  project_completed: {
    label: 'Проект завершён',
    icon: <ShieldCheck className="w-3.5 h-3.5" />,
    color: 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10',
    emoji: '✅',
  },
  claim_verified: {
    label: 'Claim подтверждён',
    icon: <ShieldCheck className="w-3.5 h-3.5" />,
    color: 'text-lighthouse bg-lighthouse/10',
    emoji: '✅',
  },
  nft_skill_received: {
    label: 'NFT-навык',
    icon: <Award className="w-3.5 h-3.5" />,
    color: 'text-amber-700 dark:text-amber-400 bg-amber-500/10',
    emoji: '🏅',
  },
};

function formatRelative(iso: string): string {
  const d = new Date(iso);
  const now = Date.now();
  const diffMs = now - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'только что';
  if (diffMin < 60) return `${diffMin} мин назад`;
  const diffH = Math.floor(diffMin / 60);
  if (diffH < 24) return `${diffH} ч назад`;
  const diffD = Math.floor(diffH / 24);
  if (diffD < 7) return `${diffD} дн назад`;
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

interface ProfessionalMomentsProps {
  /** Сколько моментов показывать (по умолчанию 5) */
  limit?: number;
  /** Компактный режим — без карточки-обёртки */
  compact?: boolean;
  /** Колбэк при клике «Показать все» */
  onShowAll?: () => void;
  /** Дополнительный className */
  className?: string;
}

export function ProfessionalMoments({
  limit = 5,
  compact = false,
  onShowAll,
  className,
}: ProfessionalMomentsProps) {
  const [moments, setMoments] = React.useState<Moment[]>([]);
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<MomentsResponse>(`/api/me/moments?limit=${limit}`);
      setMoments(res.moments ?? []);
    } catch (e) {
      console.error('[professional-moments] load error:', e);
    } finally {
      setLoading(false);
    }
  }, [limit]);

  React.useEffect(() => {
    load();
  }, [load]);

  const body = (
    <>
      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: Math.min(limit, 3) }).map((_, i) => (
            <div key={i} className="flex items-start gap-2.5">
              <Skeleton className="w-7 h-7 rounded-full flex-shrink-0" />
              <div className="flex-1 space-y-1.5">
                <Skeleton className="h-3 w-2/3" />
                <Skeleton className="h-2 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : moments.length === 0 ? (
        <div className="text-center py-6 text-sm text-muted-foreground">
          <Sparkles className="w-6 h-6 mx-auto mb-2 text-muted-foreground/50" />
          Пока нет Professional Moments.
          <br />
          Подтверждайте навыки и завершайте проекты — моменты появятся здесь.
        </div>
      ) : (
        <ul className="space-y-2.5">
          {moments.map((m, i) => {
            const meta = MOMENT_META[m.type] ?? {
              label: m.type,
              icon: <Sparkles className="w-3.5 h-3.5" />,
              color: 'text-muted-foreground bg-muted',
              emoji: '•',
            };
            return (
              <li key={`${m.type}-${i}-${m.timestamp}`} className="flex items-start gap-2.5">
                <div
                  className={cn(
                    'w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5',
                    meta.color,
                  )}
                  aria-hidden="true"
                  title={meta.label}
                >
                  {meta.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-sm font-medium truncate">{m.title}</span>
                    <time
                      dateTime={m.timestamp}
                      className="text-xs text-muted-foreground shrink-0 tabular-nums"
                    >
                      {formatRelative(m.timestamp)}
                    </time>
                  </div>
                  {m.description && (
                    <p className="text-xs text-muted-foreground leading-snug line-clamp-2 mt-0.5">
                      {m.description}
                    </p>
                  )}
                  {/* Дельта Trust для trust_up моментов */}
                  {m.type === 'trust_up' && m.metadata?.delta != null && (
                    <span className="inline-flex items-center gap-0.5 mt-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
                      <TrendingUp className="w-2.5 h-2.5" />
                      +{String(m.metadata.delta)}
                    </span>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );

  if (compact) {
    return (
      <div className={cn('space-y-3', className)}>
        {body}
        {onShowAll && !loading && moments.length > 0 && (
          <Button variant="ghost" size="sm" className="w-full text-xs h-7" onClick={onShowAll}>
            Показать все
            <ChevronRight className="w-3 h-3 ml-1" />
          </Button>
        )}
      </div>
    );
  }

  return (
    <Card className={className}>
      <CardContent className="p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-1 h-4 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Что изменилось
            </h3>
          </div>
          {onShowAll && !loading && moments.length > 0 && (
            <Button variant="ghost" size="sm" className="text-xs h-7" onClick={onShowAll}>
              Все <ChevronRight className="w-3 h-3" />
            </Button>
          )}
        </div>
        {body}
      </CardContent>
    </Card>
  );
}
