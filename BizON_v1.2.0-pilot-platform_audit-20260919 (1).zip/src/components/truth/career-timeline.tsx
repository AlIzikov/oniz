// BizON — GPT Truth Engine: CareerTimeline
// Вертикальная timeline карьерных записей пользователя.
// Загружает /api/career-entries, показывает форму добавления.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { StatusBadge } from '@/components/truth/status-badge';
import { cn } from '@/lib/utils';
import {
  Plus,
  Briefcase,
  Loader2,
  Calendar,
  MapPin,
  Building2,
} from 'lucide-react';

interface CareerEntry {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string | null;
  description: string | null;
  location: string | null;
  verificationLevel: string;
  createdAt: string;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'short',
    });
  } catch {
    return iso;
  }
}

export function CareerTimeline({ className }: { className?: string }) {
  const [entries, setEntries] = React.useState<CareerEntry[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [open, setOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ entries: CareerEntry[] }>('/api/career-entries');
      setEntries(res.entries);
    } catch (e: any) {
      toast({
        title: 'Не удалось загрузить карьеру',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  return (
    <div className={cn('space-y-4', className)}>
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Briefcase className="size-5" />
            Карьера
          </h2>
          <p className="text-sm text-muted-foreground">
            Хронология вашего профессионального пути.
          </p>
        </div>
        <AddCareerEntryDialog
          open={open}
          onOpenChange={setOpen}
          onCreated={load}
        />
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full rounded-xl" />
          ))}
        </div>
      ) : entries.length === 0 ? (
        <Card className="p-8 text-center">
          <Briefcase className="size-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground mb-4">
            Пока нет записей о карьере.
          </p>
          <AddCareerEntryDialog
            open={open}
            onOpenChange={setOpen}
            onCreated={load}
            asButton
          />
        </Card>
      ) : (
        <div className="relative">
          {/* Вертикальная линия timeline */}
          <div className="absolute left-3 top-2 bottom-2 w-px bg-border" />
          <ol className="space-y-4">
            {entries.map((entry) => (
              <li key={entry.id} className="relative pl-10">
                {/* Точка */}
                <span className="absolute left-1.5 top-3 size-3 rounded-full border-2 border-background bg-primary" />
                <Card className="py-0">
                  <CardContent className="p-4 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="text-sm font-semibold leading-snug">
                          {entry.position}
                        </h3>
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                          <Building2 className="size-3" />
                          <span className="truncate">{entry.company}</span>
                        </div>
                      </div>
                      <StatusBadge
                        level={entry.verificationLevel}
                        size="sm"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1">
                        <Calendar className="size-3" />
                        {formatDate(entry.startDate)} —{' '}
                        {entry.endDate ? formatDate(entry.endDate) : 'настоящее'}
                      </span>
                      {entry.location && (
                        <span className="inline-flex items-center gap-1">
                          <MapPin className="size-3" />
                          {entry.location}
                        </span>
                      )}
                    </div>

                    {entry.description && (
                      <p className="text-xs text-muted-foreground line-clamp-2 pt-1">
                        {entry.description}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}

// === Диалог добавления новой записи ===
function AddCareerEntryDialog({
  open,
  onOpenChange,
  onCreated,
  asButton = false,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: () => void;
  asButton?: boolean;
}) {
  const [company, setCompany] = React.useState('');
  const [position, setPosition] = React.useState('');
  const [startDate, setStartDate] = React.useState('');
  const [endDate, setEndDate] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);

  function reset() {
    setCompany('');
    setPosition('');
    setStartDate('');
    setEndDate('');
    setDescription('');
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!company.trim() || !position.trim() || !startDate) {
      toast({
        title: 'Заполните обязательные поля',
        description: 'Компания, должность и дата начала обязательны.',
        variant: 'destructive',
      });
      return;
    }
    setSubmitting(true);
    try {
      await api('/api/career-entries', {
        method: 'POST',
        body: JSON.stringify({
          company: company.trim(),
          position: position.trim(),
          startDate,
          endDate: endDate || null,
          description: description.trim() || null,
        }),
      });
      toast({ title: 'Этап карьеры добавлен' });
      reset();
      onOpenChange(false);
      onCreated();
    } catch (e: any) {
      toast({
        title: 'Не удалось создать',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        {asButton ? (
          <Button variant="outline" className="bg-emerald-600 text-white hover:bg-emerald-700">
            <Plus className="size-4" />
            Добавить этап
          </Button>
        ) : (
          <Button size="sm" className="bg-emerald-600 text-white hover:bg-emerald-700">
            <Plus className="size-4" />
            Добавить этап
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Briefcase className="size-5" />
            Новый этап карьеры
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="ce-company">Компания</Label>
            <Input
              id="ce-company"
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              placeholder="ООО «Ромашка»"
              maxLength={200}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ce-position">Должность</Label>
            <Input
              id="ce-position"
              value={position}
              onChange={(e) => setPosition(e.target.value)}
              placeholder="Senior Engineer"
              maxLength={200}
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="ce-start">Дата начала</Label>
              <Input
                id="ce-start"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ce-end">
                Дата окончания{' '}
                <span className="text-muted-foreground font-normal">
                  (опц.)
                </span>
              </Label>
              <Input
                id="ce-end"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ce-description">
              Описание{' '}
              <span className="text-muted-foreground font-normal">
                (опционально)
              </span>
            </Label>
            <Textarea
              id="ce-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Что делали, каких результатов достигли…"
              maxLength={5000}
              className="min-h-20"
            />
          </div>
          <Button
            type="submit"
            disabled={submitting}
            className="w-full bg-emerald-600 text-white hover:bg-emerald-700"
          >
            {submitting ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                Сохранение…
              </>
            ) : (
              <>
                <Plus className="size-4" />
                Добавить
              </>
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
