// BizON — GPT Truth Engine: ClaimCard
// Карточка claim: статус, тип, заголовок, PROVE IT, подтверждения, запросить подтверждение.
'use client';

import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StatusBadge, type TruthLevel } from '@/components/truth/status-badge';
import { ProveItButton } from '@/components/truth/prove-it-button';
import { EvidenceModal } from '@/components/truth/evidence-modal';
import { cn } from '@/lib/utils';
import { Users, MessageSquare, Award, Briefcase, Target } from 'lucide-react';

export type ClaimType =
  | 'skill'
  | 'experience'
  | 'achievement'
  | 'role'
  | 'result';

export interface Claim {
  id: string;
  type: ClaimType | string;
  title: string;
  description?: string | null;
  status: TruthLevel | string;
  verificationsCount?: number;
  projectId?: string | null;
  skillId?: string | null;
  createdAt?: string;
}

const TYPE_META: Record<
  string,
  { label: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  skill: { label: 'Навык', Icon: Award },
  experience: { label: 'Опыт', Icon: Briefcase },
  achievement: { label: 'Достижение', Icon: Target },
  role: { label: 'Роль', Icon: Briefcase },
  result: { label: 'Результат', Icon: Target },
};

interface ClaimCardProps {
  claim: Claim;
  /** Callback при изменении claim (например, после создания claim-form в PROVE IT) */
  onChanged?: () => void;
  className?: string;
  /** Показывать кнопку «Запросить подтверждение» */
  showRequestVerify?: boolean;
}

export function ClaimCard({
  claim,
  onChanged,
  className,
  showRequestVerify = true,
}: ClaimCardProps) {
  const typeKey = (claim.type as string) in TYPE_META ? (claim.type as string) : 'skill';
  const typeMeta = TYPE_META[typeKey];
  const { Icon } = typeMeta;
  const isClaimed = claim.status === 'claimed';
  const verificationsCount = claim.verificationsCount ?? 0;

  return (
    <Card className={cn('py-0', className)}>
      <CardContent className="p-4 space-y-3">
        {/* Header: тип + статус */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="flex items-center justify-center size-7 rounded-md bg-muted text-muted-foreground shrink-0">
              <Icon className="size-3.5" />
            </div>
            <span className="text-xs text-muted-foreground font-medium">
              {typeMeta.label}
            </span>
          </div>
          <StatusBadge level={claim.status} size="sm" />
        </div>

        {/* Title + description */}
        <div className="space-y-1">
          <h3 className="text-sm font-semibold leading-snug">
            {claim.title}
          </h3>
          {claim.description && (
            <p className="text-xs text-muted-foreground line-clamp-2">
              {claim.description}
            </p>
          )}
        </div>

        {/* Footer: подтверждения + actions */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t">
          <EvidenceModal
            title={`Почему «${claim.title.slice(0, 40)}${claim.title.length > 40 ? '…' : ''}»?`}
            description="Основание для уровня доказательности этого claim."
            evidence={[
              {
                label: 'Подтверждения',
                count: verificationsCount,
                source: 'verifications',
              },
              {
                label: 'Через проект',
                count: claim.projectId ? 1 : 0,
                source: 'projects',
              },
            ]}
            trigger={
              <span className="inline-flex items-center gap-1">
                <Users className="size-3.5" />
                Подтверждений: {verificationsCount}
              </span>
            }
          />

          <div className="flex items-center gap-1.5 ml-auto">
            {isClaimed && (
              <ProveItButton
                type="claim"
                size="sm"
                projectId={claim.projectId ?? undefined}
                skillId={claim.skillId ?? undefined}
                onClaimCreated={onChanged}
              />
            )}
            {showRequestVerify && (
              <Button
                size="sm"
                variant="outline"
                disabled
                title="Точечный выбор верификатора появится в следующей волне; подтверждение уже возможно по прямой ссылке claim"
                className="h-8"
              >
                <MessageSquare className="size-3.5" />
                Запросить подтверждение
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
