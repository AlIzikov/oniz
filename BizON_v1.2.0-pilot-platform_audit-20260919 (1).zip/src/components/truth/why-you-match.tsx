// BizON — GPT Truth Engine: Why You Match (улучшенный breakdown)
// Компонент для отображения в JobCard — объяснение почему match = X%.
// Принимает props: matchPercent, userSkills, requiredSkills.
// Показывает:
//   - ✅ N совпадающих навыков (зелёный) — пересечение userSkills и requiredSkills
//   - ❌ N недостающих навыков (красный) — requiredSkills минус userSkills
//   - Список недостающих навыков (мелким текстом)
//   - «Если вы подтвердите [навык], match может вырасти до ~X%»
'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

interface WhyYouMatchProps {
  /** Текущий процент совпадения (0-100) */
  matchPercent: number;
  /** Навыки текущего пользователя (по названиям) */
  userSkills: string[];
  /** Навыки, требуемые вакансией */
  requiredSkills: string[];
  /** Дополнительный className для контейнера */
  className?: string;
}

function toLowerSet(skills: string[]): Set<string> {
  return new Set(skills.map((s) => s.trim().toLowerCase()).filter(Boolean));
}

export function WhyYouMatch({
  matchPercent,
  userSkills,
  requiredSkills,
  className,
}: WhyYouMatchProps) {
  // Сравнение делаем case-insensitively, чтобы не зависеть от регистра навыков
  const userSet = React.useMemo(() => toLowerSet(userSkills), [userSkills]);
  const requiredLower = React.useMemo(
    () => requiredSkills.map((s) => s.trim()).filter(Boolean),
    [requiredSkills]
  );

  const matched = React.useMemo(
    () => requiredLower.filter((s) => userSet.has(s.toLowerCase())),
    [requiredLower, userSet]
  );
  const missing = React.useMemo(
    () => requiredLower.filter((s) => !userSet.has(s.toLowerCase())),
    [requiredLower, userSet]
  );

  // Прогноз: каждое подтверждение недостающего навыка поднимает match на ~(100 / N)%.
  // Берём ОДИН следующий недостающий навык (наибольший эффект).
  const perSkillValue = requiredLower.length > 0 ? 100 / requiredLower.length : 0;
  const projectedMatch = Math.min(100, Math.round(matchPercent + perSkillValue));
  const nextMissingSkill = missing[0];

  return (
    <div
      className={cn(
        'mt-2 rounded-lg border bg-muted/30 p-3 text-xs space-y-2',
        className
      )}
    >
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-emerald-700 dark:text-emerald-400 font-medium">
          ✅ {matched.length} совпадающих навыков
        </span>
        <span className="text-red-700 dark:text-red-400 font-medium">
          ❌ {missing.length} недостающих навыков
        </span>
      </div>

      {missing.length > 0 && (
        <div>
          <div className="text-muted-foreground mb-1">Недостающие навыки:</div>
          <div className="flex flex-wrap gap-1">
            {missing.map((s) => (
              <span
                key={s}
                className="px-1.5 py-0.5 rounded bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300"
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      )}

      {nextMissingSkill && (
        <div className="text-muted-foreground leading-relaxed">
          Если вы подтвердите{' '}
          <strong className="text-foreground">{nextMissingSkill}</strong>, match может
          вырасти до ~{projectedMatch}%
        </div>
      )}

      {missing.length === 0 && requiredLower.length > 0 && (
        <div className="text-emerald-700 dark:text-emerald-400 leading-relaxed">
          Все требуемые навыки у вас есть. Подтверждайте их, чтобы усилить репутацию.
        </div>
      )}
    </div>
  );
}
