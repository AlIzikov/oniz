// BizON 2.0 — Phase 5 / Spec §D.9: Skill Graph View
// Вектор навыков с explainable level (1-10), decay индикаторами и resurrection path.
//
// Источник данных: GET /api/me/skills/graph
// Drilldown:       GET /api/me/skills/[skillId]/explain
// Resurrection:    POST /api/me/skills/[skillId]/resurrect
//
// Принципы (Spec §0):
//   - Nothing is trusted by default — каждое число explainable
//   - Explainability is a contract — drilldown до evidence
//   - Trust is revocable and bounded — peakLevel монотонно не убывает
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { useAppStore } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';
import {
  Brain,
  TrendingUp,
  TrendingDown,
  ChevronDown,
  ChevronRight,
  RefreshCw,
  Loader2,
  Award,
  FolderKanban,
  Users,
  Target,
  FileText,
  AlertTriangle,
  Clock,
  Sparkles,
  CheckCircle2,
  Info,
  GraduationCap,
} from 'lucide-react';

// === Типы ответов API ===

type DecayStatus = 'fresh' | 'stale' | 'decayed';
type EvidenceSource = 'project' | 'confirmation' | 'result' | 'recommendation' | 'certificate';

interface SkillEvidenceItem {
  source: EvidenceSource;
  title: string;
  meta?: Record<string, string | number | null>;
  verifierTrust: number;
  recencyFactor: number;
}

interface SkillGraphNode {
  skillId: string;
  skillName: string;
  category: string | null;
  currentLevel: number;
  peakLevel: number;
  confidence: number;
  decayStatus: DecayStatus;
  lastUsedAt: string | null;
  breakdown: {
    bucket1: number;
    bucket2: number;
    bucket3: number;
    bucket4: number;
  };
  explanation: string;
  evidence: SkillEvidenceItem[];
  formulaVersion: number;
}

interface SkillGraphResponse {
  skills: SkillGraphNode[];
  stats: {
    total: number;
    fresh: number;
    stale: number;
    decayed: number;
    avgLevel: number;
    avgConfidence: number;
  };
}

interface ExplainResponse extends SkillGraphNode {
  rawScore: number;
  nextLevelRequirements: string[];
}

interface ResurrectResponse {
  skillId: string;
  skillName: string;
  currentLevel: number;
  peakLevel: number;
  decayStatus: DecayStatus;
  steps: string[];
  estimatedTime: string;
  deltaLevels: number;
}

// === Phase 6: Proof-of-Skill ===
type ProofSource = 'project' | 'confirmation' | 'claim' | 'result' | 'recommendation';
type ProofStatus =
  | 'verified'
  | 'project_verified'
  | 'expert_verified'
  | 'claimed'
  | 'pending'
  | 'rejected';

interface SkillProof {
  source: ProofSource;
  type: string;
  date: string | null;
  projectName: string | null;
  role: string | null;
  result: string | null;
  verifier: string | null;
  confidence: number | null;
  status: ProofStatus;
}

interface ProofsResponse {
  skillId: string;
  userSkillId: string;
  skillName: string;
  proofs: SkillProof[];
  stats: {
    total: number;
    verified: number;
    projects: number;
    confirmations: number;
    claims: number;
    results: number;
    recommendations: number;
  };
}

// === Хелперы ===

const DECAY_META: Record<
  DecayStatus,
  { icon: '🟢' | '🟡' | '🔴'; label: string; className: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  fresh: {
    icon: '🟢',
    label: 'Свежий',
    className: 'border-emerald-300/40 text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40',
    Icon: CheckCircle2,
  },
  stale: {
    icon: '🟡',
    label: 'Устаревает',
    className: 'border-amber-300/40 text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40',
    Icon: Clock,
  },
  decayed: {
    icon: '🔴',
    label: 'Затухший',
    className: 'border-red-400/40 text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/40',
    Icon: AlertTriangle,
  },
};

const BUCKET_META = [
  {
    key: 'bucket1' as const,
    label: 'B1 · Проекты',
    ceiling: 40,
    Icon: FolderKanban,
    color: 'text-emerald-600',
  },
  {
    key: 'bucket2' as const,
    label: 'B2 · Подтверждения',
    ceiling: 30,
    Icon: Users,
    color: 'text-blue-600',
  },
  {
    key: 'bucket3' as const,
    label: 'B3 · Результаты',
    ceiling: 20,
    Icon: Target,
    color: 'text-purple-600',
  },
  {
    key: 'bucket4' as const,
    label: 'B4 · Рекомендации',
    ceiling: 10,
    Icon: FileText,
    color: 'text-amber-600',
  },
];

const SOURCE_META: Record<EvidenceSource, { label: string; Icon: React.ComponentType<{ className?: string }> }> = {
  project: { label: 'Проект', Icon: FolderKanban },
  confirmation: { label: 'Подтверждение', Icon: Users },
  result: { label: 'Результат', Icon: Target },
  recommendation: { label: 'Рекомендация', Icon: FileText },
  certificate: { label: 'Сертификат', Icon: Award },
};

// === Phase 6: Proof-of-Skill — метаданные источников для drilldown ===
const PROOF_SOURCE_META: Record<
  ProofSource,
  { label: string; glyph: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  project: { label: 'Проект', glyph: '├──', Icon: FolderKanban },
  confirmation: { label: 'Подтверждение', glyph: '├──', Icon: Users },
  claim: { label: 'Утверждение', glyph: '├──', Icon: FileText },
  result: { label: 'Результат', glyph: '├──', Icon: Target },
  recommendation: { label: 'Recommendation', glyph: '└──', Icon: Award },
};

const PROOF_STATUS_META: Record<ProofStatus, { label: string; className: string }> = {
  expert_verified: {
    label: 'эксперт подтвердил',
    className: 'text-amber-700 dark:text-amber-300',
  },
  project_verified: {
    label: 'подтверждён',
    className: 'text-emerald-700 dark:text-emerald-300',
  },
  verified: {
    label: 'подтверждён',
    className: 'text-emerald-700 dark:text-emerald-300',
  },
  claimed: {
    label: 'заявлен',
    className: 'text-muted-foreground',
  },
  pending: {
    label: 'на модерации',
    className: 'text-amber-600',
  },
  rejected: {
    label: 'отклонён',
    className: 'text-red-600',
  },
};

function levelColor(level: number): string {
  if (level >= 8) return 'bg-emerald-500';
  if (level >= 5) return 'bg-blue-500';
  if (level >= 3) return 'bg-amber-500';
  return 'bg-muted-foreground/40';
}

function confidenceLabel(c: number): { label: string; className: string } {
  if (c >= 0.75) return { label: 'Высокая', className: 'text-emerald-600' };
  if (c >= 0.5) return { label: 'Средняя', className: 'text-blue-600' };
  if (c >= 0.25) return { label: 'Низкая', className: 'text-amber-600' };
  return { label: 'Очень низкая', className: 'text-red-600' };
}

function formatDate(iso: string | null): string {
  if (!iso) return 'никогда';
  try {
    return new Date(iso).toLocaleDateString('ru-RU', { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return iso;
  }
}

// === Главный компонент ===

export function SkillGraphView({ className }: { className?: string }) {
  const [data, setData] = React.useState<SkillGraphResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const load = React.useCallback(async () => {
    setRefreshing(true);
    try {
      const res = await api<SkillGraphResponse>('/api/me/skills/graph');
      setData(res);
    } catch (e: any) {
      toast({
        title: 'Не удалось загрузить Skill Graph',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <Card className={className}>
        <CardHeader>
          <Skeleton className="h-7 w-48" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full rounded-lg" />
          ))}
        </CardContent>
      </Card>
    );
  }

  const stats = data?.stats;
  const skills = data?.skills ?? [];

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <Brain className="size-5 text-lighthouse" />
              Skill Graph
              <span className="text-xs font-normal text-muted-foreground">
                v{skills[0]?.formulaVersion ?? 1}
              </span>
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Explainable уровни навыков (1–10) с decay и resurrection path.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={load}
            disabled={refreshing}
            title="Пересчитать уровни и decay"
          >
            {refreshing ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <RefreshCw className="size-3.5" />
            )}
            Обновить
          </Button>
        </div>

        {/* Stats summary */}
        {stats && stats.total > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-3">
            <StatPill label="Всего" value={stats.total} />
            <StatPill label="Свежие" value={stats.fresh} icon="🟢" />
            <StatPill label="Устаревают" value={stats.stale} icon="🟡" />
            <StatPill label="Затухшие" value={stats.decayed} icon="🔴" />
            <StatPill
              label="Средний уровень"
              value={stats.avgLevel}
              hint={`conf ${(stats.avgConfidence * 100).toFixed(0)}%`}
            />
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-2">
        {skills.length === 0 ? (
          <div className="text-center py-10">
            <Brain className="size-8 mx-auto mb-2 text-muted-foreground/60" />
            <p className="text-sm text-muted-foreground">
              У вас пока нет навыков. Добавьте навыки в профиле, чтобы увидеть Skill Graph.
            </p>
          </div>
        ) : (
          skills.map((s) => (
            <SkillRow key={s.skillId} skill={s} onChanged={load} />
          ))
        )}

        {/* Formula hint */}
        <div className="mt-4 pt-3 border-t text-xs text-muted-foreground flex items-start gap-2">
          <Info className="size-3.5 mt-0.5 flex-shrink-0" />
          <div>
            Формула: 4 бакета доказательств (B1 проекты ×1.0 / B2 подтверждения ×0.7 / B3 результаты ×0.8 /
            B4 рекомендации ×0.5) с потолками 40/30/20/10 → rawScore 0–100 → level 1–10.
            Peak level монотонно не убывает. Decay: &gt;2 года → ×0.6, &gt;1 года → ×0.8.
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// === Строка навыка (раскрывающаяся) ===

function SkillRow({ skill, onChanged }: { skill: SkillGraphNode; onChanged: () => void }) {
  const [open, setOpen] = React.useState(false);
  const [explain, setExplain] = React.useState<ExplainResponse | null>(null);
  const [resurrect, setResurrect] = React.useState<ResurrectResponse | null>(null);
  const [proofs, setProofs] = React.useState<ProofsResponse | null>(null);
  const [loadingExplain, setLoadingExplain] = React.useState(false);
  const [loadingResurrect, setLoadingResurrect] = React.useState(false);
  const [loadingProofs, setLoadingProofs] = React.useState(false);
  const setView = useAppStore((s) => s.setView);

  const decay = DECAY_META[skill.decayStatus];
  const conf = confidenceLabel(skill.confidence);
  const progressPct = (skill.currentLevel / 10) * 100;
  const peakAboveCurrent = skill.peakLevel > skill.currentLevel;

  // === Phase 11: Mentor Graph integration ===
  // currentLevel < 7 → пользователю нужен ментор по этому навыку
  const needsMentor = skill.currentLevel < 7;
  // peakLevel >= 8 → пользователь может быть ментором для других
  const canBeMentor = skill.peakLevel >= 8;

  async function loadExplain() {
    if (explain) {
      // toggle off
      setExplain(null);
      return;
    }
    setLoadingExplain(true);
    try {
      const res = await api<ExplainResponse>(`/api/me/skills/${skill.skillId}/explain`);
      setExplain(res);
      setResurrect(null);
    } catch (e: any) {
      toast({ title: 'Ошибка explain', description: e?.message, variant: 'destructive' });
    } finally {
      setLoadingExplain(false);
    }
  }

  async function loadProofs() {
    if (proofs) {
      setProofs(null);
      return;
    }
    setLoadingProofs(true);
    try {
      const res = await api<ProofsResponse>(`/api/me/skills/${skill.skillId}/proofs`);
      setProofs(res);
    } catch (e: any) {
      toast({ title: 'Ошибка загрузки proofs', description: e?.message, variant: 'destructive' });
    } finally {
      setLoadingProofs(false);
    }
  }

  async function loadResurrect() {
    if (resurrect) {
      setResurrect(null);
      return;
    }
    setLoadingResurrect(true);
    try {
      const res = await api<ResurrectResponse>(`/api/me/skills/${skill.skillId}/resurrect`, {
        method: 'POST',
        body: JSON.stringify({}),
      });
      setResurrect(res);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e?.message, variant: 'destructive' });
    } finally {
      setLoadingResurrect(false);
    }
  }

  return (
    <div
      className={cn(
        'rounded-lg border transition-colors',
        skill.decayStatus === 'decayed'
          ? 'border-red-200 dark:border-red-900/50 bg-red-50/30 dark:bg-red-950/10'
          : skill.decayStatus === 'stale'
            ? 'border-amber-200 dark:border-amber-900/50 bg-amber-50/30 dark:bg-amber-950/10'
            : 'border-border',
      )}
    >
      {/* Header row — кликабельный */}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full text-left p-3 flex items-center gap-3 hover:bg-muted/30 transition-colors"
      >
        <div className="flex-shrink-0">
          {open ? (
            <ChevronDown className="size-4 text-muted-foreground" />
          ) : (
            <ChevronRight className="size-4 text-muted-foreground" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm truncate">{skill.skillName}</span>
            {skill.category && (
              <Badge variant="outline" className="text-xs px-1.5 py-0">
                {skill.category}
              </Badge>
            )}
            <Badge
              variant="outline"
              className={cn('text-xs px-1.5 py-0 gap-1', decay.className)}
              title={`Decay: ${skill.decayStatus}`}
            >
              <span>{decay.icon}</span>
              {decay.label}
            </Badge>
            {peakAboveCurrent && (
              <span
                className="inline-flex items-center gap-0.5 text-xs text-amber-600 dark:text-amber-400"
                title={`Peak был ${skill.peakLevel}, упал до ${skill.currentLevel} из-за decay`}
              >
                <TrendingDown className="size-3" />
                peak {skill.peakLevel}
              </span>
            )}
            {/* Phase 11: Mentor Graph — бейдж «Может быть наставником» для peakLevel >= 8 */}
            {canBeMentor && (
              <Badge
                variant="outline"
                className="text-xs px-1.5 py-0 gap-1 border-emerald-300/50 text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40"
                title={`Ваш peak level ${skill.peakLevel} >= 8 — вы можете стать наставником по этому навыку`}
              >
                <GraduationCap className="size-3" />
                Может быть наставником
              </Badge>
            )}
          </div>

          {/* Level bar */}
          <div className="mt-1.5 flex items-center gap-2">
            <div className="flex-shrink-0 text-xs font-bold tabular-nums w-8 text-right">
              {skill.currentLevel}
            </div>
            <Progress
              value={progressPct}
              className={cn('h-2 flex-1', `[&_[data-slot=progress-indicator]]:${levelColor(skill.currentLevel)}`)}
            />
            <div className="flex-shrink-0 text-xs text-muted-foreground tabular-nums w-10">
              / 10
            </div>
          </div>

          <div className="mt-1 text-xs text-muted-foreground flex items-center gap-2 flex-wrap">
            <span className={cn('font-medium', conf.className)}>
              conf {(skill.confidence * 100).toFixed(0)}% ({conf.label})
            </span>
            <span>·</span>
            <span>last used: {formatDate(skill.lastUsedAt)}</span>
          </div>
        </div>
      </button>

      {/* Раскрывающийся контент */}
      {open && (
        <div className="px-3 pb-3 pt-1 space-y-3 border-t">
          {/* === Explanation block === */}
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">
              Почему level {skill.currentLevel}?
            </div>
            <p className="text-xs text-foreground/90 leading-relaxed">{skill.explanation}</p>
          </div>

          {/* === Breakdown по бакетам === */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {BUCKET_META.map((b) => {
              const v = skill.breakdown[b.key];
              const pct = Math.min(100, (v / b.ceiling) * 100);
              const Icon = b.Icon;
              return (
                <div key={b.key} className="rounded-md border bg-muted/20 p-2">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground uppercase tracking-wide">
                    <Icon className={cn('size-3', b.color)} />
                    {b.label}
                  </div>
                  <div className="mt-1 text-sm font-bold tabular-nums">
                    {v.toFixed(1)}
                    <span className="text-xs text-muted-foreground font-normal"> / {b.ceiling}</span>
                  </div>
                  <Progress value={pct} className="mt-1 h-1" />
                </div>
              );
            })}
          </div>

          {/* === Evidence list === */}
          {skill.evidence.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">
                Что подтверждено ({skill.evidence.length})
              </div>
              <div className="space-y-1 max-h-48 overflow-y-auto scroll-area-thin">
                {skill.evidence.slice(0, 20).map((ev, i) => {
                  const meta = SOURCE_META[ev.source];
                  const Icon = meta.Icon;
                  return (
                    <div
                      key={i}
                      className="flex items-start gap-2 text-xs rounded-md border bg-background/60 p-2"
                    >
                      <Icon className="size-3.5 mt-0.5 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium truncate">{ev.title}</span>
                          <Badge variant="outline" className="text-xs px-1 py-0">
                            {meta.label}
                          </Badge>
                        </div>
                        {ev.meta && (
                          <div className="mt-0.5 text-xs text-muted-foreground flex items-center gap-2 flex-wrap">
                            {ev.meta.verifier && <span>{String(ev.meta.verifier)}</span>}
                            {ev.meta.role && <span>· {String(ev.meta.role)}</span>}
                            {ev.meta.date && <span>· {formatDate(String(ev.meta.date))}</span>}
                            {typeof ev.meta.outcome === 'string' && ev.meta.outcome && (
                              <span>· результат: {ev.meta.outcome}</span>
                            )}
                          </div>
                        )}
                        <div className="mt-0.5 text-xs text-muted-foreground tabular-nums">
                          verifierTrust: {ev.verifierTrust.toFixed(2)} · recency: {ev.recencyFactor.toFixed(2)}
                        </div>
                      </div>
                    </div>
                  );
                })}
                {skill.evidence.length > 20 && (
                  <div className="text-xs text-muted-foreground text-center pt-1">
                    …и ещё {skill.evidence.length - 20}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* === Actions === */}
          <div className="flex items-center gap-2 flex-wrap pt-1">
            <Button
              size="sm"
              variant="outline"
              onClick={loadProofs}
              disabled={loadingProofs}
              title="Почему именно такой level? Покажем конкретные проекты, подтверждения и результаты."
            >
              {loadingProofs ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : proofs ? (
                <ChevronDown className="size-3.5" />
              ) : (
                <Info className="size-3.5" />
              )}
              Почему {skill.currentLevel}?
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={loadExplain}
              disabled={loadingExplain}
            >
              {loadingExplain ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : explain ? (
                <ChevronDown className="size-3.5" />
              ) : (
                <TrendingUp className="size-3.5" />
              )}
              Как повысить?
            </Button>
            {(skill.decayStatus === 'stale' || skill.decayStatus === 'decayed') && (
              <Button
                size="sm"
                variant="outline"
                onClick={loadResurrect}
                disabled={loadingResurrect}
                className="border-amber-400/50 text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30"
              >
                {loadingResurrect ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <Sparkles className="size-3.5" />
                )}
                Восстановить
              </Button>
            )}
            {/* Phase 11: Mentor Graph — кнопка «Найти наставника» для currentLevel < 7 */}
            {needsMentor && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setView('mentor')}
                title={`Ваш уровень ${skill.currentLevel} < 7 — найдём ментора с peak >= 8 по «${skill.skillName}»`}
                className="border-blue-400/50 text-blue-700 dark:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-950/30"
              >
                <GraduationCap className="size-3.5" />
                Найти наставника
              </Button>
            )}
          </div>

          {/* === Next level requirements === */}
          {explain && (
            <div className="rounded-md border border-blue-200 dark:border-blue-900/50 bg-blue-50/50 dark:bg-blue-950/20 p-3">
              <div className="text-xs font-semibold flex items-center gap-1.5 mb-2 text-blue-700 dark:text-blue-300">
                <TrendingUp className="size-3.5" />
                Next level ({explain.currentLevel} → {Math.min(10, explain.currentLevel + 1)})
              </div>
              <div className="text-xs text-muted-foreground mb-2 tabular-nums">
                rawScore: {explain.rawScore.toFixed(1)} / 100
              </div>
              <ul className="space-y-1 text-xs">
                {explain.nextLevelRequirements.map((req, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="size-3.5 mt-0.5 text-blue-500 flex-shrink-0" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* === Resurrection path === */}
          {resurrect && (
            <div className="rounded-md border border-amber-300 dark:border-amber-900/50 bg-amber-50/50 dark:bg-amber-950/20 p-3">
              <div className="text-xs font-semibold flex items-center gap-1.5 mb-2 text-amber-700 dark:text-amber-300">
                <Sparkles className="size-3.5" />
                Маршрут восстановления
                <span className="text-xs font-normal text-muted-foreground ml-1">
                  {resurrect.currentLevel} → {resurrect.peakLevel} · ≈ {resurrect.estimatedTime}
                </span>
              </div>
              {resurrect.deltaLevels === 0 ? (
                <p className="text-xs text-muted-foreground">{resurrect.steps[0]}</p>
              ) : (
                <ol className="space-y-1.5 text-xs">
                  {resurrect.steps.map((step, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="flex-shrink-0 size-5 rounded-full bg-amber-500 text-white text-xs font-bold flex items-center justify-center tabular-nums">
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          )}

          {/* === Phase 6: Proof-of-Skill — drilldown «ПОЧЕМУ level X?» === */}
          {proofs && (
            <ProofsBlock proofs={proofs} currentLevel={skill.currentLevel} />
          )}
        </div>
      )}
    </div>
  );
}

// === Локальные мини-компоненты ===

// === Phase 6: Proof-of-Skill — блок drilldown «ПОЧЕМУ level X?» ===
//
// ASCII-tree визуализация (как в ТЗ):
//   Управление проектами — 8/10
//   ПОЧЕМУ 8?
//   ├── Проект: Green Energy (роль: руководитель, результат: +18%, подтверждён)
//   ├── Проект: Avito Delivery (роль: lead, результат: запуск, подтверждён)
//   ├── Подтверждение: Мария Иванова (2026-03)
//   └── Recommendation: Дмитрий Соколов (2025-11)
function ProofsBlock({
  proofs,
  currentLevel,
}: {
  proofs: ProofsResponse;
  currentLevel: number;
}) {
  const list = proofs.proofs;
  const stats = proofs.stats;

  return (
    <div className="rounded-md border border-emerald-300/60 dark:border-emerald-900/50 bg-emerald-50/40 dark:bg-emerald-950/10 p-3">
      {/* Header */}
      <div className="text-xs font-semibold flex items-center gap-1.5 mb-2 text-emerald-800 dark:text-emerald-300">
        <Info className="size-3.5" />
        ПОЧЕМУ {currentLevel}?
        <span className="text-xs font-normal text-muted-foreground ml-1">
          {stats.total} {pluralizeProofs(stats.total)} · {stats.verified} подтверждено
        </span>
      </div>

      {/* Empty state */}
      {list.length === 0 ? (
        <p className="text-xs text-muted-foreground leading-relaxed">
          Доказательств пока нет. Участвуйте в проектах с этим навыком и просите коллег
          подтвердить — уровень поднимется автоматически.
        </p>
      ) : (
        <ul className="space-y-1 text-xs font-mono">
          {list.slice(0, 30).map((p, i) => {
            const isLast = i === Math.min(list.length, 30) - 1;
            const glyph = isLast ? '└──' : '├──';
            const meta = PROOF_SOURCE_META[p.source];
            const statusMeta = PROOF_STATUS_META[p.status] ?? PROOF_STATUS_META.claimed;
            const Icon = meta.Icon;
            return (
              <li
                key={i}
                className="flex items-start gap-1.5 leading-snug break-words"
              >
                <span className="text-muted-foreground/70 select-none flex-shrink-0">
                  {glyph}
                </span>
                <Icon className="size-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <span className="font-sans font-medium">{meta.label}:</span>{' '}
                  {p.projectName && (
                    <span className="font-sans">
                      {p.projectName}
                      {p.role && <span className="text-muted-foreground"> (роль: {roleLabel(p.role)})</span>}
                      {p.result && <span className="text-muted-foreground"> · {p.result}</span>}
                    </span>
                  )}
                  {!p.projectName && p.verifier && (
                    <span className="font-sans">
                      {p.verifier}
                      {p.date && (
                        <span className="text-muted-foreground"> ({formatDate(p.date)})</span>
                      )}
                      {p.result && <span className="text-muted-foreground"> · {p.result}</span>}
                    </span>
                  )}
                  {!p.projectName && !p.verifier && p.result && (
                    <span className="font-sans text-muted-foreground">{p.result}</span>
                  )}
                  <span className={cn('ml-1 font-sans italic', statusMeta.className)}>
                    {statusMeta.label}
                  </span>
                  {p.confidence != null && (
                    <span className="ml-1 font-sans text-xs text-muted-foreground tabular-nums">
                      conf {(p.confidence * 100).toFixed(0)}%
                    </span>
                  )}
                </div>
              </li>
            );
          })}
          {list.length > 30 && (
            <li className="text-xs text-muted-foreground pl-6 pt-1">
              …и ещё {list.length - 30}
            </li>
          )}
        </ul>
      )}

      {/* Stats footer */}
      {list.length > 0 && (
        <div className="mt-2 pt-2 border-t border-emerald-200/50 dark:border-emerald-900/40 flex items-center gap-3 flex-wrap text-xs text-muted-foreground tabular-nums">
          <span>📦 {stats.projects} проект.</span>
          <span>✓ {stats.confirmations} подтвержд.</span>
          <span>🎯 {stats.results} резул.</span>
          <span>💬 {stats.recommendations} реком.</span>
          <span>📝 {stats.claims} заявл.</span>
        </div>
      )}
    </div>
  );
}

function pluralizeProofs(n: number): string {
  const lastTwo = n % 100;
  const last = n % 10;
  if (lastTwo >= 11 && lastTwo <= 14) return 'доказательств';
  if (last === 1) return 'доказательство';
  if (last >= 2 && last <= 4) return 'доказательства';
  return 'доказательств';
}

function roleLabel(role: string): string {
  const map: Record<string, string> = {
    FOUNDER: 'основатель',
    CO_FOUNDER: 'кофаундер',
    CONTRIBUTOR: 'участник',
    MENTOR: 'ментор',
    OBSERVER: 'наблюдатель',
    lead: 'lead',
    manager: 'manager',
  };
  return map[role] ?? role.toLowerCase();
}

function StatPill({
  label,
  value,
  hint,
  icon,
}: {
  label: string;
  value: number | string;
  hint?: string;
  icon?: string;
}) {
  return (
    <div className="rounded-md border bg-muted/20 px-2 py-1.5">
      <div className="text-xs text-muted-foreground uppercase tracking-wide flex items-center gap-1">
        {icon && <span>{icon}</span>}
        {label}
      </div>
      <div className="text-sm font-bold tabular-nums">
        {value}
        {hint && <span className="text-xs text-muted-foreground font-normal ml-1">{hint}</span>}
      </div>
    </div>
  );
}
