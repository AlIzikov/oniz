// BizON — GPT Truth Engine: TruthGapDisplay
// Отображение Truth Gap одного навыка: selfAssessment vs verifiedScore.
// - gap < 0 → красный «Переоценка на |gap| пунктов»
// - gap > 0 → зелёный «Недооценка на gap пунктов»
// - gap = 0 → серый «Точная самооценка»
// Кнопка «Оценить себя» открывает slider.
'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { TrendingDown, TrendingUp, Minus, Pencil, Loader2 } from 'lucide-react';

interface TruthGapDisplayProps {
  /** id навыка (UserSkill.id) — нужен для POST self-assessment */
  userSkillId?: string;
  /** Название навыка */
  skillName?: string;
  /** 0-100 — самооценка пользователя */
  selfAssessment: number | null;
  /** 0-100 — подтверждённый балл */
  verifiedScore: number | null;
  /** Опциональный callback при сохранении selfAssessment */
  onSaved?: (newValue: number) => void;
  className?: string;
}

function gapMeta(gap: number | null): {
  Icon: React.ComponentType<{ className?: string }>;
  color: string;
  bg: string;
  text: string;
} | null {
  if (gap === null) return null;
  if (gap < 0) {
    return {
      Icon: TrendingDown,
      color: 'text-red-600 dark:text-red-400',
      bg: 'bg-red-50 dark:bg-red-950/40',
      text: `Переоценка на ${Math.abs(gap)} пунктов`,
    };
  }
  if (gap > 0) {
    return {
      Icon: TrendingUp,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-50 dark:bg-emerald-950/40',
      text: `Недооценка на ${gap} пунктов`,
    };
  }
  return {
    Icon: Minus,
    color: 'text-muted-foreground',
    bg: 'bg-muted',
    text: 'Точная самооценка',
  };
}

export function TruthGapDisplay({
  userSkillId,
  skillName,
  selfAssessment,
  verifiedScore,
  onSaved,
  className,
}: TruthGapDisplayProps) {
  const [open, setOpen] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [draftValue, setDraftValue] = React.useState<number>(
    selfAssessment ?? 50
  );

  React.useEffect(() => {
    if (open) setDraftValue(selfAssessment ?? 50);
  }, [open, selfAssessment]);

  // truthGap = verifiedScore - selfAssessment
  const hasBoth = selfAssessment !== null && verifiedScore !== null;
  const gap = hasBoth ? (verifiedScore as number) - (selfAssessment as number) : null;
  const meta = gapMeta(gap);

  async function handleSave() {
    if (!userSkillId) {
      // Нет id — просто закрываем и зовём onSaved (локальный режим)
      onSaved?.(draftValue);
      setOpen(false);
      return;
    }
    setSubmitting(true);
    try {
      await api(`/api/skills/${userSkillId}/self-assessment`, {
        method: 'POST',
        body: JSON.stringify({ selfAssessment: draftValue }),
      });
      toast({ title: 'Самооценка сохранена' });
      onSaved?.(draftValue);
      setOpen(false);
    } catch (e: any) {
      toast({
        title: 'Не удалось сохранить',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className={cn('space-y-2', className)}>
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground">
          {skillName ? skillName : 'Навык'}
        </span>
        {meta && (
          <span
            className={cn(
              'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium',
              meta.bg,
              meta.color
            )}
          >
            <meta.Icon className="size-3" />
            {meta.text}
          </span>
        )}
      </div>

      {/* Бары: самооценка (точка) и verifiedScore (полоса) */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Self-assessment</span>
          <span className="font-medium tabular-nums">
            {selfAssessment ?? '—'}
          </span>
        </div>
        <Progress value={selfAssessment ?? 0} className="h-1.5" />

        <div className="flex items-center justify-between text-xs pt-1">
          <span className="text-muted-foreground">Verified score</span>
          <span className="font-medium tabular-nums">
            {verifiedScore ?? '—'}
          </span>
        </div>
        <Progress
          value={verifiedScore ?? 0}
          className="h-1.5 bg-emerald-100 dark:bg-emerald-950/40 [&_[data-slot=progress-indicator]]:bg-emerald-500"
        />
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button type="button" variant="outline" size="sm" className="w-full h-8">
            <Pencil className="size-3.5" />
            Оценить себя
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Оценить навык</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {skillName && (
              <p className="text-sm text-muted-foreground">{skillName}</p>
            )}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Ваша самооценка</span>
                <span className="text-2xl font-bold tabular-nums">
                  {draftValue}
                </span>
              </div>
              <Slider
                value={[draftValue]}
                onValueChange={(v) => setDraftValue(v[0] ?? 1)}
                min={1}
                max={100}
                step={1}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>1 — новичок</span>
                <span>100 — эксперт</span>
              </div>
            </div>
            <Button
              onClick={handleSave}
              disabled={submitting}
              className="w-full bg-emerald-600 text-white hover:bg-emerald-700"
            >
              {submitting ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Сохранение…
                </>
              ) : (
                'Сохранить'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
