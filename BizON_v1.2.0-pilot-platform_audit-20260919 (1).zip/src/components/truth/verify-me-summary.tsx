// BizON — GPT Truth Engine: VerifyMeSummary
// Сводка верификации для кнопки VERIFY ME.
// Загружает /api/reputation/evidence + использует user.stats из store для totals.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import {
  ShieldCheck,
  Award,
  FolderKanban,
  FileText,
  CheckCircle2,
  XCircle,
  Loader2,
  UserCircle,
} from 'lucide-react';

interface EvidenceResponse {
  userId: string;
  ipScore: number;
  level: string;
  evidence: {
    verifiedProjects: Array<{ id: string; title: string }>;
    verifiedSkills: Array<{ id: string; skill: string }>;
    recommendations: number;
    claims: { total: number; verified: number; pending: number };
  };
  evidenceCoverage: number;
}

interface VerifyMeSummaryProps {
  className?: string;
  /** Показывать заголовок (default true) */
  showHeader?: boolean;
  /** Загружать данные автоматически (default true). Если false — данные нужно передать через data */
  autoLoad?: boolean;
  /** Внешние данные (для использования внутри truth-profile, где данные уже есть) */
  data?: EvidenceResponse | null;
  loading?: boolean;
  /** Опционально: переопределить totals из user.stats (для чужого профиля) */
  userStats?: {
    skillsCount?: number;
    projectsCount?: number;
  };
}

function StatusLine({
  Icon,
  label,
  value,
  total,
}: {
  Icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  total: number;
}) {
  // ok: либо total>0 и value>=total, либо value>0 при отсутствии тотала (total=0)
  const ok = total > 0 ? value >= total : value > 0;
  const isZero = total === 0 && value === 0;
  return (
    <div className="flex items-center justify-between py-1.5 border-b last:border-0">
      <div className="flex items-center gap-2 min-w-0">
        <Icon className="size-4 text-muted-foreground shrink-0" />
        <span className="text-sm truncate">{label}</span>
      </div>
      <div className="flex items-center gap-1.5 shrink-0">
        <span className="text-sm font-semibold tabular-nums">
          {value}
          {total > 0 && (
            <span className="text-muted-foreground font-normal">/{total}</span>
          )}
        </span>
        {isZero ? (
          <XCircle className="size-4 text-muted-foreground/50" />
        ) : ok ? (
          <CheckCircle2 className="size-4 text-emerald-600" />
        ) : (
          <XCircle className="size-4 text-amber-500" />
        )}
      </div>
    </div>
  );
}

export function VerifyMeSummary({
  className,
  showHeader = true,
  autoLoad = true,
  data: externalData,
  loading: externalLoading,
  userStats,
}: VerifyMeSummaryProps) {
  const { user } = useAppStore();
  const [internalData, setInternalData] = React.useState<EvidenceResponse | null>(null);
  const [internalLoading, setInternalLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setInternalLoading(true);
    setError(null);
    try {
      const res = await api<EvidenceResponse>('/api/reputation/evidence');
      setInternalData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить сводку');
    } finally {
      setInternalLoading(false);
    }
  }, []);

  React.useEffect(() => {
    if (autoLoad && !externalData) {
      load();
    }
  }, [autoLoad, externalData, load]);

  const data = externalData ?? internalData;
  const loading = externalLoading ?? internalLoading;
  const coverage = data?.evidenceCoverage ?? 0;
  const isVerifiedPro = coverage > 0.8;

  const claimsTotal = data?.evidence.claims.total ?? 0;
  const claimsVerified = data?.evidence.claims.verified ?? 0;
  const projectsVerified = data?.evidence.verifiedProjects.length ?? 0;
  const skillsVerified = data?.evidence.verifiedSkills.length ?? 0;
  // totals: сначала берём из внешнего пропа userStats (для чужого профиля), иначе из store
  const skillsTotal = userStats?.skillsCount ?? user?.stats?.skillsCount ?? 0;
  const projectsTotal = userStats?.projectsCount ?? user?.stats?.projectsCount ?? 0;

  // Сколько ещё нужно подтвердить для статуса Verified Professional (>0.8 coverage)
  const needToVerify = claimsTotal > 0
    ? Math.max(0, Math.ceil(claimsTotal * 0.8) - claimsVerified)
    : 0;

  return (
    <div className={cn('rounded-xl border bg-card p-4 space-y-3', className)}>
      {showHeader && (
        <div className="flex items-center gap-2">
          <ShieldCheck className="size-5 text-emerald-600" />
          <h3 className="text-sm font-semibold">VERIFY ME</h3>
          {loading && <Loader2 className="size-3.5 animate-spin text-muted-foreground ml-auto" />}
        </div>
      )}

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-5 w-full" />
          <Skeleton className="h-5 w-full" />
          <Skeleton className="h-5 w-full" />
        </div>
      ) : error ? (
        <p className="text-sm text-destructive">{error}</p>
      ) : data ? (
        <>
          {/* Big badge */}
          <div
            className={cn(
              'rounded-lg p-3 text-center',
              isVerifiedPro
                ? 'bg-emerald-600 text-white'
                : 'bg-muted text-muted-foreground'
            )}
          >
            <div className="flex items-center justify-center gap-1.5">
              <ShieldCheck className="size-5" />
              <span className="text-sm font-bold tracking-wide">
                {isVerifiedPro
                  ? 'VERIFIED PROFESSIONAL'
                  : 'НЕ ВЕРИФИЦИРОВАН'}
              </span>
            </div>
            {!isVerifiedPro && (
              <p className="text-xs mt-1 opacity-90">
                {needToVerify > 0
                  ? `Подтвердите ещё ${needToVerify} утверждени${needToVerify === 1 ? 'е' : needToVerify < 5 ? 'я' : 'й'} для статуса Verified Professional`
                  : 'Добавьте и подтвердите утверждения для статуса Verified Professional'}
              </p>
            )}
            {isVerifiedPro && (
              <p className="text-xs mt-1 opacity-90">
                Подтверждено: {Math.round(coverage * 100)}%
              </p>
            )}
          </div>

          {/* Status lines */}
          <div>
            <StatusLine
              Icon={UserCircle}
              label="Личность"
              value={1}
              total={1}
            />
            <StatusLine
              Icon={Award}
              label="Навыки"
              value={skillsVerified}
              total={skillsTotal}
            />
            <StatusLine
              Icon={FolderKanban}
              label="Проекты"
              value={projectsVerified}
              total={projectsTotal}
            />
            <StatusLine
              Icon={FileText}
              label="Утверждения"
              value={claimsVerified}
              total={claimsTotal}
            />
          </div>
        </>
      ) : null}
    </div>
  );
}
