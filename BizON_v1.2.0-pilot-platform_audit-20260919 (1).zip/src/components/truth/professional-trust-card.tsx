// BizON v6 — Professional Trust Card (doc_a §41)
// Карточка 6-факторного Professional Trust:
//   score = EvidenceQuality × Verification × Outcome × Recency × Independence × Consistency.
// Принцип «Экспертиза ≠ активность»: активность и связи в формуле не участвуют.
// Данные: GET /api/me/professional-trust (кэш 24ч), POST — принудительный пересчёт.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { ShieldCheck, RefreshCw, FileQuestion, Loader2 } from 'lucide-react';

type TrustFactorKey =
  | 'evidenceQuality'
  | 'verification'
  | 'outcome'
  | 'recency'
  | 'independence'
  | 'consistency';

interface TrustResponse {
  score: number;
  factors: Record<TrustFactorKey, number>;
  explanations: Record<TrustFactorKey, string>;
  summary: string;
  formulaVersion: string;
  computedAt: string;
}

/** Русские названия факторов + подсказки «что это значит». */
const FACTOR_META: Array<{
  key: TrustFactorKey;
  label: string;
  hint: string;
}> = [
  { key: 'evidenceQuality', label: 'Качество доказательств', hint: 'Полнота STAR: роль, ответственность, действие, результат + уверенность AI' },
  { key: 'verification', label: 'Верификация', hint: 'Уровень проверки: claimed → verified → project_verified → expert_verified' },
  { key: 'outcome', label: 'Результаты', hint: 'Измеримые результаты в доказательствах и завершённые проекты' },
  { key: 'recency', label: 'Актуальность', hint: 'Свежесть доказательств: вес убывает со временем' },
  { key: 'independence', label: 'Независимость', hint: 'Сколько разных людей подтвердили — не один и тот же верификатор' },
  { key: 'consistency', label: 'Согласованность', hint: 'Нет противоречий во времени, навыки подтверждаются многократно' },
];

function scoreTone(score: number): { text: string; bar: string } {
  if (score >= 66) {
    return {
      text: 'text-emerald-600 dark:text-emerald-400',
      bar: 'bg-emerald-100 dark:bg-emerald-950/40 [&_[data-slot=progress-indicator]]:bg-emerald-500',
    };
  }
  if (score >= 33) {
    return {
      text: 'text-amber-600 dark:text-amber-400',
      bar: 'bg-amber-100 dark:bg-amber-950/40 [&_[data-slot=progress-indicator]]:bg-amber-500',
    };
  }
  return {
    text: 'text-red-600 dark:text-red-400',
    bar: 'bg-red-100 dark:bg-red-950/40 [&_[data-slot=progress-indicator]]:bg-red-500',
  };
}

export function ProfessionalTrustCard({ className }: { className?: string }) {
  const [data, setData] = React.useState<TrustResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<TrustResponse>('/api/me/professional-trust');
      setData(res);
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : 'Не удалось загрузить';
      toast({ title: 'Professional Trust', description: message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    void load();
  }, [load]);

  async function handleRecompute() {
    setRefreshing(true);
    try {
      const res = await api<TrustResponse>('/api/me/professional-trust', { method: 'POST' });
      setData(res);
      toast({ title: 'Professional Trust пересчитан' });
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : 'Не удалось пересчитать';
      toast({ title: 'Professional Trust', description: message, variant: 'destructive' });
    } finally {
      setRefreshing(false);
    }
  }

  return (
    <Card className={cn(className)}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2">
            <ShieldCheck className="size-4 text-emerald-600" />
            <span>
              Professional Trust
              <span className="block text-xs font-normal text-muted-foreground">
                Экспертиза ≠ активность: формула из 6 факторов
              </span>
            </span>
          </span>
          <span className="flex items-center gap-2">
            {data && (
              <Badge variant="outline" className="text-xs font-normal text-muted-foreground">
                формула {data.formulaVersion}
              </Badge>
            )}
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-7"
              onClick={handleRecompute}
              disabled={refreshing || loading}
              aria-label="Пересчитать Professional Trust"
              title="Пересчитать Professional Trust"
            >
              {refreshing ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <RefreshCw className="size-3.5" />
              )}
            </Button>
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-28" />
            <Skeleton className="h-2 w-full" />
            <Skeleton className="h-2 w-full" />
            <Skeleton className="h-2 w-full" />
          </div>
        ) : data ? (
          data.score === 0 ? (
            <div className="text-center py-6">
              <FileQuestion className="size-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium">Нет профессиональных доказательств</p>
              <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
                Добавьте доказательства опыта (PROVE IT) с ролью, действиями и измеримым
                результатом, получите подтверждения коллег — формула учтёт их автоматически.
                Активность в ленте и число связей на балл не влияют.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-end gap-3">
                <span className={cn('text-4xl font-bold tabular-nums leading-none', scoreTone(data.score).text)}>
                  {data.score}
                </span>
                <span className="text-sm text-muted-foreground mb-0.5">/ 100</span>
                {data.summary && (
                  <span className="text-xs text-muted-foreground mb-0.5 ml-auto text-right max-w-[55%]">
                    {data.summary}
                  </span>
                )}
              </div>

              <div className="space-y-2.5">
                {FACTOR_META.map(({ key, label, hint }) => {
                  const value = data.factors[key];
                  const explanation = data.explanations[key];
                  return (
                    <div key={key}>
                      <div className="flex items-center justify-between gap-2 text-xs">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="cursor-help underline decoration-dotted underline-offset-2">
                              {label}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-64 whitespace-normal">
                            <span className="block font-medium">{hint}</span>
                            {explanation && <span className="block mt-1 opacity-80">{explanation}</span>}
                          </TooltipContent>
                        </Tooltip>
                        <span className="font-medium tabular-nums">
                          {Math.round(value * 100)}%
                        </span>
                      </div>
                      <Progress
                        value={Math.round(value * 100)}
                        className={cn('mt-1 h-1.5', scoreTone(value * 100).bar)}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          )
        ) : null}
      </CardContent>
    </Card>
  );
}
