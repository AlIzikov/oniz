// BizON — NextBestActionCard (P0: «Что сделать сейчас»)
//
// Карточка предлагает одно конкретное действие для пользователя:
//   ┌────────────────────────────────────────────────────────┐
//   │ 🎯 Ваше следующее действие                             │
//   │                                                        │
//   │ Подтвердите навык «React» через PROVE IT                │
//   │ Вы заявили навык, но он ещё не подтверждён. Запустите   │
//   │ PROVE IT — пошаговый челлендж докажет вашу экспертность. │
//   │                                                        │
//   │ 💪 +15 Trust Score · бейдж VERIFIED                    │
//   │                                                        │
//   │ [Выполнить →]                                          │
//   └────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/next-best-action
// Действие: кнопка «Выполнить» → переход по deeplink (формат view:<name>?<query>)
// Если action === null — карточка не рендерится.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Target,
  ShieldCheck,
  FolderKanban,
  TrendingUp,
  Briefcase,
  Rocket,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { NextBestActionType } from '@/lib/services/next-best-action-service';

// ============================================================================
// === Типы данных ===
// ============================================================================

interface NextBestAction {
  action: NextBestActionType;
  title: string;
  description: string;
  deeplink: string;
  expectedImpact: string;
  meta?: Record<string, string | number | null>;
}

interface NextBestActionResponse {
  action: NextBestAction | null;
  generatedAt: string;
}

// ============================================================================
// === Мета по типам действий: иконка + цвет + лейбл ===
// ============================================================================

const ACTION_META: Record<
  NextBestActionType,
  { icon: React.ReactNode; label: string; accent: string; bg: string }
> = {
  verify_skill: {
    icon: <ShieldCheck className="w-4 h-4" />,
    label: 'Подтверждение навыка',
    accent: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  confirm_project: {
    icon: <FolderKanban className="w-4 h-4" />,
    label: 'Подтверждение проекта',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
  resurrect_skill: {
    icon: <TrendingUp className="w-4 h-4" />,
    label: 'Восстановление навыка',
    accent: 'text-rose-600 dark:text-rose-400',
    bg: 'bg-rose-500/10',
  },
  apply_job: {
    icon: <Briefcase className="w-4 h-4" />,
    label: 'Отклик на вакансию',
    accent: 'text-sky-600 dark:text-sky-400',
    bg: 'bg-sky-500/10',
  },
  create_project: {
    icon: <Rocket className="w-4 h-4" />,
    label: 'Создание проекта',
    accent: 'text-violet-600 dark:text-violet-400',
    bg: 'bg-violet-500/10',
  },
};

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function NextBestActionCard() {
  const { setView } = useAppStore();
  const [data, setData] = React.useState<NextBestActionResponse | null>(null);
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<NextBestActionResponse>('/api/me/next-best-action');
      setData(res);
    } catch (e: any) {
      console.error('[NextBestActionCard] load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  // ============================================================
  // Loading state
  // ============================================================
  if (loading) {
    return (
      <Card className="border-lighthouse/20">
        <CardContent className="p-5">
          <Skeleton className="h-5 w-1/2 mb-3" />
          <Skeleton className="h-4 w-full mb-2" />
          <Skeleton className="h-4 w-2/3 mb-3" />
          <Skeleton className="h-8 w-32" />
        </CardContent>
      </Card>
    );
  }

  // ============================================================
  // Нет действия — карточка не показывается
  // ============================================================
  if (!data || !data.action) {
    return null;
  }

  const action = data.action;
  const meta = ACTION_META[action.action];

  // Парсинг deeplink: формат «view:<name>» или «view:<name>?<query>»
  function handleExecute() {
    const link = action.deeplink;
    if (!link.startsWith('view:')) return;
    const rest = link.slice('view:'.length);
    const [viewName, queryString] = rest.split('?');
    // Дополнительные query-параметры пока только записываем в URL hash для экранов,
    // которые их понимают (truth?resurrect=, projects?action=create, jobs?jobId=).
    // Базовое действие — переключение view.
    if (queryString) {
      // Сохраняем query в sessionStorage, чтобы целевой экран мог прочитать
      try {
        sessionStorage.setItem(`bizon:deeplink:${viewName}`, queryString);
      } catch {}
    }
    setView(viewName as any);
  }

  return (
    <Card className="border-lighthouse/30 bg-gradient-to-br from-lighthouse/5 via-transparent to-lighthouse/5 overflow-hidden">
      <CardContent className="p-5">
        {/* Шапка */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-lighthouse font-semibold">
            <Target className="w-3.5 h-3.5" />
            Ваше следующее действие
          </div>
          <span
            className={cn(
              'inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wider',
              meta.bg,
              meta.accent,
            )}
          >
            {meta.icon}
            {meta.label}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-base sm:text-lg leading-snug font-semibold text-foreground mb-1.5">
          {action.title}
        </h3>

        {/* Description */}
        <p className="text-sm text-muted-foreground leading-relaxed mb-3">
          {action.description}
        </p>

        {/* Expected impact */}
        <div className="flex items-start gap-1.5 p-2 rounded-md bg-emerald-500/5 border border-emerald-500/10 mb-4">
          <Zap className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-xs uppercase tracking-wider text-emerald-700 dark:text-emerald-300 font-semibold">
              Ожидаемый эффект
            </div>
            <div className="text-xs text-foreground/80">{action.expectedImpact}</div>
          </div>
        </div>

        {/* Action button */}
        <Button
          onClick={handleExecute}
          className="w-full sm:w-auto"
          size="sm"
        >
          Выполнить
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </CardContent>
    </Card>
  );
}
