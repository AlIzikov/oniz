// BizON — GPT Truth Engine: StatusBadge
// Универсальный бейдж для 4 уровней доказательности:
// 🟡 CLAIMED → 🔵 VERIFIED → 🟢 PROJECT_VERIFIED → 🟣 EXPERT_VERIFIED
'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';
import { ShieldCheck, BadgeCheck, FolderKanban, Star } from 'lucide-react';

export type TruthLevel =
  | 'claimed'
  | 'verified'
  | 'project_verified'
  | 'expert_verified';

interface StatusBadgeProps {
  level: TruthLevel | string;
  size?: 'sm' | 'md';
  className?: string;
  /** Показывать иконку (default true) */
  icon?: boolean;
}

const CONFIG: Record<
  TruthLevel,
  {
    label: string;
    dot: string;
    text: string;
    bg: string;
    border: string;
    Icon: React.ComponentType<{ className?: string }>;
  }
> = {
  claimed: {
    label: 'Заявлено',
    dot: 'bg-amber-400',
    text: 'text-amber-700 dark:text-amber-300',
    bg: 'bg-amber-50 dark:bg-amber-950/40',
    border: 'border-amber-200 dark:border-amber-800',
    Icon: ShieldCheck,
  },
  verified: {
    label: 'Подтверждено',
    dot: 'bg-blue-500',
    text: 'text-blue-700 dark:text-blue-300',
    bg: 'bg-blue-50 dark:bg-blue-950/40',
    border: 'border-blue-200 dark:border-blue-800',
    Icon: BadgeCheck,
  },
  project_verified: {
    label: 'Через проект',
    dot: 'bg-emerald-500',
    text: 'text-emerald-700 dark:text-emerald-300',
    bg: 'bg-emerald-50 dark:bg-emerald-950/40',
    border: 'border-emerald-200 dark:border-emerald-800',
    Icon: FolderKanban,
  },
  expert_verified: {
    label: 'Эксперт',
    dot: 'bg-purple-500',
    text: 'text-purple-700 dark:text-purple-300',
    bg: 'bg-purple-50 dark:bg-purple-950/40',
    border: 'border-purple-200 dark:border-purple-800',
    Icon: Star,
  },
};

const SIZE = {
  sm: 'text-xs px-1.5 py-0.5 gap-1 [&_svg]:size-2.5',
  md: 'text-xs px-2 py-0.5 gap-1.5 [&_svg]:size-3',
};

export function StatusBadge({
  level,
  size = 'md',
  className,
  icon = true,
}: StatusBadgeProps) {
  const lvl = (level as TruthLevel) in CONFIG ? (level as TruthLevel) : 'claimed';
  const cfg = CONFIG[lvl];
  const { Icon } = cfg;

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border font-medium whitespace-nowrap',
        cfg.bg,
        cfg.border,
        cfg.text,
        SIZE[size],
        className
      )}
    >
      {icon && <Icon className={cfg.text} />}
      <span className={cn('rounded-full', size === 'sm' ? 'w-1.5 h-1.5' : 'w-2 h-2', cfg.dot)} />
      <span>{cfg.label}</span>
    </span>
  );
}
