// BizON — GPT Truth Engine: ClaimForm
// Форма создания нового Claim → POST /api/claims → toast → onSuccess.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

export type ClaimType =
  | 'skill'
  | 'experience'
  | 'achievement'
  | 'role'
  | 'result';

const TYPE_OPTIONS: { value: ClaimType; label: string }[] = [
  { value: 'skill', label: 'Навык' },
  { value: 'experience', label: 'Опыт' },
  { value: 'achievement', label: 'Достижение' },
  { value: 'role', label: 'Роль' },
  { value: 'result', label: 'Результат' },
];

interface ClaimFormProps {
  /** Опциональная предустановка projectId/skillId (если форма открыта из контекста проекта/навыка) */
  projectId?: string;
  skillId?: string;
  /** Callback после успешного создания */
  onSuccess?: (claim: unknown) => void;
  /** Кастомизация кнопки submit */
  submitLabel?: string;
  loadingLabel?: string;
  /** Внешнее управление submitting-состоянием (опционально) */
  submitting?: boolean;
  setSubmitting?: (v: boolean) => void;
  className?: string;
  /** Скрыть кнопку (для использования вне формы — не нужно) */
  hideSubmit?: boolean;
}

export function ClaimForm({
  projectId,
  skillId,
  onSuccess,
  submitLabel = 'Создать',
  loadingLabel = 'Создаём…',
  submitting: externalSubmitting,
  setSubmitting: externalSetSubmitting,
  className,
  hideSubmit = false,
}: ClaimFormProps) {
  const [internalSubmitting, setInternalSubmitting] = React.useState(false);
  const submitting = externalSubmitting ?? internalSubmitting;
  const setSubmitting = externalSetSubmitting ?? setInternalSubmitting;

  const [type, setType] = React.useState<ClaimType>('skill');
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [titleError, setTitleError] = React.useState<string | null>(null);

  function validateTitle(v: string): string | null {
    const trimmed = v.trim();
    if (trimmed.length === 0) return 'Введите текст заявления (1-200 символов)';
    if (trimmed.length > 200) return 'Не более 200 символов';
    return null;
  }

  function onTitleChange(v: string) {
    setTitle(v);
    if (titleError) setTitleError(null);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const err = validateTitle(title);
    if (err) {
      setTitleError(err);
      return;
    }

    setSubmitting(true);
    try {
      const res = await api<{ claim: unknown }>('/api/claims', {
        method: 'POST',
        body: JSON.stringify({
          type,
          title: title.trim(),
          description: description.trim() || null,
          projectId: projectId ?? null,
          skillId: skillId ?? null,
        }),
      });
      toast({
        title: 'Claim создан',
        description: 'Попросите коллег его подтвердить, чтобы повысить уровень.',
      });
      // Сброс формы
      setTitle('');
      setDescription('');
      setType('skill');
      onSuccess?.(res.claim);
    } catch (e: any) {
      toast({
        title: 'Не удалось создать claim',
        description: e?.message ?? 'Попробуйте ещё раз',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className={cn('space-y-3', className)}>
      <div className="space-y-1.5">
        <Label htmlFor="claim-type">Тип</Label>
        <Select
          value={type}
          onValueChange={(v) => setType(v as ClaimType)}
          disabled={submitting}
        >
          <SelectTrigger id="claim-type" className="w-full">
            <SelectValue placeholder="Выберите тип" />
          </SelectTrigger>
          <SelectContent>
            {TYPE_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="claim-title">Заявление</Label>
        <Input
          id="claim-title"
          value={title}
          onChange={(e) => onTitleChange(e.target.value)}
          placeholder="Например: «Управлял командой 50 человек»"
          maxLength={200}
          disabled={submitting}
          aria-invalid={!!titleError}
        />
        <div className="flex items-center justify-between text-xs">
          <span
            className={cn(
              'text-muted-foreground',
              titleError && 'text-destructive font-medium'
            )}
          >
            {titleError ?? '1–200 символов'}
          </span>
          <span className="text-muted-foreground tabular-nums">
            {title.length}/200
          </span>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="claim-description">
          Описание{' '}
          <span className="text-muted-foreground font-normal">(опционально)</span>
        </Label>
        <Textarea
          id="claim-description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Контекст, детали, ссылки…"
          maxLength={5000}
          disabled={submitting}
          className="min-h-20"
        />
      </div>

      {!hideSubmit && (
        <Button
          type="submit"
          disabled={submitting || title.trim().length === 0}
          className="w-full bg-emerald-600 text-white hover:bg-emerald-700"
        >
          {submitting ? (
            <>
              <Loader2 className="size-4 animate-spin" />
              {loadingLabel}
            </>
          ) : (
            <>
              <Plus className="size-4" />
              {submitLabel}
            </>
          )}
        </Button>
      )}
    </form>
  );
}
