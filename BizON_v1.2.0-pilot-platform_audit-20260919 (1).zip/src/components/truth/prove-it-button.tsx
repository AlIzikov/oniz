// BizON — GPT Truth Engine: ProveItButton
// Кнопка «PROVE IT» — открывает Dialog с контекстом верификации навыка или создания claim.
'use client';

import * as React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ShieldCheck, FolderKanban, UserPlus } from 'lucide-react';
import { useAppStore } from '@/stores/app-store';
import { cn } from '@/lib/utils';
import { ClaimForm } from '@/components/truth/claim-form';

type ProveType = 'skill' | 'claim';

interface ProveItButtonProps {
  type: ProveType;
  /** Опциональный className для триггера */
  className?: string;
  /** Опциональный размер кнопки */
  size?: 'sm' | 'default' | 'lg';
  /** Опциональный label для кнопки */
  label?: string;
  /** Callback после успешного создания claim (только для type='claim') */
  onClaimCreated?: () => void;
  /** Опциональный projectId/skillId для предустановки в форме */
  projectId?: string;
  skillId?: string;
}

export function ProveItButton({
  type,
  className,
  size = 'sm',
  label = 'PROVE IT',
  onClaimCreated,
  projectId,
  skillId,
}: ProveItButtonProps) {
  const [open, setOpen] = React.useState(false);
  const { setView } = useAppStore();

  // === type='skill': навигация на проекты / network ===
  function goToProjects() {
    setOpen(false);
    setView('projects');
  }
  function goToNetwork() {
    setOpen(false);
    setView('network');
  }

  // === type='claim': форма внутри (использует ClaimForm) ===
  function handleClaimCreated() {
    setOpen(false);
    onClaimCreated?.();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          type="button"
          size={size}
          className={cn(
            'bg-emerald-600 text-white hover:bg-emerald-700',
            'shadow-sm font-semibold tracking-wide',
            className
          )}
        >
          <ShieldCheck className="size-4" />
          {label}
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="size-5 text-emerald-600" />
            {type === 'skill' ? 'Подтвердить навык' : 'Создать утверждение'}
          </DialogTitle>
        </DialogHeader>

        {type === 'skill' ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Добавьте проект или попросите коллегу подтвердить этот навык.
              Чем больше подтверждений — тем выше уровень доказательности.
            </p>
            <div className="grid grid-cols-1 gap-2">
              <Button
                onClick={goToProjects}
                className="bg-emerald-600 text-white hover:bg-emerald-700 justify-start"
              >
                <FolderKanban className="size-4" />
                Добавить проект
              </Button>
              <Button
                onClick={goToNetwork}
                variant="outline"
                className="justify-start"
              >
                <UserPlus className="size-4" />
                Запросить подтверждение
              </Button>
            </div>
          </div>
        ) : (
          <ClaimForm
            projectId={projectId}
            skillId={skillId}
            onSuccess={handleClaimCreated}
            submitLabel="Создать claim"
            loadingLabel="Создаём…"
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
