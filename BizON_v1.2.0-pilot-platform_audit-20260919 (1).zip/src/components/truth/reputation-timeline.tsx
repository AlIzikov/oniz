// BizON — Reputation Timeline: SVG line-chart динамики IP-score
// Источник: /api/reputation/snapshots (последние 30, по возрастанию даты)
// Чистый SVG (без Chart.js) — легче, быстрее, ноль зависимостей.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Snapshot {
  id: string;
  ipScore: number;
  level: string;
  createdAt: string;
}

interface SnapshotsResponse {
  snapshots: Snapshot[];
}

// Размеры SVG-холста (viewBox). Реальный размер — 100% ширины.
const W = 640;
const H = 220;
const PAD_X = 40;
const PAD_TOP = 16;
const PAD_BOTTOM = 28;

export function ReputationTimeline({ className }: { className?: string }) {
  const [snapshots, setSnapshots] = React.useState<Snapshot[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<SnapshotsResponse>('/api/reputation/snapshots').catch(
        () => ({ snapshots: [] as Snapshot[] }),
      );
      // API возвращает desc (новейшие первыми). Для графика нужно по возрастанию даты.
      const sorted = [...(res.snapshots || [])].sort(
        (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
      );
      setSnapshots(sorted);
    } catch (e) {
      console.error('[reputation-timeline] load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <Card className={className}>
        <CardContent className="p-4">
          <Skeleton className="h-5 w-56 mb-3" />
          <Skeleton className="h-[220px] w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  // Недостаточно данных — показываем пустое состояние.
  if (snapshots.length < 2) {
    return (
      <Card className={className}>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/10 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-emerald-600 dark:text-emerald-500" />
            </div>
            <div className="text-sm font-semibold">Динамика вашей репутации</div>
          </div>
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <div className="text-3xl mb-2">📈</div>
            <p className="text-sm text-muted-foreground max-w-xs">
              Недостаточно данных для графика. Возвращайтесь завтра.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // === Расчёт координат линии ===
  const n = snapshots.length;
  const xFor = (i: number) =>
    PAD_X + (i / Math.max(1, n - 1)) * (W - PAD_X - 16);
  const yFor = (score: number) =>
    PAD_TOP + (1 - score / 100) * (H - PAD_TOP - PAD_BOTTOM);

  // Точки графика
  const points = snapshots.map((s, i) => ({
    x: xFor(i),
    y: yFor(s.ipScore),
    snapshot: s,
  }));

  // Path для линии (M x0 y0 L x1 y1 ...)
  const linePath = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
    .join(' ');

  // Path для заливки под линией (Area)
  const areaPath =
    `M ${points[0].x.toFixed(1)} ${(H - PAD_BOTTOM).toFixed(1)} ` +
    points.map((p) => `L ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ') +
    ` L ${points[n - 1].x.toFixed(1)} ${(H - PAD_BOTTOM).toFixed(1)} Z`;

  // Сетка Y: 0, 25, 50, 75, 100
  const yTicks = [0, 25, 50, 75, 100];

  // Метки X: показываем ~5-6 равномерно распределённых дат
  const xLabelCount = Math.min(6, n);
  const xLabelIndexes = Array.from({ length: xLabelCount }, (_, i) =>
    Math.round((i * (n - 1)) / Math.max(1, xLabelCount - 1)),
  );

  // Дельта за период (последний − первый)
  const delta = snapshots[n - 1].ipScore - snapshots[0].ipScore;
  const deltaColor =
    delta > 0
      ? 'text-emerald-600 dark:text-emerald-500'
      : delta < 0
        ? 'text-red-600 dark:text-red-500'
        : 'text-muted-foreground';
  const DeltaIcon = delta > 0 ? ArrowUp : delta < 0 ? ArrowDown : Minus;

  // Hovered point
  const hovered = hoverIdx !== null ? points[hoverIdx] : null;

  function fmtDate(iso: string): string {
    return new Date(iso).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'short',
    });
  }

  return (
    <Card className={className}>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-600/10 flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-emerald-600 dark:text-emerald-500" />
          </div>
          <div>
            <div className="text-sm font-semibold">Динамика вашей репутации</div>
            <div className="text-xs text-muted-foreground">
              IP-score за последние {n} {pluralDays(n)}
            </div>
          </div>
        </div>

        {/* SVG график */}
        <div className="relative w-full">
          <svg
            viewBox={`0 0 ${W} ${H}`}
            className="w-full h-auto"
            role="img"
            aria-label="График IP-score"
            preserveAspectRatio="none"
          >
            {/* Градиент для заливки под линией */}
            <defs>
              <linearGradient id="rep-timeline-grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Горизонтальная сетка */}
            {yTicks.map((tick) => {
              const y = yFor(tick);
              return (
                <g key={tick}>
                  <line
                    x1={PAD_X}
                    y1={y}
                    x2={W - 16}
                    y2={y}
                    stroke="currentColor"
                    strokeOpacity="0.1"
                    strokeWidth="1"
                  />
                  <text
                    x={PAD_X - 6}
                    y={y + 3}
                    textAnchor="end"
                    className="fill-muted-foreground"
                    fontSize="10"
                  >
                    {tick}
                  </text>
                </g>
              );
            })}

            {/* Заливка area */}
            <path d={areaPath} fill="url(#rep-timeline-grad)" />

            {/* Линия */}
            <path
              d={linePath}
              fill="none"
              stroke="#10b981"
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
            />

            {/* Точки */}
            {points.map((p, i) => (
              <g key={p.snapshot.id}>
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={hoverIdx === i ? 5 : 3}
                  fill="#10b981"
                  stroke="white"
                  strokeWidth="1.5"
                  className="transition-all cursor-pointer"
                  onMouseEnter={() => setHoverIdx(i)}
                  onMouseLeave={() => setHoverIdx(null)}
                />
                {/* Невидимый больший круг для удобного hover */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={12}
                  fill="transparent"
                  className="cursor-pointer"
                  onMouseEnter={() => setHoverIdx(i)}
                  onMouseLeave={() => setHoverIdx(null)}
                />
              </g>
            ))}

            {/* Метки X (даты) */}
            {xLabelIndexes.map((idx) => {
              const p = points[idx];
              return (
                <text
                  key={`x-${idx}`}
                  x={p.x}
                  y={H - 8}
                  textAnchor="middle"
                  className="fill-muted-foreground"
                  fontSize="10"
                >
                  {fmtDate(p.snapshot.createdAt)}
                </text>
              );
            })}

            {/* Tooltip при hover */}
            {hovered && (
              <g pointerEvents="none">
                {(() => {
                  const tx = hovered.x;
                  const ty = hovered.y;
                  const tooltipW = 96;
                  const tooltipH = 38;
                  // Не вылезаем за правый край
                  const bx =
                    tx + tooltipW + 8 > W ? tx - tooltipW - 8 : tx + 8;
                  const by = Math.max(PAD_TOP, ty - tooltipH - 4);
                  return (
                    <>
                      <rect
                        x={bx}
                        y={by}
                        width={tooltipW}
                        height={tooltipH}
                        rx="6"
                        fill="hsl(var(--popover, 0 0% 100%))"
                        stroke="currentColor"
                        strokeOpacity="0.15"
                        className="text-foreground"
                      />
                      <text
                        x={bx + 8}
                        y={by + 15}
                        className="fill-foreground"
                        fontSize="10"
                        fontWeight="600"
                      >
                        {fmtDate(hovered.snapshot.createdAt)}
                      </text>
                      <text
                        x={bx + 8}
                        y={by + 30}
                        className="fill-emerald-600"
                        fontSize="11"
                        fontWeight="700"
                      >
                        IP-score: {hovered.snapshot.ipScore}
                      </text>
                    </>
                  );
                })()}
              </g>
            )}
          </svg>
        </div>

        {/* Изменение за период */}
        <div className="mt-3 flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Изменение за период:</span>
          <span className={cn('inline-flex items-center gap-1 font-semibold', deltaColor)}>
            <DeltaIcon className="w-3.5 h-3.5" />
            {delta > 0 ? '+' : ''}
            {delta} пунктов
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

// Плюрализация для «дней»
function pluralDays(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'день';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'дня';
  return 'дней';
}
