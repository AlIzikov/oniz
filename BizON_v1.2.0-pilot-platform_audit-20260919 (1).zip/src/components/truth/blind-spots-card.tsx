// BizON — BlindSpotsCard (P0: «Слепые зоны»)
//
// Карточка показывает недооценённые сильные стороны пользователя:
//   ┌────────────────────────────────────────────────────────┐
//   │ ✨ BizON обнаружил ваши скрытые сильные стороны         │
//   │                                                        │
//   │ ▸ Вы оцениваете «React» на 5, но ваши проекты показывают 8 │
//   │   ▼ Посмотреть доказательства                          │
//   │     • Skill «React»: ваша самооценка — 50 из 100.      │
//   │     • Подтверждённый балл — 75 из 100 (разрыв +25).    │
//   │     • Подтверждён 3 коллегами в 2 проектах.            │
//   │                                                        │
//   │ ▸ Вы называете себя «инженером», но в 4 из 5 проектов  │
//   │   вы — основатель. По факту вы лид.                    │
//   └────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/blind-spots
// Если spots пустой — карточка не рендерится.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Sparkles,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  Target,
  Wrench,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы данных ===
// ============================================================================

interface BlindSpot {
  type: 'skill_gap' | 'role_mismatch';
  skillName: string;
  selfLevel: number | null;
  verifiedLevel: number;
  gap: number;
  evidence: string[];
  insight: string;
}

interface BlindSpotsResponse {
  spots: BlindSpot[];
  generatedAt: string;
}

// ============================================================================
// === Мета по типам слепых зон ===
// ============================================================================

const TYPE_META: Record<
  BlindSpot['type'],
  { icon: React.ReactNode; label: string; accent: string }
> = {
  skill_gap: {
    icon: <TrendingUp className="w-3.5 h-3.5" />,
    label: 'Недооценённый навык',
    accent: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
  },
  role_mismatch: {
    icon: <Target className="w-3.5 h-3.5" />,
    label: 'Скрытая роль',
    accent: 'text-violet-600 dark:text-violet-400 bg-violet-500/10',
  },
};

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function BlindSpotsCard() {
  const [data, setData] = React.useState<BlindSpotsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [expandedIdx, setExpandedIdx] = React.useState<number | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<BlindSpotsResponse>('/api/me/blind-spots');
      setData(res);
    } catch (e: any) {
      console.error('[BlindSpotsCard] load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  // ============================================================
  // Loading state
  // ============================================================
  if (loading) {
    return (
      <Card className="border-emerald-500/20">
        <CardContent className="p-5">
          <Skeleton className="h-5 w-2/3 mb-3" />
          <Skeleton className="h-16 w-full mb-3" />
          <Skeleton className="h-6 w-1/3" />
        </CardContent>
      </Card>
    );
  }

  // ============================================================
  // Нет слепых зон — карточка не показывается
  // ============================================================
  if (!data || data.spots.length === 0) {
    return null;
  }

  const spots = data.spots;

  return (
    <Card className="border-emerald-500/30 bg-gradient-to-br from-emerald-500/5 via-transparent to-emerald-500/5 overflow-hidden">
      <CardContent className="p-5">
        {/* Шапка */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-emerald-600 dark:text-emerald-400 font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            BizON обнаружил ваши скрытые сильные стороны
          </div>
          <Badge variant="secondary" className="text-xs">
            {spots.length} {pluralSpots(spots.length)}
          </Badge>
        </div>

        {/* Список слепых зон */}
        <ul className="space-y-3">
          {spots.map((spot, idx) => {
            const meta = TYPE_META[spot.type];
            const isExpanded = expandedIdx === idx;
            return (
              <li
                key={`${spot.type}-${idx}`}
                className="rounded-lg border border-border/60 bg-card/40 overflow-hidden"
              >
                {/* Заголовок слепой зоны */}
                <div className="p-3">
                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    <span
                      className={cn(
                        'inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wider',
                        meta.accent,
                      )}
                    >
                      {meta.icon}
                      {meta.label}
                    </span>
                    {spot.type === 'skill_gap' && spot.selfLevel != null && (
                      <span className="text-xs text-muted-foreground font-mono">
                        {spot.selfLevel} → {spot.verifiedLevel}
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold ml-1">
                          +{spot.gap}
                        </span>
                      </span>
                    )}
                  </div>

                  {/* Insight — главная фраза */}
                  <p className="text-sm leading-snug text-foreground/90">
                    {spot.insight}
                  </p>

                  {/* Краткая форма для skill_gap */}
                  {spot.type === 'skill_gap' && spot.selfLevel != null && (
                    <p className="text-xs text-muted-foreground mt-1.5">
                      Вы оцениваете «{spot.skillName}» на{' '}
                      <span className="font-semibold text-foreground">{spot.selfLevel}</span>,
                      но ваши проекты показывают{' '}
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                        {spot.verifiedLevel}
                      </span>
                      .
                    </p>
                  )}

                  {/* Кнопка раскрытия доказательств */}
                  <button
                    type="button"
                    onClick={() => setExpandedIdx(isExpanded ? null : idx)}
                    className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline"
                  >
                    {isExpanded ? (
                      <>
                        <ChevronUp className="w-3 h-3" />
                        Свернуть доказательства
                      </>
                    ) : (
                      <>
                        <ChevronDown className="w-3 h-3" />
                        Посмотреть доказательства
                      </>
                    )}
                  </button>
                </div>

                {/* Доказательства (раскрываются) */}
                {isExpanded && (
                  <div className="px-3 pb-3 pt-2 border-t border-border/40 bg-muted/20">
                    <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1.5">
                      Доказательства
                    </div>
                    <ul className="space-y-1">
                      {spot.evidence.map((fact, i) => (
                        <li
                          key={i}
                          className="text-xs text-foreground/80 flex items-start gap-1.5"
                        >
                          <Wrench className="w-3 h-3 text-emerald-500 mt-0.5 flex-shrink-0" />
                          <span>{fact}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </li>
            );
          })}
        </ul>

        {/* Подпись */}
        <p className="text-xs text-muted-foreground/70 mt-3">
          Анализ основан на ваших подтверждённых навыках и проектах. Подсветите эти
          сильные стороны в профиле — это повышает доверие и match%.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// === Вспомогательные ===
// ============================================================================

function pluralSpots(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'находка';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'находки';
  return 'находок';
}
