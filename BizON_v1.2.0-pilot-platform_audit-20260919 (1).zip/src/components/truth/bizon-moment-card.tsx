// BizON — BizonMomentCard (Phase 2: BIZON MOMENT)
//
// Эмоциональный стиль карточки AI-инсайта:
//   ┌────────────────────────────────────────────────────────┐
//   │ ✨ BizON заметил кое-что интересное                    │
//   │                                                        │
//   │ [Крупный текст инсайта]                                │
//   │                                                        │
//   │ ▸ Посмотреть почему →   ·  Не про меня                 │
//   │   (раскрывает evidence)                                │
//   └────────────────────────────────────────────────────────┘
//
// Состояния:
//   • optIn=true, есть insight → показываем инсайт
//   • optIn=true, нет insight  → «BIZON MOMENT скоро появится»
//   • optIn=false              → CTA «Включить BIZON MOMENT»
//
// Источник: GET /api/insights/bizon-moment
// Действия: POST /dismiss, POST /opt-in
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Sparkles, ChevronDown, ChevronUp, X, Lightbulb,
  TrendingUp, ShieldCheck, Network, Layers, Gauge, Award, Target,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы данных ===
// ============================================================================

interface BizonEvidence {
  pattern: string;
  facts: string[];
  metrics?: Record<string, number | string>;
}

interface BizonInsight {
  id: string;
  type: 'bizon_moment';
  pattern: string;
  insight: string;
  evidence: BizonEvidence;
  reasoning: string | null;
  confidence: number;
  createdAt: string;
  isRead: boolean;
  engine: 'llm' | 'fallback';
}

interface BizonMomentResponse {
  insight: BizonInsight | null;
  optIn: boolean;
}

// ============================================================================
// === Маппинг паттернов → иконка + цвет ===
// ============================================================================

const PATTERN_META: Record<string, { icon: React.ReactNode; label: string; accent: string }> = {
  role_mismatch: {
    icon: <Target className="w-3.5 h-3.5" />,
    label: 'Role Mismatch',
    accent: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
  },
  cross_domain_bridge: {
    icon: <Layers className="w-3.5 h-3.5" />,
    label: 'Cross-Domain Bridge',
    accent: 'text-violet-600 dark:text-violet-400 bg-violet-500/10',
  },
  network_cluster: {
    icon: <Network className="w-3.5 h-3.5" />,
    label: 'Network Cluster',
    accent: 'text-sky-600 dark:text-sky-400 bg-sky-500/10',
  },
  skill_inflation_reverse: {
    icon: <Gauge className="w-3.5 h-3.5" />,
    label: 'Truth Gap',
    accent: 'text-rose-600 dark:text-rose-400 bg-rose-500/10',
  },
  growth_vector: {
    icon: <TrendingUp className="w-3.5 h-3.5" />,
    label: 'Growth Vector',
    accent: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
  },
  unused_nft_skills: {
    icon: <Award className="w-3.5 h-3.5" />,
    label: 'Unused NFT',
    accent: 'text-orange-600 dark:text-orange-400 bg-orange-500/10',
  },
  reputation_acceleration: {
    icon: <ShieldCheck className="w-3.5 h-3.5" />,
    label: 'Acceleration',
    accent: 'text-lighthouse bg-lighthouse/10',
  },
};

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function BizonMomentCard() {
  const [data, setData] = React.useState<BizonMomentResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [expanded, setExpanded] = React.useState(false);
  const [dismissing, setDismissing] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<BizonMomentResponse>('/api/insights/bizon-moment');
      setData(res);
    } catch (e: any) {
      console.error('[BizonMomentCard] load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  // ============================================================
  // Loading state
  // ============================================================
  if (loading) {
    return (
      <Card className="border-lighthouse/20">
        <CardContent className="p-5">
          <Skeleton className="h-5 w-1/3 mb-3" />
          <Skeleton className="h-16 w-full mb-3" />
          <Skeleton className="h-6 w-1/2" />
        </CardContent>
      </Card>
    );
  }

  // ============================================================
  // optIn=false → CTA
  // ============================================================
  if (data && !data.optIn) {
    return (
      <Card className="border-dashed border-lighthouse/30">
        <CardContent className="p-5">
          <div className="flex items-start gap-3 flex-wrap">
            <div className="w-10 h-10 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold">BIZON MOMENT</div>
              <p className="text-xs text-muted-foreground mt-0.5">
                Еженедельные AI-инсайты о вашем профиле: точки роста, слепые зоны, неожиданные закономерности.
              </p>
            </div>
            <Button
              size="sm"
              onClick={async () => {
                try {
                  await api('/api/insights/bizon-moment/opt-in', {
                    method: 'POST',
                    body: JSON.stringify({ optIn: true }),
                  });
                  load();
                } catch (e: any) {
                  console.error('[BizonMomentCard] opt-in error:', e);
                }
              }}
            >
              Включить
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // ============================================================
  // optIn=true, но инсайта нет → «скоро появится»
  // ============================================================
  if (!data || !data.insight) {
    return (
      <Card className="border-lighthouse/20 bg-gradient-to-br from-lighthouse/5 via-transparent to-transparent">
        <CardContent className="p-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold flex items-center gap-1.5">
                BIZON MOMENT
                <Badge variant="secondary" className="text-xs">скоро</Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                BizON анализирует ваш профиль. Скоро здесь появится персональный инсайт —
                точка роста, слепая зона или неожиданная закономерность.
              </p>
              <p className="text-xs text-muted-foreground/70 mt-2">
                Инсайты появляются не чаще раза в неделю.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // ============================================================
  // optIn=true, есть инсайт → показываем
  // ============================================================
  const insight = data.insight;
  const meta = PATTERN_META[insight.pattern] ?? {
    icon: <Lightbulb className="w-3.5 h-3.5" />,
    label: 'Insight',
    accent: 'text-lighthouse bg-lighthouse/10',
  };
  const confidencePercent = Math.round(insight.confidence * 100);

  return (
    <Card className="border-lighthouse/30 bg-gradient-to-br from-lighthouse/5 via-transparent to-lighthouse/5 overflow-hidden">
      <CardContent className="p-5">
        {/* Шапка */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-lighthouse font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            BizON заметил кое-что интересное
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <span className={cn('inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wider', meta.accent)}>
              {meta.icon}
              {meta.label}
            </span>
            {insight.engine === 'fallback' && (
              <Badge variant="outline" className="text-xs text-muted-foreground" title="LLM недоступен, показан шаблон">
                fallback
              </Badge>
            )}
          </div>
        </div>

        {/* Текст инсайта — крупно */}
        <p className="text-base sm:text-lg leading-snug font-medium text-foreground">
          {insight.insight}
        </p>

        {/* Reasoning (если есть и expanded) */}
        {expanded && insight.reasoning && (
          <div className="mt-3 pt-3 border-t border-lighthouse/10">
            <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1">
              Почему BizON так решил
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {insight.reasoning}
            </p>
          </div>
        )}

        {/* Evidence — раскрывается по клику */}
        {expanded && (
          <div className="mt-3 pt-3 border-t border-lighthouse/10">
            <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1.5">
              Факты
            </div>
            <ul className="space-y-1">
              {insight.evidence.facts.map((f, i) => (
                <li key={i} className="text-xs text-foreground/80 flex items-start gap-1.5">
                  <span className="text-lighthouse mt-0.5">▸</span>
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            {insight.evidence.metrics && Object.keys(insight.evidence.metrics).length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {Object.entries(insight.evidence.metrics).map(([k, v]) => (
                  <Badge key={k} variant="secondary" className="text-xs font-mono">
                    {k}: {String(v)}
                  </Badge>
                ))}
              </div>
            )}
            <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <span>Уверенность: <span className="font-mono font-semibold">{confidencePercent}%</span></span>
              <span>·</span>
              <span>{new Date(insight.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}</span>
            </div>
          </div>
        )}

        {/* Действия */}
        <div className="mt-4 flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="inline-flex items-center gap-1 text-xs font-medium text-lighthouse hover:underline"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-3 h-3" />
                Свернуть
              </>
            ) : (
              <>
                <ChevronDown className="w-3 h-3" />
                Посмотреть почему
              </>
            )}
          </button>

          <span className="text-muted-foreground/30">·</span>

          <button
            type="button"
            disabled={dismissing}
            onClick={async () => {
              setDismissing(true);
              try {
                await api('/api/insights/bizon-moment/dismiss', {
                  method: 'POST',
                  body: JSON.stringify({ insightId: insight.id }),
                });
                // Перезагружаем — после dismiss карточка скроется (isRead=true)
                load();
              } catch (e: any) {
                console.error('[BizonMomentCard] dismiss error:', e);
              } finally {
                setDismissing(false);
              }
            }}
            className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition disabled:opacity-50"
          >
            <X className="w-3 h-3" />
            Не про меня
          </button>

          <div className="ml-auto">
            <button
              type="button"
              onClick={async () => {
                try {
                  await api('/api/insights/bizon-moment/opt-in', {
                    method: 'POST',
                    body: JSON.stringify({ optIn: false }),
                  });
                  load();
                } catch (e: any) {
                  console.error('[BizonMomentCard] opt-out error:', e);
                }
              }}
              className="text-xs text-muted-foreground/60 hover:text-muted-foreground transition"
              title="Отключить BIZON MOMENT"
            >
              Отключить
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
