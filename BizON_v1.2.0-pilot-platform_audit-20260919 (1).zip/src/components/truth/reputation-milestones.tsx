// BizON — Reputation Milestones: чек-лист карьерных достижений
// Источники: /api/reputation/evidence + /api/users/[id] (для текущего юзера — статы)
// Каждый milestone имеет пороговое значение; достигнутый → зелёная галочка, иначе серый кружок.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Check, Circle, Trophy, FolderKanban, Award, Users, Shield, BarChart3, Link2, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';

interface EvidenceResponse {
  ipScore: number;
  level: string;
  evidence: {
    verifiedProjects: Array<{ id: string }>;
    verifiedSkills: Array<{ id: string }>;
    recommendations: number;
    claims: { total: number; verified: number; pending: number };
  };
  evidenceCoverage: number;
}

interface UserResponse {
  user: {
    id: string;
    level: string;
    stats?: {
      projectsCount: number;
      connectionsCount: number;
      skillsCount: number;
      postsCount: number;
    };
  };
}

interface Milestone {
  id: string;
  label: string;
  icon: React.ReactNode;
  achieved: boolean;
  hint: string;
}

export function ReputationMilestones({ className }: { className?: string }) {
  const { user } = useAppStore();
  const [evidence, setEvidence] = React.useState<EvidenceResponse | null>(null);
  const [userStats, setUserStats] = React.useState<UserResponse['user'] | null>(null);
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const userId = user?.id;
      const [evRes, uRes] = await Promise.all([
        api<EvidenceResponse>('/api/reputation/evidence').catch(() => null),
        userId
          ? api<UserResponse>(`/api/users/${userId}`).catch(() => null)
          : Promise.resolve(null),
      ]);
      setEvidence(evRes);
      if (uRes) setUserStats(uRes.user);
    } catch (e) {
      console.error('[reputation-milestones] load error:', e);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <Card className={className}>
        <CardContent className="p-4">
          <Skeleton className="h-5 w-48 mb-3" />
          <div className="space-y-2">
            {Array.from({ length: 7 }).map((_, i) => (
              <Skeleton key={i} className="h-9 w-full rounded-lg" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Значения для расчёта milestone'ов
  const verifiedProjects = evidence?.evidence.verifiedProjects.length ?? 0;
  const verifiedSkills = evidence?.evidence.verifiedSkills.length ?? 0;
  const recommendations = evidence?.evidence.recommendations ?? 0;
  const level = (evidence?.level ?? user?.level ?? 'basic') as string;
  const evidenceCoverage = evidence?.evidenceCoverage ?? 0;
  const connectionsCount = userStats?.stats?.connectionsCount ?? user?.stats?.connectionsCount ?? 0;
  const postsCount = userStats?.stats?.postsCount ?? user?.stats?.postsCount ?? 0;

  const milestones: Milestone[] = [
    {
      id: 'first-project',
      label: 'Первый подтверждённый проект',
      icon: <FolderKanban className="w-4 h-4" />,
      achieved: verifiedProjects >= 1,
      hint: `Сейчас: ${verifiedProjects}`,
    },
    {
      id: 'ten-skills',
      label: '10 подтверждённых навыков',
      icon: <Award className="w-4 h-4" />,
      achieved: verifiedSkills >= 10,
      hint: `Сейчас: ${verifiedSkills}`,
    },
    {
      id: 'five-recs',
      label: '5 рекомендаций',
      icon: <Users className="w-4 h-4" />,
      achieved: recommendations >= 5,
      hint: `Сейчас: ${recommendations}`,
    },
    {
      id: 'expert-level',
      label: 'Статус Expert',
      icon: <Shield className="w-4 h-4" />,
      achieved: level === 'expert',
      hint: `Уровень: ${levelLabel(level)}`,
    },
    {
      id: 'coverage-80',
      label: '80% подтверждено',
      icon: <BarChart3 className="w-4 h-4" />,
      achieved: evidenceCoverage >= 0.8,
      hint: `Сейчас: ${Math.round(evidenceCoverage * 100)}%`,
    },
    {
      id: 'fifty-connections',
      label: '50 связей',
      icon: <Link2 className="w-4 h-4" />,
      achieved: connectionsCount >= 50,
      hint: `Сейчас: ${connectionsCount}`,
    },
    {
      id: 'twenty-posts',
      label: '20 постов',
      icon: <FileText className="w-4 h-4" />,
      achieved: postsCount >= 20,
      hint: `Сейчас: ${postsCount}`,
    },
  ];

  const achievedCount = milestones.filter((m) => m.achieved).length;
  const totalCount = milestones.length;
  const progressPct = Math.round((achievedCount / totalCount) * 100);

  return (
    <Card className={className}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
              <Trophy className="w-4 h-4 text-amber-600 dark:text-amber-500" />
            </div>
            <div>
              <div className="text-sm font-semibold">Достижения репутации</div>
              <div className="text-xs text-muted-foreground">
                Карьерные milestones
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold tabular-nums">
              {achievedCount}{' '}
              <span className="text-muted-foreground text-sm font-normal">
                из {totalCount}
              </span>
            </div>
            <div className="text-xs text-muted-foreground">достигнуто</div>
          </div>
        </div>

        {/* Прогресс-бар */}
        <div className="h-1.5 w-full rounded-full bg-muted overflow-hidden mb-3">
          <div
            className="h-full bg-emerald-600 dark:bg-emerald-500 transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        {/* Список milestones */}
        <div className="space-y-1.5">
          {milestones.map((m) => (
            <div
              key={m.id}
              className={cn(
                'flex items-center gap-3 p-2 rounded-lg border transition',
                m.achieved
                  ? 'border-emerald-500/20 bg-emerald-500/5'
                  : 'border-transparent bg-muted/30',
              )}
            >
              {/* Чекмарк или пустой кружок */}
              <div className="flex-shrink-0">
                {m.achieved ? (
                  <div className="w-5 h-5 rounded-full bg-emerald-600 dark:bg-emerald-500 flex items-center justify-center">
                    <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />
                  </div>
                ) : (
                  <Circle className="w-5 h-5 text-muted-foreground/40" strokeWidth={1.5} />
                )}
              </div>

              {/* Иконка */}
              <div
                className={cn(
                  'flex-shrink-0',
                  m.achieved
                    ? 'text-emerald-600 dark:text-emerald-500'
                    : 'text-muted-foreground',
                )}
              >
                {m.icon}
              </div>

              {/* Лейбл */}
              <div className="flex-1 min-w-0">
                <div
                  className={cn(
                    'text-sm truncate',
                    m.achieved
                      ? 'font-medium text-foreground'
                      : 'text-muted-foreground',
                  )}
                >
                  {m.label}
                </div>
              </div>

              {/* Подсказка с текущим значением (только если не достигнуто) */}
              {!m.achieved && (
                <div className="text-xs text-muted-foreground/70 tabular-nums flex-shrink-0">
                  {m.hint}
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function levelLabel(level: string): string {
  if (level === 'expert') return 'Эксперт';
  if (level === 'extended') return 'Проверенный';
  return 'Старт';
}
