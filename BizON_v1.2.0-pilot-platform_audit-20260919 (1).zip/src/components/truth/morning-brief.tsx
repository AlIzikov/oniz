// BizON — Morning Brief: утренний бриф репутации (1 раз в день)
// Источники: /api/reputation/evidence, /api/reputation/snapshots, /api/claims?status=claimed
// Хранение: localStorage bizon-morning-brief-YYYY-MM-DD — закрывается до завтра.
// UI: dismissible Card сверху дашборда (альтернатива модалке).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Sun,
  ArrowUp,
  ArrowDown,
  Minus,
  ShieldCheck,
  AlertTriangle,
  Briefcase,
  X,
  Sparkles,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface EvidenceData {
  ipScore: number;
  level: string;
  evidence: {
    verifiedProjects: Array<{ id: string }>;
    verifiedSkills: Array<{ id: string }>;
    recommendations: number;
    claims: { total: number; verified: number; pending: number };
  };
  evidenceCoverage: number;
}

interface Snapshot {
  id: string;
  ipScore: number;
  createdAt: string;
}

interface SnapshotsResponse {
  snapshots: Snapshot[];
}

interface ClaimsResponse {
  claims: Array<{ id: string; status: string }>;
  pagination: { total: number };
}

interface UserResponse {
  user: {
    id: string;
    name: string;
    ipScore: number;
    level: string;
    stats?: { skillsCount: number };
  };
  skills: Array<{ id: string; verificationLevel: string }>;
}

function todayKey(): string {
  // YYYY-MM-DD локально
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function storageKey(): string {
  return `bizon-morning-brief-${todayKey()}`;
}

export function MorningBrief() {
  const { user } = useAppStore();
  const [visible, setVisible] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [evidence, setEvidence] = React.useState<EvidenceData | null>(null);
  const [snapshots, setSnapshots] = React.useState<Snapshot[]>([]);
  const [pendingClaims, setPendingClaims] = React.useState(0);
  const [unverifiedSkills, setUnverifiedSkills] = React.useState(0);

  React.useEffect(() => {
    if (!user) return;
    // Не показываем, если сегодня уже закрывали
    if (typeof window === 'undefined') return;
    const dismissed = localStorage.getItem(storageKey());
    if (dismissed === 'dismissed') return;

    let cancelled = false;

    (async () => {
      setLoading(true);
      try {
        const userId = user.id;
        const [evRes, snapRes, claimsRes, userRes] = await Promise.all([
          api<EvidenceData>('/api/reputation/evidence').catch(() => null),
          api<SnapshotsResponse>('/api/reputation/snapshots').catch(() => ({ snapshots: [] as Snapshot[] })),
          api<ClaimsResponse>('/api/claims?status=claimed&pageSize=100').catch(() => ({ claims: [], pagination: { total: 0 } })),
          api<UserResponse>(`/api/users/${userId}`).catch(() => null),
        ]);

        if (cancelled) return;

        if (evRes) setEvidence(evRes);
        setSnapshots((snapRes.snapshots || []).slice().sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
        ));
        setPendingClaims(claimsRes.claims?.length ?? 0);
        const claimedSkills = (userRes?.skills || []).filter(
          (s) => (s.verificationLevel ?? 'claimed') === 'claimed',
        );
        setUnverifiedSkills(claimedSkills.length);

        // Показываем бриф
        setVisible(true);
      } catch (e) {
        console.error('[morning-brief] load error:', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user]);

  function handleDismiss() {
    setVisible(false);
    try {
      localStorage.setItem(storageKey(), 'dismissed');
    } catch {
      // ignore
    }
  }

  if (!user) return null;
  if (loading) {
    return (
      <Card>
        <CardContent className="p-4">
          <Skeleton className="h-5 w-56 mb-3" />
          <div className="grid sm:grid-cols-2 gap-3">
            <Skeleton className="h-20 rounded-lg" />
            <Skeleton className="h-20 rounded-lg" />
            <Skeleton className="h-20 rounded-lg" />
            <Skeleton className="h-20 rounded-lg" />
          </div>
        </CardContent>
      </Card>
    );
  }
  if (!visible) return null;

  // IP-score + недельная дельта (последний snapshot минус snapshot ~7 дней назад)
  const ipScore = evidence?.ipScore ?? user.ipScore;
  const lastSnap = snapshots[snapshots.length - 1];
  const weekAgoSnap = snapshots.find((s) => {
    const diff = (lastSnap ? new Date(lastSnap.createdAt).getTime() : Date.now()) - new Date(s.createdAt).getTime();
    return diff >= 6 * 24 * 60 * 60 * 1000; // >= 6 дней
  });
  const weekDelta =
    lastSnap && weekAgoSnap ? lastSnap.ipScore - weekAgoSnap.ipScore : 0;
  const weekDeltaColor =
    weekDelta > 0
      ? 'text-emerald-600 dark:text-emerald-500'
      : weekDelta < 0
        ? 'text-red-600 dark:text-red-500'
        : 'text-muted-foreground';
  const WeekDeltaIcon = weekDelta > 0 ? ArrowUp : weekDelta < 0 ? ArrowDown : Minus;

  const coveragePct = Math.round((evidence?.evidenceCoverage ?? 0) * 100);

  // Заглушка: вакансии (просто рандом-стабильное число на основе userId)
  const jobsMatched = Math.max(0, (user.name?.length ?? 0) % 7);

  const firstName = user.name.split(' ')[0] || user.name;

  return (
    <Card className="border-lighthouse/30 bg-lighthouse-gradient-soft">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg lighthouse-gradient flex items-center justify-center">
              <Sun className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-base font-bold">
                ☀️ Доброе утро, {firstName}!
              </div>
              <div className="text-xs text-muted-foreground">
                Ваш утренний бриф на{' '}
                {new Date().toLocaleDateString('ru-RU', {
                  day: 'numeric',
                  month: 'long',
                })}
              </div>
            </div>
          </div>
          <button
            onClick={handleDismiss}
            className="p-1 rounded hover:bg-background/50 transition flex-shrink-0"
            aria-label="Закрыть"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* TRUST + COVERAGE — верхняя строка */}
        <div className="grid sm:grid-cols-2 gap-2 mb-3">
          <div className="rounded-lg border border-lighthouse/20 bg-background/50 p-3">
            <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
              Ваш Trust
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-extrabold tabular-nums">{ipScore}</span>
              <span className="text-xs text-muted-foreground">/ 100</span>
              {weekDelta !== 0 && (
                <span
                  className={cn(
                    'inline-flex items-center gap-0.5 text-xs font-medium',
                    weekDeltaColor,
                  )}
                >
                  <WeekDeltaIcon className="w-3 h-3" />
                  {weekDelta > 0 ? '+' : ''}
                  {weekDelta} за неделю
                </span>
              )}
              {weekDelta === 0 && (
                <span className="inline-flex items-center gap-0.5 text-xs text-muted-foreground">
                  <Minus className="w-3 h-3" />0 за неделю
                </span>
              )}
            </div>
          </div>

          <div className="rounded-lg border border-lighthouse/20 bg-background/50 p-3">
            <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              Подтверждено
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-extrabold tabular-nums">{coveragePct}%</span>
              <span className="text-xs text-muted-foreground">
                утверждений подтверждено
              </span>
            </div>
          </div>
        </div>

        {/* ЧТО ТРЕБУЕТ ВНИМАНИЯ */}
        <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3 mb-2">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-500" />
            <div className="text-sm font-semibold">Что требует внимания:</div>
          </div>
          <div className="space-y-1.5 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Утверждений ожидают подтверждения</span>
              <span className="font-semibold tabular-nums">{pendingClaims}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Навыков не подтверждены</span>
              <span className="font-semibold tabular-nums">{unverifiedSkills}</span>
            </div>
          </div>
        </div>

        {/* ВОЗМОЖНОСТИ (заглушка) */}
        <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 mb-3">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-emerald-600 dark:text-emerald-500" />
            <div className="text-sm font-semibold">Возможности:</div>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground inline-flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5" />
              Вакансий подобрано для вас
            </span>
            <span className="font-semibold tabular-nums text-emerald-600 dark:text-emerald-500">
              {jobsMatched}
            </span>
          </div>
        </div>

        {/* CTA */}
        <div className="flex justify-end">
          <Button size="sm" onClick={handleDismiss} className="bg-emerald-600 text-white hover:bg-emerald-700">
            Понятно
          </Button>
        </div>

        <p className="text-xs text-center text-muted-foreground mt-2">
          Бриф показывается 1 раз в день. Репутация — ваша валюта.
        </p>
      </CardContent>
    </Card>
  );
}
