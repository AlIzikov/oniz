// BizON — GPT Truth Engine: EvidenceModal
// Модальное окно «Почему [X]?» — показывает основание для score.
// Принимает произвольный trigger (React-узел) и список evidence.
'use client';

import * as React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import {
  FolderKanban,
  BadgeCheck,
  Star,
  Users,
  MessageSquare,
  CheckCircle2,
} from 'lucide-react';

export interface EvidenceItem {
  label: string;
  count: number;
  /** Тип источника для иконки/цвета: projects | skills | recommendations | claims | verifications | default */
  source: string;
}

interface EvidenceModalProps {
  trigger: React.ReactNode;
  title: string;
  evidence: EvidenceItem[];
  /** Дополнительный текст-описание */
  description?: string;
  /** Класс для контейнера триггера (asChild=false режим) */
  className?: string;
}

const SOURCE_CONFIG: Record<
  string,
  { Icon: React.ComponentType<{ className?: string }>; color: string }
> = {
  projects: { Icon: FolderKanban, color: 'text-emerald-600' },
  skills: { Icon: BadgeCheck, color: 'text-blue-600' },
  recommendations: { Icon: Users, color: 'text-purple-600' },
  claims: { Icon: CheckCircle2, color: 'text-amber-600' },
  verifications: { Icon: MessageSquare, color: 'text-teal-600' },
  default: { Icon: Star, color: 'text-muted-foreground' },
};

export function EvidenceModal({
  trigger,
  title,
  evidence,
  description,
  className,
}: EvidenceModalProps) {
  const [open, setOpen] = React.useState(false);

  const total = evidence.reduce((sum, e) => sum + e.count, 0);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          type="button"
          className={cn(
            'inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors underline-offset-2 hover:underline',
            className
          )}
        >
          {trigger}
        </button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star className="size-5 text-amber-500" />
            {title}
          </DialogTitle>
        </DialogHeader>

        {description && (
          <p className="text-sm text-muted-foreground leading-relaxed">
            {description}
          </p>
        )}

        <div className="space-y-2">
          {evidence.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              Пока нет подтверждений. Создайте claim и попросите коллег его проверить.
            </p>
          ) : (
            evidence.map((item, idx) => {
              const cfg = SOURCE_CONFIG[item.source] ?? SOURCE_CONFIG.default;
              const { Icon } = cfg;
              return (
                <div
                  key={`${item.label}-${idx}`}
                  className="flex items-center justify-between rounded-md border bg-card px-3 py-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <Icon className={cn('size-4 shrink-0', cfg.color)} />
                    <span className="text-sm truncate">{item.label}</span>
                  </div>
                  <span className="text-sm font-semibold tabular-nums ml-2">
                    {item.count}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {total > 0 && (
          <div className="border-t pt-3 mt-2 flex items-center justify-between text-xs text-muted-foreground">
            <span>Всего оснований</span>
            <span className="font-semibold text-foreground">{total}</span>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
