// BizON — EvidenceGraph (P0-3)
// Визуализация графа доказательств: claim → project → skill → confirmer → result → trust.
// Простой SVG-рендерер без d3.js / WebGL — радиальная схема с Trust в центре.
//
// Props:
//   • userId?     — целевой пользователь (по умолчанию текущий авторизованный)
//   • compact?    — компактный режим для публичного профиля (меньший SVG, без боковой панели)
//   • className?
//
// Поведение:
//   • Клик по узлу → детали в боковой панели (или popover в compact-режиме)
//   • Hover → tooltip с типом и статусом
//   • Empty state если данных нет
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import {
  Share2,
  ShieldCheck,
  FolderKanban,
  Award,
  Users,
  Target,
  FileText,
  Info,
  X,
  Sparkles,
} from 'lucide-react';

// ---------- types ----------
type NodeType = 'claim' | 'project' | 'skill' | 'confirmer' | 'result' | 'trust';

interface GraphNode {
  id: string;
  type: NodeType;
  label: string;
  status?: string;
  role?: string;
  description?: string;
  meta?: Record<string, string | number | boolean | null>;
}
interface GraphEdge {
  from: string;
  to: string;
  label: string;
}
interface EvidenceGraphData {
  userId: string;
  isOwner: boolean;
  nodes: GraphNode[];
  edges: GraphEdge[];
  stats: { totalNodes: number; totalEdges: number; verifiedClaims: number };
}

// ---------- visual config ----------
const NODE_COLORS: Record<NodeType, { fill: string; stroke: string; text: string; label: string }> = {
  claim:     { fill: '#fef3c7', stroke: '#f59e0b', text: '#92400e', label: 'Claim' },
  project:   { fill: '#dcfce7', stroke: '#10b981', text: '#065f46', label: 'Project' },
  skill:     { fill: '#ccfbf1', stroke: '#14b8a6', text: '#115e59', label: 'Skill' },
  confirmer: { fill: '#dbeafe', stroke: '#3b82f6', text: '#1e40af', label: 'Confirmer' },
  result:    { fill: '#ede9fe', stroke: '#8b5cf6', text: '#5b21b6', label: 'Result' },
  trust:     { fill: '#fce7f3', stroke: '#ec4899', text: '#9d174d', label: 'Trust' },
};

const NODE_RADIUS: Record<NodeType, number> = {
  trust: 36,
  claim: 26,
  project: 24,
  skill: 22,
  confirmer: 20,
  result: 22,
};

const TYPE_ORDER: NodeType[] = ['claim', 'project', 'skill', 'confirmer', 'result', 'trust'];

// ---------- layout algorithm ----------
// Trust node → center.
// Claims → ring 1 (radius R1) around trust, evenly spaced by angle.
// Each claim's children (project/skill/confirmer/result) → ring 2 (radius R2),
// in the same angular sector as the parent claim.
interface NodePosition { x: number; y: number; }

function computeLayout(
  nodes: GraphNode[],
  edges: GraphEdge[],
  width: number,
  height: number
): Record<string, NodePosition> {
  const cx = width / 2;
  const cy = height / 2;
  const positions: Record<string, NodePosition> = {};

  const trustNode = nodes.find((n) => n.type === 'trust');
  const claims = nodes.filter((n) => n.type === 'claim');
  const nonClaimNonTrust = nodes.filter((n) => n.type !== 'claim' && n.type !== 'trust');

  if (trustNode) positions[trustNode.id] = { x: cx, y: cy };

  if (claims.length === 0) {
    // No claims — place remaining nodes on a circle around center.
    nonClaimNonTrust.forEach((n, i) => {
      const angle = (2 * Math.PI * i) / Math.max(nonClaimNonTrust.length, 1) - Math.PI / 2;
      const R = Math.min(width, height) / 2 - 60;
      positions[n.id] = { x: cx + R * Math.cos(angle), y: cy + R * Math.sin(angle) };
    });
    return positions;
  }

  // R1 — радиус для claims. Adaptive: меньше claims → больший радиус для читаемости.
  const R1 = Math.max(120, Math.min(width, height) / 3);
  const R2 = R1 + 130; // ring 2 for children

  // Group children by their "parent claim" (the claim they're connected to via edges).
  // A node may be connected to multiple claims — assign it to the first claim found.
  const childrenByClaim = new Map<string, GraphNode[]>();
  const childToClaim = new Map<string, string>();

  // First, find direct claim → child edges
  for (const e of edges) {
    const fromNode = nodes.find((n) => n.id === e.from);
    if (!fromNode || fromNode.type !== 'claim') continue;
    const toNode = nodes.find((n) => n.id === e.to);
    if (!toNode) continue;
    if (childToClaim.has(toNode.id)) continue; // already assigned
    childToClaim.set(toNode.id, fromNode.id);
    const arr = childrenByClaim.get(fromNode.id) ?? [];
    arr.push(toNode);
    childrenByClaim.set(fromNode.id, arr);
  }

  // Orphan children (no direct claim edge) — assign to nearest claim by index.
  for (const child of nonClaimNonTrust) {
    if (childToClaim.has(child.id)) continue;
    // Try to find a claim via 2-hop path (child ← project/skill ← claim)
    let parentClaimId: string | null = null;
    for (const e of edges) {
      if (e.to !== child.id) continue;
      const midNode = nodes.find((n) => n.id === e.from);
      if (!midNode) continue;
      // midNode is parent — check if midNode has a claim parent
      for (const e2 of edges) {
        if (e2.to !== midNode.id) continue;
        const claimNode = nodes.find((n) => n.id === e2.from);
        if (claimNode && claimNode.type === 'claim') {
          parentClaimId = claimNode.id;
          break;
        }
      }
      if (parentClaimId) break;
    }
    if (!parentClaimId) parentClaimId = claims[0].id;
    childToClaim.set(child.id, parentClaimId);
    const arr = childrenByClaim.get(parentClaimId) ?? [];
    arr.push(child);
    childrenByClaim.set(parentClaimId, arr);
  }

  // Place claims on R1 ring
  claims.forEach((claim, i) => {
    const angle = (2 * Math.PI * i) / claims.length - Math.PI / 2;
    positions[claim.id] = {
      x: cx + R1 * Math.cos(angle),
      y: cy + R1 * Math.sin(angle),
    };
  });

  // Place each claim's children on R2 ring in same sector
  for (const claim of claims) {
    const children = childrenByClaim.get(claim.id) ?? [];
    const claimAngle = (2 * Math.PI * claims.indexOf(claim)) / claims.length - Math.PI / 2;
    // Sort children by type for visual grouping
    children.sort((a, b) => TYPE_ORDER.indexOf(a.type) - TYPE_ORDER.indexOf(b.type));
    const sectorSpread = Math.min(0.6, 0.15 * children.length); // angular spread
    children.forEach((child, j) => {
      const t = children.length === 1 ? 0 : (j / (children.length - 1)) - 0.5;
      const angle = claimAngle + t * sectorSpread;
      positions[child.id] = {
        x: cx + R2 * Math.cos(angle),
        y: cy + R2 * Math.sin(angle),
      };
    });
  }

  return positions;
}

// Truncate long labels to fit in nodes
function truncateLabel(s: string, max = 22): string {
  if (s.length <= max) return s;
  return s.slice(0, max - 1) + '…';
}

// ---------- main component ----------
interface EvidenceGraphProps {
  userId?: string;
  compact?: boolean;
  className?: string;
}

export function EvidenceGraph({ userId, compact = false, className }: EvidenceGraphProps) {
  const [data, setData] = React.useState<EvidenceGraphData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [selectedId, setSelectedId] = React.useState<string | null>(null);
  const [hoveredId, setHoveredId] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = userId ? `?userId=${encodeURIComponent(userId)}` : '';
      const res = await api<EvidenceGraphData>(`/api/me/evidence-graph${qs}`);
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить граф доказательств');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  const svgWidth = compact ? 520 : 760;
  const svgHeight = compact ? 360 : 540;

  const positions = React.useMemo(() => {
    if (!data) return {};
    return computeLayout(data.nodes, data.edges, svgWidth, svgHeight);
  }, [data, svgWidth, svgHeight]);

  const selectedNode = React.useMemo(() => {
    if (!data || !selectedId) return null;
    return data.nodes.find((n) => n.id === selectedId) ?? null;
  }, [data, selectedId]);

  // === Loading state ===
  if (loading) {
    return (
      <Card className={className}>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Share2 className="size-4 text-primary" />
            Evidence Graph
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[360px] w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  // === Error state ===
  if (error) {
    return (
      <Card className={className}>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Share2 className="size-4 text-primary" />
            Evidence Graph
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground py-8 text-center">
            <Info className="size-6 mx-auto mb-2 opacity-50" />
            {error}
            <div className="mt-3">
              <Button size="sm" variant="outline" onClick={load}>
                Повторить
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // === Empty state ===
  if (!data || data.nodes.length === 0) {
    return (
      <Card className={className}>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Share2 className="size-4 text-primary" />
            Evidence Graph
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-10 px-4">
            <div className="size-12 mx-auto mb-3 rounded-full bg-muted flex items-center justify-center">
              <Share2 className="size-6 text-muted-foreground" />
            </div>
            <div className="text-sm font-medium mb-1">
              Граф доказательств пока пуст
            </div>
            <p className="text-xs text-muted-foreground max-w-md mx-auto leading-relaxed">
              Начните с создания Claim и подтверждения навыков через совместные проекты —
              и здесь появится наглядная карта ваших профессиональных доказательств.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // === Render ===
  const nodeById = new Map(data.nodes.map((n) => [n.id, n]));

  // Build edge paths with subtle curvature
  const edgePaths = data.edges.map((e, i) => {
    const from = positions[e.from];
    const to = positions[e.to];
    if (!from || !to) return null;
    // Curve control point: midpoint + small perpendicular offset
    const mx = (from.x + to.x) / 2;
    const my = (from.y + to.y) / 2;
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const len = Math.sqrt(dx * dx + dy * dy) || 1;
    // Perpendicular vector (towards center for "spoke" effect)
    const cxp = svgWidth / 2;
    const cyp = svgHeight / 2;
    const towardCenterX = cxp - mx;
    const towardCenterY = cyp - my;
    const tcl = Math.sqrt(towardCenterX * towardCenterX + towardCenterY * towardCenterY) || 1;
    const offset = 14;
    const ctrlX = mx + (towardCenterX / tcl) * offset;
    const ctrlY = my + (towardCenterY / tcl) * offset;

    // Start/end points trimmed by node radius so arrow doesn't overlap node
    const fromNode = nodeById.get(e.from);
    const toNode = nodeById.get(e.to);
    const rFrom = fromNode ? NODE_RADIUS[fromNode.type] : 0;
    const rTo = toNode ? NODE_RADIUS[toNode.type] : 0;
    const sx = from.x + (dx / len) * rFrom;
    const sy = from.y + (dy / len) * rFrom;
    const ex = to.x - (dx / len) * (rTo + 4);
    const ey = to.y - (dy / len) * (rTo + 4);

    const isSelected = selectedId === e.from || selectedId === e.to;
    const isHovered = hoveredId === e.from || hoveredId === e.to;

    return {
      key: `edge-${i}`,
      d: `M ${sx} ${sy} Q ${ctrlX} ${ctrlY} ${ex} ${ey}`,
      label: e.label,
      midX: (sx + ex) / 2 + (ctrlX - mx) * 0.4,
      midY: (sy + ey) / 2 + (ctrlY - my) * 0.4,
      isSelected,
      isHovered,
    };
  }).filter(Boolean) as Array<{
    key: string;
    d: string;
    label: string;
    midX: number;
    midY: number;
    isSelected: boolean;
    isHovered: boolean;
  }>;

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center justify-between gap-2 flex-wrap">
          <span className="flex items-center gap-2">
            <Share2 className="size-4 text-primary" />
            Evidence Graph
          </span>
          <span className="text-xs text-muted-foreground font-normal">
            {data.stats.verifiedClaims} подтв. · {data.nodes.length} узлов ·{' '}
            {data.edges.length} связей
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className={cn('flex flex-col gap-4', compact ? 'lg:flex-row' : 'lg:flex-row')}>
          {/* === SVG Canvas === */}
          <div className="relative flex-1 min-w-0">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-auto rounded-lg border bg-gradient-to-br from-background to-muted/20"
              style={{ maxHeight: compact ? 360 : 540 }}
              role="img"
              aria-label="Граф доказательств: claim, project, skill, confirmer, result, trust"
            >
              <defs>
                {/* Arrow marker */}
                <marker
                  id="eg-arrow"
                  viewBox="0 0 10 10"
                  refX="9"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor" />
                </marker>
              </defs>

              {/* Edges */}
              <g className="text-muted-foreground/60">
                {edgePaths.map((p) => (
                  <g key={p.key}>
                    <path
                      d={p.d}
                      fill="none"
                      stroke={p.isSelected ? 'hsl(var(--primary))' : p.isHovered ? 'hsl(var(--primary)/0.6)' : 'currentColor'}
                      strokeWidth={p.isSelected ? 2 : 1.2}
                      markerEnd="url(#eg-arrow)"
                      opacity={p.isSelected || p.isHovered ? 1 : 0.5}
                    />
                    {(p.isSelected || p.isHovered || !compact) && (
                      <text
                        x={p.midX}
                        y={p.midY}
                        textAnchor="middle"
                        className="fill-muted-foreground"
                        style={{ fontSize: 9, fontWeight: 500 }}
                        dy={-3}
                      >
                        {p.label}
                      </text>
                    )}
                  </g>
                ))}
              </g>

              {/* Nodes */}
              <g>
                {data.nodes.map((node) => {
                  const pos = positions[node.id];
                  if (!pos) return null;
                  const color = NODE_COLORS[node.type];
                  const r = NODE_RADIUS[node.type];
                  const isSelected = selectedId === node.id;
                  const isHovered = hoveredId === node.id;
                  const isTrust = node.type === 'trust';
                  return (
                    <g
                      key={node.id}
                      transform={`translate(${pos.x}, ${pos.y})`}
                      className="cursor-pointer transition-opacity"
                      opacity={
                        selectedId && !isSelected && !isHovered ? 0.55 : 1
                      }
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedId(isSelected ? null : node.id);
                      }}
                      onMouseEnter={() => setHoveredId(node.id)}
                      onMouseLeave={() => setHoveredId(null)}
                      role="button"
                      aria-label={`${color.label}: ${node.label}`}
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          setSelectedId(isSelected ? null : node.id);
                        }
                      }}
                    >
                      {/* Selection/hover ring */}
                      {(isSelected || isHovered) && (
                        <circle
                          r={r + 5}
                          fill="none"
                          stroke={color.stroke}
                          strokeWidth={1.5}
                          strokeDasharray={isTrust ? '4 2' : undefined}
                          opacity={0.6}
                        />
                      )}
                      {/* Trust node: extra outer ring for emphasis */}
                      {isTrust && (
                        <circle
                          r={r + 8}
                          fill="none"
                          stroke={color.stroke}
                          strokeWidth={1}
                          opacity={0.3}
                          strokeDasharray="3 3"
                        />
                      )}
                      <circle
                        r={r}
                        fill={color.fill}
                        stroke={color.stroke}
                        strokeWidth={isSelected ? 2.5 : 1.8}
                      />
                      <text
                        textAnchor="middle"
                        dy={isTrust ? -2 : 4}
                        style={{
                          fontSize: isTrust ? 11 : 9,
                          fontWeight: 600,
                          fill: color.text,
                          pointerEvents: 'none',
                          userSelect: 'none',
                        }}
                      >
                        {isTrust
                          ? node.label
                          : truncateLabel(node.label, node.type === 'confirmer' ? 14 : 16)}
                      </text>
                      {isTrust && (
                        <text
                          textAnchor="middle"
                          dy={12}
                          style={{
                            fontSize: 8,
                            fontWeight: 500,
                            fill: color.text,
                            opacity: 0.7,
                            pointerEvents: 'none',
                            userSelect: 'none',
                          }}
                        >
                          {(node.status ?? '').toUpperCase()}
                        </text>
                      )}
                    </g>
                  );
                })}
              </g>
            </svg>

            {/* Legend */}
            <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1.5 text-xs">
              {TYPE_ORDER.map((t) => (
                <div key={t} className="flex items-center gap-1.5">
                  <span
                    className="inline-block w-2.5 h-2.5 rounded-full border"
                    style={{
                      backgroundColor: NODE_COLORS[t].fill,
                      borderColor: NODE_COLORS[t].stroke,
                    }}
                  />
                  <span className="text-muted-foreground">{NODE_COLORS[t].label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* === Side panel (non-compact only) === */}
          {!compact && (
            <div className="lg:w-72 shrink-0">
              {selectedNode ? (
                <NodeDetailPanel
                  node={selectedNode}
                  onClose={() => setSelectedId(null)}
                />
              ) : (
                <div className="rounded-lg border bg-muted/20 p-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2 mb-2 text-foreground">
                    <Sparkles className="size-4 text-primary" />
                    <span className="font-medium">Как читать граф</span>
                  </div>
                  <p className="text-xs leading-relaxed">
                    Кликните на любой узел, чтобы увидеть детали. Доказательства копятся
                    от Claim (утверждение) через Project, Skill, Confirmer, Result —
                    и формируют ваш Trust (репутацию).
                  </p>
                  <div className="mt-3 space-y-1 text-xs">
                    <div>• <span className="text-amber-600 font-medium">Claim</span> — что вы заявляете</div>
                    <div>• <span className="text-emerald-600 font-medium">Project</span> — где доказано</div>
                    <div>• <span className="text-teal-600 font-medium">Skill</span> — подтверждённый навыок</div>
                    <div>• <span className="text-blue-600 font-medium">Confirmer</span> — кто заверил</div>
                    <div>• <span className="text-violet-600 font-medium">Result</span> — измеримый итог</div>
                    <div>• <span className="text-pink-600 font-medium">Trust</span> — ваша репутация</div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ---------- node detail panel ----------
function NodeDetailPanel({
  node,
  onClose,
}: {
  node: GraphNode;
  onClose: () => void;
}) {
  const color = NODE_COLORS[node.type];
  const Icon = ICON_BY_TYPE[node.type] ?? Info;
  return (
    <div className="rounded-lg border bg-card p-4 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span
            className="inline-flex items-center justify-center rounded-md p-1.5"
            style={{ backgroundColor: color.fill, color: color.text }}
          >
            <Icon className="size-4" />
          </span>
          <span
            className="text-xs font-semibold uppercase tracking-wider"
            style={{ color: color.text }}
          >
            {color.label}
          </span>
        </div>
        <Button variant="ghost" size="icon" className="size-6" onClick={onClose}>
          <X className="size-3.5" />
        </Button>
      </div>
      <div className="text-sm font-semibold leading-snug">{node.label}</div>
      {node.description && (
        <div className="text-xs text-muted-foreground leading-relaxed">
          {node.description}
        </div>
      )}
      <div className="flex flex-wrap gap-1.5">
        {node.status && (
          <Badge variant="outline" className="text-xs capitalize">
            {node.status}
          </Badge>
        )}
        {node.role && (
          <Badge variant="secondary" className="text-xs">
            {node.role}
          </Badge>
        )}
        {node.meta?.type && (
          <Badge variant="outline" className="text-xs capitalize">
            {String(node.meta.type)}
          </Badge>
        )}
        {typeof node.meta?.level === 'number' && (
          <Badge variant="outline" className="text-xs">
            уровень {String(node.meta.level)}
          </Badge>
        )}
        {typeof node.meta?.confirmations === 'number' && (
          <Badge variant="outline" className="text-xs">
            подтверждений: {String(node.meta.confirmations)}
          </Badge>
        )}
        {typeof node.meta?.verifications === 'number' && node.meta.verifications > 0 && (
          <Badge variant="outline" className="text-xs">
            верификаций: {String(node.meta.verifications)}
          </Badge>
        )}
        {typeof node.meta?.verifiedClaims === 'number' && (
          <Badge variant="outline" className="text-xs">
            подтв. claims: {String(node.meta.verifiedClaims)}
          </Badge>
        )}
        {typeof node.meta?.ipScore === 'number' && (
          <Badge variant="outline" className="text-xs">
            IP-score: {String(node.meta.ipScore)}
          </Badge>
        )}
      </div>
    </div>
  );
}

const ICON_BY_TYPE: Record<NodeType, React.ComponentType<{ className?: string }>> = {
  claim: FileText,
  project: FolderKanban,
  skill: Award,
  confirmer: Users,
  result: Target,
  trust: ShieldCheck,
};
