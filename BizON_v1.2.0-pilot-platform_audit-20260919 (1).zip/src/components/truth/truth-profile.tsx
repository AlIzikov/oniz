// BizON — GPT Truth Engine: TruthProfile
// Страница «Ваша профессиональная правда» — сравнение «что вы заявляете» vs «что подтверждено».
// Загружает /api/reputation/evidence + /api/claims.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { StatusBadge } from '@/components/truth/status-badge';
import { ClaimCard, type Claim } from '@/components/truth/claim-card';
import { ProveItButton } from '@/components/truth/prove-it-button';
import { ClaimForm } from '@/components/truth/claim-form';
import { TruthGapDisplay } from '@/components/truth/truth-gap-display';
import { VerifyMeSummary } from '@/components/truth/verify-me-summary';
import { ReputationTimeline } from '@/components/truth/reputation-timeline';
import { ReputationMilestones } from '@/components/truth/reputation-milestones';
// P0-5: Professional Moments — Professional Change Loop (ЧАСТЬ 14)
import { ProfessionalMoments } from '@/components/truth/professional-moments';
// doc_a §41 — Professional Trust: 6-факторная формула «Экспертиза ≠ активность»
import { ProfessionalTrustCard } from '@/components/truth/professional-trust-card';
// Phase 5 — Skill Graph: explainable вектор навыков с decay и resurrection
import { SkillGraphView } from '@/components/truth/skill-graph-view';
// P1 — Career Scenario: «Что если получить навык X»
import { CareerScenarioCard } from '@/components/truth/career-scenario-card';
import { cn } from '@/lib/utils';
import {
  ShieldCheck,
  Plus,
  TrendingUp,
  AlertTriangle,
  Award,
  FolderKanban,
  FileText,
  Users,
} from 'lucide-react';

interface EvidenceResponse {
  userId: string;
  ipScore: number;
  level: string;
  breakdown: {
    projects: number;
    ratings: number;
    skills: number;
    activity: number;
  };
  evidence: {
    verifiedProjects: Array<{
      id: string;
      title: string;
      rating: number;
      role: string;
    }>;
    verifiedSkills: Array<{
      id: string;
      skill: string;
      level: number;
      confirmationsCount: number;
      verificationLevel: string;
      selfAssessment: number | null;
      verifiedScore: number | null;
    }>;
    recommendations: number;
    claims: { total: number; verified: number; pending: number };
  };
  evidenceCoverage: number;
}

interface ClaimsResponse {
  claims: Array<{
    id: string;
    type: string;
    title: string;
    description: string | null;
    status: string;
    projectId: string | null;
    skillId: string | null;
    verificationsCount: number;
    createdAt: string;
    updatedAt: string;
  }>;
}

export function TruthProfile({ className }: { className?: string }) {
  const [evidence, setEvidence] = React.useState<EvidenceResponse | null>(null);
  const [claims, setClaims] = React.useState<Claim[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [createOpen, setCreateOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const [evRes, clRes] = await Promise.all([
        api<EvidenceResponse>('/api/reputation/evidence'),
        api<ClaimsResponse>('/api/claims?pageSize=100'),
      ]);
      setEvidence(evRes);
      setClaims(clRes.claims as Claim[]);
    } catch (e: any) {
      toast({
        title: 'Не удалось загрузить данные',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  const coveragePct = Math.round((evidence?.evidenceCoverage ?? 0) * 100);
  const verifiedCount = claims.filter((c) => c.status !== 'claimed').length;
  const hasGaps = (evidence?.evidence.verifiedSkills ?? []).filter(
    (s) => s.selfAssessment !== null && s.verifiedScore !== null
  );

  return (
    <div className={cn('space-y-6', className)}>
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ShieldCheck className="size-6 text-emerald-600" />
            Ваша профессиональная правда
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Сравнение того, что вы заявляете, с тем, что подтверждено.
          </p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 text-white hover:bg-emerald-700">
              <Plus className="size-4" />
              Заявить о навыке
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="size-5" />
                Новое утверждение
              </DialogTitle>
            </DialogHeader>
            <ClaimForm
              onSuccess={() => {
                setCreateOpen(false);
                load();
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-24 w-full rounded-xl" />
          <div className="grid md:grid-cols-2 gap-4">
            <Skeleton className="h-48 rounded-xl" />
            <Skeleton className="h-48 rounded-xl" />
          </div>
        </div>
      ) : (
        <>
          {/* === doc_a §41 — PROFESSIONAL TRUST: 6-факторная формула === */}
          <ProfessionalTrustCard />

          {/* === P0-5: PROFESSIONAL MOMENTS — что изменилось (ЧАСТЬ 14) === */}
          <ProfessionalMoments limit={5} />

          {/* === Phase 5 — SKILL GRAPH: explainable вектор навыков === */}
          <SkillGraphView />

          {/* === P1 — CAREER SCENARIO: «Что если получить навык X» === */}
          <CareerScenarioCard />

          {/* СКОЛЬКО ПОДТВЕРЖДЕНО — бывший «Evidence Coverage» */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between text-base">
                <span className="flex items-center gap-2">
                  <TrendingUp className="size-4 text-emerald-600" />
                  Подтверждено
                </span>
                <span className="text-2xl font-bold tabular-nums">
                  {coveragePct}%
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Progress
                value={coveragePct}
                className={cn(
                  'h-2',
                  coveragePct > 80
                    ? 'bg-emerald-100 dark:bg-emerald-950/40 [&_[data-slot=progress-indicator]]:bg-emerald-500'
                    : coveragePct > 40
                      ? 'bg-amber-100 dark:bg-amber-950/40 [&_[data-slot=progress-indicator]]:bg-amber-500'
                      : ''
                )}
              />
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
                <StatCard
                  Icon={FileText}
                  label="Утверждений"
                  value={`${verifiedCount}/${claims.length}`}
                />
                <StatCard
                  Icon={FolderKanban}
                  label="Проектов"
                  value={String(evidence?.evidence.verifiedProjects.length ?? 0)}
                />
                <StatCard
                  Icon={Award}
                  label="Навыков"
                  value={String(evidence?.evidence.verifiedSkills.length ?? 0)}
                />
                <StatCard
                  Icon={Users}
                  label="Рекомендаций"
                  value={String(evidence?.evidence.recommendations ?? 0)}
                />
              </div>
            </CardContent>
          </Card>

          {/* REPUTATION TIMELINE + MILESTONES — рядом, в две колонки на md+ */}
          <div className="grid md:grid-cols-2 gap-4">
            <ReputationTimeline />
            <ReputationMilestones />
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {/* ЧТО ВЫ ЗАЯВЛЯЕТЕ — бывший «WHAT YOU CLAIM» */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="size-4 text-amber-500" />
                  Что вы заявляете
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {claims.length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="size-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground mb-3">
                      У вас пока нет утверждений. Подтвердите навык или опыт через PROVE IT —
                      и коллеги смогут за вас поручиться.
                    </p>
                    <ProveItButton type="claim" onClaimCreated={load} />
                  </div>
                ) : (
                  claims.map((c) => (
                    <ClaimCard
                      key={c.id}
                      claim={c}
                      onChanged={load}
                      showRequestVerify
                    />
                  ))
                )}
              </CardContent>
            </Card>

            {/* ЧТО ПОДТВЕРЖДЕНО — бывший «WHAT IS VERIFIED» */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <ShieldCheck className="size-4 text-emerald-600" />
                  Что подтверждено
                </CardTitle>
              </CardHeader>
              <CardContent>
                <VerifyMeSummary
                  data={evidence}
                  loading={loading}
                  autoLoad={false}
                  showHeader={false}
                />
              </CardContent>
            </Card>
          </div>

          {/* ЧТО ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ — бывший «TRUTH GAPS» */}
          {hasGaps.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="size-4 text-blue-500" />
                  Что требует подтверждения
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 gap-4">
                  {hasGaps.map((s) => (
                    <div
                      key={s.id}
                      className="rounded-lg border p-3 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{s.skill}</span>
                        <StatusBadge level={s.verificationLevel} size="sm" />
                      </div>
                      <TruthGapDisplay
                        userSkillId={s.id}
                        skillName={s.skill}
                        selfAssessment={s.selfAssessment}
                        verifiedScore={s.verifiedScore}
                        onSaved={load}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

// === Локальный мини-компонент: Stat Card ===
function StatCard({
  Icon,
  label,
  value,
}: {
  Icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border bg-muted/30 p-3">
      <Icon className="size-4 mx-auto mb-1 text-muted-foreground" />
      <div className="text-sm font-bold tabular-nums">{value}</div>
      <div className="text-xs text-muted-foreground uppercase tracking-wide">
        {label}
      </div>
    </div>
  );
}
