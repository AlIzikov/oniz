// BizON — NFT Skills View (Фаза 2)
// W1.3 (анти-фейк): backend-минт генерирует pseudo-tokenId (блокчейн НЕ подключён).
// Честность: действия отключены с объяснением; лживые метки «на блокчейне»,
// «Polygon», «ERC-1155» заменены на фактическое состояние.
// Полное решение по судьбе NFT-модуля — решение владельца (Q5, скрыть из лонч-навигации).
'use client';
import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { Award, Loader2, Sparkles, CheckCircle2, Clock, ExternalLink } from 'lucide-react';
import { cn } from '@/lib/utils';

export function NFTSkillsView() {
  const { user } = useAppStore();
  const [nftSkills, setNftSkills] = React.useState<any[]>([]);
  const [userSkills, setUserSkills] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const [nftRes, profileRes] = await Promise.all([
        api<{ nftSkills: any[] }>('/api/nft-skills'),
        api<{ skills: any[] }>(`/api/users/${user?.id}`),
      ]);
      setNftSkills(nftRes.nftSkills);
      setUserSkills(profileRes.skills);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally { setLoading(false); }
  }, [user?.id]);

  React.useEffect(() => { load(); }, [load]);

  // Навыки с 3+ подтверждениями, без NFT
  const eligibleSkills = userSkills.filter(s => s.confirmationsCount >= 3 && !nftSkills.some(n => n.userSkillId === s.id));

  async function requestMint(userSkillId: string, skillName: string) {
    // W1.3: создание записи внутри BizON возможно, но минта на блокчейне не будет —
    // сообщаем это честно до действия.
    try {
      await api('/api/nft-skills', { method: 'POST', body: JSON.stringify({ userSkillId }) });
      toast({ title: `Запись для «${skillName}» создана`, description: 'Блокчейн-контур не подключён — токен не выпускается.' });
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  if (loading) return <Skeleton className="h-48 w-full rounded-xl" />;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Award className="w-6 h-6 text-lighthouse" /> NFT-навыки</h1>
        <p className="text-sm text-muted-foreground">Внутренние записи о подтверждённых навыках. Блокчейн-выпуск токенов пока не подключён.</p>
      </div>

      {/* Info card */}
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-lighthouse mt-0.5" />
            <div className="text-sm">
              <div className="font-medium">Как это работает</div>
              <p className="text-xs text-muted-foreground mt-1">
                Навык с 3+ подтверждениями от коллег получает внутреннюю запись BizON.
                Выпуск блокчейн-токена появится после подключения реального блокчейн-контура —
                до этого «минт» недоступен, чтобы не создавать ложных представлений.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Minted NFTs */}
      {nftSkills.length > 0 && (
        <div>
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Ваши NFT-навыки ({nftSkills.length})</div>
          <div className="space-y-2">
            {nftSkills.map(nft => (
              <Card key={nft.id} className={cn('p-4', nft.status === 'minted' && 'border-lighthouse/30')}>
                <div className="flex items-center gap-3">
                  <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0', nft.status === 'minted' ? 'lighthouse-gradient' : 'bg-muted')}>
                    <Award className={cn('w-6 h-6', nft.status === 'minted' ? 'text-white' : 'text-muted-foreground')} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{nft.skillName}</span>
                      <Badge variant="outline" className="text-xs">Lvl {nft.level}</Badge>
                      {nft.status === 'minted' ? (
                        <Badge variant="outline" className="text-xs gap-0.5"><CheckCircle2 className="w-3 h-3" /> Запись создана</Badge>
                      ) : (
                        <Badge variant="outline" className="text-xs gap-0.5"><Clock className="w-3 h-3" /> Ожидает минта</Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {nft.endorsementsCount} подтверждений
                      {nft.tokenId && <span className="ml-2 font-mono">{nft.tokenId.slice(0, 10)}...</span>}
                    </div>
                  </div>
                  {nft.status === 'pending' && (
                    <Button
                      size="sm"
                      variant="outline"
                      disabled
                      title="Блокчейн-контур не подключён — минт токена недоступен"
                    >
                      Минт недоступен
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Eligible skills */}
      {eligibleSkills.length > 0 && (
        <div>
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Доступны для минта ({eligibleSkills.length})</div>
          <div className="space-y-2">
            {eligibleSkills.map(s => (
              <Card key={s.id} className="p-3 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center"><Award className="w-5 h-5 text-muted-foreground" /></div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{s.skill.name}</div>
                  <div className="text-xs text-muted-foreground">{s.confirmationsCount} подтверждений · Lvl {s.level}</div>
                </div>
                <Button size="sm" variant="outline" onClick={() => requestMint(s.id, s.skill.name)}>
                  <Sparkles className="w-3 h-3 mr-1" /> Токенизировать
                </Button>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* No eligible */}
      {eligibleSkills.length === 0 && nftSkills.length === 0 && (
        <Card className="p-8 text-center">
          <Award className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground text-sm">Нет навыков для токенизации. Нужно 3+ подтверждений.</p>
        </Card>
      )}
    </div>
  );
}
