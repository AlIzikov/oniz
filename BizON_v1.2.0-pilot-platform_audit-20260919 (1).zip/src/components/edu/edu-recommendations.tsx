// BizON — Этап 5.5 EDU: блок «Что изучить?»
// Показывается в Tab «Моя правда» (me-view.tsx) под TruthProfile.
// AI анализирует слабые навыки (Truth Gap) и рекомендует 3-5 курсов.
// Поддерживает запись на курс (POST /api/edu/enroll/[courseId]) и
// завершение с выдачей NFT-сертификата (POST /api/edu/complete/[userCourseId]).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  GraduationCap,
  ExternalLink,
  Loader2,
  CheckCircle2,
  Clock,
  Sparkles,
  Award,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Enrollment {
  id: string;
  status: string;
  startedAt: string;
  completedAt: string | null;
  certificateNftId: string | null;
}

interface RecommendedCourse {
  id: string;
  title: string;
  provider: string;
  providerId: string | null;
  url: string;
  durationHours: number | null;
  category: string;
  enrollment: Enrollment | null;
}

interface RecommendationsResponse {
  courses: RecommendedCourse[];
  rationale: string;
  engine: 'llm' | 'fallback';
  weakSkillsCount: number;
}

const PROVIDER_COLORS: Record<string, string> = {
  Coursera: 'bg-blue-100 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300',
  Udemy: 'bg-purple-100 text-purple-700 dark:bg-purple-950/50 dark:text-purple-300',
  Skillbox: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300',
  'BizON Academy': 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-300',
  Stepik: 'bg-orange-100 text-orange-700 dark:bg-orange-950/50 dark:text-orange-300',
  edX: 'bg-rose-100 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300',
  Pluralsight: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300',
};

export function EduRecommendations() {
  const [data, setData] = React.useState<RecommendationsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [actionLoadingId, setActionLoadingId] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<RecommendationsResponse>('/api/edu/recommendations');
      setData(res);
    } catch (e: any) {
      // Тихо показываем ошибку — блок не критичный
      console.error('[EduRecommendations] load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  async function handleEnroll(course: RecommendedCourse) {
    setActionLoadingId(course.id);
    try {
      await api(`/api/edu/enroll/${course.id}`, { method: 'POST' });
      toast({
        title: 'Вы записались на курс',
        description: course.title,
      });
      // Обновляем данные локально — устанавливаем enrollment
      setData((prev) =>
        prev
          ? {
              ...prev,
              courses: prev.courses.map((c) =>
                c.id === course.id
                  ? {
                      ...c,
                      enrollment: {
                        id: 'pending', // сервер вернёт реальный ID при следующем load
                        status: 'in_progress',
                        startedAt: new Date().toISOString(),
                        completedAt: null,
                        certificateNftId: null,
                      },
                    }
                  : c
              ),
            }
          : prev
      );
      // Подгружаем свежие данные с реальным enrollment ID
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e?.message, variant: 'destructive' });
    } finally {
      setActionLoadingId(null);
    }
  }

  async function handleComplete(course: RecommendedCourse) {
    if (!course.enrollment) return;
    setActionLoadingId(course.id);
    try {
      const res = await api<{ certificateNftId: string }>(
        `/api/edu/complete/${course.enrollment.id}`,
        { method: 'POST' }
      );
      toast({
        title: 'Курс завершён 🎓',
        description: `NFT-сертификат: ${res.certificateNftId}`,
      });
      setData((prev) =>
        prev
          ? {
              ...prev,
              courses: prev.courses.map((c) =>
                c.id === course.id && c.enrollment
                  ? {
                      ...c,
                      enrollment: {
                        ...c.enrollment,
                        status: 'completed',
                        completedAt: new Date().toISOString(),
                        certificateNftId: res.certificateNftId,
                      },
                    }
                  : c
              ),
            }
          : prev
      );
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e?.message, variant: 'destructive' });
    } finally {
      setActionLoadingId(null);
    }
  }

  return (
    <Card className="border-lighthouse/20">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <GraduationCap className="size-5 text-lighthouse" />
          Что изучить?
          {data && (
            <Badge
              variant="outline"
              className={cn(
                'text-xs gap-1',
                data.engine === 'llm'
                  ? 'border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                  : 'border-muted-foreground/40 text-muted-foreground'
              )}
            >
              <Sparkles className="size-3" />
              {data.engine === 'llm' ? 'AI-подбор' : 'эвристика'}
            </Badge>
          )}
          {data && data.weakSkillsCount > 0 && (
            <Badge variant="secondary" className="text-xs">
              {data.weakSkillsCount} слабых навыков
            </Badge>
          )}
        </CardTitle>
        {data?.rationale && (
          <p className="text-xs text-muted-foreground leading-relaxed mt-1">
            {data.rationale}
          </p>
        )}
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-lg" />
            ))}
          </div>
        ) : !data || data.courses.length === 0 ? (
          <div className="text-center py-8">
            <GraduationCap className="size-8 mx-auto mb-2 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">
              Каталог курсов пока пуст. Скоро добавим подборку от Coursera, Udemy, Skillbox и BizON Academy.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {data.courses.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                actionLoading={actionLoadingId === course.id}
                onEnroll={() => handleEnroll(course)}
                onComplete={() => handleComplete(course)}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function CourseCard({
  course,
  actionLoading,
  onEnroll,
  onComplete,
}: {
  course: RecommendedCourse;
  actionLoading: boolean;
  onEnroll: () => void;
  onComplete: () => void;
}) {
  const isEnrolled = !!course.enrollment;
  const isCompleted = course.enrollment?.status === 'completed';
  const providerColor = PROVIDER_COLORS[course.provider] ?? 'bg-muted text-muted-foreground';

  return (
    <div
      className={cn(
        'rounded-lg border p-3 space-y-2 transition',
        isCompleted ? 'border-emerald-500/30 bg-emerald-50/30 dark:bg-emerald-950/10' : 'border-border'
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <span
              className={cn(
                'inline-flex items-center px-1.5 py-0.5 rounded text-xs font-semibold',
                providerColor
              )}
            >
              {course.provider}
            </span>
            <Badge variant="outline" className="text-xs">{course.category}</Badge>
            {course.durationHours && (
              <span className="inline-flex items-center gap-0.5 text-xs text-muted-foreground">
                <Clock className="size-3" /> {course.durationHours}ч
              </span>
            )}
          </div>
          <h4 className="text-sm font-semibold leading-tight line-clamp-2">{course.title}</h4>
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <a
          href={course.url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
          onClick={(e) => e.stopPropagation()}
        >
          <ExternalLink className="size-3" />
          Открыть у провайдера
        </a>

        <div className="flex items-center gap-2">
          {isCompleted && course.enrollment?.certificateNftId && (
            <Badge variant="outline" className="text-xs gap-1 border-emerald-500/40 text-emerald-700 dark:text-emerald-300">
              <Award className="size-3" />
              Сертификат получен
            </Badge>
          )}
          {!isEnrolled && (
            <Button
              size="sm"
              onClick={onEnroll}
              disabled={actionLoading}
              className="gap-1.5 h-7 text-xs"
            >
              {actionLoading ? (
                <Loader2 className="size-3 animate-spin" />
              ) : (
                <GraduationCap className="size-3" />
              )}
              Записаться
            </Button>
          )}
          {isEnrolled && !isCompleted && (
            <Button
              size="sm"
              variant="outline"
              onClick={onComplete}
              disabled={actionLoading}
              className="gap-1.5 h-7 text-xs"
            >
              {actionLoading ? (
                <Loader2 className="size-3 animate-spin" />
              ) : (
                <CheckCircle2 className="size-3" />
              )}
              Завершить
            </Button>
          )}
          {isCompleted && (
            <Badge variant="secondary" className="text-xs gap-1">
              <CheckCircle2 className="size-3" />
              Завершён
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
