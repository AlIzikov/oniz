// BizON — ProjectNextSteps (v5.1 PROJ-2)
// Блок «Следующие шаги» для завершённого проекта.
// Показывает:
//   1. Skills Gained — навыки, подтверждённые участниками в проекте
//   2. Related Jobs — топ-10 релевантных вакансий по навыкам проекта (с match%)
//   3. Team Recommendations — участники команды доступны для hire/контакта
//
// Источник: GET /api/projects/[id]/related-jobs
// Логика: блок рендерится только когда project.status === 'COMPLETED' (или когда есть related-jobs).
'use client';

import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Sparkles, Briefcase, ArrowRight, CheckCircle2, Zap, Award,
  Users, TrendingUp, ChevronRight, Loader2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAppStore, api } from '@/stores/app-store';
import { TrustBadge } from '@/components/common/trust-badge';

interface RelatedJob {
  id: string;
  title: string;
  company: string;
  companyId: string | null;
  description: string;
  requiredSkills: string[];
  matchedSkills: string[];
  matchScore: number;
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  location: string | null;
  boosted: boolean;
  verificationStatus: 'draft' | 'posted' | 'verified';
  vacancyTrust: number;
  hiringManager: {
    id: string; name: string; title: string | null;
    avatarUrl: string | null; ipScore: number; level: string;
  } | null;
  responseTimeHours: number | null;
  createdAt: string;
}

interface SkillGained {
  skillId: string;
  skillName: string;
  category: string | null;
  verifiedCount: number;
  inProjectSpec: boolean;
}

interface TeamMember {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  ipScore: number;
  level: string;
  role: string;
  verifiedSkillsCount: number;
}

interface RelatedJobsResponse {
  projectId: string;
  projectTitle: string;
  projectStatus: string;
  isCompleted: boolean;
  completedAt: string | null;
  projectSkills: string[];
  skillsGained: SkillGained[];
  relatedJobs: RelatedJob[];
  teamMembers: TeamMember[];
  membersCount: number;
  metrics: {
    totalJobsFound: number;
    highMatchJobs: number;
    totalSkillsGained: number;
    inSpecSkillsGained: number;
  };
  message?: string;
}

const ROLE_LABELS: Record<string, string> = {
  FOUNDER: 'Основатель',
  CO_FOUNDER: 'Кофаундер',
  CONTRIBUTOR: 'Участник',
  MENTOR: 'Ментор',
  OBSERVER: 'Наблюдатель',
};

function formatSalary(job: RelatedJob): string | null {
  const from = job.salaryMin ?? job.salaryFrom;
  const to = job.salaryMax ?? job.salaryTo;
  if (!from && !to) return null;
  const fmt = (n: number) => {
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
    if (n >= 1000) return `${(n / 1000).toFixed(0)}k`;
    return `${n}`;
  };
  const cur = job.currency === 'RUB' ? '₽' : job.currency === 'USD' ? '$' : job.currency === 'EUR' ? '€' : ` ${job.currency}`;
  if (from && to) return `${fmt(from)}–${fmt(to)}${cur}`;
  if (from) return `от ${fmt(from)}${cur}`;
  if (to) return `до ${fmt(to)}${cur}`;
  return null;
}

function matchColor(match: number): string {
  if (match >= 0.7) return 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30';
  if (match >= 0.4) return 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30';
  return 'bg-muted text-muted-foreground border-border';
}

interface ProjectNextStepsProps {
  projectId: string;
  /** Сколько вакансий показывать (по умолчанию 3) */
  maxJobs?: number;
  /** Сколько навыков показывать (по умолчанию 8) */
  maxSkills?: number;
  /** Сколько участников показывать (по умолчанию 4) */
  maxMembers?: number;
}

export function ProjectNextSteps({
  projectId,
  maxJobs = 3,
  maxSkills = 8,
  maxMembers = 4,
}: ProjectNextStepsProps) {
  const setView = useAppStore((s) => s.setView);
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const [data, setData] = React.useState<RelatedJobsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(false);
  const [expanded, setExpanded] = React.useState(false);

  // Lazy-load — только когда expanded (для производительности, чтобы не дёргать API для каждого проекта в списке)
  React.useEffect(() => {
    if (!expanded) return;
    let cancelled = false;
    setLoading(true);
    api<RelatedJobsResponse>(`/api/projects/${projectId}/related-jobs`)
      .then((res) => {
        if (!cancelled) {
          setData(res);
          setError(false);
        }
      })
      .catch((e) => {
        console.warn('[ProjectNextSteps] load failed:', e);
        if (!cancelled) setError(true);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [projectId, expanded]);

  // Если ещё не expanded — показываем compact CTA
  if (!expanded) {
    return (
      <div className="rounded-lg border border-lighthouse/20 bg-lighthouse/5 p-3 mt-3">
        <button
          type="button"
          onClick={() => setExpanded(true)}
          className="w-full flex items-center gap-2 text-left"
        >
          <Sparkles className="w-4 h-4 text-lighthouse flex-shrink-0" />
          <div className="flex-1 text-sm">
            <div className="font-medium text-foreground/90">Следующие шаги команды</div>
            <div className="text-xs text-muted-foreground">
              Подбор вакансий по подтверждённым навыкам проекта
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>
    );
  }

  // Loading state
  if (loading) {
    return (
      <div className="rounded-lg border border-lighthouse/20 bg-lighthouse/5 p-3 mt-3 space-y-2">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Loader2 className="w-4 h-4 animate-spin text-lighthouse" />
          Анализ навыков и подбор вакансий…
        </div>
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  // Error state
  if (error || !data) {
    return (
      <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-3 mt-3 text-sm text-destructive">
        Не удалось загрузить следующие шаги.{' '}
        <button onClick={() => setExpanded(false)} className="underline">Свернуть</button>
      </div>
    );
  }

  const visibleJobs = data.relatedJobs.slice(0, maxJobs);
  const visibleSkills = data.skillsGained.slice(0, maxSkills);
  const visibleMembers = data.teamMembers.slice(0, maxMembers);
  const hasMoreJobs = data.relatedJobs.length > maxJobs;

  return (
    <div className="rounded-lg border border-lighthouse/30 bg-gradient-to-br from-lighthouse/5 to-transparent p-4 mt-3 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md lighthouse-gradient flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <div>
            <div className="text-sm font-semibold">Следующие шаги команды</div>
            <div className="text-xs text-muted-foreground">
              {data.metrics.totalJobsFound > 0
                ? `${data.metrics.totalJobsFound} вакансий по навыкам проекта`
                : 'Нет релевантных вакансий на сейчас'}
            </div>
          </div>
        </div>
        <button
          onClick={() => setExpanded(false)}
          className="text-xs text-muted-foreground hover:text-foreground"
        >
          Свернуть
        </button>
      </div>

      {/* Skills Gained */}
      {visibleSkills.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            <Award className="w-3.5 h-3.5" />
            Подтверждённые навыки команды
            <Badge variant="secondary" className="text-xs ml-1">{data.metrics.totalSkillsGained}</Badge>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {visibleSkills.map((s) => (
              <Badge
                key={s.skillId}
                className={cn(
                  'text-xs gap-1',
                  s.inProjectSpec
                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
                    : 'bg-secondary',
                )}
                title={`${s.skillName} — ${s.verifiedCount} подтверждений`}
              >
                {s.inProjectSpec && <CheckCircle2 className="w-3 h-3" />}
                {s.skillName}
                <span className="opacity-70 text-xs">×{s.verifiedCount}</span>
              </Badge>
            ))}
            {data.skillsGained.length > maxSkills && (
              <span className="text-xs text-muted-foreground self-center">
                +{data.skillsGained.length - maxSkills}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Related Jobs */}
      {visibleJobs.length > 0 ? (
        <div>
          <div className="flex items-center gap-1.5 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            <Briefcase className="w-3.5 h-3.5" />
            Релевантные вакансии
            {data.metrics.highMatchJobs > 0 && (
              <Badge className="ml-1 text-xs bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30">
                <TrendingUp className="w-3 h-3 mr-0.5" />
                {data.metrics.highMatchJobs} с высоким match
              </Badge>
            )}
          </div>
          <div className="space-y-2">
            {visibleJobs.map((job) => {
              const salary = formatSalary(job);
              const matchPercent = Math.round(job.matchScore * 100);
              return (
                <button
                  key={job.id}
                  onClick={() => setView('jobs')}
                  className="w-full text-left rounded-lg border bg-card hover:border-primary/40 hover:shadow-sm transition p-3 group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate group-hover:text-primary transition flex items-center gap-1.5">
                        {job.title}
                        {job.boosted && (
                          <Badge variant="outline" className="text-xs px-1 py-0 h-3.5 bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30">
                            <Zap className="w-2.5 h-2.5" />
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground truncate">
                        {job.company}
                        {job.location ? ` · ${job.location}` : ''}
                        {salary ? ` · ${salary}` : ''}
                      </div>
                    </div>
                    <div className={cn(
                      'flex-shrink-0 px-2 py-0.5 rounded-md border text-xs font-bold tabular-nums',
                      matchColor(job.matchScore),
                    )}>
                      {matchPercent}%
                    </div>
                  </div>
                  {/* Matched skills */}
                  {job.matchedSkills.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      <span className="text-xs text-muted-foreground self-center mr-0.5">Совпало:</span>
                      {job.matchedSkills.slice(0, 4).map((s) => (
                        <Badge key={s} variant="secondary" className="text-xs px-1.5 py-0 h-3.5 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                          {s}
                        </Badge>
                      ))}
                    </div>
                  )}
                </button>
              );
            })}
            {hasMoreJobs && (
              <Button
                variant="ghost"
                size="sm"
                className="w-full text-xs gap-1"
                onClick={() => setView('jobs')}
              >
                Показать все {data.relatedJobs.length} вакансий
                <ArrowRight className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>
        </div>
      ) : (
        <div className="text-xs text-muted-foreground bg-muted/30 rounded-md p-3 text-center">
          Нет активных вакансий, точно совпадающих с навыками проекта.
          Попробуйте изменить <code>requiredSkills</code> проекта или проверить позже.
        </div>
      )}

      {/* Team Recommendations */}
      {visibleMembers.length > 0 && (
        <div>
          <div className="flex items-center gap-1.5 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            <Users className="w-3.5 h-3.5" />
            Команда доступна для контакта
          </div>
          <div className="space-y-1.5">
            {visibleMembers.map((m) => (
              <button
                key={m.id}
                onClick={() => {
                  setProfileUserId(m.id);
                  setView('profile');
                }}
                className="w-full flex items-center gap-2 p-2 rounded-md hover:bg-accent transition text-left"
              >
                <Avatar className="w-6 h-6">
                  <AvatarImage src={m.avatarUrl ?? undefined} alt={m.name} />
                  <AvatarFallback className="text-xs">
                    {m.name.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">{m.name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {ROLE_LABELS[m.role] ?? m.role}
                    {m.title ? ` · ${m.title}` : ''}
                  </div>
                </div>
                {m.verifiedSkillsCount > 0 && (
                  <Badge variant="outline" className="text-xs px-1.5 py-0 h-3.5 gap-0.5">
                    <Award className="w-2.5 h-2.5" />
                    {m.verifiedSkillsCount}
                  </Badge>
                )}
                <TrustBadge ipScore={m.ipScore} level={m.level as any} size="sm" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
