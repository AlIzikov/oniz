// BizON — Этап 3.3 PROJ: ProjectCard с вариантами по статусу
// IDEA: 💡 концепт + кого ищу + финансирование
// PROPOSAL: 📋 конкретное предложение + сроки + роли
// ACTIVE: 🚀 команда + прогресс (спринты) + апдейты
// COMPLETED: ✅ результат + NFT-навыки выданы
// ON_HOLD / CANCELLED — компактный вид
'use client';

import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { UserAvatar } from '@/components/common/user-avatar';
import { cn } from '@/lib/utils';
import {
  Banknote,
  Gift,
  PieChart,
  ArrowLeftRight,
  GraduationCap,
  Handshake,
  Users,
  Check,
  Bell,
  BookOpen,
  Star,
  Lock,
  EyeOff,
  Eye,
  ShieldCheck,
  Sparkles,
  type LucideIcon,
} from 'lucide-react';
import type { ProjectPublic, ProjectFundingType } from '@/lib/types';
import {
  PROJECT_FUNDING_LABELS,
  PROJECT_FUNDING_EMOJI,
  PROJECT_STATUS_LABELS,
  PROJECT_STATUS_EMOJI,
  PROJECT_STATUS_COLORS,
  PROJECT_ROLE_LABELS,
  PROJECT_VISIBILITY_EMOJI,
} from '@/lib/projects/constants';

// ProjectPublic в '@/lib/types' объявляет requiredSkills как обязательный string[],
// но текущий GET /api/projects это поле ещё не отдаёт — локально ослабляем до optional
// и рендерим блок навыков условно (иначе runtime-краш на undefined).
type ProjectCardProject = ProjectPublic & { requiredSkills?: string[] };

// === Funding icon mapping ===
const FUNDING_ICONS: Record<ProjectFundingType, LucideIcon> = {
  PAID: Banknote,
  FREE: Gift,
  EQUITY: PieChart,
  BARTER: ArrowLeftRight,
  MENTORSHIP: GraduationCap,
  VOLUNTEER: Handshake,
};

function FundingIcon({ type }: { type: string }) {
  const Icon = FUNDING_ICONS[type as ProjectFundingType] ?? Gift;
  return <Icon className="w-3.5 h-3.5" />;
}

// === Visibility badge ===
function VisibilityBadge({ visibility }: { visibility: string }) {
  if (visibility === 'PUBLIC') return null;
  const labels: Record<string, string> = {
    COMMUNITY: '👥 Сообщество',
    PRIVATE: '🔗 По ссылке',
    STEALTH: '🤫 Stealth',
  };
  return (
    <span className="text-xs text-muted-foreground flex items-center gap-1">
      {labels[visibility] ?? visibility}
    </span>
  );
}

interface ProjectCardProps {
  project: ProjectCardProject;
  currentUserId?: string;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  onJoin?: () => void;
  onFollow?: () => void;
  onViewCase?: () => void;
  following?: boolean;
}

export function ProjectCard({
  project: p,
  currentUserId,
  onOpen,
  onMemberClick,
  onJoin,
  onFollow,
  onViewCase,
  following,
}: ProjectCardProps) {
  const isMember = p.members.some((m) => m.userId === currentUserId);
  const isOwner = p.owner.id === currentUserId;
  const status = (p.status as string) ?? 'PROPOSAL';

  // === Variant rendering by status ===
  if (status === 'IDEA') return <IdeaCard {...{ project: p, onOpen, onMemberClick, isMember, isOwner, onJoin }} />;
  if (status === 'PROPOSAL') return <ProposalCard {...{ project: p, onOpen, onMemberClick, isMember, isOwner, onJoin }} />;
  if (status === 'ACTIVE') return <ActiveCard {...{ project: p, onOpen, onMemberClick, following, onFollow }} />;
  if (status === 'COMPLETED') return <CompletedCard {...{ project: p, onOpen, onMemberClick, onViewCase }} />;
  if (status === 'ON_HOLD') return <CompactCard {...{ project: p, onOpen, onMemberClick, variant: 'ON_HOLD' }} />;
  if (status === 'CANCELLED') return <CompactCard {...{ project: p, onOpen, onMemberClick, variant: 'CANCELLED' }} />;
  return <CompactCard {...{ project: p, onOpen, onMemberClick, variant: 'DEFAULT' }} />;
}

// === Shared header used by all variants ===
function CardHeader({
  project: p,
  onOpen,
  status,
}: {
  project: ProjectCardProject;
  onOpen: () => void;
  status: string;
}) {
  return (
    <div className="flex items-start justify-between gap-3 mb-2">
      <button onClick={onOpen} className="text-left flex-1 min-w-0">
        <h3 className="text-lg font-bold hover:text-primary transition line-clamp-2 flex items-center gap-2">
          <span className="text-base" aria-hidden>
            {PROJECT_STATUS_EMOJI[status as keyof typeof PROJECT_STATUS_EMOJI] ?? '📋'}
          </span>
          {p.title}
        </h3>
      </button>
      <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap justify-end">
        <Badge variant="outline" className={cn('text-xs whitespace-nowrap', PROJECT_STATUS_COLORS[status as keyof typeof PROJECT_STATUS_COLORS] ?? '')}>
          {PROJECT_STATUS_LABELS[status as keyof typeof PROJECT_STATUS_LABELS] ?? status}
        </Badge>
        <Badge variant="outline" className="text-xs whitespace-nowrap" title={PROJECT_FUNDING_LABELS[p.fundingType as ProjectFundingType] ?? p.fundingType}>
          <FundingIcon type={p.fundingType} />
          <span className="ml-1 hidden sm:inline">
            {PROJECT_FUNDING_LABELS[p.fundingType as ProjectFundingType] ?? p.fundingType}
          </span>
        </Badge>
      </div>
    </div>
  );
}

// === Team avatars row ===
function TeamRow({
  project: p,
  onMemberClick,
  max = 5,
}: {
  project: ProjectCardProject;
  onMemberClick: (id: string) => void;
  max?: number;
}) {
  return (
    <div className="border-t pt-3 mt-3">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
        <Users className="w-3 h-3" /> Команда ({p.members.length})
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex -space-x-2">
          {p.members.slice(0, max).map((m) => (
            <button
              key={m.userId}
              onClick={() => onMemberClick(m.userId)}
              className="ring-2 ring-card rounded-full hover:z-10 hover:scale-110 transition"
              title={`${m.user.name} (${PROJECT_ROLE_LABELS[m.role as keyof typeof PROJECT_ROLE_LABELS] ?? m.role})`}
            >
              <UserAvatar name={m.user.name} avatarUrl={m.user.avatarUrl} size="sm" />
            </button>
          ))}
          {p.members.length > max && (
            <div className="w-8 h-8 rounded-full bg-muted ring-2 ring-card flex items-center justify-center text-xs font-medium">
              +{p.members.length - max}
            </div>
          )}
        </div>
        <span className="text-xs text-muted-foreground">
          {p.members.slice(0, 3).map((m) => m.user.name.split(' ')[0]).join(', ')}
          {p.members.length > 3 && ` и ещё ${p.members.length - 3}`}
        </span>
      </div>
    </div>
  );
}

// === IDEA variant: 💡 концепт + кого ищу + финансирование ===
function IdeaCard({
  project: p,
  onOpen,
  onMemberClick,
  isMember,
  isOwner,
  onJoin,
}: {
  project: ProjectCardProject;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  isMember: boolean;
  isOwner: boolean;
  onJoin?: () => void;
}) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow border-amber-400/20">
      <div className="h-1.5 bg-gradient-to-r from-amber-400 to-yellow-300" />
      <CardContent className="p-5">
        <CardHeader project={p} onOpen={onOpen} status="IDEA" />

        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-3">{p.description}</p>

        {p.lookingFor && (
          <div className="mb-3 p-2.5 rounded-lg bg-amber-400/5 border border-amber-400/20">
            <div className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Кого ищу
            </div>
            <p className="text-sm">{p.lookingFor}</p>
          </div>
        )}

        {p.requiredSkills && p.requiredSkills.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {p.requiredSkills.slice(0, 6).map((s) => (
              <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
            ))}
            {p.requiredSkills.length > 6 && (
              <Badge variant="outline" className="text-xs">+{p.requiredSkills.length - 6}</Badge>
            )}
          </div>
        )}

        <FundingInfo project={p} />

        <TeamRow project={p} onMemberClick={onMemberClick} />

        <CardFooterActions>
          <Button size="sm" variant="ghost" onClick={onOpen}>Читать</Button>
          {!isMember && !isOwner && onJoin && (
            <Button size="sm" variant="outline" onClick={onJoin}>
              <Users className="w-3 h-3 mr-1" /> Откликнуться
            </Button>
          )}
        </CardFooterActions>
      </CardContent>
    </Card>
  );
}

// === PROPOSAL variant: 📋 конкретное предложение + сроки + роли ===
function ProposalCard({
  project: p,
  onOpen,
  onMemberClick,
  isMember,
  isOwner,
  onJoin,
}: {
  project: ProjectCardProject;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  isMember: boolean;
  isOwner: boolean;
  onJoin?: () => void;
}) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow border-lighthouse/20">
      <div className="h-1.5 lighthouse-gradient" />
      <CardContent className="p-5">
        <CardHeader project={p} onOpen={onOpen} status="PROPOSAL" />

        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-3">{p.description}</p>

        {p.lookingFor && (
          <div className="mb-3 p-2.5 rounded-lg bg-lighthouse/5 border border-lighthouse/20">
            <div className="text-xs font-semibold text-lighthouse uppercase tracking-wider mb-1 flex items-center gap-1">
              <Users className="w-3 h-3" /> Ищем в команду
            </div>
            <p className="text-sm">{p.lookingFor}</p>
          </div>
        )}

        {p.requiredSkills && p.requiredSkills.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {p.requiredSkills.slice(0, 6).map((s) => (
              <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
            ))}
            {p.requiredSkills.length > 6 && (
              <Badge variant="outline" className="text-xs">+{p.requiredSkills.length - 6}</Badge>
            )}
          </div>
        )}

        <FundingInfo project={p} />

        {p.ndaRequired && (
          <div className="flex items-center gap-1.5 mb-3 text-xs text-muted-foreground">
            <Lock className="w-3 h-3" /> Требуется NDA
          </div>
        )}

        <TeamRow project={p} onMemberClick={onMemberClick} />

        <CardFooterActions>
          <Button size="sm" variant="ghost" onClick={onOpen}>Читать предложение</Button>
          {!isMember && !isOwner && onJoin && (
            <Button size="sm" variant="default" onClick={onJoin}>
              <Users className="w-3 h-3 mr-1" /> Откликнуться
            </Button>
          )}
        </CardFooterActions>
      </CardContent>
    </Card>
  );
}

// === ACTIVE variant: 🚀 команда + прогресс + апдейты ===
function ActiveCard({
  project: p,
  onOpen,
  onMemberClick,
  following,
  onFollow,
}: {
  project: ProjectCardProject;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  following?: boolean;
  onFollow?: () => void;
}) {
  const progress = Math.max(0, Math.min(100, p.progress || 0));
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow border-emerald-500/20">
      <div className="h-1.5 bg-gradient-to-r from-emerald-500 to-teal-400" />
      <CardContent className="p-5">
        <CardHeader project={p} onOpen={onOpen} status="ACTIVE" />

        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 mb-3">{p.description}</p>

        {/* Прогресс спринтов */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              Прогресс проекта
            </span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {p.requiredSkills && p.requiredSkills.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {p.requiredSkills.slice(0, 5).map((s) => (
              <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
            ))}
          </div>
        )}

        <FundingInfo project={p} />

        <TeamRow project={p} onMemberClick={onMemberClick} />

        <CardFooterActions>
          <Button size="sm" variant="ghost" onClick={onOpen}>
            <BookOpen className="w-3 h-3 mr-1" /> Апдейты
          </Button>
          {onFollow && (
            <Button size="sm" variant={following ? 'default' : 'outline'} onClick={onFollow}>
              <Bell className="w-3 h-3 mr-1" /> {following ? 'Отписаться' : 'Следить'}
            </Button>
          )}
        </CardFooterActions>
      </CardContent>
    </Card>
  );
}

// === COMPLETED variant: ✅ результат + NFT-навыки выданы ===
function CompletedCard({
  project: p,
  onOpen,
  onMemberClick,
  onViewCase,
}: {
  project: ProjectCardProject;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  onViewCase?: () => void;
}) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow border-success/20">
      <div className="h-1.5 bg-gradient-to-r from-success to-emerald-400" />
      <CardContent className="p-5">
        <CardHeader project={p} onOpen={onOpen} status="COMPLETED" />

        {p.outcome ? (
          <div className="mb-3 p-2.5 rounded-lg bg-success/5 border border-success/20">
            <div className="text-xs font-semibold text-success-text uppercase tracking-wider mb-1 flex items-center gap-1">
              <Check className="w-3 h-3" /> Результат
            </div>
            <p className="text-sm line-clamp-3">{p.outcome}</p>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-3">{p.description}</p>
        )}

        {/* §3.3 (S-080): вместо числа рейтинга — факт верификации заказчиком + NFT-навыки */}
        <div className="flex items-center gap-3 mb-3">
          {p.clientVerified && (
            <div className="flex items-center gap-1 text-sm">
              <ShieldCheck className="w-4 h-4 text-lighthouse" />
              <span className="text-xs text-muted-foreground">подтверждён заказчиком</span>
            </div>
          )}
          <div className="flex items-center gap-1 text-xs text-muted-foreground" title="Участникам выданы NFT-навыки">
            <ShieldCheck className="w-3.5 h-3.5 text-lighthouse" />
            NFT-навыки подтверждены
          </div>
        </div>

        {p.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {p.tags.slice(0, 4).map((t) => (
              <Badge key={t} variant="secondary" className="text-xs">#{t}</Badge>
            ))}
          </div>
        )}

        <TeamRow project={p} onMemberClick={onMemberClick} />

        <CardFooterActions>
          <Button size="sm" variant="ghost" onClick={onOpen}>Открыть</Button>
          {onViewCase && (
            <Button size="sm" variant="outline" onClick={onViewCase}>
              <BookOpen className="w-3 h-3 mr-1" /> Читать кейс
            </Button>
          )}
        </CardFooterActions>
      </CardContent>
    </Card>
  );
}

// === Compact card (ON_HOLD / CANCELLED / DEFAULT) ===
function CompactCard({
  project: p,
  onOpen,
  onMemberClick,
  variant,
}: {
  project: ProjectCardProject;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  variant: 'ON_HOLD' | 'CANCELLED' | 'DEFAULT';
}) {
  const status = variant === 'DEFAULT' ? (p.status as string) : variant;
  return (
    <Card className="overflow-hidden opacity-75 hover:opacity-100 transition-opacity">
      <CardContent className="p-4">
        <CardHeader project={p} onOpen={onOpen} status={status} />
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 mb-2">{p.description}</p>
        <TeamRow project={p} onMemberClick={onMemberClick} max={3} />
        <CardFooterActions>
          <Button size="sm" variant="ghost" onClick={onOpen}>Открыть</Button>
        </CardFooterActions>
      </CardContent>
    </Card>
  );
}

// === Funding info block (для PAID/EQUITY показываем детали) ===
function FundingInfo({ project: p }: { project: ProjectPublic }) {
  const type = p.fundingType as ProjectFundingType;
  if (type === 'PAID' && p.budget) {
    return (
      <div className="flex items-center gap-1.5 mb-3 text-sm">
        <Banknote className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
        <span className="font-semibold">{p.budget.toLocaleString('ru-RU')} ₽</span>
        <span className="text-muted-foreground text-xs">бюджет проекта</span>
      </div>
    );
  }
  if (type === 'EQUITY' && p.equityPercent != null) {
    return (
      <div className="flex items-center gap-1.5 mb-3 text-sm">
        <PieChart className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
        <span className="font-semibold">{p.equityPercent}%</span>
        <span className="text-muted-foreground text-xs">доля · требуется юрист</span>
      </div>
    );
  }
  // Для других типов — показываем просто иконку + label
  return (
    <div className="flex items-center gap-1.5 mb-3 text-xs text-muted-foreground">
      <FundingIcon type={type} />
      <span>{PROJECT_FUNDING_LABELS[type] ?? type}</span>
    </div>
  );
}

function CardFooterActions({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 mt-4 pt-3 border-t flex-wrap">{children}</div>
  );
}
