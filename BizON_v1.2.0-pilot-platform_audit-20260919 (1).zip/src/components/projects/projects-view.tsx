// BizON — Projects View (как статьи в журнале)
// Идеология: каждый проект — это статья с описанием, участниками и ссылками на их профили.
// Люди продвигают себя, а другие подтверждают — нельзя накрутить.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { toast } from '@/hooks/use-toast';
import type { ProjectPublic } from '@/lib/types';
import { Plus, FolderKanban, Users, Loader2, Check, Award, ShieldCheck } from 'lucide-react';
import { ProjectRoomTabs } from '@/components/projects/project-room';
import { cn } from '@/lib/utils';

export function ProjectsView() {
  const { user, setProfileUserId, selectedProjectId, setSelectedProjectId } = useAppStore();
  const [projects, setProjects] = React.useState<ProjectPublic[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<'all' | 'recruiting' | 'active' | 'completed'>('all');

  const loadProjects = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ projects: ProjectPublic[] }>(`/api/projects${filter !== 'all' ? `?status=${filter}` : ''}`);
      setProjects(res.projects);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [filter]);

  React.useEffect(() => { loadProjects(); }, [loadProjects]);

  const selectedProject = projects.find((p) => p.id === selectedProjectId);

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-bold">Проекты</h1>
          <p className="text-sm text-muted-foreground">Каждый проект — статья о реальной работе. Нельзя накрутить.</p>
        </div>
        <CreateProjectDialog onCreated={loadProjects} />
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1 border-b">
        {(['all', 'recruiting', 'active', 'completed'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              'px-3 py-1.5 text-sm border-b-2 -mb-px transition',
              filter === f ? 'border-primary text-primary font-medium' : 'border-transparent text-muted-foreground hover:text-foreground'
            )}
          >
            {f === 'all' ? 'Все' : f === 'recruiting' ? 'Набор' : f === 'active' ? 'Активные' : 'Завершённые'}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 w-full rounded-xl" />)}
        </div>
      ) : projects.length === 0 ? (
        <Card className="p-8 text-center">
          <FolderKanban className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">Проектов пока нет. Создайте первый!</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {projects.map((p) => (
            <ProjectArticle key={p.id} project={p} onOpen={() => setSelectedProjectId(p.id)} onMemberClick={setProfileUserId} currentUserId={user?.id} onChanged={loadProjects} />
          ))}
        </div>
      )}

      {/* Project detail as magazine article */}
      <ProjectArticleDialog
        project={selectedProject}
        onClose={() => setSelectedProjectId(null)}
        currentUserId={user?.id}
        onChanged={loadProjects}
      />
    </div>
  );
}

// === PROJECT AS MAGAZINE ARTICLE ===
function ProjectArticle({ project: p, onOpen, onMemberClick, currentUserId, onChanged }: {
  project: ProjectPublic;
  onOpen: () => void;
  onMemberClick: (id: string) => void;
  currentUserId?: string;
  onChanged: () => void;
}) {
  const isMember = p.members.some((m) => m.userId === currentUserId);
  const isOwner = p.owner.id === currentUserId;

  async function handleJoin() {
    try {
      await api(`/api/projects/${p.id}`, { method: 'PATCH', body: JSON.stringify({ action: 'join' }) });
      toast({ title: 'Вы присоединились к проекту' });
      onChanged();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handleComplete() {
    try {
      await api(`/api/projects/${p.id}`, { method: 'PATCH', body: JSON.stringify({ action: 'complete' }) });
      toast({ title: 'Проект завершён. Репутация обновлена.' });
      onChanged();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      {/* Cover-like header */}
      <div className="h-2 lighthouse-gradient" />

      <CardContent className="p-5">
        {/* Title + status badge */}
        <div className="flex items-start justify-between gap-3 mb-2">
          <button onClick={onOpen} className="text-left flex-1 min-w-0">
            <h3 className="text-xl font-bold hover:text-primary transition">{p.title}</h3>
          </button>
          <Badge variant="outline" className={cn('text-xs whitespace-nowrap', statusColor(p.status))}>
            {statusLabel(p.status)}
          </Badge>
        </div>

        {/* Description — like article excerpt */}
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3 mb-3">{p.description}</p>

        {/* Tags — like article keywords */}
        {p.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {p.tags.map((t) => <Badge key={t} variant="secondary" className="text-xs">#{t}</Badge>)}
          </div>
        )}

        {/* §3.3: вместо числа рейтинга — честный факт верификации заказчиком */}
        {p.clientVerified && (
          <div className="flex items-center gap-2 mb-3 text-sm">
            <ShieldCheck className="w-4 h-4 text-lighthouse" />
            <span className="text-muted-foreground">Проект подтверждён заказчиком</span>
          </div>
        )}

        {/* Participants — like article authors */}
        <div className="border-t pt-3 mt-3">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
            <Users className="w-3 h-3" /> Команда ({p.members.length})
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex -space-x-2">
              {p.members.slice(0, 5).map((m) => (
                <button
                  key={m.userId}
                  onClick={() => onMemberClick(m.userId)}
                  className="ring-2 ring-card rounded-full hover:z-10 hover:scale-110 transition"
                  title={`${m.user.name} (${roleLabel(m.role)})`}
                >
                  <UserAvatar name={m.user.name} avatarUrl={m.user.avatarUrl} size="sm" />
                </button>
              ))}
              {p.members.length > 5 && (
                <div className="w-8 h-8 rounded-full bg-muted ring-2 ring-card flex items-center justify-center text-xs font-medium">
                  +{p.members.length - 5}
                </div>
              )}
            </div>
            <span className="text-xs text-muted-foreground">
              {p.members.slice(0, 3).map((m) => m.user.name.split(' ')[0]).join(', ')}
              {p.members.length > 3 && ` и ещё ${p.members.length - 3}`}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 mt-4 pt-3 border-t">
          <Button size="sm" variant="ghost" onClick={onOpen}>Читать статью</Button>
          {!isMember && p.status === 'recruiting' && (
            <Button size="sm" variant="outline" onClick={handleJoin}>
              <Users className="w-3 h-3 mr-1" /> Участвовать
            </Button>
          )}
          {isOwner && p.status !== 'completed' && (
            <Button size="sm" variant="outline" onClick={handleComplete}>
              <Check className="w-3 h-3 mr-1" /> Завершить
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// === PROJECT DETAIL — full magazine article ===
function ProjectArticleDialog({ project: p, onClose, currentUserId, onChanged }: {
  project: ProjectPublic | undefined;
  onClose: () => void;
  currentUserId?: string;
  onChanged: () => void;
}) {
  if (!p) return null;
  const isMember = p.members.some((m) => m.userId === currentUserId);
  const isOwner = p.owner.id === currentUserId;

  async function handleJoin() {
    try {
      await api(`/api/projects/${p!.id}`, { method: 'PATCH', body: JSON.stringify({ action: 'join' }) });
      toast({ title: 'Вы присоединились' });
      onChanged();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handleComplete() {
    try {
      await api(`/api/projects/${p!.id}`, { method: 'PATCH', body: JSON.stringify({ action: 'complete' }) });
      toast({ title: 'Проект завершён' });
      onChanged();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  return (
    <Dialog open={!!p} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Cover */}
        <div className="h-3 lighthouse-gradient rounded-t-lg -mx-6 -mt-6 mb-4" />

        <DialogHeader>
          <div className="flex items-start justify-between gap-2">
            <DialogTitle className="text-2xl">{p.title}</DialogTitle>
            <Badge variant="outline" className={cn('text-xs', statusColor(p.status))}>{statusLabel(p.status)}</Badge>
          </div>
        </DialogHeader>

        {/* Article body — Project Room с табами (Wave 4, S-091) */}
        <ProjectRoomTabs project={{ ...p, clientVerified: p.clientVerified }} />

        {/* Owner CTA */}
        <div className="flex gap-2 pt-2 border-t">
          {!isMember && p.status === 'recruiting' && (
            <Button onClick={handleJoin}><Users className="w-4 h-4 mr-1" /> Участвовать</Button>
          )}
          {isOwner && p.status !== 'completed' && (
            <Button onClick={handleComplete}><Check className="w-4 h-4 mr-1" /> Завершить проект</Button>
          )}
        </div>

        {/* Truth badge */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t">
          <Award className="w-3.5 h-3.5 text-lighthouse" />
          <span>Каждый участник подтверждён через реальное участие. Накрутка невозможна.</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CreateProjectDialog({ onCreated }: { onCreated: () => void }) {
  const [open, setOpen] = React.useState(false);
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [tags, setTags] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  async function handleCreate() {
    if (!title.trim() || !description.trim()) return;
    setLoading(true);
    try {
      await api('/api/projects', {
        method: 'POST',
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          tags: tags.split(',').map((s) => s.trim()).filter(Boolean),
        }),
      });
      toast({ title: 'Проект создан' });
      setOpen(false);
      setTitle(''); setDescription(''); setTags('');
      onCreated();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm"><Plus className="w-4 h-4 mr-1" /> Создать</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Новый проект</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="pr-title">Название</Label>
            <Input id="pr-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="AI-платформа для..." />
          </div>
          <div className="space-y-1">
            <Label htmlFor="pr-desc">Описание (как статья)</Label>
            <Textarea id="pr-desc" rows={4} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Подробно опишите проект: что делали, какую проблему решали, какой результат..." />
          </div>
          <div className="space-y-1">
            <Label htmlFor="pr-tags">Теги (через запятую)</Label>
            <Input id="pr-tags" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="Python, ML, Data" />
          </div>
          <Button onClick={handleCreate} disabled={loading || !title.trim() || !description.trim()} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Создать'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function statusLabel(s: string) {
  return { recruiting: 'Набор', active: 'Активен', completed: 'Завершён', cancelled: 'Отменён' }[s] ?? s;
}
function statusColor(s: string) {
  return {
    recruiting: 'border-lighthouse/40 text-lighthouse',
    active: 'border-primary/40 text-primary',
    completed: 'border-success/40 text-success',
    cancelled: 'border-destructive/40 text-destructive',
  }[s] ?? '';
}
function roleLabel(r: string) {
  return { owner: 'владелец', lead: 'лид', member: 'участник' }[r] ?? r;
}
