// BizON — Project Room (Wave 4, S-091…S-094, План-v2 §9 ТЗ 4.9).
//
// Табы: Overview / Team / Roles / Proof / Milestones / Discussion / Results
// + LOT-биржа (витрина лота = 9 блоков: обзор, условия, навыки, сроки,
// бюджет, отклики, заказчик, статус, действия).
//
// Правила UI:
//   • §3.3 — никаких чисел доверия/рейтинга; публичные факты и verified-метки;
//   • каждая интеракция ведёт к реальному API (без заглушек «скоро»);
//   • максимальная ширина и мобильная адаптивность через Tailwind.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { UserAvatar } from '@/components/common/user-avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
  Users, ShieldCheck, Calendar, ListChecks, MessageSquare, Award, Briefcase,
  Plus, Check, X, Loader2, Send, Star, Clock,
} from 'lucide-react';

// ---------- типы ----------

interface MemberProof {
  userId: string; name: string; avatarUrl: string | null;
  participantRole: string | null; responsibility: string | null;
  contribution: string | null; memberResult: string | null; exitState: string;
}
interface EvidenceOverview {
  clientStatus: string;
  confirmerCompany: { id: string; name: string } | null;
  fields: Array<{ field: string; value: unknown; state: 'UNVERIFIED' | 'VERIFIED' }>;
  memberProofs: MemberProof[];
}
interface MilestoneDto {
  id: string; title: string; description: string | null; status: string;
  dueAt: string | null; completedAt: string | null;
  comments: Array<{ id: string; text: string; createdAt: string; user: { id: string; name: string; avatarUrl: string | null } }>;
}
interface ReviewDto {
  id: string; author: { id: string; name: string; avatarUrl: string | null };
  subject: { id: string; name: string; avatarUrl: string | null };
  text: string; wouldWorkAgain: boolean; verifiedOnly: boolean; createdAt: string;
}
interface LotResponseDto {
  id: string; userId: string; message: string; proposedLumens: number | null;
  status: string; createdAt: string; user?: { id: string; name: string; avatarUrl: string | null };
}
interface LotDto {
  id: string; title: string; description: string; skills: string[];
  budgetLumens: number | null; durationDays: number | null; acceptUntil: string;
  status: string; ownerId: string; projectId: string; assignedToId: string | null;
  responsesCount?: number; pendingCount?: number; responses?: LotResponseDto[];
}
interface ApplicationDto {
  id: string; user: { id: string; name: string; title: string | null; avatarUrl: string | null };
  message: string; skills: string[]; status: string; createdAt: string;
}
export interface ProjectRoomProject {
  id: string; title: string; description: string; status: string;
  tags: string[]; startedAt: string; completedAt: string | null;
  clientVerified?: boolean;
  owner: { id: string; name: string; avatarUrl: string | null; title: string | null };
  members: Array<{ userId: string; role: string; user: { id: string; name: string; avatarUrl: string | null; title: string | null } }>;
}

// ---------- утилиты ----------

const EVIDENCE_LABELS: Record<string, string> = {
  problem: 'Проблема', context: 'Контекст', solution: 'Решение',
  result: 'Результат', outcome: 'Итог',
};
const MILESTONE_LABELS: Record<string, string> = {
  planned: 'Запланирован', in_progress: 'В работе', done: 'Готов', missed: 'Просрочен',
};
const LOT_STATUS_LABELS: Record<string, string> = {
  open: 'Открыт', accepted: 'Исполнитель выбран', completed: 'Завершён',
  closed: 'Срок истёк', cancelled: 'Отменён',
};

// ---------- основной компонент ----------

export function ProjectRoomTabs({ project }: { project: ProjectRoomProject }) {
  const { user } = useAppStore();
  const isOwner = user?.id === project.owner.id;
  const isMember = !!user && project.members.some((m) => m.userId === user.id);
  const projectId = project.id;

  const [evidence, setEvidence] = React.useState<EvidenceOverview | null>(null);
  const [milestones, setMilestones] = React.useState<MilestoneDto[]>([]);
  const [reviews, setReviews] = React.useState<ReviewDto[]>([]);
  const [lots, setLots] = React.useState<LotDto[]>([]);
  const [applications, setApplications] = React.useState<ApplicationDto[]>([]);
  const [loading, setLoading] = React.useState(true);

  const reload = React.useCallback(async () => {
    const jobs: Array<Promise<void>> = [];
    jobs.push(api<EvidenceOverview>(`/api/projects/${projectId}/evidence/overview`)
      .then((d) => setEvidence(d)).catch(() => undefined));
    jobs.push(api<{ milestones: MilestoneDto[] }>(`/api/projects/${projectId}/milestones`)
      .then((d) => setMilestones(d.milestones)).catch(() => undefined));
    jobs.push(api<{ reviews: ReviewDto[] }>(`/api/projects/${projectId}/reviews`)
      .then((d) => setReviews(d.reviews)).catch(() => undefined));
    jobs.push(api<{ lots: LotDto[] }>(`/api/lots?projectId=${projectId}`)
      .then((d) => setLots(d.lots)).catch(() => undefined));
    if (isOwner) {
      jobs.push(api<{ applications: ApplicationDto[] }>(`/api/projects/${projectId}/applications`)
        .then((d) => setApplications(d.applications)).catch(() => undefined));
    }
    await Promise.all(jobs);
    setLoading(false);
  }, [projectId, isOwner]);

  React.useEffect(() => { setLoading(true); reload(); }, [reload]);

  if (loading) {
    return (
      <div className="space-y-3 py-2">
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  return (
    <Tabs defaultValue="overview" className="w-full">
      <TabsList className="flex w-full flex-wrap items-stretch h-auto gap-1 bg-muted/60">
        <TabsTrigger value="overview" className="h-auto flex-none px-2.5 py-1">Обзор</TabsTrigger>
        <TabsTrigger value="team" className="h-auto flex-none px-2.5 py-1">Команда</TabsTrigger>
        <TabsTrigger value="roles" className="h-auto flex-none px-2.5 py-1">Роли</TabsTrigger>
        <TabsTrigger value="proof" className="h-auto flex-none px-2.5 py-1">Доказательства</TabsTrigger>
        <TabsTrigger value="milestones" className="h-auto flex-none px-2.5 py-1">Этапы</TabsTrigger>
        <TabsTrigger value="discussion" className="h-auto flex-none px-2.5 py-1">Обсуждение</TabsTrigger>
        <TabsTrigger value="results" className="h-auto flex-none px-2.5 py-1">Результаты</TabsTrigger>
        <TabsTrigger value="lots" className="h-auto flex-none px-2.5 py-1"><Briefcase className="w-3.5 h-3.5 mr-1 inline" />LOT</TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="mt-4 space-y-4">
        <p className="text-sm leading-relaxed whitespace-pre-wrap">{project.description}</p>
        {project.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {project.tags.map((t) => <Badge key={t} variant="secondary">#{t}</Badge>)}
          </div>
        )}
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> Старт: {new Date(project.startedAt).toLocaleDateString('ru-RU')}</span>
          {project.completedAt && <span>Завершён: {new Date(project.completedAt).toLocaleDateString('ru-RU')}</span>}
        </div>
        {project.clientVerified && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-lighthouse-gradient-soft">
            <ShieldCheck className="w-5 h-5 text-lighthouse" />
            <span className="text-xs text-muted-foreground">Проект подтверждён заказчиком (verified evidence)</span>
          </div>
        )}
        <LotBoard lots={lots} project={project} isOwner={isOwner} isMember={isMember} onChanged={reload} />
      </TabsContent>

      <TabsContent value="team" className="mt-4 space-y-4">
        <TeamTab project={project} isOwner={isOwner} isMember={isMember} applications={applications} onChanged={reload} />
      </TabsContent>

      <TabsContent value="roles" className="mt-4 space-y-3">
        <RolesTab evidence={evidence} project={project} onChanged={reload} />
      </TabsContent>

      <TabsContent value="proof" className="mt-4 space-y-3">
        <ProofTab evidence={evidence} />
      </TabsContent>

      <TabsContent value="milestones" className="mt-4 space-y-3">
        <MilestonesTab projectId={projectId} milestones={milestones} isMember={isMember} onChanged={reload} />
      </TabsContent>

      <TabsContent value="discussion" className="mt-4 space-y-3">
        <DiscussionTab projectId={projectId} milestones={milestones} isMember={isMember} onChanged={reload} />
      </TabsContent>

      <TabsContent value="results" className="mt-4 space-y-3">
        <ResultsTab project={project} reviews={reviews} isMember={isMember} onChanged={reload} />
      </TabsContent>

      <TabsContent value="lots" className="mt-4 space-y-3">
        <LotBoard lots={lots} project={project} isOwner={isOwner} isMember={isMember} onChanged={reload} expanded />
      </TabsContent>
    </Tabs>
  );
}

// ---------- Team ----------

function TeamTab({ project, isOwner, isMember, applications, onChanged }: {
  project: ProjectRoomProject; isOwner: boolean; isMember: boolean;
  applications: ApplicationDto[]; onChanged: () => void;
}) {
  const { setProfileUserId } = useAppStore();
  const [applyOpen, setApplyOpen] = React.useState(false);
  const pending = applications.filter((a) => a.status === 'pending');

  async function decide(applicationId: string, decision: 'accept' | 'decline') {
    try {
      await api(`/api/projects/${project.id}/applications`, { method: 'PATCH', body: JSON.stringify({ applicationId, decision }) });
      toast({ title: decision === 'accept' ? 'Кандидат принят в команду' : 'Заявка отклонена' });
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось обработать заявку', variant: 'destructive' });
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1">
          <Users className="w-3 h-3" /> Команда ({project.members.length})
        </div>
        <div className="space-y-1.5">
          {project.members.map((m) => (
            <button key={m.userId} onClick={() => setProfileUserId(m.userId)}
              className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-accent text-left transition">
              <UserAvatar name={m.user.name} avatarUrl={m.user.avatarUrl} size="sm" />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{m.user.name}</div>
                <div className="text-xs text-muted-foreground truncate">{m.user.title ?? '—'}</div>
              </div>
              <Badge variant="outline" className="text-xs">{m.role === 'owner' ? 'Владелец' : m.role === 'lead' ? 'Лид' : 'Участник'}</Badge>
            </button>
          ))}
        </div>
      </div>

      {isOwner && (
        <div>
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Заявки ({pending.length})</div>
          {pending.length === 0 ? (
            <p className="text-xs text-muted-foreground">Новых заявок нет.</p>
          ) : (
            <div className="space-y-2">
              {pending.map((a) => (
                <div key={a.id} className="p-3 rounded-lg border space-y-2">
                  <div className="flex items-center gap-2">
                    <UserAvatar name={a.user.name} avatarUrl={a.user.avatarUrl} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{a.user.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{a.user.title ?? '—'}</div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => decide(a.id, 'accept')}><Check className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant="outline" onClick={() => decide(a.id, 'decline')}><X className="w-3.5 h-3.5" /></Button>
                  </div>
                  <p className="text-xs text-muted-foreground">{a.message}</p>
                  {a.skills.length > 0 && (
                    <div className="flex flex-wrap gap-1">{a.skills.map((s) => <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>)}</div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {!isMember && project.status === 'recruiting' && (
        <Button onClick={() => setApplyOpen(true)}><Send className="w-4 h-4 mr-1" /> Подать заявку на участие</Button>
      )}
      <ApplyDialog open={applyOpen} onClose={() => setApplyOpen(false)} projectId={project.id} onDone={() => { setApplyOpen(false); onChanged(); }} />
    </div>
  );
}

function ApplyDialog({ open, onClose, projectId, onDone }: { open: boolean; onClose: () => void; projectId: string; onDone: () => void }) {
  const [message, setMessage] = React.useState('');
  const [skills, setSkills] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  async function submit() {
    setLoading(true);
    try {
      await api(`/api/projects/${projectId}/applications`, {
        method: 'POST',
        body: JSON.stringify({ message, skills: skills.split(',').map((s) => s.trim()).filter(Boolean) }),
      });
      toast({ title: 'Заявка отправлена владельцу проекта' });
      onDone();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось отправить заявку', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Заявка на участие</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Textarea placeholder="Почему вы подходите проекту (10–2000 символов)" value={message} onChange={(e) => setMessage(e.target.value)} rows={4} />
          <Input placeholder="Навыки через запятую" value={skills} onChange={(e) => setSkills(e.target.value)} />
          <Button onClick={submit} disabled={loading || message.trim().length < 10} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 mr-1" />} Отправить
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Roles (Proof Granularity: Role → Responsibility) ----------

function RolesTab({ evidence, project, onChanged }: { evidence: EvidenceOverview | null; project: ProjectRoomProject; onChanged: () => void }) {
  const { user } = useAppStore();
  const myProof = evidence?.memberProofs.find((m) => m.userId === user?.id);
  return (
    <div className="space-y-2">
      {evidence?.memberProofs.length === 0 && <p className="text-sm text-muted-foreground">Пока нет участников.</p>}
      {evidence?.memberProofs.map((m) => (
        <div key={m.userId} className="p-3 rounded-lg border space-y-1">
          <div className="flex items-center gap-2">
            <UserAvatar name={m.name} avatarUrl={m.avatarUrl} size="sm" />
            <span className="text-sm font-medium">{m.name}</span>
            {m.participantRole && <Badge variant="outline" className="text-xs">{m.participantRole}</Badge>}
          </div>
          {m.responsibility && <p className="text-xs text-muted-foreground"><span className="font-medium">Ответственность:</span> {m.responsibility}</p>}
          {m.contribution && <p className="text-xs text-muted-foreground"><span className="font-medium">Вклад:</span> {m.contribution}</p>}
          {m.memberResult && <p className="text-xs"><span className="font-medium">Результат:</span> {m.memberResult}</p>}
        </div>
      ))}
      {user && myProof === undefined && project.members.some((m) => m.userId === user.id) && (
        <RoleEditForm projectId={project.id} onChanged={onChanged} />
      )}
      {user && myProof && (
        <RoleEditForm projectId={project.id} onChanged={onChanged} initial={myProof} />
      )}
    </div>
  );
}

function RoleEditForm({ projectId, onChanged, initial }: {
  projectId: string; onChanged: () => void; initial?: MemberProof;
}) {
  const [participantRole, setParticipantRole] = React.useState(initial?.participantRole ?? '');
  const [responsibility, setResponsibility] = React.useState(initial?.responsibility ?? '');
  const [contribution, setContribution] = React.useState(initial?.contribution ?? '');
  const [memberResult, setMemberResult] = React.useState(initial?.memberResult ?? '');
  const [loading, setLoading] = React.useState(false);
  async function save() {
    setLoading(true);
    try {
      await api(`/api/projects/${projectId}`, {
        method: 'PATCH',
        body: JSON.stringify({ action: 'update-role', participantRole, responsibility, contribution, memberResult }),
      });
      toast({ title: 'Ваша роль сохранена' });
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось сохранить', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }
  return (
    <div className="p-3 rounded-lg border bg-muted/40 space-y-2">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Моя роль (Role → Responsibility → Action → Result)</div>
      <Input placeholder="Проф. роль (например, Backend-разработчик)" value={participantRole} onChange={(e) => setParticipantRole(e.target.value)} />
      <Input placeholder="Зона ответственности" value={responsibility} onChange={(e) => setResponsibility(e.target.value)} />
      <Input placeholder="Конкретный вклад" value={contribution} onChange={(e) => setContribution(e.target.value)} />
      <Input placeholder="Измеримый результат" value={memberResult} onChange={(e) => setMemberResult(e.target.value)} />
      <Button size="sm" onClick={save} disabled={loading}>{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4 mr-1" />} Сохранить</Button>
    </div>
  );
}

// ---------- Proof (UNVERIFIED/VERIFIED + confirmer) ----------

function ProofTab({ evidence }: { evidence: EvidenceOverview | null }) {
  if (!evidence) return <p className="text-sm text-muted-foreground">Доказательства недоступны.</p>;
  return (
    <div className="space-y-3">
      <div className="text-xs text-muted-foreground">
        Заказчик: {evidence.confirmerCompany
          ? <span className="font-medium text-foreground">{evidence.confirmerCompany.name}</span>
          : 'не указан — подтвердите проект, добавив компанию-заказчика'}
      </div>
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Структура доказательств</div>
      {evidence.fields.map((f) => (
        <div key={f.field} className="p-3 rounded-lg border space-y-1">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm font-medium">{EVIDENCE_LABELS[f.field] ?? f.field}</span>
            <Badge variant="outline" className={cn('text-xs', f.state === 'VERIFIED' ? 'border-green-600 text-green-700' : 'text-muted-foreground')}>
              {f.state === 'VERIFIED' ? <><ShieldCheck className="w-3 h-3 mr-1 inline" />VERIFIED</> : 'UNVERIFIED'}
            </Badge>
          </div>
          {typeof f.value === 'string' && f.value
            ? <p className="text-xs text-muted-foreground whitespace-pre-wrap">{f.value}</p>
            : <p className="text-xs text-muted-foreground italic">Не заполнено</p>}
        </div>
      ))}
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider pt-1">Результаты участников</div>
      {evidence.memberProofs.filter((m) => m.memberResult).map((m) => (
        <div key={m.userId} className="p-3 rounded-lg bg-lighthouse-gradient-soft">
          <div className="text-sm font-medium">{m.name}{m.participantRole ? ` · ${m.participantRole}` : ''}</div>
          <p className="text-xs text-muted-foreground">{m.memberResult}</p>
        </div>
      ))}
      {evidence.memberProofs.filter((m) => m.memberResult).length === 0 && (
        <p className="text-xs text-muted-foreground">Участники ещё не заполнили результаты.</p>
      )}
    </div>
  );
}

// ---------- Milestones ----------

function MilestonesTab({ projectId, milestones, isMember, onChanged }: {
  projectId: string; milestones: MilestoneDto[]; isMember: boolean; onChanged: () => void;
}) {
  const [open, setOpen] = React.useState(false);
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [dueAt, setDueAt] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  async function setStatus(milestoneId: string, status: string) {
    try {
      await api(`/api/projects/${projectId}/milestones`, { method: 'POST', body: JSON.stringify({ action: 'status', milestoneId, status }) });
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось сменить статус', variant: 'destructive' });
    }
  }

  async function create() {
    setLoading(true);
    try {
      await api(`/api/projects/${projectId}/milestones`, {
        method: 'POST',
        body: JSON.stringify({ title, description: description || undefined, dueAt: dueAt || undefined }),
      });
      toast({ title: 'Этап создан' });
      setTitle(''); setDescription(''); setDueAt(''); setOpen(false);
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось создать этап', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-2">
      {isMember && (
        <Button size="sm" variant="outline" onClick={() => setOpen(!open)}><Plus className="w-3.5 h-3.5 mr-1" /> Новый этап</Button>
      )}
      {open && (
        <div className="p-3 rounded-lg border space-y-2">
          <Input placeholder="Название этапа" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Input placeholder="Описание (необязательно)" value={description} onChange={(e) => setDescription(e.target.value)} />
          <Input type="date" value={dueAt} onChange={(e) => setDueAt(e.target.value)} />
          <Button size="sm" onClick={create} disabled={loading || title.trim().length < 3}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Создать'}
          </Button>
        </div>
      )}
      {milestones.length === 0 && <p className="text-sm text-muted-foreground">Этапы не заданы.</p>}
      {milestones.map((m) => (
        <div key={m.id} className="p-3 rounded-lg border space-y-1">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <ListChecks className="w-4 h-4 text-muted-foreground shrink-0" />
              <span className="text-sm font-medium truncate">{m.title}</span>
            </div>
            <Badge variant="outline" className={cn('text-xs shrink-0',
              m.status === 'done' && 'border-green-600 text-green-700',
              m.status === 'missed' && 'border-destructive text-destructive')}>
              {MILESTONE_LABELS[m.status] ?? m.status}
            </Badge>
          </div>
          {m.description && <p className="text-xs text-muted-foreground">{m.description}</p>}
          {m.dueAt && <p className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" /> Срок: {new Date(m.dueAt).toLocaleDateString('ru-RU')}</p>}
          {isMember && m.status !== 'done' && (
            <div className="flex gap-1 pt-1">
              {m.status === 'planned' && <Button size="sm" variant="outline" onClick={() => setStatus(m.id, 'in_progress')}>В работу</Button>}
              {m.status === 'in_progress' && <Button size="sm" variant="outline" onClick={() => setStatus(m.id, 'done')}><Check className="w-3.5 h-3.5 mr-1" />Готово</Button>}
              {m.status === 'missed' && <Button size="sm" variant="outline" onClick={() => setStatus(m.id, 'planned')}>Вернуть в план</Button>}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ---------- Discussion (комментарии по milestones) ----------

function DiscussionTab({ projectId, milestones, isMember, onChanged }: {
  projectId: string; milestones: MilestoneDto[]; isMember: boolean; onChanged: () => void;
}) {
  const [selected, setSelected] = React.useState<string | null>(null);
  const [text, setText] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const active = milestones.find((m) => m.id === selected) ?? milestones[0];

  React.useEffect(() => { if (!selected && milestones.length > 0) setSelected(milestones[0].id); }, [milestones, selected]);

  async function send() {
    if (!active) return;
    setLoading(true);
    try {
      await api(`/api/projects/${projectId}/milestones`, { method: 'POST', body: JSON.stringify({ action: 'comment', milestoneId: active.id, text }) });
      setText('');
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось отправить', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  if (milestones.length === 0) return <p className="text-sm text-muted-foreground">Обсуждение появится после создания этапов.</p>;

  return (
    <div className="space-y-3">
      <div className="flex gap-1 flex-wrap">
        {milestones.map((m) => (
          <button key={m.id} onClick={() => setSelected(m.id)}
            className={cn('px-2.5 py-1 rounded-full text-xs border transition',
              active?.id === m.id ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-accent')}>
            {m.title}
          </button>
        ))}
      </div>
      {active && (
        <>
          <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
            {active.comments.length === 0 && <p className="text-xs text-muted-foreground">Комментариев пока нет — обсудите этап.</p>}
            {active.comments.map((c) => (
              <div key={c.id} className="flex gap-2">
                <UserAvatar name={c.user.name} avatarUrl={c.user.avatarUrl} size="sm" />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium">{c.user.name} <span className="text-muted-foreground font-normal">· {new Date(c.createdAt).toLocaleString('ru-RU')}</span></div>
                  <p className="text-sm whitespace-pre-wrap break-words">{c.text}</p>
                </div>
              </div>
            ))}
          </div>
          {isMember && (
            <div className="flex gap-2">
              <Input placeholder="Сообщение к этапу…" value={text} onChange={(e) => setText(e.target.value)} />
              <Button size="sm" onClick={send} disabled={loading || text.trim().length === 0}>
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <MessageSquare className="w-4 h-4" />}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ---------- Results (outcome + verified-отзывы) ----------

function ResultsTab({ project, reviews, isMember, onChanged }: {
  project: ProjectRoomProject; reviews: ReviewDto[]; isMember: boolean; onChanged: () => void;
}) {
  const [reviewOpen, setReviewOpen] = React.useState(false);
  const others = project.members.filter((m) => m.userId !== undefined && m.userId);
  return (
    <div className="space-y-3">
      {reviews.length === 0 && <p className="text-sm text-muted-foreground">Отзывов пока нет.</p>}
      {reviews.map((r) => (
        <div key={r.id} className="p-3 rounded-lg border space-y-1">
          <div className="flex items-center gap-2">
            <UserAvatar name={r.author.name} avatarUrl={r.author.avatarUrl} size="sm" />
            <span className="text-sm font-medium">{r.author.name}</span>
            <span className="text-xs text-muted-foreground">о</span>
            <span className="text-sm font-medium">{r.subject.name}</span>
            {r.verifiedOnly && <Badge variant="outline" className="text-xs"><ShieldCheck className="w-3 h-3 mr-1 inline" />проверенный участник</Badge>}
          </div>
          <p className="text-sm">{r.text}</p>
          {r.wouldWorkAgain && <Badge variant="secondary" className="text-xs"><Award className="w-3 h-3 mr-1 inline" />готов(а) работать снова</Badge>}
        </div>
      ))}
      {isMember && <Button size="sm" variant="outline" onClick={() => setReviewOpen(true)}><Plus className="w-3.5 h-3.5 mr-1" /> Оставить отзыв</Button>}
      <ReviewDialog open={reviewOpen} onClose={() => setReviewOpen(false)} projectId={project.id} members={others.filter((m) => m.userId)} onDone={() => { setReviewOpen(false); onChanged(); }} />
    </div>
  );
}

function ReviewDialog({ open, onClose, projectId, members, onDone }: {
  open: boolean; onClose: () => void; projectId: string;
  members: Array<{ userId: string; user: { name: string } }>; onDone: () => void;
}) {
  const { user } = useAppStore();
  const candidates = members.filter((m) => m.userId !== user?.id);
  const [subjectId, setSubjectId] = React.useState('');
  const [text, setText] = React.useState('');
  const [wouldWorkAgain, setWouldWorkAgain] = React.useState(true);
  const [scoreInternal, setScoreInternal] = React.useState('5');
  const [loading, setLoading] = React.useState(false);

  async function submit() {
    setLoading(true);
    try {
      await api(`/api/projects/${projectId}/reviews`, {
        method: 'POST',
        body: JSON.stringify({
          subjectId, text, wouldWorkAgain,
          scoreInternal: Number(scoreInternal) || undefined,
        }),
      });
      toast({ title: 'Отзыв сохранён' });
      onDone();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось сохранить отзыв', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Отзыв о работе в проекте</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <select value={subjectId} onChange={(e) => setSubjectId(e.target.value)}
            className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm">
            <option value="">Выберите участника…</option>
            {candidates.map((m) => <option key={m.userId} value={m.userId}>{m.user.name}</option>)}
          </select>
          <Textarea placeholder="Что конкретно получилось хорошо (10–2000 символов)" value={text} onChange={(e) => setText(e.target.value)} rows={4} />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={wouldWorkAgain} onChange={(e) => setWouldWorkAgain(e.target.checked)} />
            Готов(а) работать снова
          </label>
          <label className="flex items-center gap-2 text-sm">
            <Star className="w-4 h-4 text-muted-foreground" />
            Внутренняя оценка (1–5, видит только алгоритм — не публикуется):
            <Input type="number" min={1} max={5} value={scoreInternal} onChange={(e) => setScoreInternal(e.target.value)} className="w-20" />
          </label>
          <Button onClick={submit} disabled={loading || !subjectId || text.trim().length < 10} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Сохранить отзыв'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ---------- LOT-биржа (9 блоков витрины) ----------

export function LotBoard({ lots, project, isOwner, isMember, onChanged, expanded }: {
  lots: LotDto[]; project: ProjectRoomProject; isOwner: boolean; isMember: boolean;
  onChanged: () => void; expanded?: boolean;
}) {
  const [createOpen, setCreateOpen] = React.useState(false);
  const shown = expanded ? lots : lots.slice(0, 3);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
          <Briefcase className="w-3 h-3" /> LOT-биржа проекта
        </div>
        {isOwner && <Button size="sm" variant="outline" onClick={() => setCreateOpen(true)}><Plus className="w-3.5 h-3.5 mr-1" /> Разместить LOT</Button>}
      </div>
      {shown.length === 0 && <p className="text-xs text-muted-foreground">Лотов нет. Владелец может разместить задачу с бюджетом.</p>}
      {shown.map((lot) => <LotCard key={lot.id} lot={lot} project={project} isProjectOwner={isOwner} onChanged={onChanged} />)}
      {!expanded && lots.length > 3 && (
        <p className="text-xs text-muted-foreground">…ещё {lots.length - 3} — во вкладке LOT.</p>
      )}
      <CreateLotDialog open={createOpen} onClose={() => setCreateOpen(false)} projectId={project.id} onDone={() => { setCreateOpen(false); onChanged(); }} />
    </div>
  );
}

function LotCard({ lot, project, isProjectOwner, onChanged }: {
  lot: LotDto; project: ProjectRoomProject; isProjectOwner: boolean; onChanged: () => void;
}) {
  const { user } = useAppStore();
  const [respondOpen, setRespondOpen] = React.useState(false);
  const isLotOwner = user?.id === lot.ownerId;
  const deadlinePassed = new Date(lot.acceptUntil).getTime() < Date.now();
  const myResponse = lot.responses?.find((r) => r.userId === user?.id);

  async function act(path: string, body?: Record<string, unknown>) {
    try {
      await api(`/api/lots/${lot.id}/${path}`, { method: 'POST', body: body ? JSON.stringify(body) : undefined });
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Действие не выполнено', variant: 'destructive' });
    }
  }

  // 9 блоков витрины: обзор | условия | навыки | сроки | бюджет | отклики | заказчик | статус | действия
  return (
    <div className="p-3 rounded-lg border space-y-2">
      {/* 1 обзор */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="text-sm font-medium truncate">{lot.title}</div>
          <p className="text-xs text-muted-foreground line-clamp-2">{lot.description}</p>
        </div>
        {/* 8 статус */}
        <Badge variant="outline" className="text-xs shrink-0">{LOT_STATUS_LABELS[lot.status] ?? lot.status}</Badge>
      </div>
      {/* 2 условия (срок работы) + 3 навыки */}
      <div className="flex flex-wrap gap-1 items-center text-xs text-muted-foreground">
        {lot.durationDays && <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {lot.durationDays} дн.</span>}
        {lot.skills.map((s) => <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>)}
      </div>
      {/* 4 сроки приёма + 5 бюджет */}
      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
        <span>Отклики до: {new Date(lot.acceptUntil).toLocaleString('ru-RU')}</span>
        <span className="font-medium text-foreground">{lot.budgetLumens ? `${lot.budgetLumens} люменов` : 'Бюджет не указан'}</span>
      </div>
      {/* 6 отклики */}
      <div className="text-xs text-muted-foreground">
        Откликов: {lot.responsesCount ?? lot.responses?.length ?? 0}{isProjectOwner && lot.pendingCount ? ` · новых: ${lot.pendingCount}` : ''}
      </div>
      {/* 7 заказчик */}
      <div className="text-xs text-muted-foreground">Заказчик: <span className="font-medium text-foreground">{project.owner.name}</span></div>
      {/* 9 действия */}
      <div className="flex flex-wrap gap-1 pt-1">
        {isProjectOwner && lot.status === 'open' && lot.responses && lot.responses.length > 0 && (
          lot.responses.map((r) => (
            <div key={r.id} className="flex items-center gap-1 w-full py-1 border-t first:border-t-0">
              <span className="text-xs truncate flex-1">{r.user?.name ?? 'Кандидат'}: {r.message.slice(0, 60)}</span>
              {r.status === 'pending' && (
                <>
                  <Button size="sm" variant="outline" onClick={() => act('accept', { responseId: r.id, action: 'accept' })}>Принять</Button>
                  <Button size="sm" variant="outline" onClick={() => act('accept', { responseId: r.id, action: 'decline' })}>Отклонить</Button>
                </>
              )}
            </div>
          ))
        )}
        {isLotOwner && lot.status === 'accepted' && (
          <Button size="sm" onClick={() => act('complete')}><Check className="w-3.5 h-3.5 mr-1" /> Завершить и оплатить</Button>
        )}
        {isLotOwner && (lot.status === 'open' || lot.status === 'accepted') && (
          <Button size="sm" variant="outline" onClick={() => act('cancel')}>Отменить LOT</Button>
        )}
        {!isLotOwner && !isProjectOwner && lot.status === 'open' && !deadlinePassed && !myResponse && (
          <Button size="sm" onClick={() => setRespondOpen(true)}><Send className="w-3.5 h-3.5 mr-1" /> Откликнуться</Button>
        )}
        {myResponse && <span className="text-xs text-muted-foreground">Ваш отклик: {myResponse.status === 'pending' ? 'на рассмотрении' : myResponse.status === 'accepted' ? 'принят' : 'отклонён'}</span>}
      </div>
      <RespondDialog open={respondOpen} onClose={() => setRespondOpen(false)} lotId={lot.id} lotTitle={lot.title} budget={lot.budgetLumens} onDone={() => { setRespondOpen(false); onChanged(); }} />
    </div>
  );
}

function CreateLotDialog({ open, onClose, projectId, onDone }: {
  open: boolean; onClose: () => void; projectId: string; onDone: () => void;
}) {
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [skills, setSkills] = React.useState('');
  const [budget, setBudget] = React.useState('');
  const [duration, setDuration] = React.useState('');
  const [acceptUntil, setAcceptUntil] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  async function submit() {
    setLoading(true);
    try {
      await api('/api/lots', {
        method: 'POST',
        body: JSON.stringify({
          projectId, title, description,
          skills: skills.split(',').map((s) => s.trim()).filter(Boolean),
          budgetLumens: budget ? Number(budget) : null,
          durationDays: duration ? Number(duration) : null,
          acceptUntil: acceptUntil ? new Date(acceptUntil).toISOString() : new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString(),
        }),
      });
      toast({ title: 'LOT опубликован' });
      onDone();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось создать LOT', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Новый LOT — задача с бюджетом</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Input placeholder="Название (3–120)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <Textarea placeholder="Описание задачи (10–4000)" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} />
          <Input placeholder="Навыки через запятую" value={skills} onChange={(e) => setSkills(e.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <Input type="number" placeholder="Бюджет, люменов" value={budget} onChange={(e) => setBudget(e.target.value)} />
            <Input type="number" placeholder="Срок, дней" value={duration} onChange={(e) => setDuration(e.target.value)} />
          </div>
          <Input type="date" value={acceptUntil} onChange={(e) => setAcceptUntil(e.target.value)} />
          <Button onClick={submit} disabled={loading || title.trim().length < 3 || description.trim().length < 10} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Опубликовать LOT'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RespondDialog({ open, onClose, lotId, lotTitle, budget, onDone }: {
  open: boolean; onClose: () => void; lotId: string; lotTitle: string; budget: number | null; onDone: () => void;
}) {
  const [message, setMessage] = React.useState('');
  const [proposed, setProposed] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  async function submit() {
    setLoading(true);
    try {
      await api(`/api/lots/${lotId}/respond`, {
        method: 'POST',
        body: JSON.stringify({ message, proposedLumens: proposed ? Number(proposed) : null }),
      });
      toast({ title: 'Отклик отправлен' });
      onDone();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось отправить отклик', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader><DialogTitle>Отклик на «{lotTitle}»</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Textarea placeholder="Почему вы подходите (10–2000)" value={message} onChange={(e) => setMessage(e.target.value)} rows={4} />
          {budget && <Input type="number" placeholder={`Встречное предложение (бюджет: ${budget})`} value={proposed} onChange={(e) => setProposed(e.target.value)} />}
          <Button onClick={submit} disabled={loading || message.trim().length < 10} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4 mr-1" />} Отправить отклик
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
