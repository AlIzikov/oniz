// BizON — SkillFuturesPanel (9-c, doc_a §37 Skill Futures UI)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 🧭 ВАШИ ТРАЕКТОРИИ                                     [⌄]   │
//   │ Skill Futures: что будет со спросом на ваши навыки           │
//   │                                                              │
//   │ Docker                     ▲ спрос растёт                    │
//   │  Сегодня: 4 вакансии · 12 мес: 25/100 · 3 года: 33/100       │
//   │   └ Почему: активные вакансии, рост-индекс…                  │
//   │ TypeScript                 → спрос стабильный                │
//   │ …                                                            │
//   │                                                              │
//   │ ⚠ Эвристическая модель v6.0 на данных платформы…             │
//   └──────────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/skill-futures →
//   { items: SkillForecast[], total, skipped, disclaimer }
//   (агрегат над существующим SkillFuturesService — GET /api/skills/[id]/forecast)
//
// Честность: показываем только данные API; если навыков нет — empty state,
// если модель не уверена — это видно по «уверенности», без выдумок.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Compass,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  MoveRight,
  Briefcase,
  CalendarClock,
  Gauge,
  Info,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы (зеркало SkillForecast из skill-futures-service.ts) ===
// ============================================================================

type ForecastTrend = 'rising' | 'stable' | 'declining';

interface SkillForecastDTO {
  skillId: string;
  skillName: string;
  currentDemand: number; // активных вакансий сейчас (шт.)
  demand12m: number; // индекс 0..100 через 12 месяцев
  demand36m: number; // индекс 0..100 через 36 месяцев
  trend: ForecastTrend;
  confidence: number; // 0..1
  factors: { name: string; impact: number; note: string }[];
  disclaimer: string;
}

interface SkillFuturesResponse {
  items: SkillForecastDTO[];
  total: number;
  skipped: number;
  disclaimer: string | null;
  generatedAt: string;
}

// ============================================================================
// === Мета тренда: иконка + подпись + цвет (teal/emerald — рост, amber — спад) ===
// ============================================================================

const TREND_META: Record<
  ForecastTrend,
  { icon: React.ReactNode; label: string; accent: string; bg: string }
> = {
  rising: {
    icon: <TrendingUp className="w-3.5 h-3.5" />,
    label: 'спрос растёт',
    accent: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  stable: {
    icon: <MoveRight className="w-3.5 h-3.5" />,
    label: 'спрос стабильный',
    accent: 'text-lighthouse',
    bg: 'bg-lighthouse/10',
  },
  declining: {
    icon: <TrendingDown className="w-3.5 h-3.5" />,
    label: 'спрос снижается',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
};

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function SkillFuturesPanel({ className }: { className?: string }) {
  const [data, setData] = React.useState<SkillFuturesResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(true);
  // Какие навыки раскрыты до факторов (множество skillId)
  const [expanded, setExpanded] = React.useState<Set<string>>(new Set());

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<SkillFuturesResponse>('/api/me/skill-futures')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e: unknown) => {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Не удалось загрузить прогноз');
          console.error('[SkillFuturesPanel] load error:', e);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const items = data?.items ?? [];
  const hasContent = items.length > 0 || Boolean(error);

  const toggleFactors = (skillId: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(skillId)) next.delete(skillId);
      else next.add(skillId);
      return next;
    });
  };

  return (
    <Card className={cn('overflow-hidden', className)}>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger
          className="w-full text-left"
          aria-label={
            open ? 'Свернуть панель «Ваши траектории»' : 'Развернуть панель «Ваши траектории»'
          }
        >
          <CardContent className="p-4 pb-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
                <Compass className="w-4 h-4 text-lighthouse" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold leading-tight">Ваши траектории</div>
                <div className="text-xs text-muted-foreground truncate">
                  Skill Futures: что будет со спросом на ваши навыки
                </div>
              </div>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground transition-transform flex-shrink-0',
                  open && 'rotate-180',
                )}
              />
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="p-4 pt-3">
            {/* Загрузка — скелетоны */}
            {loading && (
              <div className="space-y-3" aria-busy="true" aria-live="polite">
                {Array.from({ length: 2 }).map((_, i) => (
                  <div key={i} className="rounded-lg border border-border/60 p-3 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <Skeleton className="h-4 w-28" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-2/3" />
                  </div>
                ))}
              </div>
            )}

            {/* Ошибка — не крашим вкладку */}
            {!loading && error && items.length === 0 && (
              <div className="text-xs text-muted-foreground py-4 text-center" role="alert">
                Не удалось загрузить прогноз спроса. Попробуйте обновить страницу позже.
              </div>
            )}

            {/* Empty state — честный */}
            {!loading && !error && items.length === 0 && (
              <div className="text-xs text-muted-foreground py-4 text-center leading-relaxed">
                Пока нет данных — они появятся, когда вы добавите навыки в профиль.
                Прогноз спроса строится по активным вакансиям и подтверждениям навыка
                на платформе.
              </div>
            )}

            {/* Данные */}
            {!loading && items.length > 0 && (
              <ul className="space-y-2.5">
                {items.map((f) => {
                  const meta = TREND_META[f.trend];
                  const isOpen = expanded.has(f.skillId);
                  return (
                    <li
                      key={f.skillId}
                      className="rounded-lg border border-border/60 p-3 hover:border-lighthouse/30 transition"
                    >
                      {/* Строка навыка */}
                      <div className="flex items-center gap-2 flex-wrap min-w-0">
                        <span
                          className={cn(
                            'inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full flex-shrink-0',
                            meta.accent,
                            meta.bg,
                          )}
                        >
                          {meta.icon}
                          {meta.label}
                        </span>
                        <span className="text-sm font-semibold truncate min-w-0" title={f.skillName}>
                          {f.skillName}
                        </span>
                      </div>

                      {/* Траектория: сегодня / 12 мес / 3 года (doc_a §37) */}
                      <div className="grid grid-cols-3 gap-2 mt-2.5">
                        <TrajectoryCell
                          icon={<Briefcase className="w-3 h-3" />}
                          label="Сегодня"
                          value={String(f.currentDemand)}
                          hint={`${pluralize(f.currentDemand, 'активная вакансия', 'активные вакансии', 'активных вакансий')}`}
                        />
                        <TrajectoryCell
                          icon={<CalendarClock className="w-3 h-3" />}
                          label="Через 12 мес"
                          value={`${f.demand12m}`}
                          hint="индекс спроса из 100"
                        />
                        <TrajectoryCell
                          icon={<Gauge className="w-3 h-3" />}
                          label="Через 3 года"
                          value={`${f.demand36m}`}
                          hint="индекс спроса из 100"
                        />
                      </div>

                      {/* Уверенность модели */}
                      <div className="text-xs text-muted-foreground mt-2">
                        Уверенность модели: {Math.round(f.confidence * 100)}%
                      </div>

                      {/* Объяснение — факторы (expandable) */}
                      <button
                        type="button"
                        onClick={() => toggleFactors(f.skillId)}
                        aria-expanded={isOpen}
                        className="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-lighthouse hover:underline transition"
                      >
                        <Info className="w-3 h-3" />
                        {isOpen ? 'Скрыть объяснение' : 'Почему такой прогноз'}
                      </button>
                      {isOpen && (
                        <ul className="mt-1.5 space-y-1 border-l-2 border-lighthouse/20 pl-2.5">
                          {f.factors.map((factor, idx) => (
                            <li key={idx} className="text-xs text-muted-foreground leading-relaxed">
                              <span className="font-medium text-foreground/80">{factor.name}:</span>{' '}
                              {factor.note}
                            </li>
                          ))}
                        </ul>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}

            {/* Честная приписка о навыках вне лимита */}
            {!loading && data && data.skipped > 0 && (
              <div className="text-xs text-muted-foreground mt-2.5">
                …и ещё {data.skipped} {pluralize(data.skipped, 'навык', 'навыка', 'навыков')} —
                показаны самые сильные.
              </div>
            )}

            {/* Дисклеймер модели — из API, не выдумываем */}
            {!loading && data?.disclaimer && (
              <div className="flex items-start gap-1.5 mt-3 pt-3 border-t border-border/60">
                <Badge variant="outline" className="text-xs font-normal flex-shrink-0 mt-0.5">
                  прогноз
                </Badge>
                <p className="text-xs text-muted-foreground leading-relaxed">{data.disclaimer}</p>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

// ============================================================================
// === Ячейка траектории ===
// ============================================================================

function TrajectoryCell({
  icon,
  label,
  value,
  hint,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="rounded-md bg-muted/40 px-2 py-1.5 min-w-0" title={hint}>
      <div className="flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
        {icon}
        <span className="truncate">{label}</span>
      </div>
      <div className="text-sm font-bold tabular-nums leading-tight mt-0.5">{value}</div>
    </div>
  );
}
