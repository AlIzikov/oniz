// BizON — Cultural Signals shared components (Этап 4.3)
// - CulturalSignalsChip — компактный виджет ⭐ 4.7 (N) для JobCard
// - CulturalSignalsBlock — блок для CompanyView: средний рейтинг + распределение + список
// - CulturalSignalsDialog — модалка со списком отзывов (для JobCard)
// - CulturalSignalForm — форма оставления отзыва
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Star, CheckCircle2, Loader2, Plus, MessageSquare, Info,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export interface CulturalSignalItem {
  id: string;
  rating: number;
  category: string;
  text: string;
  isAnonymous: boolean;
  isVerified: boolean;
  status: string;
  createdAt: string;
  author: {
    id: string;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  } | null;
}

export interface CulturalSignalsRating {
  avg: number;
  count: number;
  byCategory: Array<{ category: string; label: string; avg: number; count: number }>;
}

interface SignalsResponse {
  signals: CulturalSignalItem[];
  rating: CulturalSignalsRating;
  isVerifiedEmployee: boolean;
}

const CATEGORY_LABELS: Record<string, string> = {
  CULTURE: 'Корпоративная культура',
  SALARY: 'Зарплата',
  GROWTH: 'Возможности роста',
  MANAGEMENT: 'Управление',
  WORK_LIFE: 'Work-life balance',
};

// ============== Helper: загрузка сигналов ==============
async function fetchSignals(companyId: string): Promise<SignalsResponse> {
  return api<SignalsResponse>(`/api/companies/${companyId}/cultural-signals?limit=200`);
}

// ============== Helper: stars row ==============
function StarsRow({ value, size = 'sm' }: { value: number; size?: 'sm' | 'md' | 'lg' }) {
  const cls = size === 'lg' ? 'w-5 h-5' : size === 'md' ? 'w-4 h-4' : 'w-3 h-3';
  return (
    <div className="flex">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={cn(cls, s <= Math.round(value) ? 'fill-lighthouse text-lighthouse' : 'text-muted-foreground')}
        />
      ))}
    </div>
  );
}

// ============== Chip: компактный виджет ⭐ 4.7 (N) ==============
export function CulturalSignalsChip({ companyId, onClick }: {
  companyId: string;
  onClick?: () => void;
}) {
  const [rating, setRating] = React.useState<CulturalSignalsRating | null>(null);
  const [loaded, setLoaded] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    fetchSignals(companyId)
      .then((r) => {
        if (cancelled) return;
        setRating(r.rating);
      })
      .catch(() => {
        // Тихо игнорируем — чип просто не покажется
      })
      .finally(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => { cancelled = true; };
  }, [companyId]);

  // Скрываем чип если отзывов нет (чтобы не шуметь)
  if (!loaded) return null;
  if (!rating || rating.count === 0) return null;

  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-lighthouse/10 hover:bg-lighthouse/20 transition text-xs"
      title={`${rating.avg.toFixed(1)} из 5 на основе ${rating.count} отзывов сотрудников`}
    >
      <Star className="w-3.5 h-3.5 fill-lighthouse text-lighthouse" />
      <span className="font-semibold tabular-nums">{rating.avg.toFixed(1)}</span>
      <span className="text-muted-foreground">({rating.count})</span>
    </button>
  );
}

// ============== Dialog: список отзывов (для JobCard) ==============
export function CulturalSignalsDialog({ companyId, open, onClose }: {
  companyId: string;
  open: boolean;
  onClose: () => void;
}) {
  const setView = useAppStore((s) => s.setView);
  const setSelectedCompanyId = useAppStore((s) => s.setSelectedCompanyId);
  const [data, setData] = React.useState<SignalsResponse | null>(null);
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (!open || !companyId) return;
    setLoading(true);
    fetchSignals(companyId)
      .then(setData)
      .catch((e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, [open, companyId]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-lighthouse" /> Cultural Signals
            {data && data.rating.count > 0 && (
              <span className="text-base font-normal text-muted-foreground">
                · {data.rating.avg.toFixed(1)} ({data.rating.count} отзывов)
              </span>
            )}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
            </div>
          ) : !data || data.signals.length === 0 ? (
            <div className="text-center py-8 text-sm text-muted-foreground">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              Пока нет отзывов сотрудников о культуре этой компании
            </div>
          ) : (
            data.signals.map((s) => <SignalCard key={s.id} signal={s} />)
          )}
        </div>
        <div className="flex justify-between items-center pt-2 border-t">
          <Button variant="ghost" size="sm" onClick={() => {
            onClose();
            setSelectedCompanyId(companyId);
            setView('company');
          }}>
            Открыть страницу компании
          </Button>
          <Button variant="outline" size="sm" onClick={onClose}>Закрыть</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== Card: один отзыв ==============
function SignalCard({ signal: s }: { signal: CulturalSignalItem }) {
  return (
    <div className="p-3 rounded-lg border bg-muted/30">
      <div className="flex items-start gap-3">
        {s.author && !s.isAnonymous ? (
          <UserAvatar name={s.author.name} avatarUrl={s.author.avatarUrl} size="sm" />
        ) : (
          <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center">
            <Star className="w-4 h-4 text-muted-foreground" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            {s.author && !s.isAnonymous ? (
              <span className="text-sm font-medium">{s.author.name}</span>
            ) : (
              <span className="text-sm font-medium text-muted-foreground">Аноним</span>
            )}
            {s.isVerified && (
              <Badge variant="outline" className="text-xs gap-1 border-lighthouse/40 text-lighthouse">
                <CheckCircle2 className="w-3 h-3" /> Сотрудник
              </Badge>
            )}
            <StarsRow value={s.rating} />
            <Badge variant="secondary" className="text-xs">
              {CATEGORY_LABELS[s.category] ?? s.category}
            </Badge>
            <span className="text-xs text-muted-foreground ml-auto">{formatRelative(s.createdAt)}</span>
          </div>
          <p className="text-sm mt-1.5 leading-relaxed whitespace-pre-wrap">{s.text}</p>
        </div>
      </div>
    </div>
  );
}

// ============== Block: для страницы компании ==============
export function CulturalSignalsBlock({ companyId }: { companyId: string }) {
  const user = useAppStore((s) => s.user);
  const [data, setData] = React.useState<SignalsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [formOpen, setFormOpen] = React.useState(false);

  const reload = React.useCallback(() => {
    setLoading(true);
    fetchSignals(companyId)
      .then(setData)
      .catch((e) => toast({ title: 'Ошибка', description: e.message, variant: 'destructive' }))
      .finally(() => setLoading(false));
  }, [companyId]);

  React.useEffect(() => { reload(); }, [reload]);

  const isVerified = !!data?.isVerifiedEmployee;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Star className="w-4 h-4 text-lighthouse" /> Cultural Signals
            {data && data.rating.count > 0 && (
              <span className="text-sm font-normal text-muted-foreground">
                · {data.rating.count} {pluralReviews(data.rating.count)}
              </span>
            )}
          </CardTitle>
          {user && (
            isVerified ? (
              <Button size="sm" variant="outline" onClick={() => setFormOpen(true)}>
                <Plus className="w-4 h-4 mr-1" /> Оставить отзыв
              </Button>
            ) : (
              <Badge variant="outline" className="text-xs gap-1 border-amber-500/40 text-amber-700 dark:text-amber-400">
                <Info className="w-3 h-3" />
                Чтобы оставить отзыв, подтвердите работу в компании через проект
              </Badge>
            )
          )}
        </div>
        {data && data.rating.count > 0 && (
          <div className="flex items-center gap-3 mt-3">
            <div className="text-3xl font-bold tabular-nums">{data.rating.avg.toFixed(1)}</div>
            <StarsRow value={data.rating.avg} size="lg" />
            <span className="text-sm text-muted-foreground">
              из 5 · {data.rating.count} {pluralReviews(data.rating.count)}
            </span>
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : !data || data.rating.count === 0 ? (
          <div className="text-center py-6 text-sm text-muted-foreground">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
            Отзывов сотрудников пока нет.
            {user && !isVerified && (
              <div className="mt-2 text-xs">
                Подтвердите работу в компании через проект, чтобы оставить первый отзыв.
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Распределение по категориям */}
            <div className="space-y-1.5">
              {data.rating.byCategory
                .filter((c) => c.count > 0)
                .map((c) => (
                  <div key={c.category} className="flex items-center gap-2 text-xs">
                    <div className="w-36 text-muted-foreground truncate">
                      {CATEGORY_LABELS[c.category] ?? c.category}
                    </div>
                    <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-lighthouse"
                        style={{ width: `${(c.avg / 5) * 100}%` }}
                      />
                    </div>
                    <div className="w-12 text-right tabular-nums text-muted-foreground">
                      {c.avg.toFixed(1)}
                    </div>
                    <div className="w-8 text-right text-muted-foreground">({c.count})</div>
                  </div>
                ))}
            </div>

            {/* Список отзывов */}
            <div className="space-y-2 pt-2 border-t">
              {data.signals.map((s) => <SignalCard key={s.id} signal={s} />)}
            </div>
          </>
        )}
      </CardContent>

      {/* Форма оставления отзыва */}
      {formOpen && (
        <CulturalSignalForm
          companyId={companyId}
          onClose={() => setFormOpen(false)}
          onSubmitted={() => { setFormOpen(false); reload(); }}
        />
      )}
    </Card>
  );
}

// ============== Form: оставить отзыв ==============
function CulturalSignalForm({ companyId, onClose, onSubmitted }: {
  companyId: string;
  onClose: () => void;
  onSubmitted: () => void;
}) {
  const [rating, setRating] = React.useState(5);
  const [category, setCategory] = React.useState<string>('CULTURE');
  const [text, setText] = React.useState('');
  const [isAnonymous, setIsAnonymous] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  async function handleSubmit() {
    if (!text.trim()) return;
    setLoading(true);
    try {
      await api(`/api/companies/${companyId}/cultural-signals`, {
        method: 'POST',
        body: JSON.stringify({ rating, category, text, isAnonymous }),
      });
      toast({
        title: rating <= 2 ? 'Отзыв отправлен на модерацию' : 'Отзыв добавлен',
        description: rating <= 2
          ? 'Отзывы с низкой оценкой проходят премодерацию перед публикацией.'
          : undefined,
      });
      setText(''); setRating(5); setCategory('CULTURE'); setIsAnonymous(false);
      onSubmitted();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={true} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Отзыв о культуре компании</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Оценка</Label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <button key={s} onClick={() => setRating(s)} className="p-1" type="button">
                  <Star className={cn('w-6 h-6 transition', s <= rating ? 'fill-lighthouse text-lighthouse' : 'text-muted-foreground')} />
                </button>
              ))}
              {rating <= 2 && (
                <span className="ml-2 text-xs text-amber-700 dark:text-amber-400 self-center">
                  Будет отправлен на модерацию
                </span>
              )}
            </div>
          </div>
          <div className="space-y-1">
            <Label>Категория</Label>
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setCategory(key)}
                  className={cn(
                    'px-2.5 py-1 rounded-full text-xs border transition',
                    category === key
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'hover:border-primary'
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="cs-text">Текст отзыва</Label>
            <Textarea
              id="cs-text"
              rows={4}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Опишите ваш опыт работы в компании..."
              maxLength={5000}
            />
            <div className="text-xs text-muted-foreground text-right">{text.length}/5000</div>
          </div>
          <div className="flex items-center gap-2">
            <Switch checked={isAnonymous} onCheckedChange={setIsAnonymous} id="cs-anon" />
            <Label htmlFor="cs-anon" className="text-sm cursor-pointer">
              Опубликовать анонимно
            </Label>
          </div>
          <Button onClick={handleSubmit} disabled={loading || !text.trim()} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Опубликовать отзыв'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============== Helpers ==============
function pluralReviews(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'отзыв';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'отзыва';
  return 'отзывов';
}

function formatRelative(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  if (days < 7) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU');
}
