// BizON — BizonDiscover (Phase 5: BIZON DISCOVER + Opportunity Radar)
//
// Ежедневные 5 персональных находок от BizON — теперь на основе Opportunity Radar.
// Источник: GET /api/opportunities/radar (топ-5 за последние 24ч с explanation).
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 🔍 Сегодня BizON обнаружил для вас 5 возможностей            │
//   │                                                              │
//   │ 💼 Вакансия: Главный инженер — 94% match → [Открыть]         │
//   │ 🚀 Проект: AI-стартап в EdTech — 80% совпадение → [Открыть] │
//   │ 🧭 Ментор: Иван Петров — поможет с React → [Профиль]        │
//   │ 🎓 Курс: Архитектура систем — по слабому навыку → [Открыть] │
//   │ 📅 Событие: Backend Meetup — завтра → [Записаться]          │
//   └──────────────────────────────────────────────────────────────┘
//
// Каждая возможность с explanation: «Почему BizON показывает это».
// Если radar пустой — fallback на старый /api/me/discover (для обратной совместимости).
// Если оба пустые — блок не рендерится.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Sparkles,
  Briefcase,
  Rocket,
  Compass,
  GraduationCap,
  Users,
  Handshake,
  Search,
  Calendar,
  Building2,
  ChevronRight,
  Radar as RadarIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы данных ===
// ============================================================================

type OpportunityType =
  | 'job'
  | 'project'
  | 'mentor'
  | 'partnership'
  | 'expert'
  | 'education'
  | 'event'
  | 'business';

interface OpportunityDTO {
  id: string;
  type: OpportunityType;
  title: string;
  description: string | null;
  companyId: string | null;
  jobId: string | null;
  projectId: string | null;
  eventId: string | null;
  mentorId: string | null;
  skills: string[];
  location: string | null;
  compensation: string | null;
  trust: number;
  freshness: number;
  relevance: number;
  intentAlignment: number;
  explanation: string | null;
  createdAt: string;
  action: {
    label: string;
    view?: string;
    entityId?: string;
    externalUrl?: string;
  };
}

interface RadarResponse {
  items: OpportunityDTO[];
  total: number;
  type?: string;
  generatedAt: string;
  headline?: string;
}

// ============================================================================
// === Мета по типам возможностей: иконка + цвет + русская подпись ===
// ============================================================================

const TYPE_META: Record<
  OpportunityType,
  { icon: React.ReactNode; label: string; accent: string; bg: string }
> = {
  job: {
    icon: <Briefcase className="w-4 h-4" />,
    label: 'Вакансия',
    accent: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  project: {
    icon: <Rocket className="w-4 h-4" />,
    label: 'Проект',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
  mentor: {
    icon: <Compass className="w-4 h-4" />,
    label: 'Ментор',
    accent: 'text-violet-600 dark:text-violet-400',
    bg: 'bg-violet-500/10',
  },
  partnership: {
    icon: <Handshake className="w-4 h-4" />,
    label: 'Партнёр',
    accent: 'text-pink-600 dark:text-pink-400',
    bg: 'bg-pink-500/10',
  },
  expert: {
    icon: <Users className="w-4 h-4" />,
    label: 'Эксперт',
    accent: 'text-indigo-600 dark:text-indigo-400',
    bg: 'bg-indigo-500/10',
  },
  education: {
    icon: <GraduationCap className="w-4 h-4" />,
    label: 'Курс',
    accent: 'text-sky-600 dark:text-sky-400',
    bg: 'bg-sky-500/10',
  },
  event: {
    icon: <Calendar className="w-4 h-4" />,
    label: 'Событие',
    accent: 'text-teal-600 dark:text-teal-400',
    bg: 'bg-teal-500/10',
  },
  business: {
    icon: <Building2 className="w-4 h-4" />,
    label: 'Клиент',
    accent: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-500/10',
  },
};

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function BizonDiscover() {
  const { setView, setProfileUserId, setSelectedCompanyId } = useAppStore();
  const [data, setData] = React.useState<RadarResponse | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    // Фикс E2E (Wave 6): карточка читает /api/opportunities (12 типов) —
    // прежний вызов /radar возвращал {windows,...} без items → краш .length.
    api<RadarResponse>('/api/opportunities?limit=5')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e) => {
        console.error('[BizonDiscover] radar load error:', e);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Loading — compact skeleton
  if (loading) {
    return (
      <Card className="border-lighthouse/20">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <Skeleton className="w-7 h-7 rounded-lg" />
            <Skeleton className="h-4 w-48" />
          </div>
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-2.5">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-2/3" />
                  <Skeleton className="h-2.5 w-1/3" />
                </div>
                <Skeleton className="w-16 h-7 rounded-md" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Нет данных — блок не показывается (defensive: items может не прийти)
  if (!data || !data.items || data.items.length === 0) {
    return null;
  }

  const items = data.items;
  const totalLabel =
    items.length === 1
      ? '1 возможность'
      : `${items.length} ${pluralizeOpps(items.length)}`;

  // Хендлер клика по action
  function handleAction(item: OpportunityDTO) {
    const { action } = item;
    if (action.externalUrl) {
      window.open(action.externalUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    if (!action.view) return;

    switch (action.view) {
      case 'profile':
        if (action.entityId) setProfileUserId(action.entityId);
        break;
      case 'company':
        if (action.entityId) setSelectedCompanyId(action.entityId);
        break;
      case 'jobs':
        setView('jobs');
        break;
      case 'opportunities':
        setView('jobs');
        break;
      case 'events':
        setView('events');
        break;
      case 'edu':
        setView('me');
        break;
      case 'me':
        setView('me');
        break;
      default:
        setView(action.view as any);
    }
  }

  return (
    <Card className="border-lighthouse/20 bg-gradient-to-br from-lighthouse/5 via-transparent to-transparent">
      <CardContent className="p-5">
        {/* Заголовок — radar headline от BizON */}
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
            <RadarIcon className="w-4 h-4 text-lighthouse" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold leading-tight">
              {data.headline ?? 'Возможности для вас'}
            </div>
            <div className="text-xs text-muted-foreground">
              Opportunity Engine · актуальные возможности
            </div>
          </div>
        </div>

        {/* Список находок */}
        <ul className="space-y-1">
          {items.map((item, idx) => {
            const meta = TYPE_META[item.type];
            const matchPercent = item.relevance
              ? Math.round(item.relevance * 100)
              : null;
            return (
              <li
                key={`${item.type}-${idx}`}
                className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-accent/60 transition group"
              >
                {/* Иконка типа */}
                <span
                  className={cn(
                    'flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center',
                    meta.bg,
                    meta.accent,
                  )}
                >
                  {meta.icon}
                </span>

                {/* Контент */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={cn('text-xs uppercase tracking-wider font-semibold', meta.accent)}>
                      {meta.label}
                    </span>
                    {matchPercent != null && matchPercent > 0 && (
                      <span className="text-xs text-muted-foreground">
                        · {matchPercent}% match
                      </span>
                    )}
                    {item.compensation && (
                      <span className="text-xs text-muted-foreground truncate max-w-[120px]">
                        · {item.compensation}
                      </span>
                    )}
                  </div>
                  <div
                    className="text-sm truncate font-medium"
                    title={item.title}
                  >
                    {item.title}
                  </div>
                  <div className="text-xs text-muted-foreground truncate" title={item.explanation ?? ''}>
                    {item.explanation ?? '—'}
                  </div>
                </div>

                {/* CTA */}
                <button
                  type="button"
                  onClick={() => handleAction(item)}
                  className="inline-flex items-center gap-0.5 flex-shrink-0 text-xs font-medium px-2.5 py-1.5 rounded-md border border-lighthouse/30 bg-background/60 hover:bg-lighthouse/10 hover:border-lighthouse/50 transition"
                >
                  {item.action.label}
                  <ChevronRight className="w-3 h-3 opacity-60" />
                </button>
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}

function pluralizeOpps(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'возможность';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'возможности';
  return 'возможностей';
}
