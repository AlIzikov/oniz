// BizON — WhatsNewTab (P0-1: Professional Truth Dashboard — минимум)
// Первый экран при входе. 3 блока реальных данных, без заглушек:
//
//   ┌──────────────────────────────────────────────┐
//   │  TRUST HERO                                  │
//   │  IP-score (из user.ipScore) + delta + level  │
//   ├──────────────────────────────────────────────┤
//   │  ЧТО ИЗМЕНИЛОСЬ                              │
//   │  Последние 5 событий из /api/me/actions      │
//   ├──────────────────────────────────────────────┤
//   │  ВОЗМОЖНОСТИ                                 │
//   │  N вакансий   ·   M проектов                 │
//   └──────────────────────────────────────────────┘
//
// Источники:
//   • /api/me/whats-new      → trustScore, trustLevel, trustDelta30, opportunitiesCount
//   • /api/me/actions        → последние 5 событий (type, title, createdAt)
//
// Замечание: NewsCardPlaceholder и RecommendationSkeleton удалены —
// на первом экране больше нет «битых» заглушек (audit-agent-2-ux §1.1).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { TrustBadge } from '@/components/common/trust-badge';
import {
  Sparkles,
  ArrowUp,
  ArrowDown,
  TrendingUp,
  Briefcase,
  FolderKanban,
  Award,
  Star,
  ShieldCheck,
  Users,
  FileText,
  CheckCircle2,
  GraduationCap,
  Rocket,
  Eye,
  Mail,
  Lightbulb,
  ChevronRight,
  Activity,
  Package,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { TrustLevel } from '@/lib/types';
import { BizonMomentCard } from '@/components/truth/bizon-moment-card';
import { BizonDiscover } from '@/components/me/bizon-discover';
import { BlindSpotsCard } from '@/components/truth/blind-spots-card';
import { NextBestActionCard } from '@/components/truth/next-best-action-card';
import { BizonSignalCard } from '@/components/me/bizon-signal-card';
// 9-c (doc_a §14-15): прозрачность источников News Bridge — бейджи компаний
// у новостей + активные источники (read-only, без подписки/отписки)
import { NewsSourcesCard } from '@/components/news/news-sources-card';
// 10-a (doc_a §17): BIZON Market Intelligence — снапшот рынка (спрос/направления/найм)
import { MarketIntelligencePanel } from '@/components/intelligence/market-intelligence-panel';

// ====================================================================
// === Типы данных ===
// ====================================================================

interface WhatsNewResponse {
  // P0-1 (минимум): top-level shortcuts
  trustScore: number;
  trustLevel: TrustLevel;
  trustDelta30: number | null;
  opportunitiesCount: {
    jobs: number;
    projects: number;
  };
  // Обратная совместимость со старым TruthDashboardTab (не используется здесь,
  // но поле нужно для type-safety при работе с расширенным ответом).
  since?: string;
  lastVisitAt?: string | null;
  // === Phase 3: Professional Truth Dashboard (структурированный объект) ===
  trustHero?: {
    score: number;
    level: TrustLevel;
    delta30days: number | null;
    breakdown: Record<string, number>;
    evidenceCoverage: number | null;
  };
  // === Phase 3: WHILE YOU WERE AWAY ===
  // null если lastVisitAt < 1 дня назад (UI не показывает баннер).
  whileAway?: {
    daysAway: number;
    profileViews: number;
    companyJobsAdded: number;
    skillsConfirmed: number;
    newPeopleFromArea: number;
    aiRecommendation: number;
    since: string;
  } | null;
}

interface ActionItem {
  id: string;
  type: string;
  title: string;
  description: string | null;
  metadata: Record<string, unknown> | null;
  isPublic: boolean;
  createdAt: string;
}

interface ActionsResponse {
  items: ActionItem[];
  total: number;
  hasMore: boolean;
}

// ====================================================================
// === Маппинг типов событий → иконка + цвет (для блока «Что изменилось») ===
// ====================================================================

const ACTION_ICON: Record<
  string,
  { icon: React.ReactNode; color: string; fallbackLabel: string }
> = {
  nft_skill_received: {
    icon: <Award className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
    fallbackLabel: 'NFT-навык',
  },
  project_completed: {
    icon: <CheckCircle2 className="w-4 h-4" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
    fallbackLabel: 'Завершён проект',
  },
  project_started: {
    icon: <FolderKanban className="w-4 h-4" />,
    color: 'text-lighthouse bg-lighthouse/10',
    fallbackLabel: 'Старт проекта',
  },
  community_joined: {
    icon: <Users className="w-4 h-4" />,
    color: 'text-slate-600 dark:text-slate-300 bg-slate-500/10',
    fallbackLabel: 'Сообщество',
  },
  article_published: {
    icon: <FileText className="w-4 h-4" />,
    color: 'text-sky-600 dark:text-sky-400 bg-sky-500/10',
    fallbackLabel: 'Публикация',
  },
  claim_verified: {
    icon: <ShieldCheck className="w-4 h-4" />,
    color: 'text-lighthouse bg-lighthouse/10',
    fallbackLabel: 'Подтверждён claim',
  },
  // P0-5 — Professional Moments
  trust_up: {
    icon: <TrendingUp className="w-4 h-4" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
    fallbackLabel: 'Trust ↑',
  },
  evidence_added: {
    icon: <CheckCircle2 className="w-4 h-4" />,
    color: 'text-sky-600 dark:text-sky-400 bg-sky-500/10',
    fallbackLabel: 'Доказательство',
  },
  skill_verified: {
    icon: <GraduationCap className="w-4 h-4" />,
    color: 'text-lighthouse bg-lighthouse/10',
    fallbackLabel: 'Навык подтверждён',
  },
  recommendation_received: {
    icon: <Star className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
    fallbackLabel: 'Рекомендация',
  },
  project_verified: {
    icon: <Rocket className="w-4 h-4" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
    fallbackLabel: 'Проект верифицирован',
  },
  new_opportunity: {
    icon: <Briefcase className="w-4 h-4" />,
    color: 'text-lighthouse bg-lighthouse/10',
    fallbackLabel: 'Новая возможность',
  },
  company_viewed_profile: {
    icon: <Eye className="w-4 h-4" />,
    color: 'text-slate-600 dark:text-slate-300 bg-slate-500/10',
    fallbackLabel: 'Профиль просмотрен',
  },
  recruiter_invitation: {
    icon: <Mail className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
    fallbackLabel: 'Приглашение',
  },
  blind_spot_discovered: {
    icon: <Lightbulb className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
    fallbackLabel: 'Blind spot',
  },
};

// ====================================================================
// === Хелперы ===
// ====================================================================

function getGreeting(d: Date): string {
  const h = d.getHours();
  if (h < 5) return 'Доброй ночи';
  if (h < 12) return 'Доброе утро';
  if (h < 18) return 'Добрый день';
  return 'Добрый вечер';
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return 'только что';
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min} мин назад`;
  const hrs = Math.floor(min / 60);
  if (hrs < 24) return `${hrs} ч назад`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'вчера';
  if (days < 7) return `${days} дн назад`;
  return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

function getActionMeta(type: string) {
  return (
    ACTION_ICON[type] ?? {
      icon: <Activity className="w-4 h-4" />,
      color: 'text-muted-foreground bg-muted',
      fallbackLabel: type,
    }
  );
}

// ====================================================================
// === Главный компонент ===
// ====================================================================

export function WhatsNewTab() {
  const { user, setView } = useAppStore();
  const [whatsNew, setWhatsNew] = React.useState<WhatsNewResponse | null>(null);
  const [actions, setActions] = React.useState<ActionItem[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (!user) return;
    let cancelled = false;

    setLoading(true);
    Promise.all([
      api<WhatsNewResponse>('/api/me/whats-new'),
      api<ActionsResponse>('/api/me/actions?limit=5&offset=0'),
    ])
      .then(([w, a]) => {
        if (cancelled) return;
        setWhatsNew(w);
        setActions(a.items ?? []);
      })
      .catch((e) => {
        console.error('[whats-new] load error:', e);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [user]);

  if (!user) return null;

  const now = new Date();
  const greeting = getGreeting(now);
  const firstName = user.name.split(' ')[0] || user.name;

  // IP-score — напрямую из user (мгновенно из store, без ожидания API).
  // delta и opportunities — из /api/me/whats-new.
  const trustScore = user.ipScore;
  const trustLevel = user.level as TrustLevel;
  const delta30 = whatsNew?.trustDelta30 ?? null;
  const jobsCount = whatsNew?.opportunitiesCount?.jobs ?? 0;
  const projectsCount = whatsNew?.opportunitiesCount?.projects ?? 0;
  const evidenceCoverage = whatsNew?.trustHero?.evidenceCoverage ?? null;
  const skillsCount = user.stats?.skillsCount ?? 0;
  const userProjectsCount = user.stats?.projectsCount ?? 0;
  const whileAway = whatsNew?.whileAway ?? null;

  return (
    <div className="space-y-4">
      {/* ============================================================ */}
      {/* РОУ 0: ПОКА ВАС НЕ БЫЛО (Phase 3 — While You Were Away)       */}
      {/* Показывается только если lastVisitAt > 1 дня назад           */}
      {/* ============================================================ */}
      {whileAway && (
        <WhileAwayBanner data={whileAway} onSeeAll={() => setView('me')} />
      )}

      {/* ============================================================ */}
      {/* РОУ 0.5: BIZON DISCOVER (Phase 3)                             */}
      {/* 3-5 персональных находок каждый день                         */}
      {/* ============================================================ */}
      <BizonDiscover />

      {/* ============================================================ */}
      {/* РОУ 1: TRUST HERO (компактно — Phase 3)                       */}
      {/* Одна строка: Trust N ↑M | N навыков | N проектов | N% доказано */}
      {/* ============================================================ */}
      <TrustHeroCompact
        loading={loading}
        score={trustScore}
        level={trustLevel}
        delta30={delta30}
        skillsCount={skillsCount}
        projectsCount={userProjectsCount}
        evidenceCoverage={evidenceCoverage}
        greeting={greeting}
        firstName={firstName}
        onExplain={() => setView('truth')}
      />

      {/* ============================================================ */}
      {/* РОУ 1.5: BIZON MOMENT (Phase 2)                              */}
      {/* Еженедельный AI-инсайт «BizON заметил кое-что интересное»    */}
      {/* ============================================================ */}
      <BizonMomentCard />

      {/* ============================================================ */}
      {/* РОУ 1.55: BLIND SPOTS (P0)                                   */}
      {/* «BizON обнаружил ваши скрытые сильные стороны» — недооценённые*/}
      {/* навыки и несоответствие title фактическим ролям в проектах.   */}
      {/* Источник: GET /api/me/blind-spots                            */}
      {/* ============================================================ */}
      <BlindSpotsCard />

      {/* ============================================================ */}
      {/* РОУ 1.56: NEXT BEST ACTION (P0)                              */}
      {/* «Ваше следующее действие» — 1 конкретный шаг: подтвердить    */}
      {/* навык, подтвердить проект, восстановить decayed skill,        */}
      {/* откликнуться на вакансию (job_search intent), создать проект. */}
      {/* Источник: GET /api/me/next-best-action                       */}
      {/* ============================================================ */}
      <NextBestActionCard />

      {/* ============================================================ */}
      {/* РОУ 1.6: BIZON SIGNAL (P0)                                   */}
      {/* «На рынке происходит кое-что интересное» — тренды рынка,     */}
      {/* новые компании в отрасли, skill gap opportunity, market shift. */}
      {/* Источник: GET /api/me/signals                                */}
      {/* ============================================================ */}
      <BizonSignalCard />

      {/* ============================================================ */}
      {/* РОУ 1.7: ИСТОЧНИКИ ЛЕНТЫ (9-c — doc_a §14-15 News Bridge)     */}
      {/* Прозрачность: какие компании/медиа питают ленту + бейджи      */}
      {/* компаний-источников у новостей. Read-only: без подписки.      */}
      {/* ============================================================ */}
      <NewsSourcesCard />

      {/* ============================================================ */}
      {/* РОУ 1.75: РЫНОК (10-a — doc_a §17 BIZON Market Intelligence)  */}
      {/* Снапшот платформы: спрос по навыкам, горячие направления,    */}
      {/* динамика найма. Детерминированный сервис 9-b, без LLM,       */}
      {/* честные empty states + dataFootprint. Read-only.             */}
      {/* ============================================================ */}
      <MarketIntelligencePanel />

      {/* ============================================================ */}
      {/* РОУ 2: ЧТО ИЗМЕНИЛОСЬ                                        */}
      {/* Последние 5 событий из /api/me/actions                       */}
      {/* ============================================================ */}
      <RecentActionsCard
        loading={loading}
        actions={actions}
        onSeeAll={() => setView('me')}
      />

      {/* ============================================================ */}
      {/* РОУ 3: ВОЗМОЖНОСТИ                                           */}
      {/* Счётчики: вакансии (из /api/jobs) + проекты (из /api/projects) */}
      {/* ============================================================ */}
      <OpportunitiesCard
        loading={loading}
        jobsCount={jobsCount}
        projectsCount={projectsCount}
        onJobs={() => setView('jobs')}
        onProjects={() => setView('projects')}
      />
    </div>
  );
}

// ====================================================================
// === TRUST HERO COMPACT (Phase 3) ===
// Одна строка: «Trust 742 ↑18 | 12 навыков | 8 проектов | 94% доказано»
// + кнопка «Посмотреть профессиональную правду →»
// (заменяет большой ring с 6 категориями)
// ====================================================================
function TrustHeroCompact({
  loading,
  score,
  level,
  delta30,
  skillsCount,
  projectsCount,
  evidenceCoverage,
  greeting,
  firstName,
  onExplain,
}: {
  loading: boolean;
  score: number;
  level: TrustLevel;
  delta30: number | null;
  skillsCount: number;
  projectsCount: number;
  evidenceCoverage: number | null;
  greeting: string;
  firstName: string;
  onExplain: () => void;
}) {
  return (
    <Card className="lighthouse-gradient-soft border-lighthouse/20 overflow-hidden">
      <CardContent className="p-4 sm:p-5">
        {/* Заголовок: greeting + имя */}
        <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2.5">
          <Sparkles className="w-3.5 h-3.5 text-lighthouse" />
          {greeting}, {firstName}
        </div>

        {loading ? (
          <div className="space-y-2.5">
            <Skeleton className="h-7 w-full" />
            <Skeleton className="h-8 w-48" />
          </div>
        ) : (
          <>
            {/* Одна строка с метриками Trust */}
            <div className="flex items-center gap-2 sm:gap-3 flex-wrap text-sm">
              {/* Trust score + delta */}
              <div className="flex items-baseline gap-1.5">
                <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                  Trust
                </span>
                <span className="text-2xl font-extrabold leading-none tabular-nums">
                  {score}
                </span>
                {delta30 !== null && delta30 !== 0 && (
                  <span
                    className={cn(
                      'inline-flex items-center gap-0.5 text-xs font-semibold',
                      delta30 > 0
                        ? 'text-emerald-600 dark:text-emerald-500'
                        : 'text-red-600 dark:text-red-500',
                    )}
                    title="Изменение Trust за 30 дней"
                  >
                    {delta30 > 0 ? (
                      <ArrowUp className="w-3 h-3" />
                    ) : (
                      <ArrowDown className="w-3 h-3" />
                    )}
                    {Math.abs(delta30)}
                  </span>
                )}
              </div>

              <span className="text-muted-foreground/30">|</span>

              {/* Skills count */}
              <div className="inline-flex items-center gap-1.5" title="Подтверждённые навыки">
                <Award className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span className="font-semibold tabular-nums">{skillsCount}</span>
                <span className="text-muted-foreground text-xs hidden sm:inline">
                  {pluralize(skillsCount, 'навык', 'навыка', 'навыков')}
                </span>
              </div>

              <span className="text-muted-foreground/30">|</span>

              {/* Projects count */}
              <div className="inline-flex items-center gap-1.5" title="Проекты">
                <FolderKanban className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span className="font-semibold tabular-nums">{projectsCount}</span>
                <span className="text-muted-foreground text-xs hidden sm:inline">
                  {pluralize(projectsCount, 'проект', 'проекта', 'проектов')}
                </span>
              </div>

              {evidenceCoverage != null && (
                <>
                  <span className="text-muted-foreground/30">|</span>
                  {/* Evidence coverage */}
                  <div className="inline-flex items-center gap-1.5" title="Покрытие доказательствами">
                    <ShieldCheck className="w-3.5 h-3.5 text-lighthouse" />
                    <span className="font-semibold tabular-nums">
                      {Math.round(evidenceCoverage)}%
                    </span>
                    <span className="text-muted-foreground text-xs hidden sm:inline">доказано</span>
                  </div>
                </>
              )}

              <TrustBadge ipScore={score} level={level} size="sm" className="ml-auto" />
            </div>

            {/* CTA: переход на таб «Моя правда» */}
            <button
              type="button"
              onClick={onExplain}
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-lighthouse hover:underline transition"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Посмотреть профессиональную правду
              <ChevronRight className="w-3.5 h-3.5 opacity-70" />
            </button>
          </>
        )}
      </CardContent>
    </Card>
  );
}

// ====================================================================
// === WHILE AWAY BANNER (Phase 3 — While You Were Away) ===
// Баннер «Пока вас не было» с счётчиками изменений с прошлого визита.
// Показывается только если lastVisitAt > 1 дня назад.
// ====================================================================
function WhileAwayBanner({
  data,
  onSeeAll,
}: {
  data: NonNullable<WhatsNewResponse['whileAway']>;
  onSeeAll: () => void;
}) {
  const items: Array<{ icon: React.ReactNode; text: string; show: boolean }> = [
    {
      icon: <Eye className="w-3.5 h-3.5" />,
      text: `${data.profileViews} ${pluralize(data.profileViews, 'человек посмотрел', 'человека посмотрели', 'человек посмотрели')} профиль`,
      show: data.profileViews > 0,
    },
    {
      icon: <Briefcase className="w-3.5 h-3.5" />,
      text: `${data.companyJobsAdded} ${pluralize(data.companyJobsAdded, 'компания добавила', 'компании добавили', 'компаний добавили')} вакансию`,
      show: data.companyJobsAdded > 0,
    },
    {
      icon: <GraduationCap className="w-3.5 h-3.5" />,
      text: `${data.skillsConfirmed} ${pluralize(data.skillsConfirmed, 'навык подтверждён', 'навыка подтверждено', 'навыков подтверждено')}`,
      show: data.skillsConfirmed > 0,
    },
    {
      icon: <Users className="w-3.5 h-3.5" />,
      text: `${data.newPeopleFromArea} ${pluralize(data.newPeopleFromArea, 'новый человек', 'новых человека', 'новых людей')} из вашей области`,
      show: data.newPeopleFromArea > 0,
    },
    {
      icon: <Lightbulb className="w-3.5 h-3.5" />,
      text: `${data.aiRecommendation} ${pluralize(data.aiRecommendation, 'рекомендация AI', 'рекомендации AI', 'рекомендаций AI')}`,
      show: data.aiRecommendation > 0,
    },
  ];
  const visibleItems = items.filter((i) => i.show);

  // Если все счётчики нули — баннер не имеет смысла, не показываем.
  if (visibleItems.length === 0) return null;

  return (
    <Card className="border-amber-500/30 bg-gradient-to-br from-amber-500/5 via-transparent to-amber-500/5">
      <CardContent className="p-4 sm:p-5">
        {/* Заголовок: 📦 Пока вас не было (N дн) */}
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center flex-shrink-0">
            <Package className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold leading-tight">
              Пока вас не было
              <span className="text-amber-600 dark:text-amber-400 ml-1.5">
                ({data.daysAway} {pluralize(data.daysAway, 'день', 'дня', 'дней')})
              </span>
            </div>
            <div className="text-xs text-muted-foreground">
              Что произошло с последнего визита
            </div>
          </div>
        </div>

        {/* Список изменений */}
        <ul className="space-y-1.5 mb-3">
          {visibleItems.map((item, idx) => (
            <li
              key={idx}
              className="flex items-center gap-2 text-sm text-foreground/90"
            >
              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 flex-shrink-0">
                {item.icon}
              </span>
              <span>{item.text}</span>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <button
          type="button"
          onClick={onSeeAll}
          className="inline-flex items-center gap-1 text-xs font-medium px-3 py-1.5 rounded-md border border-amber-500/30 bg-background/60 hover:bg-amber-500/10 transition"
        >
          Посмотреть все
          <ChevronRight className="w-3 h-3 opacity-60" />
        </button>
      </CardContent>
    </Card>
  );
}

// ====================================================================
// === ЧТО ИЗМЕНИЛОСЬ ===
// Последние 5 событий из /api/me/actions
// ====================================================================
function RecentActionsCard({
  loading,
  actions,
  onSeeAll,
}: {
  loading: boolean;
  actions: ActionItem[];
  onSeeAll: () => void;
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-600/10 flex items-center justify-center">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-500" />
            </div>
            <div>
              <div className="text-sm font-semibold">Что изменилось</div>
              <div className="text-xs text-muted-foreground">
                Последние подтверждённые действия
              </div>
            </div>
          </div>
          {actions.length > 0 && (
            <button
              type="button"
              onClick={onSeeAll}
              className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-0.5 transition"
            >
              Все
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-2">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3 w-3/4" />
                  <Skeleton className="h-2.5 w-1/3" />
                </div>
                <Skeleton className="w-12 h-3" />
              </div>
            ))}
          </div>
        ) : actions.length === 0 ? (
          <div className="text-xs text-muted-foreground text-center py-6">
            Пока нет подтверждённых действий.
            <br />
            Завершите проект или попросите коллегу подтвердить навык — и здесь
            появятся ваши достижения.
          </div>
        ) : (
          <ul className="space-y-1">
            {actions.map((ev) => {
              const meta = getActionMeta(ev.type);
              return (
                <li
                  key={ev.id}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition"
                >
                  <span
                    className={cn(
                      'flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center',
                      meta.color,
                    )}
                  >
                    {meta.icon}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate font-medium">
                      {ev.title}
                    </div>
                    {ev.description && (
                      <div className="text-xs text-muted-foreground truncate">
                        {ev.description}
                      </div>
                    )}
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {formatRelativeTime(ev.createdAt)} · {meta.fallbackLabel}
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// ====================================================================
// === ВОЗМОЖНОСТИ ===
// Счётчики: вакансии (из /api/jobs) + проекты (из /api/projects)
// ====================================================================
function OpportunitiesCard({
  loading,
  jobsCount,
  projectsCount,
  onJobs,
  onProjects,
}: {
  loading: boolean;
  jobsCount: number;
  projectsCount: number;
  onJobs: () => void;
  onProjects: () => void;
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center">
            <Briefcase className="w-3.5 h-3.5 text-lighthouse" />
          </div>
          <div>
            <div className="text-sm font-semibold">Возможности</div>
            <div className="text-xs text-muted-foreground">
              Подобраны под ваш профиль
            </div>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 2 }).map((_, i) => (
              <div
                key={i}
                className="text-center p-4 rounded-lg bg-muted/40 space-y-2"
              >
                <Skeleton className="h-8 w-12 mx-auto" />
                <Skeleton className="h-3 w-20 mx-auto" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <OpportunityCard
              icon={<Briefcase className="w-4 h-4" />}
              count={jobsCount}
              label={pluralize(jobsCount, 'вакансия', 'вакансии', 'вакансий')}
              hint="Match ≥ 70%"
              onClick={onJobs}
              accent="text-emerald-600 dark:text-emerald-500"
            />
            <OpportunityCard
              icon={<FolderKanban className="w-4 h-4" />}
              count={projectsCount}
              label={pluralize(projectsCount, 'проект', 'проекта', 'проектов')}
              hint="Ищут команду"
              onClick={onProjects}
              accent="text-lighthouse"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function OpportunityCard({
  icon,
  count,
  label,
  hint,
  onClick,
  accent,
}: {
  icon: React.ReactNode;
  count: number;
  label: string;
  hint: string;
  onClick: () => void;
  accent: string;
}) {
  const isClickable = count > 0;
  return (
    <button
      type="button"
      onClick={isClickable ? onClick : undefined}
      disabled={!isClickable}
      className={cn(
        'text-left p-4 rounded-lg border transition group',
        isClickable
          ? 'border-transparent hover:border-lighthouse/30 hover:bg-accent cursor-pointer'
          : 'border-transparent opacity-60 cursor-default',
      )}
    >
      <div className={cn('flex items-center gap-1.5 mb-1', accent)}>
        {icon}
        <span className="text-xs uppercase tracking-wider font-semibold">
          {hint}
        </span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-3xl font-bold tabular-nums leading-none">
          {count}
        </span>
      </div>
      <div className="text-xs text-muted-foreground mt-1">{label}</div>
    </button>
  );
}
