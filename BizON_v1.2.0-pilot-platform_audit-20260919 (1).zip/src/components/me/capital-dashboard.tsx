// BizON v6 — CapitalDashboard (Professional Capital)
// Карточка «Капитал профессионала»: общий балл (0..100) + 8 компонентов
// с весами и вкладом каждого. Кнопка «Пересчитать» → POST recompute.
//
// Источник: GET  /api/me/capital          → { capital, trend }
//           POST /api/me/capital/recompute → { capital, recomputedAt }
//
// Веса зафиксированы в CapitalService (v6.0, объяснимы):
//   verifiedExpertise 0.20 · projectCapital 0.15 · outcomeCapital 0.15 ·
//   trustCapital 0.15 · networkCapital 0.10 · leadershipCapital 0.10 ·
//   marketRelevance 0.10 · learningVelocity 0.05
//
// Дизайн: navy-текст, teal (lighthouse) акценты, без синего-500 как основного.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import {
  Gauge, RefreshCw, Loader2, Lock, AlertCircle, Info, Gem,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================
// === Типы данных (/api/me/capital) ===
// ============================================================

interface CapitalData {
  id: string;
  userId: string;
  verifiedExpertise: number;
  projectCapital: number;
  outcomeCapital: number;
  trustCapital: number;
  networkCapital: number;
  leadershipCapital: number;
  marketRelevance: number;
  learningVelocity: number;
  total: number;
  recomputedAt: string;
}

interface CapitalTrend {
  direction: 'up' | 'down' | 'stable';
  delta: number;
  note: string;
}

type CapitalKey = Exclude<keyof CapitalData, 'id' | 'userId' | 'total' | 'recomputedAt'>;

// Русские подписи + веса (источник истины — CapitalService WEIGHTS)
const COMPONENT_META: Record<CapitalKey, { label: string; hint: string; weight: number }> = {
  verifiedExpertise: { label: 'Подтверждённая экспертиза', hint: 'Навыки, подтверждённые коллегами и проектами', weight: 0.20 },
  projectCapital:    { label: 'Проектный капитал',         hint: 'Доведённые до завершения проекты',            weight: 0.15 },
  outcomeCapital:    { label: 'Капитал результатов',        hint: 'Доказательства с измеримым результатом',      weight: 0.15 },
  trustCapital:      { label: 'Капитал доверия',            hint: 'IP-score и уровень доверия платформы',        weight: 0.15 },
  networkCapital:    { label: 'Сетевой капитал',            hint: 'Принятые связи в сети доверия',               weight: 0.10 },
  leadershipCapital: { label: 'Лидерский капитал',          hint: 'Роли основателя проектов, менторство',        weight: 0.10 },
  marketRelevance:   { label: 'Актуальность на рынке',      hint: 'Навыки, востребованные активными вакансиями', weight: 0.10 },
  learningVelocity:  { label: 'Скорость обучения',          hint: 'Новые навыки за последние 30 дней',           weight: 0.05 },
};

const COMPONENT_ORDER: CapitalKey[] = [
  'verifiedExpertise', 'projectCapital', 'outcomeCapital', 'trustCapital',
  'networkCapital', 'leadershipCapital', 'marketRelevance', 'learningVelocity',
];

// ============================================================
// === Утилиты ===
// ============================================================

const isAuthError = (e: unknown) => e instanceof Error && /не авторизован/i.test(e.message);

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString('ru-RU', {
      day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return '';
  }
}

// ============================================================
// === Скелетон загрузки ===
// ============================================================

function CapitalSkeleton() {
  return (
    <Card aria-label="Капитал профессионала — загрузка">
      <CardHeader>
        <Skeleton className="h-6 w-64" />
        <Skeleton className="h-4 w-80 max-w-full" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <Skeleton className="h-16 w-16 rounded-full" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-4 w-40" />
            <Skeleton className="h-2 w-full" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {COMPONENT_ORDER.map((k) => (
            <div key={k} className="space-y-2">
              <Skeleton className="h-4 w-44" />
              <Skeleton className="h-2 w-full" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================
// === Состояние «Войдите» (401) ===
// ============================================================

function LoginRequired() {
  return (
    <Card className="border-dashed">
      <CardContent className="py-10 text-center">
        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
          <Lock className="w-6 h-6 text-muted-foreground" aria-hidden="true" />
        </div>
        <div className="font-medium">Войдите, чтобы увидеть капитал профессионала</div>
        <p className="text-sm text-muted-foreground mt-1">
          Капитал считается по доказательствам вашей активности.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================
// === Основной компонент ===
// ============================================================

export function CapitalDashboard() {
  const { user } = useAppStore();
  const [capital, setCapital] = React.useState<CapitalData | null>(null);
  const [trend, setTrend] = React.useState<CapitalTrend | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [recomputing, setRecomputing] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [authRequired, setAuthRequired] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!user) { setAuthRequired(true); setLoading(false); return; }
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ capital: CapitalData | null; trend: CapitalTrend }>('/api/me/capital');
      setCapital(res.capital ?? null);
      setTrend(res.trend ?? null);
      setAuthRequired(false);
    } catch (e) {
      if (isAuthError(e)) setAuthRequired(true);
      else setError(e instanceof Error ? e.message : 'Не удалось загрузить капитал');
    } finally {
      setLoading(false);
    }
  }, [user]);

  React.useEffect(() => { load(); }, [load]);

  const recompute = async () => {
    setRecomputing(true);
    try {
      const res = await api<{ capital: CapitalData; recomputedAt: string }>(
        '/api/me/capital/recompute',
        { method: 'POST' },
      );
      setCapital(res.capital);
      setTrend((prev) => prev ? { ...prev, note: 'Капитал рассчитан только что' } : prev);
      toast({ title: 'Капитал пересчитан', description: `Новый балл: ${Math.round(res.capital.total)} из 100` });
    } catch (e) {
      if (isAuthError(e)) { setAuthRequired(true); }
      else {
        toast({ title: 'Не удалось пересчитать', description: e instanceof Error ? e.message : 'Попробуйте позже', variant: 'destructive' });
      }
    } finally {
      setRecomputing(false);
    }
  };

  if (authRequired) return <LoginRequired />;
  if (loading) return <CapitalSkeleton />;
  if (error || !capital) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="py-8 text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-destructive mx-auto" aria-hidden="true" />
          <p className="text-sm text-destructive">{error ?? 'Капитал пока не рассчитан'}</p>
          <Button variant="outline" size="sm" onClick={load} aria-label="Повторить загрузку капитала">
            <RefreshCw className="w-4 h-4 mr-1.5" aria-hidden="true" />
            Повторить
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card aria-label="Капитал профессионала">
      <CardHeader className="flex flex-row items-start justify-between space-y-0 flex-wrap gap-3">
        <div className="space-y-1.5">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Gem className="w-5 h-5 text-lighthouse" aria-hidden="true" />
            Капитал профессионала
          </CardTitle>
          <CardDescription>
            Взвешенная сумма 8 доказуемых компонентов — «Не говори, кто ты — докажи это».
          </CardDescription>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={recompute}
          disabled={recomputing}
          aria-label="Пересчитать капитал"
        >
          {recomputing
            ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" aria-hidden="true" />
            : <RefreshCw className="w-4 h-4 mr-1.5" aria-hidden="true" />}
          {recomputing ? 'Пересчёт…' : 'Пересчитать'}
        </Button>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Общий балл */}
        <div className="flex items-center gap-4 flex-wrap">
          <div
            className="flex h-20 w-20 flex-shrink-0 flex-col items-center justify-center rounded-full border-2 border-lighthouse/40 bg-lighthouse/5"
            role="status"
            aria-label={`Общий капитал: ${Math.round(capital.total)} из 100`}
          >
            <span className="text-2xl font-bold tabular-nums text-lighthouse">
              {Math.round(capital.total)}
            </span>
            <span className="text-xs text-muted-foreground">из 100</span>
          </div>
          <div className="flex-1 min-w-[200px] space-y-2">
            <Progress
              value={Math.min(100, capital.total)}
              aria-label={`Общий балл капитала: ${Math.round(capital.total)}`}
              className="h-2.5 [&_[data-slot=progress-indicator]]:bg-lighthouse"
            />
            {trend && (
              <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-lighthouse" aria-hidden="true" />
                {trend.note}
              </p>
            )}
            <p className="text-xs text-muted-foreground tabular-nums">
              Последний расчёт: {formatDate(capital.recomputedAt) || '—'}
            </p>
          </div>
        </div>

        {/* 8 компонентов */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
          {COMPONENT_ORDER.map((key) => {
            const meta = COMPONENT_META[key];
            const value = capital[key] ?? 0;
            const contribution = Math.round(value * meta.weight * 100) / 100;
            return (
              <div key={key} className="space-y-1.5" aria-label={`${meta.label}: ${Math.round(value)} из 100, вес ${Math.round(meta.weight * 100)}%`}>
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-medium leading-tight">{meta.label}</span>
                  <span className="text-xs text-muted-foreground tabular-nums flex-shrink-0">
                    {Math.round(value)} · вес {Math.round(meta.weight * 100)}%
                  </span>
                </div>
                <Progress
                  value={Math.min(100, value)}
                  aria-label={`${meta.label}: ${Math.round(value)} из 100`}
                  className={cn(
                    'h-2',
                    value >= 70
                      ? '[&_[data-slot=progress-indicator]]:bg-lighthouse'
                      : value >= 35
                        ? '[&_[data-slot=progress-indicator]]:bg-lighthouse/60'
                        : '[&_[data-slot=progress-indicator]]:bg-muted-foreground/40',
                  )}
                />
                <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                  <span className="truncate">{meta.hint}</span>
                  <Badge variant="secondary" className="text-xs px-1.5 py-0 tabular-nums flex-shrink-0">
                    +{contribution}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
