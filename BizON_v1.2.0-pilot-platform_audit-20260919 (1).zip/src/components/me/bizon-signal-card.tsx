// BizON — BizonSignalCard (P0: BIZON SIGNAL — «на рынке происходит кое-что интересное»)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 📡 BIZON SIGNAL                                              │
//   │ На рынке происходит кое-что интересное                        │
//   │                                                              │
//   │ 📈 Спрос на React вырос на 42%       → [Мои навыки]          │
//   │ 🏢 Yandex нанимает в вашей отрасли   → [Открыть]             │
//   │ 💡 Если подтвердите TypeScript,       → [Подтвердить]        │
//   │    откроется 18 новых возможностей                           │
//   │ 🌐 В отрасли «IT» растёт спрос на Go → [Узнать больше]      │
//   └──────────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/signals → { items: BizonSignal[], total, generatedAt }
// Блок НЕ рендерится, если сигналов нет (или ещё грузятся впервые — skeleton).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Radio,
  TrendingUp,
  Building2,
  Lightbulb,
  Globe2,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы данных (зеркало BizonSignal из bizon-signal-service.ts) ===
// ============================================================================

type BizonSignalType =
  | 'skill_trend'
  | 'new_company'
  | 'skill_gap_opportunity'
  | 'market_shift';

interface BizonSignal {
  type: BizonSignalType;
  title: string;
  description: string;
  relevance: number;
  action: {
    label: string;
    view?: string;
    entityId?: string;
    externalUrl?: string;
  };
  meta?: Record<string, unknown>;
}

interface SignalsResponse {
  items: BizonSignal[];
  total: number;
  generatedAt: string;
}

// ============================================================================
// === Мета по типам сигналов: иконка + цвет + русская подпись ===
// ============================================================================

const SIGNAL_META: Record<
  BizonSignalType,
  { icon: React.ReactNode; label: string; accent: string; bg: string }
> = {
  skill_trend: {
    icon: <TrendingUp className="w-4 h-4" />,
    label: 'Тренд навыка',
    accent: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  new_company: {
    icon: <Building2 className="w-4 h-4" />,
    label: 'Нанимают',
    accent: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-500/10',
  },
  skill_gap_opportunity: {
    icon: <Lightbulb className="w-4 h-4" />,
    label: 'Skill gap',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
  market_shift: {
    icon: <Globe2 className="w-4 h-4" />,
    label: 'Сдвиг рынка',
    accent: 'text-violet-600 dark:text-violet-400',
    bg: 'bg-violet-500/10',
  },
};

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function BizonSignalCard() {
  const { setView, setSelectedCompanyId } = useAppStore();
  const [data, setData] = React.useState<SignalsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<SignalsResponse>('/api/me/signals')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e) => {
        console.error('[BizonSignalCard] load error:', e);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Loading — компактный skeleton (3 строки).
  if (loading) {
    return (
      <Card className="border-lighthouse/20">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <Skeleton className="w-7 h-7 rounded-lg" />
            <Skeleton className="h-4 w-44" />
          </div>
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-2.5">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-2/3" />
                  <Skeleton className="h-2.5 w-1/2" />
                </div>
                <Skeleton className="w-16 h-7 rounded-md" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Нет сигналов — блок не показывается (как в BizonDiscover).
  if (!data || data.items.length === 0) {
    return null;
  }

  const items = data.items;

  // Хендлер клика по action — SPA-навигация (как в BizonDiscover).
  function handleAction(signal: BizonSignal) {
    const { action } = signal;
    if (action.externalUrl) {
      window.open(action.externalUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    if (!action.view) return;

    // Сначала — специальные кейсы с entityId.
    if (action.view === 'company' && action.entityId) {
      setSelectedCompanyId(action.entityId);
      return;
    }

    // Иначе — просто переключаем view.
    setView(action.view as any);
  }

  return (
    <Card className="border-lighthouse/20 bg-gradient-to-br from-lighthouse/5 via-transparent to-transparent">
      <CardContent className="p-5">
        {/* Заголовок: 📡 BIZON SIGNAL */}
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
            <Radio className="w-4 h-4 text-lighthouse" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold leading-tight">
              BIZON SIGNAL
            </div>
            <div className="text-xs text-muted-foreground">
              На рынке происходит кое-что интересное
            </div>
          </div>
        </div>

        {/* Список сигналов */}
        <ul className="space-y-1">
          {items.map((signal, idx) => {
            const meta = SIGNAL_META[signal.type];
            const relevancePct = Math.round(signal.relevance * 100);
            return (
              <li
                key={`${signal.type}-${idx}`}
                className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-accent/60 transition group"
              >
                {/* Иконка типа */}
                <span
                  className={cn(
                    'flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center mt-0.5',
                    meta.bg,
                    meta.accent,
                  )}
                >
                  {meta.icon}
                </span>

                {/* Контент */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span
                      className={cn(
                        'text-xs uppercase tracking-wider font-semibold',
                        meta.accent,
                      )}
                    >
                      {meta.label}
                    </span>
                    {relevancePct >= 70 && (
                      <span className="text-xs text-muted-foreground">
                        · {relevancePct}% relevant
                      </span>
                    )}
                  </div>
                  <div
                    className="text-sm font-medium leading-snug"
                    title={signal.title}
                  >
                    {signal.title}
                  </div>
                  <div
                    className="text-xs text-muted-foreground leading-relaxed mt-0.5"
                    title={signal.description}
                  >
                    {signal.description}
                  </div>
                </div>

                {/* CTA */}
                <button
                  type="button"
                  onClick={() => handleAction(signal)}
                  className="inline-flex items-center gap-0.5 flex-shrink-0 text-xs font-medium px-2.5 py-1.5 rounded-md border border-lighthouse/30 bg-background/60 hover:bg-lighthouse/10 hover:border-lighthouse/50 transition"
                >
                  {signal.action.label}
                  <ChevronRight className="w-3 h-3 opacity-60" />
                </button>
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}
