// BizON — ActionsTimelineTab (R10 Actions Timeline)
// Tab «Действия» в разделе «Я» — хронология подтверждённых поступков.
//   • Список событий (иконка + title + дата)
//   • Сортировка: последние сверху
//   • Фильтр по типу события
//   • Только подтверждённые действия (CLAIMED не попадает)
//
// Источник данных: GET /api/me/actions
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Award,
  FolderKanban,
  FolderCheck,
  Users,
  FileText,
  ShieldCheck,
  Activity,
  ChevronRight,
  TrendingUp,
  CheckCircle2,
  GraduationCap,
  Star,
  Rocket,
  Briefcase,
  Eye,
  Mail,
  Lightbulb,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// === Типы ===
type ActionEventType =
  | 'nft_skill_received'
  | 'project_completed'
  | 'project_started'
  | 'community_joined'
  | 'article_published'
  | 'claim_verified'
  // P0-5 — Professional Moments
  | 'trust_up'
  | 'evidence_added'
  | 'skill_verified'
  | 'recommendation_received'
  | 'project_verified'
  | 'new_opportunity'
  | 'company_viewed_profile'
  | 'recruiter_invitation'
  | 'blind_spot_discovered';

interface ActionItem {
  id: string;
  type: ActionEventType;
  title: string;
  description: string | null;
  metadata: any;
  isPublic: boolean;
  createdAt: string;
}

interface ActionStats {
  type: ActionEventType;
  count: number;
}

interface ActionsResponse {
  items: ActionItem[];
  total: number;
  hasMore: boolean;
  stats: ActionStats[];
}

const TYPE_META: Record<
  ActionEventType,
  { label: string; icon: React.ReactNode; color: string }
> = {
  nft_skill_received: {
    label: 'NFT-навык',
    icon: <Award className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
  },
  project_completed: {
    label: 'Завершён проект',
    icon: <FolderCheck className="w-4 h-4" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
  },
  project_started: {
    label: 'Старт проекта',
    icon: <FolderKanban className="w-4 h-4" />,
    color: 'text-blue-600 dark:text-blue-400 bg-blue-500/10',
  },
  community_joined: {
    label: 'Сообщество',
    icon: <Users className="w-4 h-4" />,
    color: 'text-purple-600 dark:text-purple-400 bg-purple-500/10',
  },
  article_published: {
    label: 'Публикация',
    icon: <FileText className="w-4 h-4" />,
    color: 'text-sky-600 dark:text-sky-400 bg-sky-500/10',
  },
  claim_verified: {
    label: 'Подтверждён claim',
    icon: <ShieldCheck className="w-4 h-4" />,
    color: 'text-lighthouse bg-lighthouse/10',
  },
  // === P0-5 — Professional Moments ===
  trust_up: {
    label: 'Trust ↑',
    icon: <TrendingUp className="w-4 h-4" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
  },
  evidence_added: {
    label: 'Доказательство',
    icon: <CheckCircle2 className="w-4 h-4" />,
    color: 'text-sky-600 dark:text-sky-400 bg-sky-500/10',
  },
  skill_verified: {
    label: 'Навык подтверждён',
    icon: <GraduationCap className="w-4 h-4" />,
    color: 'text-violet-600 dark:text-violet-400 bg-violet-500/10',
  },
  recommendation_received: {
    label: 'Рекомендация',
    icon: <Star className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
  },
  project_verified: {
    label: 'Проект верифицирован',
    icon: <Rocket className="w-4 h-4" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
  },
  new_opportunity: {
    label: 'Новая возможность',
    icon: <Briefcase className="w-4 h-4" />,
    color: 'text-lighthouse bg-lighthouse/10',
  },
  company_viewed_profile: {
    label: 'Профиль просмотрен',
    icon: <Eye className="w-4 h-4" />,
    color: 'text-slate-600 dark:text-slate-300 bg-slate-500/10',
  },
  recruiter_invitation: {
    label: 'Приглашение',
    icon: <Mail className="w-4 h-4" />,
    color: 'text-rose-600 dark:text-rose-400 bg-rose-500/10',
  },
  blind_spot_discovered: {
    label: 'Blind spot',
    icon: <Lightbulb className="w-4 h-4" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
  },
};

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function ActionsTimelineTab() {
  const [items, setItems] = React.useState<ActionItem[]>([]);
  const [stats, setStats] = React.useState<ActionStats[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [loadingMore, setLoadingMore] = React.useState(false);
  const [hasMore, setHasMore] = React.useState(false);
  const [total, setTotal] = React.useState(0);
  const [filter, setFilter] = React.useState<ActionEventType | 'all'>('all');
  const [offset, setOffset] = React.useState(0);

  const PAGE_SIZE = 20;

  const loadFirst = React.useCallback(async (type: ActionEventType | 'all') => {
    setLoading(true);
    try {
      const qs = type === 'all' ? '' : `?type=${type}`;
      const res = await api<ActionsResponse>(`/api/me/actions?limit=${PAGE_SIZE}&offset=0${qs ? '&' + qs.slice(1) : ''}`);
      setItems(res.items);
      setStats(res.stats);
      setHasMore(res.hasMore);
      setTotal(res.total);
      setOffset(PAGE_SIZE);
    } catch (e) {
      console.error('[actions-timeline] load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadMore = React.useCallback(async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    try {
      const typeParam = filter !== 'all' ? `&type=${filter}` : '';
      const res = await api<ActionsResponse>(
        `/api/me/actions?limit=${PAGE_SIZE}&offset=${offset}${typeParam}`,
      );
      setItems((prev) => [...prev, ...res.items]);
      setHasMore(res.hasMore);
      setOffset((o) => o + PAGE_SIZE);
    } catch (e) {
      console.error('[actions-timeline] loadMore error:', e);
    } finally {
      setLoadingMore(false);
    }
  }, [filter, hasMore, loadingMore, offset]);

  React.useEffect(() => {
    loadFirst(filter);
  }, [loadFirst, filter]);

  const totalStats = stats.reduce((sum, s) => sum + s.count, 0);

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="rounded-full bg-lighthouse/10 p-2 shrink-0">
              <Activity className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold">Действия</h2>
              <p className="text-sm text-muted-foreground mt-0.5">
                Хронология подтверждённых поступков: завершённые проекты, NFT-навыки,
                подтверждённые утверждения, публикации. Только проверенные факты — без «заявленного».
              </p>
              <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
                <span>Всего событий: <span className="font-semibold text-foreground">{total}</span></span>
                <span>·</span>
                <span>Публичных: <span className="font-semibold text-foreground">{totalStats}</span></span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <FilterChip
          label="Все"
          active={filter === 'all'}
          onClick={() => setFilter('all')}
        />
        {(Object.keys(TYPE_META) as ActionEventType[]).map((t) => {
          const count = stats.find((s) => s.type === t)?.count ?? 0;
          if (count === 0 && filter !== t) return null;
          return (
            <FilterChip
              key={t}
              label={TYPE_META[t].label}
              count={count}
              active={filter === t}
              onClick={() => setFilter(t)}
            />
          );
        })}
      </div>

      {/* Timeline list */}
      {loading ? (
        <div className="space-y-2">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full rounded-lg" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-8 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-muted mb-3">
              <Activity className="w-6 h-6 text-muted-foreground" />
            </div>
            <h3 className="text-base font-semibold mb-1">Пока пусто</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Завершите проект, опубликуйте пост или получите NFT-навык —
              и здесь появится ваша хронология поступков.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="relative">
          {/* Вертикальная линия timeline */}
          <div className="absolute left-[19px] top-2 bottom-2 w-px bg-border" aria-hidden="true" />

          <ul className="space-y-3">
            {items.map((item) => {
              const meta = TYPE_META[item.type] ?? {
                label: item.type,
                icon: <Activity className="w-4 h-4" />,
                color: 'text-muted-foreground bg-muted',
              };
              return (
                <li key={item.id} className="relative pl-12">
                  {/* Иконка */}
                  <div
                    className={cn(
                      'absolute left-0 top-0 w-10 h-10 rounded-full flex items-center justify-center ring-4 ring-background',
                      meta.color,
                    )}
                  >
                    {meta.icon}
                  </div>
                  <Card className="overflow-hidden">
                    <CardContent className="p-3 sm:p-4">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                            <Badge
                              variant="outline"
                              className={cn('text-xs px-1.5 py-0', meta.color, 'border-transparent')}
                            >
                              {meta.label}
                            </Badge>
                            {!item.isPublic && (
                              <Badge variant="secondary" className="text-xs px-1.5 py-0">
                                скрыто
                              </Badge>
                            )}
                          </div>
                          <h4 className="text-sm font-medium leading-snug">
                            {item.title}
                          </h4>
                          {item.description && (
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-3">
                              {item.description}
                            </p>
                          )}
                        </div>
                        <time
                          dateTime={item.createdAt}
                          className="text-xs text-muted-foreground shrink-0 tabular-nums"
                        >
                          {formatDate(item.createdAt)}
                        </time>
                      </div>
                    </CardContent>
                  </Card>
                </li>
              );
            })}
          </ul>

          {hasMore && (
            <div className="flex justify-center mt-4">
              <Button variant="outline" size="sm" onClick={loadMore} disabled={loadingMore}>
                {loadingMore ? 'Загрузка…' : 'Показать ещё'}
                {!loadingMore && <ChevronRight className="w-3.5 h-3.5 ml-1" />}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function FilterChip({
  label,
  count,
  active,
  onClick,
}: {
  label: string;
  count?: number;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full border transition',
        active
          ? 'bg-primary text-primary-foreground border-primary'
          : 'bg-background hover:bg-accent border-border text-foreground',
      )}
    >
      {label}
      {typeof count === 'number' && (
        <span
          className={cn(
            'text-xs px-1.5 py-0.5 rounded-full',
            active ? 'bg-primary-foreground/20' : 'bg-muted',
          )}
        >
          {count}
        </span>
      )}
    </button>
  );
}
