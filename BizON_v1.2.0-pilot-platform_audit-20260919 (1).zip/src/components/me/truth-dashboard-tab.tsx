// BizON — TruthDashboardTab (P0-1 — Professional Truth Dashboard)
// Заменяет WhatsNewTab как первый экран при входе.
//
// 4 блока из аудита (Часть 8 — UX 2.0):
//   ┌──────────────────────────────────────────────┐
//   │  ВАША ПРОФЕССИОНАЛЬНАЯ ПРАВДА                │
//   │  TRUST 82 ↑ (IP-score ring + level + delta)  │
//   │  Компетентность  Надёжность  Leadership      │
//   │      91            87          82             │
//   ├──────────────────────────────────────────────┤
//   │  ЧТО ИЗМЕНИЛОСЬ                              │
//   │  ✓ Проект подтверждён         +18 Trust       │
//   │  ✓ Навык подтверждён           +7 Trust       │
//   │  ★ Новая рекомендация                          │
//   ├──────────────────────────────────────────────┤
//   │  BIZON AI INSIGHT (заглушка до P0-10)         │
//   ├──────────────────────────────────────────────┤
//   │  ВОЗМОЖНОСТИ                                  │
//   │  3 проекта    7 вакансий   2 интро            │
//   └──────────────────────────────────────────────┘
//
// Доп. секция (старое «Что нового», без заглушек):
//   • Дельта с последнего визита (5 счётчиков)
//   • Мини-календарь событий
//   • Модал входящих запросов от коллег (R9)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { CompactCalendar } from '@/components/feed/compact-calendar';
import { IncomingInquiriesDialog } from '@/components/colleague-inquiries/incoming-inquiries-dialog';
import { TrustBadge, IpScoreRing } from '@/components/common/trust-badge';
// P0-2: Explainable Trust — карточка с breakdown + «Почему?» + «Как повысить?»
import { TrustExplainCard } from '@/components/truth/trust-explain-card';
import {
  Sparkles, ShieldCheck, FolderKanban, Briefcase, UserPlus,
  TrendingUp, ArrowUp, ArrowDown, Award, Star, FolderCheck,
  Lightbulb, Lock, ChevronRight, MessageSquare, MessageCircle,
  MessageCircleHeart, Layers, Target,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// === Типы данных с /api/me/whats-new ===
interface Breakdown {
  competence: number;     // 0..100 — навыки
  reliability: number;    // 0..100 — рейтинги
  delivery: number;       // 0..100 — завершённые проекты
  leadership: number;     // 0..100 — лидерство
  collaboration: number; // 0..100 — активность
  expertise: number;      // 0..100 — общий
}

interface TrustHero {
  score: number;
  level: string;
  delta30days: number | null;
  breakdown: Breakdown;
  evidenceCoverage: number | null;
}

interface RecentEvent {
  id: string;
  eventType: string;
  labelRu: string;
  contextName: string | null;
  deltaTrust: number | null;
  isStar: boolean;
  createdAt: string;
}

interface Opportunities {
  jobsCount: number;
  projectsCount: number;
  introCount: number;
}

interface WhatsNewData {
  since: string;
  lastVisitAt: string | null;
  deltas: {
    messages: number;
    commentsOnOwnPosts: number;
    confirmations: number;
    projectInvites: number;
    trustDelta: number;
    baselineScore: number;
    latestScore: number;
    colleagueInquiries?: number;
  };
  trustHero: TrustHero;
  recentEvents: RecentEvent[];
  opportunities: Opportunities;
}

// === Хелперы ===

function getGreeting(d: Date): string {
  const h = d.getHours();
  if (h < 5) return 'Доброй ночи';
  if (h < 12) return 'Доброе утро';
  if (h < 18) return 'Добрый день';
  return 'Добрый вечер';
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return 'только что';
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min} мин назад`;
  const hrs = Math.floor(min / 60);
  if (hrs < 24) return `${hrs} ч назад`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'вчера';
  if (days < 7) return `${days} дн назад`;
  return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// Иконки для типов ReputationEvent в блоке «Что изменилось»
const EVENT_ICON: Record<string, React.ReactNode> = {
  project_completed: <FolderCheck className="w-4 h-4" />,
  skill_confirmed: <Award className="w-4 h-4" />,
  positive_review: <Star className="w-4 h-4" />,
  intro_sent: <UserPlus className="w-4 h-4" />,
};

// 6 осей Truth Hero — метаданные для отображения
const BREAKDOWN_AXES: Array<{
  key: keyof Breakdown;
  label: string;
  hint: string;
}> = [
  { key: 'competence', label: 'Компетентность', hint: 'Подтверждённые навыки' },
  { key: 'reliability', label: 'Надёжность', hint: 'Рейтинги коллег' },
  { key: 'delivery', label: 'Delivery', hint: 'Завершённые проекты' },
  { key: 'leadership', label: 'Leadership', hint: 'Управление проектами' },
  { key: 'collaboration', label: 'Сотрудничество', hint: 'Активность' },
  { key: 'expertise', label: 'Экспертиза', hint: 'Общий уровень' },
];

// Цвет полосы прогресса по значению 0..100
function breakdownColor(v: number): string {
  if (v >= 71) return 'bg-emerald-500 dark:bg-emerald-400';
  if (v >= 31) return 'bg-lighthouse';
  return 'bg-amber-500 dark:bg-amber-400';
}

export function TruthDashboardTab() {
  const { user, setView } = useAppStore();
  const [data, setData] = React.useState<WhatsNewData | null>(null);
  const [loading, setLoading] = React.useState(true);
  // R9: модал входящих запросов от коллег
  const [inquiriesOpen, setInquiriesOpen] = React.useState(false);
  const [inquiriesCount, setInquiriesCount] = React.useState(0);

  const load = React.useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const since = sessionStorage.getItem('bizon_previous_last_visit');
      const qs = since ? `?since=${encodeURIComponent(since)}` : '';
      const res = await api<WhatsNewData>(`/api/me/whats-new${qs}`);
      setData(res);
      setInquiriesCount(res.deltas.colleagueInquiries ?? 0);
    } catch (e) {
      console.error('[truth-dashboard] load error:', e);
    } finally {
      setLoading(false);
    }
  }, [user]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (!user) return null;

  const now = new Date();
  const greeting = getGreeting(now);
  const firstName = user.name.split(' ')[0] || user.name;
  const hero = data?.trustHero;
  const opps = data?.opportunities;

  return (
    <div className="space-y-4">
      {/* ============================= */}
      {/* P0-2: EXPLAINABLE TRUST — карточка вверху «Моя правда» */}
      {/* Крупный score + breakdown (collapsed) + «Почему?» + «Как повысить?» */}
      {/* ============================= */}
      <TrustExplainCard defaultOpen />

      {/* ============================= */}
      {/* РОУ 1: TRUST HERO + Календарь */}
      {/* ============================= */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-4">
        <TrustHeroCard
          loading={loading}
          hero={hero}
          greeting={greeting}
          firstName={firstName}
          level={user.level}
          onShowEvidence={() => setView('me')}
        />
        {/* Календарь — мини, с today/tomorrow events */}
        <div className="lg:w-80">
          <CompactCalendar />
        </div>
      </div>

      {/* ============================= */}
      {/* РОУ 2: ЧТО ИЗМЕНИЛОСЬ + BIZON AI INSIGHT */}
      {/* ============================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <RecentEventsCard
          loading={loading}
          events={data?.recentEvents ?? []}
        />
        <AiInsightCard />
      </div>

      {/* ============================= */}
      {/* РОУ 3: ВОЗМОЖНОСТИ */}
      {/* ============================= */}
      <OpportunitiesCard
        loading={loading}
        opps={opps}
        onProjects={() => setView('projects')}
        onJobs={() => setView('jobs')}
        onIntros={() => setView('network')}
      />

      {/* ============================= */}
      {/* РОУ 4: ДЕЛЬТА С ПОСЛЕДНЕГО ВИЗИТА (старый синий блок) */}
      {/* ============================= */}
      <DeltaSinceVisitCard
        loading={loading}
        data={data}
        inquiriesCount={inquiriesCount}
        onInquiries={() => inquiriesCount > 0 && setInquiriesOpen(true)}
        onMessages={() => setView('messages')}
        onFeed={() => setView('feed')}
        onNetwork={() => setView('network')}
        onProjects={() => setView('projects')}
        onMe={() => setView('me')}
      />

      {/* R9: Модал входящих запросов от коллег */}
      <IncomingInquiriesDialog
        open={inquiriesOpen}
        onOpenChange={setInquiriesOpen}
        onResponded={load}
      />
    </div>
  );
}

// ====================================================================
// === TRUST HERO CARD ===
// Крупный IP-score ring + delta 30 дней + уровень + breakdown 6 осей
// ====================================================================
function TrustHeroCard({
  loading,
  hero,
  greeting,
  firstName,
  level,
  onShowEvidence,
}: {
  loading: boolean;
  hero?: TrustHero;
  greeting: string;
  firstName: string;
  level: string;
  onShowEvidence: () => void;
}) {
  const score = hero?.score ?? 0;
  const delta = hero?.delta30days ?? null;
  const coveragePct = hero?.evidenceCoverage != null
    ? Math.round(hero.evidenceCoverage * 100)
    : null;

  return (
    <Card className="lighthouse-gradient-soft border-lighthouse/20 overflow-hidden">
      <CardContent className="p-6">
        {/* Заголовок секции */}
        <div className="flex items-center justify-between gap-2 mb-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-lighthouse" />
              {greeting}, {firstName}
            </div>
            <h1 className="text-xl font-extrabold mt-0.5 leading-tight">
              Ваша профессиональная правда
            </h1>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center gap-6 flex-wrap">
            <Skeleton className="w-[120px] h-[120px] rounded-full" />
            <div className="flex-1 min-w-0 space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-8 w-40" />
              <Skeleton className="h-3 w-48" />
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-6 flex-wrap">
            {/* IP-score ring (из существующего trust-badge.tsx) */}
            <div className="flex-shrink-0">
              <IpScoreRing ipScore={score} size={120} />
            </div>

            {/* Score + level + delta */}
            <div className="flex-1 min-w-0">
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                Ваш индекс доверия
              </div>
              <div className="flex items-baseline gap-3 flex-wrap">
                <span className="text-5xl font-extrabold leading-none tabular-nums">
                  {score}
                </span>
                <span className="text-sm text-muted-foreground">/ 100</span>
                <TrustBadge ipScore={score} level={level} size="md" className="ml-1" />

                {/* Дельта за 30 дней */}
                {delta !== null && delta !== 0 && (
                  <span
                    className={cn(
                      'inline-flex items-center gap-0.5 text-sm font-medium',
                      delta > 0
                        ? 'text-emerald-600 dark:text-emerald-500'
                        : 'text-red-600 dark:text-red-500',
                    )}
                  >
                    {delta > 0 ? (
                      <ArrowUp className="w-3.5 h-3.5" />
                    ) : (
                      <ArrowDown className="w-3.5 h-3.5" />
                    )}
                    {delta > 0 ? '+' : ''}{delta} за 30 дней
                  </span>
                )}
              </div>

              {/* Evidence coverage */}
              {coveragePct !== null && (
                <div className="mt-2 text-sm">
                  <span className="font-semibold">{coveragePct}%</span>
                  <span className="text-muted-foreground"> утверждений подтверждено</span>
                </div>
              )}

              {/* CTA: PROVE IT */}
              <div className="mt-3 flex items-center gap-2 flex-wrap">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 text-xs"
                  onClick={onShowEvidence}
                >
                  <ShieldCheck className="w-3 h-3 mr-1" />
                  Почему такой IP-score?
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* === Breakdown — 6 осей === */}
        <div className="mt-5 pt-4 border-t border-lighthouse/15">
          <div className="flex items-center gap-1.5 mb-3 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
            <Layers className="w-3 h-3 text-lighthouse" />
            Breakdown
          </div>
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-1.5">
                  <Skeleton className="h-3 w-20" />
                  <Skeleton className="h-1.5 w-full" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {BREAKDOWN_AXES.map((axis) => {
                const value = hero?.breakdown?.[axis.key] ?? 0;
                return (
                  <div key={axis.key} title={axis.hint}>
                    <div className="flex items-baseline justify-between mb-1">
                      <span className="text-xs text-muted-foreground truncate">
                        {axis.label}
                      </span>
                      <span className="text-xs font-semibold tabular-nums">
                        {value}
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className={cn(
                          'h-full rounded-full transition-all duration-500',
                          breakdownColor(value),
                        )}
                        style={{ width: `${Math.max(2, Math.min(100, value))}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ====================================================================
// === ЧТО ИЗМЕНИЛОСЬ ===
// Последние 5 ReputationEvent с типом и +Trust
// ====================================================================
function RecentEventsCard({
  loading,
  events,
}: {
  loading: boolean;
  events: RecentEvent[];
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-600/10 flex items-center justify-center">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-500" />
            </div>
            <div>
              <div className="text-sm font-semibold">Что изменилось</div>
              <div className="text-xs text-muted-foreground">Последние подтверждённые действия</div>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-2">
                <Skeleton className="w-4 h-4 rounded" />
                <Skeleton className="flex-1 h-3" />
                <Skeleton className="w-12 h-3" />
              </div>
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="text-xs text-muted-foreground text-center py-6">
            Пока нет подтверждённых действий.
            <br />
            Завершите проект или попросите коллегу подтвердить навык — и здесь появятся ваши достижения.
          </div>
        ) : (
          <div className="space-y-1">
            {events.map((ev) => {
              const icon = EVENT_ICON[ev.eventType] ?? <Star className="w-4 h-4" />;
              return (
                <div
                  key={ev.id}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition group"
                >
                  <span className="flex-shrink-0 text-emerald-600 dark:text-emerald-500">
                    {icon}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate">
                      <span className="font-medium">{ev.labelRu}</span>
                      {ev.contextName && (
                        <span className="text-muted-foreground"> · {ev.contextName}</span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatRelativeTime(ev.createdAt)}
                    </div>
                  </div>
                  {ev.isStar ? (
                    <span className="flex-shrink-0 inline-flex items-center gap-0.5 text-xs font-semibold text-amber-600 dark:text-amber-500">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    </span>
                  ) : ev.deltaTrust !== null ? (
                    <span className="flex-shrink-0 inline-flex items-center gap-0.5 text-xs font-semibold text-emerald-600 dark:text-emerald-500 tabular-nums">
                      <ArrowUp className="w-3 h-3" />
                      +{ev.deltaTrust} Trust
                    </span>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ====================================================================
// === BIZON AI INSIGHT (заглушка до P0-10) ===
// ====================================================================
function AiInsightCard() {
  return (
    <Card className="border-lighthouse/30 bg-gradient-to-br from-lighthouse/5 to-transparent">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg lighthouse-gradient flex items-center justify-center">
              <Lightbulb className="w-3.5 h-3.5 text-white" />
            </div>
            <div>
              <div className="text-sm font-semibold">BIZON AI Insight</div>
              <div className="text-xs text-muted-foreground">Анализ вашей правды</div>
            </div>
          </div>
          <span className="inline-flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
            <Lock className="w-2.5 h-2.5" />
            В разработке
          </span>
        </div>

        {/* Заглушка: «скоро» */}
        <div className="relative overflow-hidden rounded-lg bg-muted/40 border border-dashed border-muted-foreground/25 p-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-lighthouse/15 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-4 h-4 text-lighthouse" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium mb-1">
                BIZON AI Insight — в разработке
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                AI будет еженедельно анализировать вашу правду, находить слепые зоны
                и подсказывать, где вы недооцениваете свои сильные стороны.
                Например: «Вы недооцениваете свою способность управлять сложными проектами».
              </p>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 mt-2 text-xs text-muted-foreground"
                disabled
                title="Функция в разработке — дрилл-даун доказательств появится вместе с инсайтами"
              >
                Показать доказательства
                <ChevronRight className="w-3 h-3 ml-0.5" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ====================================================================
// === ВОЗМОЖНОСТИ ===
// 3 счётчика: проекты / вакансии / интро
// ====================================================================
function OpportunitiesCard({
  loading,
  opps,
  onProjects,
  onJobs,
  onIntros,
}: {
  loading: boolean;
  opps?: Opportunities;
  onProjects: () => void;
  onJobs: () => void;
  onIntros: () => void;
}) {
  const projectsCount = opps?.projectsCount ?? 0;
  const jobsCount = opps?.jobsCount ?? 0;
  const introCount = opps?.introCount ?? 0;

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center">
            <Target className="w-3.5 h-3.5 text-lighthouse" />
          </div>
          <div>
            <div className="text-sm font-semibold">Возможности</div>
            <div className="text-xs text-muted-foreground">Подобраны под ваш профиль</div>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-3 gap-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="text-center p-3 rounded-lg bg-muted/40">
                <Skeleton className="h-6 w-10 mx-auto mb-1.5" />
                <Skeleton className="h-3 w-16 mx-auto" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-3">
            <OpportunityCard
              icon={<FolderKanban className="w-4 h-4" />}
              count={projectsCount}
              label={pluralize(projectsCount, 'проект', 'проекта', 'проектов')}
              hint="Ищут команду"
              onClick={onProjects}
              accent="text-lighthouse"
            />
            <OpportunityCard
              icon={<Briefcase className="w-4 h-4" />}
              count={jobsCount}
              label={pluralize(jobsCount, 'вакансия', 'вакансии', 'вакансий')}
              hint="Match ≥ 70%"
              onClick={onJobs}
              accent="text-emerald-600 dark:text-emerald-500"
            />
            <OpportunityCard
              icon={<UserPlus className="w-4 h-4" />}
              count={introCount}
              label={pluralize(introCount, 'интро', 'интро', 'интро')}
              hint="За 30 дней"
              onClick={onIntros}
              accent="text-amber-600 dark:text-amber-500"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function OpportunityCard({
  icon, count, label, hint, onClick, accent,
}: {
  icon: React.ReactNode;
  count: number;
  label: string;
  hint: string;
  onClick: () => void;
  accent: string;
}) {
  const isClickable = count > 0;
  return (
    <button
      onClick={isClickable ? onClick : undefined}
      disabled={!isClickable}
      className={cn(
        'text-left p-3 rounded-lg border transition group',
        isClickable
          ? 'border-transparent hover:border-lighthouse/30 hover:bg-accent cursor-pointer'
          : 'border-transparent opacity-60 cursor-default',
      )}
    >
      <div className={cn('flex items-center gap-1.5 mb-1', accent)}>
        {icon}
        <span className="text-xs uppercase tracking-wider font-semibold">{hint}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-bold tabular-nums leading-none">{count}</span>
      </div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
    </button>
  );
}

// ====================================================================
// === ДЕЛЬТА С ПОСЛЕДНЕГО ВИЗИТА (старый синий блок — без заглушек) ===
// ====================================================================
function DeltaSinceVisitCard({
  loading, data, inquiriesCount, onInquiries,
  onMessages, onFeed, onNetwork, onProjects, onMe,
}: {
  loading: boolean;
  data: WhatsNewData | null;
  inquiriesCount: number;
  onInquiries: () => void;
  onMessages: () => void;
  onFeed: () => void;
  onNetwork: () => void;
  onProjects: () => void;
  onMe: () => void;
}) {
  return (
    <Card className="bg-gradient-to-br from-[#1e3a8a] to-[#2563eb] text-white border-[#1e3a8a]/30 shadow-lg">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div>
            <div className="text-xs uppercase tracking-wider text-white/70 font-semibold mb-0.5">
              Что изменилось
            </div>
            <div className="text-lg font-bold">С вашего визита</div>
          </div>
          <div className="text-xs text-white/60">
            {data ? (
              <>
                с{' '}
                {data.lastVisitAt
                  ? new Date(data.lastVisitAt).toLocaleDateString('ru-RU', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'за неделю'}
              </>
            ) : (
              '—'
            )}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white/10 rounded-lg p-3">
                <Skeleton className="h-3 w-12 bg-white/20 mb-2" />
                <Skeleton className="h-6 w-16 bg-white/20" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <DeltaCard
              icon={<MessageSquare className="w-4 h-4" />}
              label="Сообщения"
              value={data?.deltas.messages ?? 0}
              onClick={onMessages}
            />
            <DeltaCard
              icon={<MessageCircle className="w-4 h-4" />}
              label="Ответы на статьи"
              value={data?.deltas.commentsOnOwnPosts ?? 0}
              onClick={onFeed}
            />
            <DeltaCard
              icon={<ShieldCheck className="w-4 h-4" />}
              label="Подтверждения"
              value={data?.deltas.confirmations ?? 0}
              onClick={onNetwork}
            />
            <DeltaCard
              icon={<FolderKanban className="w-4 h-4" />}
              label="Приглашения в проекты"
              value={data?.deltas.projectInvites ?? 0}
              onClick={onProjects}
            />
            <DeltaCard
              icon={<MessageCircleHeart className="w-4 h-4" />}
              label="Запросы от коллег"
              value={inquiriesCount}
              onClick={onInquiries}
              highlight={inquiriesCount > 0}
            />
            <DeltaCard
              icon={<TrendingUp className="w-4 h-4" />}
              label="Trust State"
              value={data?.deltas.trustDelta ?? 0}
              isDelta
              onClick={onMe}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// DeltaCard — карточка одной категории дельты в синем блоке
function DeltaCard({
  icon, label, value, isDelta, highlight, onClick,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  isDelta?: boolean;
  highlight?: boolean;
  onClick?: () => void;
}) {
  const display = isDelta
    ? (value > 0 ? `+${value}` : value === 0 ? '0' : `${value}`)
    : String(value);

  const isPositive = isDelta ? value > 0 : value > 0;
  const isNegative = isDelta ? value < 0 : false;
  const isClickable = !!onClick && (isDelta ? true : value > 0);

  return (
    <button
      onClick={isClickable ? onClick : undefined}
      disabled={!isClickable}
      className={cn(
        'text-left bg-white/10 rounded-lg p-3 transition group',
        isClickable && 'hover:bg-white/15',
        highlight && 'bg-amber-400/20 ring-2 ring-amber-300/50',
      )}
      title={label}
    >
      <div className="flex items-center gap-1.5 mb-1.5 text-white/70">
        <span className="shrink-0">{icon}</span>
        <span className="text-xs uppercase tracking-wider truncate font-medium">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span
          className={cn(
            'text-2xl font-bold tabular-nums leading-none',
            isDelta && isPositive && 'text-emerald-300',
            isDelta && isNegative && 'text-red-300',
            !isDelta && !isPositive && 'text-white/60',
            highlight && 'text-amber-200',
          )}
        >
          {display}
        </span>
        {isDelta && isPositive && <ArrowUp className="w-3 h-3 text-emerald-300" />}
        {isDelta && isNegative && <ArrowDown className="w-3 h-3 text-red-300" />}
        {!isDelta && <span className="text-xs text-white/60">новых</span>}
      </div>
    </button>
  );
}
