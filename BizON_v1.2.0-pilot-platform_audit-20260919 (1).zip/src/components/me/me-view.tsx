// BizON — MeView (раздел «Я» с 5 табами)
// Этап 3.1 — UX-NAV: первый экран при входе = Tab «Что нового»
//
// Структура:
//   Tab 1 «Что нового»    — P0-1 Professional Truth Dashboard: IP-score + delta +
//                          level + последние 5 действий + возможности (без заглушек)
//   Tab 2 «Моё лицо»      — Public Persona (текущий ProfileView)
//   Tab 3 «Анализ»        — Private Truth: IP, Truth Gap, blind spots (текущий TruthProfile)
//   Tab 4 «Действия»      — Actions Timeline (R10)
//   Tab 5 «Редактировать» — текущий SettingsView
//
// Этап 6.4 ONB-10: Progressive Disclosure — пока onboardingStep < 3, скрываем
// продвинутые функции (Cultural Signals, Career Compass, EDU Recommendations).
'use client';

import * as React from 'react';
import { useAppStore } from '@/stores/app-store';
import type { UserPublic } from '@/lib/types';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { WhatsNewTab } from './whats-new-tab';
import { ActionsTimelineTab } from './actions-timeline-tab';
import { ProfileView } from '@/components/profile/profile-view';
import { TruthProfile } from '@/components/truth/truth-profile';
import { SettingsView } from '@/components/settings/settings-view';
// P0-2: Explainable Trust — карточка объяснения Trust вверху «Анализ»
import { TrustExplainCard } from '@/components/truth/trust-explain-card';
// Этап 5.3 — CV блок: Карьерный компас
import { CareerCompass } from '@/components/cv/career-compass';
// Этап 5.5 — EDU: рекомендации курсов по Truth Gap
import { EduRecommendations } from '@/components/edu/edu-recommendations';
// P0-3 — Evidence Graph: визуализация claim → project → skill → confirmer → result → trust
import { EvidenceGraph } from '@/components/truth/evidence-graph';
// Phase 5 — Skill Graph: explainable вектор навыков с decay и resurrection
import { SkillGraphView } from '@/components/truth/skill-graph-view';
// Этап 6.4 ONB-10: блок-заглушка для скрытых функций
import { Card, CardContent } from '@/components/ui/card';
// v6.0 — AI-Коуч и Капитал: 8 компонентов Professional Capital, вопрос дня,
// инсайты и профессиональная память (таймлайн того, что AI знает о вас)
import { CapitalDashboard } from './capital-dashboard';
import { BizonCoachCard } from './bizon-coach-card';
import { ProfessionalMemory } from './professional-memory';
// 9-c (doc_a §61 п.26): дайджест «Пока вас не было» — whats-new + profile-views + signals,
// детерминированная сборка без LLM; сворачиваемый
import { WhileYouWereAwayDigest } from '@/components/who-viewed/while-you-were-away-digest';
// 9-c (doc_a §61 п.24): Who Viewed — «Вас смотрели» на /api/me/profile-views
import { WhoViewedCard } from '@/components/who-viewed/who-viewed-card';
// 9-c (doc_a §37): Skill Futures UI — «Ваши траектории» на /api/me/skill-futures
import { SkillFuturesPanel } from '@/components/skill-futures/skill-futures-panel';
// 10-a (doc_a §58): «Ваши сценарии» — дефицитность профиля, сценарии × горизонты
import { TalentForecastScenariosCard } from '@/components/intelligence/talent-forecast-scenarios-card';
// 10-a (doc_a §55): «Что на вас работает» — гипотезы причинности с честными ярлыками
import { CausalityCard } from '@/components/intelligence/causality-card';
import {
  UserCircle, Activity, Settings, Lock, Microscope, Sparkles, Brain,
  BrainCircuit,
} from 'lucide-react';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';

// TODO(11-a): onboardingStep отсутствует в UserPublic ('@/lib/types') — локальное расширение,
// удалить после добавления поля в общий тип.
type MeViewUser = UserPublic & { onboardingStep?: number | null };

export function MeView() {
  const user = useAppStore((s) => s.user) as MeViewUser | null;
  // P0-1: Таб по умолчанию = «Что нового» (Professional Truth Dashboard — минимум)
  const [tab, setTab] = React.useState('whats-new');

  // ONB-10: если onboardingStep < 3 — продвинутые функции скрыты
  const onboardingStep = user?.onboardingStep ?? 0;
  const advancedUnlocked = onboardingStep >= 3;

  return (
    <div className="space-y-4">
      <Tabs value={tab} onValueChange={setTab} className="w-full">
        {/* Заголовок раздела «Я» — компактный, чтобы не занимать много места */}
        <div className="flex items-baseline justify-between flex-wrap gap-2 mb-1">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <UserCircle className="w-6 h-6 text-lighthouse" />
              Я
            </h1>
            <p className="text-sm text-muted-foreground">
              Ваш профиль, правда и действия
            </p>
          </div>
        </div>

        {/* Список табов */}
        <TabsList className="w-full justify-start overflow-x-auto scroll-area-thin h-auto flex-wrap sm:flex-nowrap">
          <TabsTrigger value="whats-new" className="gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Что нового
            <TermInfo k="insights" />
          </TabsTrigger>
          <TabsTrigger value="persona" className="gap-1.5">
            <UserCircle className="w-3.5 h-3.5" />
            Моё лицо
          </TabsTrigger>
          <TabsTrigger value="truth" className="gap-1.5">
            <Microscope className="w-3.5 h-3.5" />
            Анализ
          </TabsTrigger>
          <TabsTrigger value="skills" className="gap-1.5">
            <Brain className="w-3.5 h-3.5" />
            Мои навыки
          </TabsTrigger>
          <TabsTrigger value="ai-coach" className="gap-1.5">
            <BrainCircuit className="w-3.5 h-3.5" />
            AI-Коуч и Капитал
          </TabsTrigger>
          <TabsTrigger value="actions" className="gap-1.5">
            <Activity className="w-3.5 h-3.5" />
            Действия
          </TabsTrigger>
          <TabsTrigger value="edit" className="gap-1.5">
            <Settings className="w-3.5 h-3.5" />
            Редактировать
          </TabsTrigger>
        </TabsList>

        {/* === TAB 1: Что нового (Professional Truth Dashboard — P0-1 минимум) ===
            9-c: аддитивно сверху — дайджест «Пока вас не было» (§61 п.26),
            снизу — «Вас смотрели» (§61 п.24) и «Ваши траектории» (§37)
            10-a: аддитивно в конце — «Ваши сценарии» (§58) и
            «Что на вас работает» (§55) — вкладка «Я» */}
        <TabsContent value="whats-new">
          <div className="space-y-4">
            <WhileYouWereAwayDigest />
            <WhatsNewTab />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
              <WhoViewedCard />
              <SkillFuturesPanel />
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
              <TalentForecastScenariosCard />
              <CausalityCard />
            </div>
          </div>
        </TabsContent>

        {/* === TAB 2: Моё лицо (Public Persona) === */}
        <TabsContent value="persona">
          <ProfileView />
        </TabsContent>

        {/* === TAB 3: Анализ (Private Truth — подробный разбор) ===
            ONB-10: Cultural Signals / Career Compass / EDU — скрыты пока onboardingStep < 3 */}
        <TabsContent value="truth">
          {/* P0-2: Explainable Trust — крупный score + breakdown по 6 категориям */}
          <TrustExplainCard className="mb-6" />
          <TruthProfile />
          {/* P0-3 — Evidence Graph: визуализация claim → project → skill → confirmer → result → trust */}
          <div className="mt-6">
            <EvidenceGraph />
          </div>
          {advancedUnlocked ? (
            <>
              {/* Этап 5.3 — Карьерный компас внутри «Анализ» */}
              <div className="mt-6">
                <CareerCompass />
              </div>
              {/* Этап 5.5 — EDU: блок «Что изучить?» по слабым навыкам (Truth Gap) */}
              <div className="mt-6">
                <EduRecommendations />
              </div>
            </>
          ) : (
            <div className="mt-6">
              <Card className="border-dashed border-muted-foreground/30 bg-muted/10">
                <CardContent className="p-6 text-center">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
                    <Lock className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div className="text-sm font-medium">
                    Продвинутые функции — Cultural Signals, Карьерный компас, EDU
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed max-w-md mx-auto">
                    Эти функции откроются после завершения 3 шагов онбординга.
                    Продолжите онбординг, чтобы получить доступ к карьерным подсказкам AI
                    и рекомендациям курсов по вашим слабым навыкам.
                  </p>
                  <div className="text-xs text-muted-foreground mt-3 tabular-nums">
                    Прогресс: {onboardingStep} из 5 шагов
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        {/* === TAB: AI-Коуч и Капитал (v6.0 — Professional Capital + Bizon Coach + Memory) === */}
        <TabsContent value="ai-coach">
          <div className="space-y-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <BrainCircuit className="w-6 h-6 text-lighthouse" />
                AI-Коуч и Капитал
              </h1>
              <p className="text-sm text-muted-foreground">
                Восемь доказуемых компонентов капитала, вопрос дня и память AI — всё объяснимо.
              </p>
            </div>
            <CapitalDashboard />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
              <BizonCoachCard />
              <ProfessionalMemory />
            </div>
          </div>
        </TabsContent>

        {/* === TAB 4: Действия (Actions Timeline) — R10 === */}
        <TabsContent value="actions">
          <ActionsTimelineTab />
        </TabsContent>

        {/* === TAB: Мои навыки (Phase 5 — Skill Graph) === */}
        <TabsContent value="skills">
          <div className="space-y-4">
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Brain className="w-6 h-6 text-lighthouse" />
                Мои навыки
              </h1>
              <p className="text-sm text-muted-foreground">
                Explainable вектор уровней (1–10) с decay-индикаторами и маршрутами восстановления.
              </p>
            </div>
            <SkillGraphView />
          </div>
        </TabsContent>

        {/* === TAB 5: Редактировать === */}
        <TabsContent value="edit">
          <SettingsView />
        </TabsContent>
      </Tabs>
    </div>
  );
}
