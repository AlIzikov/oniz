// BizON v6 — BizonCoachCard (AI-коуч)
// «Вопрос дня» + ответы + подтверждаемые инсайты.
//
// Источники:
//   GET   /api/me/coach/daily-question     → { question }        (вопрос дня, детерминированный)
//   POST  /api/me/coach/answer             → { ok, question }    (ответ + follow-up коуча)
//   GET   /api/me/coach/insights           → { insights }        (гипотезы AI)
//   POST  /api/me/coach/discover           → { insights }        (поиск скрытого потенциала, ТЗ doc_agents стр. 33-41)
//   PATCH /api/me/coach/insights/[id]      → { ok, insight }     (подтвердить/отклонить/пропустить)
//
// ТЗ doc_agents «Помогите нам понять вас лучше» (BIZON LEARNS YOU):
//   - заголовок виджета при наличии new-инсайтов: «💡 Помогите нам понять вас лучше»;
//   - карточки-гипотезы показываются ПО ОДНОЙ, после ответа подгружается следующая
//     (максимум 3 за открытие виджета);
//   - третья кнопка «Пропустить» (link-стиль внизу карточки) — статус инсайта не меняет;
//   - при монтировании, если new-инсайтов нет, вызывается POST /discover (один раз, без зацикливания);
//   - после подтверждения показывается блок «Что делать дальше: …» (recommendationAction).
//
// Принцип v6: AI не решает за пользователя — Coach предлагает, человек подтверждает.
//
// Дизайн (спокойный, доверие): тёмно-синий (navy) текст, teal (lighthouse)
// акценты, amber — ТОЛЬКО кнопка «Ответить». Синий-500/indigo-500 не используются.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/hooks/use-toast';
import {
  MessageCircleQuestion, Lightbulb, Send, Loader2, Lock, AlertCircle,
  RefreshCw, Check, X, Sparkles,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================
// === Типы данных ===
// ============================================================

interface CoachQuestion {
  id: string;
  question: string;
  category: string; // career | skills | projects | goals
  answer: string | null;
  answeredAt: string | null;
  followUp: string | null;
  createdAt: string;
}

interface CoachInsight {
  id: string;
  title: string;
  content: string;
  category: string;              // potential | blind_spot | opportunity (legacy)
  insightType?: string | null;   // ТЗ doc_agents: career_shift | hidden_talent | fear_of_public | …
  recommendationAction?: string | null; // ТЗ doc_agents: «что делать дальше»
  status: string;                // new | confirmed | dismissed | done
  confidence: number;
  sourceData?: string | null;    // JSON: причина гипотезы + skipped-флаг
  createdAt: string;
  confirmedAt?: string | null;
}

/** Инсайт в представлении карточки: skipped распарсен из sourceData */
interface CoachInsightView extends CoachInsight {
  skipped: boolean;
}

const CATEGORY_LABEL: Record<string, string> = {
  career: 'Карьера',
  skills: 'Навыки',
  projects: 'Проекты',
  goals: 'Цели',
};

const INSIGHT_CATEGORY: Record<string, { label: string; className: string }> = {
  potential:   { label: 'Потенциал',   className: 'bg-lighthouse/10 text-lighthouse border-lighthouse/30' },
  blind_spot:  { label: 'Слепая зона', className: 'bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/30' },
  opportunity: { label: 'Возможность', className: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30' },
};

/** Новые типы гипотез из ТЗ doc_agents */
const INSIGHT_TYPE_LABEL: Record<string, string> = {
  career_shift: 'Смена профессии',
  hidden_talent: 'Скрытый талант',
  fear_of_public: 'Страх публичности',
};

const STATUS_LABEL: Record<string, string> = {
  new: 'Новый',
  confirmed: 'Подтверждён',
  dismissed: 'Отклонён',
  done: 'Обработан',
};

/** Лимит ТЗ doc_agents: максимум 3 гипотезы за одно открытие виджета */
const MAX_CARDS_PER_SESSION = 3;

// ============================================================
// === Утилиты ===
// ============================================================

const isAuthError = (e: unknown) => e instanceof Error && /не авторизован/i.test(e.message);

/** sourceData.skipped — инсайт пропущен («Пропустить вопрос»), показывать его больше не нужно */
function isSkippedSource(sourceData: string | null | undefined): boolean {
  if (!sourceData) return false;
  try {
    const parsed: unknown = JSON.parse(sourceData);
    return typeof parsed === 'object' && parsed !== null && (parsed as { skipped?: unknown }).skipped === true;
  } catch {
    return false;
  }
}

// ============================================================
// === Скелетон ===
// ============================================================

function CoachSkeleton() {
  return (
    <Card aria-label="BizON Коуч — загрузка">
      <CardHeader>
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-4 w-72 max-w-full" />
      </CardHeader>
      <CardContent className="space-y-4">
        <Skeleton className="h-5 w-28" />
        <Skeleton className="h-14 w-full" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-9 w-32" />
      </CardContent>
    </Card>
  );
}

function LoginRequired() {
  return (
    <Card className="border-dashed">
      <CardContent className="py-10 text-center">
        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
          <Lock className="w-6 h-6 text-muted-foreground" aria-hidden="true" />
        </div>
        <div className="font-medium">Войдите, чтобы говорить с AI-коучем</div>
        <p className="text-sm text-muted-foreground mt-1">
          Вопрос дня и инсайты строятся на ваших доказательствах.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================
// === Основной компонент ===
// ============================================================

export function BizonCoachCard() {
  const { user } = useAppStore();

  const [question, setQuestion] = React.useState<CoachQuestion | null>(null);
  const [insights, setInsights] = React.useState<CoachInsight[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [authRequired, setAuthRequired] = React.useState(false);

  const [answer, setAnswer] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);
  const [busyInsightId, setBusyInsightId] = React.useState<string | null>(null);

  // ТЗ doc_agents: показ гипотез — по одной, максимум 3 за открытие виджета
  const [shownCount, setShownCount] = React.useState(0);
  const [discovering, setDiscovering] = React.useState(false);
  const discoverAttemptedRef = React.useRef(false);
  const discoveringRef = React.useRef(false);

  const load = React.useCallback(async () => {
    if (!user) { setAuthRequired(true); setLoading(false); return; }
    setLoading(true);
    setError(null);
    try {
      const [q, i] = await Promise.all([
        api<{ question: CoachQuestion }>('/api/me/coach/daily-question'),
        api<{ insights: CoachInsight[] }>('/api/me/coach/insights'),
      ]);
      setQuestion(q.question ?? null);
      setInsights(i.insights ?? []);
      setAuthRequired(false);
      if (q.question?.answer) setAnswer(q.question.answer);
    } catch (e) {
      if (isAuthError(e)) setAuthRequired(true);
      else setError(e instanceof Error ? e.message : 'Не удалось загрузить коуча');
    } finally {
      setLoading(false);
    }
  }, [user]);

  React.useEffect(() => { load(); }, [load]);

  /**
   * POST /api/me/coach/discover — единственный источник новых гипотез.
   * Вызывается не чаще одного раза за открытие виджета (guard по ref) — без зацикливания.
   */
  const runDiscover = React.useCallback(async () => {
    if (discoveringRef.current) return;
    discoveringRef.current = true;
    setDiscovering(true);
    try {
      await api('/api/me/coach/discover', { method: 'POST', body: JSON.stringify({}) });
      const i = await api<{ insights: CoachInsight[] }>('/api/me/coach/insights');
      setInsights(i.insights ?? []);
    } catch (e) {
      if (isAuthError(e)) setAuthRequired(true);
      // тихая деградация: discovery — фоновое обогащение, не ломаем карточку
    } finally {
      discoveringRef.current = false;
      setDiscovering(false);
    }
  }, []);

  /** Ручной запуск поиска гипотез (пустое состояние) — не превышая лимит сессии */
  const handleManualDiscover = React.useCallback(() => {
    if (shownCount >= MAX_CARDS_PER_SESSION) return;
    discoverAttemptedRef.current = false;
    void runDiscover();
  }, [runDiscover, shownCount]);

  // Ответ на вопрос дня
  const submitAnswer = async () => {
    if (!question || !answer.trim()) return;
    setSubmitting(true);
    try {
      const res = await api<{ ok: boolean; question?: CoachQuestion; error?: string }>(
        '/api/me/coach/answer',
        { method: 'POST', body: JSON.stringify({ questionId: question.id, answer: answer.trim() }) },
      );
      if (!res.ok || !res.question) {
        toast({ title: 'Не удалось сохранить ответ', description: res.error ?? 'Попробуйте ещё раз', variant: 'destructive' });
        return;
      }
      setQuestion(res.question);
      toast({ title: 'Ответ сохранён', description: 'Коуч зафиксировал его в профессиональной памяти' });
    } catch (e) {
      if (isAuthError(e)) setAuthRequired(true);
      else toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Попробуйте позже', variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  };

  // Подтверждение / отклонение / пропуск инсайта
  const decideInsight = async (insight: CoachInsight, decision: 'confirm' | 'dismiss' | 'skip') => {
    setBusyInsightId(insight.id);
    try {
      const res = await api<{ ok: boolean; insight?: CoachInsight; error?: string }>(
        `/api/me/coach/insights/${insight.id}`,
        {
          method: 'PATCH',
          // «Пропустить вопрос» (ТЗ): статус не меняется, помечается sourceData.skipped
          body: JSON.stringify(decision === 'skip' ? { status: 'skipped' } : { confirmed: decision === 'confirm' }),
        },
      );
      if (!res.ok || !res.insight) {
        toast({ title: 'Не удалось обновить инсайт', description: res.error ?? 'Попробуйте ещё раз', variant: 'destructive' });
        return;
      }
      const updated = res.insight;
      setInsights((prev) => prev.map((i) => (i.id === insight.id ? { ...i, ...updated } : i)));
      setShownCount((n) => Math.min(n + 1, MAX_CARDS_PER_SESSION)); // карточка отработана — считаем в лимит 3
      if (decision === 'confirm') {
        toast({ title: 'Инсайт подтверждён', description: 'Он усилит ваш нарратив в профессиональной памяти' });
      } else if (decision === 'dismiss') {
        toast({ title: 'Инсайт отклонён', description: 'AI больше не будет предлагать похожее' });
      } else {
        toast({ title: 'Вопрос пропущен', description: 'Мы пока уберём эту гипотезу' });
      }
    } catch (e) {
      if (isAuthError(e)) setAuthRequired(true);
      else toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Попробуйте позже', variant: 'destructive' });
    } finally {
      setBusyInsightId(null);
    }
  };

  // === Производные данные ===
  const viewCards: CoachInsightView[] = React.useMemo(
    () => insights.map((i) => ({ ...i, skipped: isSkippedSource(i.sourceData) })),
    [insights],
  );
  // Очередь гипотез: только new и не пропущенные. Первая — текущая карточка.
  const newCards = viewCards.filter((i) => i.status === 'new' && !i.skipped);
  const historyCards = viewCards.filter((i) => i.status !== 'new');
  const sessionLimitReached = shownCount >= MAX_CARDS_PER_SESSION;
  const currentCard: CoachInsightView | null = !sessionLimitReached ? newCards[0] ?? null : null;
  const hasNew = currentCard !== null;

  // ТЗ doc_agents: при монтировании, если нет new-инсайтов — POST /discover.
  // Один вызов за открытие виджета (guard по ref + лимит сессии) — без зацикливания.
  // После ответа на гипотезу, если очередь пуста, discover подгрузит следующую автоматически.
  React.useEffect(() => {
    if (!user || loading || authRequired || error) return;
    if (hasNew || discovering || sessionLimitReached) return;
    if (discoverAttemptedRef.current) return;
    discoverAttemptedRef.current = true;
    void runDiscover();
  }, [user, loading, authRequired, error, hasNew, discovering, sessionLimitReached, runDiscover]);

  if (authRequired) return <LoginRequired />;
  if (loading) return <CoachSkeleton />;
  if (error) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="py-8 text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-destructive mx-auto" aria-hidden="true" />
          <p className="text-sm text-destructive">{error}</p>
          <Button variant="outline" size="sm" onClick={load} aria-label="Повторить загрузку коуча">
            <RefreshCw className="w-4 h-4 mr-1.5" aria-hidden="true" />
            Повторить
          </Button>
        </CardContent>
      </Card>
    );
  }

  const answered = Boolean(question?.answer);
  const busy = hasNew && busyInsightId === currentCard.id;

  return (
    <Card aria-label="BizON Коуч">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          {hasNew ? (
            <span>💡 Помогите нам понять вас лучше</span>
          ) : (
            <>
              <MessageCircleQuestion className="w-5 h-5 text-lighthouse" aria-hidden="true" />
              BizON Коуч
            </>
          )}
        </CardTitle>
        <CardDescription>
          AI не решает за вас — он задаёт вопросы и предлагает гипотезы. Решаете вы.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* === Вопрос дня === */}
        {question && (
          <section aria-label="Вопрос дня" className="space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline" className="bg-lighthouse/5 text-lighthouse border-lighthouse/30">
                Вопрос дня
              </Badge>
              {CATEGORY_LABEL[question.category] && (
                <Badge variant="secondary" className="text-xs">
                  {CATEGORY_LABEL[question.category]}
                </Badge>
              )}
            </div>

            <p className="text-base font-semibold leading-snug text-[#1e3a8a] dark:text-blue-100">
              «{question.question}»
            </p>

            {answered ? (
              <div className="space-y-3">
                <div className="rounded-lg border border-lighthouse/20 bg-lighthouse/5 p-3 text-sm leading-relaxed whitespace-pre-line">
                  {question.answer}
                </div>
                {question.followUp && (
                  <div className="flex items-start gap-2 rounded-lg border border-lighthouse/20 bg-muted/40 p-3">
                    <Lightbulb className="w-4 h-4 mt-0.5 text-lighthouse flex-shrink-0" aria-hidden="true" />
                    <p className="text-sm text-muted-foreground leading-relaxed">{question.followUp}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <Textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Напишите честно: цифры, проекты, результаты…"
                  className="min-h-[88px] resize-none"
                  aria-label="Ответ на вопрос дня"
                  maxLength={2000}
                />
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground tabular-nums">
                    {answer.length}/2000
                  </span>
                  <Button
                    size="sm"
                    onClick={submitAnswer}
                    disabled={submitting || !answer.trim()}
                    aria-label="Ответить на вопрос дня"
                    className="bg-amber-500 hover:bg-amber-600 text-white"
                  >
                    {submitting
                      ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" aria-hidden="true" />
                      : <Send className="w-4 h-4 mr-1.5" aria-hidden="true" />}
                    Ответить
                  </Button>
                </div>
              </div>
            )}
          </section>
        )}

        {/* === Гипотезы AI (BIZON LEARNS YOU, ТЗ doc_agents) — по одной карточке === */}
        <section aria-label="Инсайты коуча" className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-semibold flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-lighthouse" aria-hidden="true" />
              Инсайты коуча
            </h3>
            {hasNew && (
              <Badge variant="secondary" className="text-xs tabular-nums">
                {Math.min(shownCount + 1, MAX_CARDS_PER_SESSION)} из {MAX_CARDS_PER_SESSION}
              </Badge>
            )}
          </div>

          {currentCard ? (
            (() => {
              const cat = INSIGHT_CATEGORY[currentCard.category];
              const typeLabel = currentCard.insightType ? INSIGHT_TYPE_LABEL[currentCard.insightType] : undefined;
              return (
                <div
                  className="rounded-lg border border-lighthouse/30 bg-lighthouse/5 p-3 space-y-2"
                  aria-label={`Гипотеза AI: ${currentCard.title}`}
                >
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <span className="text-sm font-medium leading-snug">{currentCard.title}</span>
                    <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap">
                      {typeLabel && (
                        <Badge variant="outline" className="text-xs border-lighthouse/40 text-lighthouse bg-lighthouse/5">
                          {typeLabel}
                        </Badge>
                      )}
                      <Badge variant="outline" className={cn('text-xs', cat?.className)}>
                        {cat?.label ?? currentCard.category} · {Math.round(currentCard.confidence * 100)}%
                      </Badge>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{currentCard.content}</p>
                  <div className="flex items-center gap-2 pt-1">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={busy}
                      onClick={() => decideInsight(currentCard, 'confirm')}
                      aria-label={`Подтвердить инсайт: ${currentCard.title}`}
                      className="h-7 border-lighthouse/40 text-lighthouse hover:bg-lighthouse/10 hover:text-lighthouse"
                    >
                      {busy
                        ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" aria-hidden="true" />
                        : <Check className="w-3.5 h-3.5 mr-1" aria-hidden="true" />}
                      Подтвердить
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={busy}
                      onClick={() => decideInsight(currentCard, 'dismiss')}
                      aria-label={`Отклонить инсайт: ${currentCard.title}`}
                      className="h-7 text-muted-foreground"
                    >
                      <X className="w-3.5 h-3.5 mr-1" aria-hidden="true" />
                      Отклонить
                    </Button>
                  </div>
                  {/* «Пропустить вопрос» (ТЗ doc_agents) — link-стиль внизу карточки */}
                  <div className="flex justify-end pt-0.5">
                    <Button
                      variant="link"
                      size="sm"
                      disabled={busy}
                      onClick={() => decideInsight(currentCard, 'skip')}
                      aria-label={`Пропустить вопрос: ${currentCard.title}`}
                      className="h-auto p-0 text-xs text-muted-foreground hover:text-foreground"
                    >
                      Пропустить
                    </Button>
                  </div>
                </div>
              );
            })()
          ) : discovering ? (
            <div className="flex items-center gap-2 rounded-lg border border-dashed p-4 text-sm text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin text-lighthouse flex-shrink-0" aria-hidden="true" />
              AI изучает ваш профиль и ищет скрытый потенциал…
            </div>
          ) : sessionLimitReached ? (
            <p className="text-sm text-muted-foreground rounded-lg border border-dashed p-4 text-center">
              Это все гипотезы на сегодня — максимум {MAX_CARDS_PER_SESSION} за раз. Заглядывайте завтра.
            </p>
          ) : (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground rounded-lg border border-dashed p-4 text-center">
                Инсайтов пока нет. Они появятся, когда AI заметит скрытый потенциал в вашем профиле.
                Если вы недавно отклоняли гипотезы — новые появятся через несколько дней.
              </p>
              <div className="flex justify-center">
                <Button
                  variant="link"
                  size="sm"
                  onClick={handleManualDiscover}
                  aria-label="Запустить поиск гипотез"
                  className="h-auto p-0 text-xs"
                >
                  <Sparkles className="w-3.5 h-3.5 mr-1" aria-hidden="true" />
                  Искать гипотезы
                </Button>
              </div>
            </div>
          )}

          {/* === Прошлые гипотезы (история) === */}
          {historyCards.length > 0 && (
            <div className="space-y-2 pt-1">
              <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Прошлые гипотезы
              </h4>
              <ul className="space-y-2">
                {historyCards.map((insight) => {
                  const cat = INSIGHT_CATEGORY[insight.category];
                  const confirmed = insight.status === 'confirmed';
                  return (
                    <li
                      key={insight.id}
                      className={cn(
                        'rounded-lg border p-3 space-y-2',
                        confirmed && 'border-lighthouse/40 bg-lighthouse/5',
                        insight.status === 'dismissed' && 'opacity-60',
                      )}
                    >
                      <div className="flex items-start justify-between gap-2 flex-wrap">
                        <span className="text-sm font-medium leading-snug">{insight.title}</span>
                        <Badge
                          variant="outline"
                          className={cn('text-xs flex-shrink-0', cat?.className)}
                        >
                          {cat?.label ?? insight.category} · {Math.round(insight.confidence * 100)}%
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{insight.content}</p>
                      {confirmed ? (
                        <>
                          {/* ТЗ doc_agents: после подтверждения — блок «Что делать дальше» */}
                          {insight.recommendationAction && (
                            <div className="flex items-start gap-2 rounded-lg border border-lighthouse/20 bg-muted/40 p-2.5">
                              <Lightbulb className="w-4 h-4 mt-0.5 text-lighthouse flex-shrink-0" aria-hidden="true" />
                              <p className="text-xs leading-relaxed">
                                <span className="font-medium">Что делать дальше:</span>{' '}
                                {insight.recommendationAction}
                              </p>
                            </div>
                          )}
                          <Badge variant="default" className="text-xs">
                            {STATUS_LABEL[insight.status] ?? insight.status}
                          </Badge>
                        </>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          {STATUS_LABEL[insight.status] ?? insight.status}
                        </Badge>
                      )}
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </section>
      </CardContent>
    </Card>
  );
}
