// BizON v6 — ProfessionalMemory (Профессиональная память)
// Таймлайн версий нарратива: что AI знает о пользователе и как это менялось.
//
// Источник: GET /api/me/memory → { narrative, evolution }
//   narrative — текущая версия нарратива (ProfessionalNarrative);
//   evolution — история версий: { points: [{ date, version, event }],
//               totalVersions, firstVersion }.
//
// Принцип peak-level: нарратив не деградирует — версии только добавляются,
// источник данных сохранён (объяснимость).
//
// UI: таймлайн в скролл-контейнере max-h-96 с кастомным скроллбаром
// (класс .scroll-area-thin из globals.css — teal-палитра).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import {
  Brain, Lock, AlertCircle, RefreshCw, History, GitBranch,
} from 'lucide-react';

// ============================================================
// === Типы данных (/api/me/memory) ===
// ============================================================

interface Narrative {
  id: string;
  narrative: string;
  version: number;
  sourceData: string | null;
  createdAt: string;
}

interface EvolutionPoint {
  date: string;
  version: number;
  event: string;
}

interface Evolution {
  points: EvolutionPoint[];
  totalVersions: number;
  firstVersion: string | null;
}

// ============================================================
// === Утилиты ===
// ============================================================

const isAuthError = (e: unknown) => e instanceof Error && /не авторизован/i.test(e.message);

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('ru-RU', {
      day: 'numeric', month: 'short', year: 'numeric',
    });
  } catch {
    return '';
  }
}

// ============================================================
// === Скелетон ===
// ============================================================

function MemorySkeleton() {
  return (
    <Card aria-label="Профессиональная память — загрузка">
      <CardHeader>
        <Skeleton className="h-6 w-56" />
        <Skeleton className="h-4 w-72 max-w-full" />
      </CardHeader>
      <CardContent className="space-y-3">
        <Skeleton className="h-20 w-full" />
        {[0, 1, 2].map((i) => (
          <div key={i} className="flex gap-3">
            <Skeleton className="h-3 w-3 rounded-full mt-1.5 flex-shrink-0" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-4 w-full" />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function LoginRequired() {
  return (
    <Card className="border-dashed">
      <CardContent className="py-10 text-center">
        <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
          <Lock className="w-6 h-6 text-muted-foreground" aria-hidden="true" />
        </div>
        <div className="font-medium">Войдите, чтобы увидеть профессиональную память</div>
        <p className="text-sm text-muted-foreground mt-1">
          Память строится только из ваших действий и доказательств.
        </p>
      </CardContent>
    </Card>
  );
}

// ============================================================
// === Основной компонент ===
// ============================================================

export function ProfessionalMemory() {
  const { user } = useAppStore();
  const [narrative, setNarrative] = React.useState<Narrative | null>(null);
  const [evolution, setEvolution] = React.useState<Evolution | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [authRequired, setAuthRequired] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!user) { setAuthRequired(true); setLoading(false); return; }
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ narrative: Narrative | null; evolution: Evolution | null }>('/api/me/memory');
      setNarrative(res.narrative ?? null);
      setEvolution(res.evolution ?? null);
      setAuthRequired(false);
    } catch (e) {
      if (isAuthError(e)) setAuthRequired(true);
      else setError(e instanceof Error ? e.message : 'Не удалось загрузить память');
    } finally {
      setLoading(false);
    }
  }, [user]);

  React.useEffect(() => { load(); }, [load]);

  if (authRequired) return <LoginRequired />;
  if (loading) return <MemorySkeleton />;
  if (error) {
    return (
      <Card className="border-destructive/40">
        <CardContent className="py-8 text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-destructive mx-auto" aria-hidden="true" />
          <p className="text-sm text-destructive">{error}</p>
          <Button variant="outline" size="sm" onClick={load} aria-label="Повторить загрузку памяти">
            <RefreshCw className="w-4 h-4 mr-1.5" aria-hidden="true" />
            Повторить
          </Button>
        </CardContent>
      </Card>
    );
  }

  const points = evolution?.points ?? [];
  const totalVersions = evolution?.totalVersions ?? points.length;

  return (
    <Card aria-label="Профессиональная память">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Brain className="w-5 h-5 text-lighthouse" aria-hidden="true" />
          Профессиональная память
        </CardTitle>
        <CardDescription>
          Что AI знает о вас — и как это менялось. Только факты и доказательства, ничего выдуманного.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Текущий нарратив (последняя версия) */}
        {narrative ? (
          <div className="rounded-lg border border-lighthouse/20 bg-lighthouse/5 p-3">
            <div className="flex items-center gap-2 mb-1.5">
              <Badge variant="outline" className="bg-lighthouse/10 text-lighthouse border-lighthouse/30 text-xs">
                v{narrative.version}
              </Badge>
              <span className="text-xs text-muted-foreground tabular-nums">
                текущая версия · {formatDate(narrative.createdAt)}
              </span>
            </div>
            <p className="text-sm leading-relaxed">{narrative.narrative}</p>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground rounded-lg border border-dashed p-4 text-center">
            Память пока пуста — она наполнится по мере подтверждения навыков, проектов и ответов коучу.
          </p>
        )}

        {/* Таймлайн эволюции */}
        {points.length > 0 && (
          <section aria-label="Эволюция нарратива" className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm font-semibold flex items-center gap-1.5">
                <History className="w-4 h-4 text-lighthouse" aria-hidden="true" />
                Эволюция
              </h3>
              <Badge variant="secondary" className="text-xs tabular-nums">
                {totalVersions} {totalVersions === 1 ? 'версия' : totalVersions < 5 ? 'версии' : 'версий'}
              </Badge>
            </div>

            {/* Скролл-контейнер с кастомным teal-скроллбаром */}
            <div className="max-h-96 overflow-y-auto scroll-area-thin pr-2" role="list">
              <ol className="relative ml-2 border-l-2 border-lighthouse/20 space-y-4 py-1">
                {[...points].reverse().map((p) => (
                  <li key={p.version} className="relative pl-4" role="listitem">
                    <span
                      className="absolute -left-[7px] top-1.5 h-3 w-3 rounded-full border-2 border-background bg-lighthouse"
                      aria-hidden="true"
                    />
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-medium text-lighthouse tabular-nums flex items-center gap-1">
                        <GitBranch className="w-3 h-3" aria-hidden="true" />
                        v{p.version}
                      </span>
                      <span className="text-xs text-muted-foreground tabular-nums">
                        {formatDate(p.date)}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{p.event}</p>
                  </li>
                ))}
              </ol>
            </div>
          </section>
        )}
      </CardContent>
    </Card>
  );
}
