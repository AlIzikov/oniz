// BizON — TalentForecastScenariosCard (10-a, doc_a §58 — «Ваши сценарии»)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 🧭 ВАШИ СЦЕНАРИИ                                    [⌄]      │
//   │ Насколько ваш профиль дефицитен на рынке платформы           │
//   │                                                              │
//   │ [Консервативный] [Реалистичный] [Оптимистичный]  ← сценарий  │
//   │ Горизонт: [6 мес] [12 мес] [24 мес]                          │
//   │                                                              │
//   │ ОХВАТ    ОЖИДАЕМО НАЙМОВ   ПОКРЫТИЕ СТАВКИ   СЛОЖНОСТЬ НАЙМА │
//   │   4          1                33%          высокая          │
//   │                                                              │
//   │ ПУЛ КАНДИДАТОВ (как будто ищут вас)                          │
//   │ Готовы сейчас: 2 · не хватает 1 навыка: 1 · дефицит: 2       │
//   │                                                              │
//   │ Допущения сценария: …                                        │
//   │ Что делать: … (советы горизонта)                             │
//   │ ⓘ Эвристическая модель воронки платформы — оценка, не …      │
//   └──────────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/talent-forecast (10-a) — read-only обёртка над
// TalentForecastService.forecastScenarios (9-b, сервис не менялся).
// Семантика для пользователя: прогноз строится так, как будто работодатель
// ищет специалиста с профилем пользователя — виден размер пула конкурентов
// (marketPool) и сложность найма для работодателя (дефицитность профиля).
// Честность: дисклеймер «эвристическая модель», советы и допущения — из API,
// пустой пул — честный empty state из note, без выдуманных цифр.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Route,
  ChevronDown,
  Users,
  UserCheck,
  Target,
  Gauge,
  Lightbulb,
  ListChecks,
  Info,
  CalendarClock,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы (зеркало ответа /api/me/talent-forecast) ===
// ============================================================================

type ScenarioKey = 'conservative' | 'realistic' | 'optimistic';
type Difficulty = 'easy' | 'moderate' | 'hard' | 'critical';

interface ForecastHorizonDTO {
  months: number;
  expectedReach: number;
  expectedHire: number;
  coverage: number;
  difficulty: Difficulty;
  advice: string[];
}

interface ForecastScenarioDTO {
  key: ScenarioKey;
  label: string;
  assumptions: string[];
  demandMultiplier: number;
  horizons: ForecastHorizonDTO[];
}

interface TalentForecastResponse {
  role: string;
  requiredSkills: string[];
  requestedCount: number;
  demandJobs: number;
  paramsSource: {
    role: 'query' | 'profile' | 'default';
    skills: 'query' | 'profile';
    count: 'query' | 'active_jobs' | 'fallback';
  };
  hasSkills: boolean;
  baseForecast: {
    marketPool: number;
    confidence: number;
    difficulty: Difficulty;
  };
  scenarios: ForecastScenarioDTO[];
  summary: {
    readyNow: number;
    in6Months: number;
    in12Months: number;
    unlikely: number;
    deficit: number;
  };
  note: string;
  generatedAt: string;
}

// ============================================================================
// === Мета ===
// ============================================================================

/** Локальные подписи сценариев — только fallback, обычно приходят из API. */
const SCENARIO_FALLBACK: Record<ScenarioKey, string> = {
  conservative: 'Консервативный',
  realistic: 'Реалистичный',
  optimistic: 'Оптимистичный',
};

const SCENARIO_HINT: Record<ScenarioKey, string> = {
  conservative: 'строгие требования, узкая воронка',
  realistic: 'базовые коэффициенты платформы',
  optimistic: 'гибкие требования, широкая воронка',
};

const DIFFICULTY_META: Record<
  Difficulty,
  { label: string; accent: string; bg: string }
> = {
  easy: {
    label: 'низкая',
    accent: 'text-muted-foreground',
    bg: 'bg-muted',
  },
  moderate: {
    label: 'средняя',
    accent: 'text-lighthouse',
    bg: 'bg-lighthouse/10',
  },
  hard: {
    label: 'высокая',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
  critical: {
    label: 'критическая',
    accent: 'text-amber-700 dark:text-amber-300 font-bold',
    bg: 'bg-amber-500/15',
  },
};

const HORIZONS: Array<{ months: number; label: string }> = [
  { months: 6, label: '6 мес' },
  { months: 12, label: '12 мес' },
  { months: 24, label: '24 мес' },
];

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function TalentForecastScenariosCard({ className }: { className?: string }) {
  const [data, setData] = React.useState<TalentForecastResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(true);

  // Выбор пользователя: сценарий × горизонт (по умолчанию реалистичный × 12 мес)
  const [scenarioKey, setScenarioKey] = React.useState<ScenarioKey>('realistic');
  const [horizon, setHorizon] = React.useState(12);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<TalentForecastResponse>('/api/me/talent-forecast')
      .then((res) => {
        if (cancelled) return;
        setData(res);
        // Нормализация выбора под фактический ответ (защита от пустых массивов)
        if (!res.scenarios.some((s) => s.key === scenarioKey)) {
          setScenarioKey(res.scenarios[0]?.key ?? 'realistic');
        }
        const sel = res.scenarios.find((s) => s.key === scenarioKey);
        if (sel && !sel.horizons.some((h) => h.months === horizon)) {
          setHorizon(sel.horizons[0]?.months ?? 12);
        }
      })
      .catch((e: unknown) => {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Не удалось загрузить сценарии');
          console.error('[TalentForecastScenariosCard] load error:', e);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    // Нормализация выбора — только при монтировании (стартовые значения
    // scenarioKey/horizon намеренно фиксированы; смена пользователем не перезагружает данные)
  }, []);

  const scenario = data?.scenarios.find((s) => s.key === scenarioKey) ?? null;
  const horizonData =
    scenario?.horizons.find((h) => h.months === horizon) ?? scenario?.horizons[0] ?? null;
  const marketPool = data?.baseForecast.marketPool ?? 0;
  const summary = data?.summary ?? null;
  const difficultyMeta = horizonData ? DIFFICULTY_META[horizonData.difficulty] : null;

  return (
    <Card className={cn('overflow-hidden', className)}>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger
          className="w-full text-left"
          aria-label={
            open ? 'Свернуть блок «Ваши сценарии»' : 'Развернуть блок «Ваши сценарии»'
          }
        >
          <CardContent className="p-4 pb-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
                <Route className="w-4 h-4 text-lighthouse" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold leading-tight">Ваши сценарии</div>
                <div className="text-xs text-muted-foreground truncate">
                  Дефицитность вашего профиля: как будто работодатель ищет вас
                </div>
              </div>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground transition-transform flex-shrink-0',
                  open && 'rotate-180',
                )}
              />
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="p-4 pt-3">
            {/* Загрузка — скелетоны */}
            {loading && (
              <div className="space-y-3" aria-busy="true" aria-live="polite">
                <Skeleton className="h-7 w-full max-w-xs" />
                <div className="grid grid-cols-2 gap-2">
                  <Skeleton className="h-14 w-full" />
                  <Skeleton className="h-14 w-full" />
                </div>
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-3 w-full" />
              </div>
            )}

            {/* Ошибка — не роняем вкладку */}
            {!loading && error && !data && (
              <div className="text-xs text-muted-foreground py-4 text-center" role="alert">
                Не удалось построить сценарии. Попробуйте обновить страницу позже.
              </div>
            )}

            {/* Данные */}
            {!loading && data && (
              <div className="space-y-4">
                {/* Честная пометка: профиль без навыков */}
                {!data.hasSkills && (
                  <div className="flex items-start gap-1.5 rounded-lg bg-muted/60 px-2.5 py-2">
                    <Info className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" aria-hidden="true" />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      В профиле не указаны навыки — сценарий построен по базовой роли.
                      Добавьте навыки, чтобы увидеть прогноз по вашему профилю.
                    </p>
                  </div>
                )}

                {/* Переключатель сценария */}
                <div
                  className="flex items-center gap-1.5 flex-wrap"
                  role="group"
                  aria-label="Сценарий прогноза"
                >
                  {(['conservative', 'realistic', 'optimistic'] as ScenarioKey[]).map(
                    (key) => {
                      const active = scenarioKey === key;
                      const exists = data.scenarios.some((s) => s.key === key);
                      return (
                        <button
                          key={key}
                          type="button"
                          disabled={!exists}
                          aria-pressed={active}
                          onClick={() => setScenarioKey(key)}
                          className={cn(
                            'inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-full transition min-h-[32px] disabled:opacity-40 disabled:cursor-not-allowed',
                            active
                              ? 'bg-lighthouse text-lighthouse-foreground'
                              : 'bg-muted text-muted-foreground hover:bg-accent',
                          )}
                          title={SCENARIO_HINT[key]}
                        >
                          {data.scenarios.find((s) => s.key === key)?.label ??
                            SCENARIO_FALLBACK[key]}
                        </button>
                      );
                    },
                  )}
                </div>

                {/* Переключатель горизонта */}
                <div
                  className="flex items-center gap-1.5 flex-wrap"
                  role="group"
                  aria-label="Горизонт прогноза"
                >
                  <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                    Горизонт:
                  </span>
                  {HORIZONS.map((h) => {
                    const active = horizonData?.months === h.months;
                    return (
                      <button
                        key={h.months}
                        type="button"
                        aria-pressed={active}
                        onClick={() => setHorizon(h.months)}
                        className={cn(
                          'inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-full transition min-h-[32px]',
                          active
                            ? 'bg-lighthouse text-lighthouse-foreground'
                            : 'bg-muted text-muted-foreground hover:bg-accent',
                        )}
                      >
                        <CalendarClock className="w-3 h-3" aria-hidden="true" />
                        {h.label}
                      </button>
                    );
                  })}
                </div>

                {/* Ключевые цифры выбранного сценария × горизонта */}
                {scenario && horizonData ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="rounded-lg border border-border/60 px-3 py-2">
                      <div className="flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                        <Users className="w-3 h-3" aria-hidden="true" />
                        Охват
                      </div>
                      <div className="text-lg font-extrabold tabular-nums leading-tight">
                        {horizonData.expectedReach}
                      </div>
                      <div className="text-xs text-muted-foreground leading-tight">
                        {pluralize(
                          horizonData.expectedReach,
                          'кандидат',
                          'кандидата',
                          'кандидатов',
                        )}{' '}
                        реально достижимо
                      </div>
                    </div>
                    <div className="rounded-lg border border-border/60 px-3 py-2">
                      <div className="flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                        <UserCheck className="w-3 h-3" aria-hidden="true" />
                        Наймов
                      </div>
                      <div className="text-lg font-extrabold tabular-nums leading-tight">
                        {horizonData.expectedHire}
                      </div>
                      <div className="text-xs text-muted-foreground leading-tight">
                        ожидается за {horizonData.months} мес
                      </div>
                    </div>
                    <div className="rounded-lg border border-border/60 px-3 py-2">
                      <div className="flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                        <Target className="w-3 h-3" aria-hidden="true" />
                        Покрытие
                      </div>
                      <div className="text-lg font-extrabold tabular-nums leading-tight">
                        {Math.round(horizonData.coverage * 100)}%
                      </div>
                      <div className="text-xs text-muted-foreground leading-tight">
                        из {data.requestedCount}{' '}
                        {pluralize(data.requestedCount, 'ставки', 'ставок', 'ставок')}
                      </div>
                    </div>
                    <div className="rounded-lg border border-border/60 px-3 py-2">
                      <div className="flex items-center gap-1 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                        <Gauge className="w-3 h-3" aria-hidden="true" />
                        Сложность найма
                      </div>
                      <div className="mt-0.5">
                        {difficultyMeta && (
                          <span
                            className={cn(
                              'inline-block text-xs font-semibold px-1.5 py-0.5 rounded-full',
                              difficultyMeta.accent,
                              difficultyMeta.bg,
                            )}
                          >
                            {difficultyMeta.label}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground leading-tight mt-0.5">
                        для работодателя — чем выше, тем ценнее профиль
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Для выбранного сценария нет горизонтов — данные ещё собираются.
                  </p>
                )}

                {/* Пул кандидатов (конкуренция) + pipeline-сводка */}
                {summary && (
                  <section aria-label="Пул кандидатов с этими навыками">
                    <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1.5">
                      Пул кандидатов с вашим набором навыков
                    </h4>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-lighthouse/10 text-lighthouse tabular-nums">
                        <Users className="w-3 h-3" aria-hidden="true" />
                        всего: {marketPool}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 tabular-nums">
                        готовы сейчас: {summary.readyNow}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-muted text-muted-foreground tabular-nums">
                        −1 навык: {summary.in6Months} · −2: {summary.in12Months}
                      </span>
                      <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400 tabular-nums">
                        маловероятно: {summary.unlikely}
                      </span>
                      {summary.deficit > 0 && (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-1 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 tabular-nums">
                          дефицит ставок: {summary.deficit}
                        </span>
                      )}
                    </div>
                    {data.demandJobs > 0 && (
                      <p className="text-xs text-muted-foreground mt-1.5">
                        Активных вакансий с этими навыками: {data.demandJobs} — спрос на
                        профиль виден в открытых позициях платформы.
                      </p>
                    )}
                  </section>
                )}

                {/* Допущения сценария + советы горизонта */}
                {scenario && (scenario.assumptions.length > 0 || (horizonData?.advice.length ?? 0) > 0) && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {scenario.assumptions.length > 0 && (
                      <div className="min-w-0">
                        <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1 flex items-center gap-1">
                          <ListChecks className="w-3 h-3" aria-hidden="true" />
                          Допущения сценария
                        </h4>
                        <ul className="text-xs text-muted-foreground space-y-1 max-h-32 overflow-y-auto scroll-area-thin">
                          {scenario.assumptions.map((a, i) => (
                            <li key={i} className="leading-relaxed flex gap-1.5">
                              <span aria-hidden="true" className="flex-shrink-0">
                                ·
                              </span>
                              <span>{a}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {horizonData && horizonData.advice.length > 0 && (
                      <div className="min-w-0">
                        <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1 flex items-center gap-1">
                          <Lightbulb className="w-3 h-3" aria-hidden="true" />
                          Что это значит
                        </h4>
                        <ul className="text-xs text-muted-foreground space-y-1 max-h-32 overflow-y-auto scroll-area-thin">
                          {horizonData.advice.map((a, i) => (
                            <li key={i} className="leading-relaxed flex gap-1.5">
                              <span aria-hidden="true" className="flex-shrink-0">
                                ·
                              </span>
                              <span>{a}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* Дисклеймер: эвристическая модель */}
                <div className="flex items-start gap-1.5 pt-3 border-t border-border/60">
                  <Info
                    className="w-3 h-3 text-muted-foreground flex-shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Эвристическая модель воронки платформы (охват × отклик × найм) на
                    допущениях сценария — это оценка, а не гарантия и не предсказание:
                    без внешних рыночных данных и без AI-догадок.
                  </p>
                </div>
                {data.note && (
                  <p className="text-xs text-muted-foreground leading-relaxed -mt-2">
                    {data.note}
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
