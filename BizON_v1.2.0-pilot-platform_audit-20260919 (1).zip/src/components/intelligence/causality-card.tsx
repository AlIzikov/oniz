// BizON — CausalityCard (10-a, doc_a §55/п.14 аудита — «Что на вас работает»)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 🔎 ЧТО НА ВАС РАБОТАЕТ                              [⌄]      │
//   │ Связи между вашими действиями и результатами                 │
//   │                                                              │
//   │ ГИПОТЕЗЫ (по вашей истории, ≤5)                              │
//   │ ┌──────────────────────────────────────────────────────────┐ │
//   │ │ Подтверждение инсайта → больше действий   [инсайт→повед.]│ │
//   │ │ До: 0.2/день → После: 0.9/день   ▲ +350%                 │ │
//   │ │ [корреляция; механизм правдоподобен] [уверенность: ср.]  │ │
//   │ │ Механизм: … · последовательность во времени соблюдена ✓  │ │
//   │ └──────────────────────────────────────────────────────────┘ │
//   │   — или честный empty state «Собираем наблюдения» из API —   │
//   │                                                              │
//   │ СОБИРАЕМ НАБЛЮДЕНИЯ                                          │
//   │ · Просмотры → отклики: мало просмотров (до готовности 4 дн.) │
//   │                                                              │
//   │ ⓘ Наблюдательные корреляции вашей истории — не доказанная …  │
//   │ ⛁ Проанализировано N событий за 180 дней                     │
//   └──────────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/causality → PersonalCausalityResult
// (Professional Causality Engine, Task 9-f: детерминированно, без LLM).
// Честность: ярлык каждой гипотезы — только «корреляция…» из claimLabel API
// (никогда не «причинность»); мало данных → empty state «Собираем наблюдения»
// с минимумами; pendingObservations → «до готовности N дней».
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Workflow,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  MoveRight,
  ShieldCheck,
  ShieldQuestion,
  Clock,
  Database,
  Info,
  Hourglass,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы (зеркало PersonalCausalityResult из causality-engine-service) ===
// ============================================================================

type ConfidenceLevel = 'low' | 'medium' | 'high';
type MechanismPlausibility = 'plausible' | 'unverified' | 'absent';
type EffectSign = 'positive' | 'negative' | 'neutral';
type CausalityClaim =
  | 'correlation_with_plausible_mechanism'
  | 'correlation_mechanism_unverified'
  | 'no_effect_observed';

interface CausalityHypothesisDTO {
  id: string;
  kind: string;
  kindLabel: string;
  title: string;
  summary: string;
  cause: { type: string; label: string; at: string | null };
  outcome: { type: string; label: string };
  windowDays: number;
  observed: {
    beforeCount: number;
    beforeDays: number;
    beforeRatePerDay: number;
    afterCount: number;
    afterDays: number;
    afterRatePerDay: number;
    afterActiveDays: number | null;
    baselinePartial: boolean;
    windowPartial: boolean;
  };
  effectSize: {
    absolutePerDay: number;
    relativePct: number | null;
    sign: EffectSign;
  };
  durationDays: number | null;
  conversion: {
    views: number;
    applications: number;
    rate: number | null;
    weightedRate: number | null;
    byTopToken: { token: string; views: number; conversions: number; conversion: number }[];
  } | null;
  temporalPrecedence: boolean;
  mechanismPlausibility: MechanismPlausibility;
  mechanismNote: string;
  repeatability: { observations: number; consistent: boolean | null } | null;
  doseEffect: { checked: boolean; observed: boolean | null; note: string } | null;
  confidence: ConfidenceLevel;
  confidenceReasons: string[];
  claim: CausalityClaim;
  claimLabel: string;
}

interface CausalityPendingDTO {
  id: string;
  kind: string;
  label: string;
  anchorAt: string;
  reason: string;
  readyInDays: number | null;
}

interface CausalityResponse {
  status: 'ok';
  hasData: boolean;
  hypotheses: CausalityHypothesisDTO[];
  pendingObservations: CausalityPendingDTO[];
  emptyState: {
    active: boolean;
    message: string;
    detail: string;
    minimums: Record<string, string>;
  } | null;
  dataCoverage: {
    windowDays: number;
    eventsAnalyzed: number;
    eventsLimit: number;
    truncated: boolean;
    counts: Record<string, number>;
  };
  methodology: {
    disclaimer: string;
    rules: string[];
    windowDays: number;
    effectWindowDays: number;
    claimLabels: Record<string, string>;
  };
  generatedAt: string;
  cache: { ttlSeconds: number };
}

// ============================================================================
// === Мета ===
// ============================================================================

const CONFIDENCE_META: Record<
  ConfidenceLevel,
  { label: string; accent: string; bg: string }
> = {
  low: { label: 'уверенность: низкая', accent: 'text-muted-foreground', bg: 'bg-muted' },
  medium: {
    label: 'уверенность: средняя',
    accent: 'text-lighthouse',
    bg: 'bg-lighthouse/10',
  },
  high: {
    label: 'уверенность: высокая',
    accent: 'text-emerald-700 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
};

const MECHANISM_META: Record<
  MechanismPlausibility,
  { label: string; accent: string; bg: string }
> = {
  plausible: {
    label: 'механизм правдоподобен',
    accent: 'text-lighthouse',
    bg: 'bg-lighthouse/10',
  },
  unverified: {
    label: 'механизм не проверен',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
  absent: {
    label: 'механизм не найден',
    accent: 'text-muted-foreground',
    bg: 'bg-muted',
  },
};

/** Порог «шума» движка (0.01/день) — меньше считаем нулевым эффектом. */
const NOISE_THRESHOLD = 0.01;

function fmtRate(v: number): string {
  if (Math.abs(v) >= 10) return String(Math.round(v));
  return String(Math.round(v * 100) / 100);
}

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// ============================================================================
// === Карточка гипотезы ===
// ============================================================================

function HypothesisItem({ h }: { h: CausalityHypothesisDTO }) {
  const sign = h.effectSize.sign;
  const conf = CONFIDENCE_META[h.confidence];
  const mech = MECHANISM_META[h.mechanismPlausibility];

  // Ярлык эффекта: показываем relativePct, если движок его дал и эффект не шумовой
  const relative =
    h.effectSize.relativePct !== null &&
    Math.abs(h.effectSize.absolutePerDay) > NOISE_THRESHOLD
      ? Math.round(h.effectSize.relativePct)
      : null;

  return (
    <li className="rounded-lg border border-border/60 px-3 py-2.5 hover:border-lighthouse/30 transition min-w-0">
      <div className="flex items-start gap-2 flex-wrap">
        <span className="text-sm font-semibold leading-snug min-w-0 flex-1">
          {h.title}
        </span>
        <span className="text-xs uppercase tracking-wide text-muted-foreground bg-muted px-1.5 py-0.5 rounded-full flex-shrink-0">
          {h.kindLabel}
        </span>
      </div>

      <p className="text-xs text-muted-foreground leading-relaxed mt-1">{h.summary}</p>

      {/* Эффект: до → после */}
      <div className="flex items-center gap-2 flex-wrap mt-2 text-xs">
        <span className="text-muted-foreground tabular-nums">
          До: {fmtRate(h.observed.beforeRatePerDay)}/день
        </span>
        <MoveRight className="w-3.5 h-3.5 text-muted-foreground" aria-hidden="true" />
        <span className="font-semibold tabular-nums">
          После: {fmtRate(h.observed.afterRatePerDay)}/день
        </span>
        {relative !== null && sign !== 'neutral' && (
          <span
            className={cn(
              'inline-flex items-center gap-0.5 font-semibold tabular-nums',
              sign === 'positive'
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-amber-600 dark:text-amber-400',
            )}
          >
            {sign === 'positive' ? (
              <TrendingUp className="w-3.5 h-3.5" aria-hidden="true" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5" aria-hidden="true" />
            )}
            {relative > 0 ? `+${relative}%` : `${relative}%`}
          </span>
        )}
        <span className="sr-only">
          {sign === 'positive'
            ? 'эффект положительный'
            : sign === 'negative'
              ? 'эффект отрицательный'
              : 'эффекта не наблюдается'}
        </span>
      </div>

      {/* Конверсия просмотров → откликов (только для view_to_action) */}
      {h.conversion && h.conversion.rate !== null && (
        <p className="text-xs text-muted-foreground mt-1.5 tabular-nums">
          Конверсия: {h.conversion.views}{' '}
          {pluralize(h.conversion.views, 'просмотр', 'просмотра', 'просмотров')} →{' '}
          {h.conversion.applications}{' '}
          {pluralize(h.conversion.applications, 'отклик', 'отклика', 'откликов')} (
          {Math.round(h.conversion.rate * 100)}%)
        </p>
      )}

      {/* Честные ярлыки: claim + уверенность + механизм */}
      <div className="flex items-center gap-1.5 flex-wrap mt-2">
        <span
          className={cn(
            'inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full',
            h.claim === 'correlation_with_plausible_mechanism'
              ? 'bg-lighthouse/10 text-lighthouse'
              : h.claim === 'correlation_mechanism_unverified'
                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                : 'bg-muted text-muted-foreground',
          )}
        >
          <Info className="w-3 h-3" aria-hidden="true" />
          {h.claimLabel}
        </span>
        <span
          className={cn(
            'inline-flex items-center text-xs font-semibold px-2 py-0.5 rounded-full',
            conf.accent,
            conf.bg,
          )}
        >
          {conf.label}
        </span>
        <span
          className={cn(
            'inline-flex items-center text-xs font-semibold px-2 py-0.5 rounded-full',
            mech.accent,
            mech.bg,
          )}
        >
          {mech.label}
        </span>
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
          {h.temporalPrecedence ? (
            <>
              <ShieldCheck className="w-3 h-3 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              последовательность во времени соблюдена
            </>
          ) : (
            <>
              <ShieldQuestion className="w-3 h-3 text-amber-600 dark:text-amber-400" aria-hidden="true" />
              последовательность во времени не подтверждена
            </>
          )}
        </span>
      </div>

      {/* Механизм + основания уверенности + повторы/дозы */}
      {h.mechanismNote && (
        <p className="text-xs text-muted-foreground leading-relaxed mt-1.5">
          Механизм: {h.mechanismNote}
        </p>
      )}
      {h.confidenceReasons.length > 0 && (
        <p className="text-xs text-muted-foreground leading-relaxed mt-1">
          Уверенность: {h.confidenceReasons.join(' · ')}
        </p>
      )}
      {h.repeatability && h.repeatability.observations > 1 && (
        <p className="text-xs text-muted-foreground leading-relaxed mt-1">
          Повторяемость: {h.repeatability.observations} измеримых наблюдений,{' '}
          {h.repeatability.consistent === true
            ? 'знак эффекта согласован'
            : h.repeatability.consistent === false
              ? 'знак эффекта не согласован'
              : 'согласованность знака неизвестна'}
        </p>
      )}
      {h.doseEffect?.checked && (
        <p className="text-xs text-muted-foreground leading-relaxed mt-1">
          Доз-эффект: {h.doseEffect.observed ? 'наблюдается' : 'не наблюдается'} ·{' '}
          {h.doseEffect.note}
        </p>
      )}
      {h.durationDays !== null && h.durationDays > 0 && (
        <p className="text-xs text-muted-foreground leading-relaxed mt-1">
          Эффект держится ~{h.durationDays}{' '}
          {pluralize(h.durationDays, 'день', 'дня', 'дней')}
        </p>
      )}
      {(h.observed.baselinePartial || h.observed.windowPartial) && (
        <p className="text-xs text-amber-600 dark:text-amber-400 leading-relaxed mt-1">
          Часть окна наблюдения неполна — эффект оценён по доступным данным.
        </p>
      )}
    </li>
  );
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function CausalityCard({ className }: { className?: string }) {
  const [data, setData] = React.useState<CausalityResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(true);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<CausalityResponse>('/api/me/causality')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e: unknown) => {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Не удалось загрузить гипотезы');
          console.error('[CausalityCard] load error:', e);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const empty = data?.emptyState ?? null;
  const hypotheses = data?.hypotheses ?? [];
  const pending = data?.pendingObservations ?? [];

  return (
    <Card className={cn('overflow-hidden', className)}>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger
          className="w-full text-left"
          aria-label={
            open
              ? 'Свернуть блок «Что на вас работает»'
              : 'Развернуть блок «Что на вас работает»'
          }
        >
          <CardContent className="p-4 pb-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
                <Workflow className="w-4 h-4 text-lighthouse" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold leading-tight">
                  Что на вас работает
                </div>
                <div className="text-xs text-muted-foreground truncate">
                  Связи действий и результатов по вашей истории
                </div>
              </div>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground transition-transform flex-shrink-0',
                  open && 'rotate-180',
                )}
              />
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="p-4 pt-3">
            {/* Загрузка — скелетоны */}
            {loading && (
              <div className="space-y-3" aria-busy="true" aria-live="polite">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            )}

            {/* Ошибка — не роняем вкладку */}
            {!loading && error && !data && (
              <div className="text-xs text-muted-foreground py-4 text-center" role="alert">
                Не удалось загрузить гипотезы. Попробуйте обновить страницу позже.
              </div>
            )}

            {/* Данные */}
            {!loading && data && (
              <div className="space-y-4">
                {/* Гипотезы или честный empty state */}
                {hypotheses.length > 0 ? (
                  <section aria-label="Гипотезы связей">
                    <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2">
                      Гипотезы ({hypotheses.length})
                    </h4>
                    <ul className="space-y-2.5 max-h-96 overflow-y-auto scroll-area-thin">
                      {hypotheses.map((h) => (
                        <HypothesisItem key={h.id} h={h} />
                      ))}
                    </ul>
                  </section>
                ) : empty?.active ? (
                  <section
                    aria-label="Данных пока мало"
                    className="rounded-lg bg-muted/60 px-3 py-3"
                  >
                    <div className="flex items-center gap-2">
                      <Hourglass
                        className="w-4 h-4 text-lighthouse flex-shrink-0"
                        aria-hidden="true"
                      />
                      <p className="text-sm font-semibold">{empty.message}</p>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed mt-1.5">
                      {empty.detail}
                    </p>
                    {Object.keys(empty.minimums).length > 0 && (
                      <ul className="text-xs text-muted-foreground leading-relaxed mt-2 space-y-1">
                        {Object.values(empty.minimums).map((m, i) => (
                          <li key={i} className="flex gap-1.5">
                            <span aria-hidden="true" className="flex-shrink-0">
                              ·
                            </span>
                            <span>{m}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </section>
                ) : (
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Гипотез пока нет — по мере накопления истории здесь появятся
                    проверенные связи между вашими действиями и результатами.
                  </p>
                )}

                {/* Pending-наблюдения: «Собираем наблюдения (до готовности N дней)» */}
                {pending.length > 0 && (
                  <section aria-label="Собираем наблюдения">
                    <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1.5 flex items-center gap-1">
                      <Clock className="w-3 h-3" aria-hidden="true" />
                      Собираем наблюдения
                    </h4>
                    <ul className="space-y-1.5 max-h-40 overflow-y-auto scroll-area-thin">
                      {pending.map((p) => (
                        <li
                          key={p.id}
                          className="rounded-lg border border-border/60 px-2.5 py-2 min-w-0"
                        >
                          <div className="flex items-start gap-2 flex-wrap">
                            <span className="text-xs font-semibold min-w-0 flex-1 leading-snug">
                              {p.label}
                            </span>
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-lighthouse flex-shrink-0 tabular-nums">
                              <Hourglass className="w-3 h-3" aria-hidden="true" />
                              {p.readyInDays !== null
                                ? `до готовности ${p.readyInDays} ${pluralize(p.readyInDays, 'день', 'дня', 'дней')}`
                                : 'срок готовности уточняется'}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">
                            {p.reason}
                          </p>
                        </li>
                      ))}
                    </ul>
                  </section>
                )}

                {/* Дисклеймер методологии: корреляция ≠ причинность */}
                <div className="flex items-start gap-1.5 pt-3 border-t border-border/60">
                  <Info
                    className="w-3 h-3 text-muted-foreground flex-shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {data.methodology.disclaimer} Это наблюдательные корреляции по вашей
                    же истории: временная последовательность и механизм объяснимы, но без
                    эксперимента это не доказанная причинность — на результат могли
                    повлиять другие факторы.
                  </p>
                </div>

                {/* Прозрачность объёма данных */}
                <div className="flex items-start gap-1.5">
                  <Database
                    className="w-3 h-3 text-muted-foreground flex-shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Проанализировано {data.dataCoverage.eventsAnalyzed}{' '}
                    {pluralize(
                      data.dataCoverage.eventsAnalyzed,
                      'событие',
                      'события',
                      'событий',
                    )}{' '}
                    за {data.dataCoverage.windowDays} дней (лимит{' '}
                    {data.dataCoverage.eventsLimit}){data.dataCoverage.truncated ? ' — данные усечены лимитом' : ''}
                    . Расчёт детерминированный, без LLM; кэш {data.cache.ttlSeconds}с.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
