// BizON — MarketIntelligencePanel (10-a, doc_a §17 — BIZON Market Intelligence UI)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 📊 РЫНОК                                              [⌄]   │
//   │ Спрос, горячие направления и динамика найма                  │
//   │                                                              │
//   │ СПРОС ПО НАВЫКАМ (30 дней)                                   │
//   │ Docker            5 вакансий        ▲ +100%                  │
//   │ Python            3 вакансии        → стабильный             │
//   │ …                                                            │
//   │                                                              │
//   │ ГОРЯЧИЕ НАПРАВЛЕНИЯ                                          │
//   │ IT / DevOps · категория навыков  ▲ +100%                     │
//   │   └ Почему: рост вакансий отрасли за 30 дней                 │
//   │                                                              │
//   │ ДИНАМИКА НАЙМА (8 недель)                                    │
//   │ ▁▂▃▅▂▁▁▂  вакансии по неделям · 1 трудоустройство · 2 новости│
//   │   — или честный empty state «данных пока мало» из API —      │
//   │                                                              │
//   │ ⓘ Снапшот построен на 13 вакансиях, 2 новостях, 113 показах… │
//   └──────────────────────────────────────────────────────────────┘
//
// Источник: GET /api/market/intelligence → MarketIntelligenceSnapshot
// (детерминированный снапшот без LLM, Task 9-b). Честность: сегмент без данных
// → empty state с meta.dataNote из API, никаких выдуманных цифр.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  BarChart3,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  MoveRight,
  Sparkles,
  Flame,
  Briefcase,
  CalendarRange,
  UserCheck,
  Newspaper,
  Database,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы (зеркало MarketIntelligenceSnapshot из market-intelligence-service) ===
// ============================================================================

type SkillTrend = 'rising' | 'stable' | 'declining' | 'new';

interface SegmentMetaDTO {
  segment: string;
  title: string;
  dataAvailable: boolean;
  dataNote: string;
}

interface SkillDemandDTO {
  skill: string;
  currentJobs: number;
  previousJobs: number;
  growthPct: number;
  trend: SkillTrend;
}

interface HotDirectionDTO {
  kind: 'industry' | 'skill_category';
  name: string;
  currentJobs: number;
  previousJobs: number;
  growthPct: number;
  reason: string;
}

interface MarketIntelligenceResponse {
  generatedAt: string;
  dataFootprint: {
    activeJobs: number;
    publishedNews: number;
    activeAds: number;
    adImpressions30d: number;
    placements: number;
  };
  demandBySkills: {
    meta: SegmentMetaDTO;
    items: SkillDemandDTO[];
    distinctSkills: number;
  };
  hiringDynamics: {
    meta: SegmentMetaDTO;
    weeklyJobs: Array<{ weekStart: string; jobs: number }>;
    placements30d: number;
    news30d: number;
  };
  hotDirections: {
    meta: SegmentMetaDTO;
    items: HotDirectionDTO[];
  };
}

// ============================================================================
// === Мета тренда спроса (emerald — рост, teal — новый/стабильный, amber — спад) ===
// ============================================================================

const TREND_META: Record<
  SkillTrend,
  { icon: React.ReactNode; label: string; accent: string; bg: string }
> = {
  rising: {
    icon: <TrendingUp className="w-3 h-3" />,
    label: 'растёт',
    accent: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-500/10',
  },
  new: {
    icon: <Sparkles className="w-3 h-3" />,
    label: 'новый спрос',
    accent: 'text-lighthouse',
    bg: 'bg-lighthouse/10',
  },
  stable: {
    icon: <MoveRight className="w-3 h-3" />,
    label: 'стабильно',
    accent: 'text-muted-foreground',
    bg: 'bg-muted',
  },
  declining: {
    icon: <TrendingDown className="w-3 h-3" />,
    label: 'снижается',
    accent: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-500/10',
  },
};

/** Показываем топ-5 навыков и топ-4 направления — панель, а не таблица. */
const TOP_SKILLS_SHOWN = 5;
const TOP_DIRECTIONS_SHOWN = 4;

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function MarketIntelligencePanel({ className }: { className?: string }) {
  const [data, setData] = React.useState<MarketIntelligenceResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(true);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<MarketIntelligenceResponse>('/api/market/intelligence')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e: unknown) => {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Не удалось загрузить снапшот рынка');
          console.error('[MarketIntelligencePanel] load error:', e);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const skills = (data?.demandBySkills.items ?? []).slice(0, TOP_SKILLS_SHOWN);
  const directions = (data?.hotDirections.items ?? []).slice(0, TOP_DIRECTIONS_SHOWN);
  const demandAvailable = data?.demandBySkills.meta.dataAvailable ?? false;
  const hotAvailable = data?.hotDirections.meta.dataAvailable ?? false;
  const hiring = data?.hiringDynamics;
  const hiringAvailable = hiring?.meta.dataAvailable ?? false;
  const maxWeekly = Math.max(1, ...(hiring?.weeklyJobs ?? []).map((w) => w.jobs));

  const footprint = data?.dataFootprint;
  const footprintParts: string[] = [];
  if (footprint) {
    if (footprint.activeJobs > 0)
      footprintParts.push(
        `${footprint.activeJobs} ${pluralize(footprint.activeJobs, 'активная вакансия', 'активные вакансии', 'активных вакансий')}`,
      );
    if (footprint.publishedNews > 0)
      footprintParts.push(
        `${footprint.publishedNews} ${pluralize(footprint.publishedNews, 'новость', 'новости', 'новостей')}`,
      );
    if (footprint.activeAds > 0)
      footprintParts.push(
        `${footprint.activeAds} ${pluralize(footprint.activeAds, 'рекламное объявление', 'рекламных объявления', 'рекламных объявлений')}`,
      );
    if (footprint.placements > 0)
      footprintParts.push(
        `${footprint.placements} ${pluralize(footprint.placements, 'подтверждённое трудоустройство', 'подтверждённых трудоустройства', 'подтверждённых трудоустройств')}`,
      );
  }

  return (
    <Card className={cn('overflow-hidden', className)}>
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger
          className="w-full text-left"
          aria-label={
            open ? 'Свернуть панель «Рынок»' : 'Развернуть панель «Рынок»'
          }
        >
          <CardContent className="p-4 pb-0">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
                <BarChart3 className="w-4 h-4 text-lighthouse" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold leading-tight">Рынок</div>
                <div className="text-xs text-muted-foreground truncate">
                  Спрос по навыкам, направления и найм — снапшот платформы
                </div>
              </div>
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground transition-transform flex-shrink-0',
                  open && 'rotate-180',
                )}
              />
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="p-4 pt-3">
            {/* Загрузка — скелетоны */}
            {loading && (
              <div className="space-y-3" aria-busy="true" aria-live="polite">
                <Skeleton className="h-4 w-40" />
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between gap-2">
                    <Skeleton className="h-4 w-28" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                ))}
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            )}

            {/* Ошибка — не роняем вкладку */}
            {!loading && error && !data && (
              <div className="text-xs text-muted-foreground py-4 text-center" role="alert">
                Не удалось загрузить снапшот рынка. Попробуйте обновить страницу позже.
              </div>
            )}

            {/* Данные */}
            {!loading && data && (
              <div className="space-y-4">
                {/* (а) Спрос по навыкам */}
                <section aria-label="Спрос по навыкам">
                  <div className="flex items-baseline justify-between gap-2 mb-2">
                    <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                      Спрос по навыкам
                    </h4>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {demandAvailable
                        ? `${pluralize(skills.length, 'навык', 'навыка', 'навыков')} из ${data.demandBySkills.distinctSkills} · 30 дней`
                        : '30 дней'}
                    </span>
                  </div>
                  {demandAvailable && skills.length > 0 ? (
                    <ul className="space-y-1.5 max-h-64 overflow-y-auto scroll-area-thin">
                      {skills.map((s) => {
                        const meta = TREND_META[s.trend];
                        return (
                          <li
                            key={s.skill}
                            className="flex items-center gap-2 text-sm rounded-lg px-2 py-1.5 hover:bg-accent transition min-w-0"
                          >
                            <span className="font-medium truncate min-w-0 flex-1" title={s.skill}>
                              {s.skill}
                            </span>
                            <span className="text-xs text-muted-foreground tabular-nums whitespace-nowrap">
                              {s.currentJobs}{' '}
                              {pluralize(s.currentJobs, 'вакансия', 'вакансии', 'вакансий')}
                            </span>
                            <span
                              className={cn(
                                'inline-flex items-center gap-1 text-xs font-semibold px-1.5 py-0.5 rounded-full flex-shrink-0',
                                meta.accent,
                                meta.bg,
                              )}
                            >
                              {meta.icon}
                              {s.trend === 'stable'
                                ? meta.label
                                : s.trend === 'declining'
                                  ? `${Math.round(s.growthPct)}%`
                                  : `+${Math.round(s.growthPct)}%`}
                              <span className="sr-only">{`тренд: ${meta.label}`}</span>
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  ) : (
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {data.demandBySkills.meta.dataNote}
                    </p>
                  )}
                </section>

                {/* (б) Горячие направления */}
                <section aria-label="Горячие направления">
                  <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2">
                    Горячие направления
                  </h4>
                  {hotAvailable && directions.length > 0 ? (
                    <ul className="space-y-1.5 max-h-56 overflow-y-auto scroll-area-thin">
                      {directions.map((d) => (
                        <li
                          key={`${d.kind}:${d.name}`}
                          className="rounded-lg border border-border/60 px-2.5 py-2 hover:border-lighthouse/30 transition min-w-0"
                        >
                          <div className="flex items-center gap-2 flex-wrap min-w-0">
                            <Flame
                              className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 flex-shrink-0"
                              aria-hidden="true"
                            />
                            <span className="text-sm font-semibold truncate min-w-0" title={d.name}>
                              {d.name}
                            </span>
                            <span className="text-xs uppercase tracking-wide text-muted-foreground flex-shrink-0">
                              {d.kind === 'industry' ? 'отрасль' : 'навыки'}
                            </span>
                            <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 ml-auto tabular-nums flex-shrink-0">
                              <TrendingUp className="w-3 h-3" />
                              +{Math.round(d.growthPct)}%
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                            {d.reason}
                          </p>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {data.hotDirections.meta.dataNote}
                    </p>
                  )}
                </section>

                {/* (в) Динамика найма */}
                <section aria-label="Динамика найма">
                  <h4 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2">
                    Динамика найма
                  </h4>
                  {hiringAvailable && hiring && hiring.weeklyJobs.length > 0 ? (
                    <>
                      <div
                        className="flex items-end gap-1 h-14"
                        role="img"
                        aria-label={`Активные вакансии по неделям: ${hiring.weeklyJobs.map((w) => w.jobs).join(', ')}`}
                      >
                        {hiring.weeklyJobs.map((w) => (
                          <div
                            key={w.weekStart}
                            className="flex-1 flex flex-col items-center justify-end min-w-0"
                            title={`${new Date(w.weekStart).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}: ${w.jobs}`}
                          >
                            <div
                              className={cn(
                                'w-full rounded-t-sm min-h-[2px]',
                                w.jobs > 0 ? 'bg-lighthouse/70' : 'bg-muted',
                              )}
                              style={{ height: `${Math.max(6, (w.jobs / maxWeekly) * 100)}%` }}
                            />
                          </div>
                        ))}
                      </div>
                      <div className="flex items-center gap-3 mt-2 flex-wrap text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1">
                          <CalendarRange className="w-3 h-3" aria-hidden="true" />
                          8 недель: вакансии по неделям
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <UserCheck className="w-3 h-3" aria-hidden="true" />
                          {hiring.placements30d}{' '}
                          {pluralize(hiring.placements30d, 'найм', 'найма', 'наймов')} за 30 дней
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Newspaper className="w-3 h-3" aria-hidden="true" />
                          {hiring.news30d}{' '}
                          {pluralize(hiring.news30d, 'новость', 'новости', 'новостей')}
                        </span>
                      </div>
                    </>
                  ) : (
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {hiring?.meta.dataNote ?? 'Данных пока мало.'}
                    </p>
                  )}
                </section>

                {/* (г) Прозрачность: data footprint */}
                {footprintParts.length > 0 && (
                  <div className="flex items-start gap-1.5 pt-3 border-t border-border/60">
                    <Database
                      className="w-3 h-3 text-muted-foreground flex-shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Снапшот построен на {footprintParts.join(', ')} платформы — без внешних
                      источников и без AI-догадок.
                    </p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
