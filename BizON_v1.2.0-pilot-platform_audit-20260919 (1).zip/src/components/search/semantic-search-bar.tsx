// BizON v6 — SemanticSearchBar (умный поиск)
// Natural-language поиск вакансий: русские синонимы, разбор интента,
// объяснимая релевантность («почему найдено»).
//
// Источник: POST /api/search/semantic  { query, limit }
//   → { intent: { role, skills, location, remote, salaryMin, seniority, raw },
//       results: Job[] & { relevance, matchedSkills }, totalFound }
//   (бэкенд v6 принимает POST с JSON-телом; GET ?q= вернёт 405)
//
// UX-защита: debounce 400мс, минимум 3 символа, кэш ответов по запросу
// (rate limit бэкенда — 10 запросов/час на пользователя).
//
// Дизайн: navy-текст, teal (lighthouse) акценты, amber не используется.
'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  ScanSearch, Loader2, Lock, AlertCircle, MapPin, Wallet, Sparkles, SearchX,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================
// === Типы данных (/api/search/semantic) ===
// ============================================================

interface SearchIntent {
  role: string | null;
  skills: string[];
  location: string | null;
  remote: boolean | null;
  salaryMin: number | null;
  seniority: 'junior' | 'middle' | 'senior' | 'lead' | null;
  raw: string;
}

interface SemanticJob {
  id: string;
  title: string;
  company: string;
  description: string;
  requiredSkills: string;
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string | null;
  location: string | null;
  growthScore: number;
  verificationStatus: string | null;
  relevance: number;
  matchedSkills: string[];
}

interface SemanticResponse {
  intent: SearchIntent;
  results: SemanticJob[];
  totalFound: number;
}

const SENIORITY_LABEL: Record<string, string> = {
  junior: 'джун', middle: 'мидл', senior: 'сеньор', lead: 'лид',
};

const MIN_QUERY_LENGTH = 3;
const DEBOUNCE_MS = 400;

// ============================================================
// === Утилиты ===
// ============================================================

function formatSalary(from: number | null, to: number | null): string | null {
  if (!from && !to) return null;
  const fmt = (n: number) => (n >= 1000 ? `${Math.round(n / 1000)}k` : String(n));
  if (from && to) return `${fmt(from)}–${fmt(to)} ₽`;
  if (from) return `от ${fmt(from)} ₽`;
  if (to) return `до ${fmt(to)} ₽`;
  return null;
}

/** Объяснение «почему найдено» — из полей интента и совпавших навыков. */
function buildWhy(intent: SearchIntent, job: SemanticJob): string {
  const parts: string[] = [];
  if (job.matchedSkills.length > 0) {
    parts.push(`совпали навыки: ${job.matchedSkills.slice(0, 4).join(', ')}`);
  }
  if (intent.role && job.title.toLowerCase().includes(intent.role.toLowerCase())) {
    parts.push(`роль «${intent.role}» из вашего запроса в заголовке`);
  }
  if (intent.remote !== null && job.location && /удал[её]н|remote/i.test(job.location)) {
    parts.push('вакансия удалённая, как вы просили');
  }
  if (intent.location && job.location?.toLowerCase().includes(intent.location.toLowerCase())) {
    parts.push(`локация: ${intent.location}`);
  }
  if (intent.salaryMin) {
    const jobSalary = job.salaryMax ?? job.salaryTo ?? job.salaryFrom ?? job.salaryMin ?? 0;
    if (jobSalary >= intent.salaryMin) parts.push('зарплата соответствует запросу');
  }
  if (parts.length === 0) {
    parts.push('прямое совпадение текста запроса с вакансией');
  }
  return parts.join(' · ');
}

// ============================================================
// === Основной компонент ===
// ============================================================

export function SemanticSearchBar() {
  const router = useRouter();
  // W2.4 (DEF-08): вакансия из semantic-поиска открывается в приложении

  const [query, setQuery] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [data, setData] = React.useState<SemanticResponse | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [authRequired, setAuthRequired] = React.useState(false);

  // Кэш ответов: защищает rate limit (10/час) от повторных одинаковых запросов
  const cacheRef = React.useRef<Map<string, SemanticResponse>>(new Map());
  const abortRef = React.useRef<AbortController | null>(null);

  // Debounced запрос — 400мс после последнего ввода
  React.useEffect(() => {
    const q = query.trim();

    if (q.length < MIN_QUERY_LENGTH) {
      setData(null);
      setError(null);
      setLoading(false);
      return;
    }

    const key = q.toLowerCase();
    const cached = cacheRef.current.get(key);
    if (cached) {
      setData(cached);
      setError(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    const t = setTimeout(async () => {
      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const res = await fetch('/api/search/semantic', {
          method: 'POST',
          credentials: 'include',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ query: q, limit: 8 }),
          signal: controller.signal,
        });
        const body = await res.json().catch(() => null);

        if (!res.ok) {
          if (res.status === 401) {
            setAuthRequired(true);
            setError('Войдите, чтобы использовать умный поиск');
          } else if (res.status === 429) {
            setError(body?.error ?? 'Лимит умного поиска исчерпан (10 запросов в час) — повторите позже');
          } else {
            setError(body?.error ?? 'Ошибка умного поиска');
          }
          setData(null);
          return;
        }

        setAuthRequired(false);
        const payload = body as SemanticResponse;
        setData(payload);
        cacheRef.current.set(key, payload);
      } catch (e) {
        if (e instanceof DOMException && e.name === 'AbortError') return;
        setError('Сеть недоступна');
        setData(null);
      } finally {
        setLoading(false);
      }
    }, DEBOUNCE_MS);

    return () => clearTimeout(t);
  }, [query]);

  const hasQuery = query.trim().length >= MIN_QUERY_LENGTH;
  const intent = data?.intent;

  return (
    <Card
      className="border-lighthouse/30 bg-lighthouse/[0.03]"
      aria-label="Умный семантический поиск"
    >
      <CardContent className="py-4 space-y-3">
        {/* Заголовок */}
        <div className="flex items-center gap-2">
          <ScanSearch className="w-5 h-5 text-lighthouse" aria-hidden="true" />
          <h2 className="text-base font-semibold text-[#1e3a8a] dark:text-blue-100">
            Умный поиск по смыслу
          </h2>
          <Badge variant="outline" className="bg-lighthouse/10 text-lighthouse border-lighthouse/30 text-xs">
            v6 AI
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground">
          Опишите задачу словами — поиск поймёт синонимы («питон» → Python), грейд, город, удалёнку и зарплату.
        </p>

        {/* Поле ввода */}
        <div className="relative">
          <ScanSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-lighthouse pointer-events-none" aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder='Например: «react разработчик в Москве от 200k удалённо»'
            aria-label="Запрос умного поиска"
            className={cn(
              'w-full h-10 rounded-md border border-input bg-background pl-9 pr-9 text-sm',
              'placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-lighthouse',
            )}
          />
          {loading && (
            <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-lighthouse animate-spin" aria-hidden="true" />
          )}
        </div>

        {/* 401 — Войдите */}
        {authRequired && (
          <div className="flex items-center gap-2 rounded-lg border border-dashed border-lighthouse/40 p-3 text-sm">
            <Lock className="w-4 h-4 text-lighthouse flex-shrink-0" aria-hidden="true" />
            <span>Умный поиск доступен после входа.</span>
            <button
              type="button"
              onClick={() => router.push('/')}
              className="font-medium text-lighthouse hover:underline ml-auto"
            >
              Войдите →
            </button>
          </div>
        )}

        {/* Ошибка (кроме 401) */}
        {error && !authRequired && (
          <div className="flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" aria-hidden="true" />
            <span>{error}</span>
          </div>
        )}

        {/* Скелетон загрузки */}
        {loading && !data && (
          <div className="space-y-2" aria-label="Идёт семантический поиск">
            <Skeleton className="h-4 w-64" />
            <Skeleton className="h-14 w-full" />
            <Skeleton className="h-14 w-full" />
          </div>
        )}

        {/* Разобранный интент */}
        {intent && !loading && (
          <div className="flex flex-wrap items-center gap-1.5" aria-label="Как поняли запрос">
            <span className="text-xs text-muted-foreground">Поняли как:</span>
            {intent.role && (
              <Badge variant="outline" className="text-xs border-lighthouse/40 text-lighthouse">
                роль: {intent.role}
              </Badge>
            )}
            {intent.skills.slice(0, 4).map((s) => (
              <Badge key={s} variant="secondary" className="text-xs">
                <Sparkles className="w-3 h-3 mr-1 text-lighthouse" aria-hidden="true" />
                {s}
              </Badge>
            ))}
            {intent.seniority && (
              <Badge variant="outline" className="text-xs">
                грейд: {SENIORITY_LABEL[intent.seniority] ?? intent.seniority}
              </Badge>
            )}
            {intent.remote && (
              <Badge variant="outline" className="text-xs">
                удалённо
              </Badge>
            )}
            {intent.location && (
              <Badge variant="outline" className="text-xs">
                <MapPin className="w-3 h-3 mr-1" aria-hidden="true" />
                {intent.location}
              </Badge>
            )}
            {intent.salaryMin && (
              <Badge variant="outline" className="text-xs">
                <Wallet className="w-3 h-3 mr-1" aria-hidden="true" />
                от {(intent.salaryMin / 1000).toFixed(0)}k ₽
              </Badge>
            )}
          </div>
        )}

        {/* Результаты */}
        {data && !loading && (
          <div className="space-y-2" aria-label={`Найдено вакансий: ${data.totalFound}`}>
            {data.results.length === 0 ? (
              <div className="flex flex-col items-center text-center py-6 text-muted-foreground">
                <SearchX className="w-8 h-8 mb-2 text-muted-foreground/60" aria-hidden="true" />
                <p className="text-sm">
                  По смыслу ничего не найдено — попробуйте переформулировать запрос.
                </p>
              </div>
            ) : (
              <>
                <p className="text-xs text-muted-foreground">
                  Найдено по смыслу: {data.totalFound} · релевантность объяснима для каждого результата
                </p>
                <ul className="space-y-2">
                  {data.results.map((job) => {
                    const salary = formatSalary(job.salaryFrom ?? job.salaryMin, job.salaryTo ?? job.salaryMax);
                    return (
                      <li key={job.id}>
                        <button
                          type="button"
                          onClick={() => router.push(`/?view=jobs&jobId=${job.id}`)}
                          className="block w-full text-left rounded-lg border bg-card p-3 hover:border-lighthouse/50 hover:shadow-sm transition"
                          aria-label={`Вакансия ${job.title} в ${job.company}, совпадение ${Math.round(job.relevance * 100)}%`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <span className="text-sm font-medium leading-snug">{job.title}</span>
                            <Badge
                              variant="outline"
                              className="text-xs flex-shrink-0 border-lighthouse/40 text-lighthouse tabular-nums"
                            >
                              {Math.round(job.relevance * 100)}%
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground mt-0.5 truncate">
                            {job.company}
                            {job.location ? ` · ${job.location}` : ''}
                            {salary ? ` · ${salary}` : ''}
                          </div>
                          {job.matchedSkills.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1.5">
                              {job.matchedSkills.slice(0, 5).map((s) => (
                                <Badge key={s} variant="secondary" className="text-xs px-1.5 py-0">
                                  {s}
                                </Badge>
                              ))}
                            </div>
                          )}
                          <p className="text-xs text-muted-foreground mt-1.5 flex items-start gap-1">
                            <Sparkles className="w-3 h-3 mt-0.5 text-lighthouse flex-shrink-0" aria-hidden="true" />
                            <span>
                              <span className="font-medium text-foreground/80">Почему найдено: </span>
                              {buildWhy(intent!, job)}
                            </span>
                          </p>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>
        )}

        {/* Подсказка до ввода */}
        {!hasQuery && !loading && !error && !data && (
          <div className="flex flex-wrap gap-1.5" aria-label="Примеры запросов">
            <span className="text-xs text-muted-foreground self-center">Попробуйте:</span>
            {['питон разработчик удалённо', 'фронтенд react в спб', 'аналитик от 200k'].map((example) => (
              <button
                key={example}
                type="button"
                onClick={() => setQuery(example)}
                aria-label={`Подставить пример: ${example}`}
                className="text-xs rounded-full border border-lighthouse/30 px-2.5 py-0.5 text-lighthouse hover:bg-lighthouse/10 transition"
              >
                {example}
              </button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
