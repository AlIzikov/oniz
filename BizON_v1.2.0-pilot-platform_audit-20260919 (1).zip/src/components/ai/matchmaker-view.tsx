// BizON — AI-Matchmaker View (5 рукопожатий)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { toast } from '@/hooks/use-toast';
import type { MatchmakerResult } from '@/lib/types';
import { Search, Sparkles, ArrowRight, Loader2, Network, Copy, Check, Send } from 'lucide-react';

export function MatchmakerView() {
  const { setProfileUserId } = useAppStore();
  const [query, setQuery] = React.useState('');
  const [results, setResults] = React.useState<any[]>([]);
  const [searching, setSearching] = React.useState(false);
  const [target, setTarget] = React.useState<any | null>(null);
  const [matchResult, setMatchResult] = React.useState<MatchmakerResult | null>(null);
  const [matching, setMatching] = React.useState(false);
  const [copied, setCopied] = React.useState(false);
  const [sendingIntro, setSendingIntro] = React.useState(false);
  const setView = useAppStore((s) => s.setView);

  React.useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      return;
    }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await api<{ users: any[] }>(`/api/users/search?q=${encodeURIComponent(query)}&limit=10`);
        setResults(res.users);
      } catch {}
      setSearching(false);
    }, 250);
    return () => clearTimeout(t);
  }, [query]);

  async function handleFindMatch(toUserId: string) {
    setMatching(true);
    setMatchResult(null);
    try {
      const res = await api<MatchmakerResult>('/api/ai/matchmaker', {
        method: 'POST',
        body: JSON.stringify({ toUserId }),
      });
      setMatchResult(res);
      if (res.found) {
        toast({ title: `Путь найден через ${res.path.length - 1} рукопожатий` });
      } else {
        toast({ title: 'Путь не найден', description: 'Граф доверия не связывает вас с этим пользователем в пределах 5 рукопожатий', variant: 'destructive' });
      }
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setMatching(false);
    }
  }

  function copyIntro() {
    if (matchResult?.introTemplate) {
      navigator.clipboard.writeText(matchResult.introTemplate);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  // P1-5: отправить интро напрямую через мессенджер (без необходимости копировать)
  async function sendIntro() {
    if (!matchResult?.introTemplate || !target) return;
    setSendingIntro(true);
    try {
      const targetId = matchResult.path[matchResult.path.length - 1].userId;
      await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId: targetId, content: matchResult.introTemplate }),
      });
      toast({ title: 'Интро отправлено!', description: 'Перейдите в Сообщения для продолжения диалога.' });
      setView('messages');
    } catch (e: any) {
      toast({ title: 'Не удалось отправить', description: e.message, variant: 'destructive' });
    } finally {
      setSendingIntro(false);
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-primary" /> AI-Matchmaker
        </h1>
        <p className="text-sm text-muted-foreground">
          Алгоритм «5 рукопожатий» — поиск кратчайшего пути в графе доверия
        </p>
      </div>

      <Card>
        <CardContent className="p-4 space-y-4">
          <div className="space-y-1">
            <Label htmlFor="m-search">Кого ищем?</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="m-search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Имя, должность или город..."
                className="pl-9"
              />
              {searching && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin" />}
            </div>
          </div>

          {results.length > 0 && (
            <div className="space-y-1 max-h-72 overflow-y-auto scroll-area-thin">
              {results.map((u) => (
                <button
                  key={u.id}
                  onClick={() => { setTarget(u); setQuery(''); setResults([]); setMatchResult(null); }}
                  className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-accent text-left transition"
                >
                  <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="sm" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{u.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{u.title} {u.location ? `· ${u.location}` : ''}</div>
                  </div>
                  <TrustBadge ipScore={u.ipScore} level={u.level} size="sm" />
                </button>
              ))}
            </div>
          )}

          {target && (
            <div className="p-3 rounded-lg border bg-accent/20">
              <div className="flex items-center gap-3 mb-3">
                <UserAvatar name={target.name} avatarUrl={target.avatarUrl} size="md" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{target.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{target.title}</div>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleFindMatch(target.id)}
                  disabled={matching}
                >
                  {matching ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Network className="w-4 h-4 mr-1" />}
                  Найти путь
                </Button>
              </div>
              <Button variant="ghost" size="sm" onClick={() => { setTarget(null); setMatchResult(null); }}>
                Сменить цель
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Результат */}
      {matching && (
        <Card>
          <CardContent className="p-6 text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-primary" />
            <p className="text-sm text-muted-foreground">Идёт поиск пути в графе доверия (BFS, макс. глубина 5)...</p>
          </CardContent>
        </Card>
      )}

      {matchResult && !matching && (
        <MatchResultView result={matchResult} onUserClick={setProfileUserId} onCopy={copyIntro} copied={copied} onSend={sendIntro} sending={sendingIntro} />
      )}
    </div>
  );
}

function MatchResultView({ result, onUserClick, onCopy, copied, onSend, sending }: {
  result: MatchmakerResult;
  onUserClick: (id: string) => void;
  onCopy: () => void;
  copied: boolean;
  onSend: () => void;
  sending: boolean;
}) {
  if (!result.found) {
    return (
      <Card className="border-destructive/30 bg-destructive/5">
        <CardContent className="p-6 text-center">
          <Network className="w-10 h-10 mx-auto mb-2 text-muted-foreground" />
          <h3 className="font-semibold mb-1">Путь не найден</h3>
          <p className="text-sm text-muted-foreground">
            В графе доверия нет связи между вами и этим пользователем в пределах 5 рукопожатий.
            Попробуйте расширить сеть — присоединяйтесь к проектам и подтверждайте навыки.
          </p>
        </CardContent>
      </Card>
    );
  }

  const handshakes = result.path.length - 1;
  return (
    <div className="space-y-3">
      <Card className="bg-gradient-to-br from-primary/5 to-accent/30 border-primary/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider">Найдено за</div>
              <div className="text-2xl font-bold text-primary">{handshakes} {pluralHandshakes(handshakes)}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground uppercase tracking-wider">Уверенность</div>
              <div className="text-2xl font-bold">{Math.round(result.confidence * 100)}%</div>
            </div>
          </div>

          {/* Path visualization */}
          <div className="flex items-center gap-1 overflow-x-auto pb-2 scroll-area-thin">
            {result.path.map((u, i) => (
              <React.Fragment key={u.userId}>
                <button
                  onClick={() => onUserClick(u.userId)}
                  className="flex flex-col items-center gap-1 min-w-[80px] hover:bg-accent/50 p-2 rounded-lg transition"
                >
                  <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="md" />
                  <div className="text-xs font-medium text-center truncate w-full">{u.name}</div>
                  <TrustBadge ipScore={u.ipScore} level="basic" size="sm" showScore={false} />
                  {i === 0 && <Badge variant="outline" className="text-xs px-1">Вы</Badge>}
                  {i === result.path.length - 1 && <Badge variant="default" className="text-xs px-1">Цель</Badge>}
                  {result.introducerId === u.userId && <Badge variant="secondary" className="text-xs px-1">Посредник</Badge>}
                </button>
                {i < result.path.length - 1 && (
                  <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                )}
              </React.Fragment>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Intro template */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-semibold flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" /> AI-сгенерированное интро-сообщение
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={onCopy}>
                {copied ? <Check className="w-3 h-3 mr-1" /> : <Copy className="w-3 h-3 mr-1" />}
                {copied ? 'Скопировано' : 'Копировать'}
              </Button>
              {/* P1-5: прямая отправка интро через мессенджер */}
              <Button
                size="sm"
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
                onClick={onSend}
                disabled={sending}
              >
                {sending ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Send className="w-3 h-3 mr-1" />}
                {sending ? 'Отправка...' : 'Отправить интро'}
              </Button>
            </div>
          </div>
          <pre className="text-xs whitespace-pre-wrap font-sans bg-muted/50 p-3 rounded-md border">
{result.introTemplate}
          </pre>
          <p className="text-xs text-muted-foreground mt-2">
            Событие IntroRequestSent зафиксировано в Trust Stream.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function pluralHandshakes(n: number) {
  if (n === 1) return 'рукопожатие';
  if (n >= 2 && n <= 4) return 'рукопожатия';
  return 'рукопожатий';
}
