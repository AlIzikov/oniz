// BizON — AI-Career-Agent View
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import type { CareerAgentResponse } from '@/lib/types';
import { CareerSimulator } from '@/components/career-simulator/career-simulator';
import { LumenPaywallDialog, extractLumenNeed } from '@/components/common/lumen-paywall';
import { Brain, Loader2, Sparkles, TrendingUp, ArrowRight, Lightbulb } from 'lucide-react';

export function CareerAgentView() {
  const { user, setView } = useAppStore();
  const [result, setResult] = React.useState<CareerAgentResponse | null>(null);
  const [loading, setLoading] = React.useState(false);
  // Волна 14: paywall люменов — открывается при 402 (не хватает люменов)
  const [paywall, setPaywall] = React.useState<{ need: number; have: number } | null>(null);
  const isFree = user?.subscriptionTier === 'free';

  async function run() {
    setLoading(true);
    setResult(null);
    try {
      const res = await api<CareerAgentResponse>('/api/ai/career', { method: 'POST' });
      setResult(res);
      toast({ title: 'AI-Career-Agent готов' });
    } catch (e: any) {
      // Волна 14: 402 — не хватает люменов → диалог пополнения
      const lumenNeed = extractLumenNeed(e);
      if (lumenNeed) {
        setPaywall(lumenNeed);
        return;
      }
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Волна 14: paywall — не хватает люменов на ИИ-действие */}
      <LumenPaywallDialog
        open={paywall !== null}
        onOpenChange={(o) => { if (!o) setPaywall(null); }}
        need={paywall?.need ?? 1}
        have={paywall?.have ?? 0}
        onToppedUp={() => { setPaywall(null); run(); }}
      />
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Brain className="w-6 h-6 text-primary" /> AI-Career-Agent
        </h1>
        <p className="text-sm text-muted-foreground">
          LLM анализирует ваш профиль, навыки и репутацию, строит персональную карьерную траекторию
          {isFree && ' · на Free-тарифе — 1 люмен за запуск (1 ₽ = 1 люмен)'}
        </p>
      </div>

      <Card className="bg-gradient-to-br from-primary/5 to-accent/30 border-primary/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="min-w-0">
              <div className="text-sm font-medium">{user?.name}</div>
              <div className="text-xs text-muted-foreground">
                {user?.title} · IP-score {user?.ipScore}/100 · уровень: {user?.level}
              </div>
            </div>
            <Button onClick={run} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Sparkles className="w-4 h-4 mr-1" />}
              {loading ? 'Анализирую...' : isFree ? 'Запустить анализ · 1 люмен' : 'Запустить анализ'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* === Career Simulator «Что если?» (Task 10-d) — без LLM, на данных юзера === */}
      <CareerSimulator />

      {loading && (
        <div className="space-y-3">
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
      )}

      {result && !loading && (
        <>
          {/* Summary */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-sm font-semibold mb-2">
                <Brain className="w-4 h-4 text-primary" /> Резюме
              </div>
              <p className="text-sm text-foreground/80">{result.summary}</p>
            </CardContent>
          </Card>

          {/* Career Map */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-sm font-semibold mb-3">
                <TrendingUp className="w-4 h-4 text-primary" /> Карта карьеры
              </div>
              <div className="space-y-3">
                {result.careerMap.map((stage, i) => (
                  <div key={i} className="relative pl-6 pb-3 border-l-2 border-primary/30 last:border-l-0 last:pb-0">
                    <div className="absolute left-0 top-0 -translate-x-1/2 w-3 h-3 rounded-full bg-primary" />
                    <div className="flex items-start justify-between gap-3 mb-1">
                      <div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">{stage.stage}</div>
                        <div className="font-medium text-sm">{stage.role}</div>
                      </div>
                      <Badge variant="secondary" className="text-xs">{Math.round(stage.score * 100)}% готовность</Badge>
                    </div>
                    {stage.recommendedSkills && stage.recommendedSkills.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {stage.recommendedSkills.map((s) => (
                          <Badge key={s} variant="outline" className="text-xs">{s}</Badge>
                        ))}
                      </div>
                    )}
                    {i < result.careerMap.length - 1 && (
                      <ArrowRight className="hidden sm:block w-3 h-3 text-muted-foreground mt-2 rotate-90" />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-sm font-semibold mb-3">
                <Lightbulb className="w-4 h-4 text-primary" /> Рекомендации
              </div>
              <ul className="space-y-2">
                {result.recommendations.map((r, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <span className="w-5 h-5 rounded-full bg-primary/15 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0">
                      {i + 1}
                    </span>
                    <span className="text-foreground/80">{r}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setView('jobs')} className="flex-1">
              <TrendingUp className="w-4 h-4 mr-1" /> Смотреть вакансии
            </Button>
            <Button variant="outline" onClick={() => setView('profile')} className="flex-1">
              Открыть профиль
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
