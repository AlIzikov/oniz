// BizON — Communities View (сообщества)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import type { CommunityPublic } from '@/lib/types';
import { MessagesSquare, Users, ArrowLeft, Plus, Check, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

const CATEGORIES: Array<{ id: string; label: string }> = [
  { id: 'all', label: 'Все' },
  { id: 'ml', label: 'ML/AI' },
  { id: 'frontend', label: 'Frontend' },
  { id: 'backend', label: 'Backend' },
  { id: 'devops', label: 'DevOps' },
  { id: 'product', label: 'Продукт' },
  { id: 'design', label: 'Дизайн' },
  { id: 'career', label: 'Карьера' },
  { id: 'other', label: 'Другое' },
];

export function CommunitiesView() {
  const setView = useAppStore((s) => s.setView);
  const setSelectedCommunitySlug = useAppStore((s) => (s as any).setSelectedCommunitySlug);
  const [communities, setCommunities] = React.useState<CommunityPublic[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filterCategory, setFilterCategory] = React.useState('all');

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const cat = filterCategory !== 'all' ? `?category=${filterCategory}` : '';
      const res = await api<{ communities: CommunityPublic[] }>(`/api/communities${cat}`);
      setCommunities(res.communities);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [filterCategory]);

  React.useEffect(() => { load(); }, [load]);

  async function handleJoin(slug: string, isMember: boolean) {
    try {
      if (isMember) {
        await api(`/api/communities/${slug}/join`, { method: 'DELETE' });
        toast({ title: 'Вы покинули сообщество' });
      } else {
        await api(`/api/communities/${slug}/join`, { method: 'POST' });
        toast({ title: 'Вы вступили в сообщество' });
      }
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-bold">Сообщества</h1>
          <p className="text-sm text-muted-foreground">Тематические группы по интересам</p>
        </div>
      </div>

      {/* Category filter */}
      <div className="flex gap-1.5 flex-wrap">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setFilterCategory(cat.id)}
            className={cn(
              'px-3 py-1 text-xs rounded-full border transition',
              filterCategory === cat.id ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary'
            )}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}
        </div>
      ) : communities.length === 0 ? (
        <Card className="p-8 text-center">
          <MessagesSquare className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">Сообществ пока нет</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {communities.map((c) => (
            <Card
              key={c.id}
              className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => { if (setSelectedCommunitySlug) setSelectedCommunitySlug(c.slug); }}
            >
              <CardContent className="p-4 flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  {c.logoUrl ? (
                    <img src={c.logoUrl} alt="" className="w-full h-full rounded-lg object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
                  ) : (
                    <MessagesSquare className="w-5 h-5 text-primary" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-base truncate">{c.name}</h3>
                    {c.visibility === 'private' && <Lock className="w-3 h-3 text-muted-foreground" />}
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2 mt-0.5">{c.description}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-0.5"><Users className="w-3 h-3" /> {c.membersCount}</span>
                    <span>·</span>
                    <span>{c.postsCount} постов</span>
                    {c.minIpScore > 0 && <Badge variant="outline" className="text-xs">IP ≥ {c.minIpScore}</Badge>}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant={c.isMember ? 'outline' : 'default'}
                  onClick={(e) => { e.stopPropagation(); handleJoin(c.slug, c.isMember); }}
                  className="flex-shrink-0"
                >
                  {c.isMember ? <><Check className="w-3 h-3 mr-1" />Участник</> : 'Вступить'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
