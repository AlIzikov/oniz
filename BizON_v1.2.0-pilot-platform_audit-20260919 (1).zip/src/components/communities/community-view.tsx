// BizON — Community Detail View (страница отдельного сообщества)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import type { CommunityDetail } from '@/lib/types';
import {
  MessagesSquare, Users, ChevronLeft, Plus, Check, Lock, Loader2, Crown, Pin,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function CommunityView() {
  const slug = useAppStore((s) => (s as any).selectedCommunitySlug);
  const setView = useAppStore((s) => s.setView);
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const [data, setData] = React.useState<CommunityDetail | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [postContent, setPostContent] = React.useState('');
  const [posting, setPosting] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!slug) return;
    setLoading(true);
    try {
      const res = await api<{ community: CommunityDetail }>(`/api/communities/${slug}`);
      setData(res.community);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [slug]);

  React.useEffect(() => { load(); }, [load]);

  async function handleJoin() {
    if (!data) return;
    try {
      if (data.isMember) {
        await api(`/api/communities/${data.slug}/join`, { method: 'DELETE' });
        toast({ title: 'Вы покинули сообщество' });
      } else {
        await api(`/api/communities/${data.slug}/join`, { method: 'POST' });
        toast({ title: 'Вы вступили в сообщество' });
      }
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handlePost() {
    if (!data || !postContent.trim()) return;
    setPosting(true);
    try {
      await api(`/api/communities/${data.slug}/posts`, {
        method: 'POST',
        body: JSON.stringify({ content: postContent, tags: [] }),
      });
      setPostContent('');
      toast({ title: 'Пост опубликован' });
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setPosting(false);
    }
  }

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-20 w-full rounded-xl" />
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
    );
  }

  const c = data;

  return (
    <div className="space-y-4">
      <Button variant="ghost" size="sm" onClick={() => setView('communities')}>
        <ChevronLeft className="w-4 h-4 mr-1" /> Все сообщества
      </Button>

      {/* Hero */}
      <Card className="overflow-hidden">
        {c.coverUrl && (
          <div className="h-24 bg-muted">
            <img src={c.coverUrl} alt="" className="w-full h-full object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} />
          </div>
        )}
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              {c.logoUrl ? (
                <img src={c.logoUrl} alt="" className="w-full h-full rounded-xl object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
              ) : (
                <MessagesSquare className="w-7 h-7 text-primary" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold truncate">{c.name}</h1>
                {c.visibility === 'private' && <Lock className="w-4 h-4 text-muted-foreground" />}
              </div>
              <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {c.membersCount}</span>
                <span>·</span>
                <span>{c.postsCount} постов</span>
                {c.minIpScore > 0 && <Badge variant="outline" className="text-xs">IP ≥ {c.minIpScore}</Badge>}
              </div>
              <p className="text-sm text-foreground/80 mt-2">{c.description}</p>
              <div className="flex items-center gap-2 mt-3">
                <Button size="sm" variant={c.isMember ? 'outline' : 'default'} onClick={handleJoin}>
                  {c.isMember ? <><Check className="w-3 h-3 mr-1" />Участник</> : 'Вступить'}
                </Button>
                {c.memberRole === 'owner' && <Badge variant="secondary" className="text-xs"><Crown className="w-3 h-3 mr-1" />Владелец</Badge>}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Composer (только для участников) */}
      {c.isMember && (
        <Card className="p-4">
          <Textarea
            value={postContent}
            onChange={(e) => setPostContent(e.target.value)}
            placeholder="Поделитесь мыслями с сообществом..."
            className="min-h-[80px] resize-none"
          />
          <div className="flex justify-end mt-2">
            <Button size="sm" onClick={handlePost} disabled={!postContent.trim() || posting}>
              {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Plus className="w-4 h-4 mr-1" />Опубликовать</>}
            </Button>
          </div>
        </Card>
      )}

      {/* Posts */}
      <div className="space-y-3">
        {c.posts.length === 0 ? (
          <Card className="p-8 text-center">
            <MessagesSquare className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground">Постов пока нет. Будьте первым!</p>
          </Card>
        ) : (
          c.posts.map((p) => (
            <Card key={p.id} className={cn('p-4', p.isPinned && 'border-lighthouse/40 bg-lighthouse-gradient-soft')}>
              {p.isPinned && (
                <Badge variant="outline" className="mb-2 text-xs gap-1">
                  <Pin className="w-3 h-3" /> Закреплено
                </Badge>
              )}
              <div className="flex gap-3">
                <button onClick={() => setProfileUserId(p.author.id)}>
                  <UserAvatar name={p.author.name} avatarUrl={p.author.avatarUrl} size="md" />
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <button onClick={() => setProfileUserId(p.author.id)} className="font-medium text-sm hover:underline">
                      {p.author.name}
                    </button>
                    <span className="text-xs text-muted-foreground">{formatRelative(p.createdAt)}</span>
                  </div>
                  <div className="text-sm whitespace-pre-wrap leading-relaxed">{p.content}</div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Members */}
      {c.members.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="w-4 h-4 text-lighthouse" /> Участники ({c.membersCount})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {c.members.map((m) => (
                <button
                  key={m.userId}
                  onClick={() => setProfileUserId(m.userId)}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent transition text-left"
                >
                  <UserAvatar name={m.user.name} avatarUrl={m.user.avatarUrl} size="sm" />
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{m.user.name}</div>
                    <div className="text-xs text-muted-foreground">{m.role === 'owner' ? 'Владелец' : m.role === 'moderator' ? 'Модератор' : 'Участник'}</div>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function formatRelative(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  if (days < 7) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU');
}
