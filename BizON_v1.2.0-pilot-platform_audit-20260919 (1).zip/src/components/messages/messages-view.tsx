// BizON — Messages View (мессенджер, направление А: реалтайм)
// Реалтайм: socket.io chat-service (транспорт), каноничное хранение — REST.
// Доставка message:new / conversation:activity, typing, read-receipts, presence.
'use client';
import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { toast } from '@/hooks/use-toast';
import { MessageSquare, Send, ChevronLeft, Loader2, Check, CheckCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import { io, type Socket } from 'socket.io-client';

interface Conv {
  id: string;
  otherUser: { id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number; level: string };
  lastMessage: { content: string; authorId: string; createdAt: string } | null;
  unreadCount: number;
}

interface RtMessage {
  id: string;
  content: string;
  authorId: string;
  isRead?: boolean;
  createdAt: string;
  author?: { id: string; name: string; avatarUrl: string | null };
}

type ConnState = 'connecting' | 'online' | 'offline';

const timeOf = (iso: string) => {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? '' : d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
};

export function MessagesView() {
  const { user, setProfileUserId } = useAppStore();
  const [conversations, setConversations] = React.useState<Conv[]>([]);
  const [activeConv, setActiveConv] = React.useState<Conv | null>(null);
  const [messages, setMessages] = React.useState<RtMessage[]>([]);
  const [text, setText] = React.useState('');
  const [loading, setLoading] = React.useState(true);
  const [sending, setSending] = React.useState(false);
  const [connState, setConnState] = React.useState<ConnState>('connecting');
  const [peerTyping, setPeerTyping] = React.useState(false);
  const [peerOnline, setPeerOnline] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  const socketRef = React.useRef<Socket | null>(null);
  const activeConvRef = React.useRef<Conv | null>(null);
  const typingSentAtRef = React.useRef(0);
  const typingStopTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const peerTypingTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const scrollToBottom = React.useCallback(() => {
    setTimeout(() => scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight), 80);
  }, []);

  const loadConvs = React.useCallback(async () => {
    try {
      const res = await api<{ conversations: Conv[] }>('/api/messages');
      setConversations(res.conversations);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);
  const loadConvsRef = React.useRef(loadConvs);
  loadConvsRef.current = loadConvs;

  React.useEffect(() => { loadConvs(); }, [loadConvs]);

  // ===== Socket: одно подключение на монтировании =====
  React.useEffect(() => {
    // Путь и адрес — по контракту Caddy: путь '/', порт только через XTransformPort.
    const socket = io('/?XTransformPort=3003', {
      withCredentials: true,
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 10000,
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      setConnState('online');
      // после (ре)коннекта — вернуться в активную комнату
      const conv = activeConvRef.current;
      if (conv) {
        socket.emit('conversation:join', { conversationId: conv.id });
        socket.emit('conversation:read', { conversationId: conv.id });
      }
    });
    socket.on('disconnect', () => setConnState('offline'));
    socket.on('connect_error', () => setConnState('offline'));

    // Новое сообщение: только для открытого диалога (комнату мы джойним при открытии)
    socket.on('message:new', (payload: { conversationId: string; message: RtMessage }) => {
      if (payload?.conversationId !== activeConvRef.current?.id) return;
      const msg = payload.message;
      setMessages((prev) => (prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]));
      scrollToBottom();
      // подтверждение автору, что мы прочитали (в БД отметит следующий REST GET)
      socket.emit('conversation:read', { conversationId: payload.conversationId });
    });

    // Активность диалога (обоим участникам, их личные комнаты): список + unread
    socket.on(
      'conversation:activity',
      (p: { conversationId: string; lastMessage: { content: string; authorId: string; createdAt: string }; message?: RtMessage }) => {
        const me = useAppStore.getState().user;
        const isActive = activeConvRef.current?.id === p.conversationId;
        setConversations((prev) => {
          if (!prev.some((c) => c.id === p.conversationId)) {
            // новый диалог, которого нет в списке — подтягиваем список
            queueMicrotask(() => loadConvsRef.current());
            return prev;
          }
          return prev.map((c) => {
            if (c.id !== p.conversationId) return c;
            const isMine = p.lastMessage?.authorId === me?.id;
            const bump = !isActive && !isMine && p.message && p.message.isRead === false ? 1 : 0;
            return {
              ...c,
              lastMessage: p.lastMessage ?? c.lastMessage,
              unreadCount: isActive ? 0 : c.unreadCount + bump,
            };
          });
        });
      },
    );

    // Партнёр печатает
    socket.on('conversation:typing', (p: { conversationId: string; userId: string; isTyping: boolean }) => {
      const me = useAppStore.getState().user;
      if (p?.conversationId !== activeConvRef.current?.id || p.userId === me?.id) return;
      setPeerTyping(p.isTyping);
      if (p.isTyping) {
        if (peerTypingTimerRef.current) clearTimeout(peerTypingTimerRef.current);
        peerTypingTimerRef.current = setTimeout(() => setPeerTyping(false), 4000); // страховка
      } else if (peerTypingTimerRef.current) {
        clearTimeout(peerTypingTimerRef.current);
      }
    });

    // Мои сообщения прочитаны
    socket.on('conversation:read', (p: { conversationId: string; readerId: string }) => {
      const me = useAppStore.getState().user;
      if (p?.conversationId !== activeConvRef.current?.id || p.readerId === me?.id) return;
      setMessages((prev) => prev.map((m) => (m.authorId === me?.id && !m.isRead ? { ...m, isRead: true } : m)));
    });

    // Presence партнёра
    socket.on('presence:state', (p: { conversationId: string; userId: string; online: boolean }) => {
      if (p?.conversationId !== activeConvRef.current?.id) return;
      if (p.userId === activeConvRef.current?.otherUser.id) setPeerOnline(p.online);
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
      if (typingStopTimerRef.current) clearTimeout(typingStopTimerRef.current);
      if (peerTypingTimerRef.current) clearTimeout(peerTypingTimerRef.current);
    };
  }, [scrollToBottom]);

  async function openConv(conv: Conv) {
    setActiveConv(conv);
    activeConvRef.current = conv;
    setPeerTyping(false);
    setPeerOnline(false);
    try {
      const res = await api<{ messages: RtMessage[] }>(`/api/messages/${conv.id}`);
      setMessages(res.messages);
      setConversations((prev) => prev.map((c) => (c.id === conv.id ? { ...c, unreadCount: 0 } : c)));
      scrollToBottom();
      // реалтайм: вход в комнату диалога (членство проверит сервер) + read-receipt автору
      socketRef.current?.emit('conversation:join', { conversationId: conv.id });
      socketRef.current?.emit('conversation:read', { conversationId: conv.id });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  function leaveActiveConv() {
    const conv = activeConvRef.current;
    if (conv) socketRef.current?.emit('conversation:leave', { conversationId: conv.id });
    activeConvRef.current = null;
    setActiveConv(null);
    setPeerTyping(false);
    setPeerOnline(false);
  }

  function emitTyping(isTyping: boolean) {
    const socket = socketRef.current;
    const conv = activeConvRef.current;
    if (!socket || !conv || connState !== 'online') return;
    socket.emit('conversation:typing', { conversationId: conv.id, isTyping });
  }

  function onTextChange(v: string) {
    setText(v);
    const hasText = v.trim().length > 0;
    const now = Date.now();
    if (hasText && now - typingSentAtRef.current > 1500) {
      typingSentAtRef.current = now;
      emitTyping(true);
    }
    if (typingStopTimerRef.current) clearTimeout(typingStopTimerRef.current);
    typingStopTimerRef.current = setTimeout(
      () => {
        if (typingSentAtRef.current) emitTyping(false);
        typingSentAtRef.current = 0;
      },
      hasText ? 2200 : 0,
    );
    if (!hasText && typingSentAtRef.current) {
      emitTyping(false);
      typingSentAtRef.current = 0;
    }
  }

  async function send() {
    if (!text.trim() || !activeConv || sending) return;
    setSending(true);
    if (typingSentAtRef.current) {
      emitTyping(false);
      typingSentAtRef.current = 0;
    }
    try {
      const res = await api<{ message: RtMessage; conversationId: string }>('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId: activeConv.otherUser.id, content: text.trim() }),
      });
      setText('');
      setMessages((prev) => (prev.some((m) => m.id === res.message.id) ? prev : [...prev, res.message]));
      scrollToBottom();
      // список диалогов обновит conversation:activity от сервера
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  const connBadge =
    connState === 'online'
      ? { label: 'В сети', cls: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300' }
      : connState === 'connecting'
        ? { label: 'Подключение…', cls: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300' }
        : { label: 'Офлайн', cls: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300' };

  if (loading) {
    return (
      <div className="space-y-3">
        <h1 className="text-2xl font-bold">Сообщения</h1>
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-16 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <h1 className="text-2xl font-bold">Сообщения</h1>
        <span aria-live="polite" className={cn('text-xs px-2 py-0.5 rounded-full font-medium', connBadge.cls)}>
          <span
            className={cn(
              'inline-block w-1.5 h-1.5 rounded-full mr-1.5 align-middle',
              connState === 'online' ? 'bg-emerald-500' : connState === 'connecting' ? 'bg-amber-500' : 'bg-red-500',
            )}
          />
          {connBadge.label}
        </span>
      </div>
      <div className="grid md:grid-cols-[300px_1fr] gap-4 h-[calc(100vh-240px)] min-h-[420px]">
        {/* Список диалогов */}
        <div className={cn('space-y-1 overflow-y-auto scroll-area-thin', activeConv && 'hidden md:block')}>
          {conversations.length === 0 ? (
            <Card className="p-8 text-center">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground text-sm">Нет диалогов</p>
            </Card>
          ) : (
            conversations.map((c) => (
              <button
                key={c.id}
                onClick={() => openConv(c)}
                className={cn(
                  'w-full flex items-center gap-3 p-3 rounded-lg transition text-left',
                  activeConv?.id === c.id ? 'bg-accent' : 'hover:bg-accent/50',
                )}
              >
                <UserAvatar name={c.otherUser.name} avatarUrl={c.otherUser.avatarUrl} size="sm" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{c.otherUser.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{c.lastMessage?.content ?? 'Нет сообщений'}</div>
                </div>
                {c.unreadCount > 0 && (
                  <span className="bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">{c.unreadCount}</span>
                )}
              </button>
            ))
          )}
        </div>
        {/* Активный диалог */}
        {activeConv ? (
          <Card className="flex flex-col overflow-hidden">
            <div className="flex items-center gap-3 p-3 border-b">
              <Button variant="ghost" size="sm" className="md:hidden" onClick={leaveActiveConv}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <button onClick={() => setProfileUserId(activeConv.otherUser.id)}>
                <UserAvatar name={activeConv.otherUser.name} avatarUrl={activeConv.otherUser.avatarUrl} size="sm" />
              </button>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate flex items-center gap-2">
                  {activeConv.otherUser.name}
                  <span
                    title={peerOnline ? 'В сети' : 'Не в сети'}
                    aria-label={peerOnline ? 'В сети' : 'Не в сети'}
                    className={cn('inline-block w-2 h-2 rounded-full flex-shrink-0', peerOnline ? 'bg-emerald-500' : 'bg-muted-foreground/30')}
                  />
                </div>
                <div className="text-xs text-muted-foreground truncate" aria-live="polite">
                  {peerTyping ? 'печатает…' : activeConv.otherUser.title}
                </div>
              </div>
              <TrustBadge ipScore={activeConv.otherUser.ipScore} level={activeConv.otherUser.level} size="sm" />
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 scroll-area-thin">
              {messages.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">Нет сообщений — напишите первым</p>}
              {messages.map((m) => {
                const mine = m.authorId === user?.id;
                return (
                  <div key={m.id} className={cn('flex gap-2 max-w-[80%]', mine ? 'ml-auto flex-row-reverse' : '')}>
                    <div className={cn('rounded-2xl px-3 py-2 text-sm', mine ? 'bg-primary text-primary-foreground' : 'bg-muted')}>
                      <div className="whitespace-pre-wrap break-words">{m.content}</div>
                      <div className={cn('flex items-center gap-1 justify-end text-[10px] mt-0.5', mine ? 'text-primary-foreground/70' : 'text-muted-foreground')}>
                        {timeOf(m.createdAt)}
                        {mine && (m.isRead ? <CheckCheck className="w-3 h-3 text-emerald-500 dark:text-emerald-400" aria-label="Прочитано" /> : <Check className="w-3 h-3" aria-label="Отправлено" />)}
                      </div>
                    </div>
                  </div>
                );
              })}
              {peerTyping && (
                <div className="flex">
                  <div className="rounded-2xl px-3 py-2 bg-muted text-xs text-muted-foreground" aria-live="polite">
                    печатает…
                  </div>
                </div>
              )}
            </div>
            <div className="flex gap-2 p-3 border-t">
              <Input
                value={text}
                onChange={(e) => onTextChange(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && send()}
                placeholder="Сообщение..."
                className="flex-1"
                maxLength={2000}
                aria-label="Текст сообщения"
              />
              <Button size="icon" onClick={send} disabled={!text.trim() || sending} aria-label="Отправить">
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </Button>
            </div>
          </Card>
        ) : (
          <CardContent className="hidden md:flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <MessageSquare className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm">Выберите диалог</p>
            </div>
          </CardContent>
        )}
      </div>
    </div>
  );
}
