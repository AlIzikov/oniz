// BizON — DAO View (Фаза 2 — голосования)
'use client';
import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/hooks/use-toast';
import { Vote, ThumbsUp, ThumbsDown, Minus, Clock, Loader2, Plus, Users } from 'lucide-react';
import { cn } from '@/lib/utils';

export function DAOView() {
  const { user } = useAppStore();
  const [proposals, setProposals] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [createOpen, setCreateOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ proposals: any[] }>('/api/dao?status=all');
      setProposals(res.proposals);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally { setLoading(false); }
  }, []);

  React.useEffect(() => { load(); }, [load]);

  async function vote(proposalId: string, vote: 'for' | 'against' | 'abstain') {
    try {
      const res = await api(`/api/dao/${proposalId}/vote`, { method: 'POST', body: JSON.stringify({ vote }) });
      toast({ title: `Голос учтён (вес: ${res.weight})`, description: 'Чем выше IP-score, тем больше вес' });
      load();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  if (loading) return <Skeleton className="h-48 w-full rounded-xl" />;

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Vote className="w-6 h-6 text-lighthouse" /> DAO</h1>
          <p className="text-sm text-muted-foreground">Голосования. Вес голоса = ваш IP-score.</p>
        </div>
        {user && user.ipScore >= 31 && (
          <Button size="sm" onClick={() => setCreateOpen(true)}><Plus className="w-4 h-4 mr-1" /> Предложить</Button>
        )}
      </div>

      {/* Info */}
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Vote className="w-5 h-5 text-lighthouse mt-0.5" />
            <div className="text-sm">
              <div className="font-medium">Доверие, а не капитал</div>
              <p className="text-xs text-muted-foreground mt-1">
                В традиционных DAO голос зависит от количества токенов. В BizON — от вашего IP-score.
                Эксперт (71+) имеет в 2× больше влияния, чем новичок (0-30). Это <strong>демократия доверия</strong>.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {user && user.ipScore < 31 && (
        <Card className="p-4 text-center border-destructive/20">
          <p className="text-sm text-muted-foreground">Для участия в голосованиях нужен IP-score 31+. Ваш: {user.ipScore}</p>
        </Card>
      )}

      {/* Proposals */}
      {proposals.length === 0 ? (
        <Card className="p-8 text-center">
          <Vote className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground text-sm">Предложений пока нет</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {proposals.map(p => (
            <Card key={p.id} className={cn('overflow-hidden', p.status !== 'active' && 'opacity-60')}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-base">{p.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">{typeLabel(p.type)}</Badge>
                      <Badge variant={p.status === 'active' ? 'default' : 'secondary'} className="text-xs">{statusLabel(p.status)}</Badge>
                    </div>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <div className="flex items-center gap-1 justify-end"><Clock className="w-3 h-3" /> {daysLeft(p.endDate)}</div>
                    <div className="flex items-center gap-1 justify-end mt-1"><Users className="w-3 h-3" /> {p.totalVotes} голосов</div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3">{p.description}</p>

                {/* Vote results bar */}
                {p.totalVotes > 0 && (
                  <div className="mb-3">
                    <div className="flex h-2 rounded-full overflow-hidden bg-muted">
                      <div className="bg-success" style={{ width: `${(p.forVotes / (p.forVotes + p.againstVotes + p.abstainVotes)) * 100}%` }} />
                      <div className="bg-destructive" style={{ width: `${(p.againstVotes / (p.forVotes + p.againstVotes + p.abstainVotes)) * 100}%` }} />
                      <div className="bg-muted-foreground" style={{ width: `${(p.abstainVotes / (p.forVotes + p.againstVotes + p.abstainVotes)) * 100}%` }} />
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                      <span className="text-success-text">За: {p.forVotes}</span>
                      <span className="text-destructive">Против: {p.againstVotes}</span>
                      <span>Воздержались: {p.abstainVotes}</span>
                    </div>
                  </div>
                )}

                {/* Vote buttons */}
                {p.status === 'active' && user && user.ipScore >= p.minIpScore && (
                  <div className="flex gap-2">
                    {p.myVote ? (
                      <Badge variant="secondary" className="text-xs">Вы проголосовали: {voteLabel(p.myVote)}</Badge>
                    ) : (
                      <>
                        <Button size="sm" variant="outline" onClick={() => vote(p.id, 'for')} className="text-success-text hover:text-success-text"><ThumbsUp className="w-3 h-3 mr-1" /> За</Button>
                        <Button size="sm" variant="outline" onClick={() => vote(p.id, 'against')} className="text-destructive hover:text-destructive"><ThumbsDown className="w-3 h-3 mr-1" /> Против</Button>
                        <Button size="sm" variant="outline" onClick={() => vote(p.id, 'abstain')}><Minus className="w-3 h-3 mr-1" /> Воздержаться</Button>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <CreateProposalDialog open={createOpen} onClose={() => setCreateOpen(false)} onCreated={() => { setCreateOpen(false); load(); }} />
    </div>
  );
}

function CreateProposalDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [type, setType] = React.useState('governance');
  const [loading, setLoading] = React.useState(false);

  async function handleCreate() {
    if (!title.trim() || !description.trim()) return;
    setLoading(true);
    try {
      await api('/api/dao', { method: 'POST', body: JSON.stringify({ title, description, type, durationDays: 7 }) });
      toast({ title: 'Предложение создано' });
      setTitle(''); setDescription('');
      onCreated();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally { setLoading(false); }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader><DialogTitle>Новое предложение DAO</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Заголовок</Label>
            <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Например: Добавить раздел «Образование»" />
          </div>
          <div className="space-y-1">
            <Label>Описание</Label>
            <Textarea rows={4} value={description} onChange={e => setDescription(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Тип</Label>
            <select value={type} onChange={e => setType(e.target.value)} className="w-full p-2 border rounded-md bg-background text-sm">
              <option value="governance">Управление</option>
              <option value="feature">Новая функция</option>
              <option value="budget">Бюджет</option>
              <option value="partnership">Партнёрство</option>
            </select>
          </div>
          <Button onClick={handleCreate} disabled={loading || !title.trim()} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Создать'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function typeLabel(t: string) { return { governance: 'Управление', feature: 'Функция', budget: 'Бюджет', partnership: 'Партнёрство' }[t] ?? t; }
function statusLabel(s: string) { return { active: 'Активно', passed: 'Принято', rejected: 'Отклонено', executed: 'Исполнено' }[s] ?? s; }
function voteLabel(v: string) { return { for: 'За', against: 'Против', abstain: 'Воздержался' }[v] ?? v; }
function daysLeft(endDate: string) {
  const days = Math.ceil((new Date(endDate).getTime() - Date.now()) / (24 * 60 * 60 * 1000));
  if (days <= 0) return 'Завершено';
  if (days === 1) return '1 день';
  return `${days} дней`;
}
