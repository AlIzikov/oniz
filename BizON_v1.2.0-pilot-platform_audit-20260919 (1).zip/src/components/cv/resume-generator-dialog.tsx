// BizON — Resume Generator Dialog (Этап 5.3 — CV блок)
// Кнопка «Сформировать резюме» с выбором типа:
//   • short       — короткое резюме в один экран
//   • long        — полное резюме
//   • cover_letter — сопроводительное письмо под вакансию (50-280 символов)
//
// После генерации:
//   • Превью контента (структурированное)
//   • Кнопки: «Скачать PDF» (заглушка) / «Копировать» / «Отправить на вакансию»
//
// Этика: только VERIFIED факты (CLAIMED не включаются).
// z-ai-web-dev-sdk только server-side — UI вызывает /api/cv/generate.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LumenPaywallDialog, extractLumenNeed } from '@/components/common/lumen-paywall';
import {
  FileText, Loader2, Copy, Download, Send, Sparkles, Check, X, Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

type ResumeType = 'short' | 'long' | 'cover_letter';

interface ResumeContent {
  header?: { name: string; title: string | null; location: string | null };
  summary?: string;
  topSkills?: string[];
  skills?: Array<{ name: string; level: number; verification: string }>;
  topProjects?: Array<{ title: string; description: string; role: string }>;
  experience?: Array<{
    company: string;
    position: string;
    period: string;
    description: string | null;
  }>;
  contacts?: { name: string; location: string | null };
  coverLetter?: string;
}

interface GenerateResponse {
  resumeId: string;
  type: ResumeType;
  content: ResumeContent;
  engine: 'llm' | 'fallback';
  aiGenerated: boolean;
}

interface ResumeGeneratorDialogProps {
  /** ID пользователя, чьё резюме генерировать (для своего профиля — currentUser.id).
   *  Бэкенд всегда генерирует резюме для currentUser (т.к. только владелец может),
   *  но мы передаём targetUserId для будущего расширения (HR генерирует для кандидата). */
  targetUserId?: string;
  /** Опционально: jobId для cover_letter */
  jobId?: string;
  /** Текст кнопки-триггера */
  triggerLabel?: string;
  triggerVariant?: 'default' | 'outline' | 'secondary' | 'ghost';
  triggerSize?: 'sm' | 'default' | 'lg' | 'icon';
  triggerIcon?: boolean;
}

export function ResumeGeneratorDialog({
  targetUserId,
  jobId,
  triggerLabel = 'Сформировать резюме',
  triggerVariant = 'outline',
  triggerSize = 'sm',
  triggerIcon = true,
}: ResumeGeneratorDialogProps) {
  const [open, setOpen] = React.useState(false);
  const [generating, setGenerating] = React.useState(false);
  const [result, setResult] = React.useState<GenerateResponse | null>(null);
  const [activeType, setActiveType] = React.useState<ResumeType | null>(null);
  const [copied, setCopied] = React.useState(false);
  // Волна 14: paywall люменов (Free: 2 люмена за генерацию) + последний тип для повтора
  const [paywall, setPaywall] = React.useState<{ need: number; have: number } | null>(null);
  const { user } = useAppStore();
  const isFree = user?.subscriptionTier === 'free';

  async function handleGenerate(type: ResumeType) {
    setActiveType(type);
    setGenerating(true);
    setResult(null);
    try {
      const res = await api<GenerateResponse & { lumenRefunded?: boolean }>('/api/cv/generate', {
        method: 'POST',
        body: JSON.stringify({ type, jobId: jobId ?? undefined }),
      });
      setResult(res);
      if (res.lumenRefunded) {
        toast({
          title: 'AI временно недоступен — люмены возвращены',
          description: 'Резюме собрано из подтверждённых фактов без списания люменов.',
        });
      } else if (res.engine === 'fallback') {
        toast({
          title: 'Использована базовая структура',
          description: 'AI временно недоступен — резюме собрано из подтверждённых фактов.',
        });
      }
    } catch (e: any) {
      // Волна 14: 402 — не хватает люменов → диалог пополнения (после — повтор)
      const lumenNeed = extractLumenNeed(e);
      if (lumenNeed) {
        setPaywall(lumenNeed);
        return;
      }
      toast({
        title: 'Не удалось сгенерировать резюме',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setGenerating(false);
    }
  }

  function reset() {
    setResult(null);
    setActiveType(null);
    setCopied(false);
  }

  function handleClose(open: boolean) {
    setOpen(open);
    if (!open) {
      // сбрасываем с задержкой чтобы не мелькало при закрытии
      setTimeout(reset, 200);
    }
  }

  async function handleCopy() {
    if (!result) return;
    const text = serializeResume(result.content, result.type);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast({ title: 'Резюме скопировано в буфер обмена' });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: 'Не удалось скопировать', variant: 'destructive' });
    }
  }



  return (
    <Dialog open={open} onOpenChange={handleClose}>
      {/* Волна 14: paywall — не хватает люменов на генерацию */}
      <LumenPaywallDialog
        open={paywall !== null}
        onOpenChange={(o) => { if (!o) setPaywall(null); }}
        need={paywall?.need ?? 2}
        have={paywall?.have ?? 0}
        onToppedUp={() => {
          setPaywall(null);
          if (activeType) handleGenerate(activeType);
        }}
      />
      <DialogTrigger asChild>
        <Button variant={triggerVariant} size={triggerSize} className="gap-1.5">
          {triggerIcon && <FileText className="w-3.5 h-3.5" />}
          {triggerLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-lighthouse" />
            Сформировать резюме
          </DialogTitle>
        </DialogHeader>

        {/* === Шаг 1: выбор типа === */}
        {!result && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Выберите формат резюме. AI использует только <strong>подтверждённые</strong> навыки и завершённые проекты —
              никаких заявлений без доказательств.
            </p>

            <div className="grid sm:grid-cols-3 gap-3">
              <TypeCard
                type="short"
                title="Короткое"
                description="Один экран: ключевые навыки + 3 главных проекта + контакты."
                icon={<FileText className="w-5 h-5" />}
                active={activeType === 'short'}
                disabled={generating}
                onClick={() => handleGenerate('short')}
                lumenCost={isFree ? 2 : undefined}
              />
              <TypeCard
                type="long"
                title="Полное"
                description="Вся карьера + проекты + навыки с уровнями верификации."
                icon={<FileText className="w-5 h-5" />}
                active={activeType === 'long'}
                disabled={generating}
                onClick={() => handleGenerate('long')}
                lumenCost={isFree ? 2 : undefined}
              />
              <TypeCard
                type="cover_letter"
                title="Cover letter"
                description="Сопроводительное письмо 50-280 символов под вакансию."
                icon={<Send className="w-5 h-5" />}
                active={activeType === 'cover_letter'}
                disabled={generating || !jobId}
                onClick={() => handleGenerate('cover_letter')}
                note={!jobId ? 'Нужно выбрать вакансию' : undefined}
                lumenCost={isFree ? 2 : undefined}
              />
            </div>

            {generating && (
              <div className="flex items-center justify-center gap-2 py-8 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                Генерация резюме через AI…
              </div>
            )}
          </div>
        )}

        {/* === Шаг 2: превью результата === */}
        {result && (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <Badge variant="secondary" className="gap-1">
                {result.type === 'short' ? 'Короткое' : result.type === 'long' ? 'Полное' : 'Cover letter'}
              </Badge>
              <Badge
                variant="outline"
                className={cn(
                  'gap-1',
                  result.engine === 'llm'
                    ? 'text-emerald-600 border-emerald-600/40'
                    : 'text-amber-600 border-amber-600/40'
                )}
              >
                {result.engine === 'llm' ? (
                  <>
                    <Sparkles className="w-3 h-3" /> AI
                  </>
                ) : (
                  <>
                    <FileText className="w-3 h-3" /> Из фактов
                  </>
                )}
              </Badge>
            </div>

            {/* Превью контента */}
            <div className="rounded-lg border bg-muted/30 p-4 max-h-[55vh] overflow-y-auto">
              <ResumePreview content={result.content} type={result.type} />
            </div>

            {/* Действия */}
            <div className="flex flex-wrap gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                disabled
                title="PDF-экспорт появится позже; используйте «Копировать»"
                className="gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Скачать PDF
              </Button>
              <Button variant="outline" size="sm" onClick={handleCopy} className="gap-1.5">
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Скопировано' : 'Копировать'}
              </Button>
              {result.type === 'cover_letter' && (
                <Button
                  variant="outline"
                  size="sm"
                  disabled
                  title="Отправка на вакансию появится позже; скопируйте резюме и прикрепите к отклику"
                  className="gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  Отправить на вакансию
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  reset();
                }}
                className="gap-1.5 ml-auto"
              >
                <X className="w-3.5 h-3.5" />
                Заново
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// Карточка типа резюме
// ============================================================================
function TypeCard({
  type,
  title,
  description,
  icon,
  active,
  disabled,
  onClick,
  note,
  lumenCost,
}: {
  type: ResumeType;
  title: string;
  description: string;
  icon: React.ReactNode;
  active: boolean;
  disabled?: boolean;
  onClick: () => void;
  note?: string;
  /** Волна 14: стоимость в люменах (только Free) */
  lumenCost?: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'text-left p-4 rounded-lg border-2 transition relative',
        active
          ? 'border-lighthouse bg-lighthouse/5'
          : 'border-border hover:border-lighthouse/50 hover:bg-accent/30',
        disabled && 'opacity-50 cursor-not-allowed hover:border-border hover:bg-transparent'
      )}
    >
      {typeof lumenCost === 'number' && (
        <div className="absolute top-2 right-2 flex items-center gap-0.5 text-xs font-semibold text-amber-600 bg-amber-500/10 border border-amber-600/30 rounded-full px-1.5 py-0.5">
          <Zap className="w-2.5 h-2.5 fill-amber-500 text-amber-500" />
          {lumenCost} Л
        </div>
      )}
      <div className="flex items-center gap-2 mb-1.5">
        <span className={cn('text-lighthouse', active && 'scale-110 transition')}>
          {icon}
        </span>
        <span className="font-semibold text-sm">{title}</span>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
      {note && (
        <p className="text-xs text-amber-600 mt-2 italic">{note}</p>
      )}
      {active && (
        <div className="absolute bottom-2 right-2">
          <Loader2 className="w-3.5 h-3.5 animate-spin text-lighthouse" />
        </div>
      )}
    </button>
  );
}

// ============================================================================
// Превью содержимого резюме
// ============================================================================
function ResumePreview({ content, type }: { content: ResumeContent; type: ResumeType }) {
  if (type === 'cover_letter') {
    return (
      <div className="space-y-2">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Cover Letter
        </div>
        <p className="text-sm leading-relaxed">{content.coverLetter ?? '—'}</p>
        <div className="text-xs text-muted-foreground pt-2 border-t">
          Длина: {(content.coverLetter ?? '').length} символов
          {(content.coverLetter ?? '').length < 50 || (content.coverLetter ?? '').length > 280
            ? ' (рекомендация: 50-280)'
            : ' ✓'}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      {content.header && (
        <div>
          <div className="text-lg font-bold">{content.header.name}</div>
          {content.header.title && (
            <div className="text-sm text-foreground/80">{content.header.title}</div>
          )}
          {content.header.location && (
            <div className="text-xs text-muted-foreground mt-0.5">{content.header.location}</div>
          )}
        </div>
      )}

      {/* Summary */}
      {content.summary && (
        <Section title="Профиль">
          <p className="text-sm leading-relaxed">{content.summary}</p>
        </Section>
      )}

      {/* Top skills (short) */}
      {content.topSkills && content.topSkills.length > 0 && (
        <Section title="Ключевые навыки">
          <div className="flex flex-wrap gap-1.5">
            {content.topSkills.map((s, i) => (
              <Badge key={`${s}-${i}`} variant="secondary" className="text-xs">
                {s}
              </Badge>
            ))}
          </div>
        </Section>
      )}

      {/* Skills (long) */}
      {content.skills && content.skills.length > 0 && (
        <Section title="Навыки">
          <ul className="space-y-1">
            {content.skills.map((s, i) => (
              <li key={`${s.name}-${i}`} className="text-sm flex items-center gap-2">
                <span className="font-medium">{s.name}</span>
                <Badge variant="outline" className="text-xs">ур. {s.level}/5</Badge>
                <Badge variant="outline" className="text-xs text-emerald-600 border-emerald-600/40">
                  {verificationLabel(s.verification)}
                </Badge>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {/* Experience */}
      {content.experience && content.experience.length > 0 && (
        <Section title="Опыт работы">
          <ul className="space-y-2">
            {content.experience.map((e, i) => (
              <li key={`${e.company}-${i}`} className="text-sm">
                <div className="font-medium">
                  {e.position} <span className="text-muted-foreground font-normal">· {e.company}</span>
                </div>
                <div className="text-xs text-muted-foreground">{e.period}</div>
                {e.description && (
                  <div className="text-xs text-foreground/70 mt-0.5">{e.description}</div>
                )}
              </li>
            ))}
          </ul>
        </Section>
      )}

      {/* Top projects */}
      {content.topProjects && content.topProjects.length > 0 && (
        <Section title={type === 'short' ? 'Главные проекты' : 'Проекты'}>
          <ul className="space-y-2">
            {content.topProjects.map((p, i) => (
              <li key={`${p.title}-${i}`} className="text-sm">
                <div className="font-medium">
                  {p.title} <span className="text-muted-foreground font-normal text-xs">· роль: {p.role}</span>
                </div>
                <div className="text-xs text-foreground/70 mt-0.5">{p.description}</div>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {/* Contacts */}
      {content.contacts && (
        <Section title="Контакты">
          <div className="text-sm">
            <div className="font-medium">{content.contacts.name}</div>
            {content.contacts.location && (
              <div className="text-xs text-muted-foreground">{content.contacts.location}</div>
            )}
          </div>
        </Section>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5 border-b pb-1">
        {title}
      </div>
      {children}
    </div>
  );
}

function verificationLabel(v: string): string {
  const map: Record<string, string> = {
    verified: 'verified',
    project_verified: 'project-verified',
    expert_verified: 'expert-verified',
  };
  return map[v] ?? v;
}

// ============================================================================
// Сериализация резюме в plain text (для копирования в буфер)
// ============================================================================
function serializeResume(content: ResumeContent, type: ResumeType): string {
  if (type === 'cover_letter') {
    return content.coverLetter ?? '';
  }
  const lines: string[] = [];
  if (content.header) {
    lines.push(content.header.name);
    if (content.header.title) lines.push(content.header.title);
    if (content.header.location) lines.push(content.header.location);
    lines.push('');
  }
  if (content.summary) {
    lines.push('ПРОФИЛЬ');
    lines.push(content.summary);
    lines.push('');
  }
  if (content.topSkills && content.topSkills.length > 0) {
    lines.push('КЛЮЧЕВЫЕ НАВЫКИ');
    lines.push(content.topSkills.join(', '));
    lines.push('');
  }
  if (content.skills && content.skills.length > 0) {
    lines.push('НАВЫКИ');
    content.skills.forEach((s) => {
      lines.push(`- ${s.name} (уровень ${s.level}/5, ${verificationLabel(s.verification)})`);
    });
    lines.push('');
  }
  if (content.experience && content.experience.length > 0) {
    lines.push('ОПЫТ РАБОТЫ');
    content.experience.forEach((e) => {
      lines.push(`${e.position} — ${e.company} (${e.period})`);
      if (e.description) lines.push(`  ${e.description}`);
    });
    lines.push('');
  }
  if (content.topProjects && content.topProjects.length > 0) {
    lines.push('ПРОЕКТЫ');
    content.topProjects.forEach((p) => {
      lines.push(`- ${p.title} (роль: ${p.role})`);
      if (p.description) lines.push(`  ${p.description}`);
    });
    lines.push('');
  }
  if (content.contacts) {
    lines.push('КОНТАКТЫ');
    lines.push(content.contacts.name);
    if (content.contacts.location) lines.push(content.contacts.location);
  }
  return lines.join('\n');
}
