// BizON — Career Compass (Этап 5.3 — Карьерный компас / cross-domain навигатор)
// Анализирует transferable skills и предлагает 3-5 смежных областей с matchPercent.
//
// Этика:
//   • Cross-domain подсказки только если user.crossDomainOptIn=true (по умолчанию false)
//   • Запрет «вы недостойны» — только «можете рассмотреть»
//   • Для каждой области: «Если добавишь навык X, откроется 23 вакансии» (заглушка)
//
// Рендерится в MeView → Tab «Моя правда».
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import {
  Compass, Loader2, Sparkles, MapPin, TrendingUp, Shield, Check, Save,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { UserPublic } from '@/lib/types';

interface SuggestedDomain {
  domain: string;
  reason: string;
  matchPercent: number;
}

interface CompassResponse {
  compassId: string;
  currentRole: string;
  currentDomain: string;
  transferableSkills: string[];
  suggestedDomains: SuggestedDomain[];
  engine: 'llm' | 'fallback';
  crossDomainOptIn: boolean;
  generatedAt: string;
}

interface LatestCompassResponse {
  compass: {
    id: string;
    currentRole: string;
    currentDomain: string;
    transferableSkills: string[];
    suggestedDomains: SuggestedDomain[];
    generatedAt: string;
  } | null;
}

// TODO(11-a): crossDomainOptIn / hobbies / showHobbiesToHr отсутствуют в UserPublic ('@/lib/types').
// Локальное расширение — удалить после добавления полей в общий тип.
type CompassUser = UserPublic & {
  crossDomainOptIn?: boolean | null;
  hobbies?: string | null;
  showHobbiesToHr?: boolean | null;
};

export function CareerCompass() {
  const user = useAppStore((s) => s.user) as CompassUser | null;
  const setUser = useAppStore((s) => s.setUser);
  const [running, setRunning] = React.useState(false);
  const [result, setResult] = React.useState<CompassResponse | null>(null);
  const [latest, setLatest] = React.useState<LatestCompassResponse['compass']>(null);
  const [loadingLatest, setLoadingLatest] = React.useState(true);

  // Локальный стейт opt-in — синхронизируем с user при загрузке
  const [optIn, setOptIn] = React.useState<boolean>(user?.crossDomainOptIn ?? false);
  const [optInSaving, setOptInSaving] = React.useState(false);

  // Хобби и showHobbiesToHr — редактируемые поля
  const [hobbiesInput, setHobbiesInput] = React.useState<string>(user?.hobbies ?? '');
  const [showHobbies, setShowHobbies] = React.useState<boolean>(user?.showHobbiesToHr ?? false);
  const [hobbiesSaving, setHobbiesSaving] = React.useState(false);

  React.useEffect(() => {
    setOptIn(user?.crossDomainOptIn ?? false);
    setHobbiesInput(user?.hobbies ?? '');
    setShowHobbies(user?.showHobbiesToHr ?? false);
  }, [user?.crossDomainOptIn, user?.hobbies, user?.showHobbiesToHr]);

  // Загружаем последний сгенерированный компас
  const loadLatest = React.useCallback(async () => {
    setLoadingLatest(true);
    try {
      const res = await api<LatestCompassResponse>('/api/cv/compass');
      setLatest(res.compass);
    } catch (e: any) {
      // Тихо игнорируем — не критично
      console.error('[CareerCompass] loadLatest error:', e);
    } finally {
      setLoadingLatest(false);
    }
  }, []);

  React.useEffect(() => {
    loadLatest();
  }, [loadLatest]);

  async function handleRun() {
    setRunning(true);
    try {
      const res = await api<CompassResponse>('/api/cv/compass', {
        method: 'POST',
        body: JSON.stringify({}),
      });
      setResult(res);
      if (res.engine === 'fallback') {
        toast({
          title: 'Использована базовая эвристика',
          description: 'AI временно недоступен — компас построен на основе ваших навыков.',
        });
      } else {
        toast({
          title: 'Карьерный компас готов',
          description: `Найдено ${res.suggestedDomains.length} смежных областей.`,
        });
      }
    } catch (e: any) {
      toast({
        title: 'Не удалось запустить компас',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setRunning(false);
    }
  }

  async function handleToggleOptIn(checked: boolean) {
    setOptIn(checked);
    setOptInSaving(true);
    try {
      const res = await api<{ user: any }>(`/api/users/${user?.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ crossDomainOptIn: checked }),
      });
      setUser(res.user);
      toast({
        title: checked
          ? 'Cross-domain подсказки включены'
          : 'Только смежные области в текущем домене',
        description: checked
          ? 'Компас будет предлагать области ВНЕ вашей текущей специализации.'
          : 'Компас будет предлагать только близкие к текущей специализации области.',
      });
    } catch (e: any) {
      // Откатываем при ошибке
      setOptIn(!checked);
      toast({
        title: 'Не удалось сохранить настройку',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setOptInSaving(false);
    }
  }

  async function handleToggleShowHobbies(checked: boolean) {
    setShowHobbies(checked);
    setHobbiesSaving(true);
    try {
      const res = await api<{ user: any }>(`/api/users/${user?.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ showHobbiesToHr: checked }),
      });
      setUser(res.user);
      toast({
        title: checked
          ? 'Хобби видны HR-агентствам'
          : 'Хобби анонимизированы для HR',
        description: checked
          ? 'HR увидят ваши хобби в блоке Transferable skills.'
          : 'HR увидят только счётчик хобби, без списка.',
      });
    } catch (e: any) {
      setShowHobbies(!checked);
      toast({
        title: 'Не удалось сохранить настройку',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setHobbiesSaving(false);
    }
  }

  async function handleSaveHobbies() {
    setHobbiesSaving(true);
    try {
      const res = await api<{ user: any }>(`/api/users/${user?.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ hobbies: hobbiesInput.trim() }),
      });
      setUser(res.user);
      toast({ title: 'Хобби сохранены' });
    } catch (e: any) {
      toast({
        title: 'Не удалось сохранить хобби',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setHobbiesSaving(false);
    }
  }

  // Что показывать: свежий результат или последний сохранённый
  const display = result ?? (latest
    ? {
        compassId: latest.id,
        currentRole: latest.currentRole,
        currentDomain: latest.currentDomain,
        transferableSkills: latest.transferableSkills,
        suggestedDomains: latest.suggestedDomains,
        engine: 'fallback' as const,
        crossDomainOptIn: optIn,
        generatedAt: latest.generatedAt,
      }
    : null);

  return (
    <Card className="border-lighthouse/30">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Compass className="w-4 h-4 text-lighthouse" />
          Карьерный компас
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          AI анализирует ваши подтверждённые навыки и хобби, определяет transferable skills и предлагает
          смежные области, где вы можете применить свой опыт. Только конструктивные формулировки —
          никаких «вы недостойны».
        </p>

        {/* Хобби + showHobbiesToHr настройки */}
        <div className="rounded-lg border bg-muted/30 p-3 space-y-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Источники данных компаса
          </div>
          <div className="space-y-1.5">
            <label className="text-xs text-muted-foreground">
              Хобби (через запятую — используются для transferable skills)
            </label>
            <div className="flex gap-2">
              <Input
                value={hobbiesInput}
                onChange={(e) => setHobbiesInput(e.target.value)}
                placeholder="фотография, шахматы, блогинг…"
                maxLength={500}
                className="text-sm"
              />
              <Button
                size="sm"
                variant="outline"
                onClick={handleSaveHobbies}
                disabled={hobbiesSaving || hobbiesInput.trim() === (user?.hobbies ?? '')}
                className="gap-1.5 shrink-0"
              >
                <Save className="w-3.5 h-3.5" />
                {hobbiesSaving ? '…' : 'OK'}
              </Button>
            </div>
          </div>
          <div className="flex items-start justify-between gap-3 pt-1">
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-lighthouse" />
                Показывать хобби HR-агентствам
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                {showHobbies
                  ? 'Включено — HR увидят список ваших хобби в блоке Transferable skills.'
                  : 'Выключено — HR видят только счётчик хобби (анонимизировано).'}
              </p>
            </div>
            <Switch
              checked={showHobbies}
              onCheckedChange={handleToggleShowHobbies}
              disabled={hobbiesSaving}
            />
          </div>
        </div>

        {/* Opt-in переключатель */}
        <div className="rounded-lg border bg-muted/30 p-3 space-y-2">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-lighthouse" />
                Cross-domain подсказки
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                {optIn
                  ? 'Включено — компас предложит области ВНЕ вашей текущей специализации.'
                  : 'Выключено — только смежные области внутри вашего текущего домена.'}
              </p>
            </div>
            <Switch
              checked={optIn}
              onCheckedChange={handleToggleOptIn}
              disabled={optInSaving}
            />
          </div>
        </div>

        {/* Кнопка запуска */}
        <Button onClick={handleRun} disabled={running} className="w-full gap-1.5">
          {running ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Анализирую ваши навыки…
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              {display ? 'Обновить компас' : 'Запустить карьерный компас'}
            </>
          )}
        </Button>

        {/* Результат */}
        {loadingLatest && !display ? (
          <div className="space-y-2">
            <Skeleton className="h-20 w-full rounded-lg" />
            <Skeleton className="h-20 w-full rounded-lg" />
          </div>
        ) : display ? (
          <CompassResultView data={display} />
        ) : (
          <div className="text-center py-6">
            <Compass className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">
              Нажмите «Запустить», чтобы увидеть карту смежных областей.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Превью результата компаса
// ============================================================================
function CompassResultView({ data }: { data: CompassResponse }) {
  return (
    <div className="space-y-4">
      {/* Текущая область */}
      <div className="rounded-lg bg-lighthouse-gradient-soft border border-lighthouse/20 p-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1">
          <MapPin className="w-3 h-3" />
          Текущая область
        </div>
        <div className="text-sm font-medium">{data.currentRole}</div>
        <div className="text-xs text-foreground/70 mt-0.5">{data.currentDomain}</div>
      </div>

      {/* Transferable skills */}
      {data.transferableSkills.length > 0 && (
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
            Transferable skills
          </div>
          <div className="flex flex-wrap gap-1.5">
            {data.transferableSkills.map((s, i) => (
              <Badge key={`${s}-${i}`} variant="secondary" className="text-xs gap-1">
                <Check className="w-3 h-3 text-emerald-600" />
                {s}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Suggested domains */}
      {data.suggestedDomains.length > 0 ? (
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            {data.crossDomainOptIn
              ? 'Смежные и cross-domain области'
              : 'Смежные области (cross-domain выключен)'}
          </div>
          <div className="space-y-2">
            {data.suggestedDomains.map((d, i) => (
              <DomainRow key={`${d.domain}-${i}`} domain={d} />
            ))}
          </div>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground italic">
          Нет предложенных областей. Добавьте подтверждённые навыки и хобби в профиль.
        </p>
      )}

      {/* Engine badge + этика-метка */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t text-xs text-muted-foreground">
        <span>
          Сгенерировано: {new Date(data.generatedAt).toLocaleString('ru-RU')}
        </span>
        <Badge
          variant="outline"
          className={cn(
            'text-xs gap-1',
            data.engine === 'llm'
              ? 'text-emerald-600 border-emerald-600/40'
              : 'text-amber-600 border-amber-600/40'
          )}
        >
          {data.engine === 'llm' ? (
            <>
              <Sparkles className="w-3 h-3" /> AI
            </>
          ) : (
            <>
              <Compass className="w-3 h-3" /> Эвристика
            </>
          )}
        </Badge>
      </div>
    </div>
  );
}

function DomainRow({ domain }: { domain: SuggestedDomain }) {
  const matchColor =
    domain.matchPercent >= 70
      ? 'text-emerald-600'
      : domain.matchPercent >= 50
        ? 'text-amber-600'
        : 'text-muted-foreground';

  return (
    <div className="rounded-lg border p-3 space-y-1.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm font-medium">{domain.domain}</span>
        <span className={cn('text-sm font-bold tabular-nums', matchColor)}>
          {domain.matchPercent}%
        </span>
      </div>
      <p className="text-xs text-foreground/70 leading-relaxed">{domain.reason}</p>
      <Progress value={domain.matchPercent} className="h-1.5" />
      {/* Заглушка «Если добавишь навык X, откроется 23 вакансии» */}
      <div className="text-xs text-muted-foreground/70 italic pt-1">
        Добавьте релевантный навык — откроются новые вакансии в этой области (функция в разработке).
      </div>
    </div>
  );
}
