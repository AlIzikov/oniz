// BizON — Landing Page (публичная страница для неавторизованных)
// P1-1: замена авто-входа на честную landing page с UVP + регистрация
'use client';

import * as React from 'react';
import { AuthScreen } from '@/components/auth/auth-screen';
import {
  ShieldCheck, Sparkles, TrendingUp, Brain,
  ArrowRight, Check,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function LandingPage() {
  const [showAuth, setShowAuth] = React.useState(false);

  if (showAuth) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* NAV */}
      <nav className="border-b bg-card/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <span className="text-2xl font-extrabold tracking-tight">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span>
            <span className="text-emerald-700 dark:text-emerald-500">ON</span>
          </span>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowAuth(true)} className="px-3 py-1.5 text-sm font-medium hover:bg-accent rounded-md transition">
              Войти
            </button>
            <button
              onClick={() => setShowAuth(true)}
              className="px-4 py-1.5 text-sm font-medium bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition flex items-center gap-1"
            >
              Начать бесплатно <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: 'radial-gradient(circle at 20% 30%, #1e3a8a 1px, transparent 1px), radial-gradient(circle at 80% 70%, #059669 1px, transparent 1px)',
          backgroundSize: '60px 60px, 80px 80px',
        }} />
        <div className="relative max-w-4xl mx-auto px-4 py-16 sm:py-24 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-500 text-xs font-medium mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            Профессиональная сеть нового поколения
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
            Не сеть контактов.<br />
            <span className="text-[#1e3a8a] dark:text-blue-400">Сеть </span>
            <span className="text-emerald-700 dark:text-emerald-500">доверия.</span>
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
            BizON — деловая соцсеть, где репутация подтверждается действиями, а не лайками.
            AI-агенты находят связи, вакансии и карьерные траектории.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <button
              onClick={() => setShowAuth(true)}
              className="px-6 py-3 text-base font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition flex items-center gap-2 shadow-lg"
            >
              Создать аккаунт <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowAuth(true)}
              className="px-6 py-3 text-base font-medium border rounded-lg hover:bg-accent transition"
            >
              У меня есть аккаунт
            </button>
          </div>
          <p className="text-xs text-muted-foreground mt-4">
            Бесплатно навсегда · Без карты · 30 секунд на регистрацию
          </p>
        </div>
      </section>

      {/* FEATURES */}
      <section className="py-16 bg-card/50">
        <div className="max-w-5xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Что отличает BizON</h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Четыре технологии, которых нет ни в LinkedIn, ни в HH, ни в Otta
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <FeatureCard icon={<TrendingUp className="w-6 h-6 text-emerald-600" />} title="IP-score — индекс доверия"
              desc="Репутация считается на основе завершённых проектов, подтверждённых навыков и отзывов. Нельзя накрутить — каждое подтверждение требует общего проекта." />
            <FeatureCard icon={<Sparkles className="w-6 h-6 text-emerald-600" />} title="AI-Matchmaker"
              desc="AI находит оптимальный путь к нужному человеку через граф доверия. Принцип «5 рукопожатий» — но с учётом IP-score каждого посредника." />
            <FeatureCard icon={<Brain className="w-6 h-6 text-emerald-600" />} title="AI-Career-Agent"
              desc="Строит карьерную траекторию на 3-12 месяцев. Анализирует навыки, историю проектов и предлагает конкретные шаги для роста." />
            <FeatureCard icon={<ShieldCheck className="w-6 h-6 text-emerald-600" />} title="PII защита (152-ФЗ)"
              desc="Email, телефон и личные данные шифруются AES-256-GCM. В БД нет plaintext — даже при утечке данные не будут скомпрометированы." />
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Как это работает</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <StepCard step="1" title="Регистрируйтесь" desc="30 секунд — email, имя, профессия. IP-score стартует с 0 и растёт с каждым действием." />
            <StepCard step="2" title="Стройте репутацию" desc="Завершайте проекты, подтверждайте навыки, получайте отзывы. AI пересчитывает IP-score автоматически." />
            <StepCard step="3" title="Получайте возможности" desc="AI-Matchmaker находит связи, AI-Career строит траекторию, работодатели видят ваш подтверждённый опыт." />
          </div>
        </div>
      </section>

      {/* COMPARISON */}
      <section className="py-16 bg-card/50">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">BizON vs другие платформы</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 font-semibold">Возможность</th>
                  <th className="text-center py-3 px-4 font-semibold text-emerald-700 dark:text-emerald-500">BizON</th>
                  <th className="text-center py-3 px-4 font-semibold text-muted-foreground">LinkedIn</th>
                  <th className="text-center py-3 px-4 font-semibold text-muted-foreground">HH.ru</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: 'Репутация на основе действий', linkedin: 'Лайки', hh: 'Нет' },
                  { feature: 'AI-поиск связей (5 рукопожатий)', linkedin: 'Нет', hh: 'Нет' },
                  { feature: 'AI карьерная траектория', linkedin: 'Нет', hh: 'Нет' },
                  { feature: 'PII шифрование AES-256', linkedin: 'Нет', hh: 'Нет' },
                  { feature: 'Подтверждение навыков через проекты', linkedin: 'Endorsements', hh: 'Нет' },
                  { feature: 'Алгоритмическая лента по доверию', linkedin: 'По времени', hh: 'По времени' },
                ].map((row, i) => (
                  <tr key={i} className="border-b last:border-0">
                    <td className="py-3 px-4 font-medium">{row.feature}</td>
                    <td className="text-center py-3 px-4"><Check className="w-4 h-4 text-emerald-600 mx-auto" /></td>
                    <td className="text-center py-3 px-4 text-muted-foreground">{row.linkedin}</td>
                    <td className="text-center py-3 px-4 text-muted-foreground">{row.hh}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Тарифы</h2>
          <p className="text-center text-muted-foreground mb-12">Free — навсегда. Pro — когда вырастете.</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <PricingCard name="Free" price="0 ₽" desc="Для всех профессионалов"
              features={['Безлимитные посты', 'AI-Matchmaker 5/час', 'IP-score + Trust Stream', 'До 5 навыков']}
              cta="Начать бесплатно" onClick={() => setShowAuth(true)} />
            <PricingCard name="Pro" price="1 499 ₽/мес" desc="Для активных специалистов"
              features={['Всё из Free', 'AI-Matchmaker 50/час', 'AI-Career-Agent', 'Безлимит навыков', 'Commercial посты']}
              cta="Выбрать Pro" highlighted onClick={() => setShowAuth(true)} />
            <PricingCard name="Business" price="4 999 ₽/мес" desc="Для компаний и HR"
              features={['Всё из Pro', 'Безлимит вакансий', 'AI-Ad-Moderator', 'Аналитика кандидатов', 'Приоритетная поддержка']}
              cta="Выбрать Business" onClick={() => setShowAuth(true)} />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-[#1e3a8a] to-emerald-700 text-white">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Начните строить репутацию сегодня</h2>
          <p className="text-lg text-white/80 mb-8">Присоединяйтесь к сети, где доверие — это валюта</p>
          <button
            onClick={() => setShowAuth(true)}
            className="px-8 py-3.5 text-base font-semibold bg-white text-[#1e3a8a] rounded-lg hover:bg-white/90 transition inline-flex items-center gap-2 shadow-xl"
          >
            Создать аккаунт <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-8 border-t">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between flex-wrap gap-4">
          <span className="text-2xl font-extrabold tracking-tight">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span>
            <span className="text-emerald-700 dark:text-emerald-500">ON</span>
          </span>
          <p className="text-xs text-muted-foreground">BizON Systems · Москва · 2025 · Маяк в цифровом море</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="p-6 rounded-xl border bg-background hover:shadow-md transition">
      <div className="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-4">{icon}</div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}

function StepCard({ step, title, desc }: { step: string; title: string; desc: string }) {
  return (
    <div className="text-center">
      <div className="w-12 h-12 mx-auto rounded-full bg-[#1e3a8a] dark:bg-blue-500 text-white text-xl font-bold flex items-center justify-center mb-4">{step}</div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}

function PricingCard({ name, price, desc, features, cta, highlighted, onClick }: {
  name: string; price: string; desc: string; features: string[]; cta: string; highlighted?: boolean; onClick: () => void;
}) {
  return (
    <div className={cn('p-6 rounded-xl border-2 transition', highlighted ? 'border-emerald-500 bg-emerald-500/5 shadow-lg' : 'border-border bg-background')}>
      {highlighted && <div className="inline-block px-2 py-0.5 rounded-full bg-emerald-600 text-white text-xs font-medium mb-3">Популярный</div>}
      <h3 className="text-lg font-bold mb-1">{name}</h3>
      <div className="text-2xl font-extrabold mb-1">{price}</div>
      <p className="text-xs text-muted-foreground mb-4">{desc}</p>
      <ul className="space-y-2 mb-6">
        {features.map((f, i) => <li key={i} className="flex items-start gap-2 text-sm"><Check className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" /><span>{f}</span></li>)}
      </ul>
      <button onClick={onClick} className={cn('w-full py-2.5 rounded-lg font-medium text-sm transition', highlighted ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'border hover:bg-accent')}>{cta}</button>
    </div>
  );
}
