// BizON — 7-day Onboarding Mission
// Заменяет обычный onboarding wizard: вместо скучной формы — 7-дневная миссия,
// где каждый день — небольшое действие, усиливающее профиль пользователя.
// Прогресс хранится в localStorage `bizon-onboarding-mission`.
// Показывается только для isOwn (текущего пользователя), только если не все 7 дней завершены.
'use client';

import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAppStore, api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import {
  User, Award, FolderKanban, CheckCircle2, MessageSquare, Users, Brain,
  X, Lock, Loader2, ShieldCheck, Sparkles, PartyPopper,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const STORAGE_KEY = 'bizon-onboarding-mission';
const DISMISSED_KEY = 'bizon-onboarding-mission-dismissed';

type DayKey = 'day1' | 'day2' | 'day3' | 'day4' | 'day5' | 'day6' | 'day7';
type MissionState = Record<DayKey, boolean>;

const DEFAULT_STATE: MissionState = {
  day1: false,
  day2: false,
  day3: false,
  day4: false,
  day5: false,
  day6: false,
  day7: false,
};

type MissionView = 'profile' | 'projects' | 'network' | 'feed' | 'matchmaker' | 'career';

interface DayDef {
  key: DayKey;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
  cta: string;
  view: MissionView;
}

const DAYS: DayDef[] = [
  {
    key: 'day1',
    icon: User,
    title: 'Заполнить профиль',
    desc: 'Имя, должность и фото — основа вашего паспорта доверия.',
    cta: 'Заполнить',
    view: 'profile',
  },
  {
    key: 'day2',
    icon: Award,
    title: 'Добавить 3 навыка',
    desc: 'Перечислите ключевые навыки — коллеги смогут их подтвердить.',
    cta: 'Добавить',
    view: 'profile',
  },
  {
    key: 'day3',
    icon: FolderKanban,
    title: 'Добавить проект',
    desc: 'Опишите проект, над которым работали — это фундамент репутации.',
    cta: 'Добавить',
    view: 'projects',
  },
  {
    key: 'day4',
    icon: CheckCircle2,
    title: 'Получить подтверждение навыка',
    desc: 'Попросите коллегу подтвердить ваш навык — это повышает IP-score.',
    cta: 'Запросить',
    view: 'network',
  },
  {
    key: 'day5',
    icon: MessageSquare,
    title: 'Написать пост',
    desc: 'Поделитесь инсайтом или достижением в ленте.',
    cta: 'Написать',
    view: 'feed',
  },
  {
    key: 'day6',
    icon: Users,
    title: 'Найти контакт',
    desc: 'Добавьте хотя бы один контакт — это расширяет вашу сеть.',
    cta: 'Найти',
    view: 'matchmaker',
  },
  {
    key: 'day7',
    icon: Brain,
    title: 'Получить AI Career Report',
    desc: 'AI построит вашу карьерную карту и подскажет следующий шаг.',
    cta: 'Запустить',
    view: 'career',
  },
];

interface UserDataResponse {
  user: {
    name?: string;
    title?: string | null;
    avatarUrl?: string | null;
    stats?: {
      skillsCount?: number;
      projectsCount?: number;
      postsCount?: number;
      connectionsCount?: number;
    };
  };
  skills?: Array<{ confirmationsCount: number }>;
}

export function OnboardingMission() {
  const { user, setView } = useAppStore();
  const [state, setState] = React.useState<MissionState>(DEFAULT_STATE);
  const [dismissed, setDismissed] = React.useState(false);
  const [verifying, setVerifying] = React.useState<DayKey | null>(null);
  const [hydrated, setHydrated] = React.useState(false);
  // Реф: была ли миссия уже полностью завершена на момент загрузки (чтобы не показывать toast при reload)
  const previouslyCompletedRef = React.useRef(false);

  // === Загрузка состояния из localStorage + авто-верификация дней 1-6 ===
  React.useEffect(() => {
    let loadedState: MissionState = DEFAULT_STATE;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        loadedState = { ...DEFAULT_STATE, ...JSON.parse(raw) };
        setState(loadedState);
      }
      if (Object.values(loadedState).every(Boolean)) {
        previouslyCompletedRef.current = true;
      }
      if (localStorage.getItem(DISMISSED_KEY) === 'true') {
        setDismissed(true);
      }
    } catch {
      // ignore parse errors
    }
    setHydrated(true);

    // Авто-верификация дней 1-6 по данным пользователя (не трогаем day7 — там нужен клик)
    if (!user?.id) return;
    api<UserDataResponse>(`/api/users/${user.id}`)
      .then((res) => {
        const u = res.user ?? {};
        const skills = res.skills ?? [];
        const stats = u.stats ?? {};
        const auto: Partial<MissionState> = {
          day1: Boolean(u.name && u.title && u.avatarUrl),
          day2: (stats.skillsCount ?? skills.length) >= 3,
          day3: (stats.projectsCount ?? 0) >= 1,
          day4: skills.some((s) => s.confirmationsCount > 0),
          day5: (stats.postsCount ?? 0) >= 1,
          day6: (stats.connectionsCount ?? 0) >= 1,
        };
        setState((prev) => {
          const next = { ...prev };
          (Object.keys(auto) as DayKey[]).forEach((k) => {
            if (auto[k]) next[k] = true;
          });
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
          } catch {
            // ignore quota errors
          }
          return next;
        });
      })
      .catch(() => {
        // Тихо игнорируем — пользователь может не иметь доступа к своим данным
      });
     
  }, [user?.id]);

  // === Persist state on changes ===
  React.useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // ignore quota errors
    }
  }, [state, hydrated]);

  const allDone = Object.values(state).every(Boolean);
  const completedCount = Object.values(state).filter(Boolean).length;

  // === Toast при завершении миссии (только если переход в этой сессии) ===
  React.useEffect(() => {
    if (!hydrated) return;
    if (allDone && !previouslyCompletedRef.current) {
      toast({
        title: 'Поздравляем! Вы прошли миссию.',
        description: 'Вы получили статус VERIFIED PROFESSIONAL.',
      });
      previouslyCompletedRef.current = true;
    }
  }, [allDone, hydrated]);

  const currentDayIndex = DAYS.findIndex((d) => !state[d.key]);

  // Не рендерим до гидратации
  if (!hydrated || !user) return null;
  // Скрываем если закрыто И хотя бы 1 день завершён
  if (dismissed && completedCount > 0) return null;

  function dismiss() {
    setDismissed(true);
    try {
      localStorage.setItem(DISMISSED_KEY, 'true');
    } catch {
      // ignore
    }
  }

  function markDay(dayKey: DayKey, done: boolean) {
    setState((prev) => {
      const next = { ...prev, [dayKey]: done };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  }

  async function verifyDay(dayKey: DayKey): Promise<boolean> {
    if (!user?.id) return false;
    try {
      if (dayKey === 'day1') {
        // День 1: проверка через /api/auth/me (name, title, avatarUrl)
        const res = await api<{ user: { name: string; title: string | null; avatarUrl: string | null } }>('/api/auth/me');
        const u = res.user;
        return Boolean(u?.name && u?.title && u?.avatarUrl);
      }
      // Дни 2-6: проверка через /api/users/[id]
      const res = await api<UserDataResponse>(`/api/users/${user.id}`);
      const u = res.user ?? {};
      const skills = res.skills ?? [];
      const stats = u.stats ?? {};
      switch (dayKey) {
        case 'day2':
          return (stats.skillsCount ?? skills.length) >= 3;
        case 'day3':
          return (stats.projectsCount ?? 0) >= 1;
        case 'day4':
          return skills.some((s) => s.confirmationsCount > 0);
        case 'day5':
          return (stats.postsCount ?? 0) >= 1;
        case 'day6':
          return (stats.connectionsCount ?? 0) >= 1;
        default:
          return false;
      }
    } catch {
      return false;
    }
  }

  async function handleAction(day: DayDef) {
    // День 7: запустить Career Agent → отметить выполненным
    if (day.key === 'day7') {
      setView('career');
      markDay('day7', true);
      toast({
        title: 'AI Career Report запущен',
        description: 'Проверьте результат в разделе Career Agent.',
      });
      return;
    }

    // Остальные дни: переход к нужному view + верификация
    setView(day.view);
    setVerifying(day.key);
    try {
      const ok = await verifyDay(day.key);
      if (ok) {
        markDay(day.key, true);
        toast({
          title: 'День завершён!',
          description: `«${day.title}» выполнено.`,
        });
      } else {
        toast({
          title: 'Ещё не готово',
          description: 'Выполните задание и нажмите кнопку ещё раз, чтобы проверить.',
        });
      }
    } catch (e: any) {
      toast({
        title: 'Ошибка проверки',
        description: e?.message ?? 'Попробуйте ещё раз',
        variant: 'destructive',
      });
    } finally {
      setVerifying(null);
    }
  }

  // === Финальная карточка: миссия пройдена ===
  if (allDone) {
    return (
      <Card className="border-emerald-500/40 bg-gradient-to-br from-emerald-500/10 to-emerald-700/5">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-600 flex items-center justify-center flex-shrink-0">
              <PartyPopper className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-base">Миссия пройдена!</span>
                <Badge className="bg-emerald-600 hover:bg-emerald-600 text-white gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  VERIFIED PROFESSIONAL
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                Все 7 дней завершены. Ваш профиль укреплён, IP-score растёт. Продолжайте
                развивать репутацию — завершайте проекты и подтверждайте навыки.
              </p>
            </div>
            <button
              onClick={dismiss}
              className="p-1 rounded hover:bg-accent transition flex-shrink-0"
              title="Закрыть"
              aria-label="Закрыть"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // === Основная карточка миссии ===
  return (
    <Card className="border-lighthouse/20">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-lg lighthouse-gradient flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div className="min-w-0">
              <CardTitle className="text-base leading-tight">
                🎯 7-дневная миссия: Постройте репутацию
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-0.5">
                {completedCount === 0
                  ? 'Каждый день — небольшое действие, которое усиливает ваш профиль.'
                  : `Вы прошли ${completedCount} из 7 дней. Продолжайте!`}
              </p>
            </div>
          </div>
          <button
            onClick={dismiss}
            className="p-1 rounded hover:bg-accent transition flex-shrink-0"
            title="Закрыть"
            aria-label="Закрыть миссию"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Прогресс-бар: «3 из 7» */}
        <div className="mt-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground">Прогресс</span>
            <span className="text-xs font-medium tabular-nums">{completedCount} из 7</span>
          </div>
          <Progress value={(completedCount / 7) * 100} className="h-1.5" />
        </div>
      </CardHeader>

      <CardContent className="space-y-2 pt-0">
        {DAYS.map((day, idx) => {
          const isDone = state[day.key];
          const isCurrent = idx === currentDayIndex;
          const isFuture = idx > currentDayIndex;
          const Icon = day.icon;
          return (
            <div
              key={day.key}
              className={cn(
                'flex items-start gap-3 p-3 rounded-lg border transition',
                isDone && 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-500/30',
                isCurrent && !isDone && 'border-emerald-500 bg-emerald-50/30 dark:bg-emerald-950/10',
                isFuture && 'opacity-60 bg-muted/30 border-border',
                !isDone && !isCurrent && !isFuture && 'border-border'
              )}
            >
              {/* Иконка / статус */}
              <div
                className={cn(
                  'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0',
                  isDone
                    ? 'bg-emerald-600 text-white'
                    : isFuture
                      ? 'bg-muted text-muted-foreground'
                      : 'bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'
                )}
              >
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : isFuture ? (
                  <Lock className="w-3.5 h-3.5" />
                ) : (
                  <Icon className="w-4 h-4" />
                )}
              </div>

              {/* Описание */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground tabular-nums">День {idx + 1}</span>
                  {isCurrent && !isDone && (
                    <Badge
                      variant="outline"
                      className="text-xs py-0 px-1.5 border-emerald-500 text-emerald-700 dark:text-emerald-400"
                    >
                      сейчас
                    </Badge>
                  )}
                </div>
                <div className="text-sm font-medium leading-tight mt-0.5">{day.title}</div>
                <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{day.desc}</p>
              </div>

              {/* Кнопка действия / статус */}
              <div className="flex-shrink-0">
                {isDone ? (
                  <Badge
                    variant="secondary"
                    className="text-emerald-700 dark:text-emerald-400 gap-1"
                  >
                    <CheckCircle2 className="w-3 h-3" />
                    Готово
                  </Badge>
                ) : isFuture ? (
                  <Button size="sm" variant="ghost" disabled className="text-xs h-7">
                    Заблокировано
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant={isCurrent ? 'default' : 'outline'}
                    onClick={() => handleAction(day)}
                    disabled={verifying === day.key}
                    className={cn(
                      'text-xs h-7 gap-1',
                      isCurrent && 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600'
                    )}
                  >
                    {verifying === day.key ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : null}
                    {day.cta}
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
