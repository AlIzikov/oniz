// BizON — Этап 6.4 ONB-9: Onboarding Banner
// Compact banner shown in app-shell when user.onboardingStep < 5.
// CTA «Продолжить» открывает OnboardingFlow dialog.
'use client';

import * as React from 'react';
import { useAppStore } from '@/stores/app-store';
import type { UserPublic } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Sparkles, X, ChevronRight } from 'lucide-react';
import { OnboardingFlow } from './onboarding-flow';

const DISMISS_KEY = 'bizon-onboarding-banner-dismissed';

// TODO(11-a): onboardingStep отсутствует в UserPublic ('@/lib/types') — локальное расширение,
// удалить после добавления поля в общий тип.
type OnboardingBannerUser = UserPublic & { onboardingStep?: number | null };

export function OnboardingBanner() {
  const user = useAppStore((s) => s.user) as OnboardingBannerUser | null;
  const [flowOpen, setFlowOpen] = React.useState(false);
  const [dismissed, setDismissed] = React.useState(false);

  React.useEffect(() => {
    try {
      if (localStorage.getItem(DISMISS_KEY) === 'true') {
        setDismissed(true);
      }
    } catch {
      // ignore
    }
  }, []);

  if (!user) return null;
  const step = user.onboardingStep ?? 0;
  if (step >= 5) return null; // онбординг завершён — не показываем
  if (dismissed) return null;

  function dismiss() {
    setDismissed(true);
    try {
      localStorage.setItem(DISMISS_KEY, 'true');
    } catch {
      // ignore
    }
  }

  const percent = Math.round((step / 5) * 100);

  return (
    <>
      <div className="border-b border-lighthouse/20 bg-lighthouse/5 px-3 py-2">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <div className="w-7 h-7 rounded-lg lighthouse-gradient flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium leading-tight">
                Завершите онбординг ({step} из 5)
              </div>
              <div className="flex items-center gap-2 mt-1">
                <Progress value={percent} className="h-1 max-w-[200px]" />
                <span className="text-xs text-muted-foreground tabular-nums">{percent}%</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <Button
              size="sm"
              variant="default"
              onClick={() => setFlowOpen(true)}
              className="h-7 text-xs gap-1 bg-lighthouse hover:bg-lighthouse/90 text-white"
            >
              Продолжить
              <ChevronRight className="w-3.5 h-3.5" />
            </Button>
            <button
              onClick={dismiss}
              className="p-1 rounded hover:bg-accent transition"
              title="Скрыть баннер"
              aria-label="Скрыть баннер"
            >
              <X className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>

      <OnboardingFlow open={flowOpen} onClose={() => setFlowOpen(false)} />
    </>
  );
}
