// BizON — Этап 6.4 ONB: Onboarding Flow (раздельный по типам аккаунтов)
// 3 flow: individual / company / hr_agency — каждый по 5 шагов.
// Шаги определены в OnboardingService (server side); тут — UI с прогресс-баром.
//
// Открытие: извне через <OnboardingFlow open={true} onClose={...} />.
// Также показывается автоматически внутри MeView, если onboardingStep < 5.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import type { UserPublic } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import {
  X, Check, ChevronLeft, ChevronRight, Loader2, Sparkles, SkipForward,
  User as UserIcon, Award, FolderKanban, Users, ShieldCheck, Building2, Briefcase,
} from 'lucide-react';
import { cn } from '@/lib/utils';

type AccountType = 'individual' | 'company' | 'hr_agency';

// TODO(11-a): onboardingStep отсутствует в UserPublic ('@/lib/types') —
// локальное расширение, удалить после добавления поля в общий тип.
type OnboardingUser = UserPublic & { onboardingStep?: number | null };

interface StepDef {
  step: number;
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  ctaLabel: string;
  ctaView?: 'me' | 'projects' | 'network' | 'feed' | 'companies' | 'jobs';
}

// Локальные определения шагов (дублируют server side для UI)
const FLOW_STEPS: Record<AccountType, StepDef[]> = {
  individual: [
    { step: 1, title: 'Имя, должность и bio', description: 'Заполните базовый профиль — это основа паспорта доверия.', icon: UserIcon, ctaLabel: 'Заполнить профиль', ctaView: 'me' },
    { step: 2, title: '3-5 навыков с самооценкой', description: 'Перечислите ключевые навыки — коллеги смогут их подтвердить.', icon: Award, ctaLabel: 'Добавить навыки', ctaView: 'me' },
    { step: 3, title: 'Создать первый проект', description: 'Опишите проект, над которым работали.', icon: FolderKanban, ctaLabel: 'Создать проект', ctaView: 'projects' },
    { step: 4, title: 'Пригласить 1 коллегу', description: 'Пригласите коллегу — он сможет подтвердить ваши навыки.', icon: Users, ctaLabel: 'Найти коллегу', ctaView: 'network' },
    { step: 5, title: 'Получить первое подтверждение', description: 'Получите подтверждение навыка от коллеги — это повышает IP-score.', icon: ShieldCheck, ctaLabel: 'Запросить подтверждение', ctaView: 'network' },
  ],
  company: [
    { step: 1, title: 'ИНН и верификация', description: 'Укажите ИНН компании и пройдите верификацию.', icon: Building2, ctaLabel: 'Указать ИНН', ctaView: 'companies' },
    { step: 2, title: 'О компании и специализация', description: 'Заполните описание компании и отрасль специализации.', icon: Building2, ctaLabel: 'Заполнить профиль', ctaView: 'companies' },
    { step: 3, title: 'Команда (минимум 1 участник)', description: 'Добавьте хотя бы одного сотрудника в команду.', icon: Users, ctaLabel: 'Добавить сотрудника', ctaView: 'companies' },
    { step: 4, title: 'Первый кейс (проект)', description: 'Добавьте завершённый проект как кейс компании.', icon: FolderKanban, ctaLabel: 'Добавить кейс', ctaView: 'projects' },
    { step: 5, title: 'Cultural Signals', description: 'Получите первый отзыв сотрудника о культуре компании.', icon: ShieldCheck, ctaLabel: 'Открыть Cultural Signals', ctaView: 'companies' },
  ],
  hr_agency: [
    { step: 1, title: 'ИНН и верификация', description: 'Укажите ИНН агентства и пройдите верификацию.', icon: Building2, ctaLabel: 'Указать ИНН', ctaView: 'companies' },
    { step: 2, title: 'Специализация', description: 'Выберите специализацию: IT / Product / Data / Design.', icon: Briefcase, ctaLabel: 'Выбрать специализацию', ctaView: 'companies' },
    { step: 3, title: 'Первый placement', description: 'Создайте первый placement — кого и куда направили.', icon: Users, ctaLabel: 'Создать placement', ctaView: 'jobs' },
    { step: 4, title: 'Client reference', description: 'Получите отзыв от клиента — компании, которой направили кандидата.', icon: ShieldCheck, ctaLabel: 'Запросить отзыв', ctaView: 'network' },
    { step: 5, title: 'Privacy Shield настройки', description: 'Настройте Privacy Shield для кандидатов.', icon: ShieldCheck, ctaLabel: 'Настроить Privacy Shield', ctaView: 'me' },
  ],
};

interface OnboardingFlowProps {
  open: boolean;
  onClose?: () => void;
  /** Необязательный callback после завершения онбординга */
  onComplete?: () => void;
}

export function OnboardingFlow({ open, onClose, onComplete }: OnboardingFlowProps) {
  const store = useAppStore();
  const user = store.user as OnboardingUser | null;
  const setUser = store.setUser;
  const setView = store.setView;
  const [loading, setLoading] = React.useState(false);
  const [skipping, setSkipping] = React.useState(false);
  const [canSkip, setCanSkip] = React.useState(false);

  // Текущий шаг = max(1, user.onboardingStep + 1) если onboarding не завершён.
  // onboardingStep: 0 = не начинал → показываем шаг 1
  // onboardingStep: 1 = шаг 1 выполнен → показываем шаг 2
  // onboardingStep: 5 = завершён → flow не показывается
  const accountType = (user?.accountType ?? 'individual') as AccountType;
  const steps = FLOW_STEPS[accountType] ?? FLOW_STEPS.individual;
  const currentStep = Math.min((user?.onboardingStep ?? 0) + 1, 5);
  const activeIdx = Math.max(0, Math.min(currentStep - 1, steps.length - 1));
  const activeStep = steps[activeIdx];
  const isComplete = (user?.onboardingStep ?? 0) >= 5;

  React.useEffect(() => {
    if (!open) return;
    api<{ canSkip: boolean; isComplete: boolean }>('/api/onboarding/status')
      .then((res) => setCanSkip(res.canSkip))
      .catch(() => {});
  }, [open, user?.onboardingStep]);

  async function completeStep(step: number) {
    setLoading(true);
    try {
      const res = await api<{ ok: boolean; onboardingStep: number; isComplete: boolean }>(
        '/api/onboarding/complete-step',
        { method: 'POST', body: JSON.stringify({ step }) },
      );
      if (user) {
        setUser({ ...user, onboardingStep: res.onboardingStep } as UserPublic);
      }
      if (res.isComplete) {
        toast({ title: 'Онбординг завершён!', description: 'Добро пожаловать в BizON.' });
        onComplete?.();
        onClose?.();
      }
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  async function handleSkip() {
    setSkipping(true);
    try {
      const res = await api<{ ok: boolean; onboardingStep: number; isComplete: boolean }>(
        '/api/onboarding/skip',
        { method: 'POST' },
      );
      if (user) {
        setUser({ ...user, onboardingStep: res.onboardingStep } as UserPublic);
      }
      toast({ title: 'Онбординг пропущен' });
      onComplete?.();
      onClose?.();
    } catch (e: any) {
      toast({ title: 'Не удалось пропустить', description: e.message, variant: 'destructive' });
    } finally {
      setSkipping(false);
    }
  }

  function handleCtaClick() {
    if (activeStep?.ctaView) {
      setView(activeStep.ctaView);
    }
    onClose?.();
  }

  if (!user) return null;

  const completedCount = user.onboardingStep ?? 0;
  const percent = Math.round((completedCount / 5) * 100);

  return (
    <Dialog open={open && !isComplete} onOpenChange={(o) => { if (!o) onClose?.(); }}>
      <DialogContent className="sm:max-w-[560px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-lighthouse" />
            Онбординг · {accountType === 'individual' ? 'Частное лицо' : accountType === 'company' ? 'Компания' : 'HR-агентство'}
          </DialogTitle>
          <DialogDescription>
            Шаг {currentStep} из 5 — пройдите все шаги, чтобы получить максимальную отдачу от BizON.
          </DialogDescription>
        </DialogHeader>

        {/* Progress bar */}
        <div className="space-y-1.5 my-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Прогресс</span>
            <span className="text-xs font-medium tabular-nums">{completedCount} из 5</span>
          </div>
          <Progress value={percent} className="h-1.5" />
        </div>

        {/* Steps list */}
        <div className="space-y-2 max-h-[40vh] overflow-y-auto scroll-area-thin pr-1">
          {steps.map((s, idx) => {
            const isDone = idx < completedCount;
            const isActive = idx === activeIdx;
            const isFuture = idx > activeIdx;
            const Icon = s.icon;
            return (
              <div
                key={s.step}
                className={cn(
                  'flex items-start gap-3 p-3 rounded-lg border transition',
                  isDone && 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-500/30',
                  isActive && !isDone && 'border-emerald-500 bg-emerald-50/30 dark:bg-emerald-950/10',
                  isFuture && 'opacity-60 bg-muted/30 border-border',
                  !isDone && !isActive && !isFuture && 'border-border',
                )}
              >
                <div
                  className={cn(
                    'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0',
                    isDone
                      ? 'bg-emerald-600 text-white'
                      : isFuture
                        ? 'bg-muted text-muted-foreground'
                        : 'bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400',
                  )}
                >
                  {isDone ? <Check className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs text-muted-foreground tabular-nums">Шаг {s.step}</span>
                    {isActive && !isDone && (
                      <Badge variant="outline" className="text-xs py-0 px-1.5 border-emerald-500 text-emerald-700 dark:text-emerald-400">
                        сейчас
                      </Badge>
                    )}
                    {isDone && (
                      <Badge variant="secondary" className="text-xs py-0 px-1.5 text-emerald-700 dark:text-emerald-400 gap-0.5">
                        <Check className="w-2.5 h-2.5" /> готово
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm font-medium leading-tight mt-0.5">{s.title}</div>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{s.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Active step CTA */}
        {!isComplete && activeStep && (
          <div className="mt-3 p-3 rounded-lg bg-muted/40 border border-border">
            <div className="text-xs font-medium mb-1">Текущий шаг</div>
            <div className="text-sm font-medium">{activeStep.title}</div>
            <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{activeStep.description}</p>
            <div className="flex items-center gap-2 mt-3">
              <Button size="sm" variant="default" onClick={handleCtaClick} className="gap-1.5">
                {activeStep.ctaLabel}
                <ChevronRight className="w-3.5 h-3.5" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => completeStep(activeStep.step)}
                disabled={loading}
                className="gap-1.5"
                title="Отметить шаг выполненным (после того, как вы его действительно сделали)"
              >
                {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                Отметить выполненным
              </Button>
            </div>
          </div>
        )}

        {/* Skip — только если ipScore > 50 */}
        {canSkip && !isComplete && (
          <div className="flex items-center justify-between gap-2 pt-2 border-t">
            <p className="text-xs text-muted-foreground">
              IP-score &gt; 50 — можно пропустить онбординг.
            </p>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleSkip}
              disabled={skipping}
              className="text-muted-foreground gap-1.5"
            >
              {skipping ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <SkipForward className="w-3.5 h-3.5" />}
              Пропустить
            </Button>
          </div>
        )}

        {/* Close button at bottom */}
        <div className="flex justify-end pt-2">
          <Button size="sm" variant="ghost" onClick={() => onClose?.()} className="text-muted-foreground">
            Закрыть
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
