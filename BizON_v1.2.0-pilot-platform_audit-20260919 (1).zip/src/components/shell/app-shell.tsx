// BizON — App Shell (sidebar + topbar + content area)
// Реализует desktop-first 3-колоночный layout по ТЗ 4.1.1
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useTheme } from 'next-themes';
import { toast } from '@/hooks/use-toast';
import type { AppView, UserPublic } from '@/lib/types';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge, IpScoreRing } from '@/components/common/trust-badge';
import {
  Network, LayoutGrid, FolderKanban, Briefcase, Users, Brain, Sparkles,
  Settings, LogOut, Search, Bell, Moon, Sun, Plus, ChevronRight, Crown, Compass,
  Building2, Calendar, MoreHorizontal, FolderGit, MessagesSquare, Home, Award,
  MessageSquare, Share2, Network as NetworkIcon, Vote, ArrowLeft, Newspaper, UserCircle, X, Loader2,
  ShoppingBag,
} from 'lucide-react';
import { AICoPilot } from '@/components/ai-co-pilot/ai-co-pilot';
import { io, type Socket } from 'socket.io-client';
import { SubSectionBar } from '@/components/shell/sub-section-bar';
import { CompactCalendar } from '@/components/feed/compact-calendar';

// 6 основных + «Ещё» (Miller's Law 7±2)
// Для individual — стандартный набор
const NAV_MAIN_INDIVIDUAL: Array<{ view: AppView; label: string; icon: React.ReactNode; minLevel?: string }> = [
  { view: 'dashboard', label: 'Главная', icon: <Compass className="w-4 h-4" /> },
  { view: 'feed', label: 'Новости', icon: <Newspaper className="w-4 h-4" /> },
  { view: 'profile', label: 'Профиль', icon: <UserCircle className="w-4 h-4" /> },
  { view: 'companies', label: 'Компании', icon: <Building2 className="w-4 h-4" /> },
  { view: 'jobs', label: 'Работа', icon: <Briefcase className="w-4 h-4" /> },
  { view: 'network', label: 'Контакты', icon: <Users className="w-4 h-4" /> },
];

// Для company/hr_agency — тот же набор, «Маяк» остаётся философией, не кнопкой
const NAV_MAIN_COMPANY: Array<{ view: AppView; label: string; icon: React.ReactNode; minLevel?: string }> = [
  { view: 'dashboard', label: 'Главная', icon: <Compass className="w-4 h-4" /> },
  { view: 'jobs', label: 'Работа', icon: <Briefcase className="w-4 h-4" /> },
  { view: 'feed', label: 'Новости', icon: <Newspaper className="w-4 h-4" /> },
  { view: 'profile', label: 'Профиль', icon: <UserCircle className="w-4 h-4" /> },
  { view: 'companies', label: 'Компании', icon: <Building2 className="w-4 h-4" /> },
  { view: 'network', label: 'Контакты', icon: <Users className="w-4 h-4" /> },
];

// FIX-05A: «Контакты», «Работа», «Компании» добавлены сюда — мобильный таб-бар (grid-cols-5)
// показывает только 4 основных раздела + кнопку «Ещё», всё остальное — в этом sheet.
// На десктопе эти пункты отфильтровываются (они и так есть в NAV_MAIN) — см. dedupe ниже.
const NAV_MORE: Array<{ view: AppView; label: string; icon: React.ReactNode; minLevel?: string }> = [
  { view: 'network', label: 'Контакты', icon: <Users className="w-4 h-4" /> },
  { view: 'jobs', label: 'Работа', icon: <Briefcase className="w-4 h-4" /> },
  { view: 'companies', label: 'Компании', icon: <Building2 className="w-4 h-4" /> },
  { view: 'messages', label: 'Сообщения', icon: <MessageSquare className="w-4 h-4" /> },
  { view: 'communities', label: 'Сообщества', icon: <MessagesSquare className="w-4 h-4" /> },
  { view: 'projects', label: 'Проекты', icon: <FolderKanban className="w-4 h-4" /> },
  { view: 'store', label: 'Store', icon: <ShoppingBag className="w-4 h-4" /> },
  { view: 'trust-graph', label: 'Граф доверия', icon: <NetworkIcon className="w-4 h-4" /> },
  { view: 'nft-skills', label: 'NFT-навыки', icon: <Award className="w-4 h-4" />, minLevel: 'extended' },
  { view: 'dao', label: 'DAO', icon: <Vote className="w-4 h-4" />, minLevel: 'extended' },
  { view: 'matchmaker', label: 'AI-Поиск', icon: <Sparkles className="w-4 h-4" /> },
  { view: 'career', label: 'AI-Карьера', icon: <Brain className="w-4 h-4" /> },
  { view: 'subscription', label: 'Тарифы', icon: <Crown className="w-4 h-4" /> },
  { view: 'settings', label: 'Настройки', icon: <Settings className="w-4 h-4" /> },
];

// Направление Г: форма ответа /api/search для превью хедер-поиска
interface HeaderSearchResults {
  users: Array<{ id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number; level: string }>;
  companies: Array<{ id: string; name: string; logoUrl: string | null; industry: string | null; location: string | null }>;
  jobs: Array<{ id: string; title: string; company: string; location: string | null; salaryMin: number | null; salaryTo: number | null }>;
  communities: Array<{ id: string; slug: string; name: string; membersCount: number }>;
  totals: { users: number; companies: number; jobs: number; communities: number; projects: number };
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { user, view, setView, setProfileUserId, setUser, logout, goBack, viewHistory, setSelectedCompanyId, setSelectedCommunitySlug } = useAppStore();
  const { theme, setTheme } = useTheme();
  const [searchQuery, setSearchQuery] = React.useState('');
  // Направление Г: мульти-сущностное превью из /api/search (5 категорий) вместо только людей
  const [searchResults, setSearchResults] = React.useState<HeaderSearchResults | null>(null);
  const [searchOpen, setSearchOpen] = React.useState(false);
  const [hydrated, setHydrated] = React.useState(false);
  const [moreOpen, setMoreOpen] = React.useState(false);
  // P1-3: Mobile «Ещё» sheet
  const [moreSheetOpen, setMoreSheetOpen] = React.useState(false);
  // Collapse sidebar — сохраняем в localStorage чтобы запомнить выбор пользователя
  const [sidebarCollapsed, setSidebarCollapsed] = React.useState(false);

  // FIX-08: ToS-баннер — показываем пока условия люмен-программы (/legal)
  // не приняты. Dismissible per session: флаг в sessionStorage живёт до
  // закрытия вкладки (не путать с самим согласием — оно в acceptedTosAt в БД).
  const [tosBannerDismissed, setTosBannerDismissed] = React.useState(() => {
    if (typeof window === 'undefined') return false;
    try { return sessionStorage.getItem('bizon-tos-banner-dismissed') === '1'; } catch { return false; }
  });
  const [tosAccepting, setTosAccepting] = React.useState(false);
  const showTosBanner = !!user && !user.tosAccepted && !tosBannerDismissed;

  function dismissTosBanner() {
    setTosBannerDismissed(true);
    try { sessionStorage.setItem('bizon-tos-banner-dismissed', '1'); } catch {}
  }

  async function acceptTos() {
    if (!user) return;
    setTosAccepting(true);
    try {
      await api('/api/me/accept-tos', { method: 'PATCH' });
      setUser({ ...user, tosAccepted: true } as UserPublic);
      dismissTosBanner();
      toast({ title: 'Условия люмен-программы приняты' });
    } catch (e: any) {
      toast({ title: 'Не удалось сохранить согласие', description: e.message, variant: 'destructive' });
    } finally {
      setTosAccepting(false);
    }
  }

  React.useEffect(() => {
    const saved = localStorage.getItem('bizon-sidebar-collapsed');
    if (saved === 'true') setSidebarCollapsed(true);
  }, []);

  function toggleSidebar() {
    setSidebarCollapsed((v) => {
      const next = !v;
      localStorage.setItem('bizon-sidebar-collapsed', String(next));
      // При коллапсе закрываем раскрытое «Ещё»
      if (next) setMoreOpen(false);
      return next;
    });
  }

  // Выбираем навигацию по типу аккаунта
  const NAV_MAIN = user?.accountType === 'company' || user?.accountType === 'hr_agency' ? NAV_MAIN_COMPANY : NAV_MAIN_INDIVIDUAL;

  // FIX-05A: мобильный таб-бар = 4 основных раздела + кнопка «Ещё» → 5 колонок (grid-cols-5).
  // Бывшие 5-й и 6-й пункты («Работа»/«Компании»/«Контакты») доступны через sheet «Ещё» (NAV_MORE).
  const NAV_MOBILE_PRIMARY_COUNT = 4;

  React.useEffect(() => { setHydrated(true); }, []);

  // Клавиатурная навигация: Alt+← = Назад, как в браузере
  React.useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      // Alt+стрелка влево — назад (как в браузере)
      if (e.altKey && e.key === 'ArrowLeft') {
        if (viewHistory.length > 0) {
          e.preventDefault();
          goBack();
        }
      }
      // Cmd/Ctrl+стрелка влево — тоже назад (привычный shortcut)
      if ((e.metaKey || e.ctrlKey) && e.key === 'ArrowLeft') {
        if (viewHistory.length > 0) {
          e.preventDefault();
          goBack();
        }
      }
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [viewHistory.length, goBack]);

  // Search
  React.useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults(null);
      setSearchOpen(false);
      return;
    }
    const t = setTimeout(async () => {
      try {
        // Направление Г: единый /api/search (5 категорий) вместо только людей
        const res = await api<HeaderSearchResults>(`/api/search?q=${encodeURIComponent(searchQuery.trim())}&limit=20`);
        const hasAny = res.totals && (res.totals.users + res.totals.companies + res.totals.jobs + res.totals.communities + res.totals.projects) > 0;
        setSearchResults(res);
        setSearchOpen(!!hasAny);
      } catch {}
    }, 250);
    return () => clearTimeout(t);
  }, [searchQuery]);

  // Направление Г: Enter и «Все результаты» — переход к полному поиску /search?q=
  function openFullSearch() {
    const q = searchQuery.trim();
    if (q.length < 2) return;
    setSearchOpen(false);
    window.location.assign(`/search?q=${encodeURIComponent(q)}`);
  }

  // Направление Г: клик по сущности в превью — переход к ней без перезагрузки (кроме вакансий)
  function openEntity(type: 'user' | 'company' | 'community' | 'job', id: string) {
    setSearchOpen(false);
    setSearchQuery('');
    if (type === 'user') { setProfileUserId(id); setView('profile'); return; }
    if (type === 'company') { setSelectedCompanyId(id); return; }
    if (type === 'community') { setSelectedCommunitySlug(id); return; }
    // вакансия: deep-link читает URL только при монтировании — полный nav
    window.location.assign(`/?view=jobs&jobId=${encodeURIComponent(id)}`);
  }

  if (!user) return null;

  async function handleLogout() {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
    logout();
    toast({ title: 'Вы вышли из BizON' });
  }

  function openProfile(id: string) {
    setProfileUserId(id);
    setSearchOpen(false);
    setSearchQuery('');
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* TopBar */}
      <header className="h-14 border-b bg-card/80 backdrop-blur flex items-center px-4 gap-3 flex-shrink-0 z-30">
        {/* Кнопка "Назад" — видна только когда есть история навигации.
            Работает как "-1": возвращает на 1 шаг назад (смена раздела или подменю) */}
        {viewHistory.length > 0 && (
          <button
            onClick={goBack}
            className="lighthouse-gradient text-white flex items-center gap-1.5 px-3 h-9 rounded-md text-sm font-medium shadow-md hover:shadow-lg hover:opacity-90 transition group beacon-pulse"
            title="Назад — на один шаг"
            aria-label="Назад"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
            <span className="hidden sm:inline">Назад</span>
          </button>
        )}

        <button
          onClick={() => { setView('dashboard'); setProfileUserId(null); }}
          className="flex items-center hover:opacity-80 transition"
        >
          {/* Логотип: Biz (Navy, на тон светлее) + ON (тёмно-зелёный — индикатор "включено/онлайн")
              Большой шрифт для гармоничного вида, без картинки маяка */}
          <span className="text-2xl font-extrabold tracking-tight leading-none">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span><span className="text-emerald-700 dark:text-emerald-500">ON</span>
          </span>
        </button>

        {/* Search */}
        <div className="flex-1 max-w-2xl relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') openFullSearch(); }}
            placeholder="Поиск по людям, должностям, городам..."
            className="pl-9 h-9"
            onFocus={() => searchResults && setSearchOpen(true)}
            onBlur={() => setTimeout(() => setSearchOpen(false), 200)}
          />
          {searchOpen && searchResults && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-popover border rounded-lg shadow-lg max-h-96 overflow-y-auto scroll-area-thin z-50">
              {/* Направление Г: сгруппированное превью по 5 категориям */}
              {(searchResults.users.length > 0) && (
                <div className="py-1">
                  <div className="px-3 pt-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Люди</div>
                  {searchResults.users.slice(0, 3).map((u) => (
                    <button
                      key={u.id}
                      onMouseDown={() => openEntity('user', u.id)}
                      className="w-full flex items-center gap-3 p-2.5 hover:bg-accent text-left transition"
                    >
                      <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="sm" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{u.name}</div>
                        <div className="text-xs text-muted-foreground truncate">{u.title ?? ''}</div>
                      </div>
                      <TrustBadge ipScore={u.ipScore} level={u.level} size="sm" />
                    </button>
                  ))}
                </div>
              )}
              {(searchResults.companies.length > 0) && (
                <div className="py-1 border-t">
                  <div className="px-3 pt-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Компании</div>
                  {searchResults.companies.slice(0, 2).map((c) => (
                    <button
                      key={c.id}
                      onMouseDown={() => openEntity('company', c.id)}
                      className="w-full flex items-center gap-3 p-2.5 hover:bg-accent text-left transition"
                    >
                      <Building2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{c.name}</div>
                        <div className="text-xs text-muted-foreground truncate">{[c.industry, c.location].filter(Boolean).join(' · ')}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
              {(searchResults.jobs.length > 0) && (
                <div className="py-1 border-t">
                  <div className="px-3 pt-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Вакансии</div>
                  {searchResults.jobs.slice(0, 2).map((j) => (
                    <button
                      key={j.id}
                      onMouseDown={() => openEntity('job', j.id)}
                      className="w-full flex items-center gap-3 p-2.5 hover:bg-accent text-left transition"
                    >
                      <Briefcase className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{j.title}</div>
                        <div className="text-xs text-muted-foreground truncate">{[j.company, j.location].filter(Boolean).join(' · ')}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
              {(searchResults.communities.length > 0) && (
                <div className="py-1 border-t">
                  <div className="px-3 pt-1.5 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Сообщества</div>
                  {searchResults.communities.slice(0, 2).map((c) => (
                    <button
                      key={c.id}
                      onMouseDown={() => openEntity('community', c.slug)}
                      className="w-full flex items-center gap-3 p-2.5 hover:bg-accent text-left transition"
                    >
                      <MessagesSquare className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{c.name}</div>
                        <div className="text-xs text-muted-foreground truncate">{c.membersCount} участников</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
              <div className="border-t p-1">
                <button
                  onMouseDown={openFullSearch}
                  className="w-full text-center text-sm text-primary hover:bg-accent rounded-md py-2 transition"
                >
                  Все результаты ({searchResults.totals.users + searchResults.totals.companies + searchResults.totals.jobs + searchResults.totals.communities + searchResults.totals.projects}) →
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1">
          <AICoPilot />
          <NotificationsDropdown />
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} title="Тема">
            {hydrated && theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          <button
            onClick={() => { setProfileUserId(null); setView('profile'); }}
            className="flex items-center gap-2 hover:bg-accent rounded-lg p-1 transition"
          >
            <UserAvatar name={user.name} avatarUrl={user.avatarUrl} size="sm" />
            <span className="hidden md:inline text-sm font-medium max-w-[120px] truncate">{user.name}</span>
          </button>
          <Button variant="ghost" size="icon" onClick={handleLogout} title="Выйти">
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* FIX-08: ToS-баннер — «Примите условия люмен-программы», dismissible per session */}
      {showTosBanner && (
        <div role="status" className="flex-shrink-0 z-20 border-b bg-amber-50 dark:bg-amber-950/40 text-foreground">
          <div className="px-4 py-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
            <span className="font-medium">Примите условия люмен-программы</span>
            <a
              href="/legal"
              target="_blank"
              rel="noopener noreferrer"
              className="underline underline-offset-2 hover:opacity-80"
            >
              Читать
            </a>
            <div className="ml-auto flex items-center gap-1.5">
              <Button size="sm" onClick={acceptTos} disabled={tosAccepting}>
                {tosAccepting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Принимаю'}
              </Button>
              <button
                onClick={dismissTosBanner}
                aria-label="Скрыть баннер"
                title="Скрыть до конца сессии"
                className="p-1.5 rounded-md hover:bg-accent transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main 3-column layout — sidebar и right rail НЕПОДВИЖНЫ, скроллится только центр */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar — FIXED, с возможностью коллапса в icon-only режим */}
        <aside className={cn(
          'border-r bg-card/50 hidden md:flex flex-col flex-shrink-0 overflow-y-auto scroll-area-thin transition-[width] duration-200',
          sidebarCollapsed ? 'w-14' : 'w-60'
        )}>
          {/* Кнопка collapse/expand — в правом верхнем углу сайдбара */}
          <button
            onClick={toggleSidebar}
            className="absolute top-16 right-[-12px] z-10 w-6 h-6 rounded-full border bg-background shadow-sm flex items-center justify-center hover:bg-accent transition"
            title={sidebarCollapsed ? 'Развернуть меню' : 'Свернуть меню'}
            aria-label={sidebarCollapsed ? 'Развернуть меню' : 'Свернуть меню'}
          >
            <ChevronRight className={cn('w-3.5 h-3.5 transition-transform', !sidebarCollapsed && 'rotate-180')} />
          </button>

          <div className={cn('p-4 border-b', sidebarCollapsed && 'p-2')}>
            <button
              onClick={() => { setProfileUserId(null); setView('profile'); }}
              className="w-full flex items-center gap-3 hover:bg-accent rounded-lg p-2 transition text-left"
              title={sidebarCollapsed ? `${user.name} · IP ${user.ipScore}` : undefined}
            >
              <IpScoreRing ipScore={user.ipScore} size={sidebarCollapsed ? 36 : 48} />
              {!sidebarCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm truncate">{user.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{user.title ?? '—'}</div>
                  <TrustBadge ipScore={user.ipScore} level={user.level} size="sm" className="mt-1" />
                </div>
              )}
            </button>
          </div>

          <nav className="flex-1 p-2 space-y-0.5">
            {NAV_MAIN.map((item) => {
              const isActive = view === item.view;
              return (
                <button
                  key={item.view}
                  onClick={() => {
                    if (item.view === 'profile') setProfileUserId(null);
                    setView(item.view);
                    setMoreOpen(false);
                  }}
                  className={cn(
                    'w-full flex items-center gap-2.5 rounded-md text-sm transition',
                    sidebarCollapsed ? 'justify-center px-0 py-2.5' : 'px-3 py-2',
                    isActive
                      ? 'bg-primary text-primary-foreground font-medium'
                      : 'hover:bg-accent text-foreground/80'
                  )}
                  title={sidebarCollapsed ? item.label : undefined}
                >
                  {item.icon}
                  {!sidebarCollapsed && <span className="flex-1 text-left">{item.label}</span>}
                </button>
              );
            })}

            {/* «Ещё» — скрывается в collapsed-режиме */}
            {!sidebarCollapsed && (
              <>
                <button
                  onClick={() => setMoreOpen((v) => !v)}
                  className={cn(
                    'w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition',
                    moreOpen ? 'bg-accent text-foreground' : 'hover:bg-accent text-foreground/80'
                  )}
                >
                  <MoreHorizontal className="w-4 h-4" />
                  <span className="flex-1 text-left">Ещё</span>
                  <ChevronRight className={cn('w-3 h-3 transition', moreOpen && 'rotate-90')} />
                </button>
                {moreOpen && (
                  <div className="space-y-0.5 pl-2 soft-fade-in">
                    {/* FIX-05A: dedupe — пункты, уже показанные в основном сайдбаре, не дублируем в «Ещё» */}
                    {NAV_MORE.filter((item) => !NAV_MAIN.some((n) => n.view === item.view)).map((item) => {
                      const isActive = view === item.view;
                      const minLevel = item.minLevel;
                      const userLevel = user?.level ?? 'basic';
                      const isLocked = minLevel && !(
                        (minLevel === 'extended' && (userLevel === 'extended' || userLevel === 'expert')) ||
                        (minLevel === 'expert' && userLevel === 'expert')
                      );
                      return (
                        <button
                          key={item.view}
                          onClick={() => {
                            if (isLocked) {
                              toast({ title: 'Функция заблокирована', description: `Требуется уровень: ${minLevel}. Ваш уровень: ${userLevel}.` });
                              return;
                            }
                            if (item.view === 'profile') setProfileUserId(null);
                            setView(item.view);
                            setMoreOpen(false);
                          }}
                          className={cn(
                            'w-full flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm transition',
                            isActive
                              ? 'bg-primary text-primary-foreground font-medium'
                              : isLocked
                                ? 'text-muted-foreground/40 cursor-not-allowed'
                                : 'hover:bg-accent text-foreground/70'
                          )}
                        >
                          {item.icon}
                          <span className="flex-1 text-left">{item.label}</span>
                          {isLocked && <span className="text-xs">🔒</span>}
                        </button>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </nav>

          <div className={cn('p-3 border-t space-y-1.5', sidebarCollapsed && 'p-2')}>
            {/* P2-11: Upsell Free→Pro и Pro→Business */}
            {!sidebarCollapsed && user.subscriptionTier === 'free' && (
              <Button
                size="sm"
                className="w-full bg-gradient-to-r from-primary to-emerald-500 text-white hover:opacity-90"
                onClick={() => setView('subscription')}
              >
                <Crown className="w-4 h-4 mr-1.5" /> Перейти на Pro
              </Button>
            )}
            {!sidebarCollapsed && user.subscriptionTier === 'pro' && (
              <Button
                size="sm"
                variant="outline"
                className="w-full border-emerald-500/50 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10"
                onClick={() => setView('subscription')}
              >
                <Building2 className="w-4 h-4 mr-1.5" /> Перейти на Business
              </Button>
            )}
            {sidebarCollapsed ? (
              <Button
                variant="outline"
                size="icon"
                className="w-full"
                onClick={() => setView('projects')}
                title="Создать проект"
              >
                <Plus className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                onClick={() => setView('projects')}
              >
                <Plus className="w-4 h-4 mr-2" /> Создать проект
              </Button>
            )}
          </div>
        </aside>

        {/* Center content — ONLY THIS SCROLLS */}
        <main id="main-content" className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden scroll-area-thin">
          <div className="max-w-3xl mx-auto p-4 sm:p-6">
            {children}
          </div>
        </main>

        {/* Right rail — FIXED, видна на xl+ */}
        <aside className="w-72 border-l bg-card/50 hidden lg:flex flex-col flex-shrink-0 overflow-y-auto scroll-area-thin p-4 gap-4">
          <RightRail />
        </aside>
      </div>

      {/* Mobile bottom nav — 4 основных + «Ещё» = 5 колонок, иначе тесно на 320px (FIX-05A) */}
      <nav className="md:hidden border-t bg-card/95 backdrop-blur sticky bottom-0 grid grid-cols-5 z-30">
        {NAV_MAIN.slice(0, NAV_MOBILE_PRIMARY_COUNT).map((item) => (
          <button
            key={item.view}
            onClick={() => {
              if (item.view === 'profile') setProfileUserId(null);
              setView(item.view);
            }}
            className={cn(
              'flex flex-col items-center gap-0.5 py-2 text-xs',
              view === item.view ? 'text-primary' : 'text-muted-foreground'
            )}
          >
            {item.icon}
            <span className="truncate max-w-full px-1">{item.label.split(' ')[0]}</span>
          </button>
        ))}
        {/* P1-3: кнопка «Ещё» — открывает sheet с остальными разделами */}
        <button
          onClick={() => setMoreSheetOpen(true)}
          className={cn(
            'flex flex-col items-center gap-0.5 py-2 text-xs',
            moreSheetOpen ? 'text-primary' : 'text-muted-foreground'
          )}
        >
          <MoreHorizontal className="w-4 h-4" />
          <span>Ещё</span>
        </button>
      </nav>

      {/* P1-3: Mobile «Ещё» sheet — все недоступные разделы */}
      {moreSheetOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex items-end" onClick={() => setMoreSheetOpen(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div
            className="relative w-full bg-card border-t rounded-t-2xl p-4 pb-6 max-h-[70vh] overflow-y-auto scroll-area-thin soft-fade-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold">Все разделы</span>
              <button onClick={() => setMoreSheetOpen(false)} className="p-1 rounded hover:bg-accent">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {/* FIX-05A: dedupe — не показываем в sheet то, что уже есть в таб-баре */}
              {NAV_MORE.filter((item) => !NAV_MAIN.slice(0, NAV_MOBILE_PRIMARY_COUNT).some((n) => n.view === item.view)).map((item) => {
                const isActive = view === item.view;
                const minLevel = item.minLevel;
                const userLevel = user?.level ?? 'basic';
                const isLocked = minLevel && !(
                  (minLevel === 'extended' && (userLevel === 'extended' || userLevel === 'expert')) ||
                  (minLevel === 'expert' && userLevel === 'expert')
                );
                return (
                  <button
                    key={item.view}
                    onClick={() => {
                      if (isLocked) {
                        toast({ title: 'Функция заблокирована', description: `Требуется уровень: ${minLevel}.` });
                        return;
                      }
                      if (item.view === 'profile') setProfileUserId(null);
                      setView(item.view);
                      setMoreSheetOpen(false);
                    }}
                    className={cn(
                      'flex flex-col items-center gap-1.5 p-3 rounded-lg transition',
                      isActive ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'
                    )}
                  >
                    {item.icon}
                    <span className="text-xs text-center leading-tight">{item.label}</span>
                  </button>
                );
              })}
            </div>
            {user?.subscriptionTier === 'free' && (
              <Button
                size="sm"
                className="w-full mt-4 bg-gradient-to-r from-primary to-emerald-500 text-white"
                onClick={() => { setView('subscription'); setMoreSheetOpen(false); }}
              >
                <Crown className="w-4 h-4 mr-1.5" /> Перейти на Pro
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Smart Button "+" — плавающая AI-кнопка */}
      <SmartButton />
    </div>
  );
}

// Smart Button — плавающая кнопка с AI-предсказанием действий (ТЗ 4.3)
// Улучшенная версия: структурированное меню по 3 категориям + модальные диалоги создания
function SmartButton() {
  const { setView, user, goBack, viewHistory } = useAppStore();
  const [open, setOpen] = React.useState(false);
  // Какой модальный диалог создания открыт
  const [createModal, setCreateModal] = React.useState<null | 'post' | 'project' | 'event' | 'job'>(null);

  // Структурируем действия по категориям (как в iOS share sheet / Android FAB)
  const groups: Array<{
    title: string;
    actions: Array<{ label: string; icon: React.ReactNode; onClick: () => void; primary?: boolean }>;
  }> = [
    {
      title: 'Создать',
      actions: [
        { label: 'Опубликовать пост', icon: <LayoutGrid className="w-4 h-4" />, onClick: () => { setCreateModal('post'); setOpen(false); } },
        { label: 'Новый проект', icon: <FolderKanban className="w-4 h-4" />, onClick: () => { setCreateModal('project'); setOpen(false); } },
        { label: 'Создать событие', icon: <Calendar className="w-4 h-4" />, onClick: () => { setCreateModal('event'); setOpen(false); } },
        // Создание вакансии — только для company/hr_agency
        ...(user?.accountType === 'company' || user?.accountType === 'hr_agency' ? [{
          label: 'Опубликовать вакансию',
          icon: <Briefcase className="w-4 h-4" />,
          onClick: () => { setCreateModal('job'); setOpen(false); },
        }] : []),
      ],
    },
    {
      title: 'Найти',
      actions: [
        { label: 'AI-поиск контакта', icon: <Sparkles className="w-4 h-4" />, onClick: () => { setView('matchmaker'); setOpen(false); }, primary: true },
        { label: 'AI-подбор вакансий', icon: <Briefcase className="w-4 h-4" />, onClick: () => { setView('jobs'); setOpen(false); } },
        { label: 'Карта карьеры', icon: <Brain className="w-4 h-4" />, onClick: () => { setView('career'); setOpen(false); } },
      ],
    },
    {
      title: 'Действия',
      actions: [
        { label: 'Подтвердить навык', icon: <Award className="w-4 h-4" />, onClick: () => { setView('network'); setOpen(false); } },
        // Если есть история — добавляем "Назад"
        ...(viewHistory.length > 0 ? [{
          label: 'Назад',
          icon: <ArrowLeft className="w-4 h-4" />,
          onClick: () => { goBack(); setOpen(false); },
        }] : []),
      ],
    },
  ];

  // Закрытие по клику вне
  const containerRef = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    if (!open) return;
    function onClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    function onEsc(e: KeyboardEvent) {
      if (e.key === 'Escape') setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    document.addEventListener('keydown', onEsc);
    return () => {
      document.removeEventListener('mousedown', onClickOutside);
      document.removeEventListener('keydown', onEsc);
    };
  }, [open]);

  // FIX-05B: на мобильном поднимаем FAB над таб-баром (bottom-20 ≈ 80px), чтобы не перекрывать «Ещё»
  return (
    <div ref={containerRef} className="fixed bottom-20 right-4 md:bottom-6 md:right-6 z-40">
      {open && (
        <div className="absolute bottom-16 right-0 bg-card border rounded-xl shadow-2xl p-2 min-w-[240px] soft-fade-in max-h-[80vh] overflow-y-auto scroll-area-thin">
          {/* Заголовок */}
          <div className="flex items-center justify-between px-2 py-1.5 mb-1 border-b">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Быстрое действие</span>
            <Sparkles className="w-3 h-3 text-lighthouse" />
          </div>

          {/* Группы действий */}
          {groups.map((group) => {
            // Скрываем пустые группы
            if (group.actions.length === 0) return null;
            return (
              <div key={group.title} className="mb-1">
                <div className="text-xs font-medium text-muted-foreground/70 uppercase tracking-wider px-2 py-1">
                  {group.title}
                </div>
                {group.actions.map((a, i) => (
                  <button
                    key={group.title + i}
                    onClick={a.onClick}
                    className={cn(
                      'w-full flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-accent transition text-sm text-left group',
                      a.primary && 'text-primary font-medium'
                    )}
                  >
                    <span className={cn(
                      'shrink-0 transition',
                      a.primary ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'
                    )}>
                      {a.icon}
                    </span>
                    <span className="flex-1">{a.label}</span>
                  </button>
                ))}
              </div>
            );
          })}

          {/* Подсказка */}
          <div className="mt-2 pt-2 border-t px-2 py-1">
            <div className="text-xs text-muted-foreground/60">
              ESC для закрытия · клик вне меню
            </div>
          </div>
        </div>
      )}
      <button
        onClick={() => setOpen((v) => !v)}
        className={cn(
          'w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition beacon-pulse',
          open ? 'bg-destructive text-white rotate-45' : 'lighthouse-gradient text-white'
        )}
        title={open ? 'Закрыть' : 'Быстрое действие (создать, найти, подтвердить)'}
        aria-label={open ? 'Закрыть меню действий' : 'Открыть меню быстрых действий'}
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Модальные диалоги создания контента — единый паттерн для всех типов */}
      <CreateActionModal type={createModal} onClose={() => setCreateModal(null)} />
    </div>
  );
}

// CreateActionModal — модальный диалог создания контента (пост/проект/событие/вакансия)
// В Фазе 2 здесь будут полноценные формы. Сейчас — заглушка с навигацией в нужный раздел
function CreateActionModal({ type, onClose }: { type: null | 'post' | 'project' | 'event' | 'job'; onClose: () => void }) {
  const setView = useAppStore((s) => s.setView);
  if (!type) return null;

  const config = {
    post:    { title: 'Опубликовать пост',   desc: 'Поделитесь новостью, инсайтом или достижением с вашей сетью', icon: <LayoutGrid className="w-5 h-5" />, view: 'feed' as const, cta: 'Перейти к ленте' },
    project: { title: 'Новый проект',         desc: 'Создайте проект, чтобы подтвердить навыки и повысить IP-score', icon: <FolderKanban className="w-5 h-5" />, view: 'projects' as const, cta: 'Перейти к проектам' },
    event:   { title: 'Создать событие',      desc: 'Организуйте митап, воркшоп или вебинар. Доступно на Pro-тарифе', icon: <Calendar className="w-5 h-5" />, view: 'events' as const, cta: 'Перейти к событиям' },
    job:     { title: 'Опубликовать вакансию', desc: 'Найдите лучших кандидатов с помощью AI-подбора по навыкам', icon: <Briefcase className="w-5 h-5" />, view: 'jobs' as const, cta: 'Перейти к вакансиям' },
  }[type];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 soft-fade-in" onClick={onClose}>
      <div
        className="bg-card border rounded-xl shadow-2xl max-w-md w-full p-6 soft-fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Иконка + заголовок */}
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-lg lighthouse-gradient flex items-center justify-center text-white">
            {config.icon}
          </div>
          <h3 className="text-lg font-semibold">{config.title}</h3>
        </div>
        {/* Описание */}
        <p className="text-sm text-muted-foreground mb-4">{config.desc}</p>
        {/* Заглушка: полная форма будет в Фазе 2 */}
        <div className="text-xs bg-muted/50 border border-dashed border-border rounded-md p-3 mb-4 text-muted-foreground">
          🚧 Полноценная форма создания будет добавлена в Фазе 2. Сейчас вы можете создать контент напрямую в соответствующем разделе.
        </div>
        {/* Действия */}
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose}>
            Отмена
          </Button>
          <Button
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
            onClick={() => { setView(config.view); onClose(); }}
          >
            {config.cta}
            <ChevronRight className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// Notifications Dropdown — рабочие уведомления (ТЗ 4.1.1) + live-доставка (направление Б).
// Канон — REST (GET /api/notifications); socket — только транспорт:
// notification:new → мгновенный prepend + badge++, notification:refresh → тихий рефетч.
// Поллинг 30с сохранён как фолбэк при недоступности chat-service.
function NotificationsDropdown() {
  const [open, setOpen] = React.useState(false);
  const [notifications, setNotifications] = React.useState<any[]>([]);
  const [unreadCount, setUnreadCount] = React.useState(0);

  const loadNotifications = React.useCallback(async () => {
    try {
      const res = await api<{ notifications: any[]; unreadCount: number }>('/api/notifications');
      setNotifications(res.notifications);
      setUnreadCount(res.unreadCount);
    } catch {}
  }, []);

  React.useEffect(() => {
    loadNotifications();
    const interval = setInterval(loadNotifications, 30000); // фолбэк, пока сокет жив — не срабатывает
    return () => clearInterval(interval);
  }, [loadNotifications]);

  // Направление Б: постоянный сокет live-уведомлений (тот же контракт, что у чата)
  React.useEffect(() => {
    const socket: Socket = io('/?XTransformPort=3003', {
      withCredentials: true,
      transports: ['polling', 'websocket'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelayMax: 5000,
      timeout: 10000,
    });

    socket.on('notification:new', (n: any) => {
      if (!n || typeof n.id !== 'string') return;
      setNotifications((prev) => (prev.some((x) => x.id === n.id) ? prev : [n, ...prev]));
      setUnreadCount((c) => c + 1);
      // Тост только для не-message типов: новое сообщение в открытом диалоге
      // и так доставляется живым пузырём (направление А) — без двойного шума.
      if (n.type !== 'message') {
        toast({ title: n.title || 'Новое уведомление', description: n.content || undefined });
      }
    });

    // Bulk-случаи (createMany) — сигнала «список изменился» достаточно
    socket.on('notification:refresh', () => { void loadNotifications(); });

    return () => { socket.disconnect(); };
  }, [loadNotifications]);

  async function markAllRead() {
    try {
      await api('/api/notifications/read', { method: 'POST' });
      setUnreadCount(0);
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    } catch {}
  }

  return (
    <div className="relative">
      <Button variant="ghost" size="icon" onClick={() => { setOpen(v => !v); if (!open && unreadCount > 0) markAllRead(); }} title="Уведомления" className="relative">
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 bg-destructive text-white text-xs rounded-full flex items-center justify-center">{unreadCount > 9 ? '9+' : unreadCount}</span>}
      </Button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 bg-card border rounded-xl shadow-xl w-80 max-h-96 overflow-y-auto scroll-area-thin z-20 soft-fade-in">
            <div className="p-3 border-b flex items-center justify-between">
              <span className="text-sm font-semibold">Уведомления</span>
              {unreadCount > 0 && <span className="text-xs text-muted-foreground">{unreadCount} новых</span>}
            </div>
            {notifications.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">Нет уведомлений</div>
            ) : (
              notifications.slice(0, 10).map(n => (
                <div key={n.id} className={`p-3 border-b last:border-0 ${!n.isRead ? 'bg-lighthouse/5' : ''}`}>
                  <div className="text-sm font-medium">{n.title}</div>
                  {n.content && <div className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.content}</div>}
                  <div className="text-xs text-muted-foreground mt-1">{new Date(n.createdAt).toLocaleString('ru-RU')}</div>
                </div>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
// SectionTitle — единый заголовок секции с зелёным вертикальным якорем слева
// Используется в RightRail и других местах для визуальной консистентности
function SectionTitle({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('flex items-center gap-2 mb-2', className)}>
      <span className="w-1 h-3 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{children}</span>
    </div>
  );
}

function RightRail() {
  const { setView, setProfileUserId, view } = useAppStore();
  const [ad, setAd] = React.useState<any>(null);
  const [adLoaded, setAdLoaded] = React.useState(false);

  // Lazy-load ad только после задержки 2с, чтобы не конкурировать с основным контентом
  React.useEffect(() => {
    const timer = setTimeout(() => {
      api<{ ad: any }>('/api/ads').then((res) => { setAd(res.ad); setAdLoaded(true); }).catch(() => {});
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <div>
        <SectionTitle>Быстрые действия</SectionTitle>
        <div className="space-y-1">
          <button
            onClick={() => { setProfileUserId(null); setView('matchmaker'); }}
            className="w-full flex items-center justify-between p-2 rounded-md hover:bg-accent text-sm transition"
          >
            <span className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" /> Найти контакт</span>
            <ChevronRight className="w-3 h-3 text-muted-foreground" />
          </button>
          <button
            onClick={() => setView('career')}
            className="w-full flex items-center justify-between p-2 rounded-md hover:bg-accent text-sm transition"
          >
            <span className="flex items-center gap-2"><Brain className="w-4 h-4 text-primary" /> Карта карьеры</span>
            <ChevronRight className="w-3 h-3 text-muted-foreground" />
          </button>
          <button
            onClick={() => setView('jobs')}
            className="w-full flex items-center justify-between p-2 rounded-md hover:bg-accent text-sm transition"
          >
            <span className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-primary" /> AI-подбор вакансий</span>
            <ChevronRight className="w-3 h-3 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Подразделы текущего view (Лента/Моё/Социальное) */}
      <SubSectionBar view={view} />

      {/* CompactCalendar — только на странице Ленты новостей */}
      {view === 'feed' && <CompactCalendar />}

      {ad && (
        <div>
          <SectionTitle>Рекомендованный партнёр</SectionTitle>
          <button
            onClick={async () => {
              // W2.4 (DEF-14): фиксируем клик и делаем РЕАЛЬНЫЙ переход,
              // если у объявления есть безопасный outbound-URL. Без URL —
              // честная фиксация интереса, никакого ложного «переход выполнен».
              try {
                const res = await api<{ ok: boolean; targetUrl: string | null }>('/api/ads', {
                  method: 'POST',
                  body: JSON.stringify({ adId: ad.id }),
                });
                if (res.targetUrl) {
                  window.open(res.targetUrl, '_blank', 'noopener,noreferrer');
                } else {
                  toast({ title: 'Зафиксирован интерес к партнёру' });
                }
              } catch {}
            }}
            className="block w-full text-left p-3 rounded-lg border bg-gradient-to-br from-accent/50 to-accent hover:border-primary transition group"
          >
            <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <span className="bg-primary/15 text-primary px-1.5 py-0.5 rounded font-medium">ATI {Math.round(ad.adTrustIndex * 100)}</span>
              <span>Партнёр</span>
            </div>
            <div className="font-semibold text-sm mb-1 group-hover:text-primary transition">{ad.title}</div>
            <div className="text-xs text-muted-foreground line-clamp-2">{ad.content}</div>
          </button>
        </div>
      )}

      <div className="mt-auto text-xs text-muted-foreground">
        <div className="flex items-center gap-1 mb-1">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
          <span>Система работает</span>
        </div>
        <div>v10.0 MVP · Фаза 1</div>
      </div>
    </>
  );
}
