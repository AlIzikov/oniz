// BizON — SubSectionBar
// Универсальная правая панель подразделов для разделов (Вакансии/Новости/Объявления)
//
// Эталонная 3-блочная структура (по ресёрчу LinkedIn/Otta/Reddit/X):
//   ▌Лента      → Рекомендуемое [AI] (default) + Все + От друзей
//   ▌Моё        → Мои [посты/вакансии] + Избранное + (Подборки)
//   ▌Социальное → Избранные группы/компании/продавцы
//
// Источники:
//   - LinkedIn Job tracker (Saved/In progress/Applied/Interview/Archived)
//   - Otta sequential card flow + Saved/Applied
//   - Reddit Home/Popular/Following + Communities sidebar
//   - X (Twitter) For You / Following
//   - Etsy Collections (для «Избранные группы/новости»)
//   - NN/g Menu Design Checklist (Jun 2024) — lateral exploration
//
// См. отчёт: /home/z/my-project/download/SubSectionBar-UX-research.md
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import type {
  FeedSubSection, JobsSubSection, AdsSubSection,
} from '@/stores/app-store';
import type { AppView } from '@/lib/types';
import { cn } from '@/lib/utils';
import { SavedFiltersPanel } from '@/components/jobs/saved-filters-panel';
import {
  Sparkles, LayoutGrid, Users, FileText, Bookmark, FolderOpen,
  Briefcase, Flame, Building2, Megaphone, Store, Heart, Map as MapIcon,
} from 'lucide-react';

// === Типы ===
type SectionDef = {
  id: string;
  label: string;
  icon: React.ReactNode;
  badgeKey?: string; // ключ в counts для бейджа
};

type BlockDef = {
  title: string;
  items: SectionDef[];
};

type SubSectionConfig = {
  active: string;
  onSelect: (id: string) => void;
  blocks: BlockDef[];
  counts?: Record<string, number>;
};

// === Конфиги для каждого раздела ===

const FEED_CONFIG: Omit<SubSectionConfig, 'active' | 'onSelect' | 'counts'> = {
  blocks: [
    {
      title: 'Лента',
      items: [
        { id: 'recommended', label: 'Рекомендуемое', icon: <Sparkles className="w-4 h-4" />, badgeKey: 'recommended' },
        { id: 'all', label: 'Все новости', icon: <LayoutGrid className="w-4 h-4" />, badgeKey: 'all' },
        { id: 'friends', label: 'От друзей', icon: <Users className="w-4 h-4" />, badgeKey: 'friends' },
      ],
    },
    {
      title: 'Моё',
      items: [
        { id: 'mine', label: 'Мои посты', icon: <FileText className="w-4 h-4" />, badgeKey: 'mine' },
        { id: 'favorites', label: 'Избранное', icon: <Bookmark className="w-4 h-4" />, badgeKey: 'favorites' },
      ],
    },
    {
      title: 'Социальное',
      items: [
        { id: 'favGroups', label: 'Избранные группы', icon: <FolderOpen className="w-4 h-4" />, badgeKey: 'favGroups' },
        { id: 'favNews', label: 'Избранные новости', icon: <Heart className="w-4 h-4" />, badgeKey: 'favNews' },
      ],
    },
  ],
};

const JOBS_CONFIG: Omit<SubSectionConfig, 'active' | 'onSelect' | 'counts'> = {
  blocks: [
    {
      title: 'Лента',
      items: [
        { id: 'recommended', label: 'Рекомендованные', icon: <Sparkles className="w-4 h-4" />, badgeKey: 'recommended' },
        { id: 'all', label: 'Все вакансии', icon: <Briefcase className="w-4 h-4" />, badgeKey: 'all' },
        { id: 'hot', label: 'Горячие', icon: <Flame className="w-4 h-4" />, badgeKey: 'hot' },
      ],
    },
    {
      title: 'Моё',
      items: [
        { id: 'applied', label: 'Мои отклики', icon: <FileText className="w-4 h-4" />, badgeKey: 'applied' },
        // «Мой путь» (Job Pipeline, Стратегия п.18) — item по хэндоверу 7-d:
        // бейдж jobs['my-path'] уже считает GET /api/subsections/counts
        { id: 'my-path', label: 'Мой путь', icon: <MapIcon className="w-4 h-4" />, badgeKey: 'my-path' },
        { id: 'saved', label: 'Сохранённые', icon: <Bookmark className="w-4 h-4" />, badgeKey: 'saved' },
      ],
    },
    {
      title: 'Социальное',
      items: [
        { id: 'favCompanies', label: 'Избранные компании', icon: <Building2 className="w-4 h-4" />, badgeKey: 'favCompanies' },
      ],
    },
  ],
};

const ADS_CONFIG: Omit<SubSectionConfig, 'active' | 'onSelect' | 'counts'> = {
  blocks: [
    {
      title: 'Лента',
      items: [
        { id: 'recommended', label: 'Рекомендованные', icon: <Sparkles className="w-4 h-4" />, badgeKey: 'recommended' },
        { id: 'all', label: 'Все объявления', icon: <Megaphone className="w-4 h-4" />, badgeKey: 'all' },
      ],
    },
    {
      title: 'Моё',
      items: [
        { id: 'mine', label: 'Мои объявления', icon: <Megaphone className="w-4 h-4" />, badgeKey: 'mine' },
        { id: 'saved', label: 'Избранное', icon: <Bookmark className="w-4 h-4" />, badgeKey: 'saved' },
      ],
    },
    {
      title: 'Социальное',
      items: [
        { id: 'favSellers', label: 'Избранные продавцы', icon: <Store className="w-4 h-4" />, badgeKey: 'favSellers' },
      ],
    },
  ],
};

// === Главный компонент ===
export function SubSectionBar({ view }: { view: AppView }) {
  const {
    feedSubSection, setFeedSubSection,
    jobsSubSection, setJobsSubSection,
    adsSubSection, setAdsSubSection,
  } = useAppStore();

  const [counts, setCounts] = React.useState<Record<string, Record<string, number>>>({
    feed: {}, jobs: {}, ads: {},
  });

  // Загружаем счётчики один раз + при смене view
  const loadCounts = React.useCallback(async () => {
    try {
      const res = await api<{ feed: Record<string, number>; jobs: Record<string, number>; ads: Record<string, number> }>('/api/subsections/counts');
      setCounts(res);
    } catch {}
  }, []);

  React.useEffect(() => {
    loadCounts();
    // Обновляем каждые 60 сек (badge counts — медленно меняющиеся данные)
    const t = setInterval(loadCounts, 60000);
    return () => clearInterval(t);
  }, [loadCounts]);

  // Подбираем конфиг по view
  let config: SubSectionConfig | null = null;
  if (view === 'feed') {
    config = {
      ...FEED_CONFIG,
      active: feedSubSection,
      onSelect: (id) => setFeedSubSection(id as FeedSubSection),
      counts: counts.feed,
    };
  } else if (view === 'jobs') {
    config = {
      ...JOBS_CONFIG,
      active: jobsSubSection,
      onSelect: (id) => setJobsSubSection(id as JobsSubSection),
      counts: counts.jobs,
    };
  } else if (view === 'companies') {
    // Ads показываем в companies? Нет — у нас нет view 'ads'. Используем companies как референс.
    // Пока adsSubSection зарезервирован, но не активирован.
    return null;
  } else {
    return null;
  }

  // P1-4: Mobile — горизонтальные чипсы над контентом
  const mobileChips = (
    <div className="lg:hidden flex gap-1.5 overflow-x-auto scroll-area-thin pb-2 -mx-4 px-4">
      {config.blocks.flatMap(block => block.items).map(item => {
        const isActive = config.active === item.id;
        const count = item.badgeKey ? config.counts?.[item.badgeKey] : undefined;
        return (
          <button
            key={item.id}
            onClick={() => config.onSelect(item.id)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition flex-shrink-0',
              isActive ? 'bg-primary text-primary-foreground font-medium' : 'border text-muted-foreground hover:text-foreground'
            )}
          >
            <span className="shrink-0">{item.icon}</span>
            <span>{item.label}</span>
            {typeof count === 'number' && count > 0 && (
              <span className={cn('text-xs px-1 rounded-full tabular-nums', isActive ? 'bg-white/20' : 'bg-muted')}>
                {count > 99 ? '99+' : count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );

  // Desktop — вертикальный rail
  const desktopRail = (
    <div className="hidden lg:block border-t pt-3">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-1 h-3 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
        <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Разделы</span>
      </div>
      <div className="space-y-3">
        {config.blocks.map((block) => (
          <div key={block.title}>
            <div className="text-xs font-medium text-muted-foreground/70 uppercase tracking-wider mb-1 px-2">
              {block.title}
            </div>
            <div className="space-y-0.5">
              {block.items.map((item) => {
                const isActive = config.active === item.id;
                const count = item.badgeKey ? config.counts?.[item.badgeKey] : undefined;
                const showBadge = typeof count === 'number' && count > 0;
                return (
                  <button
                    key={item.id}
                    onClick={() => config.onSelect(item.id)}
                    className={cn(
                      'w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-sm transition text-left group',
                      isActive ? 'bg-primary/10 text-primary font-medium' : 'hover:bg-accent text-foreground/80'
                    )}
                    title={item.label}
                  >
                    <span className={cn('shrink-0 transition', isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground')}>
                      {item.icon}
                    </span>
                    <span className="flex-1 truncate text-[13px]">{item.label}</span>
                    {showBadge && (
                      <span className={cn('text-xs px-1.5 py-0.5 rounded-full font-semibold tabular-nums', isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground')}>
                        {count! > 99 ? '99+' : count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
        {/* Wave 11-c: фильтры-мониторы — только в разделе «Работа»
            (создание из текущего поиска, применение кликом, монитор, кап 9) */}
        {view === 'jobs' && (
          <div className="border-t pt-3 mt-3">
            <SavedFiltersPanel />
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div>
      {mobileChips}
      {desktopRail}
    </div>
  );
}
