// BizON — WhoViewedCard (9-c, doc_a §61 п.24 «Who Viewed»)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 👁 ВАС СМОТРЕЛИ                                               │
//   │ N просмотров за 30 дней · M на этой неделе                    │
//   │                                                              │
//   │ [аватар] Мария Иванова      Product Manager · 2 ч назад      │
//   │ [аватар] GreenAI Corp       HR-агентство · вчера             │
//   │ … (max-h, скролл)                                            │
//   │                                                              │
//   │ И ещё K просмотров от пользователей, чьи данные недоступны.  │
//   └──────────────────────────────────────────────────────────────┘
//
// Источник: GET /api/me/profile-views →
//   { views: [{ viewerId, viewerName, viewerTitle, viewerAvatar, viewedAt }], total }
//   (top-10 идентифицированных просмотров за 30 дней; total — все просмотры)
//
// Приватность (честно, без выдуманных имён):
//   • имена только из API; self-view и дубликаты 24ч API уже отфильтровал;
//   • если total больше показанного списка — разница выводится АГРЕГАТОМ
//     («И ещё K просмотров…»): это просмотры от удалённых/недоступных аккаунтов
//     и просмотры за пределами топ-10. Никаких guessed имён.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Eye, EyeOff, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProfileViewDTO {
  viewerId: string;
  viewerName: string;
  viewerTitle: string | null;
  viewerAvatar: string | null;
  viewedAt: string;
}

interface ProfileViewsResponse {
  views: ProfileViewDTO[];
  total: number;
}

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diffMs = Date.now() - date.getTime();
  const sec = Math.floor(diffMs / 1000);
  if (sec < 60) return 'только что';
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min} мин назад`;
  const hrs = Math.floor(min / 60);
  if (hrs < 24) return `${hrs} ч назад`;
  const days = Math.floor(hrs / 24);
  if (days === 1) return 'вчера';
  if (days < 7) return `${days} дн назад`;
  return date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

export function WhoViewedCard({ className }: { className?: string }) {
  const [data, setData] = React.useState<ProfileViewsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<ProfileViewsResponse>('/api/me/profile-views')
      .then((res) => {
        if (!cancelled) setData(res);
      })
      .catch((e: unknown) => {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : 'Не удалось загрузить просмотры');
          console.error('[WhoViewedCard] load error:', e);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const views = data?.views ?? [];
  const total = data?.total ?? 0;

  // Агрегат по неделе считаем ТОЛЬКО если он точный (все просмотры в списке).
  const weekCountExact =
    total <= views.length ? views.filter((v) => Date.now() - new Date(v.viewedAt).getTime() <= 7 * 24 * 60 * 60 * 1000).length : null;
  const hiddenCount = Math.max(0, total - views.length);

  return (
    <Card className={cn('overflow-hidden', className)}>
      <CardContent className="p-4">
        {/* Заголовок */}
        <div className="flex items-center gap-2 mb-1">
          <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
            <Eye className="w-4 h-4 text-lighthouse" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold leading-tight">Вас смотрели</div>
            <div className="text-xs text-muted-foreground truncate">
              Кто обращал внимание на ваш профиль
            </div>
          </div>
        </div>

        {/* Загрузка — скелетоны */}
        {loading && (
          <div className="space-y-2 mt-3" aria-busy="true" aria-live="polite">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-2">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3 w-2/3" />
                  <Skeleton className="h-2.5 w-1/3" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Ошибка — не крашим вкладку */}
        {!loading && error && (
          <div className="text-xs text-muted-foreground py-4 text-center" role="alert">
            Не удалось загрузить просмотры профиля. Попробуйте обновить страницу позже.
          </div>
        )}

        {/* Empty state — честный */}
        {!loading && !error && total === 0 && (
          <div className="text-xs text-muted-foreground py-4 text-center leading-relaxed">
            Пока нет данных — они появятся, когда кто-то откроет ваш профиль.
            Ваш собственный просмотр и повторные просмотры в течение 24 часов
            не учитываются.
          </div>
        )}

        {/* Данные */}
        {!loading && !error && total > 0 && (
          <>
            {/* Агрегат */}
            <div className="flex items-center gap-1.5 flex-wrap text-xs mt-2 mb-2">
              <span className="text-xl font-extrabold tabular-nums leading-none">{total}</span>
              <span className="text-muted-foreground">
                {pluralize(total, 'просмотр', 'просмотра', 'просмотров')} за 30 дней
              </span>
              {weekCountExact !== null && weekCountExact > 0 && (
                <>
                  <span className="text-muted-foreground/40">·</span>
                  <span className="text-muted-foreground">
                    {weekCountExact} на этой неделе
                  </span>
                </>
              )}
            </div>

            {/* Список идентифицированных просмотров (max-h + скролл) */}
            {views.length > 0 && (
              <ul
                className={cn(
                  'space-y-1 mt-1 scroll-area-thin',
                  views.length > 4 && 'max-h-64 overflow-y-auto pr-1',
                )}
              >
                {views.map((v) => (
                  <li
                    key={`${v.viewerId}-${v.viewedAt}`}
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition"
                  >
                    <Avatar className="w-8 h-8 flex-shrink-0">
                      {v.viewerAvatar ? (
                        <AvatarImage src={v.viewerAvatar} alt={`Аватар: ${v.viewerName}`} />
                      ) : null}
                      <AvatarFallback className="text-xs bg-lighthouse/10 text-lighthouse">
                        {(v.viewerName || '?').slice(0, 1).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate" title={v.viewerName}>
                        {v.viewerName}
                      </div>
                      {v.viewerTitle && (
                        <div className="text-xs text-muted-foreground truncate" title={v.viewerTitle}>
                          {v.viewerTitle}
                        </div>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground flex-shrink-0 tabular-nums">
                      {formatRelativeTime(v.viewedAt)}
                    </div>
                  </li>
                ))}
              </ul>
            )}

            {/* Агрегат недоступных просмотров — БЕЗ выдуманных имён */}
            {hiddenCount > 0 && (
              <div className="flex items-start gap-1.5 mt-2.5 pt-2.5 border-t border-border/60 text-xs text-muted-foreground leading-relaxed">
                <EyeOff className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                <span>
                  И ещё {hiddenCount} {pluralize(hiddenCount, 'просмотр', 'просмотра', 'просмотров')}{' '}
                  за этот период — от пользователей, чьи данные недоступны.
                </span>
              </div>
            )}

            {/* Приватность: фиксируем, что видим только идентифицированные просмотры */}
            <div className="flex items-start gap-1.5 mt-2 text-xs text-muted-foreground/80 leading-relaxed">
              <Lock className="w-3 h-3 flex-shrink-0 mt-0.5" />
              <span>
                Приватность: вы видите только авторизованные просмотры за последние 30 дней.
                Анонимный режим просмотра — опция подписки Pro.
              </span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
