// BizON — WhileYouWereAwayDigest (9-c, doc_a §61 п.26 «While You Were Away»)
//
//   ┌──────────────────────────────────────────────────────────────┐
//   │ 📦 ПОКА ВАС НЕ БЫЛО (3 дня)                     7 событий [⌃]│
//   │ Дайджест с последнего визита                                 │
//   │                                                              │
//   │ 👁  2 просмотра профиля (30 дней)                            │
//   │ 📡  2 новых рыночных сигнала                                 │
//   │ 💼  3 компании добавили вакансию                             │
//   │ 🎓  1 навык подтверждён                                      │
//   │ 💬  20 комментариев к вашим постам                           │
//   │ 📈  Trust +8 с последнего визита                             │
//   └──────────────────────────────────────────────────────────────┘
//
// ДЕТЕРМИНИРОВАННАЯ сборка БЕЗ LLM — только числа из существующих API:
//   • GET /api/me/whats-new      → deltas + whileAway (счётчики с визита)
//   • GET /api/me/profile-views  → total просмотров за 30 дней
//   • GET /api/me/signals        → total активных рыночных сигналов
// Если один из API упал — блок просто не показывает его строки (не крашится).
// Пользователь, который не заходил > 1 дня, видит заголовок «Пока вас не было»;
// иначе — «Что происходит вокруг вас» (те же детерминированные источники).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Package,
  BellRing,
  ChevronDown,
  Eye,
  Briefcase,
  GraduationCap,
  Users,
  Lightbulb,
  MessageSquare,
  FolderKanban,
  TrendingUp,
  Radio,
  Inbox,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы (минимальные срезы ответов API) ===
// ============================================================================

interface WhatsNewDigest {
  deltas?: {
    messages?: number;
    commentsOnOwnPosts?: number;
    confirmations?: number;
    projectInvites?: number;
    trustDelta?: number;
    colleagueInquiries?: number;
  };
  whileAway?: {
    daysAway: number;
    profileViews: number;
    companyJobsAdded: number;
    skillsConfirmed: number;
    newPeopleFromArea: number;
    aiRecommendation: number;
    since: string;
  } | null;
}

interface ProfileViewsDigest {
  total: number;
}

interface SignalsDigest {
  total: number;
}

type DigestLine = {
  key: string;
  icon: React.ReactNode;
  text: string;
};

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}

// ============================================================================
// === Детерминированная сборка строк дайджеста ===
// ============================================================================

function buildLines(
  whatsNew: WhatsNewDigest | null,
  profileViews: ProfileViewsDigest | null,
  signals: SignalsDigest | null,
): DigestLine[] {
  const lines: DigestLine[] = [];
  const away = whatsNew?.whileAway ?? null;
  const deltas = whatsNew?.deltas ?? {};

  // --- Просмотры профиля: приоритет — whileAway (с визита), иначе 30-дневный total ---
  if (away && away.profileViews > 0) {
    lines.push({
      key: 'away-views',
      icon: <Eye className="w-3.5 h-3.5" />,
      text: `${away.profileViews} ${pluralize(away.profileViews, 'человек посмотрел', 'человека посмотрели', 'человек посмотрели')} ваш профиль`,
    });
  } else if (profileViews && profileViews.total > 0) {
    lines.push({
      key: 'views-30d',
      icon: <Eye className="w-3.5 h-3.5" />,
      text: `${profileViews.total} ${pluralize(profileViews.total, 'просмотр', 'просмотра', 'просмотров')} вашего профиля за 30 дней`,
    });
  }

  // --- Рыночные сигналы (BIZON SIGNAL) ---
  if (signals && signals.total > 0) {
    lines.push({
      key: 'signals',
      icon: <Radio className="w-3.5 h-3.5" />,
      text: `${signals.total} ${pluralize(signals.total, 'новый рыночный сигнал', 'новых рыночных сигнала', 'новых рыночных сигналов')}`,
    });
  }

  // --- While Away: вакансии / навыки / новые люди / AI-рекомендации ---
  if (away) {
    if (away.companyJobsAdded > 0) {
      lines.push({
        key: 'away-jobs',
        icon: <Briefcase className="w-3.5 h-3.5" />,
        text: `${away.companyJobsAdded} ${pluralize(away.companyJobsAdded, 'компания добавила', 'компании добавили', 'компаний добавили')} вакансию`,
      });
    }
    if (away.skillsConfirmed > 0) {
      lines.push({
        key: 'away-skills',
        icon: <GraduationCap className="w-3.5 h-3.5" />,
        text: `${away.skillsConfirmed} ${pluralize(away.skillsConfirmed, 'навык подтверждён', 'навыка подтверждено', 'навыков подтверждено')}`,
      });
    }
    if (away.newPeopleFromArea > 0) {
      lines.push({
        key: 'away-people',
        icon: <Users className="w-3.5 h-3.5" />,
        text: `${away.newPeopleFromArea} ${pluralize(away.newPeopleFromArea, 'новый специалист', 'новых специалиста', 'новых специалистов')} из вашей области`,
      });
    }
    if (away.aiRecommendation > 0) {
      lines.push({
        key: 'away-ai',
        icon: <Lightbulb className="w-3.5 h-3.5" />,
        text: `${away.aiRecommendation} ${pluralize(away.aiRecommendation, 'рекомендация AI', 'рекомендации AI', 'рекомендаций AI')}`,
      });
    }
  }

  // --- Дельты с визита (whats-new.deltas) — то, чего не показывает баннер ---
  if (deltas.commentsOnOwnPosts && deltas.commentsOnOwnPosts > 0) {
    lines.push({
      key: 'comments',
      icon: <MessageSquare className="w-3.5 h-3.5" />,
      text: `${deltas.commentsOnOwnPosts} ${pluralize(deltas.commentsOnOwnPosts, 'новый комментарий', 'новых комментария', 'новых комментариев')} к вашим постам`,
    });
  }
  if (deltas.messages && deltas.messages > 0) {
    lines.push({
      key: 'messages',
      icon: <Inbox className="w-3.5 h-3.5" />,
      text: `${deltas.messages} ${deltas.messages === 1 ? 'непрочитанное уведомление' : 'непрочитанных уведомлений'}`,
    });
  }
  if (deltas.projectInvites && deltas.projectInvites > 0) {
    lines.push({
      key: 'invites',
      icon: <FolderKanban className="w-3.5 h-3.5" />,
      text: `${deltas.projectInvites} ${pluralize(deltas.projectInvites, 'приглашение в проект', 'приглашения в проекты', 'приглашений в проекты')}`,
    });
  }
  if (typeof deltas.trustDelta === 'number' && deltas.trustDelta !== 0) {
    lines.push({
      key: 'trust',
      icon: <TrendingUp className="w-3.5 h-3.5" />,
      text: `Trust изменился на ${deltas.trustDelta > 0 ? '+' : ''}${deltas.trustDelta} с последнего визита`,
    });
  }

  return lines;
}

// ============================================================================
// === Главный компонент ===
// ============================================================================

export function WhileYouWereAwayDigest({ className }: { className?: string }) {
  const [whatsNew, setWhatsNew] = React.useState<WhatsNewDigest | null>(null);
  const [profileViews, setProfileViews] = React.useState<ProfileViewsDigest | null>(null);
  const [signals, setSignals] = React.useState<SignalsDigest | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [failed, setFailed] = React.useState(false);

  // Развернуть по умолчанию, если пользователя не было > 1 дня; иначе свернуть.
  const [open, setOpen] = React.useState(false);
  const initializedRef = React.useRef(false);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setFailed(false);

    // Каждый источник независим: упал один — остальные всё равно показываем.
    Promise.allSettled([
      api<WhatsNewDigest>('/api/me/whats-new'),
      api<ProfileViewsDigest>('/api/me/profile-views'),
      api<SignalsDigest>('/api/me/signals'),
    ]).then(([w, p, s]) => {
      if (cancelled) return;
      const okAny = w.status === 'fulfilled' || p.status === 'fulfilled' || s.status === 'fulfilled';
      if (w.status === 'fulfilled') setWhatsNew(w.value);
      if (p.status === 'fulfilled') setProfileViews(p.value);
      if (s.status === 'fulfilled') setSignals(s.value);
      if (!okAny) {
        setFailed(true);
        console.error('[WhileYouWereAwayDigest] все источники недоступны');
      }
      // away > 1 дня → разворачиваем дайджест сразу (однократно, после загрузки)
      if (!initializedRef.current) {
        initializedRef.current = true;
        if (w.status === 'fulfilled' && w.value?.whileAway) setOpen(true);
      }
      setLoading(false);
    });

    return () => {
      cancelled = true;
    };
  }, []);

  const lines = buildLines(whatsNew, profileViews, signals);
  const away = whatsNew?.whileAway ?? null;

  // Нечего показывать — рендерим ничего (честно: пусто → пусто).
  // Скелетон показываем только пока грузится первый ответ.
  if (!loading && lines.length === 0) return null;

  const title = away ? 'Пока вас не было' : 'Что происходит вокруг вас';
  const subtitle = away
    ? `Дайджест с последнего визита (${away.daysAway} ${pluralize(away.daysAway, 'день', 'дня', 'дней')})`
    : 'Дайджест событий в вашей профессиональной среде';

  return (
    <Card
      className={cn(
        'border-lighthouse/25 bg-gradient-to-br from-lighthouse/5 via-transparent to-transparent overflow-hidden',
        className,
      )}
    >
      <Collapsible open={open} onOpenChange={setOpen}>
        <CollapsibleTrigger
          className="w-full text-left"
          aria-label={open ? 'Свернуть дайджест событий' : 'Развернуть дайджест событий'}
        >
          <CardContent className="p-4 sm:p-5 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-lighthouse/10 flex items-center justify-center flex-shrink-0">
                {away ? (
                  <Package className="w-4 h-4 text-lighthouse" />
                ) : (
                  <BellRing className="w-4 h-4 text-lighthouse" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold leading-tight">
                  {title}
                  {away && (
                    <span className="text-lighthouse ml-1.5">
                      ({away.daysAway} {pluralize(away.daysAway, 'день', 'дня', 'дней')})
                    </span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground truncate">{subtitle}</div>
              </div>
              {!loading && lines.length > 0 && (
                <span
                  className="text-xs font-semibold text-muted-foreground bg-muted/60 rounded-full px-2 py-0.5 tabular-nums flex-shrink-0"
                  title="Количество событий"
                >
                  {lines.length}
                </span>
              )}
              <ChevronDown
                className={cn(
                  'w-4 h-4 text-muted-foreground transition-transform flex-shrink-0',
                  open && 'rotate-180',
                )}
              />
            </div>
          </CardContent>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <CardContent className="p-4 sm:p-5 pt-1">
            {loading && (
              <div className="space-y-2" aria-busy="true" aria-live="polite">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-4 w-3/4" />
                ))}
              </div>
            )}

            {!loading && failed && lines.length === 0 && (
              <div className="text-xs text-muted-foreground py-2" role="alert">
                Не удалось загрузить дайджест. Попробуйте обновить страницу позже.
              </div>
            )}

            {!loading && lines.length > 0 && (
              <ul className="space-y-1.5">
                {lines.map((line) => (
                  <li key={line.key} className="flex items-center gap-2 text-sm text-foreground/90">
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-lighthouse/10 text-lighthouse flex-shrink-0">
                      {line.icon}
                    </span>
                    <span className="min-w-0">{line.text}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}
