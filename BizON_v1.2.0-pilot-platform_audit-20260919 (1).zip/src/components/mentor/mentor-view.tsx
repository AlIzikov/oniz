// BizON 2.0 — Phase 11: MentorView
//
// Реализует UI для наставничества:
//   • Если у пользователя есть skill gaps (currentLevel < 7) → «Вам нужен наставник»:
//     список менторов с reason + кнопкой [Запросить].
//   • Если пользователь сам ментор (peakLevel >= 8 в каком-либо навыке) → «Вы наставник»:
//     эффективность (score, menteeCount, growthRate) + список учеников.
//   • Кнопка «Найти наставника» → поиск по навыкам (skill picker).
//   • Список моих активных наставничеств (as mentee + as mentor).
//
// Источники данных:
//   GET  /api/mentors?skillId=...
//   GET  /api/me/mentorships
//   POST /api/mentorships
//   POST /api/mentorships/[id]/complete
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  GraduationCap, Loader2, Search, Sparkles, Star, TrendingUp, Users,
  Award, ChevronRight, ArrowRight, Clock,
} from 'lucide-react';

// === Типы ответов API ===

interface MentorSuggestion {
  mentorId: string;
  name: string;
  title: string | null;
  avatar: string | null;
  skillName: string;
  skillId: string | null;
  mentorLevel: number;
  effectiveness: number;
  menteeCount: number;
  avgRating: number | null;
  reason: string;
}

interface MentorshipPublic {
  id: string;
  mentorId: string;
  menteeId: string;
  skillId: string | null;
  skillName: string | null;
  status: 'active' | 'completed' | 'cancelled';
  startedAt: string;
  completedAt: string | null;
  mentorRating: number | null;
  menteeGrowth: {
    skillBefore: number;
    skillAfter: number;
    newProjects?: number;
    newRole?: string | null;
  } | null;
  mentor: {
    id: string;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  };
  mentee: {
    id: string;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  };
}

interface MentorshipListResponse {
  asMentee: MentorshipPublic[];
  asMentor: MentorshipPublic[];
}

// === Helpers ===

function effectivenessColor(score: number): string {
  if (score >= 75) return 'text-emerald-600 dark:text-emerald-400';
  if (score >= 50) return 'text-blue-600 dark:text-blue-400';
  if (score >= 25) return 'text-amber-600 dark:text-amber-400';
  return 'text-muted-foreground';
}

function effectivenessLabel(score: number): string {
  if (score >= 75) return 'Высокая';
  if (score >= 50) return 'Средняя';
  if (score >= 25) return 'Низкая';
  return 'Нет данных';
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('ru-RU', { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return iso;
  }
}

// === Главный компонент ===

export function MentorView() {
  const user = useAppStore((s) => s.user);
  const setView = useAppStore((s) => s.setView);
  const [mentors, setMentors] = React.useState<MentorSuggestion[]>([]);
  const [loadingMentors, setLoadingMentors] = React.useState(true);
  const [mentorships, setMentorships] = React.useState<MentorshipListResponse | null>(null);
  const [loadingMentorships, setLoadingMentorships] = React.useState(true);
  const [skillFilter, setSkillFilter] = React.useState<string | null>(null);
  const [requesting, setRequesting] = React.useState<string | null>(null);
  const [completeTarget, setCompleteTarget] = React.useState<MentorshipPublic | null>(null);

  const loadMentors = React.useCallback(async () => {
    setLoadingMentors(true);
    try {
      const params = new URLSearchParams();
      if (skillFilter) params.set('skillId', skillFilter);
      const res = await api<{ mentors: MentorSuggestion[] }>(`/api/mentors?${params.toString()}`);
      setMentors(res.mentors ?? []);
    } catch (e: any) {
      toast({ title: 'Ошибка загрузки менторов', description: e?.message, variant: 'destructive' });
      setMentors([]);
    } finally {
      setLoadingMentors(false);
    }
  }, [skillFilter]);

  const loadMentorships = React.useCallback(async () => {
    setLoadingMentorships(true);
    try {
      const res = await api<MentorshipListResponse>('/api/me/mentorships');
      setMentorships(res);
    } catch (e: any) {
      toast({ title: 'Ошибка загрузки наставничеств', description: e?.message, variant: 'destructive' });
    } finally {
      setLoadingMentorships(false);
    }
  }, []);

  React.useEffect(() => {
    loadMentors();
  }, [loadMentors]);

  React.useEffect(() => {
    loadMentorships();
  }, [loadMentorships]);

  async function handleRequestMentor(m: MentorSuggestion) {
    setRequesting(m.mentorId);
    try {
      await api('/api/mentorships', {
        method: 'POST',
        body: JSON.stringify({ mentorId: m.mentorId, skillId: m.skillId }),
      });
      toast({
        title: 'Запрос отправлен',
        description: `${m.name} получил уведомление о запросе на наставничество по «${m.skillName}».`,
      });
      loadMentorships();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e?.message, variant: 'destructive' });
    } finally {
      setRequesting(null);
    }
  }

  // Active mentorship as mentee — IDs to disable duplicate request buttons
  const myActiveMentorIds = new Set(
    (mentorships?.asMentee ?? [])
      .filter((m) => m.status === 'active')
      .map((m) => m.mentorId),
  );

  // Вы на наставник? — есть ли у пользователя completed или active mentorship as mentor
  const isMentor = (mentorships?.asMentor ?? []).length > 0;
  const asMentorActive = (mentorships?.asMentor ?? []).filter((m) => m.status === 'active');
  const asMentorCompleted = (mentorships?.asMentor ?? []).filter((m) => m.status === 'completed');

  // Вычисляем effectiveness для текущего пользователя (если он ментор)
  const [myEffectiveness, setMyEffectiveness] = React.useState<{
    score: number;
    menteeCount: number;
    growthRate: number;
    avgRating: number | null;
    totalMenteeCount: number;
  } | null>(null);
  React.useEffect(() => {
    if (!user) return;
    if (!isMentor) {
      setMyEffectiveness(null);
      return;
    }
    api<{ score: number; menteeCount: number; growthRate: number; avgRating: number | null; totalMenteeCount: number }>(
      `/api/mentors/${user.id}/effectiveness`,
    )
      .then((r) => setMyEffectiveness(r))
      .catch(() => setMyEffectiveness(null));
  }, [user, isMentor]);

  return (
    <div className="space-y-4 pb-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-semibold">
            <GraduationCap className="size-6 text-lighthouse" />
            Наставничество
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Найдите ментора по своим skill gaps или станьте наставником для других.
          </p>
        </div>
      </div>

      {/* === Если пользователь — ментор === */}
      {isMentor && myEffectiveness && (
        <Card className="border-emerald-200 dark:border-emerald-900/50 bg-emerald-50/40 dark:bg-emerald-950/10">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Award className="size-5 text-emerald-600 dark:text-emerald-400" />
              Вы — наставник
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <StatPill label="Effectiveness" value={`${myEffectiveness.score}/100`} hint={effectivenessLabel(myEffectiveness.score)} />
              <StatPill label="Учеников завершено" value={myEffectiveness.menteeCount} />
              <StatPill label="Рост у учеников" value={`${Math.round(myEffectiveness.growthRate * 100)}%`} />
              <StatPill
                label="Средняя оценка"
                value={myEffectiveness.avgRating !== null ? `${myEffectiveness.avgRating}/5` : '—'}
              />
            </div>
            <Progress
              value={myEffectiveness.score}
              className={cn(
                'h-2',
                `[&_[data-slot=progress-indicator]]:${myEffectiveness.score >= 75 ? 'bg-emerald-500' : myEffectiveness.score >= 50 ? 'bg-blue-500' : 'bg-amber-500'}`,
              )}
            />

            {/* Список активных учеников */}
            {asMentorActive.length > 0 && (
              <div className="pt-2">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Активные ученики ({asMentorActive.length})
                </div>
                <div className="space-y-2">
                  {asMentorActive.map((m) => (
                    <MentorshipRow key={m.id} m={m} role="mentor" onComplete={() => setCompleteTarget(m)} />
                  ))}
                </div>
              </div>
            )}

            {/* Завершённые ученики */}
            {asMentorCompleted.length > 0 && (
              <div className="pt-2">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Завершённые ({asMentorCompleted.length})
                </div>
                <div className="space-y-2">
                  {asMentorCompleted.slice(0, 5).map((m) => (
                    <MentorshipRow key={m.id} m={m} role="mentor" />
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* === Find a mentor === */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Search className="size-5 text-lighthouse" />
                Найти наставника
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1">
                Подбираем менторов по вашим skill gaps (currentLevel &lt; 7) и экспертизе (peakLevel &gt;= 8).
              </p>
            </div>
            {skillFilter && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSkillFilter(null)}
              >
                Сбросить фильтр
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {loadingMentors ? (
            <>
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-24 w-full rounded-lg" />
              ))}
            </>
          ) : mentors.length === 0 ? (
            <div className="text-center py-8">
              <GraduationCap className="size-8 mx-auto mb-2 text-muted-foreground/60" />
              <p className="text-sm text-muted-foreground">
                {skillFilter
                  ? 'По этому навыку менторов не найдено. Попробуйте сбросить фильтр.'
                  : 'У вас пока нет skill gaps (все навыки ≥ 7) — ментор не требуется. 🎉'}
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-3"
                onClick={() => setView('truth')}
              >
                Открыть Skill Graph
                <ArrowRight className="size-3.5 ml-1" />
              </Button>
            </div>
          ) : (
            mentors.map((m) => {
              const alreadyRequested = myActiveMentorIds.has(m.mentorId);
              return (
                <MentorCard
                  key={`${m.mentorId}-${m.skillId ?? ''}`}
                  m={m}
                  alreadyRequested={alreadyRequested}
                  requesting={requesting === m.mentorId}
                  onRequest={() => handleRequestMentor(m)}
                />
              );
            })
          )}
        </CardContent>
      </Card>

      {/* === My active mentorships (as mentee) === */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="size-5 text-lighthouse" />
            Мои наставники
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {loadingMentorships ? (
            <Skeleton className="h-16 w-full rounded-lg" />
          ) : (mentorships?.asMentee ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              У вас пока нет активных наставников. Запросите ментора выше.
            </p>
          ) : (
            (mentorships?.asMentee ?? []).map((m) => (
              <MentorshipRow
                key={m.id}
                m={m}
                role="mentee"
                onComplete={() => setCompleteTarget(m)}
              />
            ))
          )}
        </CardContent>
      </Card>

      {/* === Complete mentorship dialog === */}
      {completeTarget && (
        <CompleteMentorshipDialog
          mentorship={completeTarget}
          onClose={() => setCompleteTarget(null)}
          onCompleted={() => {
            setCompleteTarget(null);
            loadMentorships();
            loadMentors();
          }}
        />
      )}
    </div>
  );
}

// === Sub-components ===

function MentorCard({
  m,
  alreadyRequested,
  requesting,
  onRequest,
}: {
  m: MentorSuggestion;
  alreadyRequested: boolean;
  requesting: boolean;
  onRequest: () => void;
}) {
  return (
    <div className="rounded-lg border p-3 flex items-start gap-3 hover:bg-muted/30 transition-colors">
      <UserAvatar name={m.name} avatarUrl={m.avatar} size="md" />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-sm truncate">{m.name}</span>
          {m.title && (
            <span className="text-xs text-muted-foreground truncate">· {m.title}</span>
          )}
          <Badge
            variant="outline"
            className="text-xs px-1.5 py-0 gap-1 border-blue-300/40 text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40"
            title={`Peak level ${m.mentorLevel} в «${m.skillName}»`}
          >
            <Award className="size-3" />
            {m.skillName} · {m.mentorLevel}
          </Badge>
        </div>
        <p className="mt-1 text-xs text-muted-foreground leading-relaxed line-clamp-2">
          {m.reason}
        </p>
        <div className="mt-1.5 flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
          <span className={cn('font-medium', effectivenessColor(m.effectiveness))}>
            Эффект: {m.effectiveness}/100
          </span>
          {m.avgRating !== null && (
            <span className="flex items-center gap-0.5">
              <Star className="size-3 fill-amber-400 text-amber-400" />
              {m.avgRating}
            </span>
          )}
          <span>{m.menteeCount} ученик(ов)</span>
        </div>
      </div>
      <div className="flex-shrink-0">
        <Button
          size="sm"
          variant={alreadyRequested ? 'outline' : 'default'}
          disabled={alreadyRequested || requesting}
          onClick={onRequest}
        >
          {requesting ? (
            <Loader2 className="size-3.5 animate-spin" />
          ) : alreadyRequested ? (
            <Clock className="size-3.5" />
          ) : (
            <Sparkles className="size-3.5" />
          )}
          {alreadyRequested ? 'Запрошено' : 'Запросить'}
        </Button>
      </div>
    </div>
  );
}

function MentorshipRow({
  m,
  role,
  onComplete,
}: {
  m: MentorshipPublic;
  role: 'mentee' | 'mentor';
  onComplete?: () => void;
}) {
  const counterpart = role === 'mentee' ? m.mentor : m.mentee;
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);

  const statusMeta: Record<string, { label: string; className: string }> = {
    active: {
      label: 'Активно',
      className: 'border-emerald-300/40 text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40',
    },
    completed: {
      label: 'Завершено',
      className: 'border-blue-300/40 text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40',
    },
    cancelled: {
      label: 'Отменено',
      className: 'border-muted-foreground/30 text-muted-foreground bg-muted/30',
    },
  };
  const st = statusMeta[m.status] ?? statusMeta.active;

  return (
    <div className="rounded-lg border p-3 flex items-center gap-3">
      <button
        type="button"
        onClick={() => setProfileUserId(counterpart.id)}
        className="flex items-center gap-3 flex-1 min-w-0 text-left hover:opacity-80 transition"
      >
        <UserAvatar
          name={counterpart.name}
          avatarUrl={counterpart.avatarUrl}
          size="md"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm truncate">{counterpart.name}</span>
            {m.skillName && (
              <Badge variant="outline" className="text-xs px-1.5 py-0">
                {m.skillName}
              </Badge>
            )}
            <Badge variant="outline" className={cn('text-xs px-1.5 py-0', st.className)}>
              {st.label}
            </Badge>
          </div>
          <div className="mt-0.5 text-xs text-muted-foreground">
            с {formatDate(m.startedAt)}
            {m.completedAt && ` · завершено ${formatDate(m.completedAt)}`}
          </div>
          {m.status === 'completed' && m.mentorRating && (
            <div className="mt-0.5 text-xs flex items-center gap-1">
              <Star className="size-3 fill-amber-400 text-amber-400" />
              <span>Оценка: {m.mentorRating}/5</span>
              {m.menteeGrowth && (
                <span className="text-muted-foreground">
                  · рост {m.menteeGrowth.skillBefore} → {m.menteeGrowth.skillAfter}
                </span>
              )}
            </div>
          )}
        </div>
      </button>
      <div className="flex-shrink-0">
        {m.status === 'active' && role === 'mentee' && onComplete && (
          <Button size="sm" variant="outline" onClick={onComplete}>
            Завершить
          </Button>
        )}
      </div>
    </div>
  );
}

function StatPill({
  label,
  value,
  hint,
}: {
  label: string;
  value: number | string;
  hint?: string;
}) {
  return (
    <div className="rounded-md border bg-muted/20 px-2 py-1.5">
      <div className="text-xs text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className="text-sm font-bold tabular-nums">
        {value}
        {hint && <span className="text-xs text-muted-foreground font-normal ml-1">{hint}</span>}
      </div>
    </div>
  );
}

function CompleteMentorshipDialog({
  mentorship,
  onClose,
  onCompleted,
}: {
  mentorship: MentorshipPublic;
  onClose: () => void;
  onCompleted: () => void;
}) {
  const [rating, setRating] = React.useState(5);
  const [skillBefore, setSkillBefore] = React.useState<number>(3);
  const [skillAfter, setSkillAfter] = React.useState<number>(5);
  const [newRole, setNewRole] = React.useState<string>('');
  const [submitting, setSubmitting] = React.useState(false);

  async function handleSubmit() {
    setSubmitting(true);
    try {
      await api(`/api/mentorships/${mentorship.id}/complete`, {
        method: 'POST',
        body: JSON.stringify({
          rating,
          growth: {
            skillBefore,
            skillAfter,
            newRole: newRole.trim() || null,
          },
        }),
      });
      toast({ title: 'Наставничество завершено', description: 'Спасибо за оценку!' });
      onCompleted();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e?.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Завершить наставничество</DialogTitle>
          <DialogDescription>
            Оцените работу с {mentorship.mentor.name}
            {mentorship.skillName ? ` по «${mentorship.skillName}»` : ''}.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Rating */}
          <div>
            <Label className="text-sm">Оценка наставника</Label>
            <div className="flex items-center gap-1 mt-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  className={cn(
                    'p-1 rounded transition',
                    n <= rating ? 'text-amber-400' : 'text-muted-foreground/40 hover:text-muted-foreground',
                  )}
                  aria-label={`Оценка ${n}`}
                >
                  <Star className={cn('size-6', n <= rating && 'fill-amber-400')} />
                </button>
              ))}
              <span className="ml-2 text-sm font-medium tabular-nums">{rating}/5</span>
            </div>
          </div>

          {/* Growth */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-sm">Уровень до ({skillBefore})</Label>
              <input
                type="range"
                min={1}
                max={10}
                value={skillBefore}
                onChange={(e) => setSkillBefore(parseInt(e.target.value, 10))}
                className="w-full mt-2"
              />
            </div>
            <div>
              <Label className="text-sm">Уровень после ({skillAfter})</Label>
              <input
                type="range"
                min={1}
                max={10}
                value={skillAfter}
                onChange={(e) => setSkillAfter(parseInt(e.target.value, 10))}
                className="w-full mt-2"
              />
            </div>
          </div>

          {/* New role */}
          <div>
            <Label className="text-sm">Новая роль (опционально)</Label>
            <input
              type="text"
              value={newRole}
              onChange={(e) => setNewRole(e.target.value)}
              placeholder="Например: Senior Developer"
              className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm"
            />
          </div>

          {skillAfter > skillBefore && (
            <div className="rounded-md border border-emerald-300/50 bg-emerald-50/50 dark:bg-emerald-950/20 px-3 py-2 text-xs flex items-center gap-2 text-emerald-700 dark:text-emerald-300">
              <TrendingUp className="size-3.5" />
              Рост на {skillAfter - skillBefore} уровней
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>
            Отмена
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting && <Loader2 className="size-4 mr-1 animate-spin" />}
            Завершить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
