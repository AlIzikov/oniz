// BizON — Этап 5.1 — NB блок: News Moderation (admin only)
// Список pending NewsCard с возможностью:
//   • Опубликовать (status='published')
//   • Отклонить (status='rejected')
//   • Перегенерировать AI-резюме (новый LLM-вызов)
// Только для пользователей с ролью 'admin'.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import {
  Check, X, RefreshCw, Loader2, ExternalLink, Newspaper, ShieldAlert,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// TODO(11-a): NewsCardPublic отсутствует в '@/lib/types' — локальный тип по шейпу
// GET /api/news/moderation. Удалить после появления NewsCardPublic в '@/lib/types'.
type NewsCardPublic = {
  id: string;
  url: string;
  title: string;
  description: string | null;
  imageUrl: string | null;
  aiSummary: string;
  tags: string[];
  sourceDomain: string;
  publishedAt: string;
  category: string; // news | ad | industry
  advertiserId: string | null;
  advertiserName: string | null;
  erirToken: string | null;
  recommendedBy: string | null;
  recommendedType: string | null;
};

export function NewsModeration() {
  const [items, setItems] = React.useState<NewsCardPublic[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [processing, setProcessing] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ items: NewsCardPublic[] }>('/api/news/moderation?status=pending&limit=50');
      setItems(res.items ?? []);
    } catch (e: any) {
      toast({ title: 'Ошибка загрузки', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  async function handleAction(cardId: string, action: 'publish' | 'reject' | 'regenerate') {
    setProcessing(`${cardId}:${action}`);
    try {
      const res = await api<{ ok: boolean; card: NewsCardPublic }>(`/api/news/${cardId}/moderate`, {
        method: 'POST',
        body: JSON.stringify({ action }),
      });
      if (action === 'regenerate') {
        // Обновляем только AI-резюме в локальном стейте
        setItems((prev) => prev.map((c) => (c.id === cardId ? res.card : c)));
        toast({ title: 'AI-резюме обновлено' });
      } else {
        // Удаляем из списка pending
        setItems((prev) => prev.filter((c) => c.id !== cardId));
        toast({
          title: action === 'publish' ? 'Карточка опубликована' : 'Карточка отклонена',
        });
      }
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setProcessing(null);
    }
  }

  return (
    <Card className="border-amber-500/20">
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <ShieldAlert className="w-4 h-4 text-amber-600" />
          Модерация внешних новостей (NB)
          {!loading && (
            <Badge variant="secondary" className="text-xs">{items.length} ожидает</Badge>
          )}
          <Button variant="ghost" size="sm" className="ml-auto text-xs gap-1" onClick={load} disabled={loading}>
            <RefreshCw className={cn('w-3.5 h-3.5', loading && 'animate-spin')} />
            Обновить
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-32 w-full rounded-lg" />
            <Skeleton className="h-32 w-full rounded-lg" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-8 rounded-lg border border-dashed border-muted-foreground/30 bg-muted/10">
            <Newspaper className="w-8 h-8 mx-auto mb-2 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">
              Нет карточек, ожидающих модерации. Cron-скрипт <code className="text-xs">scripts/cron-fetch-news.js</code> парсит RSS раз в час.
            </p>
          </div>
        ) : (
          items.map((c) => {
            const isProcessing = processing?.startsWith(c.id);
            return (
              <div
                key={c.id}
                className="rounded-lg border p-3 space-y-2 bg-card hover:shadow-sm transition"
              >
                {/* Header: домен + время + категория */}
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline" className="text-xs gap-1">
                      <Newspaper className="w-3 h-3" />
                      {c.category === 'ad' ? 'Реклама' : c.category === 'industry' ? 'Индустрия' : 'Новости'}
                    </Badge>
                    <span className="text-xs text-muted-foreground font-medium">{c.sourceDomain}</span>
                  </div>
                  <a
                    href={c.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-primary hover:underline inline-flex items-center gap-0.5"
                  >
                    открыть источник <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* Превью: image + заголовок + AI-резюме */}
                <div className="flex gap-3">
                  {c.imageUrl && (
                    <a
                      href={c.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="shrink-0 w-24 h-24 rounded-md overflow-hidden border bg-muted"
                    >
                      <img
                        src={c.imageUrl}
                        alt=""
                        className="w-full h-full object-cover"
                        onError={(e) => { e.currentTarget.parentElement!.style.display = 'none'; }}
                      />
                    </a>
                  )}
                  <div className="flex-1 min-w-0 space-y-1">
                    <a
                      href={c.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block font-semibold text-sm hover:underline line-clamp-2"
                    >
                      {c.title}
                    </a>
                    <div className="text-xs text-foreground/90 leading-relaxed bg-muted/40 rounded px-2 py-1.5">
                      <span className="text-xs text-muted-foreground uppercase tracking-wider font-medium">AI-резюме:</span>
                      <br />
                      {c.aiSummary}
                    </div>
                    {c.description && (
                      <div className="text-xs text-muted-foreground line-clamp-2">
                        {c.description}
                      </div>
                    )}
                  </div>
                </div>

                {/* Ad-specific: advertiser + erirToken */}
                {c.category === 'ad' && (c.advertiserName || c.erirToken) && (
                  <div className="text-xs text-muted-foreground bg-amber-500/5 border border-amber-500/20 rounded px-2 py-1">
                    {c.advertiserName && <span>Рекламодатель: <strong>{c.advertiserName}</strong></span>}
                    {c.erirToken && <span className="ml-2 font-mono">ERIR: {c.erirToken}</span>}
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex items-center gap-2 pt-1 border-t">
                  <Button
                    size="sm"
                    variant="default"
                    onClick={() => handleAction(c.id, 'publish')}
                    disabled={isProcessing}
                    className="gap-1 bg-emerald-600 hover:bg-emerald-700"
                  >
                    {processing === `${c.id}:publish` ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Check className="w-3.5 h-3.5" />
                    )}
                    Опубликовать
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleAction(c.id, 'reject')}
                    disabled={isProcessing}
                    className="gap-1 text-destructive border-destructive/30 hover:bg-destructive/5"
                  >
                    {processing === `${c.id}:reject` ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <X className="w-3.5 h-3.5" />
                    )}
                    Отклонить
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleAction(c.id, 'regenerate')}
                    disabled={isProcessing}
                    className="ml-auto gap-1 text-xs"
                  >
                    {processing === `${c.id}:regenerate` ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <RefreshCw className="w-3.5 h-3.5" />
                    )}
                    Перегенерировать AI-резюме
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
