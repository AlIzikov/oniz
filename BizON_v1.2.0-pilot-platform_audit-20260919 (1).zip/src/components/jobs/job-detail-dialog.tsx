// BizON — JobDetailDialog (Task 7-b, «BIZON NEXT» п.10-13 — «Подробнее» о вакансии)
// Архитектура диалога:
//   1) Верх: match% + «Почему подходит» (✓-причины) + «Что не совпадает» (⚠️, если есть missing)
//   2) JobPassport (готовый компонент, preloaded через /api/jobs/[id]/job-passport)
//   3) Блок «Что эта работа даст» + «Подготовить меня» (GET /api/jobs/[id]/growth —
//      если API ещё не готов / 404 — graceful-заглушка «Собираем план подготовки…»)
// Работает и по deep-link ?view=jobs&jobId=... — когда объекта вакансии нет,
// тянет данные сама (passport даёт title/company).
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Check, TriangleAlert, GraduationCap, Loader2, Sparkles, BookOpenCheck, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { JobPassport } from '@/components/jobs/job-passport';
import {
  formatSalaryText, matchBadgeClass,
  type JobGrowthResponse, type JobWithExtras,
} from '@/components/jobs/jobs-types';

// Форма ответа /api/jobs/[id]/job-passport (подмножество, нужное для верхнего блока)
interface PassportSummary {
  job?: { title?: string; companyName?: string; company?: string; location?: string | null; salaryMin?: number | null; salaryMax?: number | null; currency?: string };
  match?: {
    totalMatch?: number;
    why?: string;
    whatYouGet?: string[];
    breakdown?: { skills?: { matched?: string[]; missing?: string[] } };
  };
  context?: {
    matchedSkills?: string[];
    missingSkills?: string[];
  };
}

// Тип preloaded берём из пропсов JobPassport (JobPassportResponse не экспортируется)
type PassportPreloaded = NonNullable<React.ComponentProps<typeof JobPassport>['preloaded']>;

interface JobDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobId: string | null;
  /** Данные вакансии из списка (если есть) — обогащают верхний блок без ожидания API */
  job?: JobWithExtras | null;
  isSaved?: boolean;
  hasApplied?: boolean;
  onToggleSave?: (job: JobWithExtras) => void;
}

export function JobDetailDialog({ open, onOpenChange, jobId, job, isSaved, hasApplied, onToggleSave }: JobDetailDialogProps) {
  const [passport, setPassport] = React.useState<PassportSummary | null>(null);
  const [passportLoading, setPassportLoading] = React.useState(false);

  React.useEffect(() => {
    if (!open || !jobId) return;
    let cancelled = false;
    setPassport(null);
    setPassportLoading(true);
    api<PassportSummary>(`/api/jobs/${jobId}/job-passport`)
      .then(res => { if (!cancelled) setPassport(res); })
      .catch(() => {
        // Passport сам умеет догружаться и показывать ошибку — тихо идём дальше
        if (!cancelled) setPassport(null);
      })
      .finally(() => { if (!cancelled) setPassportLoading(false); });
    return () => { cancelled = true; };
  }, [open, jobId]);

  const title = job?.title ?? passport?.job?.title ?? 'Вакансия';
  const company = job?.company ?? passport?.job?.companyName ?? passport?.job?.company ?? '';
  const location = job?.location ?? passport?.job?.location ?? null;
  const matchPercent = job?.matchConfidence != null
    ? Math.round(job.matchConfidence * 100)
    : passport?.match?.totalMatch != null ? passport.match.totalMatch : null;
  const salary = job ? formatSalaryText(job) : passport?.job ? formatSalaryText({
    salaryMin: passport.job.salaryMin, salaryMax: passport.job.salaryMax, currency: passport.job.currency,
  }) : null;

  // === «Почему подходит» / «Что не совпадает» ===
  const reasons: string[] = React.useMemo(() => {
    if (job?.explanation?.reasons && job.explanation.reasons.length > 0) {
      return job.explanation.reasons.slice(0, 4);
    }
    const out: string[] = [];
    if (passport?.match?.why) out.push(passport.match.why);
    const matched = passport?.context?.matchedSkills ?? passport?.match?.breakdown?.skills?.matched ?? [];
    if (matched.length > 0) out.push(`Ваши навыки соответствуют требованиям: ${matched.slice(0, 4).join(', ')}`);
    const gives = passport?.match?.whatYouGet ?? [];
    if (out.length === 0 && gives.length > 0) out.push(...gives.slice(0, 2));
    return out.slice(0, 4);
  }, [job, passport]);

  const missing: string[] = React.useMemo(() => {
    if (job?.explanation?.missing && job.explanation.missing.length > 0) {
      return job.explanation.missing.slice(0, 3);
    }
    return (passport?.context?.missingSkills ?? passport?.match?.breakdown?.skills?.missing ?? []).slice(0, 3);
  }, [job, passport]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <DialogTitle className="text-lg leading-snug pr-6">{title}</DialogTitle>
          <DialogDescription className="flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
            {company && <span className="font-medium text-foreground/80">{company}</span>}
            {location && <span>· {location}</span>}
            {salary && <span className="font-semibold text-lighthouse tabular-nums">· {salary}</span>}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-120px)]">
          <div className="px-6 py-4 space-y-4">
            {/* === 1. Верхний блок: match + Почему подходит / Что не совпадает === */}
            {matchPercent != null && (
              <div className="flex items-start gap-3">
                <div
                  className={cn(
                    'flex-shrink-0 w-14 h-14 rounded-xl border flex flex-col items-center justify-center',
                    matchBadgeClass(matchPercent),
                  )}
                  aria-label={`Совпадение ${matchPercent} процентов`}
                >
                  <span className="text-base font-bold tabular-nums leading-none">{matchPercent}%</span>
                  <span className="text-xs uppercase tracking-wide opacity-80 mt-0.5">match</span>
                </div>
                <div className="min-w-0 flex-1 space-y-1.5 text-sm">
                  {reasons.length > 0 && (
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Почему подходит</div>
                      <ul className="space-y-0.5">
                        {reasons.map((r, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <Check className="w-3.5 h-3.5 mt-0.5 text-emerald-600 flex-shrink-0" aria-hidden="true" />
                            <span className="text-[13px] leading-snug">{r}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {missing.length > 0 && (
                    <div>
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Что не совпадает</div>
                      <ul className="space-y-0.5">
                        {missing.map((m, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <TriangleAlert className="w-3.5 h-3.5 mt-0.5 text-amber-600 flex-shrink-0" aria-hidden="true" />
                            <span className="text-[13px] leading-snug">{m}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
            {matchPercent == null && passportLoading && (
              <div className="flex items-center gap-3">
                <Skeleton className="w-14 h-14 rounded-xl" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-3.5 w-3/4" />
                  <Skeleton className="h-3.5 w-1/2" />
                </div>
              </div>
            )}

            {/* === 2. Job Passport (готовый компонент; при ошибке preloaded догружает сам) === */}
            {jobId && (
              <JobPassport
                jobId={jobId}
                hasApplied={hasApplied}
                isSaved={isSaved}
                preloaded={passport ? (passport as unknown as PassportPreloaded) : undefined}
                onToggleSave={onToggleSave && job ? () => onToggleSave(job) : undefined}
              />
            )}

            {/* === 3. Что эта работа даст + Подготовить меня (growth) === */}
            {jobId && <JobGrowthBlock jobId={jobId} />}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ===========================================================================
// Growth-блок: GET /api/jobs/[id]/growth → { readiness, actions, gives, forecast }
// Graceful: 404/ошибка → заглушка «Собираем план подготовки…», карточку не ломаем.
// ===========================================================================
export function JobGrowthBlock({ jobId }: { jobId: string }) {
  const [data, setData] = React.useState<JobGrowthResponse | null>(null);
  const [state, setState] = React.useState<'loading' | 'ok' | 'unavailable'>('loading');

  React.useEffect(() => {
    let cancelled = false;
    setState('loading');
    setData(null);
    api<JobGrowthResponse>(`/api/jobs/${jobId}/growth`)
      .then(res => {
        if (cancelled) return;
        setData(res);
        setState('ok');
      })
      .catch(() => { if (!cancelled) setState('unavailable'); });
    return () => { cancelled = true; };
  }, [jobId]);

  const gives = data?.gives ?? [];
  const readiness = data?.readiness ?? [];
  const actions = data?.actions ?? [];
  const hasContent = gives.length > 0 || readiness.length > 0 || actions.length > 0;

  if (state === 'loading') {
    return (
      <div className="rounded-lg border border-dashed p-4 flex items-center gap-2.5 text-sm text-muted-foreground">
        <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
        Собираем план подготовки…
      </div>
    );
  }

  if (state === 'unavailable' || !hasContent) {
    // API ещё не готов / пусто — изящная заглушка без поломки карточки
    return (
      <div className="rounded-lg border border-dashed p-4 flex items-center gap-2.5 text-sm text-muted-foreground">
        <BookOpenCheck className="w-4 h-4 flex-shrink-0" aria-hidden="true" />
        Собираем план подготовки к этой вакансии — скоро он появится здесь.
      </div>
    );
  }

  return (
    <div className="rounded-lg border p-4 space-y-3">
      <div className="text-sm font-semibold flex items-center gap-1.5">
        <GraduationCap className="w-4 h-4 text-lighthouse" aria-hidden="true" />
        Что эта работа даст
      </div>

      {gives.length > 0 && (
        <ul className="space-y-1">
          {gives.slice(0, 5).map((g, i) => (
            <li key={i} className="flex items-start gap-1.5 text-[13px]">
              <Sparkles className="w-3.5 h-3.5 mt-0.5 text-lighthouse flex-shrink-0" aria-hidden="true" />
              {g}
            </li>
          ))}
        </ul>
      )}

      {readiness.length > 0 && (
        <div>
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Подготовить меня</div>
          <ul className="space-y-1">
            {readiness.slice(0, 6).map((r, i) => (
              <li key={i} className="flex items-start gap-1.5 text-[13px]">
                {r.ok ? (
                  <Check className="w-3.5 h-3.5 mt-0.5 text-emerald-600 flex-shrink-0" aria-hidden="true" />
                ) : (
                  <X className="w-3.5 h-3.5 mt-0.5 text-amber-600 flex-shrink-0" aria-hidden="true" />
                )}
                <span>
                  <span className="font-medium">{r.skill}</span>
                  <span className="text-muted-foreground"> — нужно {r.requiredLevel}, у вас {r.currentLevel}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {actions.length > 0 && (
        <div>
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Что сделать</div>
          <ol className="space-y-1 list-decimal list-inside">
            {actions.slice(0, 4).map((a, i) => (
              <li key={i} className="text-[13px]">{a}</li>
            ))}
          </ol>
        </div>
      )}

      {data?.forecast && (
        <div className="text-[13px] text-muted-foreground bg-muted/50 rounded-md p-2.5">
          <span className="font-medium text-foreground">Прогноз: </span>{data.forecast}
        </div>
      )}
    </div>
  );
}
