'use client';

// BizON — HiringRealityBadge (Phase 3 — Hiring Reality Index)
// Бейдж «Hiring Reality: N/100» + кнопка «Почему?» → модалка с 11 критериями.
//
// Источник: GET /api/jobs/[id]/hiring-reality
//   {
//     "score": 91,
//     "level": "high" | "medium" | "low",
//     "criteria": [{ name, passed, points, detail? }, ...]
//   }
//
// Пороги (как в сервисе): ≥70 → high (зелёный), 40–69 → medium (жёлтый), <40 → low (красный).
// Lazy: грузит /api/jobs/[id]/hiring-reality при первом открытии модалки.
// Если передать initialScore/initialLevel — показывает бейдж сразу, без запроса.
import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import {
  Loader2, CheckCircle2, AlertTriangle, XCircle, Activity, HelpCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { HiringRealityLevel } from '@/lib/services/hiring-reality-service';

interface HiringRealityCriterion {
  name: string;
  passed: boolean;
  points: number;
  detail?: string;
}

interface HiringRealityResponse {
  score: number;
  level: HiringRealityLevel;
  criteria: HiringRealityCriterion[];
  computedAt?: string;
}

interface HiringRealityBadgeProps {
  jobId: string;
  /** Начальный score (если есть в JobPublic) — чтобы не дёргать API на каждый рендер */
  initialScore?: number;
  /** Начальный level — если известен */
  initialLevel?: HiringRealityLevel;
  /** Компактный режим (без текста, только иконка) */
  compact?: boolean;
  /** Крупный бейдж — для verified вакансий в заголовке карточки */
  prominent?: boolean;
  /** Дополнительный класс */
  className?: string;
}

const LEVEL_META: Record<HiringRealityLevel, {
  label: string;
  badge: string;
  icon: React.ReactNode;
  progressClass: string;
}> = {
  high: {
    label: 'Высокая',
    badge:
      'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25',
    icon: <CheckCircle2 className="w-3.5 h-3.5" />,
    progressClass: '[&>[data-slot=progress-indicator]]:bg-emerald-600',
  },
  medium: {
    label: 'Средняя',
    badge:
      'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30 hover:bg-amber-500/25',
    icon: <AlertTriangle className="w-3.5 h-3.5" />,
    progressClass: '[&>[data-slot=progress-indicator]]:bg-amber-500',
  },
  low: {
    label: 'Низкая',
    badge:
      'bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30 hover:bg-red-500/25',
    icon: <XCircle className="w-3.5 h-3.5" />,
    progressClass: '[&>[data-slot=progress-indicator]]:bg-red-500',
  },
};

function deriveLevel(score: number): HiringRealityLevel {
  if (score >= 70) return 'high';
  if (score >= 40) return 'medium';
  return 'low';
}

export function HiringRealityBadge({
  jobId,
  initialScore,
  initialLevel,
  compact,
  prominent,
  className,
}: HiringRealityBadgeProps) {
  const [score, setScore] = React.useState<number>(initialScore ?? 0);
  const [level, setLevel] = React.useState<HiringRealityLevel>(
    initialLevel ?? deriveLevel(initialScore ?? 0),
  );
  const [result, setResult] = React.useState<HiringRealityResponse | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [open, setOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!jobId) return;
    setLoading(true);
    try {
      const res = await api<HiringRealityResponse>(`/api/jobs/${jobId}/hiring-reality`);
      setResult(res);
      setScore(res.score);
      setLevel(res.level);
    } catch {
      // silent — оставляем initial
    } finally {
      setLoading(false);
    }
  }, [jobId]);

  function handleOpenChange(next: boolean) {
    if (next && !result) {
      load();
    }
    setOpen(next);
  }

  const meta = LEVEL_META[level];
  const scoreInt = Math.round(score);
  // Если initialScore не передан (или 0) — показываем neutral-серый бейдж «HR: ?»,
  // пользователь жмёт и видит расчёт.
  const hasInitial = (initialScore ?? 0) > 0 || !!initialLevel;
  const isNeutral = !hasInitial && !result;

  return (
    <>
      <button
        type="button"
        onClick={() => handleOpenChange(true)}
        title={`Hiring Reality: ${scoreInt}/100 (${meta.label}). Нажмите для подробностей.`}
        aria-label={`Hiring Reality ${scoreInt} из 100. Открыть объяснение.`}
        className={cn(
          'inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-xs font-medium transition',
          prominent && 'text-xs px-2.5 py-1',
          compact && 'px-1.5',
          isNeutral
            ? 'bg-muted text-muted-foreground border-border hover:bg-accent'
            : meta.badge,
          className,
        )}
      >
        {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : (isNeutral ? <Activity className="w-3 h-3" /> : meta.icon)}
        {!compact && (
          <>
            <span>Hiring Reality:</span>
            <span className="tabular-nums opacity-90">
              {isNeutral ? '?' : `${scoreInt}/100`}
            </span>
          </>
        )}
      </button>

      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-lighthouse" />
              Hiring Reality: {scoreInt}/100
            </DialogTitle>
            <DialogDescription>
              11 критериев реальности вакансии. Пороги: ≥70 — Высокая, 40–69 — Средняя, &lt;40 — Низкая.
            </DialogDescription>
          </DialogHeader>

          {loading && !result ? (
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin mr-2" /> Расчёт критериев…
            </div>
          ) : result ? (
            <div className="space-y-3">
              {/* Overall */}
              <div className="flex items-center justify-between gap-3">
                <div className={cn('inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-semibold border', meta.badge)}>
                  {meta.icon} {meta.label}
                </div>
                <div className="text-xs text-muted-foreground text-right tabular-nums">
                  {scoreInt}/100
                </div>
              </div>
              <Progress value={scoreInt} className={cn('h-2', meta.progressClass)} />

              {/* 11 criteria */}
              <div className="space-y-2 pt-2 max-h-[50vh] overflow-y-auto">
                {result.criteria.map((c, idx) => (
                  <div key={`${idx}-${c.name}`} className="flex items-start gap-2 text-sm">
                    <span
                      className={cn(
                        'flex-shrink-0 mt-0.5 w-4 h-4 rounded-full flex items-center justify-center',
                        c.passed
                          ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                          : 'bg-muted text-muted-foreground',
                      )}
                      aria-hidden="true"
                    >
                      {c.passed ? '✓' : '·'}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className={cn('font-medium', c.passed ? 'text-foreground' : 'text-muted-foreground')}>
                          {c.name}
                        </span>
                        <span className="text-xs tabular-nums text-muted-foreground flex-shrink-0">
                          {c.points}
                        </span>
                      </div>
                      {c.detail && (
                        <div className="text-xs text-foreground/70 mt-0.5">{c.detail}</div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t text-xs text-muted-foreground flex items-start gap-1.5">
                <HelpCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                <span>
                  Индекс считается на лету из данных о вакансии, компании и истории откликов.
                  BizON рекомендует откликаться на вакансии с уровнем «Высокая» (≥70) —
                  это снижает риск «фантомных» вакансий.
                </span>
              </div>
            </div>
          ) : (
            <div className="text-sm text-muted-foreground py-4">
              Не удалось загрузить Hiring Reality.
              <button onClick={load} className="ml-2 underline hover:text-foreground">Повторить</button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
