// BizON — Opportunity embedding helpers (Wave 11-c, отзыв пользователя)
//
// БЫЛО (Task 7-b): блок «ВАМ ПОДХОДИТ» + «ВОЗМОЖНО, ВАМ ПОДОЙДЁТ» отдельной
// секцией НАД списком «Вакансии для вас» — два похожих блока один под другим.
//
// СТАЛО (11-c): по отзыву «"Вакансии для вас" и "Вам подходит" очень одинаковы —
// надо объединить» — главный список един: JobsView вливает топ-возможности
// (GET /api/opportunities?type=job) в НАЧАЛО ленты карточками JobLightCard с
// бейджем «Вам подходит», затем обычная лента без дублей. Секция exploration
// («ВОЗМОЖНО, ВАМ ПОДОЙДЁТ») из главного окна убрана.
//
// Поэтому компонент-блок адаптирован под «выдачу данных для встраивания»:
// здесь только сортировка и конвертация OpportunityItem → JobWithExtras;
// рендер делает JobsView через JobLightCard (проп highlight).
'use client';

import {
  opportunityMatch, reasonsToList,
  type JobWithExtras,
  type OpportunityItem,
} from '@/components/jobs/jobs-types';

/** Сколько топ-возможностей вливаем в начало ленты (как раньше в блоке). */
export const TOP_OPPORTUNITIES_COUNT = 3;

/** Бейдж-метка на карточках, влитых из Opportunity Engine. */
export const OPPORTUNITY_HIGHLIGHT = 'Вам подходит';

/** Топ-возможности по убыванию match% (та же сортировка, что была в блоке). */
export function sortOpportunities(items: OpportunityItem[]): OpportunityItem[] {
  return [...items].sort((a, b) => opportunityMatch(b) - opportunityMatch(a));
}

export interface EmbeddableOpportunityCard {
  job: JobWithExtras;
  highlight: string;
}

/**
 * Конвертирует возможность в карточку для ленты.
 * Если вакансия уже есть в ленте (jobId ∈ feedJobs) — берём РЕАЛЬНУЮ карточку
 * (честные компания/зарплата) и переопределяем match% и «Почему» данными
 * Opportunity Engine (теми же, что показывал старый блок «ВАМ ПОДХОДИТ»).
 * Если вакансии нет в ленте — собираем карточку из самой возможности.
 * Возвращает null для возможностей без jobId — раньше их кнопка была
 * disabled («некликабельно»), теперь мы их честно не вливаем в ленту.
 */
export function opportunityToFeedCard(
  item: OpportunityItem,
  feedJobs: JobWithExtras[],
): EmbeddableOpportunityCard | null {
  if (!item.jobId) return null;

  const matchConfidence = opportunityMatch(item) / 100;
  const reasons = reasonsToList({ explanation: item.explanation });
  const explanation = reasons.length > 0 ? { reasons, missing: [] as string[] } : null;

  const real = feedJobs.find(j => j.id === item.jobId);
  if (real) {
    return {
      job: { ...real, matchConfidence, explanation: explanation ?? real.explanation ?? null },
      highlight: OPPORTUNITY_HIGHLIGHT,
    };
  }

  // Вакансии нет в ленте (скрыта анти-эхо-камерой / за пределами выборки) —
  // собираем карточку из возможности: company неизвестен API (только companyId).
  const compensation =
    typeof item.compensation === 'number' && Number.isFinite(item.compensation)
      ? item.compensation
      : null;

  return {
    job: {
      id: item.jobId,
      title: item.title,
      company: '',
      description: item.description ?? '',
      requiredSkills: [],
      salaryFrom: compensation,
      salaryTo: null,
      location: item.location ?? null,
      growthScore: 0.5,
      matchConfidence,
      createdAt: item.createdAt ?? new Date().toISOString(),
      explanation,
    },
    highlight: OPPORTUNITY_HIGHLIGHT,
  };
}
