// BizON — Jobs View («Работа», Task 7-b — BIZON NEXT, intention-first главный экран;
// Wave 11-c — объединение лент, фильтры-мониторы, «Горячие» = платные)
//
// Стратегия (стр. 19-31 PDF): первым элементом не фильтр, а намерение человека.
//   • Единая интент-строка «Какую работу вы ищете?» + [Найти работу]
//   • 4 режима: 🔎 Быстро | ✍️ Своими словами (parsedIntent + «Я правильно вас понял?») |
//               🎯 Точно (точные фильтры + чипы «Что для вас важно?») | 🔬 Исследовать
//   • Wave 11-c (отзыв пользователя): «Вакансии для вас» и «ВАМ ПОДХОДИТ» — одно и то же.
//     ЕДИНАЯ лента: топ-3 возможностей (Opportunity Engine) влиты в начало списка
//     карточками с бейджем «Вам подходит» + обычная лента без дублей.
//     Отдельный блок «ВОЗМОЖНО, ВАМ ПОДОЙДЁТ» из главного окна убран (разгрузка).
//   • Подраздел «Горячие» = платные и срочные размещения (Job.boosted, boostedUntil > now) —
//     НЕ «высокий match», как было раньше.
//   • Сохранённые фильтры-мониторы (SavedFilter, максимум 9) — панель в правом rail;
//     применение фильтра приходит сигналом jobsFilterApply из app-store.
//   • Группы выдачи: Точное соответствие / Сильное / Смежные (счётчики-фильтры по matchTier)
//   • Лёгкая карточка: [Подробнее] [Сохранить] [Не моё] (Explicit Negative Intent)
//   • Никакой стены из 17 фильтров — точные фильтры только в режиме «Точно»
//   • Deep-link ?view=jobs&jobId=... открывает детальный диалог вакансии
// Личные подразделы (Сохранённые / Мои отклики) — обычный список без интент-шапки.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import type { JobPublic } from '@/lib/types';
import { RefreshCw, SearchX } from 'lucide-react';
import { cn } from '@/lib/utils';
import { JobIntentBar } from '@/components/jobs/job-intent-bar';
import { JobFacetsPanel } from '@/components/jobs/job-facets-panel';
import { JobPreciseFilters, EMPTY_PRECISE_FILTERS, type PreciseFilters } from '@/components/jobs/job-precise-filters';
import { JobExplorePanel } from '@/components/jobs/job-explore-panel';
import { JobLightCard, JobLightCardSkeleton } from '@/components/jobs/job-light-card';
import { JobDetailDialog } from '@/components/jobs/job-detail-dialog';
import { JobNotMineDialog } from '@/components/jobs/job-not-mine-dialog';
import { MyPathView } from '@/components/jobs/my-path-view';
import {
  sortOpportunities, opportunityToFeedCard, TOP_OPPORTUNITIES_COUNT,
  type EmbeddableOpportunityCard,
} from '@/components/jobs/job-opportunities';
import {
  tierLabel, matchBadgeClass,
  type JobSearchMode, type JobWithExtras, type JobsApiResponse,
  type JobsGroups, type ParsedIntent, type OpportunityItem,
  type CareerDiscoveryResponse,
} from '@/components/jobs/jobs-types';

// Заголовки для личных подразделов (SubSectionBar в правой панели)
const SUBSECTION_TITLES: Record<string, { title: string; subtitle: string }> = {
  saved:   { title: 'Сохранённые', subtitle: 'Ваш список избранного' },
  applied: { title: 'Мои отклики', subtitle: 'Вакансии, на которые вы откликнулись' },
  mine:    { title: 'Мои отклики', subtitle: 'Вакансии, на которые вы откликнулись' },
};

const WORK_FORMAT_LABELS: Record<string, string> = {
  remote: 'Удалённо', hybrid: 'Гибрид', onsite: 'В офисе', any: 'Любой',
};

type GroupFilter = 'all' | 'exact' | 'strong' | 'adjacent';

// Wave 11-c: «Горячие» = платные размещения (Job.boosted / boostedUntil).
// jobs-types.ts — зона 11-d, не расширяем: локальное расширение типа здесь.
type BoostedJob = JobWithExtras & { boosted?: boolean; boostedUntil?: string | null };

/** Платное/срочное размещение активно: boosted=true и boostedUntil в будущем. */
function isHotJob(j: JobWithExtras): boolean {
  const b = j as BoostedJob;
  return b.boosted === true && !!b.boostedUntil && new Date(b.boostedUntil).getTime() > Date.now();
}

interface JobsViewProps {
  /** Deep-link ?view=jobs&jobId=... — открыть детальный диалог этой вакансии */
  deepLinkJobId?: string | null;
  /** Родитель сообщает, что deep-link обработан */
  onDeepLinkHandled?: () => void;
}

export function JobsView({ deepLinkJobId, onDeepLinkHandled }: JobsViewProps) {
  const {
    jobsSubSection, setJobsSubSection,
    jobsFilterApply, setJobsCurrentSearchParams,
  } = useAppStore();

  // === Личные подразделы (Сохранённые / Мои отклики) — обычный список ===
  const isPersonalSection = jobsSubSection === 'saved' || jobsSubSection === 'applied' || jobsSubSection === 'mine';

  // === Режим и интент ===
  const [mode, setMode] = React.useState<JobSearchMode>('quick');
  const [query, setQuery] = React.useState('');
  const [autoFocusSignal, setAutoFocusSignal] = React.useState(0);

  // === Режим «Точно» ===
  const [preciseFilters, setPreciseFilters] = React.useState<PreciseFilters>(EMPTY_PRECISE_FILTERS);
  const [important, setImportant] = React.useState<Set<string>>(new Set());

  // === Режим «Исследовать» ===
  const [exploreGoals, setExploreGoals] = React.useState<Set<string>>(new Set());
  const [discovery, setDiscovery] = React.useState<CareerDiscoveryResponse | null>(null);
  const [discoveryLoading, setDiscoveryLoading] = React.useState(false);
  const discoveryLoaded = React.useRef(false);

  // === Результаты ===
  const [feedJobs, setFeedJobs] = React.useState<JobWithExtras[]>([]); // лента без поиска
  const [results, setResults] = React.useState<JobWithExtras[] | null>(null);
  const [groups, setGroups] = React.useState<JobsGroups | null>(null);
  const [parsedIntent, setParsedIntent] = React.useState<ParsedIntent | null>(null);
  const [intentDismissed, setIntentDismissed] = React.useState(false);
  const [groupFilter, setGroupFilter] = React.useState<GroupFilter>('all');
  const [searched, setSearched] = React.useState(false);
  const [loading, setLoading] = React.useState(true);

  // === Личное состояние карточек ===
  const [savedJobs, setSavedJobs] = React.useState<Set<string>>(new Set());
  const [removedIds, setRemovedIds] = React.useState<Set<string>>(new Set());

  // === Opportunity Engine (топ-возможности влиты в ленту с бейджем «Вам подходит») ===
  const [opportunities, setOpportunities] = React.useState<OpportunityItem[]>([]);

  // === Диалоги ===
  const [detailJob, setDetailJob] = React.useState<{ jobId: string; job: JobWithExtras | null } | null>(null);
  const [notMineJob, setNotMineJob] = React.useState<JobWithExtras | null>(null);

  // ===========================================================================
  // Загрузка данных
  // ===========================================================================

  const loadPersonalJobs = React.useCallback(async () => {
    setLoading(true);
    try {
      if (jobsSubSection === 'saved') {
        const res = await api<{ jobs: JobWithExtras[] }>('/api/jobs/saved');
        setFeedJobs(res.jobs ?? []);
      } else {
        // applied / mine — через JobApplication
        const res = await api<{ jobs?: JobWithExtras[]; applications?: Array<{ job: Record<string, unknown>; matchConfidence?: number }> }>('/api/jobs/applications');
        if (res.applications) {
          setFeedJobs(res.applications.map(a => {
            const j = a.job as unknown as JobPublic & { growthScore?: number };
            return {
              id: j.id, title: j.title, company: j.company,
              description: j.description ?? '',
              requiredSkills: j.requiredSkills ?? [],
              salaryFrom: j.salaryFrom, salaryTo: j.salaryTo,
              location: j.location,
              growthScore: j.growthScore ?? 0.5,
              matchConfidence: a.matchConfidence ?? 0,
              createdAt: j.createdAt,
            } satisfies JobWithExtras;
          }));
        } else {
          setFeedJobs(res.jobs ?? []);
        }
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Не удалось загрузить список';
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [jobsSubSection]);

  const loadFeed = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<JobsApiResponse>('/api/jobs');
      setFeedJobs(res.jobs ?? []);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Не удалось загрузить вакансии';
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  const loadOpportunities = React.useCallback(async () => {
    try {
      const res = await api<{ items?: OpportunityItem[] }>('/api/opportunities?type=job');
      setOpportunities((res.items ?? []).filter(o => o.type === 'job' || o.jobId));
    } catch {
      // Opportunity Engine — обогащение, не критичный путь: тихо прячем блок
      setOpportunities([]);
    }
  }, []);

  const loadDiscovery = React.useCallback(async () => {
    if (discoveryLoaded.current) return;
    discoveryLoaded.current = true;
    setDiscoveryLoading(true);
    try {
      const res = await api<CareerDiscoveryResponse>('/api/me/career-discovery');
      setDiscovery(res);
    } catch {
      setDiscovery(null);
    } finally {
      setDiscoveryLoading(false);
    }
  }, []);

  React.useEffect(() => {
    if (isPersonalSection) {
      loadPersonalJobs();
    } else {
      // Wave 11: смена подраздела (Горячие/Рекомендованные/Все) сбрасывает активный
      // поиск — раньше клик «Горячие» после поиска показывал старые результаты.
      // Исключение не нужно: при применении фильтра из панели «Мои фильтры»
      // эффект фильтра (объявлен ниже) сам перезапускает поиск уже после сброса.
      if (searched) {
        setResults(null);
        setSearched(false);
        setGroups(null);
        setParsedIntent(null);
      }
      loadFeed();
    }
     
  }, [isPersonalSection, jobsSubSection, loadFeed, loadPersonalJobs]);

  React.useEffect(() => { loadOpportunities(); }, [loadOpportunities]);

  // Career Discovery — лениво при первом входе в режим «Исследовать»
  React.useEffect(() => {
    if (mode === 'explore') loadDiscovery();
  }, [mode, loadDiscovery]);

  // ===========================================================================
  // Wave 11-c: фильтры-мониторы (правая панель «Мои фильтры» ↔ главный экран)
  // ===========================================================================

  // (Эффект применения фильтра объявлен НИЖЕ — после executeSearch,
  // чтобы не использовать коллбэк до его объявления.)

  // Публикуем параметры ТЕКУЩЕГО поиска в стор — их видит панель «Мои фильтры»
  // (кнопка «Сохранить текущий поиск как фильтр» активна при searched или непустом запросе).
  React.useEffect(() => {
    const q = query.trim();
    if (!searched && !q) {
      setJobsCurrentSearchParams(null);
      return;
    }
    const params: Record<string, string> = { mode };
    if (q) params.q = q;
    const imp = mode === 'explore'
      ? Array.from(exploreGoals).join(',')
      : Array.from(important).join(',');
    if (imp) params.important = imp;
    if (mode === 'precise') {
      if (preciseFilters.location.trim()) params.location = preciseFilters.location.trim();
      if (preciseFilters.minSalary && Number(preciseFilters.minSalary) > 0) {
        params.minSalary = String(Number(preciseFilters.minSalary));
      }
      if (preciseFilters.workFormat && preciseFilters.workFormat !== 'any') params.workFormat = preciseFilters.workFormat;
      if (preciseFilters.level) params.level = preciseFilters.level;
      if (preciseFilters.industry.trim()) params.industry = preciseFilters.industry.trim();
    }
    setJobsCurrentSearchParams(params);
  }, [searched, query, mode, important, exploreGoals, preciseFilters, setJobsCurrentSearchParams]);

  // ===========================================================================
  // Поиск (единая точка для всех режимов)
  // ===========================================================================

  const executeSearch = React.useCallback(async (params: {
    mode: JobSearchMode;
    q?: string;
    importantCsv?: string;
    precise?: PreciseFilters;
  }) => {
    setLoading(true);
    setGroupFilter('all');
    try {
      const usp = new URLSearchParams();
      if (params.q) usp.set('q', params.q);
      usp.set('mode', params.mode);
      if (params.importantCsv) usp.set('important', params.importantCsv);
      if (params.precise) {
        const p = params.precise;
        if (p.location.trim()) usp.set('location', p.location.trim());
        if (p.minSalary && Number(p.minSalary) > 0) usp.set('minSalary', String(Number(p.minSalary)));
        if (p.workFormat && p.workFormat !== 'any') usp.set('workFormat', p.workFormat);
        if (p.level) usp.set('level', p.level);
        if (p.industry.trim()) usp.set('industry', p.industry.trim());
      }
      const res = await api<JobsApiResponse>(`/api/jobs?${usp.toString()}`);
      setResults(res.jobs ?? []);
      setGroups(res.groups ?? null);
      setParsedIntent(res.parsedIntent ?? null);
      setIntentDismissed(false);
      setSearched(true);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Поиск не удался';
      toast({ title: 'Ошибка поиска', description: msg, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  // Применение сохранённого фильтра: сигналом из правой панели (jobsFilterApply).
  // Новый объект сигнала = новый ts → эффект срабатывает даже при тех же параметрах.
  React.useEffect(() => {
    if (!jobsFilterApply) return;
    const p = jobsFilterApply.params;
    const applyMode: JobSearchMode =
      p.mode === 'nl' || p.mode === 'precise' || p.mode === 'explore' ? p.mode : 'quick';
    // Из личных подразделов (Сохранённые/Мои отклики) — возвращаемся в главный экран
    setJobsSubSection('recommended');
    setMode(applyMode);
    setQuery(p.q ?? '');
    if (applyMode === 'precise') {
      const precise: PreciseFilters = {
        location: p.location ?? '',
        minSalary: p.minSalary ?? '',
        workFormat: p.workFormat ?? 'any',
        level: p.level ?? '',
        industry: p.industry ?? '',
      };
      setPreciseFilters(precise);
      executeSearch({
        mode: applyMode,
        q: p.q || undefined,
        importantCsv: p.important || undefined,
        precise,
      });
    } else {
      const importantSet = new Set(p.important ? p.important.split(',').filter(Boolean) : []);
      if (applyMode === 'explore') {
        setExploreGoals(importantSet);
        setImportant(new Set());
      } else {
        setImportant(importantSet);
        setExploreGoals(new Set());
      }
      executeSearch({ mode: applyMode, q: p.q || undefined, importantCsv: p.important || undefined });
    }
  }, [jobsFilterApply, executeSearch, setJobsSubSection]);

  function handleSubmit() {
    const q = query.trim();
    if (mode === 'precise') {
      const hasFilters = preciseFilters.location.trim() || preciseFilters.minSalary || preciseFilters.industry.trim() ||
        (preciseFilters.workFormat && preciseFilters.workFormat !== 'any') || preciseFilters.level || important.size > 0;
      if (!q && !hasFilters) {
        toast({ title: 'Уточните запрос', description: 'Напишите должность или задайте хотя бы один фильтр.' });
        return;
      }
      executeSearch({ mode: 'precise', q: q || undefined, importantCsv: important.size ? Array.from(important).join(',') : undefined, precise: preciseFilters });
      return;
    }
    if (mode === 'explore') {
      if (exploreGoals.size === 0) {
        toast({ title: 'Выберите, что для вас важно', description: 'Отметьте 1–2 карточки — и мы подберём варианты.' });
        return;
      }
      executeSearch({ mode: 'explore', q: q || undefined, importantCsv: Array.from(exploreGoals).join(',') });
      return;
    }
    if (!q) {
      setAutoFocusSignal(s => s + 1);
      toast({ title: 'Напишите, какую работу вы ищете', description: 'Например: хочу руководить проектами в энергетике, от 250 000 ₽' });
      return;
    }
    executeSearch({ mode, q });
  }

  // Выбор цели в «Исследовать» → сразу ищем
  function handleGoalsChange(goals: Set<string>) {
    setExploreGoals(goals);
    if (goals.size > 0) {
      executeSearch({ mode: 'explore', q: query.trim() || undefined, importantCsv: Array.from(goals).join(',') });
    } else {
      setResults(null); setSearched(false); setGroups(null); setParsedIntent(null);
    }
  }

  // Клик по карьерному сценарию — подставляем роль в q и ищем
  function handlePickRole(role: string) {
    setQuery(role);
    executeSearch({ mode: 'quick', q: role });
  }

  function toggleImportant(code: string) {
    setImportant(prev => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code); else next.add(code);
      return next;
    });
  }

  // ===========================================================================
  // Действия карточек
  // ===========================================================================

  async function handleToggleSave(job: JobWithExtras) {
    const wasSaved = savedJobs.has(job.id);
    // Оптимистичное обновление
    setSavedJobs(prev => {
      const next = new Set(prev);
      if (wasSaved) next.delete(job.id); else next.add(job.id);
      return next;
    });
    try {
      const res = await api<{ saved: boolean }>(`/api/jobs/${job.id}/save`, { method: 'POST' });
      toast({ title: res.saved ? 'Вакансия сохранена' : 'Удалено из сохранённых' });
      setSavedJobs(prev => {
        const next = new Set(prev);
        if (res.saved) next.add(job.id); else next.delete(job.id);
        return next;
      });
    } catch (e: unknown) {
      // Откат
      setSavedJobs(prev => {
        const next = new Set(prev);
        if (wasSaved) next.add(job.id); else next.delete(job.id);
        return next;
      });
      const msg = e instanceof Error ? e.message : 'Не удалось изменить';
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    }
  }

  // «Не моё» — Explicit Negative Intent: оптимистично скрываем, при ошибке откатываем
  async function handleNotMineConfirm(reason: string, reasonLabel: string) {
    const job = notMineJob;
    if (!job) return;
    setNotMineJob(null);
    setRemovedIds(prev => new Set(prev).add(job.id));
    try {
      await api('/api/feed/recommendations/ignore', {
        method: 'POST',
        body: JSON.stringify({
          topic: job.title,
          itemType: 'job',
          source: 'jobs',
          reason,
          targetId: job.id,
        }),
      });
      toast({ title: 'Учли ваш выбор', description: `«${reasonLabel}» — похожие вакансии больше не будем показывать.` });
    } catch (e: unknown) {
      setRemovedIds(prev => {
        const next = new Set(prev);
        next.delete(job.id);
        return next;
      });
      const msg = e instanceof Error ? e.message : 'Не удалось сохранить выбор';
      toast({ title: 'Не получилось скрыть', description: msg, variant: 'destructive' });
    }
  }

  // Deep-link: ?view=jobs&jobId=... — открыть детальный диалог
  React.useEffect(() => {
    if (deepLinkJobId) {
      setDetailJob({ jobId: deepLinkJobId, job: null });
      onDeepLinkHandled?.();
    }
  }, [deepLinkJobId, onDeepLinkHandled]);

  // ===========================================================================
  // Производные списки
  // ===========================================================================

  // Wave 11-c: топ-возможности → карточки для вливания в начало ленты.
  // Только когда НЕТ активного поиска (при поиске главный список = результаты,
  // возможности не дублируем). Бейдж «Вам подходит» объясняет, почему карточка наверху.
  const opportunityCards: EmbeddableOpportunityCard[] = React.useMemo(() => {
    if (searched || isPersonalSection) return [];
    // Влиты только в дефолтную «Рекомендованные»: в «Горячие»/«Все вакансии»
    // подсветка неуместна (Горячие — только платные размещения)
    if (jobsSubSection !== 'recommended') return [];
    return sortOpportunities(opportunities)
      .slice(0, TOP_OPPORTUNITIES_COUNT)
      .map(o => opportunityToFeedCard(o, feedJobs))
      .filter((c): c is EmbeddableOpportunityCard => c !== null)
      .filter(c => !removedIds.has(c.job.id));
  }, [searched, isPersonalSection, jobsSubSection, opportunities, feedJobs, removedIds]);

  // Базовый список для главного экрана: результат поиска или лента
  const baseList: JobWithExtras[] = React.useMemo(() => {
    if (searched && results !== null) return results;
    let list = feedJobs;
    // Wave 11-c: «Горячие» = платные и срочные размещения (boosted), НЕ «высокий match»
    if (jobsSubSection === 'hot') list = list.filter(isHotJob);
    // Возможности, влитые наверх, не дублируем в общей ленте
    if (opportunityCards.length > 0) {
      const oppIds = new Set(opportunityCards.map(c => c.job.id));
      list = list.filter(j => !oppIds.has(j.id));
    }
    return list;
  }, [searched, results, feedJobs, jobsSubSection, opportunityCards]);

  // Скрываем «Не моё»-скрытые вакансии
  const visibleList = React.useMemo(
    () => baseList.filter(j => !removedIds.has(j.id)),
    [baseList, removedIds],
  );

  // Групповой фильтр (Точное/Сильное/Смежные) — только если в данных есть matchTier
  const hasTiers = React.useMemo(() => visibleList.some(j => j.matchTier), [visibleList]);
  const shownList = React.useMemo(() => {
    if (groupFilter === 'all' || !hasTiers) return visibleList;
    const filtered = visibleList.filter(j => j.matchTier === groupFilter);
    return filtered.length > 0 ? filtered : visibleList;
  }, [visibleList, groupFilter, hasTiers]);

  // ===========================================================================
  // Рендер
  // ===========================================================================

  // «Мой путь» (Job Pipeline, Task 10-d) — отдельный экран: стадии из
  // JOBS_PIPELINE_CONFIG + переключатель статусов через PATCH /api/applications/[id]/status
  if (jobsSubSection === 'my-path') {
    return <MyPathView />;
  }

  if (isPersonalSection) {
    const meta = SUBSECTION_TITLES[jobsSubSection] ?? SUBSECTION_TITLES.saved;
    return (
      <div className="space-y-4 w-full min-w-0">
        <div className="flex items-baseline justify-between">
          <div>
            <h1 className="text-2xl font-bold">{meta.title}</h1>
            <p className="text-sm text-muted-foreground">{meta.subtitle}</p>
          </div>
          <Button variant="outline" size="sm" onClick={loadPersonalJobs} disabled={loading} aria-label="Обновить список">
            <RefreshCw className={cn('w-4 h-4', loading && 'animate-spin')} aria-hidden="true" />
            Обновить
          </Button>
        </div>
        <JobListArea
          loading={loading}
          jobs={feedJobs.filter(j => !removedIds.has(j.id))}
          emptyText={jobsSubSection === 'saved'
            ? 'У вас пока нет сохранённых вакансий. Нажмите на иконку закладки в карточке вакансии.'
            : 'Вы ещё не откликались на вакансии.'}
          showNotMine={false}
          onOpen={job => setDetailJob({ jobId: job.id, job })}
          onToggleSave={handleToggleSave}
          isSaved={id => savedJobs.has(id)}
        />
        {/* Диалоги доступны и в личных разделах (deep-link из поиска) */}
        {detailJob && (
          <JobDetailDialog
            open
            onOpenChange={o => { if (!o) setDetailJob(null); }}
            jobId={detailJob.jobId}
            job={detailJob.job}
            isSaved={detailJob.job ? savedJobs.has(detailJob.job.id) : false}
            onToggleSave={handleToggleSave}
          />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 w-full min-w-0">
      {/* === Заголовок модуля === */}
      <div className="flex items-baseline justify-between">
        <div>
          <h1 className="text-2xl font-bold">Работа</h1>
          <p className="text-sm text-muted-foreground">Найдём следующую хорошую работу — опишите её своими словами</p>
        </div>
        <Button variant="outline" size="sm" onClick={() => { setResults(null); setSearched(false); setGroups(null); setParsedIntent(null); loadFeed(); }} disabled={loading} aria-label="Обновить ленту вакансий">
          <RefreshCw className={cn('w-4 h-4', loading && 'animate-spin')} aria-hidden="true" />
          Обновить
        </Button>
      </div>

      {/* === Интент-строка + режимы === */}
      <JobIntentBar
        query={query}
        onQueryChange={setQuery}
        mode={mode}
        onModeChange={setMode}
        onSubmit={handleSubmit}
        loading={loading}
        autoFocusSignal={autoFocusSignal}
      />

      {/* === Панель режима «Точно» === */}
      {mode === 'precise' && (
        <JobPreciseFilters
          filters={preciseFilters}
          onFiltersChange={setPreciseFilters}
          important={important}
          onToggleImportant={toggleImportant}
          onApply={handleSubmit}
          loading={loading}
        />
      )}

      {/* === Wave 5: фасет-фильтры с агрегациями + Radar + автопоиск (S-115..S-117) === */}
      <JobFacetsPanel onApplyFilters={(f) => {
        // фасеты → режим «Точно» штатного поиска (совместимые поля)
        setMode('precise');
        setPreciseFilters((prev) => ({
          ...prev,
          location: f.location ?? prev.location,
          minSalary: f.salaryMin ?? prev.minSalary,
          workFormat: (f.workFormat as 'remote' | 'hybrid' | 'onsite' | 'any') ?? prev.workFormat,
          level: f.level ?? prev.level,
          industry: f.industry ?? prev.industry,
        }));
        handleSubmit();
      }} />

      {/* === Панель режима «Исследовать» === */}
      {mode === 'explore' && (
        <JobExplorePanel
          goals={exploreGoals}
          onGoalsChange={handleGoalsChange}
          discovery={discovery}
          discoveryLoading={discoveryLoading}
          onPickRole={handlePickRole}
        />
      )}

      {/* === «Я правильно вас понял?» (режим «Своими словами») === */}
      {mode === 'nl' && parsedIntent && !intentDismissed && (
        <IntentConfirmPanel
          intent={parsedIntent}
          onConfirm={() => setIntentDismissed(true)}
          onEdit={() => { setIntentDismissed(true); setAutoFocusSignal(s => s + 1); }}
        />
      )}

      {/* Wave 11-c: отдельный блок «ВАМ ПОДХОДИТ»/«ВОЗМОЖНО» убран — топ-возможности
          влиты в начало единой ленты ниже (карточки с бейджем «Вам подходит»). */}

      {/* === Список вакансий === */}
      <section aria-label="Список вакансий" className="min-h-[420px]">
        <div className="flex items-baseline justify-between gap-2 mb-3 flex-wrap">
          <div>
            <h2 className="text-base font-semibold">
              {searched ? (shownList.length > 0 ? `Нашли ${shownList.length} ${plural(shownList.length)}` : 'Ничего не нашли') : 'Вакансии для вас'}
            </h2>
            <p className="text-xs text-muted-foreground">
              {searched
                ? query.trim() ? `по запросу «${query.trim()}»` : 'по вашим параметрам'
                : jobsSubSection === 'hot' ? 'платные и срочные размещения работодателей' : 'подобраны по вашему профилю'}
            </p>
          </div>
        </div>

        {/* Счётчики-фильтры групп выдачи */}
        {groups && (
          <div className="flex flex-wrap gap-1.5 mb-3">
            <GroupChip
              active={groupFilter === 'all'}
              onClick={() => setGroupFilter('all')}
              label={`Все — ${visibleList.length}`}
            />
            {(['exact', 'strong', 'adjacent'] as const).map(tier => {
              const count = groups[tier];
              if (typeof count !== 'number') return null;
              return (
                <GroupChip
                  key={tier}
                  active={groupFilter === tier}
                  onClick={() => setGroupFilter(tier)}
                  label={`${tierLabel(tier)} — ${count}`}
                />
              );
            })}
          </div>
        )}

        <JobListArea
          loading={loading}
          jobs={shownList}
          // Wave 11-c: топ-возможности влиты в начало ленты с бейджем «Вам подходит»
          highlightCards={opportunityCards}
          emptyText={searched
            ? 'Попробуйте переформулировать запрос или упростить фильтры.'
            : jobsSubSection === 'hot'
              ? 'Сейчас нет платных/срочных размещений — загляните в общий список.'
              : 'Активных вакансий пока нет — загляните позже.'}
          showNotMine
          onOpen={job => setDetailJob({ jobId: job.id, job })}
          onToggleSave={handleToggleSave}
          onNotMine={setNotMineJob}
          isSaved={id => savedJobs.has(id)}
        />

        {/* Пагинации нет — честная подпись */}
        {!loading && (shownList.length > 0 || opportunityCards.length > 0) && (
          <p className="text-xs text-muted-foreground mt-4 text-center">
            Показаны {shownList.length + opportunityCards.length} {plural(shownList.length + opportunityCards.length)}
          </p>
        )}
      </section>

      {/* === Диалоги === */}
      {detailJob && (
        <JobDetailDialog
          open
          onOpenChange={o => { if (!o) setDetailJob(null); }}
          jobId={detailJob.jobId}
          job={detailJob.job}
          isSaved={detailJob.job ? savedJobs.has(detailJob.job.id) : false}
          onToggleSave={handleToggleSave}
        />
      )}
      {notMineJob && (
        <JobNotMineDialog
          open
          onOpenChange={o => { if (!o) setNotMineJob(null); }}
          jobTitle={notMineJob.title}
          jobId={notMineJob.id}
          onConfirm={handleNotMineConfirm}
        />
      )}
    </div>
  );
}

// ===========================================================================
// Область списка (общая для главного экрана и личных подразделов)
// ===========================================================================
function JobListArea({
  loading, jobs, emptyText, showNotMine, highlightCards, onOpen, onToggleSave, onNotMine, isSaved,
}: {
  loading: boolean;
  jobs: JobWithExtras[];
  emptyText: string;
  showNotMine: boolean;
  /** Wave 11-c: карточки, влитые в начало списка (топ-возможности с бейджем «Вам подходит»). */
  highlightCards?: EmbeddableOpportunityCard[];
  onOpen: (job: JobWithExtras) => void;
  onToggleSave: (job: JobWithExtras) => void;
  onNotMine?: (job: JobWithExtras) => void;
  isSaved: (id: string) => boolean;
}) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
        {Array.from({ length: 6 }).map((_, i) => <JobLightCardSkeleton key={i} />)}
      </div>
    );
  }
  const cards: Array<{ job: JobWithExtras; highlight?: string }> = [
    ...(highlightCards ?? []).map(c => ({ job: c.job, highlight: c.highlight })),
    ...jobs.map(job => ({ job, highlight: undefined })),
  ];
  if (cards.length === 0) {
    return (
      <Card className="p-8 text-center">
        <SearchX className="w-8 h-8 mx-auto mb-2 text-muted-foreground" aria-hidden="true" />
        <p className="text-sm text-muted-foreground">{emptyText}</p>
      </Card>
    );
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 items-start">
      {cards.map(card => (
        <JobLightCard
          key={card.job.id}
          job={card.job}
          highlight={card.highlight}
          isSaved={isSaved(card.job.id)}
          showNotMine={showNotMine}
          onOpen={onOpen}
          onToggleSave={onToggleSave}
          onNotMine={onNotMine}
        />
      ))}
    </div>
  );
}

// ===========================================================================
// «Я правильно вас понял?» — структурированный разбор намерения
// ===========================================================================
function IntentConfirmPanel({ intent, onConfirm, onEdit }: { intent: ParsedIntent; onConfirm: () => void; onEdit: () => void }) {
  const rows: Array<{ label: string; value: string }> = [];
  if (intent.role) rows.push({ label: 'Должность', value: intent.role });
  if (intent.industry) rows.push({ label: 'Отрасль', value: intent.industry });
  if (intent.location) rows.push({ label: 'Локация', value: intent.location });
  if (typeof intent.minSalary === 'number' && intent.minSalary > 0) {
    rows.push({ label: 'Зарплата от', value: `${intent.minSalary.toLocaleString('ru-RU')} ₽` });
  }
  if (intent.workFormat) rows.push({ label: 'Формат', value: WORK_FORMAT_LABELS[intent.workFormat] ?? intent.workFormat });
  if (intent.level) rows.push({ label: 'Уровень', value: intent.level });

  return (
    <Card className="border-lighthouse/40 bg-lighthouse/5">
      <CardContent className="p-4 space-y-3">
        <div className="text-sm font-semibold flex items-center gap-1.5">
          <span aria-hidden="true">🤝</span> Я правильно вас понял?
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
          {rows.map(r => (
            <div key={r.label} className="min-w-0">
              <div className="text-xs uppercase tracking-wide text-muted-foreground">{r.label}</div>
              <div className="text-sm font-medium truncate" title={r.value}>{r.value}</div>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={onConfirm}>Да, искать</Button>
          <Button size="sm" variant="outline" onClick={onEdit}>Изменить</Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ===========================================================================
// Мелочи
// ===========================================================================
function GroupChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'px-3 py-1.5 rounded-full text-xs border transition whitespace-nowrap',
        active ? 'border-transparent text-white font-medium' : 'hover:border-lighthouse/60 hover:text-foreground',
        !active && matchBadgeClass(0),
      )}
      // Активный чип — teal (lighthouse), неактивные — нейтральные
      style={active ? { backgroundColor: 'var(--lighthouse)' } : undefined}
    >
      {label}
    </button>
  );
}

function plural(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'вакансия';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return 'вакансии';
  return 'вакансий';
}
