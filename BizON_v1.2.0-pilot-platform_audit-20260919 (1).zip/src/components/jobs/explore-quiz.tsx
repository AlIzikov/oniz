// BizON — ExploreQuiz (Wave 11, отзыв п.1): опросник «Помогите BizON понять
// вас лучше». 6 вопросов × один выбор → POST /api/me/preferences {exploreQuiz}.
// GET-merge: при маунте читаем сохранённые preferences и отправляем interests/
// goals обратно — не затираем их (бэк кладёт body в JSON скопом).
// Влияние на рекомендации: сохранённые ответы через quizToGoalCodes маппятся
// на дефолтные цели «Исследовать» → JobExplorePanel предзаполняет выбор
// (только если человек не выбирал цели сам).
// Вопросы/white-list — источник правды в jobs-types.ts (EXPLORE_QUIZ_*).
'use client';

import * as React from 'react';
import { Button } from '@/components/ui/button';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { CheckCircle2, ChevronDown, ClipboardList, Loader2 } from 'lucide-react';
import {
  EXPLORE_QUIZ_ALLOWED,
  EXPLORE_QUIZ_QUESTIONS,
  type ExploreQuizAnswers,
} from '@/components/jobs/jobs-types';

interface PrefsShape {
  interests: string[];
  goals: string[];
  exploreQuiz: ExploreQuizAnswers;
}

// Кэш GET /api/me/preferences на уровне модуля: панель «Исследовать»
// монтируется заново при каждом входе в режим — не дёргаем API лишний раз.
let prefsCache: PrefsShape | null = null;

function normalizePrefs(data: unknown): PrefsShape {
  const src = (typeof data === 'object' && data !== null ? data : {}) as Record<string, unknown>;
  const interests = Array.isArray(src.interests)
    ? src.interests.filter((x): x is string => typeof x === 'string')
    : [];
  const goals = Array.isArray(src.goals)
    ? src.goals.filter((x): x is string => typeof x === 'string')
    : [];
  const quizRaw = src.exploreQuiz;
  const exploreQuiz: ExploreQuizAnswers = {};
  if (typeof quizRaw === 'object' && quizRaw !== null && !Array.isArray(quizRaw)) {
    for (const [k, v] of Object.entries(quizRaw as Record<string, unknown>)) {
      if (typeof v === 'string' && EXPLORE_QUIZ_ALLOWED[k]?.includes(v)) exploreQuiz[k] = v;
    }
  }
  return { interests, goals, exploreQuiz };
}

/** Только валидные (по white-list) пары вопрос→ответ. */
function pickKnownQuiz(quiz: ExploreQuizAnswers): ExploreQuizAnswers {
  const known: ExploreQuizAnswers = {};
  for (const [k, v] of Object.entries(quiz)) {
    if (EXPLORE_QUIZ_ALLOWED[k]?.includes(v)) known[k] = v;
  }
  return known;
}

export interface ExploreQuizProps {
  /** Сохранённые ответы готовы (маунт) или обновлены (save) — родитель маппит на цели. */
  onQuizImpact: (answers: ExploreQuizAnswers, source: 'mount' | 'save') => void;
}

export function ExploreQuiz({ onQuizImpact }: ExploreQuizProps) {
  const [loading, setLoading] = React.useState<boolean>(!prefsCache);
  const [answers, setAnswers] = React.useState<ExploreQuizAnswers>({});
  const [hasQuiz, setHasQuiz] = React.useState<boolean>(false);
  const [expanded, setExpanded] = React.useState<boolean>(false);
  const [saving, setSaving] = React.useState<boolean>(false);

  const onQuizImpactRef = React.useRef(onQuizImpact);
  React.useEffect(() => {
    onQuizImpactRef.current = onQuizImpact;
  }, [onQuizImpact]);

  React.useEffect(() => {
    let alive = true;
    async function load() {
      if (prefsCache) {
        hydrate(prefsCache);
        return;
      }
      setLoading(true);
      try {
        const res = await fetch('/api/me/preferences');
        if (!res.ok) return; // не авторизован/ошибка — опросник работает локально, без ложных статусов
        const prefs = normalizePrefs(await res.json());
        prefsCache = prefs;
        if (alive) hydrate(prefs);
      } catch {
        // сеть/сервер недоступны — остаёмся в локальном состоянии без обмана
      } finally {
        if (alive) setLoading(false);
      }
    }
    function hydrate(prefs: PrefsShape) {
      const known = pickKnownQuiz(prefs.exploreQuiz);
      setAnswers(known);
      const completed = Object.keys(known).length > 0;
      setHasQuiz(completed);
      // Влияние на рекомендации: сохранённые ответы → родитель (маунт-источник)
      if (completed) onQuizImpactRef.current(known, 'mount');
    }
    load();
    return () => {
      alive = false;
    };
  }, []);

  async function save() {
    setSaving(true);
    try {
      // GET-merge: если GET при маунте не дошёл — пробуем ещё раз перед POST,
      // чтобы не затереть interests/goals пустыми массивами.
      let current = prefsCache;
      if (!current) {
        try {
          const res = await fetch('/api/me/preferences');
          if (res.ok) {
            current = normalizePrefs(await res.json());
            prefsCache = current;
          }
        } catch {
          // продолжаем с пустыми interests/goals — бэк сохранит опросник
        }
      }
      const res = await fetch('/api/me/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          interests: current?.interests ?? [],
          goals: current?.goals ?? [],
          exploreQuiz: answers,
        }),
      });
      const data: unknown = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg =
          typeof data === 'object' && data !== null && typeof (data as Record<string, unknown>).error === 'string'
            ? ((data as Record<string, string>).error as string)
            : 'Не удалось сохранить настройки';
        throw new Error(msg);
      }
      const saved = normalizePrefs(data);
      prefsCache = saved;
      const known = pickKnownQuiz(saved.exploreQuiz);
      setAnswers(known);
      setHasQuiz(Object.keys(known).length > 0);
      setExpanded(false);
      toast({ title: 'Настройки рекомендаций обновлены' });
      // Сразу влияяем на подбор: родитель предзаполнит цели (если человек не выбирал сам)
      onQuizImpactRef.current(known, 'save');
    } catch (e) {
      toast({
        title: 'Не удалось сохранить настройки',
        description: e instanceof Error ? e.message : 'Попробуйте ещё раз',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  }

  const answeredCount = Object.keys(answers).length;

  return (
    <Collapsible
      open={expanded}
      onOpenChange={setExpanded}
      className="rounded-xl border bg-muted/20"
      aria-label="Опросник: помогите BizON понять вас лучше"
    >
      {/* Сводка (свёрнутое состояние) + триггер */}
      <div className="flex items-start justify-between gap-3 p-3">
        <div className="flex items-start gap-2 min-w-0">
          <ClipboardList className="w-4 h-4 text-lighthouse mt-0.5 shrink-0" aria-hidden="true" />
          <div className="min-w-0">
            <div className="text-sm font-semibold leading-tight">Помогите BizON понять вас лучше</div>
            {loading ? (
              <Skeleton className="h-3.5 w-56 max-w-full mt-1" />
            ) : hasQuiz ? (
              <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-lighthouse shrink-0" aria-hidden="true" />
                Опросник пройден — рекомендации учитывают ваши ответы
              </p>
            ) : (
              <p className="text-xs text-muted-foreground mt-0.5">
                Пройдите короткий опросник (6 вопросов) — и BizON точнее подберёт вакансии, проекты и возможности
              </p>
            )}
          </div>
        </div>
        <CollapsibleTrigger asChild>
          <Button variant="outline" size="sm" className="h-8 shrink-0">
            {hasQuiz ? 'Изменить' : 'Пройти опросник'}
            <ChevronDown
              className={cn('w-3.5 h-3.5 ml-1 transition-transform', expanded && 'rotate-180')}
              aria-hidden="true"
            />
          </Button>
        </CollapsibleTrigger>
      </div>

      {/* Вопросы */}
      <CollapsibleContent className="overflow-hidden data-[state=closed]:hidden">
        <div className="px-3 pb-3 space-y-3 border-t pt-3">
          {EXPLORE_QUIZ_QUESTIONS.map(q => (
            <div key={q.key} role="radiogroup" aria-label={q.question}>
              <div className="text-xs font-medium mb-1.5">{q.question}</div>
              <div className="flex flex-wrap gap-1.5">
                {q.options.map(o => {
                  const active = answers[q.key] === o.value;
                  return (
                    <button
                      key={o.value}
                      type="button"
                      role="radio"
                      aria-checked={active}
                      onClick={() => setAnswers(prev => ({ ...prev, [q.key]: o.value }))}
                      className={cn(
                        'px-2.5 py-1 rounded-md border text-xs transition',
                        active
                          ? 'border-lighthouse bg-lighthouse/10 text-lighthouse font-medium ring-1 ring-lighthouse/30'
                          : 'bg-background text-muted-foreground hover:border-lighthouse/40 hover:bg-accent/50',
                      )}
                    >
                      {o.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
            <p className="text-xs text-muted-foreground">
              {answeredCount > 0
                ? `Отмечено ${answeredCount} из 6 — можно отвечать не на все. Ответы влияют на подбор вакансий, проектов и возможностей.`
                : 'Ответы влияют на подбор вакансий, проектов и возможностей.'}
            </p>
            <Button size="sm" className="h-8 shrink-0" onClick={save} disabled={saving || loading}>
              {saving && <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" aria-hidden="true" />}
              Сохранить настройки
            </Button>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
