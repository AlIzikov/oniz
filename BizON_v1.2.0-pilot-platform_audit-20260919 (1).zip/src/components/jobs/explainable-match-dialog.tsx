// BizON — Explainable Match Modal (P0-5, ЧАСТЬ 7/11)
// Модалка с breakdown совпадения вакансии:
//   • 2 крупных ring'а: Candidate Fit / Company Fit (двусторонний BIZON MATCH)
//   • 3 прогресс-бара: Skills / Trust / Growth
//   • Список matched / missing skills
//   • Человекочитаемое «Почему вы подходите»
//   • 2 колонки: Что вы получите / Что компания получит
//
// Источник: GET /api/jobs/[id]/match-explain
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles, ShieldCheck, TrendingUp, Check, X,
  ArrowRight, Heart, Building2,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// === Тип ответа /api/jobs/[id]/match-explain ===
interface MatchExplainResponse {
  candidateFit: number;
  companyFit: number | null; // W1.2: null = нет Cultural Signals (не 88)
  totalMatch: number;
  breakdown: {
    skills: { score: number; matched: string[]; missing: string[] };
    trust: { score: number; reason: string };
    growth: { score: number; reason: string };
  };
  why: string;
  whatYouGet: string[];
  whatCompanyGets: string[];
  context?: {
    jobId: string;
    jobTitle: string;
    company: string;
    companyId: string | null;
    culturalFitScore: number | null;
    companyFitAvailable: boolean; // v6.1/W1.2: контракт реального API (был несуществующий isStub)
    commonContactsCount: number;
    verifiedProjectsCount: number;
    similarProjectsCount: number;
  };
}

interface ExplainableMatchDialogProps {
  jobId: string;
  jobTitle: string;
  company: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ExplainableMatchDialog({
  jobId, jobTitle, company, open, onOpenChange,
}: ExplainableMatchDialogProps) {
  const [data, setData] = React.useState<MatchExplainResponse | null>(null);
  const [loading, setLoading] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!jobId) return;
    setLoading(true);
    setData(null);
    try {
      const res = await api<MatchExplainResponse>(`/api/jobs/${jobId}/match-explain`);
      setData(res);
    } catch (e: any) {
      toast({
        title: 'Не удалось загрузить объяснение',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [jobId]);

  React.useEffect(() => {
    if (open && jobId) load();
  }, [open, jobId, load]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="w-5 h-5 text-lighthouse" />
            Почему вы подходите
          </DialogTitle>
          <DialogDescription className="text-sm">
            {jobTitle} · {company}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <ExplainLoading />
        ) : data ? (
          <ExplainContent data={data} />
        ) : (
          <div className="py-8 text-center text-sm text-muted-foreground">
            Не удалось загрузить данные.{' '}
            <Button variant="ghost" size="sm" onClick={load}>
              Повторить
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ===========================================================================
// Loading skeleton
// ===========================================================================
function ExplainLoading() {
  return (
    <div className="space-y-4 py-2">
      <div className="grid grid-cols-2 gap-3">
        <Skeleton className="h-24 rounded-lg" />
        <Skeleton className="h-24 rounded-lg" />
      </div>
      <Skeleton className="h-4 w-2/3" />
      <div className="space-y-3">
        <Skeleton className="h-12 w-full rounded-md" />
        <Skeleton className="h-12 w-full rounded-md" />
        <Skeleton className="h-12 w-full rounded-md" />
      </div>
      <Skeleton className="h-20 w-full rounded-md" />
    </div>
  );
}

// ===========================================================================
// Content
// ===========================================================================
function ExplainContent({ data }: { data: MatchExplainResponse }) {
  return (
    <div className="space-y-5">
      {/* === 1. Двусторонний BIZON MATCH: Candidate Fit ↔ Company Fit === */}
      <div className="grid grid-cols-2 gap-3">
        <FitRing
          label="Candidate Fit"
          value={data.candidateFit}
          hint="Соответствие кандидата вакансии"
          color="emerald"
        />
        <FitRing
          label="Company Fit"
          value={data.companyFit}
          hint={
            data.companyFit === null
              ? 'Нет данных о культурном соответствии компании'
              : 'Двустороннее соответствие'
          }
          color="lighthouse"
        />
      </div>

      {/* Total match banner */}
      <div className="rounded-lg border bg-muted/40 p-3 flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
            Total Match
          </div>
          <div className="text-2xl font-bold tabular-nums">
            {data.totalMatch}%
          </div>
        </div>
        <div className="text-xs text-muted-foreground text-right max-w-[60%]">
          Среднее арифметическое Candidate Fit и Company Fit
        </div>
      </div>

      {/* === 2. 3 прогресс-бара: Skills / Trust / Growth === */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground font-semibold">
          <span className="w-1 h-3 rounded-full bg-emerald-600" aria-hidden="true" />
          Breakdown
        </div>

        <BreakdownBar
          label="Skills"
          score={data.breakdown.skills.score}
          icon={<ShieldCheck className="w-3.5 h-3.5" />}
        />
        <BreakdownBar
          label="Trust"
          score={data.breakdown.trust.score}
          icon={<ShieldCheck className="w-3.5 h-3.5" />}
          reason={data.breakdown.trust.reason}
        />
        <BreakdownBar
          label="Growth"
          score={data.breakdown.growth.score}
          icon={<TrendingUp className="w-3.5 h-3.5" />}
          reason={data.breakdown.growth.reason}
        />
      </div>

      {/* === 3. Matched / Missing skills === */}
      {(data.breakdown.skills.matched.length > 0 || data.breakdown.skills.missing.length > 0) && (
        <div className="space-y-2">
          <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
            Навыки
          </div>
          {data.breakdown.skills.matched.length > 0 && (
            <div className="flex items-start gap-2 flex-wrap">
              <span className="text-xs text-emerald-700 dark:text-emerald-400 font-medium pt-0.5">
                Есть у вас:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {data.breakdown.skills.matched.map((s) => (
                  <Badge key={s} className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1">
                    <Check className="w-3 h-3" />
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          {data.breakdown.skills.missing.length > 0 && (
            <div className="flex items-start gap-2 flex-wrap">
              <span className="text-xs text-muted-foreground pt-0.5">
                Требуются:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {data.breakdown.skills.missing.map((s) => (
                  <Badge key={s} variant="outline" className="gap-1 text-muted-foreground">
                    <X className="w-3 h-3" />
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* === 4. WHY — человекочитаемое объяснение === */}
      <div className="rounded-lg bg-lighthouse/5 border border-lighthouse/20 p-3">
        <div className="flex items-center gap-2 mb-1 text-xs uppercase tracking-wider text-lighthouse font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          Почему вы подходите
        </div>
        <p className="text-sm text-foreground leading-relaxed">
          {data.why}
        </p>
      </div>

      {/* === 5. Что вы получите / Что компания получит === */}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="rounded-lg border p-3 space-y-2">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-emerald-700 dark:text-emerald-400 font-semibold">
            <Heart className="w-3.5 h-3.5" />
            Что вы получите
          </div>
          <ul className="space-y-1">
            {data.whatYouGet.map((item, i) => (
              <li key={i} className="text-xs text-foreground flex items-start gap-1.5">
                <ArrowRight className="w-3 h-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-lg border p-3 space-y-2">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-lighthouse font-semibold">
            <Building2 className="w-3.5 h-3.5" />
            Что компания получит
          </div>
          <ul className="space-y-1">
            {data.whatCompanyGets.map((item, i) => (
              <li key={i} className="text-xs text-foreground flex items-start gap-1.5">
                <ArrowRight className="w-3 h-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* === W1.2: честный баннер отсутствия данных (вместо «заглушка 88%») === */}
      {data.companyFit === null && (
        <div className="text-xs text-muted-foreground text-center pt-2 border-t">
          Company Fit недоступен: у компании пока нет Cultural Signals (отзывы
          сотрудников). Оценка не придумывается — сводные проценты используют
          только Candidate Fit.
        </div>
      )}
    </div>
  );
}

// ===========================================================================
// FitRing — крупный ring с процентом (Candidate Fit / Company Fit)
// ===========================================================================
function FitRing({
  label, value, hint, color,
}: {
  label: string;
  value: number | null; // W1.2: null = данных нет → «—», а не 0%
  hint: string;
  color: 'emerald' | 'lighthouse';
}) {
  const v = value === null ? 0 : Math.max(0, Math.min(100, value));
  // SVG ring
  const r = 28;
  const c = 2 * Math.PI * r;
  const offset = c - (v / 100) * c;
  const ringColor = value === null
    ? 'stroke-muted-foreground/30'
    : color === 'emerald'
      ? 'stroke-emerald-600 dark:stroke-emerald-400'
      : 'stroke-lighthouse';
  const textColor = value === null
    ? 'text-muted-foreground'
    : color === 'emerald'
      ? 'text-emerald-700 dark:text-emerald-400'
      : 'text-lighthouse';

  return (
    <div className="rounded-lg border bg-card p-3 flex items-center gap-3">
      <div className="relative w-16 h-16 flex-shrink-0">
        <svg className="w-16 h-16 -rotate-90" viewBox="0 0 64 64" aria-hidden="true">
          <circle
            cx="32" cy="32" r={r}
            className="stroke-muted"
            strokeWidth="6" fill="none"
          />
          <circle
            cx="32" cy="32" r={r}
            className={cn('transition-all duration-700', ringColor)}
            strokeWidth="6" fill="none"
            strokeDasharray={c}
            strokeDashoffset={offset}
            strokeLinecap="round"
          />
        </svg>
        <div className={cn('absolute inset-0 flex items-center justify-center font-bold tabular-nums text-sm', textColor)}>
          {value === null ? '—' : `${v}%`}
        </div>
      </div>
      <div className="min-w-0">
        <div className={cn('text-sm font-semibold', textColor)}>{label}</div>
        <div className="text-xs text-muted-foreground leading-snug">{hint}</div>
      </div>
    </div>
  );
}

// ===========================================================================
// BreakdownBar — один прогресс-бар с меткой и опциональной причиной
// ===========================================================================
function BreakdownBar({
  label, score, icon, reason,
}: {
  label: string;
  score: number;
  icon: React.ReactNode;
  reason?: string;
}) {
  const v = Math.max(0, Math.min(100, score));
  const colorClass = v >= 70
    ? 'bg-emerald-600'
    : v >= 40 ? 'bg-amber-500' : 'bg-muted-foreground/60';
  const textClass = v >= 70
    ? 'text-emerald-700 dark:text-emerald-400'
    : v >= 40 ? 'text-amber-700 dark:text-amber-400' : 'text-muted-foreground';

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 font-medium">
          <span className="text-muted-foreground">{icon}</span>
          {label}
        </span>
        <span className={cn('font-bold tabular-nums', textClass)}>{v}%</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div
          className={cn('h-full rounded-full transition-all duration-500', colorClass)}
          style={{ width: `${v}%` }}
        />
      </div>
      {reason && (
        <div className="text-xs text-muted-foreground pt-0.5">{reason}</div>
      )}
    </div>
  );
}
