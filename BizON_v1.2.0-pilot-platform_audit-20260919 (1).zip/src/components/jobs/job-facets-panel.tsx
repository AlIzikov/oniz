// BizON — Wave 5 «Поиск работы»: фасет-панель с агрегациями (ТЗ 4.3 API-01),
// Radar-слой (§71: 3/7/30/90 дней) и подписки автопоиска (SEARCH_PREF).
//
// §3.3: счётчики фильтров — фактические числа вакансий (это не числа доверия);
// RMI/скор не публикуются — только окна и объяснения.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
  Radar, Filter, BellPlus, BellRing, BellOff, Trash2, Loader2, CalendarDays,
} from 'lucide-react';

// ---------- типы ----------

interface Aggregation {
  value: string;
  count: number;
}
interface FacetsResponse {
  jobs: Array<Record<string, unknown>>;
  total: number;
  aggregations: Record<string, Aggregation[]>;
}
interface RadarWindowDto {
  horizon: string;
  days: number;
  expectedOpportunities: number;
  explanation: string;
  topTypes: Array<{ type: string; count: number }>;
}
interface RadarResponse {
  windows: RadarWindowDto[];
  leadTimeDays: number | null;
  dataSufficient: boolean;
  basisDays: number;
}
interface SearchPrefDto {
  id: string;
  kind: string;
  query: string | null;
  skills: string[];
  regions: string[];
  filters: Record<string, unknown>;
  isActive: boolean;
}
interface ViewCalendarDay {
  day: string;
  count: number;
  jobIds: string[];
}

const EMPLOYMENT_LABELS: Record<string, string> = {
  full_time: 'Полная занятость', part_time: 'Частичная', contract: 'Контракт',
  internship: 'Стажировка', temporary: 'Временная', seasonal: 'Сезонная',
};
const SCHEDULE_LABELS: Record<string, string> = {
  full_day: 'Полный день', shift: 'Сменный', flexible: 'Гибкий', remote_only: 'Только удалённо', rotation: 'Вахта',
};
const LEVEL_LABELS: Record<string, string> = {
  Junior: 'Джун', Middle: 'Мидл', Senior: 'Сеньор', Lead: 'Лид', Director: 'Директор',
};
const FORMAT_LABELS: Record<string, string> = {
  remote: 'Удалённо', hybrid: 'Гибрид', onsite: 'В офисе',
};

// ---------- основной компонент ----------

export function JobFacetsPanel({ onApplyFilters }: { onApplyFilters?: (params: Record<string, string>) => void }) {
  const jobsFilterApply = useAppStore((s) => (s as unknown as { jobsFilterApply: { params: Record<string, string> } | null }).jobsFilterApply);

  const [filters, setFilters] = React.useState<Record<string, string>>({});
  const [facets, setFacets] = React.useState<FacetsResponse | null>(null);
  const [radar, setRadar] = React.useState<RadarResponse | null>(null);
  const [prefs, setPrefs] = React.useState<SearchPrefDto[]>([]);
  const [calendar, setCalendar] = React.useState<ViewCalendarDay[]>([]);
  const [loading, setLoading] = React.useState(true);

  const loadFacets = React.useCallback(async (f: Record<string, string>) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(f)) if (v) sp.set(k, v);
    try {
      const res = await api<FacetsResponse>(`/api/jobs/facets?${sp.toString()}`);
      setFacets(res);
    } catch {
      // панель фасетов — не критичный путь: тихо держим прошлые данные
    }
  }, []);

  const loadAux = React.useCallback(async () => {
    const jobs: Array<Promise<void>> = [
      api<RadarResponse>('/api/opportunities/radar').then(setRadar).catch(() => undefined),
      api<{ prefs: SearchPrefDto[] }>('/api/search-prefs').then((d) => setPrefs(d.prefs)).catch(() => undefined),
      api<{ calendar: ViewCalendarDay[] }>('/api/jobs/view-log/calendar').then((d) => setCalendar(d.calendar)).catch(() => undefined),
    ];
    await Promise.all(jobs);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    loadFacets(filters);
    loadAux();
  }, []);

  React.useEffect(() => {
    loadFacets(filters);
  }, [filters, loadFacets]);

  function setFilter(key: string, value: string) {
    setFilters((prev) => {
      const next = { ...prev };
      if (next[key] === value || value === '') delete next[key];
      else next[key] = value;
      return next;
    });
  }

  function applyToSearch() {
    // фильтры уходят в основной поиск через штатный сигнал
    onApplyFilters?.(filters);
    const setSignal = useAppStore.getState() as unknown as { applyJobsFilter: (p: Record<string, string>) => void };
    setSignal.applyJobsFilter?.(filters);
  }

  const agg = (key: string) => facets?.aggregations[key] ?? [];

  if (loading && !facets) return <Skeleton className="h-64 w-full rounded-xl" />;

  return (
    <div className="space-y-4">
      {/* Radar-слой §71 */}
      <RadarBlock radar={radar} />

      {/* Фильтры 10 секций с агрегациями (ТЗ 4.3 API-01) */}
      <div className="rounded-lg border p-3 space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
            <Filter className="w-3 h-3" /> Фильтры
            {facets && <Badge variant="secondary" className="ml-1">{facets.total} вакансий</Badge>}
          </div>
          <Button size="sm" variant="outline" onClick={applyToSearch}>Применить к поиску</Button>
        </div>

        <FacetRow label="Занятость" options={agg('employmentType')} labels={EMPLOYMENT_LABELS}
          active={filters.employmentType} onPick={(v) => setFilter('employmentType', v)} />
        <FacetRow label="График" options={agg('schedule')} labels={SCHEDULE_LABELS}
          active={filters.schedule} onPick={(v) => setFilter('schedule', v)} />
        <FacetRow label="Уровень" options={agg('level')} labels={LEVEL_LABELS}
          active={filters.level} onPick={(v) => setFilter('level', v)} />
        <FacetRow label="Формат" options={agg('workFormat')} labels={FORMAT_LABELS}
          active={filters.workFormat} onPick={(v) => setFilter('workFormat', v)} />
        <FacetRow label="Индустрия" options={agg('industry')} labels={{}}
          active={filters.industry} onPick={(v) => setFilter('industry', v)} />

        <div className="flex items-center gap-2">
          <Input placeholder="Мин. зарплата" inputMode="numeric" className="h-8 w-36"
            value={filters.salaryMin ?? ''}
            onChange={(e) => setFilters((p) => ({ ...p, salaryMin: e.target.value.replace(/\D/g, '') }))} />
          <Button size="sm" variant={filters.verifiedOnly === '1' ? 'default' : 'outline'}
            onClick={() => setFilter('verifiedOnly', '1')}>
            Только проверенные работодатели
          </Button>
        </div>
      </div>

      {/* SEARCH_PREF — автопоиск */}
      <SearchPrefsBlock prefs={prefs} filters={filters} onChanged={loadAux} />

      {/* VIEW_LOG — календарь просмотров */}
      <ViewCalendarBlock calendar={calendar} />
    </div>
  );
}

// ---------- Radar ----------

function RadarBlock({ radar }: { radar: RadarResponse | null }) {
  if (!radar) return null;
  if (!radar.dataSufficient) {
    return (
      <div className="rounded-lg border p-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-1 font-semibold text-foreground mb-1">
          <Radar className="w-3.5 h-3.5 text-lighthouse" /> Opportunity Radar
        </div>
        Данных мало ({radar.basisDays} дн. истории) — прогноз появится после набора статистики. Честно ждём данные, не имитируем.
      </div>
    );
  }
  return (
    <div className="rounded-lg border p-3 space-y-2">
      <div className="flex items-center gap-1 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
        <Radar className="w-3.5 h-3.5 text-lighthouse" /> Opportunity Radar
        {radar.leadTimeDays != null && (
          <Badge variant="secondary" className="ml-1 text-xs">Lead Time: {radar.leadTimeDays} дн.</Badge>
        )}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {radar.windows.map((w) => (
          <div key={w.horizon} className="p-2 rounded-lg bg-muted/50">
            <div className="text-lg font-bold">{w.expectedOpportunities}</div>
            <div className="text-xs text-muted-foreground">за {w.days} дн.</div>
          </div>
        ))}
      </div>
      <p className="text-xs text-muted-foreground">{radar.windows[1]?.explanation ?? radar.windows[0]?.explanation}</p>
      {radar.windows[0]?.topTypes?.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {radar.windows[0].topTypes.map((t) => (
            <Badge key={t.type} variant="outline" className="text-xs">
              {t.type === 'job' ? 'вакансии' : t.type === 'gig' ? 'разовые задачи' : t.type === 'event' ? 'события' : t.type}: {t.count}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------- фасет-строка ----------

function FacetRow({ label, options, labels, active, onPick }: {
  label: string;
  options: Aggregation[];
  labels: Record<string, string>;
  active?: string;
  onPick: (value: string) => void;
}) {
  if (options.length === 0) return null;
  return (
    <div className="flex flex-wrap items-center gap-1">
      <span className="text-xs font-medium text-muted-foreground w-20 shrink-0">{label}</span>
      {options.slice(0, 6).map((o) => (
        <button key={o.value}
          onClick={() => onPick(o.value)}
          className={cn('px-2 py-0.5 rounded-full text-xs border transition',
            active === o.value ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-accent')}>
          {labels[o.value] ?? o.value} <span className="opacity-70">{o.count}</span>
        </button>
      ))}
    </div>
  );
}

// ---------- SEARCH_PREF ----------

function SearchPrefsBlock({ prefs, filters, onChanged }: {
  prefs: SearchPrefDto[]; filters: Record<string, string>; onChanged: () => void;
}) {
  const [name, setName] = React.useState('');
  const [saving, setSaving] = React.useState(false);

  async function create() {
    setSaving(true);
    try {
      await api('/api/search-prefs', {
        method: 'POST',
        body: JSON.stringify({
          kind: 'seeker',
          query: name.trim() || null,
          filters,
          isActive: true,
        }),
      });
      toast({ title: 'Автопоиск сохранён — лента будет подстраиваться' });
      setName('');
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось сохранить', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  async function toggle(pref: SearchPrefDto) {
    try {
      await api(`/api/search-prefs/${pref.id}`, { method: 'PATCH', body: JSON.stringify({ isActive: !pref.isActive }) });
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось переключить', variant: 'destructive' });
    }
  }

  async function remove(pref: SearchPrefDto) {
    try {
      await api(`/api/search-prefs/${pref.id}`, { method: 'DELETE' });
      onChanged();
    } catch (e: unknown) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : 'Не удалось удалить', variant: 'destructive' });
    }
  }

  return (
    <div className="rounded-lg border p-3 space-y-2">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Автопоиск (SEARCH_PREF)</div>
      {prefs.length > 0 && (
        <div className="space-y-1.5">
          {prefs.map((p) => (
            <div key={p.id} className="flex items-center gap-2 text-sm">
              {p.isActive ? <BellRing className="w-4 h-4 text-lighthouse shrink-0" /> : <BellOff className="w-4 h-4 text-muted-foreground shrink-0" />}
              <span className="flex-1 truncate">{p.query ?? 'Без запроса'}{p.skills.length > 0 ? ` · ${p.skills.slice(0, 3).join(', ')}` : ''}</span>
              <Button size="sm" variant="ghost" onClick={() => toggle(p)} aria-label={p.isActive ? 'Выключить' : 'Включить'}>
                {p.isActive ? 'Пауза' : 'Включить'}
              </Button>
              <Button size="sm" variant="ghost" onClick={() => remove(p)} aria-label="Удалить">
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <Input placeholder="Название подписки (например, «Backend, удалённо»)" value={name}
          onChange={(e) => setName(e.target.value)} className="h-8" />
        <Button size="sm" variant="outline" onClick={create} disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <BellPlus className="w-4 h-4 mr-1" />} Сохранить текущие фильтры
        </Button>
      </div>
    </div>
  );
}

// ---------- VIEW_LOG календарь ----------

function ViewCalendarBlock({ calendar }: { calendar: ViewCalendarDay[] }) {
  if (calendar.length === 0) return null;
  const maxCount = Math.max(...calendar.map((d) => d.count), 1);
  return (
    <div className="rounded-lg border p-3 space-y-2">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
        <CalendarDays className="w-3.5 h-3.5" /> Календарь просмотров (30 дн.)
      </div>
      <div className="flex gap-1 flex-wrap">
        {calendar.slice(0, 31).map((d) => (
          <div key={d.day}
            title={`${d.day}: ${d.count} просмотров`}
            className={cn('rounded px-1.5 py-0.5 text-xs border',
              d.count === maxCount ? 'bg-primary/10 border-primary/40 font-semibold' : 'bg-muted/40')}>
            {d.day.slice(8)}·{d.count}
          </div>
        ))}
      </div>
    </div>
  );
}
