// BizON — JobLightCard (Task 7-b, «BIZON NEXT» п.9 — лёгкая карточка вакансии)
// Стратегия: title / company · location / зарплата (teal) / match% /
// строка «Почему» (2-3 короткие причины) / действия [Подробнее] [Сохранить] [Не моё].
// Бейджи: verificationStatus / hiringReality / matchTier — только если пришли в данных.
'use client';

import * as React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { VerifiedVacancyBadge } from '@/components/jobs/verified-vacancy-badge';
import {
  MapPin, Bookmark, Check, X, Activity, ChevronRight, Sparkles,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  formatSalaryText, matchBadgeClass, reasonsToList, tierLabel,
  type JobWithExtras,
} from '@/components/jobs/jobs-types';

interface JobLightCardProps {
  job: JobWithExtras;
  isSaved?: boolean;
  /** Скрывать «Не моё» (например, в «Сохранённых» и «Моих откликах») */
  showNotMine?: boolean;
  /** Wave 11-c: бейдж-метка поверх карточки (напр. «Вам подходит» — карточка влита из Opportunity Engine). */
  highlight?: string;
  onOpen: (job: JobWithExtras) => void;
  onToggleSave: (job: JobWithExtras) => void;
  onNotMine?: (job: JobWithExtras) => void;
}

export function JobLightCard({ job, isSaved, showNotMine = true, highlight, onOpen, onToggleSave, onNotMine }: JobLightCardProps) {
  const matchPercent = Math.round((job.matchConfidence ?? 0) * 100);
  const salary = formatSalaryText(job);
  const reasons = reasonsToList({ explanation: undefined, reasons: job.explanation?.reasons });
  const missing = job.explanation?.missing ?? [];
  const isVerified = job.verificationStatus === 'verified';

  return (
    <Card className="group hover:shadow-md transition-shadow overflow-hidden">
      <CardContent className="p-4 flex flex-col gap-2.5">
        {/* Wave 11-c: бейдж-метка «почему карточка наверху» (напр. «Вам подходит») */}
        {highlight && (
          <Badge
            variant="outline"
            className="self-start text-xs px-1.5 py-0 h-4 gap-1 font-medium bg-lighthouse/10 text-lighthouse border-lighthouse/30"
          >
            <Sparkles className="w-2.5 h-2.5" aria-hidden="true" />
            {highlight}
          </Badge>
        )}
        {/* Row 1: title + match% */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <button
              onClick={() => onOpen(job)}
              className="text-left font-semibold text-[15px] leading-snug hover:text-lighthouse transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
              aria-label={`Открыть вакансию ${job.title}`}
            >
              {job.title}
            </button>
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground mt-0.5 min-w-0">
              <span className="font-medium text-foreground/80 truncate">{job.company}</span>
              {job.location && (
                <span className="flex items-center gap-0.5 truncate">
                  · <MapPin className="w-3 h-3 flex-shrink-0" aria-hidden="true" /> {job.location}
                </span>
              )}
            </div>
          </div>
          <div
            className={cn('flex-shrink-0 px-2 py-1 rounded-md border text-xs font-bold tabular-nums', matchBadgeClass(matchPercent))}
            title="Персональное совпадение с вакансией"
          >
            {matchPercent}%
          </div>
        </div>

        {/* Row 2: зарплата (teal по «Маяку») + бейджи */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          {salary && <span className="font-semibold text-lighthouse tabular-nums">{salary}</span>}
          {job.matchTier && (
            <Badge variant="outline" className="text-xs px-1.5 py-0 h-4 font-normal">
              {tierLabel(job.matchTier as 'exact' | 'strong' | 'adjacent')}
            </Badge>
          )}
          {job.verificationStatus && (
            <VerifiedVacancyBadge
              jobId={job.id}
              initialStatus={job.verificationStatus}
              initialScore={job.vacancyTrust}
              compact
            />
          )}
          {job.hiringReality && (
            <Badge
              variant="outline"
              className={cn(
                'text-xs px-1.5 py-0 h-4 gap-0.5 font-normal',
                job.hiringReality.level === 'high'
                  ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30',
              )}
              title="Hiring Reality — что происходит в найме на самом деле"
            >
              <Activity className="w-2.5 h-2.5" aria-hidden="true" />
              {job.hiringReality.score ? `HR ${job.hiringReality.score}/100` : 'Hiring Reality'}
            </Badge>
          )}
        </div>

        {/* Row 3: «Почему» — 2-3 короткие причины */}
        {(reasons.length > 0 || missing.length > 0) && (
          <div className="text-xs space-y-0.5">
            {reasons.slice(0, 2).map((r, i) => (
              <div key={i} className="flex items-start gap-1 text-muted-foreground">
                <Check className="w-3 h-3 mt-0.5 text-emerald-600 flex-shrink-0" aria-hidden="true" />
                <span className="line-clamp-1">{r}</span>
              </div>
            ))}
            {missing.slice(0, 1).map((m, i) => (
              <div key={i} className="flex items-start gap-1 text-muted-foreground">
                <X className="w-3 h-3 mt-0.5 text-amber-600 flex-shrink-0" aria-hidden="true" />
                <span className="line-clamp-1">{m}</span>
              </div>
            ))}
          </div>
        )}

        {/* Row 4: действия */}
        <div className="flex items-center gap-1.5 pt-0.5">
          <Button
            size="sm"
            variant="outline"
            className="h-7 text-xs gap-1 flex-1 sm:flex-none"
            onClick={() => onOpen(job)}
          >
            Подробнее
            <ChevronRight className="w-3 h-3" aria-hidden="true" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className={cn('h-7 w-7 p-0', isSaved && 'text-lighthouse bg-lighthouse/10 hover:bg-lighthouse/20')}
            onClick={() => onToggleSave(job)}
            aria-label={isSaved ? 'Убрать из сохранённых' : 'Сохранить вакансию'}
            title={isSaved ? 'Убрать из сохранённых' : 'Сохранить'}
          >
            <Bookmark className={cn('w-3.5 h-3.5', isSaved && 'fill-current')} aria-hidden="true" />
          </Button>
          {showNotMine && onNotMine && (
            <Button
              size="sm"
              variant="ghost"
              className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              onClick={() => onNotMine(job)}
              aria-label="Не моё — скрыть вакансию и похожие"
              title="Не моё"
            >
              <X className="w-3.5 h-3.5" aria-hidden="true" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

/** Плейсхолдер-скелет карточки для состояний загрузки сетки. */
export function JobLightCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4 flex flex-col gap-2.5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 space-y-1.5">
            <div className="h-4 w-3/4 rounded bg-muted animate-pulse" />
            <div className="h-3 w-1/2 rounded bg-muted animate-pulse" />
          </div>
          <div className="h-7 w-12 rounded-md bg-muted animate-pulse" />
        </div>
        <div className="h-3 w-1/3 rounded bg-muted animate-pulse" />
        <div className="h-7 w-full rounded bg-muted animate-pulse" />
      </CardContent>
    </Card>
  );
}