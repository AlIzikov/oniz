// BizON — JobPreciseFilters (Task 7-b, «BIZON NEXT» п.3 — режим «Точно»)
// Панель точных фильтров: город, зарплата от, формат работы, уровень, отрасль
// + чипы «Что для вас важно?» (multi-select → параметр important=csv).
// НЕ стена фильтров — только в режиме «Точно»; на мобиле сворачивается в аккордеон.
'use client';

import * as React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { ChevronDown, SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { IMPORTANT_CHIPS } from '@/components/jobs/jobs-types';

// === Форма точных фильтров ===
export interface PreciseFilters {
  location: string;
  minSalary: string;
  workFormat: string;   // any | remote | hybrid | onsite
  level: string;        // '' | Junior | Middle | Senior | Lead | Head
  industry: string;
}

export const EMPTY_PRECISE_FILTERS: PreciseFilters = {
  location: '', minSalary: '', workFormat: 'any', level: '', industry: '',
};

interface JobPreciseFiltersProps {
  filters: PreciseFilters;
  onFiltersChange: (f: PreciseFilters) => void;
  important: Set<string>;
  onToggleImportant: (code: string) => void;
  onApply: () => void;
  loading?: boolean;
}

export function JobPreciseFilters({ filters, onFiltersChange, important, onToggleImportant, onApply, loading }: JobPreciseFiltersProps) {
  const set = (patch: Partial<PreciseFilters>) => onFiltersChange({ ...filters, ...patch });

  const fields = (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        <div className="space-y-1.5">
          <Label htmlFor="pf-location" className="text-xs text-muted-foreground">Город</Label>
          <Input
            id="pf-location"
            value={filters.location}
            onChange={e => set({ location: e.target.value })}
            placeholder="Москва"
            className="h-9"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pf-salary" className="text-xs text-muted-foreground">Зарплата от, ₽</Label>
          <Input
            id="pf-salary"
            type="number"
            inputMode="numeric"
            min={0}
            value={filters.minSalary}
            onChange={e => set({ minSalary: e.target.value })}
            placeholder="250 000"
            className="h-9"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pf-format" className="text-xs text-muted-foreground">Формат работы</Label>
          <Select value={filters.workFormat || 'any'} onValueChange={v => set({ workFormat: v })}>
            <SelectTrigger id="pf-format" className="h-9 w-full" aria-label="Формат работы">
              <SelectValue placeholder="Любой" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Любой</SelectItem>
              <SelectItem value="remote">Удалённо</SelectItem>
              <SelectItem value="hybrid">Гибрид</SelectItem>
              <SelectItem value="onsite">В офисе</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pf-level" className="text-xs text-muted-foreground">Уровень</Label>
          <Select value={filters.level || 'any'} onValueChange={v => set({ level: v === 'any' ? '' : v })}>
            <SelectTrigger id="pf-level" className="h-9 w-full" aria-label="Уровень должности">
              <SelectValue placeholder="Любой" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Любой</SelectItem>
              <SelectItem value="Junior">Junior</SelectItem>
              <SelectItem value="Middle">Middle</SelectItem>
              <SelectItem value="Senior">Senior</SelectItem>
              <SelectItem value="Lead">Lead</SelectItem>
              <SelectItem value="Head">Head</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pf-industry" className="text-xs text-muted-foreground">Отрасль</Label>
          <Input
            id="pf-industry"
            value={filters.industry}
            onChange={e => set({ industry: e.target.value })}
            placeholder="Энергетика"
            className="h-9"
          />
        </div>
      </div>

      {/* Чипы «Что для вас важно?» */}
      <div className="space-y-1.5">
        <div className="text-xs text-muted-foreground">Что для вас важно?</div>
        <div className="flex flex-wrap gap-1.5">
          {IMPORTANT_CHIPS.map(chip => {
            const active = important.has(chip.code);
            return (
              <button
                key={chip.code}
                type="button"
                onClick={() => onToggleImportant(chip.code)}
                aria-pressed={active}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs border transition whitespace-nowrap',
                  active
                    ? 'bg-primary text-primary-foreground border-primary font-medium'
                    : 'hover:border-primary hover:text-foreground',
                )}
              >
                {chip.label}
              </button>
            );
          })}
        </div>
      </div>

      <Button size="sm" onClick={onApply} disabled={loading} className="gap-1.5">
        <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
        Показать вакансии
      </Button>
    </div>
  );

  return (
    <>
      {/* Desktop — панель всегда развёрнута */}
      <div className="hidden md:block rounded-xl border bg-muted/20 p-4">
        {fields}
      </div>

      {/* Mobile — аккордеон */}
      <Collapsible className="md:hidden">
        <CollapsibleTrigger className="w-full flex items-center justify-between rounded-xl border bg-muted/20 px-4 py-3 text-sm font-medium">
          <span className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4" aria-hidden="true" />
            Точные фильтры
            {important.size > 0 && (
              <span className="text-xs px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground">
                {important.size}
              </span>
            )}
          </span>
          <ChevronDown className="w-4 h-4 transition-transform [[data-state=open]>&]:rotate-180" aria-hidden="true" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2">
          <div className="rounded-xl border bg-muted/20 p-4">
            {fields}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </>
  );
}
