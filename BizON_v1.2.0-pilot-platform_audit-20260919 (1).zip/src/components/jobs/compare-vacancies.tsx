// BizON — Compare Vacancies (P1: Side-by-side сравнение вакансий)
// Модалка с таблицей сравнения по метрикам: Match / Hiring Reality / Employer Trust /
// Время ответа / Зарплата / Время закрытия / Проекты / Рост.
// Источник: POST /api/jobs/compare { jobIds: string[] }
//
// Вызов:
//   <CompareVacanciesDialog jobIds={[...]} open={...} onOpenChange={...} />
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles,
  Loader2,
  ShieldCheck,
  TrendingUp,
  Clock,
  Wallet,
  CheckCircle2,
  Minus,
  GitBranch,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ---------- типы ответа API ----------

interface CompareRow {
  jobId: string;
  title: string;
  company: string;
  companyId: string | null;
  match: number;
  hiringReality: number;
  employerTrust: number | null;
  responseDays: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  closureDays: number | null;
  hasTrustChain: boolean;
  growthScore: number;
  growthLabel: 'низкий' | 'средний' | 'высокий' | 'оч. высокий';
  requiredSkills: string[];
  matchedSkills: string[];
  missingSkills: string[];
}

interface CompareResponse {
  rows: CompareRow[];
  recommendation: string;
  meta: {
    userId: string;
    userSkillsCount: number;
    generatedAt: string;
  };
}

// ---------- helpers ----------

const LETTERS = ['A', 'B', 'C', 'D'];

function currencySymbol(c: string): string {
  return c === 'RUB' ? '₽' : c === 'USD' ? '$' : c === 'EUR' ? '€' : c;
}

function formatSalary(min: number | null, max: number | null, cur: string): string {
  if (min == null || max == null || min <= 0 || max <= 0) return '—';
  const sym = currencySymbol(cur);
  // Если диапазон узкий — показываем одно число, иначе «350k–400k»
  const fmtK = (n: number) => (n >= 1000 ? `${Math.round(n / 1000)}k` : `${n}`);
  if (min === max) return `${fmtK(min)}${sym}`;
  return `${fmtK(min)}–${fmtK(max)}${sym}`;
}

function formatDays(d: number | null): string {
  if (d == null) return '—';
  if (d < 1) return 'менее дня';
  if (d === 1) return '1 день';
  if (d < 5) return `${d} дня`;
  return `${d} дн`;
}

// Цветовой ранг для метрик «чем больше — тем лучше» (0..100)
function scoreClass(score: number): string {
  if (score >= 70) return 'text-emerald-700 dark:text-emerald-400 font-bold';
  if (score >= 40) return 'text-amber-700 dark:text-amber-400 font-medium';
  return 'text-muted-foreground';
}

// Цветовой ранг для дней «чем меньше — тем лучше»
function daysClass(d: number | null, good: number, mid: number): string {
  if (d == null) return 'text-muted-foreground';
  if (d <= good) return 'text-emerald-700 dark:text-emerald-400 font-medium';
  if (d <= mid) return 'text-amber-700 dark:text-amber-400';
  return 'text-red-700 dark:text-red-400 font-medium';
}

// ---------- компонент ----------

interface Props {
  jobIds: string[];
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function CompareVacanciesDialog({ jobIds, open, onOpenChange }: Props) {
  const [data, setData] = React.useState<CompareResponse | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    if (!open || jobIds.length < 2) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api<CompareResponse>('/api/jobs/compare', {
        method: 'POST',
        body: JSON.stringify({ jobIds }),
      });
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить сравнение');
      toast({
        title: 'Не удалось сравнить вакансии',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [open, jobIds]);

  React.useEffect(() => {
    if (open) {
      load();
    } else {
      // Сброс при закрытии — чтобы при следующем открытии не мелькали старые данные
      setData(null);
      setError(null);
    }
  }, [open, load]);

  const rows = data?.rows ?? [];

  // Определим «лучшее» значение по каждой метрике — для подсветки.
  // Лучшее = max для score-метрик, min для days-метрик.
  const best = React.useMemo(() => {
    if (rows.length === 0) return null;
    const max = (sel: (r: CompareRow) => number) => Math.max(...rows.map(sel));
    const min = (sel: (r: CompareRow) => number | null) => {
      const vals = rows.map(sel).filter((v): v is number => v != null);
      return vals.length === 0 ? null : Math.min(...vals);
    };
    return {
      match: max((r) => r.match),
      hiringReality: max((r) => r.hiringReality),
      employerTrust: rows.every((r) => r.employerTrust == null)
        ? null
        : max((r) => r.employerTrust ?? -1),
      responseDays: min((r) => r.responseDays),
      closureDays: min((r) => r.closureDays),
      growth: max((r) => r.growthScore),
      // Salary: best = max верхняя граница
      salaryMax: max((r) => r.salaryMax ?? 0),
    };
  }, [rows]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl w-[95vw] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Сравнение вакансий
          </DialogTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Side-by-side по 8 метрикам · {rows.length} вакансии
          </p>
        </DialogHeader>

        {loading ? (
          <div className="space-y-3 py-4">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : error ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            {error}
            <div className="mt-3">
              <Button variant="outline" size="sm" onClick={load}>
                Повторить
              </Button>
            </div>
          </div>
        ) : rows.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground">
            Недостаточно данных для сравнения
          </div>
        ) : (
          <div className="space-y-4">
            {/* === Таблица сравнения === */}
            <div className="overflow-x-auto -mx-2 px-2">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left text-xs text-muted-foreground font-medium uppercase tracking-wider py-2 pr-3 align-bottom">
                      Метрика
                    </th>
                    {rows.map((r, i) => (
                      <th
                        key={r.jobId}
                        className="text-left py-2 px-3 align-bottom min-w-[140px]"
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-600 text-white text-xs font-bold flex-shrink-0">
                            {LETTERS[i] ?? '?'}
                          </span>
                          <div className="min-w-0">
                            <div className="text-xs font-semibold truncate" title={r.title}>
                              {r.title}
                            </div>
                            <div className="text-xs text-muted-foreground truncate">
                              {r.company}
                            </div>
                          </div>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {/* Match */}
                  <CompareRowCells
                    label="Match"
                    icon={<TrendingUp className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', scoreClass(r.match))}>
                        {r.match}%
                        {best && r.match === best.match && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Hiring Reality */}
                  <CompareRowCells
                    label="Hiring Reality"
                    icon={<ShieldCheck className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', scoreClass(r.hiringReality))}>
                        {r.hiringReality}
                        {best && r.hiringReality === best.hiringReality && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Employer Trust */}
                  <CompareRowCells
                    label="Employer Trust"
                    icon={<ShieldCheck className="w-3.5 h-3.5" />}
                    render={(r) =>
                      r.employerTrust == null ? (
                        <span className="text-muted-foreground">—</span>
                      ) : (
                        <span className={cn('tabular-nums', scoreClass(r.employerTrust))}>
                          {r.employerTrust}
                          {best && r.employerTrust === best.employerTrust && (
                            <span className="ml-1 text-xs text-emerald-600">★</span>
                          )}
                        </span>
                      )
                    }
                    rows={rows}
                  />
                  {/* Ответ (дни) */}
                  <CompareRowCells
                    label="Ответ"
                    icon={<Clock className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', daysClass(r.responseDays, 1, 5))}>
                        {formatDays(r.responseDays)}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Зарплата */}
                  <CompareRowCells
                    label="Зарплата"
                    icon={<Wallet className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className="tabular-nums font-medium">
                        {formatSalary(r.salaryMin, r.salaryMax, r.currency)}
                        {best && r.salaryMax === best.salaryMax && r.salaryMax != null && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Закрытие (дни) */}
                  <CompareRowCells
                    label="Закрытие"
                    icon={<Clock className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span className={cn('tabular-nums', daysClass(r.closureDays, 30, 60))}>
                        {formatDays(r.closureDays)}
                      </span>
                    )}
                    rows={rows}
                  />
                  {/* Проекты (trustChain) */}
                  <CompareRowCells
                    label="Проекты"
                    icon={<GitBranch className="w-3.5 h-3.5" />}
                    render={(r) =>
                      r.hasTrustChain ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> есть
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-muted-foreground">
                          <Minus className="w-3.5 h-3.5" /> —
                        </span>
                      )
                    }
                    rows={rows}
                  />
                  {/* Рост */}
                  <CompareRowCells
                    label="Рост"
                    icon={<TrendingUp className="w-3.5 h-3.5" />}
                    render={(r) => (
                      <span
                        className={cn(
                          'tabular-nums',
                          r.growthLabel === 'оч. высокий'
                            ? 'text-emerald-700 dark:text-emerald-400 font-bold'
                            : r.growthLabel === 'высокий'
                              ? 'text-emerald-600 dark:text-emerald-500 font-medium'
                              : r.growthLabel === 'средний'
                                ? 'text-amber-700 dark:text-amber-400'
                                : 'text-muted-foreground',
                        )}
                      >
                        {r.growthLabel}
                        {best && r.growthScore === best.growth && (
                          <span className="ml-1 text-xs text-emerald-600">★</span>
                        )}
                      </span>
                    )}
                    rows={rows}
                  />
                </tbody>
              </table>
            </div>

            {/* === Легенда === */}
            <p className="text-xs text-muted-foreground">
              ★ — лучшее значение по метрике. Hiring Reality: ≥70 — высокая реальность
              найма, 40–69 — средняя, &lt;40 — низкая.
            </p>

            {/* === Совпадение навыков (развернуто) === */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {rows.map((r, i) => (
                <div key={r.jobId} className="rounded-lg border p-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-emerald-600 text-white text-xs font-bold">
                      {LETTERS[i] ?? '?'}
                    </span>
                    <div className="text-xs font-semibold truncate">{r.title}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Совпало {r.matchedSkills.length} из {r.requiredSkills.length} навыков
                  </div>
                  {r.matchedSkills.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {r.matchedSkills.map((s) => (
                        <Badge
                          key={`m-${s}`}
                          variant="default"
                          className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white"
                        >
                          {s}
                        </Badge>
                      ))}
                    </div>
                  )}
                  {r.missingSkills.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {r.missingSkills.map((s) => (
                        <Badge key={`x-${s}`} variant="secondary" className="text-xs">
                          {s}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* === AI рекомендация === */}
            <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 mb-1">
                    AI рекомендация
                  </div>
                  <p className="text-sm text-foreground/90 leading-relaxed">
                    {data?.recommendation ?? '—'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Закрыть
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ---------- подкомпонент: строка таблицы ----------

function CompareRowCells({
  label,
  icon,
  render,
  rows,
}: {
  label: string;
  icon: React.ReactNode;
  render: (r: CompareRow) => React.ReactNode;
  rows: CompareRow[];
}) {
  return (
    <tr>
      <td className="py-2 pr-3 text-xs text-muted-foreground align-middle">
        <div className="flex items-center gap-1.5">
          <span className="text-muted-foreground/70">{icon}</span>
          <span className="font-medium">{label}</span>
        </div>
      </td>
      {rows.map((r) => (
        <td key={r.jobId} className="py-2 px-3 align-middle">
          {render(r)}
        </td>
      ))}
    </tr>
  );
}

// ---------- маленький trigger-компонент для родителя ----------

export function CompareVacanciesButton({
  selectedIds,
  onClear,
  maxJobs = 4,
}: {
  selectedIds: string[];
  onClear?: () => void;
  maxJobs?: number;
}) {
  const [open, setOpen] = React.useState(false);
  const count = selectedIds.length;
  const canCompare = count >= 2 && count <= maxJobs;

  return (
    <>
      <div className="inline-flex items-center gap-2">
        <Button
          size="sm"
          onClick={() => setOpen(true)}
          disabled={!canCompare}
          className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
          title={
            count < 2
              ? `Выберите ещё ${2 - count} вакансию(и)`
              : count > maxJobs
                ? `Максимум ${maxJobs} вакансии для сравнения`
                : `Сравнить ${count} вакансии`
          }
        >
          <Sparkles className="w-3.5 h-3.5" />
          Сравнить ({count})
        </Button>
        {count > 0 && onClear && (
          <button
            onClick={onClear}
            className="text-xs text-muted-foreground hover:text-foreground"
            title="Очистить выбор"
          >
            сбросить
          </button>
        )}
      </div>

      <CompareVacanciesDialog
        jobIds={selectedIds}
        open={open}
        onOpenChange={setOpen}
      />
    </>
  );
}
