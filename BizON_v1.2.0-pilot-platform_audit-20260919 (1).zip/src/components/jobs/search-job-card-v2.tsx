// BizON — SearchJobCardV2 (v5.1)
// Компактная v2-карточка вакансии для страницы глобального поиска /search.
// Переиспользует v2-функционал:
//   • match % (персональный, рассчитан в /api/search)
//   • VerifiedVacancyBadge (8 критериев, по клику — модалка)
//   • Hiring Manager preview (ipScore, avatar, online badge)
//   • Boosted mark (ФЗ-38 — бейдж «Реклама»)
//   • 3 пути отклика — кнопка "Откликнуться" ведёт в раздел jobs с фильтром
//   • Hot badge (если matchConfidence >= 0.5)
//   • Personal state — saved / applied индикаторы
'use client';

import * as React from 'react';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { VerifiedVacancyBadge } from '@/components/jobs/verified-vacancy-badge';
import {
  MapPin, Flame, Bookmark, CheckCircle2, Zap, Clock,
  ArrowRight, Sparkles, MessageSquare,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export interface SearchJobV2 {
  id: string;
  title: string;
  company: string;
  description: string;
  requiredSkills: string[];
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  location: string | null;
  growthScore: number;
  matchConfidence: number;
  isHot: boolean;
  hiringManager: {
    id: string;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  } | null;
  responseTimeHours: number | null;
  boosted: boolean;
  boostedUntil: string | null;
  verificationStatus: 'draft' | 'posted' | 'verified';
  verifiedAt: string | null;
  vacancyTrust: number;
  companyId: string | null;
  hasApplied: boolean;
  isSaved: boolean;
  createdAt: string;
}

interface SearchJobCardV2Props {
  job: SearchJobV2;
  query: string;
  onHighlight: (text: string, q: string) => React.ReactNode;
}

function formatSalary(job: SearchJobV2): string | null {
  // Приоритет — salaryMin/Max (новые v2-поля), fallback на salaryFrom/To
  const from = job.salaryMin ?? job.salaryFrom;
  const to = job.salaryMax ?? job.salaryTo;
  if (!from && !to) return null;
  const fmt = (n: number) => {
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
    if (n >= 1000) return `${(n / 1000).toFixed(0)}k`;
    return `${n}`;
  };
  const cur = job.currency === 'RUB' ? '₽' : job.currency === 'USD' ? '$' : job.currency === 'EUR' ? '€' : ` ${job.currency}`;
  if (from && to) return `${fmt(from)}–${fmt(to)}${cur}`;
  if (from) return `от ${fmt(from)}${cur}`;
  if (to) return `до ${fmt(to)}${cur}`;
  return null;
}

function matchColor(match: number): string {
  if (match >= 0.7) return 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30';
  if (match >= 0.4) return 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30';
  return 'bg-muted text-muted-foreground border-border';
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  if (days < 1) return 'сегодня';
  if (days < 7) return `${days} дн. назад`;
  if (days < 30) return `${Math.floor(days / 7)} нед. назад`;
  return `${Math.floor(days / 30)} мес. назад`;
}

export function SearchJobCardV2({ job, query, onHighlight }: SearchJobCardV2Props) {
  const salary = formatSalary(job);
  const matchPercent = Math.round(job.matchConfidence * 100);
  const isVerified = job.verificationStatus === 'verified';

  // Кликабельная ссылка в раздел /jobs с фильтром по ID вакансии
  // (на странице поиска мы НЕ открываем модалку — пользователь должен перейти в раздел,
  // где есть полный v2-функционал: 3 пути отклика, сравнение, Time Value, etc.)
  const jobsDeepLink = `/?view=jobs&jobId=${job.id}`;

  return (
    <Link href={jobsDeepLink} className="block group">
      <Card
        className={cn(
          'hover:border-primary/50 hover:shadow-md transition-all overflow-hidden',
          job.boosted && 'ring-1 ring-amber-500/30',
          isVerified && 'border-emerald-500/30',
        )}
      >
        {/* Boosted stripe (ФЗ-38 маркировка рекламы) */}
        {job.boosted && (
          <div className="h-1 bg-gradient-to-r from-amber-400 to-amber-500" />
        )}

        <CardContent className="p-4 space-y-2.5">
          {/* Row 1: Title + Match + Boosted mark */}
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-[15px] leading-snug group-hover:text-primary transition">
                {onHighlight(job.title, query)}
                {job.boosted && (
                  <Badge
                    variant="outline"
                    className="ml-2 text-xs px-1.5 py-0 h-4 bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30 align-middle"
                    title="Реклама (ФЗ-38)"
                  >
                    <Zap className="w-2.5 h-2.5 mr-0.5" />
                    Реклама
                  </Badge>
                )}
              </div>
              <div className="text-sm text-muted-foreground truncate">
                {onHighlight(job.company, query)}
                {job.location && (
                  <>
                    {' · '}
                    <MapPin className="w-3 h-3 inline-block -mt-0.5" />
                    {onHighlight(job.location, query)}
                  </>
                )}
              </div>
            </div>

            {/* Personal match score */}
            <div
              className={cn(
                'flex-shrink-0 flex flex-col items-center justify-center px-2 py-1 rounded-md border min-w-[52px]',
                matchColor(job.matchConfidence),
              )}
              title="Ваше персональное совпадение по навыкам"
            >
              <div className="text-base font-bold tabular-nums leading-none">
                {matchPercent}%
              </div>
              <div className="text-xs uppercase tracking-wide opacity-80 mt-0.5">match</div>
            </div>
          </div>

          {/* Row 2: Salary + Verified + Hot + Posted time */}
          <div className="flex items-center gap-2 flex-wrap text-xs">
            {salary && (
              <span className="font-semibold text-foreground">
                {salary}
              </span>
            )}
            <VerifiedVacancyBadge
              jobId={job.id}
              initialStatus={job.verificationStatus}
              initialScore={job.vacancyTrust}
              compact={false}
            />
            {job.isHot && (
              <Badge className="bg-rose-500/10 text-rose-700 dark:text-rose-300 border-rose-500/30 text-xs px-1.5 py-0 h-4">
                <Flame className="w-2.5 h-2.5 mr-0.5" />
                Горячая
              </Badge>
            )}
            <span className="text-muted-foreground ml-auto">
              {timeAgo(job.createdAt)}
            </span>
          </div>

          {/* Row 3: Skills (top 5) */}
          {job.requiredSkills.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {job.requiredSkills.slice(0, 5).map((s) => (
                <Badge
                  key={s}
                  variant="secondary"
                  className="text-xs px-1.5 py-0 h-4"
                >
                  {s}
                </Badge>
              ))}
              {job.requiredSkills.length > 5 && (
                <span className="text-xs text-muted-foreground self-center">
                  +{job.requiredSkills.length - 5}
                </span>
              )}
            </div>
          )}

          {/* Row 4: Hiring Manager preview (если есть) */}
          {job.hiringManager && (
            <div className="flex items-center gap-2 pt-1.5 border-t">
              <Avatar className="w-6 h-6">
                <AvatarImage src={job.hiringManager.avatarUrl ?? undefined} alt={job.hiringManager.name} />
                <AvatarFallback className="text-xs">
                  {job.hiringManager.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 text-xs">
                <div className="font-medium truncate flex items-center gap-1">
                  {job.hiringManager.name}
                  {isVerified && (
                    <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                  )}
                </div>
                <div className="text-muted-foreground truncate">
                  {job.hiringManager.title ?? 'Hiring Manager'}
                </div>
              </div>
              {job.responseTimeHours != null && (
                <Badge variant="outline" className="text-xs px-1.5 py-0 h-4 gap-0.5">
                  <Clock className="w-2.5 h-2.5" />
                  ~{job.responseTimeHours}ч
                </Badge>
              )}
            </div>
          )}

          {/* Row 5: Personal state CTA */}
          <div className="flex items-center gap-2 pt-1">
            {job.hasApplied ? (
              <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-xs">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Отклик отправлен
              </Badge>
            ) : (
              <Button
                size="sm"
                variant="default"
                className="h-7 text-xs gap-1"
                // Кнопка ведёт в раздел jobs — там доступны все 3 пути отклика
                onClick={(e) => {
                  // Link уже отработает, ничего не делаем
                }}
              >
                <MessageSquare className="w-3 h-3" />
                Открыть вакансию
                <ArrowRight className="w-3 h-3" />
              </Button>
            )}
            {job.isSaved && (
              <Badge variant="outline" className="text-xs px-1.5 py-0 h-4 gap-0.5">
                <Bookmark className="w-2.5 h-2.5 fill-current" />
                Сохранена
              </Badge>
            )}
            <div className="ml-auto text-xs text-muted-foreground flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5" />
              AI-подбор
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
