// BizON — JobIntentBar (Task 7-b, «BIZON NEXT» стр. 19-21 — intention-first главный экран)
// ЕДИНАЯ интент-строка для всех режимов:
//   «Какую работу вы ищете? …» + [Найти работу]
// + переключатель режимов (сегмент-контрол): 🔎 Быстро | ✍️ Своими словами | 🎯 Точно | 🔬 Исследовать.
// Переключение — state, не навсегда (в любой момент можно сменить режим).
'use client';

import * as React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Search, Loader2 } from 'lucide-react';
import { SEARCH_MODES, type JobSearchMode } from '@/components/jobs/jobs-types';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';

interface JobIntentBarProps {
  query: string;
  onQueryChange: (q: string) => void;
  mode: JobSearchMode;
  onModeChange: (m: JobSearchMode) => void;
  onSubmit: () => void;
  loading?: boolean;
  /** Автофокус при переключении режима «Изменить» в nl-подтверждении */
  autoFocusSignal?: number;
}

export function JobIntentBar({ query, onQueryChange, mode, onModeChange, onSubmit, loading, autoFocusSignal }: JobIntentBarProps) {
  const inputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (autoFocusSignal && autoFocusSignal > 0) {
      inputRef.current?.focus();
    }
  }, [autoFocusSignal]);

  return (
    <div className="space-y-3">
      {/* Интент-строка */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" aria-hidden="true" />
          <Input
            ref={inputRef}
            value={query}
            onChange={e => onQueryChange(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') onSubmit(); }}
            placeholder="Какую работу вы ищете? Например: хочу руководить проектами в энергетике, желательно удалённо, от 250 000 ₽"
            className="pl-9 h-11 text-sm"
            aria-label="Опишите, какую работу вы ищете"
          />
        </div>
        <Button
          onClick={onSubmit}
          disabled={loading}
          className="h-11 px-6 font-medium gap-2"
          aria-label="Найти работу по описанию"
        >
          {loading
            ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
            : <Search className="w-4 h-4" aria-hidden="true" />}
          Найти работу
        </Button>
      </div>

      {/* Переключатель режимов + подсказка-термин «Интент-строка» (Wave 11-e) */}
      <div className="flex items-center gap-1.5 min-w-0">
      <ToggleGroup
        type="single"
        variant="outline"
        value={mode}
        onValueChange={v => { if (v) onModeChange(v as JobSearchMode); }}
        // Мобильный: сетка 2×2 (режимы не сжимаются), десктоп: один ряд
        className="w-full grid grid-cols-2 gap-2 sm:flex sm:gap-1"
        aria-label="Режим поиска работы"
      >
        {SEARCH_MODES.map(m => (
          <ToggleGroupItem
            key={m.value}
            value={m.value}
            aria-label={`Режим: ${m.label}`}
            className="w-full sm:w-auto sm:flex-1 gap-1.5 text-xs sm:text-sm h-9 px-3"
          >
            <span aria-hidden="true">{m.icon}</span>
            {m.label}
          </ToggleGroupItem>
        ))}
      </ToggleGroup>
        <TermInfo k="intent_bar" className="shrink-0" />
      </div>
    </div>
  );
}
