// BizON — Job Passport (Phase 3 + Phase 4 — BIZON TIME VALUE)
// Карточка «паспорта вакансии» — агрегирует match + hiring reality + company trust
// + BIZON TIME VALUE (apply / skip / consider).
//
// Карточка показывает:
//   • Должность / компания / локация / зарплата
//   • MATCH %  •  HIRING REALITY  •  EMPLOYER TRUST  •  RESPONSE ~
//   • «Почему вам подходит» (✓ N/M подтверждены, ✓ N похожих проекта, ✗ нет навыка X → PROVE IT)
//   • BizON рекомендует (apply/skip/consider) + reason
//   • Кнопки: [Откликнуться] [Сохранить] [Сравнить]
//
// Источник: GET /api/jobs/[id]/job-passport (включает timeValue + context с Phase 4)
//           GET /api/jobs/[id]/time-value (дублирующий endpoint для удобства)
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles, ShieldCheck, Clock, TrendingUp, Bookmark, Zap,
  GitCompare, Loader2, CheckCircle2, AlertTriangle, XCircle,
  ArrowRight, Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { HiringRealityLevel } from '@/lib/services/hiring-reality-service';
import type { TimeValueRecommendation } from '@/lib/services/time-value-service';

// === Тип ответа /api/jobs/[id]/job-passport ===
interface JobPassportResponse {
  job: {
    id: string;
    title: string;
    company: string;
    companyId: string | null;
    companyName: string;
    location: string | null;
    salaryMin: number | null;
    salaryMax: number | null;
    currency: string;
    createdAt: string;
    hiringManager: { id: string; name: string; title: string | null; avatarUrl: string | null } | null;
  };
  match: {
    candidateFit: number;
    companyFit: number | null; // W1.2: null = нет Cultural Signals (честное отсутствие)
    totalMatch: number;
    breakdown: {
      skills: { score: number; matched: string[]; missing: string[] };
      trust: { score: number; reason: string };
      growth: { score: number; reason: string };
    };
    why: string;
    whatYouGet: string[];
    whatCompanyGets: string[];
  };
  hiringReality: {
    score: number;
    level: HiringRealityLevel;
    criteria?: Array<{ name: string; passed: boolean; points: number; detail?: string }>;
  };
  companyTrust: {
    employerTrust: number;
    businessTrust: number;
    deliveryTrust: number;
    transparency: number;
    overall: number;
  } | null;
  responseTimeHours: number | null;
  // Legacy: apply/skip (оставлено для обратной совместимости)
  recommendation: 'apply' | 'skip';
  recommendationReason: string;
  // === Phase 4 — BIZON TIME VALUE ===
  timeValue?: {
    recommendation: TimeValueRecommendation;
    reason: string;
    factors: { match: number; hiringReality: number; salaryFit: number; trustFit: number };
    computedAt: string;
  };
  // === Phase 4 — контекст «Почему вам подходит» ===
  context?: {
    verifiedProjectsCount: number;
    similarProjectsCount: number;
    commonContactsCount: number;
    matchedSkills: string[];
    missingSkills: string[];
    verifiedSkillsMatched: string;  // "N/M"
    totalRequiredSkills: number;
  };
}

interface JobPassportProps {
  jobId: string;
  /** Уже применён отклик / сохранён — управляется родителем (BIZON WORK «Найди мне») */
  hasApplied?: boolean;
  isSaved?: boolean;
  onApply?: (jobId: string) => void | Promise<void>;
  onToggleSave?: (jobId: string) => void | Promise<void>;
  onCompare?: (jobId: string) => void;
  /** Lazy: по умолчанию грузит при монтировании. Если передать preloaded — использует его. */
  preloaded?: JobPassportResponse;
  /** Компактный режим — для маленьких карточек в списке «Найди мне». */
  compact?: boolean;
  /** Колбэк при клике на PROVE IT — родитель может открыть Claim-форму. */
  onProveIt?: (missingSkill: string) => void;
}

const HIRING_REALITY_META: Record<HiringRealityLevel, { label: string; color: string; icon: React.ReactNode }> = {
  high: {
    label: 'Высокая',
    color: 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    icon: <CheckCircle2 className="w-3.5 h-3.5" />,
  },
  medium: {
    label: 'Средняя',
    color: 'text-amber-700 dark:text-amber-400 bg-amber-500/10 border-amber-500/30',
    icon: <AlertTriangle className="w-3.5 h-3.5" />,
  },
  low: {
    label: 'Низкая',
    color: 'text-red-700 dark:text-red-400 bg-red-500/10 border-red-500/30',
    icon: <XCircle className="w-3.5 h-3.5" />,
  },
};

// === Phase 4 — BIZON TIME VALUE meta (3-state: apply/skip/consider) ===
const TIME_VALUE_META: Record<TimeValueRecommendation, {
  label: string;
  short: string;
  color: string;
  icon: React.ReactNode;
}> = {
  apply: {
    label: 'BizON рекомендует: Откликнуться — высокая ценность',
    short: 'Откликнуться',
    color: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-800 dark:text-emerald-300',
    icon: <Sparkles className="w-3.5 h-3.5" />,
  },
  skip: {
    label: 'BizON рекомендует: Не тратьте время',
    short: 'Не тратьте время',
    color: 'bg-red-500/10 border-red-500/30 text-red-800 dark:text-red-300',
    icon: <XCircle className="w-3.5 h-3.5" />,
  },
  consider: {
    label: 'BizON рекомендует: Стоит рассмотреть',
    short: 'Стоит рассмотреть',
    color: 'bg-amber-500/10 border-amber-500/30 text-amber-800 dark:text-amber-300',
    icon: <AlertTriangle className="w-3.5 h-3.5" />,
  },
};

export function JobPassport({
  jobId,
  hasApplied,
  isSaved,
  onApply,
  onToggleSave,
  onCompare,
  preloaded,
  compact,
  onProveIt,
}: JobPassportProps) {
  const [data, setData] = React.useState<JobPassportResponse | null>(preloaded ?? null);
  const [loading, setLoading] = React.useState(!preloaded);
  const [error, setError] = React.useState<string | null>(null);
  const [applyLoading, setApplyLoading] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!jobId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api<JobPassportResponse>(`/api/jobs/${jobId}/job-passport`);
      setData(res);
    } catch (e: any) {
      setError(e.message ?? 'Ошибка загрузки паспорта вакансии');
    } finally {
      setLoading(false);
    }
  }, [jobId]);

  React.useEffect(() => {
    if (!preloaded) load();
  }, [load, preloaded]);

  async function handleApply() {
    if (!data) return;
    setApplyLoading(true);
    try {
      await api(`/api/jobs/${jobId}/apply`, { method: 'POST', body: JSON.stringify({}) });
      toast({ title: 'Отклик отправлен', description: `Совпадение: ${data.match.totalMatch}%` });
      onApply?.(jobId);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setApplyLoading(false);
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-4 space-y-3">
          <Skeleton className="h-5 w-2/3" />
          <div className="grid grid-cols-2 gap-2">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-9 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    return (
      <Card>
        <CardContent className="p-4 text-sm text-muted-foreground">
          Не удалось загрузить паспорт вакансии.
          <button onClick={load} className="ml-2 underline hover:text-foreground">Повторить</button>
        </CardContent>
      </Card>
    );
  }

  const { job, match, hiringReality, companyTrust, responseTimeHours, timeValue, context } = data;
  const matchPct = match.totalMatch;
  const hrMeta = HIRING_REALITY_META[hiringReality.level];
  const employerTrust = companyTrust?.overall ?? 0;

  // Phase 4: timeValue recommendation (3-state). Fallback на legacy recommendation
  // (apply/skip → применяем как есть) если timeValue не пришёл.
  const tvRec: TimeValueRecommendation = timeValue?.recommendation ?? data.recommendation;
  const tvReason: string = timeValue?.reason ?? data.recommendationReason;
  const tvMeta = TIME_VALUE_META[tvRec];
  const isApply = tvRec === 'apply';

  // Salary text
  const salaryMin = job.salaryMin;
  const salaryMax = job.salaryMax;
  const currencySymbol = job.currency === 'RUB' ? '₽' : job.currency === 'USD' ? '$' : job.currency === 'EUR' ? '€' : job.currency;
  const salaryText = salaryMin != null && salaryMax != null && salaryMin > 0 && salaryMax > 0
    ? `${salaryMin.toLocaleString('ru-RU')}–${salaryMax.toLocaleString('ru-RU')} ${currencySymbol}`
    : 'Зарплата не указана';

  // Response time text
  const responseText = responseTimeHours
    ? responseTimeHours <= 1
      ? 'Обычно отвечает сразу'
      : `Обычно отвечает за ${responseTimeHours} ч`
    : 'Время ответа неизвестно';

  // Phase 4: «Почему вам подходит» — checklist с ✓/✗ и кнопкой PROVE IT
  const ctx = context;
  const verifiedSkillsMatched = ctx?.verifiedSkillsMatched ?? `${match.breakdown.skills.matched.length}/${(match.breakdown.skills.matched.length + match.breakdown.skills.missing.length)}`;
  const similarProjects = ctx?.similarProjectsCount ?? 0;
  const verifiedProjects = ctx?.verifiedProjectsCount ?? 0;
  const missingSkills = ctx?.missingSkills ?? match.breakdown.skills.missing;
  const matchedSkills = ctx?.matchedSkills ?? match.breakdown.skills.matched;

  return (
    <Card className={cn(
      'hover:shadow-md transition-shadow relative overflow-hidden',
      isApply && 'ring-1 ring-emerald-400/40',
    )}>
      <CardContent className={cn('p-4 space-y-3', compact && 'p-3 space-y-2')}>
        {/* === Заголовок: должность + компания + зарплата + MATCH === */}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <h3 className="font-semibold text-base truncate">{job.title}</h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-0.5 flex-wrap">
              <span className="font-medium text-foreground/80 truncate">{job.companyName}</span>
              {job.location && (
                <span className="text-xs">· {job.location}</span>
              )}
            </div>
            <div className="text-sm font-semibold tabular-nums mt-1">{salaryText}</div>
          </div>
          {/* Match ring — крупный */}
          <div className="flex flex-col items-center gap-0.5 flex-shrink-0">
            <div className={cn(
              'relative w-12 h-12 rounded-full flex items-center justify-center text-xs font-bold tabular-nums',
              matchPct >= 70 ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                : matchPct >= 40 ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400'
                : 'bg-muted text-muted-foreground',
            )}>
              {matchPct}%
            </div>
            <span className="text-xs text-muted-foreground">Match</span>
          </div>
        </div>

        {/* === 4 метрики: MATCH / HIRING REALITY / EMPLOYER TRUST / RESPONSE === */}
        <div className={cn('grid gap-2', compact ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-4')}>
          <Metric
            icon={<Sparkles className="w-3.5 h-3.5" />}
            label="Match"
            value={`${matchPct}%`}
            sub={matchPct >= 70 ? 'Высокое' : matchPct >= 40 ? 'Среднее' : 'Низкое'}
            className={
              matchPct >= 70
                ? 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
                : matchPct >= 40
                  ? 'text-amber-700 dark:text-amber-400 bg-amber-500/10 border-amber-500/30'
                  : 'text-muted-foreground bg-muted border-border'
            }
          />
          <Metric
            icon={hrMeta.icon}
            label="Hiring Reality"
            value={`${hiringReality.score}/100`}
            sub={hrMeta.label}
            className={hrMeta.color}
          />
          <Metric
            icon={<ShieldCheck className="w-3.5 h-3.5" />}
            label="Employer Trust"
            value={`${Math.round(employerTrust)}/100`}
            sub={employerTrust >= 60 ? 'Высокий' : employerTrust >= 30 ? 'Средний' : 'Низкий'}
            className={employerTrust >= 60
              ? 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
              : employerTrust >= 30
                ? 'text-amber-700 dark:text-amber-400 bg-amber-500/10 border-amber-500/30'
                : 'text-muted-foreground bg-muted border-border'}
          />
          <Metric
            icon={<Clock className="w-3.5 h-3.5" />}
            label="Response"
            value={responseTimeHours ? `${responseTimeHours} ч` : '—'}
            sub={responseTimeHours ? (responseTimeHours <= 24 ? 'Быстро' : 'Медленно') : 'нет данных'}
            className="text-foreground/80 bg-muted/40 border-border"
          />
        </div>

        {/* === Почему вам подходит — checklist (✓/✗) с кнопкой PROVE IT === */}
        <div className="p-2.5 rounded-md bg-muted/40 space-y-1.5">
          <div className="text-xs font-medium flex items-center gap-1 mb-0.5">
            <Sparkles className="w-3 h-3" /> Почему вам подходит
          </div>
          <div className="space-y-1 text-xs">
            <ChecklistRow
              passed={match.breakdown.skills.matched.length > 0}
              text={`${verifiedSkillsMatched} требований подтверждены вашими навыками`}
            />
            {similarProjects > 0 && (
              <ChecklistRow
                passed
                text={`${similarProjects} ${similarProjects === 1 ? 'похожий проект' : similarProjects < 5 ? 'похожих проекта' : 'похожих проектов'} в вашем портфолио`}
              />
            )}
            {verifiedProjects > 0 && similarProjects === 0 && (
              <ChecklistRow
                passed
                text={`${verifiedProjects} ${verifiedProjects === 1 ? 'завершённый проект' : 'завершённых проекта'} в профиле`}
              />
            )}
            {/* ✗ Нет навыка → PROVE IT */}
            {missingSkills.slice(0, 3).map((skill) => (
              <ChecklistRow
                key={skill}
                passed={false}
                text={`Нет навыка «${skill}»`}
                action={
                  onProveIt ? (
                    <button
                      type="button"
                      onClick={() => onProveIt(skill)}
                      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wide bg-primary text-primary-foreground hover:bg-primary/90 transition"
                      title={`Подтвердить навык «${skill}»`}
                    >
                      Prove it
                      <ArrowRight className="w-2.5 h-2.5" />
                    </button>
                  ) : null
                }
              />
            ))}
          </div>
          {match.why && (
            <p className="text-xs text-muted-foreground leading-snug pt-1 border-t border-border/50">
              {match.why}
            </p>
          )}
          {match.whatYouGet.length > 0 && (
            <div className="mt-1 flex flex-wrap gap-1">
              {match.whatYouGet.slice(0, 3).map((w, i) => (
                <Badge key={i} variant="secondary" className="text-xs font-normal">{w}</Badge>
              ))}
            </div>
          )}
        </div>

        {/* === BizON рекомендация (Phase 4 — BIZON TIME VALUE) === */}
        <div className={cn(
          'flex items-start gap-2 p-2.5 rounded-md border text-xs',
          tvMeta.color,
        )}>
          {tvMeta.icon}
          <div className="min-w-0 flex-1">
            <div className="font-semibold">{tvMeta.label}</div>
            <div className="opacity-80">{tvReason}</div>
            {timeValue && (
              <div className="mt-1.5 flex flex-wrap gap-1.5 text-xs">
                <FactorChip label="Match" value={timeValue.factors.match} />
                <FactorChip label="HR" value={timeValue.factors.hiringReality} />
                <FactorChip label="Salary" value={timeValue.factors.salaryFit} />
                <FactorChip label="Trust" value={timeValue.factors.trustFit} />
              </div>
            )}
          </div>
        </div>

        {/* === Кнопки: [Откликнуться] [Сохранить] [Сравнить] === */}
        <div className="flex items-center gap-2 flex-wrap pt-1 border-t">
          <Button
            size="sm"
            onClick={handleApply}
            disabled={hasApplied || applyLoading}
            className={cn('gap-1.5', isApply ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : '')}
          >
            {applyLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
            {hasApplied ? 'Отклик отправлен' : 'Откликнуться'}
          </Button>

          {onToggleSave && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onToggleSave(jobId)}
              className="gap-1.5"
              title={isSaved ? 'В избранном' : 'Сохранить'}
            >
              <Bookmark className={cn('w-3.5 h-3.5', isSaved && 'fill-current')} />
              {!compact && (isSaved ? 'Сохранено' : 'Сохранить')}
            </Button>
          )}

          {onCompare && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => onCompare(jobId)}
              className="gap-1.5"
              title="Добавить к сравнению"
            >
              <GitCompare className="w-3.5 h-3.5" />
              {!compact && 'Сравнить'}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Metric — отдельный блок метрики
// ============================================================================
function Metric({
  icon, label, value, sub, className,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  className?: string;
}) {
  return (
    <div className={cn(
      'flex flex-col gap-0.5 p-2 rounded-md border text-xs',
      className,
    )}>
      <div className="flex items-center gap-1 opacity-80">
        {icon}
        <span className="text-xs uppercase tracking-wide">{label}</span>
      </div>
      <div className="font-semibold tabular-nums text-sm">{value}</div>
      {sub && <div className="text-xs opacity-70">{sub}</div>}
    </div>
  );
}

// ============================================================================
// ChecklistRow — ✓/✗ строка с опциональным action (PROVE IT)
// ============================================================================
function ChecklistRow({
  passed,
  text,
  action,
}: {
  passed: boolean;
  text: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-1.5">
      <span
        className={cn(
          'flex-shrink-0 mt-0.5 w-3.5 h-3.5 rounded-full flex items-center justify-center text-xs',
          passed
            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
            : 'bg-red-500/15 text-red-700 dark:text-red-300',
        )}
        aria-hidden="true"
      >
        {passed ? '✓' : '✗'}
      </span>
      <span className={cn('flex-1 min-w-0', passed ? 'text-foreground/80' : 'text-foreground/70')}>
        {text}
      </span>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
  );
}

// ============================================================================
// FactorChip — мини-чип фактора (Match/HR/Salary/Trust) в блоке timeValue
// ============================================================================
function FactorChip({ label, value }: { label: string; value: number }) {
  const v = Math.round(value);
  const color = v >= 70
    ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
    : v >= 40
      ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300'
      : 'bg-red-500/15 text-red-700 dark:text-red-300';
  return (
    <span className={cn('inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded font-medium tabular-nums', color)}>
      <Activity className="w-2.5 h-2.5 opacity-70" />
      {label}: {v}
    </span>
  );
}
