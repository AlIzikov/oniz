// BizON — JobNotMineDialog (Task 7-b, «BIZON NEXT» п.14 — Explicit Negative Intent)
// Диалог «Почему не подходит?» с radio-причинами.
// Отправка: POST /api/feed/recommendations/ignore
//   { topic: <title вакансии>, itemType: 'job', source: 'jobs', reason: <код>, targetId: <jobId> }
// Контракт расширяется параллельным бэкенд-агентом; текущий бэкенд принимает
// topic+itemType — расширенные поля игнорируются изящно (graceful).
'use client';

import * as React from 'react';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { cn } from '@/lib/utils';
import { NOT_MINE_REASONS } from '@/components/jobs/jobs-types';

interface JobNotMineDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobTitle: string;
  jobId: string;
  /** Вызывается после подтверждения причины — родитель делает оптимистичное скрытие + POST. */
  onConfirm: (reason: string, reasonLabel: string) => void;
}

export function JobNotMineDialog({ open, onOpenChange, jobTitle, jobId, onConfirm }: JobNotMineDialogProps) {
  const [reason, setReason] = React.useState<string>('');

  // Сброс выбора при открытии нового диалога
  React.useEffect(() => {
    if (open) setReason('');
  }, [open, jobId]);

  function handleConfirm() {
    const found = NOT_MINE_REASONS.find(r => r.code === reason);
    if (!found) return;
    onConfirm(found.code, found.label);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Почему не подходит?</DialogTitle>
          <DialogDescription className="line-clamp-1" title={jobTitle}>
            «{jobTitle}» — мы учтём это и не будем показывать похожее.
          </DialogDescription>
        </DialogHeader>

        <RadioGroup value={reason} onValueChange={setReason} className="max-h-72 overflow-y-auto scroll-area-thin gap-1 pr-1">
          {NOT_MINE_REASONS.map(r => (
            <Label
              key={r.code}
              htmlFor={`not-mine-${r.code}`}
              className={cn(
                'flex cursor-pointer items-center gap-2.5 rounded-md border px-3 py-2 text-sm font-normal transition',
                reason === r.code ? 'border-primary bg-primary/5' : 'hover:bg-accent',
              )}
            >
              <RadioGroupItem value={r.code} id={`not-mine-${r.code}`} />
              {r.label}
            </Label>
          ))}
        </RadioGroup>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" size="sm" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button size="sm" disabled={!reason} onClick={handleConfirm}>
            Не показывать
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}