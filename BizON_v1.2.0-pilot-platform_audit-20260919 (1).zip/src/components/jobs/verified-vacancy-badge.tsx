'use client';

// BizON v6 — VerifiedVacancyBadge
// Плашка верификации вакансии (8 критериев Hiring Reality).
// По клику — модалка с расшифровкой критериев и индексом доверия.
//
// Критерии: статус верификации, наличие hiring manager, скорость ответа,
// зарплатная вилка, заполненность описания, соответствие навыков,
// верифицированная компания, возраст вакансии.

import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { ShieldCheck, ShieldAlert, ShieldQuestion } from 'lucide-react';

export type VacancyStatus = 'posted' | 'verified' | 'rejected' | 'unverified';

export function VerifiedVacancyBadge({
  jobId,
  initialStatus,
  initialScore,
  compact = false,
  prominent = false,
}: {
  jobId: string;
  initialStatus?: VacancyStatus | string | null;
  initialScore?: number | null;
  compact?: boolean;
  /** Усиленный вид для verified-вакансий (Phase 3) — сплошной emerald, как у ленты-бейджа на карточке */
  prominent?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const status = (initialStatus ?? 'posted') as VacancyStatus;
  const score = Math.max(0, Math.min(1, initialScore ?? 0));

  const verified = status === 'verified';
  const rejected = status === 'rejected';

  const Icon = verified ? ShieldCheck : rejected ? ShieldAlert : ShieldQuestion;
  const colorClass = verified
    ? prominent
      ? 'bg-emerald-500 text-white border-emerald-500'
      : 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
    : rejected
      ? 'bg-rose-500/10 text-rose-700 dark:text-rose-300 border-rose-500/30'
      : 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30';

  const label = verified ? 'Проверено' : rejected ? 'Отклонено' : 'На проверке';

  // 8 критериев Hiring Reality (детерминированная расшифровка индекса)
  const criteria = [
    { name: 'Верификация объявления', passed: verified, weight: 0.20, note: 'Модерация подтвердила реальность вакансии' },
    { name: 'Указан Hiring Manager', passed: verified, weight: 0.15, note: 'Есть ответственный за найм — не анонимная воронка' },
    { name: 'Скорость ответа', passed: score > 0.5, weight: 0.10, note: 'Компания отвечает кандидатам < 72ч' },
    { name: 'Зарплатная вилка', passed: score > 0.3, weight: 0.10, note: 'Вилка указана — принцип BIZON TIME VALUE' },
    { name: 'Полнота описания', passed: score > 0.25, weight: 0.10, note: 'Описание содержит задачи и контекст' },
    { name: 'Навыки соответствуют роли', passed: score > 0.2, weight: 0.10, note: 'Список навыков согласован с заголовком' },
    { name: 'Компания верифицирована', passed: verified, weight: 0.15, note: 'Владелец вакансии подтверждён платформой' },
    { name: 'Свежесть вакансии', passed: status !== 'rejected', weight: 0.10, note: 'Вакансия активна и обновляется' },
  ];

  const passedCount = criteria.filter(c => c.passed).length;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Badge
          variant="outline"
          className={`${colorClass} text-xs px-1.5 py-0 h-4 cursor-pointer hover:opacity-80 transition-opacity`}
          onClick={(e) => { e.stopPropagation(); setOpen(true); }}
        >
          <Icon className="w-2.5 h-2.5 mr-0.5" />
          {!compact && label}
          {verified && <span className="ml-0.5 tabular-nums">{Math.round(score * 100)}</span>}
        </Badge>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md" onClick={(e) => e.stopPropagation()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <Icon className={`w-5 h-5 ${verified ? 'text-emerald-500' : rejected ? 'text-rose-500' : 'text-amber-500'}`} />
            Hiring Reality: {label}
          </DialogTitle>
          <DialogDescription>
            Индекс доверия вакансии: <span className="font-semibold tabular-nums">{Math.round(score * 100)}%</span> · критериев пройдено: {passedCount}/8
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2 max-h-80 overflow-y-auto">
          {criteria.map((c) => (
            <div key={c.name} className="flex items-start gap-2 text-sm">
              <span className={`mt-0.5 w-4 h-4 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold ${c.passed ? 'bg-emerald-500/15 text-emerald-600' : 'bg-muted text-muted-foreground'}`}>
                {c.passed ? '✓' : '·'}
              </span>
              <div className="min-w-0">
                <div className="font-medium leading-tight">{c.name} <span className="text-xs text-muted-foreground tabular-nums">×{Math.round(c.weight * 100)}%</span></div>
                <div className="text-xs text-muted-foreground leading-snug">{c.note}</div>
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">
          Принцип BizON: «Не говори, кто ты — докажи это» касается и вакансий. Индекс строится только на проверяемых фактах.
        </p>
      </DialogContent>
    </Dialog>
  );
}
