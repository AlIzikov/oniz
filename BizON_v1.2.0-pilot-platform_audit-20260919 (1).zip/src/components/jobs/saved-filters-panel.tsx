// BizON — SavedFiltersPanel (Wave 11-c, отзыв пользователя:
// «Я бы добавил кнопку "Избранные", в ней можно создавать фильтры для поиска,
// создать фильтр, который будет постоянно отслеживать — максимум не более 9 фильтров»).
//
// Панель для ПРАВОГО rail раздела «Работа» (SubSectionBar, desktop):
//   • список сохранённых фильтров — клик = применить к поиску в главном окне;
//   • «Отслеживать» (Bell, aria-pressed) — включает монитор фильтра (PATCH);
//   • «Сохранить текущий поиск как фильтр» — активна, когда в главном окне есть
//     активный поиск (jobsCurrentSearchParams из стора);
//   • кап 9 фильтров — сервер валидирует, фронт дублирует подписью и disabled.
//
// Интеграция с главным окном: применение фильтра → applyJobsFilter(params) —
// JobsView подписан на сигнал и запускает executeSearch.
// Мобильные (<lg) панель не показываем — в горизонтальных чипсах тесно.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  Bell, BellOff, BookmarkPlus, Filter, Loader2, Trash2, X,
} from 'lucide-react';

const CAP = 9;

interface SavedFilterItem {
  id: string;
  name: string;
  target: string;
  params: string;
  paramsParsed: Record<string, string> | null;
  monitoring: boolean;
  createdAt: string;
}

export function SavedFiltersPanel() {
  const { jobsCurrentSearchParams, applyJobsFilter } = useAppStore();

  const [items, setItems] = React.useState<SavedFilterItem[] | null>(null);
  const [creating, setCreating] = React.useState(false);
  const [name, setName] = React.useState('');
  const [monitor, setMonitor] = React.useState(true);
  const [busy, setBusy] = React.useState<string | null>(null); // id фильтра или 'create'
  const [createError, setCreateError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    try {
      const res = await api<{ items: SavedFilterItem[] }>(`/api/saved-filters?target=jobs&t=${Date.now()}`);
      setItems(res.items ?? []);
    } catch {
      // Панель не критична — при сбое показываем честную ошибку в empty
      setItems([]);
    }
  }, []);

  React.useEffect(() => { load(); }, [load]);

  const canSave = Boolean(jobsCurrentSearchParams);
  const atCap = (items?.length ?? 0) >= CAP;

  // Имя по умолчанию — из активного запроса
  function suggestName(): string {
    const p = jobsCurrentSearchParams;
    if (!p) return '';
    const parts: string[] = [];
    if (p.q) parts.push(p.q);
    if (p.important) parts.push(p.important.split(',').slice(0, 2).join(', '));
    if (p.location) parts.push(p.location);
    return parts.join(' · ').slice(0, 60) || 'Мой фильтр';
  }

  async function handleCreate() {
    if (!jobsCurrentSearchParams || atCap) return;
    const finalName = (name.trim() || suggestName()).slice(0, 60);
    if (!finalName) return;
    setBusy('create');
    setCreateError(null);
    try {
      await api('/api/saved-filters', {
        method: 'POST',
        body: JSON.stringify({
          name: finalName,
          target: 'jobs',
          params: JSON.stringify(jobsCurrentSearchParams),
          monitoring: monitor,
        }),
      });
      toast({ title: 'Фильтр сохранён', description: monitor ? 'Монитор включён — новые совпадения подсветим.' : undefined });
      setName('');
      setMonitor(true);
      setCreating(false);
      load();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Не удалось сохранить фильтр';
      setCreateError(msg);
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  async function handleToggleMonitor(item: SavedFilterItem) {
    setBusy(item.id);
    // Оптимистично
    setItems(prev => prev?.map(f => f.id === item.id ? { ...f, monitoring: !f.monitoring } : f) ?? prev);
    try {
      await api(`/api/saved-filters/${item.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ monitoring: !item.monitoring }),
      });
    } catch (e: unknown) {
      // Откат
      setItems(prev => prev?.map(f => f.id === item.id ? { ...f, monitoring: item.monitoring } : f) ?? prev);
      const msg = e instanceof Error ? e.message : 'Не удалось изменить';
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  async function handleDelete(item: SavedFilterItem) {
    setBusy(item.id);
    try {
      await api(`/api/saved-filters/${item.id}`, { method: 'DELETE' });
      setItems(prev => prev?.filter(f => f.id !== item.id) ?? prev);
      toast({ title: 'Фильтр удалён' });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Не удалось удалить';
      toast({ title: 'Ошибка', description: msg, variant: 'destructive' });
    } finally {
      setBusy(null);
    }
  }

  function handleApply(item: SavedFilterItem) {
    const params = item.paramsParsed;
    if (!params || Object.keys(params).length === 0) {
      toast({ title: 'У фильтра нет параметров', description: 'Пересоздайте фильтр из активного поиска.' });
      return;
    }
    applyJobsFilter(params);
    toast({ title: `Применён фильтр «${item.name}»` });
  }

  return (
    <div data-testid="saved-filters-panel">
      <div className="flex items-center justify-between gap-1 mb-1.5 px-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <Filter className="w-3.5 h-3.5 text-lighthouse shrink-0" aria-hidden="true" />
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider truncate">
            Мои фильтры
          </span>
        </div>
        <span className="text-xs text-muted-foreground tabular-nums">
          {items ? `${items.length}/${CAP}` : `—/${CAP}`}
        </span>
      </div>

      {/* Список фильтров */}
      {items === null ? (
        <div className="space-y-1 px-2">
          {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-8 w-full rounded-md" />)}
        </div>
      ) : items.length === 0 ? (
        <p className="text-xs text-muted-foreground leading-relaxed px-2 py-1">
          Нет сохранённых фильтров. Настройте поиск и сохраните его как фильтр — максимум {CAP}.
        </p>
      ) : (
        <div className="space-y-0.5 px-2" role="list" aria-label="Сохранённые фильтры">
          {items.map(f => (
            <div
              key={f.id}
              role="listitem"
              className="group flex items-center gap-1 rounded-md px-2 py-1.5 hover:bg-accent/60 transition"
            >
              <button
                type="button"
                onClick={() => handleApply(f)}
                className="flex-1 min-w-0 text-left"
                title={`Применить: ${f.name}`}
              >
                <div className="text-[13px] leading-tight truncate group-hover:text-lighthouse transition-colors">
                  {f.name}
                </div>
                <div className="text-xs text-muted-foreground truncate">
                  {f.paramsParsed?.q || 'параметры поиска'}
                </div>
              </button>
              <button
                type="button"
                onClick={() => handleToggleMonitor(f)}
                disabled={busy === f.id}
                aria-pressed={f.monitoring}
                aria-label={f.monitoring ? `Выключить монитор «${f.name}»` : `Включить монитор «${f.name}»`}
                title={f.monitoring ? 'Монитор включён' : 'Отслеживать новые совпадения'}
                className={cn(
                  'shrink-0 p-1 rounded transition',
                  f.monitoring ? 'text-lighthouse' : 'text-muted-foreground/50 hover:text-foreground',
                )}
              >
                {busy === f.id
                  ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                  : f.monitoring
                    ? <Bell className="w-3.5 h-3.5" aria-hidden="true" />
                    : <BellOff className="w-3.5 h-3.5" aria-hidden="true" />}
              </button>
              <button
                type="button"
                onClick={() => handleDelete(f)}
                disabled={busy === f.id}
                aria-label={`Удалить фильтр «${f.name}»`}
                title="Удалить фильтр"
                className="shrink-0 p-1 rounded text-muted-foreground/50 hover:text-destructive transition"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Создание из текущего поиска */}
      {creating ? (
        <div className="mx-2 mt-2 rounded-md border bg-muted/30 p-2.5 space-y-2">
          <div className="flex items-center justify-between gap-1">
            <span className="text-xs font-medium">Новый фильтр</span>
            <button
              type="button"
              onClick={() => { setCreating(false); setCreateError(null); }}
              aria-label="Отменить создание фильтра"
              className="text-muted-foreground hover:text-foreground p-0.5"
            >
              <X className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          </div>
          <Input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder={suggestName()}
            maxLength={60}
            className="h-8 text-xs"
            aria-label="Название фильтра"
          />
          <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
            <Checkbox checked={monitor} onCheckedChange={v => setMonitor(v === true)} className="w-3.5 h-3.5" />
            Отслеживать новые совпадения
          </label>
          {createError && <p className="text-xs text-destructive">{createError}</p>}
          <Button size="sm" className="w-full h-8 text-xs" onClick={handleCreate} disabled={busy === 'create'}>
            {busy === 'create'
              ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
              : <BookmarkPlus className="w-3.5 h-3.5" aria-hidden="true" />}
            Сохранить фильтр
          </Button>
        </div>
      ) : (
        <div className="px-2 mt-2">
          <Button
            size="sm"
            variant="outline"
            className="w-full h-8 text-xs justify-start gap-1.5"
            onClick={() => setCreating(true)}
            disabled={!canSave || atCap}
            title={!canSave
              ? 'Сначала задайте поиск в главном окне'
              : atCap ? `Максимум ${CAP} фильтров` : 'Сохранить текущий поиск как фильтр'}
          >
            <BookmarkPlus className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            {atCap ? `Максимум ${CAP} фильтров` : 'Сохранить текущий поиск'}
          </Button>
          {!canSave && (
            <p className="text-xs text-muted-foreground mt-1 leading-snug px-0.5">
              Активно, когда в главном окне есть поиск
            </p>
          )}
        </div>
      )}
    </div>
  );
}
