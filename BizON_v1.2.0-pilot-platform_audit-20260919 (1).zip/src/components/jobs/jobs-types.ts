// BizON — Jobs module shared types & constants (Task 7-b, «BIZON NEXT»)
// Общие контракты для intention-first главного экрана модуля «Работа».
// Бэкенд (GET /api/jobs с q/mode/important/..., parsedIntent, groups, matchTier)
// разворачивается параллельным агентом — все новые поля ОПЦИОНАЛЬНЫ,
// фронтенд обязан работать и со старым ответом { jobs: [...] }.
import type { JobPublic } from '@/lib/types';

// === Расширенная вакансия (новый контракт GET /api/jobs) ===
export interface JobExplanation {
  reasons?: string[];
  missing?: string[];
}

export interface JobWithExtras extends JobPublic {
  companyId?: string | null;
  currency?: string | null;
  salaryMin?: number | null;
  salaryMax?: number | null;
  level?: string | null;
  workFormat?: string | null;
  industry?: string | null;
  travelDaysPerMonth?: number | null;
  teamSize?: number | null;
  schedule?: string | null;
  matchTier?: 'exact' | 'strong' | 'adjacent' | string | null;
  verificationStatus?: string | null;
  vacancyTrust?: number | null;
  responseTimeHours?: number | null;
  hiringReality?: { score?: number; level?: string } | null;
  applicationStatus?: string | null;
  explanation?: JobExplanation | null;
}

// === Разбор намерения (режим «Своими словами») ===
export interface ParsedIntent {
  role?: string;
  industry?: string;
  location?: string;
  minSalary?: number;
  workFormat?: string;
  level?: string;
}

export interface JobsGroups {
  exact?: number;
  strong?: number;
  adjacent?: number;
}

export interface JobsApiResponse {
  jobs: JobWithExtras[];
  groups?: JobsGroups;
  parsedIntent?: ParsedIntent | null;
}

// === Opportunity Engine (GET /api/opportunities?type=job) ===
// Реальная форма (проверено curl'ом): { items: [{ id, type, title, description,
// companyId, jobId, requirements, skills, level, location, compensation, trust,
// freshness, relevance, intentAlignment, explanation, createdAt, action }] }.
export interface OpportunityItem {
  id: string;
  type: string;
  title: string;
  description?: string;
  companyId?: string | null;
  jobId?: string | null;
  level?: string | null;
  location?: string | null;
  compensation?: string | number | null;
  trust?: number;
  freshness?: number;
  relevance?: number;
  intentAlignment?: number;
  explanation?: string;
  // Возможные будущие поля (параллельный бэкенд) — читаем tolerantно:
  matchPercent?: number;
  match?: number;
  matchConfidence?: number;
  reasons?: string[];
  exploration?: boolean;
  explorationReason?: string;
  createdAt?: string;
}

// === Career Discovery (GET /api/me/career-discovery) ===
export interface CareerDiscoveryItem {
  jobId?: string;
  title: string;
  company?: string;
  companyId?: string | null;
  location?: string | null;
  matchPct?: number;
  reason?: string;
  matchedSkills?: string[];
  salaryMin?: number | null;
  salaryMax?: number | null;
  currency?: string | null;
}

export interface CareerDiscoveryResponse {
  currentSearch?: string[];
  discoveries?: CareerDiscoveryItem[];
  suggestions?: CareerDiscoveryItem[];
  reason?: string;
  userSkillsCount?: number;
  scannedJobs?: number;
}

// === Growth (GET /api/jobs/[id]/growth — контракт параллельного бэкенда) ===
export interface JobGrowthReadiness {
  skill: string;
  requiredLevel: number;
  currentLevel: number;
  ok: boolean;
}

export interface JobGrowthResponse {
  readiness?: JobGrowthReadiness[];
  actions?: string[];
  gives?: string[];
  forecast?: string;
}

// === Режимы поиска ===
export type JobSearchMode = 'quick' | 'nl' | 'precise' | 'explore';

export const SEARCH_MODES: Array<{ value: JobSearchMode; label: string; icon: string }> = [
  { value: 'quick', label: 'Быстро', icon: '🔎' },
  { value: 'nl', label: 'Своими словами', icon: '✍️' },
  { value: 'precise', label: 'Точно', icon: '🎯' },
  { value: 'explore', label: 'Исследовать', icon: '🔬' },
];

// === Чипы «Что для вас важно?» (точный режим) → параметр important=csv ===
export const IMPORTANT_CHIPS: Array<{ code: string; label: string }> = [
  { code: 'salary', label: 'Зарплата' },
  { code: 'remote', label: 'Удалённо' },
  { code: 'growth', label: 'Рост' },
  { code: 'leadership', label: 'Руководство' },
  { code: 'industry', label: 'Отрасль' },
  { code: 'stability', label: 'Стабильность' },
];

// === Карточки «Что для вас сейчас важнее?» (режим «Исследовать») ===
export const EXPLORE_GOALS: Array<{ code: string; label: string; hint: string; icon: string }> = [
  { code: 'salary', label: 'Больше дохода', hint: 'Вакансии с более высокой вилкой', icon: '💰' },
  { code: 'growth', label: 'Новый уровень', hint: 'Следующая ступень в карьере', icon: '📈' },
  { code: 'remote', label: 'Больше свободы', hint: 'Удалённая работа и гибкий график', icon: '🌴' },
  { code: 'industry', label: 'Сменить профессию', hint: 'Смежные роли и новые домены', icon: '🧭' },
  { code: 'leadership', label: 'Руководящая роль', hint: 'Управление командой и проектами', icon: '🧑‍💼' },
  { code: 'unsure', label: 'Пока не знаю', hint: 'Посмотрим вместе', icon: '✨' },
];

// === Опросник «Помогите BizON понять вас лучше» (Wave 11, отзыв п.1) ===
// 6 вопросов × один выбор; сохраняется в POST /api/me/preferences как
// exploreQuiz { q1..q6 → ответ }. White-list значений продублирован на бэке
// (src/app/api/me/preferences/route.ts, ALLOWED_QUIZ_VALUES) — списки
// синхронизированы, здесь — источник правды для UI.
export interface ExploreQuizOption {
  value: string;
  label: string;
}

export interface ExploreQuizQuestion {
  key: 'q1' | 'q2' | 'q3' | 'q4' | 'q5' | 'q6';
  question: string;
  options: ExploreQuizOption[];
}

export const EXPLORE_QUIZ_QUESTIONS: ExploreQuizQuestion[] = [
  {
    key: 'q1',
    question: 'Какая цель сейчас главнее?',
    options: [
      { value: 'income_growth', label: 'Рост дохода' },
      { value: 'new_experience', label: 'Новый опыт' },
      { value: 'stability', label: 'Стабильность' },
      { value: 'scale_role', label: 'Масштаб и роль' },
    ],
  },
  {
    key: 'q2',
    question: 'Какой формат работы удобен?',
    options: [
      { value: 'office', label: 'Офис' },
      { value: 'hybrid', label: 'Гибрид' },
      { value: 'remote', label: 'Удалёнка' },
      { value: 'any_format', label: 'Любой' },
    ],
  },
  {
    key: 'q3',
    question: 'Насколько важен доход прямо сейчас?',
    options: [
      { value: 'salary_critical', label: 'Критично' },
      { value: 'salary_important', label: 'Важен, но не первый' },
      { value: 'salary_secondary', label: 'Вторичен' },
    ],
  },
  {
    key: 'q4',
    question: 'Готовы ли к командировкам?',
    options: [
      { value: 'travel_often', label: 'Да, часто' },
      { value: 'travel_sometimes', label: 'Иногда' },
      { value: 'travel_no', label: 'Нет' },
    ],
  },
  {
    key: 'q5',
    question: 'Что интереснее?',
    options: [
      { value: 'same_domain', label: 'Укрепить текущую сферу' },
      { value: 'adjacent_domain', label: 'Смежная сфера' },
      { value: 'new_domain', label: 'Полная смена сферы' },
    ],
  },
  {
    key: 'q6',
    question: 'Какую роль рассматриваете?',
    options: [
      { value: 'same_level', label: 'Как сейчас' },
      { value: 'next_level', label: 'Выше уровнем' },
      { value: 'switch_direction', label: 'Смена направления' },
    ],
  },
];

/** Ответы опросника: ключ вопроса → значение (tolerant к ответу API). */
export type ExploreQuizAnswers = Record<string, string>;

/** White-list для бэка/фронта: ключ вопроса → допустимые значения. */
export const EXPLORE_QUIZ_ALLOWED: Record<string, string[]> = Object.fromEntries(
  EXPLORE_QUIZ_QUESTIONS.map(q => [q.key, q.options.map(o => o.value)]),
);

// === Честный маппинг ответов опросника на реальные code'ы EXPLORE_GOALS ===
// Только ПРЯМЫЕ смысловые соответствия. Ответ без пары (stability — такого
// кода в EXPLORE_GOALS нет, форматы «офис/гибрид/любой», командировки,
// «доход вторичен» и т.п.) НЕ маппится — выдуманных кодов нет.
export const EXPLORE_QUIZ_TO_GOALS: Record<string, string> = {
  income_growth: 'salary',     // «Рост дохода» → «Больше дохода»
  new_experience: 'growth',    // «Новый опыт» → «Новый уровень»
  scale_role: 'leadership',    // «Масштаб и роль» → «Руководящая роль»
  remote: 'remote',            // q2 «Удалёнка» → «Больше свободы» (удалёнка/гибкий график)
  salary_critical: 'salary',   // q3 «Критично» → «Больше дохода»
  next_level: 'growth',        // q6 «Выше уровнем» → «Новый уровень»
  adjacent_domain: 'industry', // q5 «Смежная сфера» → «Сменить профессию» (смежные роли и домены)
  new_domain: 'industry',      // q5 «Полная смена сферы» → «Сменить профессию»
};

/** Ответы опросника → уникальные code'ы целей «Исследовать» (валидные из EXPLORE_GOALS). */
export function quizToGoalCodes(quiz: ExploreQuizAnswers): string[] {
  const codes = new Set<string>();
  for (const value of Object.values(quiz)) {
    const code = EXPLORE_QUIZ_TO_GOALS[value];
    if (code && EXPLORE_GOALS.some(g => g.code === code)) codes.add(code);
  }
  return Array.from(codes);
}

// === Причины «Не моё» (Explicit Negative Intent) ===
export const NOT_MINE_REASONS: Array<{ code: string; label: string }> = [
  { code: 'salary', label: 'Зарплата' },
  { code: 'location', label: 'Локация' },
  { code: 'company', label: 'Компания' },
  { code: 'profession', label: 'Не хочу эту профессию' },
  { code: 'level_too_low', label: 'Слишком низкий уровень' },
  { code: 'level_too_high', label: 'Слишком высокий уровень' },
  { code: 'travel', label: 'Командировки' },
  { code: 'schedule', label: 'График' },
  { code: 'industry', label: 'Неинтересная отрасль' },
  { code: 'other', label: 'Другое' },
];

// === Утилиты ===

/** Зарплатная строка: приоритет salaryMin/Max, fallback salaryFrom/To. */
export function formatSalaryText(job: {
  salaryMin?: number | null; salaryMax?: number | null;
  salaryFrom?: number | null; salaryTo?: number | null;
  currency?: string | null;
}): string | null {
  const from = job.salaryMin ?? job.salaryFrom;
  const to = job.salaryMax ?? job.salaryTo;
  if (!from && !to) return null;
  const cur = job.currency === 'RUB' || !job.currency ? '₽' : job.currency === 'USD' ? '$' : job.currency === 'EUR' ? '€' : job.currency;
  if (from && to) return `${from.toLocaleString('ru-RU')}–${to.toLocaleString('ru-RU')} ${cur}`;
  if (from) return `от ${from.toLocaleString('ru-RU')} ${cur}`;
  return `до ${to!.toLocaleString('ru-RU')} ${cur}`;
}

/** Классы match-бейджа по «Маяку»: высокий → emerald, средний → amber, низкий → muted. */
export function matchBadgeClass(percent: number): string {
  if (percent >= 70) return 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30';
  if (percent >= 40) return 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30';
  return 'bg-muted text-muted-foreground border-border';
}

/** Разбор explanation в список коротких причин (tolerant к строке или массиву). */
export function reasonsToList(item: { explanation?: string; reasons?: string[] }): string[] {
  if (Array.isArray(item.reasons) && item.reasons.length > 0) {
    return item.reasons.map(r => String(r).trim()).filter(Boolean).slice(0, 3);
  }
  if (typeof item.explanation === 'string' && item.explanation.trim()) {
    return item.explanation
      .split(/[·•]\s*|\.\s+/)
      .map(s => s.trim())
      .filter(Boolean)
      .slice(0, 3);
  }
  return [];
}

/** match% для карточки Opportunity (tolerant: новые поля → композит из relevance/intent/trust). */
export function opportunityMatch(o: OpportunityItem): number {
  if (typeof o.matchPercent === 'number') return Math.round(o.matchPercent);
  if (typeof o.match === 'number') return Math.round(o.match <= 1 ? o.match * 100 : o.match);
  if (typeof o.matchConfidence === 'number') return Math.round(o.matchConfidence * 100);
  const relevance = typeof o.relevance === 'number' ? o.relevance : 0;
  const intent = typeof o.intentAlignment === 'number' ? o.intentAlignment : 0;
  const trust = typeof o.trust === 'number' ? o.trust : 0;
  return Math.round(Math.min(1, relevance * 0.5 + intent * 0.3 + trust * 0.2) * 100);
}

/** Подпись уровня matchTier для счётчиков-фильтров. */
export function tierLabel(tier: 'exact' | 'strong' | 'adjacent'): string {
  if (tier === 'exact') return 'Точное соответствие';
  if (tier === 'strong') return 'Сильное';
  return 'Смежные';
}
