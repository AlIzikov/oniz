// BizON — «Мой путь» (My Path View, Task 10-d)
//
// Личный Job Pipeline (Стратегия п.18): стадии из JOBS_PIPELINE_CONFIG
// (Ищу → Сохранил → Откликнулся → HR просмотрел → Интервью → Предложение → Принял),
// отклонённые — отдельная секция с причиной (rejectReason).
//
// Переключатель статусов (Task 10-d): для откликов на стадиях от «Откликнулся»
// (submitted и дальше) — меню переходов по пайплайну через готовый бэкенд
// PATCH /api/applications/[id]/status (зона 7-d — только потребляем):
//   • вперёд с пропуском стадий разрешён, назад запрещён (зеркало STAGE_ORDER API);
//   • accepted → hired — единственный переход внутри финальной стадии;
//   • rejected — из любой стадии после отправки, ОБЯЗАТЕЛЬНАЯ причина (select);
//   • rejected/withdrawn — терминальные (меню не показывается).
// Оптимистичный UI + rollback при ошибке + toast (паттерн проекта).
//
// Дизайн: navy + teal (lighthouse-токен); red — только rejected (сдержанный
// destructive-токен). Mobile-first 390px: стадии — горизонтальный скролл
// (snap-x), карточки колонок — max-h + overflow-y-auto. Без violet/indigo.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import {
  JOBS_PIPELINE_CONFIG,
  type JobApplicationStatus,
} from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import {
  RefreshCw,
  ChevronDown,
  SearchX,
  Map as MapIcon,
  Bookmark,
  FileText,
  Eye,
  Users2,
  Gift,
  CheckCircle2,
  XCircle,
  Ban,
  CircleDashed,
  Send,
  BriefcaseBusiness,
  X,
  Loader2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';

// ===========================================================================
// Типы данных
// ===========================================================================

/** Отклик из GET /api/jobs/applications (потребляем tolerantно) */
interface PathApplication {
  id: string;
  status: string; // JobApplicationStatus | 'withdrawn' — проверяем в рантайме
  matchConfidence?: number | null;
  appliedAt: string;
  /** Локальное поле: history/rejectReason приходят из PATCH-ответов (GET их не отдаёт) */
  rejectReason?: string | null;
  statusHistory?: Array<{ status: string; at: string; reason?: string }>;
  job: {
    id: string;
    title: string;
    company: string;
    location?: string | null;
    salaryFrom?: number | null;
    salaryTo?: number | null;
    requiredSkills?: string[];
  };
}

/** Сохранённая вакансия для шага «Сохранил» (модель SavedJob, без статусов) */
interface SavedJobLite {
  id: string;
  title: string;
  company?: string | null;
  location?: string | null;
}

/** Ответ PATCH /api/applications/[id]/status */
interface StatusPatchResponse {
  application: {
    id: string;
    status: string;
    previousStatus: string;
    rejectReason: string | null;
    statusHistory: Array<{ status: string; at: string; reason?: string }>;
  };
  changed: boolean;
  message?: string;
}

// ===========================================================================
// Константы: зеркала правил бэкенда PATCH /api/applications/[id]/status
// (маршрут 7-d не меняем — UI обязан предлагать только валидные переходы)
// ===========================================================================

/** Порядок стадий (чем больше — тем дальше по «Моему пути»), зеркало STAGE_ORDER API */
const STAGE_ORDER: Record<string, number> = {
  draft: 0,
  preparing: 1,
  submitted: 2,
  viewed: 3,
  reviewed: 4,
  interview: 5,
  offer: 6,
  accepted: 7,
  hired: 7,
};

const TERMINAL_STATUSES = new Set(['rejected', 'withdrawn']);

/** Человекочитаемые подписи статусов (для меню и бейджей) */
export const STATUS_LABELS: Record<JobApplicationStatus, string> = {
  draft: 'Черновик',
  preparing: 'Готовлюсь',
  submitted: 'Откликнулся',
  viewed: 'HR просмотрел',
  reviewed: 'HR изучил',
  interview: 'Интервью',
  offer: 'Предложение',
  accepted: 'Принял',
  hired: 'Вышел на работу',
  rejected: 'Отклонён',
};

/**
 * Разрешённые цели перехода для текущего статуса — зеркало валидации бэкенда:
 * вперёд по STAGE_ORDER (пропуск стадий разрешён), accepted→hired,
 * rejected — из любой стадии ПОСЛЕ отправки. Терминальные — без переходов.
 */
export function allowedTargets(current: string): JobApplicationStatus[] {
  if (TERMINAL_STATUSES.has(current)) return [];
  const curOrder = STAGE_ORDER[current];
  if (curOrder === undefined || curOrder < STAGE_ORDER.submitted) return []; // меню только от «Откликнулся»
  const forward = (['preparing', 'submitted', 'viewed', 'reviewed', 'interview', 'offer', 'accepted'] as JobApplicationStatus[])
    .filter((s) => (STAGE_ORDER[s] ?? -1) > curOrder);
  const targets: JobApplicationStatus[] = [...forward];
  if (current === 'accepted') targets.push('hired'); // единственный переход внутри финальной стадии
  targets.push('rejected'); // из submitted+ — в любую сторону цикла
  return targets;
}

/** Причины отказа для rejected (select, обязательная по API) */
const REJECT_REASONS: Array<{ code: string; label: string }> = [
  { code: 'salary', label: 'Зарплата ниже ожиданий' },
  { code: 'location', label: 'Локация / удалённость' },
  { code: 'schedule', label: 'График или нагрузка' },
  { code: 'chose_other', label: 'Выбрал другую вакансию' },
  { code: 'role_fit', label: 'Роль не подошла' },
  { code: 'company', label: 'Разонналась компания' },
  { code: 'other', label: 'Другое (укажу сам)' },
];

/** Иконка стадии (по id шага JOBS_PIPELINE_CONFIG) */
function stepIcon(stepId: string): React.ReactNode {
  switch (stepId) {
    case 'searching': return <CircleDashed className="w-3.5 h-3.5" aria-hidden="true" />;
    case 'saved': return <Bookmark className="w-3.5 h-3.5" aria-hidden="true" />;
    case 'applied': return <Send className="w-3.5 h-3.5" aria-hidden="true" />;
    case 'viewed': return <Eye className="w-3.5 h-3.5" aria-hidden="true" />;
    case 'interview': return <Users2 className="w-3.5 h-3.5" aria-hidden="true" />;
    case 'offer': return <Gift className="w-3.5 h-3.5" aria-hidden="true" />;
    case 'accepted': return <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />;
    default: return <BriefcaseBusiness className="w-3.5 h-3.5" aria-hidden="true" />;
  }
}

function formatSalaryRange(from?: number | null, to?: number | null): string | null {
  if (from != null && to != null) return `${from.toLocaleString('ru-RU')}–${to.toLocaleString('ru-RU')} ₽`;
  if (to != null) return `до ${to.toLocaleString('ru-RU')} ₽`;
  if (from != null) return `от ${from.toLocaleString('ru-RU')} ₽`;
  return null;
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
  } catch {
    return '';
  }
}

function pluralApps(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'отклик';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'отклика';
  return 'откликов';
}

// ===========================================================================
// Главный компонент
// ===========================================================================

export function MyPathView() {
  const setView = useAppStore((s) => s.setView);

  const [loading, setLoading] = React.useState(true);
  const [loadError, setLoadError] = React.useState<string | null>(null);
  const [applications, setApplications] = React.useState<PathApplication[]>([]);
  const [savedJobs, setSavedJobs] = React.useState<SavedJobLite[]>([]);
  const [savedFailed, setSavedFailed] = React.useState(false);
  /** id откликов, у которых прямо сейчас идёт PATCH (для спиннеров) */
  const [pendingIds, setPendingIds] = React.useState<Set<string>>(new Set());
  /** Диалог причины отказа: { applicationId, jobTitle, rollback: () => void } | null */
  const [rejectDialog, setRejectDialog] = React.useState<{
    application: PathApplication;
    prev: PathApplication;
  } | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await api<{ applications?: PathApplication[]; total?: number }>('/api/jobs/applications');
      setApplications(Array.isArray(res.applications) ? res.applications : []);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Не удалось загрузить отклики';
      setLoadError(msg);
    } finally {
      setLoading(false);
    }
    // Сохранённые — для шага «Сохранил» (независимо, чтобы ошибка не роняла вкладку)
    try {
      const saved = await api<{ jobs?: Array<Record<string, unknown>> }>('/api/jobs/saved');
      const jobs = Array.isArray(saved.jobs) ? saved.jobs : [];
      setSavedJobs(jobs.map((j) => ({
        id: typeof j.id === 'string' ? j.id : String(j.id ?? ''),
        title: typeof j.title === 'string' ? j.title : 'Вакансия',
        company: typeof j.company === 'string' ? j.company : null,
        location: typeof j.location === 'string' ? j.location : null,
      })).filter((j) => j.id));
      setSavedFailed(false);
    } catch {
      setSavedJobs([]);
      setSavedFailed(true);
    }
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  // === Оптимистичное обновление статуса + rollback =========================

  const patchStatus = React.useCallback(async (
    app: PathApplication,
    prev: PathApplication,
    target: JobApplicationStatus,
    rejectReason: string | null,
  ) => {
    // Оптимистично двигаем статус (откат — если API отклонит)
    setApplications((list) => list.map((a) =>
      a.id === app.id
        ? {
            ...a,
            status: target,
            rejectReason: target === 'rejected' ? (rejectReason ?? a.rejectReason) : a.rejectReason,
          }
        : a,
    ));
    setPendingIds((s) => new Set(s).add(app.id));
    try {
      const res = await api<StatusPatchResponse>(`/api/applications/${app.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify(
          target === 'rejected'
            ? { status: target, rejectReason }
            : { status: target },
        ),
      });
      // Сервер — источник истины: statusHistory/rejectReason из ответа
      setApplications((list) => list.map((a) =>
        a.id === app.id
          ? {
              ...a,
              status: res.application.status,
              rejectReason: res.application.rejectReason,
              statusHistory: res.application.statusHistory,
            }
          : a,
      ));
      if (res.changed) {
        toast({
          title: `Статус: ${STATUS_LABELS[target as JobApplicationStatus] ?? target}`,
          description: `«${app.job.title}» — обновлено в «Моём пути»`,
        });
      } else {
        toast({ title: 'Отклик уже в этом статусе' });
      }
    } catch (e: unknown) {
      // Rollback к предыдущему состоянию карточки
      setApplications((list) => list.map((a) => (a.id === app.id ? prev : a)));
      const msg = e instanceof Error ? e.message : 'Не удалось сменить статус';
      toast({ title: 'Переход не выполнен', description: msg, variant: 'destructive' });
    } finally {
      setPendingIds((s) => {
        const next = new Set(s);
        next.delete(app.id);
        return next;
      });
    }
  }, []);

  /** Клик по цели в меню: rejected — через диалог причины, остальные — сразу */
  const handleTargetClick = React.useCallback((app: PathApplication, target: JobApplicationStatus) => {
    if (target === 'rejected') {
      setRejectDialog({ application: app, prev: app });
    } else {
      void patchStatus(app, app, target, null);
    }
  }, [patchStatus]);

  const current = React.useMemo(
    () => applications.find((a) => a.id === rejectDialog?.application.id) ?? rejectDialog?.application ?? null,
    [applications, rejectDialog],
  );

  // === Группировка по стадиям JOBS_PIPELINE_CONFIG ==========================

  const withdrawnCount = React.useMemo(
    () => applications.filter((a) => a.status === 'withdrawn').length,
    [applications],
  );

  const stepColumns = React.useMemo(() => (
    JOBS_PIPELINE_CONFIG.steps.map((step) => {
      if (step.source === 'saved') {
        return { step, apps: [] as PathApplication[], saved: savedJobs };
      }
      const apps = applications.filter((a) => step.statuses.includes(a.status as JobApplicationStatus));
      return { step, apps, saved: [] as SavedJobLite[] };
    })
  ), [applications, savedJobs]);

  const rejectedApps = React.useMemo(
    () => applications.filter((a) => a.status === 'rejected'),
    [applications],
  );

  const activeCount = React.useMemo(
    () => applications.filter((a) => !TERMINAL_STATUSES.has(a.status)).length,
    [applications],
  );

  // =========================================================================
  // Рендер
  // =========================================================================

  return (
    <div className="space-y-4 w-full min-w-0">
      {/* Заголовок */}
      <div className="flex items-baseline justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <MapIcon className="w-5 h-5 text-lighthouse shrink-0" aria-hidden="true" />
            Мой путь
          </h1>
          <p className="text-sm text-muted-foreground">
            Карьерный цикл откликов: от «Откликнулся» до «Принял».
            {activeCount > 0 && <> В пути — {activeCount} {pluralApps(activeCount)}.</>}
            {withdrawnCount > 0 && <> Отозванных: {withdrawnCount} (не отображаются).</>}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading} aria-label="Обновить «Мой путь»">
          <RefreshCw className={cn('w-4 h-4', loading && 'animate-spin')} aria-hidden="true" />
          Обновить
        </Button>
      </div>

      {/* Загрузка */}
      {loading && (
        <div className="flex gap-3 overflow-hidden" aria-hidden="true">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="min-w-[230px] flex-1 space-y-2">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          ))}
        </div>
      )}

      {/* Ошибка загрузки — вкладка не падает, есть повтор */}
      {loadError && !loading && (
        <Card>
          <CardContent className="p-6 text-center space-y-3">
            <XCircle className="w-8 h-8 mx-auto text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">{loadError}</p>
            <Button variant="outline" size="sm" onClick={load}>Попробовать снова</Button>
          </CardContent>
        </Card>
      )}

      {/* Лента стадий: mobile — горизонтальный скролл, xl — сетка 7 */}
      {!loading && !loadError && (
        <div
          className="flex gap-3 overflow-x-auto scroll-area-thin pb-2 -mx-4 px-4 snap-x xl:grid xl:grid-cols-7 xl:overflow-visible xl:mx-0 xl:px-0"
          role="list"
          aria-label="Стадии «Моего пути»"
        >
          {stepColumns.map(({ step, apps, saved }) => {
            const isEmpty = step.source === 'saved' ? saved.length === 0 : apps.length === 0;
            return (
              <section
                key={step.id}
                role="listitem"
                aria-label={`${step.label}: ${step.source === 'saved' ? saved.length : apps.length}`}
                className="min-w-[230px] w-[230px] flex-shrink-0 snap-start xl:min-w-0 xl:w-auto flex flex-col rounded-lg border bg-card/50"
              >
                {/* Шапка стадии */}
                <div className="flex items-center gap-1.5 px-2.5 py-2 border-b bg-muted/30 rounded-t-lg">
                  <span className="text-lighthouse shrink-0">{stepIcon(step.id)}</span>
                  <span className="text-xs font-semibold truncate">{step.label}</span>
                  <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground tabular-nums">
                    {step.source === 'saved' ? saved.length : apps.length}
                  </span>
                </div>

                {/* Карточки стадии */}
                <div className="p-2 space-y-2 max-h-80 overflow-y-auto scroll-area-thin flex-1">
                  {isEmpty && (
                    <p className="text-xs text-muted-foreground text-center py-4 px-1">
                      {step.source === 'saved' && savedFailed
                        ? 'Не удалось загрузить сохранённые'
                        : 'Пока пусто'}
                    </p>
                  )}

                  {/* Шаг «Сохранил» — SavedJob без статус-меню */}
                  {step.source === 'saved' && saved.map((j) => (
                    <div key={j.id} className="rounded-md border p-2 bg-background space-y-1">
                      <div className="text-xs font-medium leading-snug line-clamp-2">{j.title}</div>
                      <div className="text-xs text-muted-foreground truncate">
                        {[j.company, j.location].filter(Boolean).join(' · ') || '—'}
                      </div>
                      <button
                        type="button"
                        onClick={() => setView('jobs')}
                        className="text-xs text-lighthouse hover:underline"
                      >
                        Продолжить отклик →
                      </button>
                    </div>
                  ))}

                  {/* Отклики стадии */}
                  {step.source === 'applications' && apps.map((app) => (
                    <PathCard
                      key={app.id}
                      app={app}
                      pending={pendingIds.has(app.id)}
                      onTarget={(target) => handleTargetClick(app, target)}
                    />
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}

      {/* Отклонённые — отдельная секция с причиной (JOBS_PIPELINE_CONFIG.rejected) */}
      {!loading && !loadError && (
        <section aria-label="Отклонённые отклики" className="space-y-2">
          <div className="flex items-center gap-2">
            <XCircle className="w-4 h-4 text-destructive/80 shrink-0" aria-hidden="true" />
            <h2 className="text-sm font-semibold">
              {JOBS_PIPELINE_CONFIG.rejected.label}
              {rejectedApps.length > 0 && (
                <span className="ml-1.5 text-xs font-normal text-muted-foreground tabular-nums">
                  {rejectedApps.length}
                </span>
              )}
            </h2>
          </div>
          {rejectedApps.length === 0 ? (
            <p className="text-xs text-muted-foreground">Пока пусто — и это нормально.</p>
          ) : (
            <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
              {rejectedApps.map((app) => (
                <div
                  key={app.id}
                  className="rounded-md border border-destructive/25 bg-destructive/5 p-2.5 space-y-1"
                >
                  <div className="text-xs font-medium leading-snug">{app.job.title}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {[app.job.company, app.job.location].filter(Boolean).join(' · ') || '—'}
                  </div>
                  <div className="text-xs text-destructive/90">
                    <span className="font-medium">Причина: </span>
                    {app.rejectReason || 'не указана'}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Диалог причины отказа (rejected — обязательная причина, select) */}
      <RejectReasonDialog
        open={rejectDialog !== null}
        application={current}
        pending={current ? pendingIds.has(current.id) : false}
        onCancel={() => {
          // Отмена диалога — откатываем оптимистичное перемещение в rejected
          if (rejectDialog) {
            setApplications((list) => list.map((a) => (a.id === rejectDialog.prev.id ? rejectDialog.prev : a)));
          }
          setRejectDialog(null);
        }}
        onConfirm={(reason) => {
          if (!current) return;
          void patchStatus(current, rejectDialog?.prev ?? current, 'rejected', reason);
          setRejectDialog(null);
        }}
      />
    </div>
  );
}

// ===========================================================================
// Карточка отклика в стадии (+ меню смены статуса)
// ===========================================================================

function PathCard({
  app,
  pending,
  onTarget,
}: {
  app: PathApplication;
  pending: boolean;
  onTarget: (target: JobApplicationStatus) => void;
}) {
  const targets = React.useMemo(() => allowedTargets(app.status), [app.status]);
  const salary = formatSalaryRange(app.job.salaryFrom, app.job.salaryTo);
  const canTransition = targets.length > 0;

  return (
    <div className="rounded-md border p-2 bg-background space-y-1.5">
      <div className="flex items-start justify-between gap-1.5">
        <div className="text-xs font-medium leading-snug line-clamp-2 min-w-0">{app.job.title}</div>
        {pending && <Loader2 className="w-3 h-3 animate-spin text-muted-foreground shrink-0 mt-0.5" aria-hidden="true" />}
      </div>
      <div className="text-xs text-muted-foreground truncate">
        {[app.job.company, app.job.location].filter(Boolean).join(' · ') || '—'}
      </div>
      <div className="flex items-center gap-1.5 flex-wrap">
        <Badge variant="secondary" className="text-xs px-1 py-0 h-4">
          {STATUS_LABELS[app.status as JobApplicationStatus] ?? app.status}
        </Badge>
        {typeof app.matchConfidence === 'number' && app.matchConfidence > 0 && (
          <>
            <span className="text-xs text-muted-foreground tabular-nums">
              match {Math.round(app.matchConfidence * 100)}%
            </span>
            <TermInfo k="match_tier" />
          </>
        )}
        <span className="text-xs text-muted-foreground/70 ml-auto">{formatDate(app.appliedAt)}</span>
      </div>
      {salary && <div className="text-xs text-lighthouse">{salary}</div>}

      {/* Переключатель статусов — только от «Откликнулся» и не для терминальных */}
      {canTransition && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="w-full h-7 text-xs px-2 gap-1"
              disabled={pending}
              aria-label={`Сменить статус отклика «${app.job.title}», сейчас: ${STATUS_LABELS[app.status as JobApplicationStatus] ?? app.status}`}
            >
              Сменить статус
              <ChevronDown className="w-3 h-3" aria-hidden="true" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-52">
            <DropdownMenuLabel className="text-xs text-muted-foreground">
              Перевести дальше (только вперёд)
            </DropdownMenuLabel>
            {/* Не-rejected цели — вверх по пайплайну */}
            {targets.filter((t) => t !== 'rejected').map((t) => (
              <DropdownMenuItem key={t} onClick={() => onTarget(t)} className="text-xs">
                {t === 'hired' ? <CheckCircle2 className="w-3.5 h-3.5 text-lighthouse" aria-hidden="true" /> : <FileText className="w-3.5 h-3.5 text-muted-foreground" aria-hidden="true" />}
                {STATUS_LABELS[t]}
              </DropdownMenuItem>
            ))}
            {targets.includes('rejected') && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => onTarget('rejected')}
                  className="text-xs text-destructive focus:text-destructive"
                >
                  <Ban className="w-3.5 h-3.5" aria-hidden="true" />
                  {STATUS_LABELS.rejected} — нужна причина
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
}

// ===========================================================================
// Диалог причины отказа
// ===========================================================================

function RejectReasonDialog({
  open,
  application,
  pending,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  application: PathApplication | null;
  pending: boolean;
  onCancel: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reasonCode, setReasonCode] = React.useState<string>('');
  const [customReason, setCustomReason] = React.useState('');

  // Сброс выбора при открытии диалога под новый отклик
  React.useEffect(() => {
    if (open) {
      setReasonCode('');
      setCustomReason('');
    }
  }, [open, application?.id]);

  const selected = REJECT_REASONS.find((r) => r.code === reasonCode) ?? null;
  const isCustom = selected?.code === 'other';
  const finalReason = isCustom ? customReason.trim() : selected?.label ?? '';
  const canSubmit = finalReason.length > 0 && finalReason.length <= 500 && !pending;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onCancel(); }}>
      <DialogContent className="sm:max-w-md" aria-describedby="reject-reason-desc">
        <DialogHeader>
          <DialogTitle className="text-base flex items-center gap-2">
            <XCircle className="w-4 h-4 text-destructive" aria-hidden="true" />
            Отклонить отклик
          </DialogTitle>
          <DialogDescription id="reject-reason-desc" className="text-xs">
            «{application?.job.title ?? ''}». Укажите причину — она сохранится в истории отклика
            и поможет честно оценить «Мой путь».
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2.5">
          <div>
            <label htmlFor="reject-reason-select" className="text-xs font-medium text-muted-foreground">
              Причина отказа
            </label>
            <Select value={reasonCode} onValueChange={setReasonCode}>
              <SelectTrigger id="reject-reason-select" className="w-full mt-1" aria-label="Причина отказа">
                <SelectValue placeholder="Выберите причину…" />
              </SelectTrigger>
              <SelectContent>
                {REJECT_REASONS.map((r) => (
                  <SelectItem key={r.code} value={r.code} className="text-xs">
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isCustom && (
            <div>
              <label htmlFor="reject-reason-custom" className="text-xs font-medium text-muted-foreground">
                Своя формулировка
              </label>
              <Input
                id="reject-reason-custom"
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                maxLength={500}
                placeholder="Например: удалённость офиса"
                className="mt-1 h-8 text-xs"
                autoFocus
              />
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="ghost" size="sm" onClick={onCancel} disabled={pending}>
            <X className="w-3.5 h-3.5 mr-1" aria-hidden="true" />
            Отмена
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={() => onConfirm(finalReason)}
            disabled={!canSubmit}
          >
            {pending && <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" aria-hidden="true" />}
            Отклонить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
