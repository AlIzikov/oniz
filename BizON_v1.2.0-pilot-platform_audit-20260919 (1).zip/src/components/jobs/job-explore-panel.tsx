// BizON — JobExplorePanel (Task 7-b, «BIZON NEXT» стр. 21-22 — режим «Исследовать»;
// Wave 11, отзыв пользователя).
// Блок «Что для вас сейчас важнее?» — 6 компактных карточек-чипов, выбор БЕЗ
// лимита (отзыв п.2: человек может отметить ВСЕ цели) → GET /api/jobs?mode=explore&important=...
// + опросник ExploreQuiz (отзыв п.1): ответы → /api/me/preferences.exploreQuiz,
// честный маппинг на цели (quizToGoalCodes) предзаполняет выбор.
// + блок «Карьерные сценарии» из GET /api/me/career-discovery (TermTooltip п.4).
// Graceful: если discoveries пусты — показываем currentSearch как «роли, которые вы уже рассматривали».
'use client';

import * as React from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { Compass, Sparkles } from 'lucide-react';
import { TermTooltip, TermInfo } from '@/components/common/term-tooltip';
import { ExploreQuiz } from '@/components/jobs/explore-quiz';
import {
  EXPLORE_GOALS,
  quizToGoalCodes,
  type CareerDiscoveryResponse,
  type ExploreQuizAnswers,
} from '@/components/jobs/jobs-types';

interface JobExplorePanelProps {
  goals: Set<string>;
  onGoalsChange: (goals: Set<string>) => void;
  discovery: CareerDiscoveryResponse | null;
  discoveryLoading: boolean;
  onPickRole: (role: string) => void;
}

export function JobExplorePanel({ goals, onGoalsChange, discovery, discoveryLoading, onPickRole }: JobExplorePanelProps) {
  // Источник текущего выбора целей: 'quiz' — предзаполнено опросником,
  // 'user' — человек кликал сам. Показываем подпись только для 'quiz'.
  const [goalSource, setGoalSource] = React.useState<'quiz' | 'user' | null>(null);
  const userTouchedRef = React.useRef(false);
  const mountImpactDoneRef = React.useRef(false);

  // Свежее зеркало goals для колбэка из опросника (маунт-влияние применяется
  // только когда человек ещё не выбирал цели сам).
  const goalsRef = React.useRef(goals);
  React.useEffect(() => {
    goalsRef.current = goals;
  }, [goals]);

  function toggleGoal(code: string) {
    userTouchedRef.current = true;
    setGoalSource('user');
    const next = new Set(goals);
    if (next.has(code)) {
      next.delete(code);
    } else {
      next.add(code);
    }
    onGoalsChange(next);
  }

  // Влияние опросника: маппим ответы на дефолтные цели (честный маппинг,
  // только если человек ещё не выбирал сам). onGoalsChange в родителе
  // одновременно запускает подбор с новыми целями.
  const handleQuizImpact = React.useCallback(
    (answers: ExploreQuizAnswers, source: 'mount' | 'save') => {
      if (userTouchedRef.current) return; // цели выбрал человек — не трогаем
      if (source === 'mount' && mountImpactDoneRef.current) return; // повторный маунт/StrictMode
      mountImpactDoneRef.current = true;
      const codes = quizToGoalCodes(answers);
      if (codes.length === 0) return; // нет честного соответствия — не маппим
      if (goalsRef.current.size > 0) return; // цели уже выбраны — предзаполнение не нужно
      onGoalsChange(new Set(codes));
      setGoalSource('quiz');
    },
    [onGoalsChange],
  );

  // Сценарии: сначала discoveries (роли, которые вы не искали), потом currentSearch
  const discovered = (discovery?.discoveries ?? discovery?.suggestions ?? []).slice(0, 4);
  const currentSearch = (discovery?.currentSearch ?? []).slice(0, 4);

  return (
    <div className="space-y-4">
      {/* === «Что для вас сейчас важнее?» === */}
      <div className="rounded-xl border bg-muted/20 p-4 space-y-3">
        <div className="flex items-center justify-between gap-x-2 gap-y-1 flex-wrap">
          <div className="text-sm font-semibold flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-lighthouse" aria-hidden="true" />
            Что для вас сейчас важнее?
            <TermInfo k="explore_mode" />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {goalSource === 'quiz' && goals.size > 0 && (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-lighthouse">
                <Sparkles className="w-3 h-3" aria-hidden="true" />
                учитываем ваш опросник
              </span>
            )}
            <span className="text-xs text-muted-foreground">отметьте всё, что важно — можно несколько</span>
          </div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
          {EXPLORE_GOALS.map(goal => {
            const active = goals.has(goal.code);
            return (
              <button
                key={goal.code}
                type="button"
                onClick={() => toggleGoal(goal.code)}
                aria-pressed={active}
                className={cn(
                  'text-left rounded-lg border p-2.5 transition',
                  active
                    ? 'border-lighthouse bg-lighthouse/5 ring-1 ring-lighthouse/40'
                    : 'hover:border-lighthouse/40 hover:bg-accent/50',
                )}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-base leading-none shrink-0" aria-hidden="true">{goal.icon}</span>
                  <span className="text-xs font-medium leading-tight">{goal.label}</span>
                </div>
                <div className="text-xs text-muted-foreground mt-1 leading-snug">{goal.hint}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* === Опросник «Помогите BizON понять вас лучше» === */}
      <ExploreQuiz onQuizImpact={handleQuizImpact} />

      {/* === Карьерные сценарии (Career Discovery) === */}
      <div className="space-y-2">
        <div className="text-sm font-semibold flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-lighthouse" aria-hidden="true" />
          <TermTooltip k="career_scenario" term="Карьерные сценарии" />
        </div>

        {discoveryLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)}
          </div>
        ) : discovered.length > 0 ? (
          <>
            <p className="text-xs text-muted-foreground">Роли, которые вы сами не искали, но профиль подсказывает:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {discovered.map((d, i) => (
                <button
                  key={d.jobId ?? `${d.title}-${i}`}
                  type="button"
                  onClick={() => onPickRole(d.title)}
                  className="text-left rounded-lg border p-3 hover:border-lighthouse/50 hover:bg-accent/50 transition group"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium leading-tight group-hover:text-lighthouse transition-colors">{d.title}</span>
                    {typeof d.matchPct === 'number' && (
                      <span className="flex-shrink-0 text-xs font-bold tabular-nums text-lighthouse">{d.matchPct}%</span>
                    )}
                  </div>
                  {d.reason && <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{d.reason}</div>}
                </button>
              ))}
            </div>
          </>
        ) : currentSearch.length > 0 ? (
          <>
            <p className="text-xs text-muted-foreground">Роли, которые вы уже рассматривали:</p>
            <div className="flex flex-wrap gap-1.5">
              {currentSearch.map(role => (
                <button
                  key={role}
                  type="button"
                  onClick={() => onPickRole(role)}
                  className="px-3 py-1.5 rounded-full text-xs border hover:border-lighthouse hover:text-lighthouse transition"
                >
                  {role}
                </button>
              ))}
            </div>
          </>
        ) : (
          <p className="text-xs text-muted-foreground">
            Подтвердите навыки в профиле — и BizON предложит карьерные сценарии, которые вы могли не заметить.
          </p>
        )}
      </div>
    </div>
  );
}
