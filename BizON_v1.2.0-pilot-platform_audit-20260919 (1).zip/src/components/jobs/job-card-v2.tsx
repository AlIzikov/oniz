// BizON — Job Card v2 (Этап 5.2 JOB блок: Вакансии v2)
// 4-уровневая карточка:
//   Уровень 1 (мгновенный скан): должность / компания / зарплата / локация / match%
//   Уровень 2 (быстрый просмотр): опыт / навыки / тип / команда / hiring manager онлайн
//   Уровень 3 (решение): Why this job (AI) / Cultural Signals ⭐ / deadline
//   Уровень 4 (действие): 3 кнопки — Чат / Отклик / Сохранить
//
// 3 пути отклика:
//   A) Чат с hiring manager (/api/jobs/[id]/chat)
//   B) Отклик через BizON Profile (/api/jobs/[id]/apply)
//   C) Через общий контакт (/api/jobs/[id]/apply-via-contact)
//
// Цепочка доверия: trustChain (candidate → ? → hiringManager)
// Application Tracker: статус submitted → viewed → interview → offer → closed
// Boost (ФЗ-38): бейдж «Реклама» если boosted=true
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import type { JobPublic } from '@/lib/types';

// === Локальное расширение JobPublic для v2-карточки ===
// Поля расширенного Job API (v5/v6): в JobPublic из '@/lib/types' их пока нет,
// основной GET /api/jobs их не возвращает — все опциональны, блоки рендерятся условно.
// TODO(11-a): перенести в JobPublic в '@/lib/types' и удалить локальные типы.
type JobHiringManager = {
  name: string;
  title?: string | null;
  avatarUrl?: string | null;
  responseTimeHours?: number | null;
};
type JobTrustChainPerson = { name: string; title?: string | null };
type JobTrustChain = {
  through?: JobTrustChainPerson;
  via?: JobTrustChainPerson;
  project?: { title?: string | null } | null;
  confidence?: number | null;
};
type JobCardJob = JobPublic & {
  applicationStatus?: string | null;
  salaryMin?: number | null;
  salaryMax?: number | null;
  currency?: string | null;
  companyId?: string | null;
  hiringManager?: JobHiringManager | null;
  trustChain?: JobTrustChain | null;
  boosted?: boolean;
  boostedUntil?: string | null;
  verificationStatus?: string | null;
  vacancyTrust?: number | null;
};
import {
  Briefcase, MapPin, TrendingUp, Loader2, Bookmark, Flame, Zap,
  MessageSquare, Send, Star, Clock, Sparkles, ChevronDown, ChevronUp,
  Link2, ShieldCheck, X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { UserAvatar } from '@/components/common/user-avatar';
import { CulturalSignalsChip, CulturalSignalsDialog } from '@/components/cultural-signals/cultural-signals';
import { ExplainableMatchDialog } from '@/components/jobs/explainable-match-dialog';
import { VerifiedVacancyBadge } from '@/components/jobs/verified-vacancy-badge';
import { HiringRealityBadge } from '@/components/jobs/hiring-reality-badge';

// === Application Tracker: 5 шагов ===
const TRACKER_STEPS: Array<{ key: string; label: string }> = [
  { key: 'submitted', label: 'Отклик' },
  { key: 'viewed', label: 'Просмотр' },
  { key: 'interview', label: 'Интервью' },
  { key: 'offer', label: 'Оффер' },
  { key: 'closed', label: 'Закрыто' },
];

// Статусы, считающиеся «closed» (финальный шаг трекера)
const CLOSED_STATUSES = ['offer', 'rejected', 'withdrawn'];

function getTrackerIndex(status: string | null | undefined): number {
  if (!status) return -1;
  const idx = TRACKER_STEPS.findIndex(s => s.key === status);
  if (idx === -1) {
    // rejected/withdrawn показываем как «closed» (последний шаг)
    if (CLOSED_STATUSES.includes(status)) return TRACKER_STEPS.length - 1;
    return -1;
  }
  return idx;
}

interface JobCardV2Props {
  job: JobCardJob;
  isSaved?: boolean;
  userSkillLevels?: Record<string, string>;
  userSkills?: string[];
  onToggleSave?: (job: JobCardJob) => void;
  onChanged?: () => void; // колбэк после отклика/withdraw (чтобы родитель обновил список)
  // === P1: Compare vacancies ===
  selectedForCompare?: boolean;
  onToggleCompare?: (job: JobCardJob) => void;
  compareDisabled?: boolean; // когда уже выбрано максимум — блокируем невыбранные
}

export function JobCardV2({
  job, isSaved, userSkillLevels = {}, userSkills = [], onToggleSave, onChanged,
  selectedForCompare, onToggleCompare, compareDisabled,
}: JobCardV2Props) {
  // === Уровень раскрытия карточки ===
  // 1 = мгновенный скан, 2 = быстрый просмотр, 3 = решение
  const [level, setLevel] = React.useState<1 | 2 | 3>(1);
  const [signalsOpen, setSignalsOpen] = React.useState(false);
  // P0-5: Explainable Match modal — открывается по клику на match%
  const [explainOpen, setExplainOpen] = React.useState(false);

  // Модалки для 3 путей отклика
  const [applyDialogOpen, setApplyDialogOpen] = React.useState(false);
  const [chatDialogOpen, setChatDialogOpen] = React.useState(false);
  const [contactDialogOpen, setContactDialogOpen] = React.useState(false);
  const [contactsList, setContactsList] = React.useState<
    Array<{ id: string; name: string; title: string | null; avatarUrl: string | null }>
  >([]);

  // Текущий статус отклика (для трекера) — синхронизирован с job.applicationStatus
  const [currentStatus, setCurrentStatus] = React.useState<string | null>(job.applicationStatus ?? null);
  React.useEffect(() => {
    setCurrentStatus(job.applicationStatus ?? null);
  }, [job.applicationStatus]);

  // === Match % ===
  const matchPercent = Math.round(job.matchConfidence * 100);
  const isHot = matchPercent >= 70;
  const matchColor = isHot
    ? 'text-emerald-700 dark:text-emerald-400 bg-emerald-500/10'
    : matchPercent >= 40 ? 'text-amber-700 dark:text-amber-400 bg-amber-500/10' : 'text-muted-foreground bg-muted';
  const barColor = isHot ? 'bg-emerald-600' : matchPercent >= 40 ? 'bg-amber-500' : 'bg-muted-foreground/50';

  // === Salary (Этап 5.2: используем salaryMin/salaryMax, fallback на salaryFrom/salaryTo) ===
  const salaryMin = job.salaryMin ?? job.salaryFrom;
  const salaryMax = job.salaryMax ?? job.salaryTo;
  const currency = job.currency ?? 'RUB';
  const currencySymbol = currency === 'RUB' ? '₽' : currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency;
  const hasSalary = salaryMin != null && salaryMax != null && salaryMin > 0 && salaryMax > 0;
  const salaryText = hasSalary
    ? `${salaryMin!.toLocaleString('ru-RU')}–${salaryMax!.toLocaleString('ru-RU')} ${currencySymbol}`
    : 'Зарплата не указана';

  // === Hiring manager ===
  const hm = job.hiringManager ?? null;
  const hmResponseText = hm?.responseTimeHours
    ? `Обычно отвечает за ${hm.responseTimeHours} ч`
    : 'Время ответа неизвестно';

  // === Trust chain ===
  const chain = job.trustChain ?? null;
  // Контакт в цепочке: v5-API присылает либо through, либо via — берём первого существующего
  const chainContact = chain?.through ?? chain?.via ?? null;

  // === Boost (ФЗ-38 маркировка) ===
  const isBoosted = job.boosted === true &&
    (!job.boostedUntil || new Date(job.boostedUntil) > new Date());

  // === Matched skills breakdown ===
  const matchedSkills = job.requiredSkills.filter(s => userSkillLevels[s] !== undefined).length;

  // === Tracker ===
  const trackerIdx = getTrackerIndex(currentStatus);
  const hasApplication = currentStatus !== null && currentStatus !== undefined;

  // ===========================================================================
  // Действия: 3 пути отклика
  // ===========================================================================

  // Путь B: Отклик через BizON Profile
  const [coverLetter, setCoverLetter] = React.useState('');
  const [applyLoading, setApplyLoading] = React.useState(false);

  async function handleApplyB() {
    setApplyLoading(true);
    try {
      await api(`/api/jobs/${job.id}/apply`, {
        method: 'POST',
        body: JSON.stringify({ coverLetter: coverLetter.trim() || undefined }),
      });
      toast({
        title: 'Отклик отправлен',
        description: `Совпадение: ${matchPercent}%`,
      });
      setCurrentStatus('submitted');
      setApplyDialogOpen(false);
      setCoverLetter('');
      onChanged?.();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setApplyLoading(false);
    }
  }

  // Путь A: Чат с hiring manager
  const [chatMessage, setChatMessage] = React.useState('');
  const [chatLoading, setChatLoading] = React.useState(false);

  async function handleChat() {
    setChatLoading(true);
    try {
      await api(`/api/jobs/${job.id}/chat`, {
        method: 'POST',
        body: JSON.stringify({ message: chatMessage.trim() || undefined }),
      });
      toast({
        title: 'Чат начат',
        description: hm ? `с ${hm.name}` : 'с hiring manager',
      });
      setCurrentStatus('submitted');
      setChatDialogOpen(false);
      setChatMessage('');
      onChanged?.();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setChatLoading(false);
    }
  }

  // Путь C: через общий контакт
  const [contactMessage, setContactMessage] = React.useState('');
  const [contactLoading, setContactLoading] = React.useState(false);
  const [selectedContact, setSelectedContact] = React.useState<string | null>(null);

  async function loadContacts() {
    try {
      // Загружаем accepted connections пользователя
      const res = await api<{
        connections: Array<{
          id: string;
          status: string;
          direction: string;
          fromUser: { id: string; name: string; title: string | null; avatarUrl: string | null };
          toUser: { id: string; name: string; title: string | null; avatarUrl: string | null };
        }>;
      }>('/api/connections?status=accepted');
      const contacts = res.connections
        .filter(c => c.status === 'accepted')
        .map(c => {
          const u = c.direction === 'outgoing' ? c.toUser : c.fromUser;
          return {
            id: u.id,
            name: u.name,
            title: u.title ?? null,
            avatarUrl: u.avatarUrl ?? null,
          };
        });
      setContactsList(contacts);
    } catch (e: any) {
      toast({ title: 'Не удалось загрузить контакты', description: e.message, variant: 'destructive' });
    }
  }

  async function handleApplyViaContact() {
    if (!selectedContact) {
      toast({ title: 'Выберите контакт', variant: 'destructive' });
      return;
    }
    setContactLoading(true);
    try {
      await api(`/api/jobs/${job.id}/apply-via-contact`, {
        method: 'POST',
        body: JSON.stringify({
          contactId: selectedContact,
          message: contactMessage.trim() || undefined,
        }),
      });
      toast({
        title: 'Запрос отправлен',
        description: `Контакт получит запрос «порекомендуй меня»`,
      });
      setCurrentStatus('submitted');
      setContactDialogOpen(false);
      setContactMessage('');
      setSelectedContact(null);
      onChanged?.();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setContactLoading(false);
    }
  }

  // Withdraw отклика
  const [withdrawLoading, setWithdrawLoading] = React.useState(false);
  async function handleWithdraw() {
    if (!hasApplication) return;
    if (!confirm('Отозвать отклик?')) return;
    setWithdrawLoading(true);
    try {
      // applicationId хранится в job.id паре, но у нас нет прямого доступа к applicationId
      // в JobPublic — используем поиск через /api/jobs/applications
      const res = await api<{ applications: Array<{ id: string; job: { id: string } }> }>('/api/jobs/applications');
      const app = res.applications.find(a => a.job.id === job.id);
      if (!app) {
        toast({ title: 'Отклик не найден', variant: 'destructive' });
        return;
      }
      await api(`/api/jobs/applications/${app.id}/withdraw`, { method: 'POST' });
      toast({ title: 'Отклик отозван' });
      setCurrentStatus('withdrawn');
      onChanged?.();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setWithdrawLoading(false);
    }
  }

  // ===========================================================================
  // Render
  // ===========================================================================
  return (
    <Card className={cn(
      'hover:shadow-md transition-shadow relative',
      isBoosted && 'ring-1 ring-amber-400/50',
      // Phase 3, задача 5: verified вакансия → ring-2 ring-green-500/50 на карточке.
      job.verificationStatus === 'verified' && 'ring-2 ring-emerald-500/50',
      // P1: подсвечиваем выбранную для сравнения
      selectedForCompare && 'ring-2 ring-blue-500/60',
    )}>
      <CardContent className="p-4">
        {/* === P1: Checkbox «Сравнить» — левый верхний угол === */}
        {onToggleCompare && (
          <label
            className={cn(
              'absolute top-3 left-3 z-10 inline-flex items-center gap-1.5 px-1.5 py-1 rounded-md cursor-pointer transition select-none',
              selectedForCompare
                ? 'bg-blue-500/10 text-blue-700 dark:text-blue-300'
                : 'text-muted-foreground hover:bg-accent hover:text-foreground',
              compareDisabled && !selectedForCompare && 'opacity-40 cursor-not-allowed hover:bg-transparent',
            )}
            title={
              compareDisabled && !selectedForCompare
                ? 'Уже выбрано максимум вакансий для сравнения'
                : selectedForCompare
                  ? 'Убрать из сравнения'
                  : 'Добавить в сравнение'
            }
          >
            <input
              type="checkbox"
              className="w-3.5 h-3.5 accent-blue-600 cursor-pointer"
              checked={!!selectedForCompare}
              disabled={compareDisabled && !selectedForCompare}
              onChange={(e) => {
                e.preventDefault();
                onToggleCompare(job);
              }}
              onClick={(e) => e.stopPropagation()}
            />
            <span className="text-xs font-medium">Сравнить</span>
          </label>
        )}

        {/* === Boost badge (ФЗ-38 маркировка) === */}
        {isBoosted && (
          <div className="absolute -top-2 left-3 px-2 py-0.5 rounded-full bg-amber-500 text-white text-xs font-semibold flex items-center gap-1 shadow-sm">
            <Sparkles className="w-2.5 h-2.5" />
            Реклама
          </div>
        )}

        {/* === Verified Vacancy ribbon (Phase 3, задача 5) ===
            Для verified вакансий — крупный бейдж в правом верхнем углу карточки,
            дублирующий основной бейдж в заголовке. */}
        {job.verificationStatus === 'verified' && (
          <div className="absolute -top-2 right-3 px-2 py-0.5 rounded-full bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1 shadow-sm">
            <ShieldCheck className="w-2.5 h-2.5" />
            Verified
          </div>
        )}

        {/* Кнопка "Сохранить" — в правом верхнем углу */}
        {onToggleSave && (
          <button
            onClick={() => onToggleSave(job)}
            className={cn(
              'absolute top-3 right-3 p-1.5 rounded-md transition',
              isSaved ? 'text-primary bg-primary/10 hover:bg-primary/20' : 'text-muted-foreground hover:bg-accent hover:text-foreground'
            )}
            title={isSaved ? 'Убрать из избранного' : 'Сохранить в избранное'}
          >
            <Bookmark className={cn('w-4 h-4', isSaved && 'fill-current')} />
          </button>
        )}

        {/* === УРОВЕНЬ 1: Мгновенный скан === */}
        {/* должность / компания / зарплата / локация / match% */}
        <div className={cn('flex items-start justify-between gap-3 mb-2 pr-8', onToggleCompare && 'pl-7')}>
          <div className="min-w-0 flex-1">
            <h3 className="font-semibold text-base flex items-center gap-2 flex-wrap">
              {job.title}
              {isHot && <Flame className="w-3.5 h-3.5 text-orange-500" />}
              {/* Phase 2 — Verified Vacancy бейдж (Phase 3: prominent для verified) */}
              <VerifiedVacancyBadge
                jobId={job.id}
                initialStatus={job.verificationStatus ?? 'draft'}
                initialScore={job.vacancyTrust ?? 0}
                prominent={job.verificationStatus === 'verified'}
              />
              {/* Phase 3 — Hiring Reality Index бейдж (упрощённый Job Passport) */}
              {/* Lazy: подгрузит /api/jobs/[id]/hiring-reality по клику на «Почему?» */}
              <HiringRealityBadge jobId={job.id} />
            </h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-0.5 flex-wrap">
              <span className="font-medium text-foreground/80">{job.company}</span>
              {job.location && (
                <span className="flex items-center gap-0.5">
                  <MapPin className="w-3 h-3" /> {job.location}
                </span>
              )}
              {/* Cultural Signals чип */}
              {job.companyId && (
                <CulturalSignalsChip companyId={job.companyId} onClick={() => setSignalsOpen(true)} />
              )}
            </div>
          </div>

          {/* P-score с прогресс-баром — кликабельно → открывает Explainable Match */}
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            <button
              type="button"
              onClick={() => setExplainOpen(true)}
              className={cn(
                'text-xs px-2 py-0.5 rounded-md font-bold tabular-nums transition hover:scale-105 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400',
                matchColor
              )}
              title="Открыть объяснение совпадения (BIZON MATCH)"
              aria-label={`Совпадение ${matchPercent} процентов. Открыть объяснение.`}
            >
              {matchPercent}% match
            </button>
            <button
              type="button"
              onClick={() => setExplainOpen(true)}
              className="w-16 h-1.5 rounded-full bg-muted overflow-hidden cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
              aria-hidden="true"
              title="Открыть объяснение совпадения"
            >
              <div
                className={cn('h-full rounded-full transition-all duration-500', barColor)}
                style={{ width: `${Math.min(100, matchPercent)}%` }}
              />
            </button>
            {matchedSkills > 0 && (
              <span className="text-xs text-muted-foreground tabular-nums">
                {matchedSkills} из {job.requiredSkills.length} навыков
              </span>
            )}
          </div>
        </div>

        {/* Salary — prominent (Этап 5.2: salary обязательна) */}
        <div className="flex items-center gap-3 text-sm mb-2 flex-wrap">
          <span className={cn(
            'font-semibold tabular-nums',
            hasSalary ? 'text-foreground' : 'text-muted-foreground italic',
          )}>
            {salaryText}
          </span>
          <span className="flex items-center gap-0.5 text-xs text-muted-foreground">
            <TrendingUp className="w-3 h-3" /> Рост: {Math.round(job.growthScore * 100)}%
          </span>
        </div>

        {/* === Кнопка раскрытия уровня 2 === */}
        <button
          type="button"
          onClick={() => setLevel(l => l === 2 ? 1 : 2)}
          className="text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline transition flex items-center gap-1"
          aria-expanded={level >= 2}
        >
          {level >= 2 ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          {level >= 2 ? 'Скрыть детали' : 'Подробнее'}
        </button>

        {/* === УРОВЕНЬ 2: Быстрый просмотр === */}
        {level >= 2 && (
          <div className="mt-3 space-y-3 pt-3 border-t">
            {/* Опыт / навыки / тип / команда */}
            <div className="space-y-2">
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Briefcase className="w-3 h-3" /> Тип: вакансия
              </div>

              {/* Навыки с StatusBadge (Truth Engine) */}
              {job.requiredSkills.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs text-muted-foreground">Навыки:</span>
                  {job.requiredSkills.map(s => {
                    const hasSkill = userSkillLevels[s] !== undefined;
                    return (
                      <Badge
                        key={s}
                        variant={hasSkill ? 'default' : 'secondary'}
                        className={cn('text-xs', hasSkill && 'bg-emerald-600 hover:bg-emerald-700 text-white')}
                      >
                        {s}
                      </Badge>
                    );
                  })}
                </div>
              )}

              {/* Hiring manager info — онлайн индикатор + время ответа */}
              {hm && (
                <div className="flex items-center gap-2 p-2 rounded-md bg-muted/40">
                  <UserAvatar
                    name={hm.name}
                    avatarUrl={hm.avatarUrl ?? null}
                    size="sm"
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-medium truncate">{hm.name}</div>
                    {hm.title && (
                      <div className="text-xs text-muted-foreground truncate">{hm.title}</div>
                    )}
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" /> {hmResponseText}
                    </div>
                  </div>
                </div>
              )}

              {/* Trust chain — если есть общий контакт до hiring manager */}
              {chain && chainContact && (
                <div className="flex items-center gap-2 p-2 rounded-md bg-emerald-500/10 border border-emerald-500/30">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-emerald-400 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-emerald-800 dark:text-emerald-300">
                      Цепочка доверия
                    </div>
                    <div className="text-xs text-muted-foreground">
                      ты → <span className="font-medium">{chainContact.name}</span>
                      {chainContact.title ? ` · ${chainContact.title}` : ''}
                      {chain.project?.title ? ` → ${chain.project.title}` : ''}
                    </div>
                  </div>
                  <span className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold tabular-nums">
                    {Math.round((chain.confidence ?? 0.6) * 100)}%
                  </span>
                </div>
              )}
            </div>

            {/* Кнопка раскрытия уровня 3 */}
            <button
              type="button"
              onClick={() => setLevel(l => l === 3 ? 2 : 3)}
              className="text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline transition flex items-center gap-1"
              aria-expanded={level >= 3}
            >
              {level >= 3 ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              {level >= 3 ? 'Скрыть решение' : 'Почему эта вакансия?'}
            </button>
          </div>
        )}

        {/* === УРОВЕНЬ 3: Решение === */}
        {level >= 3 && (
          <div className="mt-3 space-y-2 pt-3 border-t">
            {/* Why this job (AI) — короткое описание */}
            <div className="p-2 rounded-md bg-muted/40">
              <div className="text-xs font-medium flex items-center gap-1 mb-1">
                <Sparkles className="w-3 h-3" /> Почему эта вакансия
              </div>
              <p className="text-xs text-muted-foreground">
                {matchPercent >= 70
                  ? `Отличное совпадение: ${matchedSkills} из ${job.requiredSkills.length} ключевых навыков у вас уже есть. Рост потенциала ${Math.round(job.growthScore * 100)}%.`
                  : matchPercent >= 40
                    ? `Среднее совпадение (${matchPercent}%). Подтвердите ещё ${Math.max(0, Math.ceil(job.requiredSkills.length * 0.5) - matchedSkills)} навыков, чтобы увеличить шанс.`
                    : `Низкое совпадение (${matchPercent}%). Добавьте навыки из требований в профиль и подтвердите их.`}
              </p>
            </div>

            {/* Cultural Signals ⭐ */}
            {job.companyId && (
              <button
                onClick={() => setSignalsOpen(true)}
                className="w-full text-left p-2 rounded-md hover:bg-accent transition flex items-center gap-2"
              >
                <Star className="w-3.5 h-3.5 text-amber-500" />
                <span className="text-xs flex-1">Cultural Signals — отзывы сотрудников</span>
                <span className="text-xs text-muted-foreground">открыть →</span>
              </button>
            )}

            {/* Deadline / срочность */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>Размещена {new Date(job.createdAt).toLocaleDateString('ru-RU')}</span>
            </div>
          </div>
        )}

        {/* === Application Tracker (если есть отклик) === */}
        {hasApplication && (
          <div className="mt-3 pt-3 border-t">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium text-muted-foreground">Статус отклика</span>
              {currentStatus !== 'withdrawn' && currentStatus !== 'rejected' && (
                <button
                  onClick={handleWithdraw}
                  disabled={withdrawLoading}
                  className="text-xs text-muted-foreground hover:text-red-600 transition flex items-center gap-0.5"
                >
                  {withdrawLoading ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : <X className="w-2.5 h-2.5" />}
                  Отозвать
                </button>
              )}
            </div>
            <div className="flex items-center gap-1">
              {TRACKER_STEPS.map((step, idx) => {
                const reached = trackerIdx >= 0 && idx <= trackerIdx;
                const isClosed = currentStatus === 'withdrawn' || currentStatus === 'rejected';
                const isCurrent = trackerIdx === idx;
                return (
                  <React.Fragment key={step.key}>
                    <div className="flex flex-col items-center gap-0.5 flex-1">
                      <div
                        className={cn(
                          'w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold transition',
                          reached
                            ? isClosed && idx === TRACKER_STEPS.length - 1
                              ? currentStatus === 'withdrawn'
                                ? 'bg-red-500 text-white'
                                : 'bg-red-500 text-white'
                              : 'bg-emerald-600 text-white'
                            : 'bg-muted text-muted-foreground',
                          isCurrent && 'ring-2 ring-emerald-400 ring-offset-1',
                        )}
                      >
                        {isClosed && idx === TRACKER_STEPS.length - 1 ? '×' : idx + 1}
                      </div>
                      <span className={cn(
                        'text-xs text-center leading-tight',
                        reached ? 'text-foreground font-medium' : 'text-muted-foreground',
                      )}>
                        {step.label}
                      </span>
                    </div>
                    {idx < TRACKER_STEPS.length - 1 && (
                      <div className={cn(
                        'h-0.5 flex-1 min-w-[8px]',
                        trackerIdx > idx ? 'bg-emerald-600' : 'bg-muted',
                      )} />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
            {currentStatus === 'withdrawn' && (
              <p className="text-xs text-red-600 dark:text-red-400 mt-1">Отклик отозван</p>
            )}
            {currentStatus === 'rejected' && (
              <p className="text-xs text-red-600 dark:text-red-400 mt-1">Отказано</p>
            )}
          </div>
        )}

        {/* === УРОВЕНЬ 4: Действие — 3 кнопки === */}
        <div className="mt-3 pt-3 border-t flex items-center gap-2 flex-wrap">
          {/* Путь A: Чат с hiring manager */}
          <Button
            size="sm"
            variant="outline"
            onClick={() => setChatDialogOpen(true)}
            disabled={currentStatus === 'withdrawn'}
            className="gap-1.5"
            title="Начать чат с hiring manager"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            Чат
          </Button>

          {/* Путь B: Отклик через BizON Profile (молния = быстрый отклик) */}
          <Button
            size="sm"
            onClick={() => setApplyDialogOpen(true)}
            disabled={currentStatus === 'submitted' || currentStatus === 'viewed' || currentStatus === 'interview' || currentStatus === 'offer'}
            className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
            title="Отклик через BizON Profile (не CV)"
          >
            <Zap className="w-3.5 h-3.5" />
            {hasApplication ? 'Отклик отправлен' : 'Откликнуться'}
          </Button>

          {/* Путь C: Через общий контакт */}
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setContactDialogOpen(true);
              loadContacts();
            }}
            disabled={currentStatus === 'withdrawn'}
            className="gap-1.5"
            title="Попросить общий контакт порекомендовать вас"
          >
            <Link2 className="w-3.5 h-3.5" />
            Через контакт
          </Button>

          {/* Сохранить (если не передан onToggleSave — не показываем) */}
          {onToggleSave && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onToggleSave(job)}
              className="ml-auto gap-1.5"
              title={isSaved ? 'В избранном' : 'Сохранить'}
            >
              <Bookmark className={cn('w-3.5 h-3.5', isSaved && 'fill-current')} />
            </Button>
          )}
        </div>
      </CardContent>

      {/* Cultural Signals модалка */}
      {job.companyId && (
        <CulturalSignalsDialog
          companyId={job.companyId}
          open={signalsOpen}
          onClose={() => setSignalsOpen(false)}
        />
      )}

      {/* P0-5: Explainable Match модалка — открывается по клику на match% */}
      <ExplainableMatchDialog
        jobId={job.id}
        jobTitle={job.title}
        company={job.company}
        open={explainOpen}
        onOpenChange={setExplainOpen}
      />

      {/* === Диалог: Путь B — Отклик через BizON Profile === */}
      <Dialog open={applyDialogOpen} onOpenChange={setApplyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Отклик через BizON Profile</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Вместо классического CV вы отправляете свою <span className="font-medium">Public Persona</span> —
              профиль с подтверждёнными навыками, проектами и репутацией.
              Cover letter опционален.
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="cover-letter">Cover letter (опционально)</Label>
              <Textarea
                id="cover-letter"
                value={coverLetter}
                onChange={(e) => setCoverLetter(e.target.value)}
                placeholder="Здравствуйте! Меня заинтересовала ваша вакансия…"
                maxLength={5000}
                rows={5}
              />
              <p className="text-xs text-muted-foreground text-right">
                {coverLetter.length}/5000
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApplyDialogOpen(false)} disabled={applyLoading}>
              Отмена
            </Button>
            <Button
              onClick={handleApplyB}
              disabled={applyLoading}
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1.5"
            >
              {applyLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              Отправить отклик
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* === Диалог: Путь A — Чат с hiring manager === */}
      <Dialog open={chatDialogOpen} onOpenChange={setChatDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Чат с hiring manager</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {hm && (
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted/40">
                <UserAvatar
                  name={hm.name}
                  avatarUrl={hm.avatarUrl ?? null}
                  size="sm"
                />
                <div>
                  <div className="text-sm font-medium">{hm.name}</div>
                  {hm.title && <div className="text-xs text-muted-foreground">{hm.title}</div>}
                </div>
              </div>
            )}
            <p className="text-sm text-muted-foreground">
              Начните чат с hiring manager. Ваше первое сообщение откроет диалог и
              создаст отклик со статусом «submitted».
            </p>
            <div className="space-y-1.5">
              <Label htmlFor="chat-message">Сообщение</Label>
              <Textarea
                id="chat-message"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder={`Здравствуйте! Меня интересует вакансия «${job.title}»…`}
                maxLength={2000}
                rows={5}
              />
              <p className="text-xs text-muted-foreground text-right">
                {chatMessage.length}/2000
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setChatDialogOpen(false)} disabled={chatLoading}>
              Отмена
            </Button>
            <Button
              onClick={handleChat}
              disabled={chatLoading}
              className="gap-1.5"
            >
              {chatLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              Начать чат
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* === Диалог: Путь C — Через общий контакт === */}
      <Dialog open={contactDialogOpen} onOpenChange={setContactDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Отклик через общий контакт</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Выберите контакт из ваших связей, чтобы попросить его порекомендовать вас
              hiring manager'у. Контакт получит запрос «порекомендуй меня».
            </p>

            {chain && chainContact && (
              <div className="p-2 rounded-md bg-emerald-500/10 border border-emerald-500/30 text-xs">
                <ShieldCheck className="w-3.5 h-3.5 inline mr-1 text-emerald-700 dark:text-emerald-400" />
                Рекомендуемый контакт: <span className="font-medium">{chainContact.name}</span> (через цепочку доверия)
              </div>
            )}

            <div className="space-y-1.5">
              <Label>Выберите контакт</Label>
              <div className="max-h-48 overflow-y-auto space-y-1 border rounded-md p-2">
                {contactsList.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    У вас пока нет контактов. Установите связи в разделе «Сеть».
                  </p>
                ) : (
                  contactsList.map(c => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedContact(c.id)}
                      className={cn(
                        'w-full flex items-center gap-2 p-2 rounded-md transition text-left',
                        selectedContact === c.id ? 'bg-primary text-primary-foreground' : 'hover:bg-accent',
                      )}
                    >
                      <UserAvatar name={c.name} avatarUrl={c.avatarUrl ?? null} size="sm" />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-medium truncate">{c.name}</div>
                        {c.title && <div className="text-xs opacity-70 truncate">{c.title}</div>}
                      </div>
                      {selectedContact === c.id && <span className="text-xs">✓</span>}
                    </button>
                  ))
                )}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="contact-message">Сообщение контакту (опционально)</Label>
              <Textarea
                id="contact-message"
                value={contactMessage}
                onChange={(e) => setContactMessage(e.target.value)}
                placeholder="Привет! Можешь порекомендовать меня для этой вакансии?"
                maxLength={2000}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setContactDialogOpen(false)} disabled={contactLoading}>
              Отмена
            </Button>
            <Button
              onClick={handleApplyViaContact}
              disabled={contactLoading || !selectedContact}
              className="gap-1.5"
            >
              {contactLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              Отправить запрос
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
