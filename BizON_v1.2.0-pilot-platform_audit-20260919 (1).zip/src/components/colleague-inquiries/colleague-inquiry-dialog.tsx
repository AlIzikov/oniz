// BizON — ColleagueInquiryDialog (R9 «Спроси у коллег»)
// Модалка для отправки личного запроса коллеге с просьбой поделиться
// опытом работы с третьим человеком.
//
// Используется в PublicPersona: рядом с каждым коллаборатором в списке
// «ДЕЛАЛ ВМЕСТЕ С» появляется кнопка «Спросить». При клике открывается эта модалка.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import { Loader2, MessageCircleHeart, Send } from 'lucide-react';

interface ColleagueInquiryDialogProps {
  /** Коллега, у которого спрашивают. */
  colleague: {
    id: string;
    name: string;
    title?: string | null;
    avatarUrl?: string | null;
  };
  /** Человек, про которого спрашивают. */
  aboutUser: {
    id: string;
    name: string;
    avatarUrl?: string | null;
  };
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Колбэк после успешной отправки (например, чтобы закрыть модалку). */
  onSent?: () => void;
}

const DEFAULT_MESSAGE =
  'Привет! Видел, что вы работали вместе с {about}. Поделись, пожалуйста, как тебе с ним работалось?';

const MAX_LENGTH = 2000;

export function ColleagueInquiryDialog({
  colleague,
  aboutUser,
  open,
  onOpenChange,
  onSent,
}: ColleagueInquiryDialogProps) {
  const [message, setMessage] = React.useState('');
  const [isAnonymous, setIsAnonymous] = React.useState(false);
  const [sending, setSending] = React.useState(false);

  // Pre-fill message when dialog opens
  React.useEffect(() => {
    if (open) {
      setMessage(DEFAULT_MESSAGE.replace('{about}', aboutUser.name));
      setIsAnonymous(false);
    }
  }, [open, aboutUser.name]);

  const handleSend = async () => {
    if (!message.trim()) {
      toast({ title: 'Введите текст запроса', variant: 'destructive' });
      return;
    }
    if (message.length > MAX_LENGTH) {
      toast({
        title: `Сообщение слишком длинное (макс. ${MAX_LENGTH} символов)`,
        variant: 'destructive',
      });
      return;
    }
    setSending(true);
    try {
      await api('/api/colleague-inquiries', {
        method: 'POST',
        body: JSON.stringify({
          toUserId: colleague.id,
          aboutUserId: aboutUser.id,
          message: message.trim(),
          isAnonymous,
        }),
      });
      toast({
        title: 'Запрос отправлен',
        description: `${colleague.name} получит уведомление и сможет ответить в разделе «Что нового».`,
      });
      onOpenChange(false);
      onSent?.();
    } catch (e: any) {
      toast({
        title: 'Не удалось отправить запрос',
        description: e?.message ?? 'Попробуйте ещё раз.',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircleHeart className="w-5 h-5 text-lighthouse" />
            Спросить у коллеги
          </DialogTitle>
          <DialogDescription>
            Личный запрос — никто, кроме коллеги, его не увидит.
          </DialogDescription>
        </DialogHeader>

        {/* Коллега → про кого */}
        <div className="flex items-center gap-3 py-2">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <UserAvatar
              name={colleague.name}
              avatarUrl={colleague.avatarUrl ?? null}
              size="sm"
            />
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{colleague.name}</div>
              {colleague.title && (
                <div className="text-xs text-muted-foreground truncate">{colleague.title}</div>
              )}
            </div>
          </div>
          <div className="text-muted-foreground text-xs px-1">про</div>
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <UserAvatar
              name={aboutUser.name}
              avatarUrl={aboutUser.avatarUrl ?? null}
              size="sm"
            />
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{aboutUser.name}</div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="inquiry-message">Сообщение</Label>
          <Textarea
            id="inquiry-message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            maxLength={MAX_LENGTH}
            placeholder="Напишите, что именно хотите узнать…"
            disabled={sending}
          />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{message.length} / {MAX_LENGTH}</span>
            <span>Коллега увидит запрос в разделе «Что нового»</span>
          </div>
        </div>

        {/* Анонимно */}
        <label
          htmlFor="inquiry-anonymous"
          className="flex items-center justify-between gap-3 rounded-lg border bg-muted/30 p-3 cursor-pointer"
        >
          <div className="space-y-0.5">
            <div className="text-sm font-medium">Анонимно</div>
            <div className="text-xs text-muted-foreground">
              Коллега не увидит ваше имя — только сообщение.
            </div>
          </div>
          <Switch
            id="inquiry-anonymous"
            checked={isAnonymous}
            onCheckedChange={setIsAnonymous}
            disabled={sending}
          />
        </label>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={sending}
          >
            Отмена
          </Button>
          <Button onClick={handleSend} disabled={sending || !message.trim()}>
            {sending ? (
              <>
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                Отправка…
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-1.5" />
                Отправить
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
