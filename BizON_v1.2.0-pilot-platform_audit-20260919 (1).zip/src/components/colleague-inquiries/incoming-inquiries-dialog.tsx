// BizON — IncomingInquiriesDialog (R9 «Спроси у коллег»)
// Модальный список входящих запросов от коллег с возможностью ответить/отклонить.
// Открывается из Tab «Что нового» по клику на счётчик «Запросы от коллег».
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Loader2, MessageCircleHeart, Send, X, Clock, ArrowRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface InquiryUser {
  id: string | null;
  name: string;
  title?: string | null;
  avatarUrl?: string | null;
}

interface Inquiry {
  id: string;
  message: string;
  status: string;
  response: string | null;
  isAnonymous: boolean;
  createdAt: string;
  answeredAt: string | null;
  expiresAt: string;
  fromUser: InquiryUser;
  aboutUser: InquiryUser;
}

interface IncomingInquiriesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Колбэк после успешного ответа (например, чтобы обновить счётчик). */
  onResponded?: () => void;
}

export function IncomingInquiriesDialog({
  open,
  onOpenChange,
  onResponded,
}: IncomingInquiriesDialogProps) {
  const [inquiries, setInquiries] = React.useState<Inquiry[]>([]);
  const [loading, setLoading] = React.useState(false);
  // id активного запроса, на который пишем ответ
  const [respondingId, setRespondingId] = React.useState<string | null>(null);
  const [responseText, setResponseText] = React.useState('');
  const [sending, setSending] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!open) return;
    setLoading(true);
    try {
      const res = await api<{ inquiries: Inquiry[] }>('/api/colleague-inquiries?status=pending');
      setInquiries(res.inquiries);
    } catch (e: any) {
      console.error('[incoming-inquiries] load error:', e);
      toast({
        title: 'Не удалось загрузить запросы',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [open]);

  React.useEffect(() => {
    load();
  }, [load]);

  const handleRespond = async (id: string, status: 'answered' | 'declined') => {
    if (status === 'answered' && !responseText.trim()) {
      toast({ title: 'Введите текст ответа', variant: 'destructive' });
      return;
    }
    setSending(true);
    try {
      await api(`/api/colleague-inquiries/${id}/respond`, {
        method: 'POST',
        body: JSON.stringify({
          status,
          response: status === 'answered' ? responseText.trim() : null,
        }),
      });
      toast({
        title: status === 'answered' ? 'Ответ отправлен' : 'Запрос отклонён',
        description:
          status === 'answered'
            ? 'Запросивший получит уведомление.'
            : 'Запрос помечен как отклонённый.',
      });
      setRespondingId(null);
      setResponseText('');
      await load();
      onResponded?.();
    } catch (e: any) {
      toast({
        title: 'Не удалось отправить ответ',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const handleDecline = async (id: string) => {
    setSending(true);
    try {
      await api(`/api/colleague-inquiries/${id}/respond`, {
        method: 'POST',
        body: JSON.stringify({ status: 'declined' }),
      });
      toast({ title: 'Запрос отклонён' });
      await load();
      onResponded?.();
    } catch (e: any) {
      toast({
        title: 'Не удалось отклонить запрос',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const formatExpiry = (iso: string): string => {
    const expiresAt = new Date(iso);
    const now = new Date();
    const diffMs = expiresAt.getTime() - now.getTime();
    if (diffMs <= 0) return 'истёк';
    const days = Math.floor(diffMs / (24 * 60 * 60 * 1000));
    const hours = Math.floor((diffMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    if (days > 0) return `осталось ${days} дн.`;
    if (hours > 0) return `осталось ${hours} ч.`;
    return 'истекает скоро';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircleHeart className="w-5 h-5 text-lighthouse" />
            Запросы от коллег
          </DialogTitle>
          <DialogDescription>
            Личные просьбы поделиться опытом работы с вашими коллегами.
            Никто, кроме вас, их не видит.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto -mx-6 px-6 space-y-3">
          {loading ? (
            <>
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-32 w-full rounded-lg" />
              ))}
            </>
          ) : inquiries.length === 0 ? (
            <div className="py-12 text-center text-sm text-muted-foreground">
              <MessageCircleHeart className="w-10 h-10 mx-auto mb-2 text-muted-foreground/40" />
              Нет входящих запросов.
            </div>
          ) : (
            inquiries.map((inq) => (
              <div
                key={inq.id}
                className="rounded-lg border bg-card p-3 sm:p-4 space-y-3"
              >
                {/* Header: fromUser → aboutUser */}
                <div className="flex items-center gap-2 text-sm">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <UserAvatar
                      name={inq.fromUser.name}
                      avatarUrl={inq.fromUser.avatarUrl ?? null}
                      size="sm"
                    />
                    <span className="font-medium truncate">{inq.fromUser.name}</span>
                    {inq.isAnonymous && (
                      <Badge variant="outline" className="text-xs px-1 py-0">аноним</Badge>
                    )}
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="text-muted-foreground text-xs">про</span>
                    <UserAvatar
                      name={inq.aboutUser.name}
                      avatarUrl={inq.aboutUser.avatarUrl ?? null}
                      size="sm"
                    />
                    <span className="font-medium truncate">{inq.aboutUser.name}</span>
                  </div>
                  <div className="ml-auto text-xs text-muted-foreground flex items-center gap-1 shrink-0">
                    <Clock className="w-3 h-3" />
                    {formatExpiry(inq.expiresAt)}
                  </div>
                </div>

                {/* Message */}
                <div className="text-sm bg-muted/40 rounded-md p-2.5 leading-relaxed">
                  {inq.message}
                </div>

                {/* Response form OR action buttons */}
                {respondingId === inq.id ? (
                  <div className="space-y-2">
                    <Textarea
                      value={responseText}
                      onChange={(e) => setResponseText(e.target.value)}
                      rows={4}
                      maxLength={5000}
                      placeholder="Поделитесь опытом работы с этим человеком. Без оценок и звёзд — только факты и истории."
                      disabled={sending}
                    />
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setRespondingId(null);
                          setResponseText('');
                        }}
                        disabled={sending}
                      >
                        Отмена
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleRespond(inq.id, 'answered')}
                        disabled={sending || !responseText.trim()}
                      >
                        {sending ? (
                          <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                        ) : (
                          <Send className="w-3.5 h-3.5 mr-1.5" />
                        )}
                        Отправить ответ
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDecline(inq.id)}
                      disabled={sending}
                      className="text-muted-foreground"
                    >
                      <X className="w-3.5 h-3.5 mr-1" /> Отклонить
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        setRespondingId(inq.id);
                        setResponseText('');
                      }}
                      disabled={sending}
                    >
                      <MessageCircleHeart className="w-3.5 h-3.5 mr-1.5" />
                      Ответить
                    </Button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
