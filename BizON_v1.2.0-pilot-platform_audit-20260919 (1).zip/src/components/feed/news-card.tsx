// BizON — NewsCard для ленты + NewsRelevance UI (doc_a §C2: «Почему это важно для вас»)
// Задача 4-g: backend GET /api/news/[id]/relevance существовал, но ни один компонент
// его не вызывал. Здесь:
//   • NewsCardWithRelevance — карточка новости с раскрывающимся блоком
//     «Почему это важно?» (GET /api/news/[id]/relevance, результат кэшируется
//     в состоянии карточки — повторный клик не дёргает API);
//   • NewsFeedSection — секция ленты, подгружающая published NewsCard из /api/news.
//
// Wave 15 — «Поделиться новостью»:
//   • ShareNewsDialog — адресная рекомендация: «Поделиться» → выбор получателя →
//     POST /api/news/recommend (у получателя карточка появится с атрибуцией
//     «Рекомендовано {имя отправителя}»);
//   • атрибуция отправителя на карточке получателя (sharedBy) + комментарий;
//   • платформенная рекомендация «Рекомендовано BizON» — первую неделю после
//     публикации (platformRecommended) карточка помечается бейджем;
//   • «Развернуть / Свернуть» — полный текст, описание, картинка и все теги.
//
// Контракт /api/news (route.ts):
//   { items: [{ id, url, title, description, imageUrl, aiSummary, tags[],
//               sourceDomain, publishedAt, category, platformRecommended, ... }], total }
// Контракт /api/news/shared:
//   { items: [{ shareId, message, sharedAt, fromUser{id,name,title,avatarUrl,ipScore},
//               card: NewsCardItem }], total }
// Контракт /api/news/[id]/relevance:
//   { relevant: boolean, reasons: [{ type, text, action? }], engine: 'llm'|'heuristic' }
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { UserAvatar } from '@/components/common/user-avatar';
import { ShareNewsDialog } from './share-news-dialog';
import {
  Sparkles, Loader2, ChevronDown, ChevronUp, ExternalLink, Lightbulb,
  Newspaper, GraduationCap, FolderKanban, Building2, Users, TrendingUp,
  Share2, UserPlus,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { nameToInstrumental } from '@/lib/russian-cases';
import type { AppView } from '@/lib/types';

// ============================================================================
// === Типы ===
// ============================================================================

/** Карточка новости — по контракту GET /api/news */
export interface NewsCardItem {
  id: string;
  url: string;
  title: string;
  description: string | null;
  imageUrl: string | null;
  aiSummary: string;
  tags: string[];
  sourceDomain: string;
  publishedAt: string;
  category: string;
  /** Wave 15: первая неделя после публикации — платформенная рекомендация BizON */
  platformRecommended?: boolean;
}

/** Атрибуция адресной рекомендации (кто отправил новость текущему пользователю) */
export interface SharedNewsInfo {
  shareId: string;
  message: string | null;
  sharedAt: string;
  fromUser: { id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number };
}

/** Элемент GET /api/news/shared — рекомендация + сама карточка */
export interface SharedNewsItem extends SharedNewsInfo {
  card: NewsCardItem;
}

type RelevanceReasonType =
  | 'industry_match'
  | 'company_match'
  | 'colleague_match'
  | 'skill_match'
  | 'project_match';

interface RelevanceAction {
  label: string;
  view?: string;
  entityId?: string;
  externalUrl?: string;
}

interface RelevanceReason {
  type: RelevanceReasonType | string;
  text: string;
  action?: RelevanceAction;
}

/** Ответ GET /api/news/[id]/relevance */
interface RelevanceResult {
  relevant: boolean;
  reasons: RelevanceReason[];
  engine?: 'llm' | 'heuristic' | string;
}

// Безопасный маппинг action.view → AppView: произвольным строкам из API не доверяем
const ACTION_VIEW_ALLOWED: ReadonlySet<string> = new Set<AppView>([
  'me', 'dashboard', 'feed', 'profile', 'projects', 'jobs', 'network', 'matchmaker',
  'career', 'companies', 'company', 'events', 'communities', 'community', 'messages',
  'trust-graph', 'nft-skills', 'dao', 'mentor', 'publications', 'truth', 'subscription', 'settings',
]);

const REASON_META: Record<string, { icon: React.ReactNode; color: string }> = {
  skill_match: {
    icon: <GraduationCap className="w-3.5 h-3.5" />,
    color: 'text-violet-600 dark:text-violet-400 bg-violet-500/10',
  },
  project_match: {
    icon: <FolderKanban className="w-3.5 h-3.5" />,
    color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
  },
  company_match: {
    icon: <Building2 className="w-3.5 h-3.5" />,
    color: 'text-blue-600 dark:text-blue-400 bg-blue-500/10',
  },
  colleague_match: {
    icon: <Users className="w-3.5 h-3.5" />,
    color: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
  },
  industry_match: {
    icon: <TrendingUp className="w-3.5 h-3.5" />,
    color: 'text-lighthouse bg-lighthouse/10',
  },
};

function formatRelative(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(hours / 24);
  if (hours < 1) return 'только что';
  if (hours < 24) return `${hours} ч назад`;
  if (days < 7) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

// ============================================================================
// === Раскрывающийся блок «Почему это важно для вас» ===
// ============================================================================

function RelevancePanel({ result, onActionView }: { result: RelevanceResult; onActionView: (view: AppView) => void }) {
  if (!result.relevant || result.reasons.length === 0) {
    // Новость не релевантна — мягкое сообщение без негатива
    return (
      <div className="p-2.5 rounded-lg bg-muted/40 text-xs text-muted-foreground leading-relaxed">
        <Lightbulb className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5 text-amber-500" />
        Эта новость не связана с вашим профилем — показываем её как общую повестку рынка.
      </div>
    );
  }
  return (
    <div className="space-y-1.5" role="list" aria-label="Причины релевантности">
      {result.reasons.map((reason, i) => {
        const meta = REASON_META[reason.type] ?? {
          icon: <Lightbulb className="w-3.5 h-3.5" />,
          color: 'bg-muted text-muted-foreground',
        };
        return (
          <div key={i} role="listitem" className="flex items-start gap-2 p-2 rounded-lg bg-muted/40">
            <span className={cn('w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5', meta.color)} aria-hidden="true">
              {meta.icon}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-xs leading-relaxed">{reason.text}</div>
              {reason.action?.label && (reason.action.externalUrl ? (
                <a
                  href={reason.action.externalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-medium text-lighthouse hover:underline mt-1"
                >
                  {reason.action.label}
                  <ExternalLink className="w-3 h-3" />
                </a>
              ) : reason.action.view && ACTION_VIEW_ALLOWED.has(reason.action.view) ? (
                <button
                  type="button"
                  onClick={() => {
                    const view = reason.action?.view;
                    if (view && ACTION_VIEW_ALLOWED.has(view)) onActionView(view as AppView);
                  }}
                  className="inline-flex items-center gap-1 text-xs font-medium text-lighthouse hover:underline mt-1"
                >
                  {reason.action.label} →
                </button>
              ) : null)}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ============================================================================
// === Атрибуция адресной рекомендации (Wave 15) ===
// ============================================================================

/** Блок «Рекомендовано Валерием Николаевым» + комментарий отправителя */
function SharedByLine({ sharedBy }: { sharedBy: SharedNewsInfo }) {
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  return (
    <div className="flex items-start gap-2 mb-3 p-2 -mx-1 rounded-lg bg-lighthouse/5 border border-lighthouse/20">
      <button
        type="button"
        onClick={() => setProfileUserId(sharedBy.fromUser.id)}
        className="shrink-0 rounded-full focus-visible:outline-2 focus-visible:outline-lighthouse"
        aria-label={`Профиль: ${sharedBy.fromUser.name}`}
      >
        <UserAvatar name={sharedBy.fromUser.name} avatarUrl={sharedBy.fromUser.avatarUrl ?? undefined} size="sm" />
      </button>
      <div className="min-w-0 flex-1">
        <div className="text-xs leading-snug">
          <UserPlus className="w-3 h-3 inline mr-1 -mt-0.5 text-lighthouse" aria-hidden="true" />
          <span className="font-semibold">
            Рекомендовано {nameToInstrumental(sharedBy.fromUser.name)}
          </span>
          <span className="text-muted-foreground"> · {formatRelative(sharedBy.sharedAt)}</span>
        </div>
        {sharedBy.message && (
          <p className="text-xs text-muted-foreground italic mt-1 border-l-2 border-lighthouse/30 pl-2 leading-relaxed">
            «{sharedBy.message}»
          </p>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// === Платформенная рекомендация «Рекомендовано BizON» (Wave 15) ===
// ============================================================================

/** Бейдж платформенной рекомендации: первую неделю после публикации новость рекомендует BizON */
function BizonRecommendBadge() {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge
          variant="outline"
          className="text-xs gap-1 font-normal border-lighthouse/40 text-lighthouse bg-lighthouse/5 cursor-default"
        >
          <Sparkles className="w-3 h-3" aria-hidden="true" />
          Рекомендовано BizON
        </Badge>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-56">
        Первую неделю после публикации BizON рекомендует новость всем пользователям платформы.
      </TooltipContent>
    </Tooltip>
  );
}

// ============================================================================
// === Карточка новости с блоком релевантности + шерингом + разворотом ===
// ============================================================================

export function NewsCardWithRelevance({
  item,
  sharedBy,
  className,
}: {
  item: NewsCardItem;
  /** Кто отправил новость текущему пользователю (из GET /api/news/shared) */
  sharedBy?: SharedNewsInfo;
  className?: string;
}) {
  const setView = useAppStore((s) => s.setView);

  // Кэш результата релевантности в состоянии карточки:
  // после первой загрузки повторные клики ТОЛЬКО раскрывают/скрывают панель.
  const [open, setOpen] = React.useState(false);
  const [relevance, setRelevance] = React.useState<RelevanceResult | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  // Wave 15: разворот карточки (полный текст / описание / картинка / все теги)
  const [expanded, setExpanded] = React.useState(false);
  // Wave 15: диалог «Поделиться новостью»
  const [shareOpen, setShareOpen] = React.useState(false);

  async function handleToggle() {
    // Уже загружено (кэш) — просто переключаем видимость
    if (relevance) {
      setOpen((v) => !v);
      return;
    }
    // Ошибка в прошлый раз — повторный клик повторяет запрос (retry)
    if (open && !error) {
      setOpen(false);
      return;
    }
    setOpen(true);
    setLoading(true);
    setError(null);
    try {
      const res = await api<RelevanceResult>(`/api/news/${item.id}/relevance`);
      setRelevance(res);
    } catch {
      setError('Не удалось оценить релевантность. Нажмите ещё раз, чтобы повторить.');
    } finally {
      setLoading(false);
    }
  }

  const summary = item.aiSummary || item.description || '';

  return (
    <Card className={cn('hover:shadow-md transition-shadow', sharedBy && 'border-lighthouse/25', className)}>
      <CardContent className="p-4">
        {/* Wave 15: кто порекомендовал эту новость текущему пользователю */}
        {sharedBy && <SharedByLine sharedBy={sharedBy} />}

        {/* Источник + дата + платформенная рекомендация */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2 flex-wrap">
          <Badge variant="secondary" className="text-xs gap-1 font-normal">
            <Newspaper className="w-3 h-3" aria-hidden="true" />
            {item.sourceDomain}
          </Badge>
          <span>{formatRelative(item.publishedAt)}</span>
          {!sharedBy && item.platformRecommended && <BizonRecommendBadge />}
        </div>

        {/* Заголовок — ссылка на источник */}
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          className="font-semibold text-sm leading-snug hover:text-lighthouse transition"
        >
          {item.title}
          <ExternalLink className="w-3 h-3 inline ml-1.5 text-muted-foreground" aria-hidden="true" />
        </a>

        {/* AI-резюме: свёрнуто — 3 строки, развёрнуто — полный текст */}
        {summary && (
          <p className={cn('text-sm text-muted-foreground mt-1.5 leading-relaxed', !expanded && 'line-clamp-3')}>
            {summary}
          </p>
        )}

        {/* Wave 15: развёрнутое состояние — картинка и описание источника */}
        {expanded && item.imageUrl && (
          <img
            src={item.imageUrl}
            alt=""
            className="mt-2 rounded-lg w-full max-h-56 object-cover"
            onError={(e) => (e.currentTarget.style.display = 'none')}
          />
        )}
        {expanded && item.description && item.description !== summary && (
          <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{item.description}</p>
        )}

        {/* Теги: свёрнуто — до 6, развёрнуто — все */}
        {item.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-2">
            {(expanded ? item.tags : item.tags.slice(0, 6)).map((t) => (
              <Badge key={t} variant="outline" className="text-xs font-normal">#{t}</Badge>
            ))}
            {!expanded && item.tags.length > 6 && (
              <Badge variant="outline" className="text-xs font-normal text-muted-foreground">
                +{item.tags.length - 6}
              </Badge>
            )}
          </div>
        )}

        {/* Действия карточки: релевантность (doc_a §C2) + шеринг + разворот (Wave 15) */}
        <div className="mt-3 pt-3 border-t flex items-center flex-wrap gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleToggle}
            disabled={loading}
            aria-expanded={open}
            className={cn('px-2 h-8 gap-1.5 text-xs', open && 'text-lighthouse')}
          >
            {loading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
            )}
            Почему это важно?
            <ChevronDown className={cn('w-3 h-3 transition-transform', open && 'rotate-180')} aria-hidden="true" />
          </Button>

          <span className="flex-1" aria-hidden="true" />

          {/* Wave 15: адресная рекомендация новости коллеге */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShareOpen(true)}
            className="px-2 h-8 gap-1.5 text-xs text-muted-foreground hover:text-foreground"
            title="Направить новость коллеге — она появится в его ленте с пометкой «Рекомендовано вами»"
          >
            <Share2 className="w-3.5 h-3.5" aria-hidden="true" />
            Поделиться
          </Button>

          {/* Wave 15: развернуть / свернуть карточку */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded((v) => !v)}
            aria-expanded={expanded}
            className="px-2 h-8 gap-1.5 text-xs text-muted-foreground hover:text-foreground"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" aria-hidden="true" />
                Свернуть
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" aria-hidden="true" />
                Развернуть
              </>
            )}
          </Button>
        </div>

        {open && (
          <div className="mt-2 soft-fade-in">
            {loading && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground p-2.5">
                <Loader2 className="w-3.5 h-3.5 animate-spin flex-shrink-0" aria-hidden="true" />
                Анализируем связь новости с вашим профилем…
              </div>
            )}
            {!loading && error && <div className="text-xs text-muted-foreground p-2.5">{error}</div>}
            {!loading && !error && relevance && (
              <RelevancePanel result={relevance} onActionView={setView} />
            )}
          </div>
        )}
      </CardContent>

      {/* Wave 15: диалог «Поделиться новостью» */}
      <ShareNewsDialog
        card={{ id: item.id, title: item.title }}
        open={shareOpen}
        onOpenChange={setShareOpen}
      />
    </Card>
  );
}

// ============================================================================
// === Секция «Новости отрасли» для ленты + блок «Рекомендовано вам» (Wave 15) ===
// ============================================================================

export function NewsFeedSection({ limit = 3 }: { limit?: number }) {
  const [items, setItems] = React.useState<NewsCardItem[] | null>(null);
  // Wave 15: новости, которые отправили текущему пользователю (адресные рекомендации)
  const [shared, setShared] = React.useState<SharedNewsItem[] | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    api<{ items: NewsCardItem[] }>(`/api/news?limit=${limit + 4}`)
      .then((res) => {
        if (cancelled) return;
        // Рекламные карточки (category='ad') в ленте новостей не показываем
        const visible = (res.items ?? []).filter((n) => n.category !== 'ad').slice(0, limit);
        setItems(visible);
      })
      .catch(() => {
        // Лента новостей не критична — при ошибке секция просто не появляется
        if (!cancelled) setItems([]);
      });
    // Адресные рекомендации — честный пустой список при ошибке (секция скрывается)
    api<{ items: SharedNewsItem[] }>('/api/news/shared?limit=10')
      .then((res) => {
        if (cancelled) return;
        const visible = (res.items ?? []).filter((s) => s.card.category !== 'ad');
        setShared(visible);
      })
      .catch(() => {
        if (!cancelled) setShared([]);
      });
    return () => {
      cancelled = true;
    };
  }, [limit]);

  // Загрузка / нет опубликованных новостей — секция не рендерится
  if (items === null || items.length === 0) return null;

  const sharedItems = shared ?? [];

  return (
    <div className="space-y-3" aria-label="Новости отрасли">
      <div className="flex items-center gap-2 text-sm font-semibold flex-wrap">
        <span className="w-1 h-3.5 rounded-full bg-lighthouse" aria-hidden="true" />
        <Newspaper className="w-4 h-4 text-lighthouse" aria-hidden="true" />
        Новости отрасли
        <span className="text-xs font-normal text-muted-foreground">с объяснением, почему это важно вам</span>
      </div>

      {/* Wave 15: «Рекомендовано вам» — новости от коллег (атрибуция на каждой карточке) */}
      {sharedItems.length > 0 && (
        <div className="space-y-3" aria-label="Рекомендовано вам">
          <div className="flex items-center gap-2 text-sm font-semibold flex-wrap">
            <span className="w-1 h-3.5 rounded-full bg-lighthouse" aria-hidden="true" />
            <UserPlus className="w-4 h-4 text-lighthouse" aria-hidden="true" />
            Рекомендовано вам
            <span className="text-xs font-normal text-muted-foreground">новости, направленные коллегами лично вам</span>
          </div>
          {sharedItems.map((s) => (
            <NewsCardWithRelevance key={s.shareId} item={s.card} sharedBy={s} />
          ))}
        </div>
      )}

      {items.map((n) => (
        <NewsCardWithRelevance key={n.id} item={n} />
      ))}
    </div>
  );
}
