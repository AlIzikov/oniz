// BizON — CompactCalendar (мини-календарь для RightRail на странице Ленты)
// Показывает текущий месяц с точками событий + список ближайших 3 событий
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Calendar as CalendarIcon, ChevronRight, Video, MapPin, Users } from 'lucide-react';
import { cn } from '@/lib/utils';

const WEEKDAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const MONTHS = [
  'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь',
];

interface CalendarEvent {
  id: string;
  title: string;
  startDate: string;
  format: string;
  location: string | null;
}

const CATEGORY_COLORS: Record<string, string> = {
  meetup: 'bg-emerald-500',
  workshop: 'bg-blue-500',
  webinar: 'bg-purple-500',
  conference: 'bg-orange-500',
  hackathon: 'bg-red-500',
  other: 'bg-muted-foreground',
};

export function CompactCalendar() {
  const setView = useAppStore((s) => s.setView);
  const [events, setEvents] = React.useState<CalendarEvent[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [currentMonth, setCurrentMonth] = React.useState(() => new Date());

  React.useEffect(() => {
    async function load() {
      try {
        const res = await api<{ events: any[] }>('/api/events?limit=20');
        setEvents(res.events.map((e: any) => ({
          id: e.id, title: e.title, startDate: e.startDate,
          format: e.format, location: e.location,
        })));
      } catch {} finally { setLoading(false); }
    }
    load();
  }, []);

  // Группировка событий по дням
  const eventsByDay = React.useMemo(() => {
    const map = new Map<string, number>();
    for (const e of events) {
      const d = new Date(e.startDate);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      map.set(key, (map.get(key) ?? 0) + 1);
    }
    return map;
  }, [events]);

  // Сетка месяца
  const days = React.useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const firstDayOfWeek = (firstDay.getDay() + 6) % 7;
    const result: (Date | null)[] = [];
    for (let i = 0; i < firstDayOfWeek; i++) result.push(null);
    for (let d = 1; d <= lastDay.getDate(); d++) result.push(new Date(year, month, d));
    while (result.length < 42) result.push(null);
    return result;
  }, [currentMonth]);

  const today = new Date();
  const isToday = (d: Date) =>
    d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear();

  // Ближайшие 3 события
  const upcoming = React.useMemo(() => {
    const now = Date.now();
    return events
      .filter(e => new Date(e.startDate).getTime() >= now)
      .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
      .slice(0, 3);
  }, [events]);

  function prevMonth() { setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() - 1, 1)); }
  function nextMonth() { setCurrentMonth(d => new Date(d.getFullYear(), d.getMonth() + 1, 1)); }

  return (
    <div>
      <SectionTitle>Календарь событий</SectionTitle>
      <Card className="border-lighthouse/20">
        <CardContent className="p-3">
          {loading ? (
            <Skeleton className="h-40 w-full rounded" />
          ) : (
            <>
              {/* Заголовок месяца с навигацией */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold">
                  {MONTHS[currentMonth.getMonth()]} {currentMonth.getFullYear()}
                </span>
                <div className="flex gap-0.5">
                  <button onClick={prevMonth} className="p-0.5 rounded hover:bg-accent" title="Предыдущий месяц">
                    <ChevronRight className="w-3 h-3 rotate-180" />
                  </button>
                  <button onClick={nextMonth} className="p-0.5 rounded hover:bg-accent" title="Следующий месяц">
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Дни недели */}
              <div className="grid grid-cols-7 gap-0.5 mb-1">
                {WEEKDAYS.map(d => (
                  <div key={d} className="text-center text-xs font-semibold text-muted-foreground uppercase">
                    {d}
                  </div>
                ))}
              </div>

              {/* Сетка дней */}
              <div className="grid grid-cols-7 gap-0.5 mb-3">
                {days.slice(0, 35).map((day, i) => {
                  if (!day) return <div key={i} className="aspect-square" />;
                  const key = `${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, '0')}-${String(day.getDate()).padStart(2, '0')}`;
                  const hasEvents = (eventsByDay.get(key) ?? 0) > 0;
                  const current = isToday(day);
                  return (
                    <div
                      key={i}
                      className={cn(
                        'aspect-square rounded flex flex-col items-center justify-center text-xs tabular-nums relative',
                        current ? 'bg-lighthouse/10 text-lighthouse font-bold' : 'text-foreground/80'
                      )}
                      title={hasEvents ? `${eventsByDay.get(key)} событий` : undefined}
                    >
                      {day.getDate()}
                      {hasEvents && (
                        <span className="absolute bottom-0.5 w-1 h-1 rounded-full bg-emerald-500" />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Ближайшие события */}
              {upcoming.length > 0 && (
                <div className="pt-2 border-t">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1.5">
                    Ближайшие
                  </div>
                  <div className="space-y-1">
                    {upcoming.map(e => {
                      const date = new Date(e.startDate);
                      const formatIcon = e.format === 'online' ? <Video className="w-2.5 h-2.5" /> : e.format === 'hybrid' ? <Users className="w-2.5 h-2.5" /> : <MapPin className="w-2.5 h-2.5" />;
                      return (
                        <button
                          key={e.id}
                          onClick={() => setView('events')}
                          className="w-full flex items-center gap-1.5 p-1 rounded hover:bg-accent transition text-left"
                          title={e.title}
                        >
                          <div className="w-6 h-6 rounded bg-lighthouse/10 flex flex-col items-center justify-center flex-shrink-0">
                            <span className="text-xs font-bold text-lighthouse tabular-nums leading-none">{date.getDate()}</span>
                            <span className="text-[7px] text-muted-foreground uppercase leading-none mt-0.5">
                              {date.toLocaleDateString('ru-RU', { month: 'short' })}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-medium truncate">{e.title}</div>
                            <div className="text-xs text-muted-foreground flex items-center gap-0.5">
                              {formatIcon}
                              {e.format === 'online' ? 'Онлайн' : e.format === 'hybrid' ? 'Гибрид' : 'Офлайн'}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <Button
                variant="ghost"
                size="sm"
                className="w-full mt-2 text-xs h-7"
                onClick={() => setView('events')}
              >
                Все события <ChevronRight className="w-2.5 h-2.5" />
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Локальный SectionTitle (дублирует основной, но нужен для изоляции)
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 mb-2">
      <span className="w-1 h-3 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{children}</span>
    </div>
  );
}
