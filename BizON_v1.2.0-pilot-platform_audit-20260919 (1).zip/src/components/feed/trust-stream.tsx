// BizON — Trust Stream View (лента доверия + посты + спонсорская реклама)
// Режимы: Mini (плотный) / VK (широкий с медиа)
// Спонсорские карточки каждые 10 постов
// Поддержка подразделов правого rail (feedSubSection): recommended/all/friends/mine/favorites/favGroups/favNews
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { PostComposer } from './post-composer';
import { FeedRecommendations } from './feed-recommendations';
import { NewsFeedSection } from './news-card';
import { RecommendationsCarousel } from './recommendations-carousel';
import type { FeedItem, PostPublic, SponsoredAd } from '@/lib/types';
import {
  FolderCheck, Award, Star, UserPlus, MessageSquare, Briefcase, TrendingUp,
  Heart, MessageCircle, Send, Megaphone, Loader2, X, ExternalLink, Image as ImageIcon,
  Bookmark, Minimize2, Maximize2, Shuffle, Sparkles, Mail, Check,
  BarChart3, Gem, AlarmClock, Lightbulb, Trophy, HelpCircle, Newspaper,
} from 'lucide-react';
import { ThreeDotsMenu } from '@/components/common/three-dots-menu';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

// Wave 3 (S-062): подписи типов постов (ТЗ 4.2)
const TYPE_LABELS: Record<string, string> = {
  expert: 'Опыт',
  success: 'Успех',
  question: 'Вопрос',
  news: 'Новость',
  poll: 'Опрос',
  subscription: 'Платный пост',
  term: 'Срочно',
};

const EVENT_META: Record<string, { icon: React.ReactNode; label: string; color: string }> = {
  project_completed: { icon: <FolderCheck className="w-4 h-4" />, label: 'Проект завершён', color: 'impact-high' },
  skill_confirmed: { icon: <Award className="w-4 h-4" />, label: 'Навык подтверждён', color: 'impact-medium' },
  positive_review: { icon: <Star className="w-4 h-4" />, label: 'Положительный отзыв', color: 'impact-medium' },
  connection_accepted: { icon: <UserPlus className="w-4 h-4" />, label: 'Новая связь', color: 'impact-low' },
  intro_sent: { icon: <MessageSquare className="w-4 h-4" />, label: 'Интро отправлено', color: 'impact-low' },
  job_matched: { icon: <Briefcase className="w-4 h-4" />, label: 'AI-подбор вакансии', color: 'impact-medium' },
  post_published: { icon: <MessageCircle className="w-4 h-4" />, label: 'Новый пост', color: 'impact-medium' },
  ad_clicked: { icon: <TrendingUp className="w-4 h-4" />, label: 'Реклама', color: 'impact-low' },
};

type FeedMode = 'mini' | 'vk';

// Заголовки разделов (по feedSubSection)
const SUBSECTION_META: Record<string, { title: string; subtitle: string; showComposer: boolean }> = {
  recommended: { title: 'Лента новостей',    subtitle: 'AI-подбор постов по вашему профилю', showComposer: true },
  all:         { title: 'Все новости',        subtitle: 'Полный хронологический список',     showComposer: true },
  friends:     { title: 'Новости друзей',     subtitle: 'Только от ваших контактов',          showComposer: true },
  mine:        { title: 'Мои посты',          subtitle: 'Ваши опубликованные посты',          showComposer: true },
  favorites:   { title: 'Избранное',          subtitle: 'Сохранённые посты',                  showComposer: false },
  favGroups:   { title: 'Избранные группы',   subtitle: 'Посты из ваших сообществ',           showComposer: false },
  favNews:     { title: 'Избранные новости',  subtitle: 'Подписки на авторов',                showComposer: false },
};

export function TrustStreamView() {
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const feedSubSection = useAppStore((s) => s.feedSubSection);
  const [items, setItems] = React.useState<FeedItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [offset, setOffset] = React.useState(0);
  const [hasMore, setHasMore] = React.useState(true);
  const [mode, setMode] = React.useState<FeedMode>('vk');
  const [feedMode, setFeedMode] = React.useState<'all' | 'posts' | 'achievements'>('all');
  const [randomizing, setRandomizing] = React.useState(false);

  // === Сохранение позиции скролла при смене режима/фильтра ===
  // Чтобы страница не прыгала — запоминаем scrollY главного контейнера <main>,
  // после ререндера восстанавливаем. Это касается всех переключений внутри ленты.
  const savedScrollRef = React.useRef<number | null>(null);
  const mainScrollRef = React.useRef<HTMLElement | null>(null);

  // Найти главный scroll-контейнер (тег <main> в AppShell)
  const getMainScroll = React.useCallback(() => {
    if (mainScrollRef.current) return mainScrollRef.current;
    const main = document.querySelector('main');
    if (main) mainScrollRef.current = main as HTMLElement;
    return mainScrollRef.current;
  }, []);

  // Сохранить/восстановить скролл — вызывается в useEffect после смены mode/subSection
  React.useEffect(() => {
    if (savedScrollRef.current === null) return;
    const main = getMainScroll();
    if (main) {
      // Востановление в следующем кадре (после ререндера)
      requestAnimationFrame(() => {
        main.scrollTop = savedScrollRef.current!;
        savedScrollRef.current = null;
      });
    }
  }, [mode, feedSubSection, feedMode, getMainScroll]);

  const loadItems = React.useCallback(async (reset = false, opts?: { random?: boolean }) => {
    setLoading(true);
    try {
      const newOffset = reset ? 0 : offset;
      const randomParam = opts?.random ? '&random=true' : '';
      // Для "Избранного" используем отдельный эндпоинт /api/posts/saved
      if (feedSubSection === 'favorites') {
        const res = await api<{ posts: any[]; total: number }>('/api/posts/saved');
        const savedItems: FeedItem[] = res.posts.map(p => ({
          id: `post-${p.id}`,
          eventType: 'post_published',
          impactScore: 0.5,
          weight: 1,
          payload: { postId: p.id },
          createdAt: p.createdAt,
          user: { id: p.author.id, name: p.author.name, title: p.author.title, avatarUrl: p.author.avatarUrl, ipScore: p.author.ipScore },
          post: {
            id: p.id,
            content: p.content,
            tags: p.tags ?? [],
            type: p.type,
            ctaText: p.ctaText,
            ctaUrl: p.ctaUrl,
            imageUrl: p.imageUrl,
            linkPreview: p.linkPreview,
            likesCount: p.likesCount,
            commentsCount: p.commentsCount,
            likedByMe: p.likedByMe,
            createdAt: p.createdAt,
            author: { ...p.author, level: p.author.level ?? 'basic', subscriptionTier: p.author.subscriptionTier ?? 'free' },
            comments: [],
          } as PostPublic,
          kind: 'post',
        }));
        // Если random — перемешиваем и избранное
        if (opts?.random) {
          for (let i = savedItems.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [savedItems[i], savedItems[j]] = [savedItems[j], savedItems[i]];
          }
        }
        setItems(savedItems);
        setHasMore(false);
      } else {
        const res = await api<{ items: FeedItem[]; total: number }>(`/api/feed?limit=20&offset=${newOffset}&mode=${feedMode}&sub=${feedSubSection}${randomParam}`);
        if (reset) {
          setItems(res.items);
          setOffset(20);
        } else {
          setItems((prev) => [...prev, ...res.items]);
          setOffset(newOffset + 20);
        }
        setHasMore(res.items.length === 20);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [offset, feedMode, feedSubSection]);

  React.useEffect(() => {
    loadItems(true);
     
  }, [feedMode, feedSubSection]);

  // Обработчик смены режима — СОХРАНЯЕМ СКРОЛЛ, потом меняем mode
  // Эффект [mode] выше восстановит позицию после ререндера
  function handleModeChange(newMode: FeedMode) {
    if (newMode === mode) return;
    const main = getMainScroll();
    if (main) savedScrollRef.current = main.scrollTop;
    setMode(newMode);
  }

  // Обработчик «Случайные новости» — перемешивает посты, БЕЗ прыжка скролла
  async function handleRandom() {
    if (randomizing) return;
    setRandomizing(true);
    // Сохраняем скролл, чтобы после перемешивания остаться на той же позиции
    const main = getMainScroll();
    if (main) savedScrollRef.current = main.scrollTop;
    try {
      await loadItems(true, { random: true });
      toast({ title: 'Посты перемешаны', description: 'Показаны в случайном порядке' });
    } finally {
      setRandomizing(false);
    }
  }

  function handleNewPost(post: PostPublic) {
    if (feedSubSection !== 'mine' && feedSubSection !== 'recommended' && feedSubSection !== 'all') return;
    const newItem: FeedItem = {
      id: `post-${post.id}`,
      eventType: 'post_published',
      impactScore: 0.9,
      weight: 1,
      payload: { postId: post.id, preview: post.content.slice(0, 100), postType: post.type },
      createdAt: post.createdAt,
      user: {
        id: post.author.id,
        name: post.author.name,
        title: post.author.title,
        avatarUrl: post.author.avatarUrl,
        ipScore: post.author.ipScore,
      },
      post,
      kind: 'post',
    };
    setItems((prev) => [newItem, ...prev]);
  }

  function handleHideSponsored(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
    toast({ title: 'Реклама скрыта', description: 'В дальнейшем AI будет учитывать ваши предпочтения' });
  }

  const meta = SUBSECTION_META[feedSubSection] ?? SUBSECTION_META.recommended;
  // Скрываем табы Все/Посты/Достижения в режимах, где они не релевантны
  const showFeedModeTabs = feedSubSection === 'recommended' || feedSubSection === 'all';

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold">{meta.title}</h1>
          <p className="text-sm text-muted-foreground">{meta.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Mode toggle — sliding switch с эффектом переключения (как iOS toggle) */}
          <div className="relative inline-flex rounded-lg border bg-muted/30 p-0.5">
            {/* Скользящий индикатор — анимированно перемещается между позициями */}
            <div
              className={cn(
                'absolute top-0.5 bottom-0.5 w-8 rounded-md bg-primary shadow-sm transition-transform duration-200 ease-out',
                mode === 'mini' ? 'translate-x-0' : 'translate-x-8'
              )}
              aria-hidden="true"
            />
            <button
              onClick={() => handleModeChange('mini')}
              className={cn(
                'relative z-10 flex items-center justify-center w-8 h-7 rounded-md transition-colors duration-200',
                mode === 'mini' ? 'text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
              title="Свёрнутый режим — только аватарка, имя и текст поста"
              aria-label="Свёрнутый режим"
              aria-pressed={mode === 'mini'}
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleModeChange('vk')}
              className={cn(
                'relative z-10 flex items-center justify-center w-8 h-7 rounded-md transition-colors duration-200',
                mode === 'vk' ? 'text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
              title="Развёрнутый режим — с медиа, превью ссылок, комментариями"
              aria-label="Развёрнутый режим"
              aria-pressed={mode === 'vk'}
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
          {/* Кнопка «Случайные новости» — перемешивает посты */}
          <Button
            variant="outline"
            size="sm"
            onClick={handleRandom}
            disabled={randomizing || loading}
            title="Показать посты в случайном порядке"
            className="gap-1.5"
          >
            {randomizing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Shuffle className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">Случайные</span>
          </Button>
          <Button variant="outline" size="sm" onClick={() => loadItems(true)} disabled={loading}>
            Обновить
          </Button>
        </div>
      </div>

      {/* Composer — только в режимах, где пользователь создаёт контент */}
      {meta.showComposer && <PostComposer onPosted={handleNewPost} />}

      {/* 4-g: AI-новости отрасли с блоком «Почему это важно для вас»
          (doc_a §C2: NewsRelevance — UI-проводка; скрывается без published-новостей) */}
      {(feedSubSection === 'recommended' || feedSubSection === 'all') && <NewsFeedSection />}

      {/* 4-c: карусель рекомендаций (Vings) с анти-эхо-камерой:
          «Не интересно» → IgnoredTopic, Epsilon-Greedy exploration-бейджи, 70/20/10 */}
      {(feedSubSection === 'recommended' || feedSubSection === 'all') && <RecommendationsCarousel />}

      {/* Feed mode filter — Все / Посты / Достижения (только в recommended/all) */}
      {showFeedModeTabs && (
        <div className="flex gap-1 border-b">
          {([
            ['all', 'Все'],
            ['posts', 'Посты'],
            ['achievements', 'Достижения'],
          ] as const).map(([f, label]) => (
            <button
              key={f}
              onClick={() => setFeedMode(f)}
              className={cn(
                'px-3 py-1.5 text-sm border-b-2 -mb-px transition',
                feedMode === f ? 'border-primary text-primary font-medium' : 'border-transparent text-muted-foreground hover:text-foreground'
              )}
            >
              {label}
            </button>
          ))}
        </div>
      )}

      {loading && items.length === 0 ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Card key={i} className="p-4">
              <div className="flex gap-3">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">
            {feedSubSection === 'favorites'
              ? 'В избранном пока пусто. Нажмите на иконку закладки в карточке поста.'
              : feedSubSection === 'friends'
                ? 'Ваши друзья ещё не опубликовали посты. Найдите контакты в разделе «Контакты».'
                : feedSubSection === 'mine'
                  ? 'Вы ещё не публиковали посты. Используйте форму выше.'
                  : feedSubSection === 'favGroups'
                    ? 'Вы пока не состоите в сообществах. Загляните в раздел «Сообщества».'
                    : feedSubSection === 'favNews'
                      ? 'У вас нет подписок на авторов. В Фазе 2 появится кнопка «Подписаться».'
                      : 'В ленте пока пусто. Опубликуйте первый пост выше!'}
          </p>
        </Card>
      ) : (
        <>
          {items.map((item, idx) => (
            <React.Fragment key={item.id}>
              <FeedCard
                item={item}
                onUserClick={setProfileUserId}
                mode={mode}
                onHideSponsored={handleHideSponsored}
              />
              {/* Контекстные рекомендации — только в recommended/all, не в saved/mine/favorites */}
              {(feedSubSection === 'recommended' || feedSubSection === 'all') && idx === 2 && (
                <FeedRecommendations type="jobs" />
              )}
              {(feedSubSection === 'recommended' || feedSubSection === 'all') && idx === 6 && (
                <FeedRecommendations type="people" />
              )}
              {(feedSubSection === 'recommended' || feedSubSection === 'all') && idx === 11 && (
                <FeedRecommendations type="events" />
              )}
            </React.Fragment>
          ))}
          {hasMore && (
            <Button variant="outline" className="w-full" onClick={() => loadItems(false)} disabled={loading}>
              {loading ? 'Загрузка...' : 'Загрузить ещё'}
            </Button>
          )}
        </>
      )}
    </div>
  );
}

function FeedCard({ item, onUserClick, mode, onHideSponsored }: {
  item: FeedItem;
  onUserClick: (id: string) => void;
  mode: FeedMode;
  onHideSponsored: (id: string) => void;
}) {
  if (item.kind === 'sponsored' && item.sponsored) {
    return <SponsoredCard ad={item.sponsored} onHide={() => onHideSponsored(item.id)} />;
  }
  if (item.kind === 'post' && item.post) {
    return <PostCard post={item.post} onUserClick={onUserClick} mode={mode} />;
  }
  return <ReputationEventCard item={item} onUserClick={onUserClick} />;
}

function ReputationEventCard({ item, onUserClick }: { item: FeedItem; onUserClick: (id: string) => void }) {
  const meta = EVENT_META[item.eventType] ?? EVENT_META.intro_sent;
  const impactLevel = item.impactScore >= 0.7 ? 'impact-high' : item.impactScore >= 0.4 ? 'impact-medium' : 'impact-low';
  // Идеология палитры «Маяк»: красный — только для ошибок. Знаковые события
  // подсвечиваются teal (свет маяка), средние — sky (горизонт), низкие — нейтрально.
  const impactBg = item.impactScore >= 0.7 ? 'bg-teal-500/5 border-teal-500/40' : item.impactScore >= 0.4 ? 'bg-sky-500/5 border-sky-500/25' : 'bg-muted/50 border-border';

  return (
    <Card className={cn('p-4 hover:shadow-md transition-shadow border-l-4', impactBg)}>
      <div className="flex gap-3">
        <button onClick={() => onUserClick(item.user.id)} className="shrink-0">
          <UserAvatar name={item.user.name} avatarUrl={item.user.avatarUrl} size="md" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className="flex items-center gap-2 flex-wrap">
              <button onClick={() => onUserClick(item.user.id)} className="font-semibold hover:underline">
                {item.user.name}
              </button>
              <TrustBadge ipScore={item.user.ipScore} level="basic" size="sm" />
            </div>
            <span className="text-xs text-muted-foreground whitespace-nowrap">
              {formatRelative(item.createdAt)}
            </span>
          </div>
          <div className={cn('flex items-center gap-1.5 text-sm font-medium mb-2', impactLevel)}>
            {meta.icon}
            <span>{meta.label}</span>
          </div>
          <EventContent eventType={item.eventType} payload={item.payload} />
        </div>
      </div>
    </Card>
  );
}

function PostCard({ post, onUserClick, mode }: { post: PostPublic; onUserClick: (id: string) => void; mode: FeedMode }) {
  const { user } = useAppStore();
  const [liked, setLiked] = React.useState(post.likedByMe);
  const [likesCount, setLikesCount] = React.useState(post.likesCount);
  const [liking, setLiking] = React.useState(false);
  const [saved, setSaved] = React.useState(false);
  const [showComments, setShowComments] = React.useState(false);
  const [commentText, setCommentText] = React.useState('');
  const [comments, setComments] = React.useState(post.comments);
  const [commenting, setCommenting] = React.useState(false);
  // Wave 11-a: диалог отклика В ПЛАТФОРМЕ (вместо прямой ссылки CTA)
  const [respondOpen, setRespondOpen] = React.useState(false);

  async function handleLike() {
    if (!user || liking) return;
    setLiking(true);
    const wasLiked = liked;
    setLiked(!wasLiked);
    setLikesCount((c) => c + (wasLiked ? -1 : 1));
    try {
      await api(`/api/posts/${post.id}/like`, { method: 'POST' });
    } catch (e: any) {
      setLiked(wasLiked);
      setLikesCount((c) => c + (wasLiked ? 1 : -1));
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLiking(false);
    }
  }

  async function handleSave() {
    if (!user) return;
    try {
      const res = await api<{ saved: boolean }>(`/api/posts/${post.id}/save`, { method: 'POST' });
      setSaved(res.saved);
      toast({ title: res.saved ? 'Пост сохранён в Избранное' : 'Удалено из избранного' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handleComment() {
    if (!user || !commentText.trim() || commenting) return;
    setCommenting(true);
    try {
      const res = await api<{ comment: any }>(`/api/posts/${post.id}/comment`, {
        method: 'POST',
        body: JSON.stringify({ content: commentText.trim() }),
      });
      setComments((prev) => [...prev, res.comment]);
      setCommentText('');
      toast({ title: 'Комментарий добавлен' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setCommenting(false);
    }
  }

  const isCommercial = post.type === 'commercial';
  const isMini = mode === 'mini';
  // Wave 11-a: https-CTA остаётся доступной как вторичный путь «Открыть страницу
  // автора» (mailto больше не открывает почту по клику — основной путь — отклик в платформе)
  const isExternalCta = isCommercial && !!post.ctaUrl && /^https?:\/\//i.test(post.ctaUrl);
  // Expert mode — для авторов с IP ≥ 70 показываем пост развёрнуто
  // (большая аватарка, title автора, бейдж «Эксперт», без line-clamp на тексте)
  const isExpertPost = !isMini && post.author.ipScore >= 70;

  return (
    <Card className={cn(
      'hover:shadow-md transition-shadow soft-fade-in relative',
      isMini ? 'p-3' : 'p-4',
      isCommercial && !isMini && 'border-emerald-500/30 bg-emerald-500/5',
      isExpertPost && 'border-lighthouse/30 bg-lighthouse-gradient-soft'
    )}>
      <div className="flex gap-3">
        <button onClick={() => onUserClick(post.author.id)} className="shrink-0">
          <UserAvatar
            name={post.author.name}
            avatarUrl={post.author.avatarUrl}
            size={isMini ? 'sm' : isExpertPost ? 'lg' : 'md'}
          />
        </button>
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => onUserClick(post.author.id)}
                className={cn('font-semibold hover:underline', isExpertPost ? 'text-base' : 'text-sm')}
              >
                {post.author.name}
              </button>
              {!isMini && <TrustBadge ipScore={post.author.ipScore} level={post.author.level} size="sm" />}
              {/* Бейдж «Эксперт» для постов с высоким IP — визуальная иерархия авторитета */}
              {isExpertPost && (
                <Badge variant="outline" className="text-xs gap-1 border-lighthouse/40 text-lighthouse bg-lighthouse/5">
                  <Sparkles className="w-3 h-3" /> Эксперт
                </Badge>
              )}
              {!isMini && post.author.subscriptionTier !== 'free' && (
                <Badge variant="outline" className={cn('text-xs', post.author.subscriptionTier === 'business' ? 'tier-business' : 'tier-pro')}>
                  {post.author.subscriptionTier === 'business' ? 'Business' : 'Pro'}
                </Badge>
              )}
              {!isMini && isCommercial && (
                <Badge variant="outline" className="text-xs gap-1 border-emerald-500/40 text-emerald-700 dark:text-emerald-400">
                  <Megaphone className="w-3 h-3" /> Commercial
                </Badge>
              )}
              {/* Wave 3 S-062: бейджи новых типов (ТЗ 4.2) */}
              {!isMini && post.type !== 'regular' && post.type !== 'commercial' && post.type !== 'announcement' && (
                <Badge variant="outline" className="text-xs gap-1 border-primary/40 text-primary">
                  {post.type === 'poll' && <BarChart3 className="w-3 h-3" />}
                  {post.type === 'subscription' && <Gem className="w-3 h-3" />}
                  {post.type === 'term' && <AlarmClock className="w-3 h-3" />}
                  {post.type === 'expert' && <Lightbulb className="w-3 h-3" />}
                  {post.type === 'success' && <Trophy className="w-3 h-3" />}
                  {post.type === 'question' && <HelpCircle className="w-3 h-3" />}
                  {post.type === 'news' && <Newspaper className="w-3 h-3" />}
                  {TYPE_LABELS[post.type] ?? post.type}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {formatRelative(post.createdAt)}
              </span>
              {/* Кнопка "Сохранить" — рядом с временем */}
              <button
                onClick={handleSave}
                className={cn(
                  'p-1 rounded-md transition',
                  saved ? 'text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                )}
                title={saved ? 'Убрать из избранного' : 'Сохранить в избранное'}
              >
                <Bookmark className={cn('w-3.5 h-3.5', saved && 'fill-current')} />
              </button>
            </div>
          </div>

          {!isMini && post.author.title && (
            <div className={cn('text-xs text-muted-foreground mb-2', isExpertPost && 'text-foreground/70 font-medium')}>
              {post.author.title}
            </div>
          )}

          {/* Post content — multiline preserved
              Для постов экспертов (IP≥70): больший шрифт, без line-clamp (полный текст) */}
          <div className={cn(
            'whitespace-pre-wrap leading-relaxed mb-3',
            isMini ? 'text-sm line-clamp-3' : isExpertPost ? 'text-base' : 'text-sm'
          )}>
            {post.content}
          </div>

          {/* Wave 3 S-062: paywall платного поста (решение о доступе — с сервера) */}
          {!isMini && post.locked && (
            <div className="mb-3 rounded-lg border border-primary/30 bg-primary/5 p-3 flex flex-wrap items-center justify-between gap-2">
              <div className="text-sm flex items-center gap-1.5">
                <Gem className="w-4 h-4 text-primary" />
                Закрытый пост · доступ за <strong className="tabular-nums">{post.subscriptionPriceLumens} люменов</strong>
              </div>
              <UnlockButton postId={post.id} price={post.subscriptionPriceLumens ?? 0} />
            </div>
          )}

          {/* Wave 3 S-062: опрос */}
          {!isMini && post.type === 'poll' && post.pollResults && (
            <PollInline postId={post.id} results={post.pollResults} />
          )}

          {/* Wave 3 S-062: дедлайн срочного поста */}
          {!isMini && post.type === 'term' && post.termExpiresAt && (
            <div className="mb-3 text-xs text-muted-foreground flex items-center gap-1">
              <AlarmClock className="w-3 h-3" />
              Актуально до {new Date(post.termExpiresAt).toLocaleString('ru-RU')}
            </div>
          )}

          {/* Image (только в VK-режиме). Для экспертов — крупнее (без max-w ограничения) */}
          {!isMini && post.imageUrl && (
            <div className={cn('rounded-lg overflow-hidden border mb-3', isExpertPost ? 'max-w-2xl' : 'max-w-lg')}>
              <img src={post.imageUrl} alt="" className="w-full max-h-96 object-cover" onError={(e) => (e.currentTarget.parentElement!.style.display = 'none')} />
            </div>
          )}

          {/* Link preview (только в VK-режиме) */}
          {!isMini && post.linkPreview && (
            <a href={post.linkPreview.url} target="_blank" rel="noopener noreferrer" className="block mb-3 rounded-lg border overflow-hidden hover:border-primary transition max-w-lg">
              {post.linkPreview.image && (
                <div className="h-32 bg-muted">
                  <img src={post.linkPreview.image} alt="" className="w-full h-full object-cover" onError={(e) => (e.currentTarget.parentElement!.style.display = 'none')} />
                </div>
              )}
              <div className="p-2.5 bg-muted/40">
                <div className="text-xs text-muted-foreground truncate">{post.linkPreview.url}</div>
                <div className="text-sm font-medium truncate">{post.linkPreview.title}</div>
                {post.linkPreview.description && (
                  <div className="text-xs text-muted-foreground line-clamp-2">{post.linkPreview.description}</div>
                )}
              </div>
            </a>
          )}

          {/* Tags */}
          {post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-3">
              {post.tags.map((t) => (
                <Badge key={t} variant="secondary" className="text-xs">#{t}</Badge>
              ))}
            </div>
          )}

          {/* Commercial CTA — Wave 11-a: отклик В ПЛАТФОРМЕ (диалог «Отклик»),
              почтовый клиент по клику НЕ открывается. Прямая https-ссылка —
              вторичный путь рядом с кнопкой. */}
          {isCommercial && post.ctaText && post.ctaUrl && (
            <div className="flex flex-wrap items-center gap-2 mt-1 mb-3">
              <button
                type="button"
                onClick={() => {
                  if (!user) {
                    toast({ title: 'Войдите, чтобы откликнуться', variant: 'destructive' });
                    return;
                  }
                  if (post.author.id === user.id) {
                    toast({ title: 'Это ваш пост', description: 'Отклик можно оставить только на чужое предложение' });
                    return;
                  }
                  setRespondOpen(true);
                }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 transition"
              >
                {post.ctaText}
                <Send className="w-3.5 h-3.5" />
              </button>
              {isExternalCta && (
                <a
                  href={post.ctaUrl ?? '#'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline"
                >
                  Открыть страницу автора
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-1 mt-1 pt-2 border-t">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              disabled={liking}
              className={cn('text-xs', liked && 'text-teal-600 hover:text-teal-700')}
            >
              <Heart className={cn('w-4 h-4 mr-1', liked && 'fill-current')} />
              {likesCount > 0 && likesCount}
              {!isMini && <span className="ml-1">Нравится</span>}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments((v) => !v)}
              className="text-xs"
            >
              <MessageCircle className="w-4 h-4 mr-1" />
              {post.commentsCount > 0 && post.commentsCount}
              {!isMini && <span className="ml-1">Комментарии</span>}
            </Button>
            <div className="ml-auto">
              <ThreeDotsMenu itemName={post.content.slice(0, 30)} />
            </div>
          </div>

          {/* Comments */}
          {showComments && !isMini && (
            <div className="mt-3 space-y-2 soft-fade-in">
              {comments.map((c) => (
                <div key={c.id} className="flex gap-2 p-2 rounded-md bg-muted/40">
                  <UserAvatar name={c.author.name} avatarUrl={c.author.avatarUrl} size="xs" />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium">{c.author.name}</div>
                    <div className="text-sm">{c.content}</div>
                  </div>
                  <span className="text-xs text-muted-foreground">{formatRelative(c.createdAt)}</span>
                </div>
              ))}
              {user && (
                <div className="flex gap-2 items-end">
                  <Textarea
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Ваш комментарий..."
                    className="min-h-[40px] text-sm resize-none"
                    rows={1}
                  />
                  <Button size="sm" onClick={handleComment} disabled={!commentText.trim() || commenting}>
                    {commenting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {/* Wave 11-a: диалог отклика в платформе (портал Radix — позиция в DOM не важна) */}
      <RespondDialog post={post} open={respondOpen} onOpenChange={setRespondOpen} />
    </Card>
  );
}

// Wave 11-a: диалог отклика на commercial-пост ВНУТРИ платформы.
// Порядок честности: сначала отклик уходит в платформу (Notification автору,
// POST /api/posts/[id]/respond), письмо — только опциональное дублирование
// через почтовый клиент пользователя (mailto). Сервер письмо не отправляет
// (emailDelivery: 'mailto_fallback'), поэтому кнопка mailto появляется только
// после успешного отклика и только если автор включил notifyByEmail
// и его email известен (authorEmail приходит из API, приватность соблюдена).
function RespondDialog({ post, open, onOpenChange }: {
  post: PostPublic;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [text, setText] = React.useState('');
  const [sending, setSending] = React.useState(false);
  const [sent, setSent] = React.useState<{ notifyByEmail: boolean; authorEmail: string | null } | null>(null);
  const maxLen = 1000;

  // Сброс состояния при каждом открытии диалога
  React.useEffect(() => {
    if (open) {
      setText('');
      setSent(null);
      setSending(false);
    }
  }, [open]);

  const ctaLabel = post.ctaText || 'предложение';

  async function handleSend() {
    if (!text.trim() || sending) return;
    setSending(true);
    try {
      const res = await api<{ ok: boolean; notifyByEmail: boolean; authorEmail: string | null; emailDelivery: string | null }>(
        `/api/posts/${post.id}/respond`,
        { method: 'POST', body: JSON.stringify({ content: text.trim() }) },
      );
      setSent({ notifyByEmail: res.notifyByEmail === true, authorEmail: res.authorEmail ?? null });
      toast({ title: 'Отклик отправлен', description: 'Автор получит уведомление в платформе' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  // mailto доступен ТОЛЬКО после отправки отклика в платформе (порядок важен:
  // сначала in-platform, email — дублирование). Подпись честная:
  // «откроется ваш почтовый клиент» — платформа письмо не отправляет.
  const mailtoHref =
    sent?.notifyByEmail && sent.authorEmail
      ? `mailto:${sent.authorEmail}?subject=${encodeURIComponent(`Отклик: ${ctaLabel}`)}&body=${encodeURIComponent(text.trim())}`
      : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto scroll-area-thin sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-base pr-6">Отклик на «{ctaLabel}»</DialogTitle>
          <DialogDescription className="text-sm">
            Отклик уйдёт автору в уведомления платформы
          </DialogDescription>
        </DialogHeader>

        {sent ? (
          <div className="space-y-3">
            <div className="flex items-start gap-2 rounded-md bg-teal-500/10 border border-teal-500/30 p-3">
              <Check className="w-4 h-4 text-teal-600 dark:text-teal-400 mt-0.5 shrink-0" />
              <div className="text-sm">
                <div className="font-medium">Отклик отправлен</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Автор увидит его в уведомлениях платформы.
                </div>
              </div>
            </div>
            {mailtoHref && (
              <div className="space-y-1">
                <a
                  href={mailtoHref}
                  className="inline-flex items-center gap-1.5 text-sm text-primary underline underline-offset-2 hover:no-underline"
                >
                  <Mail className="w-3.5 h-3.5" /> Продублировать письмом
                </a>
                <p className="text-xs text-muted-foreground">откроется ваш почтовый клиент</p>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
                Готово
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <>
            <Textarea
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, maxLen))}
              placeholder={`Расскажите, почему вам интересно «${ctaLabel}»...`}
              rows={5}
              className="min-h-[110px] text-sm resize-none"
              aria-label="Сообщение отклика"
              maxLength={maxLen}
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground -mt-2">
              <span>Обязательное поле</span>
              <span>{text.length}/{maxLen}</span>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} disabled={sending}>
                Отмена
              </Button>
              <Button size="sm" onClick={handleSend} disabled={sending || !text.trim()}>
                {sending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Send className="w-3.5 h-3.5 mr-1" />}
                Отправить отклик
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function SponsoredCard({ ad, onHide }: { ad: SponsoredAd; onHide: () => void }) {
  return (
    <Card className="p-4 border-lighthouse/30 bg-lighthouse-gradient-soft relative">
      <button
        onClick={onHide}
        className="absolute top-2 right-2 text-muted-foreground hover:text-foreground p-1 rounded hover:bg-muted/50"
        title="Скрыть"
      >
        <X className="w-3.5 h-3.5" />
      </button>
      <div className="flex items-center gap-2 mb-2">
        <div className="w-7 h-7 rounded-md lighthouse-gradient flex items-center justify-center">
          <Megaphone className="w-3.5 h-3.5 text-white" />
        </div>
        <div className="text-xs">
          <span className="font-semibold text-lighthouse">Партнёр BizON</span>
          <span className="text-muted-foreground ml-2">ATI {Math.round(ad.adTrustIndex * 100)}</span>
        </div>
      </div>

      {ad.imageUrl && (
        <div className="rounded-lg overflow-hidden mb-2 max-h-60">
          <img src={ad.imageUrl} alt="" className="w-full h-40 object-cover" onError={(e) => (e.currentTarget.parentElement!.style.display = 'none')} />
        </div>
      )}

      <div className="font-semibold text-sm mb-1">{ad.title}</div>
      <div className="text-xs text-muted-foreground line-clamp-2 mb-3">{ad.content}</div>

      <a
        href={ad.ctaUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-lighthouse text-white text-xs font-medium hover:opacity-90 transition"
      >
        {ad.ctaText}
        <ExternalLink className="w-3 h-3" />
      </a>
    </Card>
  );
}

function EventContent({ eventType, payload }: { eventType: string; payload: any }) {
  if (eventType === 'project_completed') {
    return (
      <div className="text-sm">
        <span className="font-medium">{payload.projectTitle}</span>
        {payload.rating > 0 && <span className="text-muted-foreground"> · ★ {payload.rating.toFixed(1)}</span>}
      </div>
    );
  }
  if (eventType === 'skill_confirmed') {
    return (
      <div className="text-sm">
        Навык <span className="font-medium text-lighthouse">{payload.skill}</span> подтверждён
        {payload.confirmationsCount > 0 && (
          <span className="text-muted-foreground"> · всего {payload.confirmationsCount}</span>
        )}
      </div>
    );
  }
  if (eventType === 'connection_accepted') {
    return <div className="text-sm">Установлена связь с <span className="font-medium">{payload.with}</span></div>;
  }
  if (eventType === 'positive_review') {
    return (
      <div className="text-sm">
        Положительный отзыв от <span className="font-medium">{payload.from}</span>
        {payload.rating && <span className="text-muted-foreground"> · ★ {Number(payload.rating).toFixed(1)}</span>}
      </div>
    );
  }
  if (eventType === 'intro_sent') {
    return <div className="text-sm">Отправлен интро-запрос к <span className="font-medium">{payload.to}</span></div>;
  }
  if (eventType === 'job_matched') {
    return (
      <div className="text-sm">
        AI-подбор: <span className="font-medium">{payload.jobTitle}</span> в {payload.company}
        <span className="text-muted-foreground"> · {Math.round(payload.matchConfidence * 100)}% совпадение</span>
      </div>
    );
  }
  return <div className="text-sm text-muted-foreground">Событие репутации</div>;
}

function formatRelative(iso: string): string {
  const now = Date.now();
  const diff = now - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (minutes < 1) return 'только что';
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  if (days < 7) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU');
}

// =============================================================================
// Wave 3 (S-062): inline-опрос и разблокировка платного поста
// =============================================================================

function PollInline({
  postId,
  results,
}: {
  postId: string;
  results: { options: Array<{ id: string; text: string; votes: number }>; totalVotes: number; myVote: string | null };
}) {
  const [state, setState] = React.useState(results);
  const [busy, setBusy] = React.useState(false);

  async function vote(optionId: string) {
    if (busy || state.myVote === optionId) return;
    setBusy(true);
    try {
      const res = await api<{ options: typeof results.options; myVote: string }>(`/api/posts/${postId}/vote`, {
        method: 'POST',
        body: JSON.stringify({ optionId }),
      });
      const total = res.options.reduce((s, o) => s + o.votes, 0);
      setState({ options: res.options, totalVotes: total, myVote: res.myVote });
    } catch (e) {
      toast({ title: 'Не удалось проголосовать', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mb-3 rounded-lg border p-3 space-y-2" role="group" aria-label="Опрос">
      {state.options.map((o) => {
        const pct = state.totalVotes > 0 ? Math.round((o.votes / state.totalVotes) * 100) : 0;
        const mine = state.myVote === o.id;
        return (
          <button
            key={o.id}
            type="button"
            onClick={() => vote(o.id)}
            disabled={busy}
            className={cn(
              'relative w-full rounded-md border px-3 py-2 text-sm text-left transition min-h-[40px] overflow-hidden',
              mine ? 'border-primary bg-primary/10' : 'hover:bg-accent',
            )}
          >
            <span
              className="absolute inset-y-0 left-0 bg-primary/15 transition-all duration-500"
              style={{ width: `${state.myVote ? pct : 0}%` }}
              aria-hidden
            />
            <span className="relative flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5 min-w-0">
                {mine && <Check className="w-3.5 h-3.5 text-primary shrink-0" />}
                <span className="truncate">{o.text}</span>
              </span>
              {state.myVote && <span className="text-xs text-muted-foreground tabular-nums shrink-0">{pct}%</span>}
            </span>
          </button>
        );
      })}
      <div className="text-xs text-muted-foreground">{state.totalVotes} голос(ов)</div>
    </div>
  );
}

function UnlockButton({ postId, price }: { postId: string; price: number }) {
  const [busy, setBusy] = React.useState(false);

  async function unlock() {
    setBusy(true);
    try {
      await api(`/api/posts/${postId}/unlock`, { method: 'POST' });
      toast({ title: 'Пост открыт', description: `Списано ${price} люменов` });
      window.location.reload(); // честно перезагружаем ленту с полным контентом
    } catch (e) {
      toast({ title: 'Не удалось открыть пост', description: e instanceof Error ? e.message : String(e), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Button size="sm" onClick={unlock} disabled={busy}>
      {busy ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Gem className="w-4 h-4 mr-1" />}
      Разблокировать
    </Button>
  );
}
