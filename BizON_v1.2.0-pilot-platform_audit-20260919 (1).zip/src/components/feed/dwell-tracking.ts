'use client';

import * as React from 'react';

// BizON — Dwell-time tracking (doc_agents A7: «implicit feedback: время просмотра»)
// Task 10-c — закрытие пункта A7 аудита (/tmp/audit_agents.md):
//   «Времени просмотра (dwell time) нет нигде — grep dwell|viewDuration… 0 совпадений».
//
// МЕХАНИКА (честные сигналы, без PII):
//   1. IntersectionObserver (threshold 0.5) — карточка «видима», когда ≥50% её
//      площади в вьюпорте.
//   2. Секундный тик (setInterval 1s) аккумулирует время ТОЛЬКО когда
//      документ видим (document.visibilityState === 'visible') и карточка
//      пересекается. Скрытая вкладка время не набирает.
//   3. Отправка ПАЧКОЙ (batch) по триггерам ухода:
//        • visibilitychange → hidden (переключение вкладки / сворачивание);
//        • pagehide (закрытие/уход со страницы — надёжнее beforeunload на мобильных);
//        • unmount компонента (SPA-навигация внутри BizON).
//      Транспорт: navigator.sendBeacon → фолбэк fetch(..., {keepalive: true}).
//   4. «Одна карточка — одна агрегированная отправка за сессию просмотра»:
//      после успешной отправки аккумуляторы очищаются; новый цикл накопления
//      для той же карточки возможен только в НОВОЙ сессии видимости
//      (вернулся на вкладку → снова копим → снова одна отправка при уходе).
//   5. Не спамим: секундный тик не делает сетевых вызовов вовсе; сетевой
//      вызов — только по триггерам из п.3; в одной пачке ≤50 позиций
//      (клиентский кламп = серверному лимиту POST /api/feed/dwell).
//
// ПРИВАТНОСТЬ (doc_agents/стр. 31 «собираем только то, что нужно»):
//   - В событии НЕТ PII: только { itemType, itemId, topic?, seconds }.
//     itemId/topic — это же содержимое уже отображённой карточки (иначе
//     трекинг был бы невозможен), seconds — агрегат без таймингов.
//   - Do Not Track (DNT): РЕШЕНИЕ — НЕ гейтить отправку по navigator.doNotTrack.
//     Обоснование: это first-party аналитика собственного продукта, данные
//     агрегированные и без PII (п.выше), используются исключительно для
//     персонализации ленты самого пользователя (веса рекомендаций), не
//     передаются третьим сторонам и не склеиваются с внешними идентификаторами.
//     DNT — сигнал против СТОРОННЕГО трекинга (cross-site), которого здесь нет.
//     Если продукт когда-нибудь начнёт делиться этими событиями наружу —
//     константу RESPECT_DO_NOT_TRACK ниже нужно включить (готовый код уже есть).
const RESPECT_DO_NOT_TRACK = false;

function doNotTrackEnabled(): boolean {
  if (typeof navigator === 'undefined') return false;
  const dnt = navigator.doNotTrack ?? (navigator as Navigator & { msDoNotTrack?: string | undefined }).msDoNotTrack;
  return dnt === '1';
}

export type DwellItemType = 'job' | 'person' | 'event' | 'company';

/** Ключ позиции — стабильный в пределах карточки. */
export interface DwellItemKey {
  itemType: DwellItemType;
  itemId: string;
  /** Человекочитаемая тема (заголовок вакансии/имя/название) — совместима с темами «Не интересно» (IgnoredTopic). */
  topic?: string | null;
}

interface DwellEntry extends DwellItemKey {
  seconds: number;
}

/** Серверный контракт POST /api/feed/dwell: seconds 1..300, ≤50 items. */
const MAX_SECONDS_PER_ITEM = 300;
const MAX_ITEMS_PER_BATCH = 50;
const FLUSH_ENDPOINT = '/api/feed/dwell';

export class DwellTracker {
  private entries = new Map<string, DwellEntry>();
  private visibleKeys = new Set<string>();
  /** Зарегистрированные элементы по ключу — чтобы пере-наблюдать элемент при повторном монтировании. */
  private elements = new Map<string, HTMLElement>();
  private observer: IntersectionObserver | null = null;
  private ticker: ReturnType<typeof setInterval> | null = null;
  private installed = false;
  private disposed = false;
  /** Реентра-защита flush (visibilitychange + pagehide могут прийти подряд). */
  private sending = false;

  constructor() {
    this.observer = this.createObserver();
  }

  /** Фабрика наблюдателя (пересоздаётся при revival после dispose). */
  private createObserver(): IntersectionObserver | null {
    if (typeof window === 'undefined' || typeof IntersectionObserver === 'undefined') return null;
    return new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          const key = keyOfElement(entry.target);
          if (!key) continue;
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            this.visibleKeys.add(key);
          } else {
            this.visibleKeys.delete(key);
          }
        }
      },
      { threshold: [0, 0.5, 1] },
    );
  }

  /**
   * Регистрирует элемент карточки. Безопасно вызывать из ref-колбэка React
   * (в т.ч. с null при размонтировании и при повторных вызовах).
   * Если трекер был остановлен (dispose — StrictMode mount→cleanup→mount),
   * оживляем его: ref-колбэки при повторном монтировании вызываются снова,
   * и тот же экземпляр продолжает работу с сохранёнными элементами.
   */
  track(key: DwellItemKey, element: HTMLElement | null): void {
    if (!element) return;
    if (this.disposed) this.revive();
    if (!this.observer) return;
    const k = itemKeyToString(key);
    if (!k) return;
    element.dataset.bizonDwellKey = k;
    if (key.topic) element.dataset.bizonDwellTopic = key.topic.slice(0, 120);
    if (!this.entries.has(k)) {
      this.entries.set(k, { ...key, seconds: 0 });
      this.install();
    }
    // Элемент мог пересоздаться React'ом под тем же ключом — наблюдаем актуальный.
    const prev = this.elements.get(k);
    if (prev === element) return;
    if (prev) this.observer.unobserve(prev);
    this.elements.set(k, element);
    this.observer.observe(element);
  }

  /** Снять регистрацию (карточка скрыта/удалена, например «Не интересно»). */
  untrack(key: DwellItemKey): void {
    const k = itemKeyToString(key);
    if (!k) return;
    const el = this.elements.get(k);
    if (el) {
      this.observer?.unobserve(el);
      this.elements.delete(k);
    }
    this.entries.delete(k);
    this.visibleKeys.delete(k);
  }

  private install(): void {
    if (this.installed || this.disposed) return;
    this.installed = true;
    this.ticker = setInterval(() => {
      // Секундный тик: время набирают только видимые карточки видимого документа.
      if (document.visibilityState !== 'visible') return;
      for (const k of this.visibleKeys) {
        // Элемент удалён из DOM (например, «Не интересно») → не копим и не ждём
        // финального callback наблюдателя: убираем из видимых немедленно.
        const el = this.elements.get(k);
        if (el && !el.isConnected) {
          this.visibleKeys.delete(k);
          continue;
        }
        this.ensureEntry(k); // новая сессия видимости после flush
        const entry = this.entries.get(k);
        if (entry && entry.seconds < MAX_SECONDS_PER_ITEM) entry.seconds += 1;
      }
    }, 1000);

    const onHidden = () => {
      if (document.visibilityState === 'hidden') this.flush();
    };
    document.addEventListener('visibilitychange', onHidden);
    window.addEventListener('pagehide', this.pageHideHandler);
    window.addEventListener('beforeunload', this.pageHideHandler);
    this.cleanup = () => {
      document.removeEventListener('visibilitychange', onHidden);
      window.removeEventListener('pagehide', this.pageHideHandler);
      window.removeEventListener('beforeunload', this.pageHideHandler);
    };
  }

  /**
   * После flush() аккумуляторы очищены (сессия завершена). Когда пользователь
   * возвращается и карточка снова видима — начинаем НОВУЮ сессию накопления:
   * восстанавливаем entry из dataset (itemType:itemId + topic).
   */
  private ensureEntry(k: string): void {
    if (this.entries.has(k)) return;
    const el = this.elements.get(k);
    if (!el) return;
    const raw = el.dataset.bizonDwellKey ?? '';
    const sep = raw.indexOf(':');
    if (sep <= 0) return;
    const itemType = raw.slice(0, sep) as DwellItemType;
    const itemId = raw.slice(sep + 1);
    if (!itemId) return;
    const topic = el.dataset.bizonDwellTopic || null;
    this.entries.set(k, { itemType, itemId, topic, seconds: 0 });
  }

  private pageHideHandler = (): void => {
    this.flush();
  };

  private cleanup: (() => void) | null = null;

  /**
   * Отправить накопленное пачкой. Идемпотентно: пустая пачка — сетевого вызова нет.
   * Возвращает true, если отправка состоялась (sendBeacon возвращает boolean,
   * keepalive-fetch считается успешным по факту запуска).
   */
  flush(): boolean {
    if (this.disposed || this.sending) return false;
    if (RESPECT_DO_NOT_TRACK && doNotTrackEnabled()) {
      this.entries.clear();
      return false;
    }
    // Агрегированные позиции с ≥1 наблюдаемой секундой, топ по времени (кламп 50).
    const items = [...this.entries.values()]
      .filter((e) => e.seconds >= 1)
      .sort((a, b) => b.seconds - a.seconds)
      .slice(0, MAX_ITEMS_PER_BATCH)
      .map((e) => ({
        itemType: e.itemType,
        itemId: e.itemId,
        topic: e.topic ?? undefined,
        seconds: e.seconds,
      }));
    if (items.length === 0) return false;

    this.sending = true;
    const payload = JSON.stringify({ items });
    let sent = false;
    try {
      if (typeof navigator.sendBeacon === 'function') {
        // sendBeacon для same-origin отправляет cookie bizon_session автоматически.
        sent = navigator.sendBeacon(FLUSH_ENDPOINT, new Blob([payload], { type: 'application/json' }));
      }
      if (!sent) {
        // Фолбэк: keepalive-request переживает закрытие страницы.
        void fetch(FLUSH_ENDPOINT, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: payload,
          keepalive: true,
          credentials: 'same-origin',
        }).catch(() => undefined);
        sent = true;
      }
    } catch {
      // Тихо: dwell — неявный сигнал, ошибки транспорта не должны влиять на UI.
    }
    // Сессия завершена: чистим аккумуляторы — та же карточка сможет накопиться
    // заново только в новой сессии видимости (после возврата на вкладку).
    this.entries.clear();
    this.sending = false;
    return sent;
  }

  /**
   * Оживление после dispose() (StrictMode mount→cleanup→mount): пересоздаём
   * наблюдатель и слушатели, пере-наблюдаем сохранённые элементы. Аккумуляторы
   * при этом пусты — начинается новая сессия накопления.
   */
  private revive(): void {
    this.disposed = false;
    this.installed = false;
    this.sending = false;
    this.observer = this.createObserver();
    this.install();
    if (this.observer) {
      for (const el of this.elements.values()) {
        if (el.isConnected) this.observer.observe(el);
      }
    }
  }

  /** Полная остановка: flush + снятие слушателей + disconnect наблюдателя.
   *  Элементы сохраняются — track() после dispose() оживляет трекер. */
  dispose(): void {
    this.flush();
    this.disposed = true;
    if (this.ticker) clearInterval(this.ticker);
    this.ticker = null;
    this.cleanup?.();
    this.cleanup = null;
    this.installed = false;
    this.observer?.disconnect();
    this.entries.clear();
    this.visibleKeys.clear();
  }
}

function itemKeyToString(key: DwellItemKey): string | null {
  if (!key || typeof key.itemId !== 'string' || key.itemId.length === 0) return null;
  return `${key.itemType}:${key.itemId}`;
}

/** Читает ключ, проставленный track() в dataset (внутри IntersectionObserver). */
function keyOfElement(el: Element): string | null {
  const k = (el as HTMLElement).dataset?.bizonDwellKey;
  return k && k.length > 0 ? k : null;
}

/**
 * React-хук поверх DwellTracker: экземпляр создаётся лениво через useState
 * (один раз на монтирование компонента; без доступа к ref во время рендера —
 * правило react-hooks/refs), при размонтировании — dispose() с финальной
 * отправкой. При StrictMode-ремонтировании track() оживляет трекер (см. revive).
 */
export function useDwellTracker(): DwellTracker {
  const [tracker] = React.useState<DwellTracker>(() => new DwellTracker());
  React.useEffect(() => {
    return () => {
      tracker.dispose();
    };
  }, [tracker]);
  return tracker;
}
