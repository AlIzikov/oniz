// BizON — Recommendations Carousel (Правка 4 — Лента рекомендаций как Vings)
// Блок «Наши рекомендации» — горизонтальная карусель из 4 типов карточек:
//   1. Вакансия   (бирюзовая 💼 Briefcase)   → setView('jobs')
//   2. Человек    (голубая 👥 Users)          → setProfileUserId(id); setView('profile')
//   3. Событие    (бирюзовая 📅 Calendar)    → setView('events')
//   4. Компания   (синяя 🏢 Building2)       → setSelectedCompanyId(id); setView('company')
//
// Действия на карточках:
//   - X (правый верх) — «Не интересно»: optimistic-скрытие + персист темы в
//     IgnoredTopic через POST /api/feed/recommendations/ignore (анти-эхо-камера,
//     Правка 4-c). При ошибке сети карточка откатывается обратно.
//   - Закладка — «Сохранить», локально toggles saved-состояние
// Exploration-карточки (Epsilon-Greedy) помечены бейджем «Случайная находка».
//
// Стиль (как Vings): белый фон, тень, скруглённые углы, иконка-категория слева сверху,
// тип рекомендации серым текстом, заголовок крупно, подзаголовок серым,
// CTA-кнопка бирюзовая на всю ширину.
// Горизонтальный скролл (overflow-x-auto, flex gap-4).
//
// Task 10-c (doc_agents A7): dwell-трекинг карточек — IntersectionObserver (≥50%
// видимости) + секундный аккумулятор; отправка агрегированной пачкой на
// POST /api/feed/dwell при уходе со страницы/переключении вкладки/unmount
// (sendBeacon → keepalive-fetch). Детали и политика приватности — dwell-tracking.ts.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Briefcase, Users, Calendar as CalendarIcon, Building2, Star, MapPin,
  X, Bookmark, Sparkles, Clock, ArrowRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useDwellTracker } from './dwell-tracking';

// ===== Типы данных (соответствуют /api/feed/recommendations) =====
interface JobRec {
  id: string;
  title: string;
  company: string;
  location: string | null;
  salaryFrom: number | null;
  salaryTo: number | null;
  currency: string;
  matchConfidence: number;
  companyId: string | null;
  // Анти-эхо-камера (Правка 4-c): Epsilon-Greedy + семантический тир 70/20/10
  exploration?: boolean;
  reason?: string;
  semanticTier?: 'exact' | 'synonym' | 'surprise';
  semanticWeight?: number;
}
interface PeopleRec {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  location: string | null;
  level: string;
  ipScore: number;
  companyName: string | null;
  commonContacts: number;
  exploration?: boolean;
  reason?: string;
}
interface EventRec {
  id: string;
  title: string;
  startDate: string;
  endDate: string | null;
  format: string;
  location: string | null;
  organizerName: string;
  participantsCount: number;
  exploration?: boolean;
  reason?: string;
}
interface CompanyRec {
  id: string;
  name: string;
  logoUrl: string | null;
  industry: string | null;
  activeJobsCount: number;
  rating: number | null;
  culturalScore: number;
  exploration?: boolean;
  reason?: string;
}
interface RecommendationsResponse {
  jobs: JobRec[];
  people: PeopleRec[];
  events: EventRec[];
  companies: CompanyRec[];
}

// ===== Цветовые пресеты для иконок-категорий =====
type CategoryStyle = {
  bg: string;
  text: string;
  label: string;
  icon: React.ReactNode;
};
const JOB_STYLE: CategoryStyle = {
  bg: 'bg-teal-100 dark:bg-teal-500/15',
  text: 'text-teal-600 dark:text-teal-400',
  label: 'Вакансия',
  icon: <Briefcase className="w-4 h-4" />,
};
const PERSON_STYLE: CategoryStyle = {
  bg: 'bg-sky-100 dark:bg-sky-500/15',
  text: 'text-sky-600 dark:text-sky-400',
  label: 'Человек',
  icon: <Users className="w-4 h-4" />,
};
const EVENT_STYLE: CategoryStyle = {
  bg: 'bg-teal-100 dark:bg-teal-500/15',
  text: 'text-teal-600 dark:text-teal-400',
  label: 'Событие',
  icon: <CalendarIcon className="w-4 h-4" />,
};
const COMPANY_STYLE: CategoryStyle = {
  bg: 'bg-blue-100 dark:bg-blue-500/15',
  text: 'text-blue-600 dark:text-blue-400',
  label: 'Компания',
  icon: <Building2 className="w-4 h-4" />,
};

// =================================================================
// Компонент одной карточки рекомендации (общий каркас)
// =================================================================
function RecCard({
  category,
  onDismiss,
  onToggleSave,
  saved,
  explorationReason,
  children,
  onClickBody,
  dwellRef,
}: {
  category: CategoryStyle;
  onDismiss: () => void;
  onToggleSave: () => void;
  saved: boolean;
  explorationReason?: string;
  children: React.ReactNode;
  onClickBody?: () => void;
  /** Task 10-c: ref для dwell-трекинга (регистрация карточки в DwellTracker). */
  dwellRef?: (el: HTMLDivElement | null) => void;
}) {
  return (
    <Card
      ref={dwellRef}
      className={cn(
        'w-[260px] sm:w-[280px] flex-shrink-0 overflow-hidden',
        'shadow-sm hover:shadow-md transition-shadow cursor-pointer group'
      )}
      onClick={onClickBody}
    >
      <CardContent className="p-4">
        {/* Верх: иконка-категория + тип + действия (X / закладка) */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div
              className={cn(
                'w-8 h-8 rounded-full flex items-center justify-center',
                category.bg,
                category.text
              )}
              aria-hidden="true"
            >
              {category.icon}
            </div>
            <span className="text-xs text-muted-foreground uppercase tracking-wide font-medium">
              {category.label}
            </span>
          </div>
          <div className="flex items-center gap-0.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave();
              }}
              className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition"
              aria-label={saved ? 'Убрать из сохранённых' : 'Сохранить'}
              title={saved ? 'Убрать из сохранённых' : 'Сохранить'}
            >
              <Bookmark
                className={cn('w-4 h-4', saved && 'fill-current text-teal-600 dark:text-teal-400')}
              />
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onDismiss();
              }}
              className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition"
              aria-label="Не интересно"
              title="Не интересно"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
        {/* Exploration-бейдж (Epsilon-Greedy, анти-эхо-камера). Палитра «Маяк»:
            sky = горизонт/расширение кругозора, красный/фиолетовый не используем */}
        {explorationReason && (
          <p
            className="text-xs text-sky-600 dark:text-sky-400 flex items-center gap-1 mt-2"
            title={explorationReason}
          >
            <Sparkles className="w-3 h-3 flex-shrink-0" />
            Случайная находка — расширяем кругозор
          </p>
        )}
        {/* Контент карточки (передаётся снаружи) */}
        {children}
      </CardContent>
    </Card>
  );
}

// =================================================================
// Кнопка CTA — бирюзовая на всю ширину (стиль Vings)
// =================================================================
function CtaButton({
  children,
  onClick,
  icon,
}: {
  children: React.ReactNode;
  onClick: (e: React.MouseEvent) => void;
  icon?: React.ReactNode;
}) {
  return (
    <Button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onClick(e);
      }}
      className={cn(
        'w-full bg-teal-500 hover:bg-teal-600 text-white',
        'border-0 shadow-none focus-visible:ring-teal-500/40'
      )}
      size="sm"
    >
      {icon && <span className="mr-1">{icon}</span>}
      {children}
    </Button>
  );
}

// =================================================================
// Форматирование зарплаты
// =================================================================
function formatSalary(from: number | null, to: number | null, currency: string): string | null {
  if (!from && !to) return null;
  const cur = currency === 'RUB' ? '₽' : currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency;
  const fmt = (n: number) => {
    if (n >= 1000) return `${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}K`;
    return String(n);
  };
  if (from && to) return `${fmt(from)}–${fmt(to)} ${cur}`;
  if (from) return `от ${fmt(from)} ${cur}`;
  if (to) return `до ${fmt(to)} ${cur}`;
  return null;
}

// =================================================================
// Форматирование даты события
// =================================================================
function formatEventDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const sameYear = d.getFullYear() === now.getFullYear();
  return d.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'short',
    year: sameYear ? undefined : 'numeric',
  }) + ', ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

// =================================================================
// Главный компонент карусели
// =================================================================
export function RecommendationsCarousel() {
  const setView = useAppStore((s) => s.setView);
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const setSelectedCompanyId = useAppStore((s) => s.setSelectedCompanyId);

  // Task 10-c (A7): трекер dwell-времени карточек (один на карусель; flush на
  // pagehide/visibilitychange/unmount — см. dwell-tracking.ts).
  const dwell = useDwellTracker();

  const [data, setData] = React.useState<RecommendationsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);

  // Локально скрытые карточки (по id) — для кнопки «Не интересно».
  // Скрываются optimistic, при ошибке персиста — откатываются.
  const [hidden, setHidden] = React.useState<Set<string>>(new Set());
  // Сохранённые карточки (по id) — для кнопки «Закладка»
  const [saved, setSaved] = React.useState<Set<string>>(new Set());

  React.useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const res = await api<RecommendationsResponse>('/api/feed/recommendations');
        if (!cancelled) setData(res);
      } catch (e) {
        // Тихо игнорируем — карусель не должна ломать ленту
        if (!cancelled) setData(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  // «Не интересно»: optimistic-скрытие + персист темы в IgnoredTopic.
  // При ошибке сети/сервера карточка возвращается (rollback).
  // Task 10-c: карточка снимается с dwell-трекинга (время больше не копится —
  // пользователь тему отклонил; это же отражено в IgnoredTopic на сервере).
  function handleDismiss(id: string, topic: string, itemType: 'job' | 'person' | 'event' | 'company') {
    dwell.untrack({ itemType, itemId: id });
    setHidden((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
    void api('/api/feed/recommendations/ignore', {
      method: 'POST',
      body: JSON.stringify({ topic, itemType }),
    }).catch(() => {
      setHidden((prev) => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
      toast({
        title: 'Не удалось сохранить «Не интересно»',
        description: 'Карточка вернулась — проверьте соединение и попробуйте ещё раз',
      });
    });
  }

  function handleToggleSave(id: string) {
    setSaved((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
    toast({
      title: saved.has(id) ? 'Убрано из сохранённых' : 'Сохранено',
      description: saved.has(id) ? undefined : 'Карточка добавлена в избранное',
    });
  }

  // Если ничего нет (или всё ещё грузится и данных нет) — рендерим skeleton/empty
  if (loading) {
    return (
      <section aria-label="Наши рекомендации" className="space-y-3">
        <RecHeader />
        <div className="flex gap-4 overflow-x-auto scroll-area-thin pb-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="w-[260px] sm:w-[280px] h-[200px] rounded-lg flex-shrink-0" />
          ))}
        </div>
      </section>
    );
  }

  if (!data) return null;

  // Фильтруем скрытые карточки
  const jobs = data.jobs.filter((j) => !hidden.has(j.id));
  const people = data.people.filter((p) => !hidden.has(p.id));
  const events = data.events.filter((e) => !hidden.has(e.id));
  const companies = data.companies.filter((c) => !hidden.has(c.id));

  // Если все карточки скрыты — не показываем блок
  if (jobs.length === 0 && people.length === 0 && events.length === 0 && companies.length === 0) {
    return null;
  }

  return (
    <section aria-label="Наши рекомендации" className="space-y-3">
      <RecHeader />

      {/* Горизонтальная карусель — flex с overflow-x-auto */}
      <div className="flex gap-4 overflow-x-auto scroll-area-thin pb-2 -mx-1 px-1">
        {/* Вакансии */}
        {jobs.map((job) => {
          const salary = formatSalary(job.salaryFrom, job.salaryTo, job.currency);
          return (
            <RecCard
              key={`job-${job.id}`}
              category={JOB_STYLE}
              saved={saved.has(job.id)}
              explorationReason={job.exploration ? job.reason : undefined}
              onDismiss={() => handleDismiss(job.id, job.title, 'job')}
              onToggleSave={() => handleToggleSave(job.id)}
              onClickBody={() => setView('jobs')}
              dwellRef={(el) => dwell.track({ itemType: 'job', itemId: job.id, topic: job.title }, el)}
            >
              <h3 className="font-semibold text-base line-clamp-2 leading-snug">{job.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-1 mt-0.5">{job.company}</p>
              {salary && (
                <p className="text-teal-600 dark:text-teal-400 font-semibold text-sm mt-2">{salary}</p>
              )}
              {job.location && (
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1 line-clamp-1">
                  <MapPin className="w-3 h-3 flex-shrink-0" />
                  {job.location}
                </p>
              )}
              <div className="mt-3">
                <CtaButton onClick={() => setView('jobs')}>Откликнуться</CtaButton>
              </div>
            </RecCard>
          );
        })}

        {/* Люди */}
        {people.map((person) => (
          <RecCard
            key={`person-${person.id}`}
            category={PERSON_STYLE}
            saved={saved.has(person.id)}
            explorationReason={person.exploration ? person.reason : undefined}
            onDismiss={() => handleDismiss(person.id, person.title ?? person.name, 'person')}
            onToggleSave={() => handleToggleSave(person.id)}
            onClickBody={() => {
              setProfileUserId(person.id);
              setView('profile');
            }}
            dwellRef={(el) => dwell.track({ itemType: 'person', itemId: person.id, topic: person.title ?? person.name }, el)}
          >
            <div className="flex items-center gap-3">
              <UserAvatar
                name={person.name}
                avatarUrl={person.avatarUrl}
                size="md"
              />
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-base line-clamp-1 leading-tight">{person.name}</h3>
                <p className="text-xs text-muted-foreground line-clamp-1">
                  {person.title}
                  {person.companyName ? ` · ${person.companyName}` : ''}
                </p>
              </div>
            </div>
            {person.commonContacts > 0 && (
              <p className="text-xs text-sky-600 dark:text-sky-400 flex items-center gap-1 mt-2">
                <Sparkles className="w-3 h-3 flex-shrink-0" />
                Возможно, вы знакомы · {person.commonContacts} общ.
              </p>
            )}
            {person.location && person.commonContacts === 0 && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-2 line-clamp-1">
                <MapPin className="w-3 h-3 flex-shrink-0" />
                {person.location}
              </p>
            )}
            <div className="mt-3">
              <CtaButton
                onClick={() => {
                  setProfileUserId(person.id);
                  setView('profile');
                }}
              >
                Открыть профиль
              </CtaButton>
            </div>
          </RecCard>
        ))}

        {/* События */}
        {events.map((event) => (
          <RecCard
            key={`event-${event.id}`}
            category={EVENT_STYLE}
            saved={saved.has(event.id)}
            explorationReason={event.exploration ? event.reason : undefined}
            onDismiss={() => handleDismiss(event.id, event.title, 'event')}
            onToggleSave={() => handleToggleSave(event.id)}
            onClickBody={() => setView('events')}
            dwellRef={(el) => dwell.track({ itemType: 'event', itemId: event.id, topic: event.title }, el)}
          >
            <h3 className="font-semibold text-base line-clamp-2 leading-snug">{event.title}</h3>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1.5 line-clamp-1">
              <Clock className="w-3 h-3 flex-shrink-0" />
              {formatEventDate(event.startDate)}
            </p>
            <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
              {event.format === 'online' ? 'Онлайн' : event.format === 'hybrid' ? 'Гибрид' : 'Офлайн'}
              {event.location ? ` · ${event.location}` : ''}
            </p>
            <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
              Организатор: {event.organizerName}
            </p>
            <div className="mt-3">
              <CtaButton onClick={() => setView('events')}>Записаться</CtaButton>
            </div>
          </RecCard>
        ))}

        {/* Компании */}
        {companies.map((company) => (
          <RecCard
            key={`company-${company.id}`}
            category={COMPANY_STYLE}
            saved={saved.has(company.id)}
            explorationReason={company.exploration ? company.reason : undefined}
            onDismiss={() => handleDismiss(company.id, company.name, 'company')}
            onToggleSave={() => handleToggleSave(company.id)}
            onClickBody={() => {
              setSelectedCompanyId(company.id);
              setView('company');
            }}
            dwellRef={(el) => dwell.track({ itemType: 'company', itemId: company.id, topic: company.name }, el)}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 overflow-hidden">
                {company.logoUrl ? (
                  <img
                    src={company.logoUrl}
                    alt=""
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                ) : (
                  <Building2 className="w-5 h-5 text-muted-foreground" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-base line-clamp-1 leading-tight">{company.name}</h3>
                {company.industry && (
                  <p className="text-xs text-muted-foreground line-clamp-1">{company.industry}</p>
                )}
              </div>
            </div>
            <div className="flex items-center justify-between mt-2 text-xs">
              <span className="text-muted-foreground">
                Активные вакансии: <span className="font-medium text-foreground">{company.activeJobsCount}</span>
              </span>
              {company.rating !== null && company.rating > 0 && (
                <span className="flex items-center gap-0.5 text-amber-600 dark:text-amber-400 font-medium">
                  <Star className="w-3 h-3 fill-current" />
                  {company.rating.toFixed(1)}
                </span>
              )}
            </div>
            <div className="mt-3">
              <CtaButton
                onClick={() => {
                  setSelectedCompanyId(company.id);
                  setView('company');
                }}
                icon={<ArrowRight className="w-3.5 h-3.5" />}
              >
                Открыть
              </CtaButton>
            </div>
          </RecCard>
        ))}
      </div>
    </section>
  );
}

// =================================================================
// Заголовок блока «Наши рекомендации»
// =================================================================
function RecHeader() {
  return (
    <div className="flex items-center justify-between">
      <h2 className="text-base font-semibold flex items-center gap-2">
        <span className="w-1 h-4 rounded-full bg-teal-500" aria-hidden="true" />
        <Sparkles className="w-4 h-4 text-teal-500" aria-hidden="true" />
        Наши рекомендации
      </h2>
      <span className="text-xs text-muted-foreground hidden sm:inline">
        Прокрутите вправо, чтобы увидеть больше
      </span>
    </div>
  );
}
