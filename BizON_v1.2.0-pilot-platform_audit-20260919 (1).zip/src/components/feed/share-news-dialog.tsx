// BizON — ShareNewsDialog (Wave 15: «Поделиться новостью»)
// Диалог адресной рекомендации NewsCard конкретному пользователю:
//   • поиск получателя по имени/должности (/api/users/search, debounce 300 мс);
//   • выбор получателя (чип с аватаром), необязательный комментарий (≤500);
//   • POST /api/news/recommend → у получателя в ленте появится карточка с
//     атрибуцией «Рекомендовано {имя отправителя}» + уведомление в «колокольчике».
// Контракт ответа: { ok, shareId, notified, attribution }
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { UserAvatar } from '@/components/common/user-avatar';
import { Loader2, Search, Send, X, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface ShareCandidate {
  id: string;
  name: string;
  title?: string | null;
  avatarUrl?: string | null;
  ipScore?: number;
}

interface ShareNewsDialogProps {
  /** Карточка новости для отправки */
  card: { id: string; title: string };
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Вызывается после успешной отправки (для локальных статусов в карточке) */
  onShared?: (toUserName: string) => void;
}

const MAX_MESSAGE = 500;

export function ShareNewsDialog({ card, open, onOpenChange, onShared }: ShareNewsDialogProps) {
  const me = useAppStore((s) => s.user);
  const [query, setQuery] = React.useState('');
  const [results, setResults] = React.useState<ShareCandidate[]>([]);
  const [searching, setSearching] = React.useState(false);
  const [selected, setSelected] = React.useState<ShareCandidate | null>(null);
  const [message, setMessage] = React.useState('');
  const [sending, setSending] = React.useState(false);

  // Сброс состояния при открытии/закрытии диалога
  React.useEffect(() => {
    if (open) {
      setQuery('');
      setResults([]);
      setSelected(null);
      setMessage('');
    }
  }, [open]);

  // Поиск получателя с debounce 300 мс (минимум 2 символа — контракт /api/users/search)
  React.useEffect(() => {
    if (!open) return;
    const q = query.trim();
    if (q.length < 2) {
      setResults([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const res = await api<{ users: ShareCandidate[] }>(`/api/users/search?q=${encodeURIComponent(q)}&limit=10`);
        // Исключаем себя из результатов (самому себе рекомендовать нельзя)
        setResults((res.users ?? []).filter((u) => u.id !== me?.id));
      } catch {
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query, open, me?.id]);

  async function handleSend() {
    if (!selected || sending) return;
    setSending(true);
    try {
      await api('/api/news/recommend', {
        method: 'POST',
        body: JSON.stringify({ newsCardId: card.id, toUserId: selected.id, message: message.trim() }),
      });
      toast({
        title: 'Новость отправлена',
        description: `${selected.name} увидит её в ленте новостей с пометкой «Рекомендовано ${me?.name ?? 'вами'}».`,
      });
      onShared?.(selected.name);
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: 'Не удалось поделиться', description: e.message, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Поделиться новостью</DialogTitle>
          <DialogDescription className="line-clamp-2">
            {card.title}
          </DialogDescription>
        </DialogHeader>

        {/* Выбранный получатель — чип */}
        {selected ? (
          <div className="flex items-center justify-between gap-2 p-2 rounded-lg border bg-muted/30">
            <div className="flex items-center gap-2 min-w-0">
              <UserAvatar name={selected.name} avatarUrl={selected.avatarUrl ?? undefined} size="sm" />
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{selected.name}</div>
                {selected.title && <div className="text-xs text-muted-foreground truncate">{selected.title}</div>}
              </div>
              <Check className="w-4 h-4 text-emerald-600 shrink-0" aria-label="Получатель выбран" />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0"
              onClick={() => setSelected(null)}
              aria-label="Сменить получателя"
            >
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
        ) : (
          /* Поиск получателя */
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Кому направить? Начните вводить имя…"
                aria-label="Поиск получателя"
                className="pl-8"
                autoFocus
              />
              {searching && (
                <Loader2 className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" aria-hidden="true" />
              )}
            </div>
            {query.trim().length >= 2 && !searching && results.length === 0 && (
              <div className="p-3 text-sm text-muted-foreground text-center">Никого не нашли. Попробуйте другой запрос.</div>
            )}
            {results.length > 0 && (
              <div className="max-h-56 overflow-y-auto scroll-area-thin rounded-lg border divide-y" role="listbox" aria-label="Результаты поиска">
                {results.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    role="option"
                    aria-selected={false}
                    onClick={() => setSelected(u)}
                    className="w-full flex items-center gap-2.5 p-2.5 text-left hover:bg-accent transition"
                  >
                    <UserAvatar name={u.name} avatarUrl={u.avatarUrl ?? undefined} size="sm" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate">{u.name}</div>
                      {u.title && <div className="text-xs text-muted-foreground truncate">{u.title}</div>}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Комментарий отправителя */}
        <div className="space-y-1.5">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value.slice(0, MAX_MESSAGE))}
            placeholder="Добавьте комментарий (необязательно) — почему эта новость важна получателю…"
            rows={3}
            maxLength={MAX_MESSAGE}
            aria-label="Комментарий к рекомендации"
          />
          <div className="text-right text-xs text-muted-foreground">{message.length}/{MAX_MESSAGE}</div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={sending}>
            Отмена
          </Button>
          <Button onClick={handleSend} disabled={!selected || sending} className={cn('gap-1.5')}>
            {sending ? <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" /> : <Send className="w-4 h-4" aria-hidden="true" />}
            Отправить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
