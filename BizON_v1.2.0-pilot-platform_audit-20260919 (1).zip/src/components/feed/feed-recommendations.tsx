// BizON — FeedRecommendations
// Контекстные блоки рекомендаций внутри ленты новостей
// Показываются между постами: вакансии / люди / события
// Превращают ленту из «читать» в «действовать»
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import {
  Briefcase, Users, Calendar as CalendarIcon, ChevronRight, MapPin, Zap, Sparkles,
} from 'lucide-react';
import { cn } from '@/lib/utils';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';

type RecommendationType = 'jobs' | 'people' | 'events';

interface JobRec {
  id: string;
  title: string;
  company: string;
  location: string | null;
  matchConfidence: number;
  salaryFrom: number | null;
  salaryTo: number | null;
}

interface PeopleRec {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  ipScore: number;
  level: string;
  location: string | null;
}

interface EventRec {
  id: string;
  title: string;
  startDate: string;
  format: string;
  location: string | null;
}

export function FeedRecommendations({ type }: { type: RecommendationType }) {
  const setView = useAppStore((s) => s.setView);
  const setSelectedCompanyId = useAppStore((s) => s.setSelectedCompanyId);
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const [data, setData] = React.useState<JobRec[] | PeopleRec[] | EventRec[] | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        if (type === 'jobs') {
          const res = await api<{ jobs: any[] }>('/api/jobs');
          if (cancelled) return;
          // Берём топ-3 по match
          const top = (res.jobs ?? [])
            .sort((a, b) => b.matchConfidence - a.matchConfidence)
            .slice(0, 3)
            .map(j => ({
              id: j.id, title: j.title, company: j.company, location: j.location,
              matchConfidence: j.matchConfidence, salaryFrom: j.salaryFrom, salaryTo: j.salaryTo,
            }));
          setData(top);
        } else if (type === 'people') {
          const res = await api<{ users: any[] }>('/api/users/search?q=');
          if (cancelled) return;
          const top = (res.users ?? []).slice(0, 3).map(u => ({
            id: u.id, name: u.name, title: u.title, avatarUrl: u.avatarUrl,
            ipScore: u.ipScore, level: u.level, location: u.location,
          }));
          setData(top);
        } else if (type === 'events') {
          const res = await api<{ events: any[] }>('/api/events?limit=3');
          if (cancelled) return;
          const top = (res.events ?? []).slice(0, 3).map(e => ({
            id: e.id, title: e.title, startDate: e.startDate,
            format: e.format, location: e.location,
          }));
          setData(top);
        }
      } catch (e) {
        if (!cancelled) setData([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [type]);

  if (loading) {
    return (
      <Card className="border-lighthouse/20 bg-lighthouse-gradient-soft">
        <CardContent className="p-4">
          <div className="h-4 w-48 bg-muted/40 rounded animate-pulse mb-3" />
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-10 bg-muted/30 rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data || data.length === 0) return null;

  const config = {
    jobs:    { title: 'Вакансии для вас',     icon: <Briefcase className="w-4 h-4" />, cta: 'Все вакансии', view: 'jobs' as const },
    people:  { title: 'С кем стоит связаться', icon: <Users className="w-4 h-4" />,    cta: 'Все контакты', view: 'network' as const },
    events:  { title: 'Ближайшие события',    icon: <CalendarIcon className="w-4 h-4" />, cta: 'Все события', view: 'events' as const },
  }[type];

  return (
    <Card className="border-lighthouse/20 bg-lighthouse-gradient-soft">
      <CardContent className="p-4">
        {/* Заголовок */}
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold flex items-center gap-2">
            <span className="w-1 h-3.5 rounded-full bg-emerald-600 dark:bg-emerald-500" aria-hidden="true" />
            <Sparkles className="w-4 h-4 text-lighthouse" />
            {config.title}
            {/* Wave 11-e: «Вакансии для вас» — подборка Opportunity Engine (только для jobs-блока) */}
            {type === 'jobs' && <TermInfo k="opportunity_engine" />}
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView(config.view)} className="text-xs">
            {config.cta} <ChevronRight className="w-3 h-3" />
          </Button>
        </div>

        {/* Контент в зависимости от типа */}
        {type === 'jobs' && (
          <div className="space-y-2">
            {(data as JobRec[]).map(job => (
              <button
                key={job.id}
                onClick={() => setView('jobs')}
                className="w-full flex items-center gap-3 p-2 rounded-md bg-background/60 hover:bg-background transition text-left group"
              >
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{job.title}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {job.company}
                    {job.location && <span className="ml-1">· {job.location}</span>}
                  </div>
                </div>
                {/* Зарплата */}
                {job.salaryFrom && job.salaryTo && (
                  <span className="text-xs font-medium text-foreground whitespace-nowrap">
                    {job.salaryFrom.toLocaleString('ru-RU')}–{job.salaryTo.toLocaleString('ru-RU')} ₽
                  </span>
                )}
                {/* Match score */}
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-500 tabular-nums whitespace-nowrap">
                  {Math.round(job.matchConfidence * 100)}%
                </span>
              </button>
            ))}
          </div>
        )}

        {type === 'people' && (
          <div className="space-y-2">
            {(data as PeopleRec[]).map(person => (
              <button
                key={person.id}
                onClick={() => setProfileUserId(person.id)}
                className="w-full flex items-center gap-3 p-2 rounded-md bg-background/60 hover:bg-background transition text-left"
              >
                <UserAvatar name={person.name} avatarUrl={person.avatarUrl} size="sm" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{person.name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {person.title}
                    {person.location && <span className="ml-1">· {person.location}</span>}
                  </div>
                </div>
                <TrustBadge ipScore={person.ipScore} level={person.level} size="sm" />
              </button>
            ))}
          </div>
        )}

        {type === 'events' && (
          <div className="space-y-2">
            {(data as EventRec[]).map(event => {
              const date = new Date(event.startDate);
              return (
                <button
                  key={event.id}
                  onClick={() => setView('events')}
                  className="w-full flex items-center gap-3 p-2 rounded-md bg-background/60 hover:bg-background transition text-left"
                >
                  {/* Дата-индикатор */}
                  <div className="w-10 h-10 rounded-md bg-lighthouse/10 flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-lighthouse tabular-nums">{date.getDate()}</span>
                    <span className="text-xs text-muted-foreground uppercase">
                      {date.toLocaleDateString('ru-RU', { month: 'short' })}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{event.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {event.format === 'online' ? 'Онлайн' : event.format === 'hybrid' ? 'Гибрид' : 'Офлайн'}
                      {event.location && <span className="ml-1">· {event.location}</span>}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
