// BizON — Post Composer (создание поста в Trust Stream)
// Применены принципы: простота (Hick's Law), крупная кнопка (Fitts's Law), мягкий фокус
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import type { PostPublic, SubscriptionTier } from '@/lib/types';
import { Loader2, Sparkles, Megaphone, Lock, Check, X, Image as ImageIcon, Link as LinkIcon, BarChart3, Gem, AlarmClock, Lightbulb, Trophy, HelpCircle, Newspaper } from 'lucide-react';

// Wave 3 (S-061): чипы типов поста (ТЗ 4.2)
const TYPE_CHIPS: Array<{ key: string; label: string; icon: React.ReactNode }> = [
  { key: 'regular', label: 'Обычный', icon: <Sparkles className="w-3 h-3" /> },
  { key: 'expert', label: 'Опыт', icon: <Lightbulb className="w-3 h-3" /> },
  { key: 'question', label: 'Вопрос', icon: <HelpCircle className="w-3 h-3" /> },
  { key: 'success', label: 'Успех', icon: <Trophy className="w-3 h-3" /> },
  { key: 'news', label: 'Новость', icon: <Newspaper className="w-3 h-3" /> },
  { key: 'poll', label: 'Опрос', icon: <BarChart3 className="w-3 h-3" /> },
  { key: 'subscription', label: 'Платный', icon: <Gem className="w-3 h-3" /> },
  { key: 'term', label: 'Срочный', icon: <AlarmClock className="w-3 h-3" /> },
];

export function PostComposer({ onPosted }: { onPosted: (post: PostPublic) => void }) {
  const { user } = useAppStore();
  const [content, setContent] = React.useState('');
  const [tags, setTags] = React.useState('');
  const [isCommercial, setIsCommercial] = React.useState(false);
  const [ctaText, setCtaText] = React.useState('');
  const [ctaUrl, setCtaUrl] = React.useState('');
  // Wave 11-a: отклик по CTA происходит В ПЛАТФОРМЕ; почта — только опционально
  const [notifyByEmail, setNotifyByEmail] = React.useState(false);
  const [imageUrl, setImageUrl] = React.useState('');
  // Wave 3 (S-061): тип поста + поля спец-режимов
  const [postType, setPostType] = React.useState('regular');
  const [pollOptions, setPollOptions] = React.useState(['', '']);
  const [subPrice, setSubPrice] = React.useState('50');
  const [termAt, setTermAt] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [focused, setFocused] = React.useState(false);

  if (!user) return null;

  const canCommercial = user.subscriptionTier === 'business';
  const remaining = content.length;
  const maxLength = 2000;
  const isExpanded = focused || content.length > 0;
  const hasUrl = /https?:\/\/[^\s]+/.test(content);

  async function handleSubmit() {
    if (!content.trim()) return;
    setLoading(true);
    try {
      const body: any = {
        content: content.trim(),
        tags: tags.split(',').map((s) => s.trim()).filter(Boolean),
        type: isCommercial ? 'commercial' : postType,
        imageUrl: imageUrl.trim() || undefined,
      };
      if (isCommercial) {
        body.ctaText = ctaText.trim() || 'Подробнее';
        body.ctaUrl = ctaUrl.trim();
        // Wave 11-a: дублирование откликов письмом — только по явному выбору автора
        body.notifyByEmail = notifyByEmail === true;
      }
      if (!isCommercial && postType === 'poll') {
        body.pollOptions = pollOptions
          .map((t, i) => ({ id: `opt${i + 1}`, text: t.trim() }))
          .filter((o) => o.text.length > 0);
      }
      if (!isCommercial && postType === 'subscription') {
        body.subscriptionPriceLumens = Number(subPrice);
      }
      if (!isCommercial && postType === 'term') {
        body.termExpiresAt = termAt ? new Date(termAt).toISOString() : undefined;
      }
      const res = await api<{ post: PostPublic }>('/api/posts', {
        method: 'POST',
        body: JSON.stringify(body),
      });
      toast({ title: 'Пост опубликован', description: 'Появится в ленте доверия' });
      onPosted(res.post);
      // reset
      setContent('');
      setTags('');
      setIsCommercial(false);
      setCtaText('');
      setCtaUrl('');
      setNotifyByEmail(false);
      setImageUrl('');
      setPostType('regular');
      setPollOptions(['', '']);
      setSubPrice('50');
      setTermAt('');
      setFocused(false);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={`post-composer bg-card border rounded-xl p-4 transition-all ${isExpanded ? 'shadow-sm' : ''}`}>
      <div className="flex gap-3">
        <UserAvatar name={user.name} avatarUrl={user.avatarUrl} size="md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline justify-between mb-2">
            <div className="text-sm">
              <span className="font-medium">{user.name}</span>
              <span className="text-muted-foreground"> · публикует в Trust Stream</span>
            </div>
            {remaining > maxLength * 0.8 && (
              <span className={`text-xs ${remaining > maxLength ? 'text-destructive' : 'text-muted-foreground'}`}>
                {maxLength - remaining}
              </span>
            )}
          </div>

          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value.slice(0, maxLength))}
            onFocus={() => setFocused(true)}
            placeholder="Что нового в вашей профессиональной жизни? Поделитесь достижением, инсайтом или найдите соавтора..."
            className="min-h-[80px] border-0 p-0 focus-visible:ring-0 resize-none text-base"
          />

          {isExpanded && (
            <>
              <div className="mt-3 space-y-3 soft-fade-in">
                {/* Wave 3 S-061: выбор типа поста (ТЗ 4.2) */}
                {!isCommercial && (
                  <div className="flex flex-wrap gap-1.5">
                    {TYPE_CHIPS.map((chip) => (
                      <button
                        key={chip.key}
                        type="button"
                        onClick={() => setPostType(chip.key)}
                        className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs transition min-h-[28px] ${
                          postType === chip.key
                            ? 'bg-primary text-primary-foreground border-primary'
                            : 'text-muted-foreground hover:bg-accent'
                        }`}
                      >
                        {chip.icon} {chip.label}
                      </button>
                    ))}
                  </div>
                )}

                {/* POLL: варианты опроса */}
                {!isCommercial && postType === 'poll' && (
                  <div className="rounded-lg border p-3 space-y-2">
                    <Label className="text-xs text-muted-foreground">Варианты ответа (2–6)</Label>
                    {pollOptions.map((opt, i) => (
                      <div key={i} className="flex gap-1.5">
                        <Input
                          value={opt}
                          onChange={(e) => setPollOptions(pollOptions.map((o, j) => (j === i ? e.target.value.slice(0, 80) : o)))}
                          placeholder={`Вариант ${i + 1}`}
                          className="h-9 text-sm"
                        />
                        {pollOptions.length > 2 && (
                          <Button type="button" variant="ghost" size="icon" className="h-9 w-9" aria-label="Удалить вариант" onClick={() => setPollOptions(pollOptions.filter((_, j) => j !== i))}>
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                    {pollOptions.length < 6 && (
                      <Button type="button" variant="outline" size="sm" onClick={() => setPollOptions([...pollOptions, ''])}>
                        + Вариант
                      </Button>
                    )}
                  </div>
                )}

                {/* SUBSCRIPTION: цена доступа */}
                {!isCommercial && postType === 'subscription' && (
                  <div className={`rounded-lg border p-3 space-y-2 ${user.subscriptionTier === 'free' ? 'bg-muted/50' : ''}`}>
                    <Label className="text-xs text-muted-foreground flex items-center gap-1">
                      <Gem className="w-3 h-3" /> Цена доступа (люмены, 1…10000)
                    </Label>
                    {user.subscriptionTier === 'free' ? (
                      <p className="text-xs text-muted-foreground">
                        Платные посты доступны на тарифах Pro и Business.{' '}
                        <button onClick={() => useAppStore.getState().setView('subscription')} className="text-primary underline hover:no-underline">Перейти →</button>
                      </p>
                    ) : (
                      <Input type="number" min={1} max={10000} value={subPrice} onChange={(e) => setSubPrice(e.target.value)} className="h-9 text-sm" />
                    )}
                  </div>
                )}

                {/* TERM: дедлайн */}
                {!isCommercial && postType === 'term' && (
                  <div className="rounded-lg border p-3 space-y-2">
                    <Label htmlFor="p-term" className="text-xs text-muted-foreground flex items-center gap-1">
                      <AlarmClock className="w-3 h-3" /> Дедлайн (до 30 дней; после — пост скрыт из ленты)
                    </Label>
                    <Input id="p-term" type="datetime-local" value={termAt} onChange={(e) => setTermAt(e.target.value)} className="h-9 text-sm" />
                  </div>
                )}

                <div className="space-y-1">
                  <Label htmlFor="p-tags" className="text-xs text-muted-foreground">Теги (через запятую)</Label>
                  <Input
                    id="p-tags"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="ML, Career, Startups"
                    className="h-9 text-sm"
                  />
                </div>

                {/* Image URL — для VK-режима */}
                <div className="space-y-1">
                  <Label htmlFor="p-image" className="text-xs text-muted-foreground flex items-center gap-1">
                    <ImageIcon className="w-3 h-3" /> URL картинки (необязательно — для VK-режима)
                  </Label>
                  <Input
                    id="p-image"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://..."
                    className="h-9 text-sm"
                  />
                  {imageUrl && (
                    <div className="mt-2 rounded-lg overflow-hidden border max-w-xs">
                      <img src={imageUrl} alt="preview" className="w-full h-32 object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} />
                    </div>
                  )}
                </div>

                {/* Auto link preview indicator */}
                {hasUrl && (
                  <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded-md flex items-center gap-1">
                    <LinkIcon className="w-3 h-3" /> Ссылка в тексте обнаружена — автоматически будет создано превью
                  </div>
                )}

                {/* Commercial toggle — только для business */}
                <div className={`rounded-lg border p-3 ${isCommercial ? 'border-emerald-500/40 bg-emerald-500/5' : ''}`}>
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 min-w-0">
                      <Megaphone className={`w-4 h-4 flex-shrink-0 ${isCommercial ? 'text-emerald-600' : 'text-muted-foreground'}`} />
                      <div className="min-w-0">
                        <div className="text-sm font-medium">Commercial-пост</div>
                        <div className="text-xs text-muted-foreground">
                          {canCommercial ? 'С CTA-кнопкой для бизнеса' : 'Только для Business-тарифа'}
                        </div>
                      </div>
                    </div>
                    {canCommercial ? (
                      <Switch checked={isCommercial} onCheckedChange={setIsCommercial} />
                    ) : (
                      <Badge variant="outline" className="text-xs gap-1">
                        <Lock className="w-3 h-3" /> Business
                      </Badge>
                    )}
                  </div>

                  {isCommercial && canCommercial && (
                    <div className="mt-3 grid grid-cols-2 gap-2 soft-fade-in">
                      <Input
                        value={ctaText}
                        onChange={(e) => setCtaText(e.target.value)}
                        placeholder="Текст кнопки: 'Записаться'"
                        className="h-9 text-sm"
                      />
                      <Input
                        value={ctaUrl}
                        onChange={(e) => setCtaUrl(e.target.value)}
                        placeholder="https:// или mailto:"
                        className="h-9 text-sm"
                      />

                      {/* Wave 11-a: отклик В ПЛАТФОРМЕ — почтовый клиент больше не
                          открывается по клику на CTA. Email — только по выбору автора. */}
                      <div className="col-span-2 space-y-1.5">
                        <div className="flex items-start gap-2">
                          <Checkbox
                            id="p-notify-email"
                            checked={notifyByEmail}
                            onCheckedChange={(v) => setNotifyByEmail(v === true)}
                            className="mt-0.5"
                          />
                          <Label
                            htmlFor="p-notify-email"
                            className="text-xs font-medium leading-snug cursor-pointer"
                          >
                            Направлять отклики дополнительно на почту
                          </Label>
                        </div>
                        <p className="text-xs text-muted-foreground leading-snug pl-6">
                          Отклик всегда придёт вам в уведомления платформы; галочка добавит кнопку продублировать отклик письмом.
                        </p>
                        <p className="text-xs text-muted-foreground bg-muted/50 p-2 rounded-md leading-snug">
                          Кнопка CTA открывает диалог «Отклик» в платформе — почтовый клиент не запускается. Прямая ссылка (https://) останется доступной рядом.
                        </p>
                      </div>
                    </div>
                  )}

                  {isCommercial && !canCommercial && (
                    <div className="mt-3 text-xs text-muted-foreground bg-muted/50 p-2 rounded-md">
                      ℹ️ Commercial-посты с CTA-кнопкой доступны на тарифе <strong>Business</strong>.{' '}
                      <button
                        onClick={() => useAppStore.getState().setView('subscription')}
                        className="text-primary underline hover:no-underline"
                      >
                        Перейти →
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t">
                <div className="flex flex-wrap gap-1">
                  {tags && tags.split(',').filter(Boolean).map((t, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">#{t.trim()}</Badge>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  {content && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => { setContent(''); setTags(''); setIsCommercial(false); setFocused(false); }}
                      disabled={loading}
                    >
                      <X className="w-4 h-4" /> Отмена
                    </Button>
                  )}
                  <Button
                    onClick={handleSubmit}
                    disabled={loading || !content.trim()}
                    size="sm"
                  >
                    {loading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Sparkles className="w-4 h-4 mr-1" />}
                    Опубликовать
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
