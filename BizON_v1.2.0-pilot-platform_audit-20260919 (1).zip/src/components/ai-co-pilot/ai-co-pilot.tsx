// BizON — AI Co-Pilot (плавающий ассистент в TopBar)
// ТЗ 4.3: AI Co-Pilot — контекстный ассистент, анализирует действия, предлагает советы
'use client';
import * as React from 'react';
import { useAppStore } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Brain, X, Send, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

export function AICoPilot() {
  const [open, setOpen] = React.useState(false);
  const [messages, setMessages] = React.useState<Array<{role: 'user'|'assistant', content: string}>>([
    { role: 'assistant', content: 'Привет! Я AI Co-Pilot BizON. Спросите меня — как поднять IP-score, найти контакт, или что делать дальше.' }
  ]);
  const [input, setInput] = React.useState('');
  const { user } = useAppStore();

  function quickAsk(q: string) {
    setMessages(prev => [...prev, { role: 'user', content: q }]);
    // Простые ответы без LLM (для MVP)
    setTimeout(() => {
      let answer = '';
      if (q.includes('IP-score') || q.includes('рейтинг') || q.includes('доверие')) {
        answer = `Ваш IP-score: ${user?.ipScore ?? '?'}. Чтобы расти:\n• Завершайте проекты (+8)\n• Подтверждайте навыки через проекты (+5)\n• Добавляйте связи (+3)\n• Публикуйте посты (+1)`;
      } else if (q.includes('найти') || q.includes('контакт') || q.includes('связь')) {
        answer = 'Используйте AI-Matchmaker — он найдёт путь к нужному человеку через 5 рукопожатий. Перейдите в раздел «AI-Поиск».';
      } else if (q.includes('проект')) {
        answer = 'Создайте проект в разделе «Проекты». Каждый участник подтвердит ваше участие — это поднимет ваш IP-score.';
      } else if (q.includes('карьер') || q.includes('ваканси')) {
        answer = 'AI-Career-Agent построит карьерную траекторию. Перейдите в «AI-Карьера» в разделе «Ещё».';
      } else {
        answer = 'Я помогу с:\n• Рост IP-score\n• Поиск контактов\n• Создание проектов\n• Карьерные рекомендации\n\nЧто вас интересует?';
      }
      setMessages(prev => [...prev, { role: 'assistant', content: answer }]);
    }, 500);
  }

  function send() {
    if (!input.trim()) return;
    quickAsk(input);
    setInput('');
  }

  return (
    <>
      {/* Кнопка в TopBar */}
      <Button variant="ghost" size="icon" onClick={() => setOpen(true)} title="AI Co-Pilot" className="relative">
        <Brain className="w-4 h-4" />
        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-lighthouse beacon-pulse" />
      </Button>

      {/* Панель Co-Pilot */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-end sm:justify-end p-4 bg-black/20" onClick={() => setOpen(false)}>
          <div className="w-full sm:w-96 bg-card border rounded-2xl shadow-2xl flex flex-col max-h-[70vh] soft-fade-in" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center gap-2 p-3 border-b">
              <div className="w-8 h-8 rounded-lg lighthouse-gradient flex items-center justify-center"><Brain className="w-4 h-4 text-white" /></div>
              <div className="flex-1"><div className="text-sm font-semibold">AI Co-Pilot</div><div className="text-xs text-muted-foreground">Ваш персональный ассистент</div></div>
              <Button variant="ghost" size="icon" onClick={() => setOpen(false)}><X className="w-4 h-4" /></Button>
            </div>
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2 scroll-area-thin">
              {messages.map((m, i) => (
                <div key={i} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                  <div className={cn('rounded-2xl px-3 py-2 text-sm max-w-[85%] whitespace-pre-wrap', m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted')}>{m.content}</div>
                </div>
              ))}
            </div>
            {/* Quick actions */}
            {messages.length <= 1 && (
              <div className="px-3 pb-2 flex gap-1.5 flex-wrap">
                {['Как поднять IP-score?', 'Найти контакт', 'Создать проект', 'Карьера'].map(q => (
                  <button key={q} onClick={() => quickAsk(q)} className="px-2.5 py-1 text-xs rounded-full border hover:border-lighthouse hover:text-lighthouse transition">{q}</button>
                ))}
              </div>
            )}
            {/* Input */}
            <div className="flex gap-2 p-3 border-t">
              <Input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="Спросите..." className="flex-1" />
              <Button size="icon" onClick={send} disabled={!input.trim()}><Send className="w-4 h-4" /></Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
