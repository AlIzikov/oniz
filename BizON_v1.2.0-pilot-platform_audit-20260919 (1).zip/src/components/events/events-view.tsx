// BizON — Events View (мероприятия с RSVP) + полный цикл: создание (Pro-гейт, направление В)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import {
  Calendar, MapPin, Video, Users, Clock, Star, ChevronLeft, ChevronRight, Plus, Crown, Loader2,
  Search, Gem, Mic, SearchX,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface EventItem {
  id: string;
  title: string;
  description: string;
  format: string;
  category: string;
  startDate: string;
  endDate: string | null;
  location: string | null;
  imageUrl: string | null;
  maxParticipants: number | null;
  trustScore: number;
  // Wave 3 (S-063): цена / внешняя регистрация / lifecycle / спикеры
  priceLumens: number | null;
  registrationUrl: string | null;
  status: string;
  speakers: Array<{ id: string; name: string; title: string | null }>;
  company: { id: string; name: string; logoUrl: string | null } | null;
  organizer: { id: string; name: string; avatarUrl: string | null } | null;
  participantsCount: number;
  myStatus: string | null;
}

const CATEGORY_LABELS: Record<string, string> = {
  conference: 'Конференция',
  meetup: 'Митап',
  workshop: 'Воркшоп',
  webinar: 'Вебинар',
  hackathon: 'Хакатон',
};

const FORMAT_LABELS: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  online: { label: 'Онлайн', icon: <Video className="w-3 h-3" />, color: 'bg-lighthouse/10 text-lighthouse' },
  offline: { label: 'Офлайн', icon: <MapPin className="w-3 h-3" />, color: 'bg-primary/10 text-primary' },
  hybrid: { label: 'Гибрид', icon: <Users className="w-3 h-3" />, color: 'bg-warning/10 text-warning-foreground' },
};

export function EventsView() {
  const setView = useAppStore((s) => s.setView);
  const user = useAppStore((s) => s.user);
  const [events, setEvents] = React.useState<EventItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filterFormat, setFilterFormat] = React.useState<string | null>(null);
  const [filterCategory, setFilterCategory] = React.useState<string | null>(null);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [createOpen, setCreateOpen] = React.useState(false);
  const isFreeTier = user?.subscriptionTier === 'free';

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filterFormat) params.set('format', filterFormat);
      if (filterCategory) params.set('category', filterCategory);
      if (searchQuery.trim()) params.set('q', searchQuery.trim());
      const res = await api<{ events: EventItem[] }>(`/api/events?limit=30&${params.toString()}`);
      setEvents(res.events);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [filterFormat, filterCategory, searchQuery]);

  React.useEffect(() => { load(); }, [load]);

  async function handleRSVP(eventId: string, status: 'going' | 'interested' | 'not_going') {
    try {
      await api(`/api/events/${eventId}/rsvp`, {
        method: 'POST',
        body: JSON.stringify({ status }),
      });
      // Обновляем локально
      setEvents((prev) => prev.map((e) => e.id === eventId ? {
        ...e,
        myStatus: status,
        participantsCount: status === 'going' && e.myStatus !== 'going' ? e.participantsCount + 1 :
                          status !== 'going' && e.myStatus === 'going' ? e.participantsCount - 1 :
                          e.participantsCount,
      } : e));
      if (status === 'going') toast({ title: 'Вы идёте на мероприятие' });
      else if (status === 'interested') toast({ title: 'Отмечено как интересное' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Мероприятия</h1>
          <p className="text-sm text-muted-foreground">Конференции, митапы, воркшопы — рядом и онлайн</p>
        </div>
        <Button
          onClick={() => {
            if (isFreeTier) {
              // Направление В: Pro-гейт в UI — без вызова API, с честным объяснением
              toast({
                title: 'Доступно на Pro и Business',
                description: 'Создание мероприятий — для организаторов на платных тарифах. Обновите тариф в настройках.',
                variant: 'destructive',
              });
              return;
            }
            setCreateOpen(true);
          }}
          className="flex-shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Создать событие</span>
          {isFreeTier && <Crown className="w-3 h-3 text-amber-500" />}
        </Button>
      </div>

      <CreateEventDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={() => load()}
      />

      {/* Filters */}
      <div className="space-y-2">
        {/* Wave 3 S-066: поиск по 5 полям */}
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Поиск: тема, город, формат…"
            className="pl-8"
            aria-label="Поиск мероприятий"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          <button
            onClick={() => setFilterFormat(null)}
            className={cn('px-3 py-1 text-xs rounded-full border transition', filterFormat === null ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary')}
          >
            Все форматы
          </button>
          {Object.entries(FORMAT_LABELS).map(([key, val]) => (
            <button
              key={key}
              onClick={() => setFilterFormat(filterFormat === key ? null : key)}
              className={cn('px-3 py-1 text-xs rounded-full border transition flex items-center gap-1', filterFormat === key ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary')}
            >
              {val.icon} {val.label}
            </button>
          ))}
        </div>
        <div className="flex gap-1.5 flex-wrap">
          <button
            onClick={() => setFilterCategory(null)}
            className={cn('px-3 py-1 text-xs rounded-full border transition', filterCategory === null ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary')}
          >
            Все темы
          </button>
          {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setFilterCategory(filterCategory === key ? null : key)}
              className={cn('px-3 py-1 text-xs rounded-full border transition', filterCategory === key ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary')}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-40 w-full rounded-xl" />)}
        </div>
      ) : events.length === 0 ? (
        <Card className="p-8 text-center">
          <Calendar className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">Мероприятий не найдено</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {events.map((e) => <EventCard key={e.id} event={e} onRSVP={handleRSVP} />)}
        </div>
      )}
    </div>
  );
}

function EventCard({ event: e, onRSVP }: { event: EventItem; onRSVP: (id: string, status: 'going' | 'interested' | 'not_going') => void }) {
  const formatMeta = FORMAT_LABELS[e.format] ?? FORMAT_LABELS.online;
  const date = new Date(e.startDate);
  const now = new Date();
  const daysLeft = Math.ceil((date.getTime() - now.getTime()) / (24 * 60 * 60 * 1000));

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow soft-fade-in">
      <div className="flex flex-col sm:flex-row">
        {/* Image / Date badge */}
        <div className="sm:w-40 h-32 sm:h-auto bg-muted relative flex-shrink-0">
          {e.imageUrl ? (
            <img src={e.imageUrl} alt="" className="w-full h-full object-cover" onError={(ev) => (ev.currentTarget.style.display = 'none')} />
          ) : null}
          {/* Date badge over image */}
          <div className="absolute top-2 left-2 bg-card/95 backdrop-blur rounded-md px-2 py-1 text-center">
            <div className="text-xs text-muted-foreground uppercase">{date.toLocaleDateString('ru-RU', { month: 'short' })}</div>
            <div className="text-lg font-bold leading-none">{date.getDate()}</div>
          </div>
        </div>

        <CardContent className="p-4 flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <Badge variant="outline" className={cn('text-xs gap-1', formatMeta.color)}>
                {formatMeta.icon} {formatMeta.label}
              </Badge>
              <Badge variant="secondary" className="text-xs">{CATEGORY_LABELS[e.category] ?? e.category}</Badge>
              {/* Wave 3 S-063: платное участие + lifecycle-статус */}
              {e.priceLumens ? (
                <Badge variant="outline" className="text-xs gap-0.5 border-primary/40 text-primary">
                  <Gem className="w-3 h-3" /> {e.priceLumens} лм.
                </Badge>
              ) : null}
              {e.status !== 'published' && (
                <Badge variant="outline" className="text-xs">
                  {e.status === 'draft' ? 'Черновик' : 'Отменено'}
                </Badge>
              )}
              <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                <Star className="w-3 h-3 fill-lighthouse text-lighthouse" />
                {Math.round(e.trustScore * 100)}
              </span>
            </div>
            {daysLeft >= 0 && (
              <span className="text-xs text-lighthouse font-medium whitespace-nowrap">
                {daysLeft === 0 ? 'Сегодня' : daysLeft === 1 ? 'Завтра' : `Через ${daysLeft} дн.`}
              </span>
            )}
          </div>

          <h3 className="font-semibold text-base mb-1">{e.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{e.description}</p>

          {/* Wave 3 S-063: спикеры */}
          {e.speakers.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground mb-2">
              <Mic className="w-3 h-3" />
              {e.speakers.slice(0, 3).map((s) => (
                <span key={s.id} className="rounded-full bg-muted px-2 py-0.5">
                  {s.name}{s.title ? ` · ${s.title}` : ''}
                </span>
              ))}
              {e.speakers.length > 3 && <span>+{e.speakers.length - 3}</span>}
            </div>
          )}

          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3 flex-wrap">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
            </span>
            {e.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {e.location}</span>}
            <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {e.participantsCount}{e.maxParticipants ? `/${e.maxParticipants}` : ''}</span>
            {e.company && <span>· {e.company.name}</span>}
          </div>

          {/* RSVP buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Платное участие — честная пометка у кнопки */}
            {e.priceLumens ? (
              <span className="text-xs text-muted-foreground">Участие платное — при нажатии «Иду» списывается {e.priceLumens} люменов</span>
            ) : null}
            {e.registrationUrl && (
              <a href={e.registrationUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline hover:no-underline">
                Внешняя регистрация ↗
              </a>
            )}
            {e.status !== 'cancelled' && (
            <>
            <Button
              size="sm"
              variant={e.myStatus === 'going' ? 'default' : 'outline'}
              onClick={() => onRSVP(e.id, 'going')}
            >
              {e.myStatus === 'going' ? '✓ Иду' : 'Иду'}
            </Button>
            <Button
              size="sm"
              variant={e.myStatus === 'interested' ? 'default' : 'outline'}
              onClick={() => onRSVP(e.id, 'interested')}
            >
              Интересно
            </Button>
            {e.myStatus && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onRSVP(e.id, 'not_going')}
                className="text-muted-foreground"
              >
                Не иду
              </Button>
            )}
            </>
            )}
          </div>
        </CardContent>
      </div>
    </Card>
  );
}

// ===== Направление В: диалог создания события (Pro/Business) =====
// Канон — POST /api/events (withRoute: zod, даты 422, SSRF-гейт, санитайзер,
// Pro-гейт 403). Диалог только собирает данные и показывает ошибки API.

const EMPTY_FORM = {
  title: '',
  description: '',
  format: 'online',
  category: 'meetup',
  startDate: '',
  endDate: '',
  location: '',
  imageUrl: '',
  maxParticipants: '',
  priceLumens: '',
  registrationUrl: '',
  speakersText: '',
  asDraft: false,
};

function CreateEventDialog({ open, onOpenChange, onCreated }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: () => void;
}) {
  const [form, setForm] = React.useState(EMPTY_FORM);
  const [submitting, setSubmitting] = React.useState(false);

  const set = (key: keyof typeof EMPTY_FORM) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title.trim() || !form.description.trim() || !form.startDate) {
      toast({ title: 'Заполните обязательные поля', description: 'Название, описание и дата начала.', variant: 'destructive' });
      return;
    }
    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        title: form.title.trim(),
        description: form.description.trim(),
        format: form.format,
        category: form.category,
        startDate: new Date(form.startDate).toISOString(),
      };
      if (form.endDate) payload.endDate = new Date(form.endDate).toISOString();
      if (form.location.trim()) payload.location = form.location.trim();
      if (form.imageUrl.trim()) payload.imageUrl = form.imageUrl.trim();
      if (form.maxParticipants) {
        const n = Number(form.maxParticipants);
        if (!Number.isInteger(n) || n <= 0) {
          toast({ title: 'Максимум участников — положительное целое число', variant: 'destructive' });
          setSubmitting(false);
          return;
        }
        payload.maxParticipants = n;
      }
      // Wave 3 S-063: цена / внешняя регистрация / спикеры / черновик
      if (form.priceLumens) {
        const p = Number(form.priceLumens);
        if (!Number.isInteger(p) || p < 0 || p > 100000) {
          toast({ title: 'Цена участия — целое число 0…100000 люменов', variant: 'destructive' });
          setSubmitting(false);
          return;
        }
        if (p > 0) payload.priceLumens = p;
      }
      if (form.registrationUrl.trim()) payload.registrationUrl = form.registrationUrl.trim();
      if (form.asDraft) payload.asDraft = true;
      const speakers = form.speakersText
        .split('\n')
        .map((line) => {
          const parts = line.split('|').map((s) => s.trim());
          const name = parts[0];
          const title = parts[1];
          if (!name) return null;
          return { name, title: title && title.length > 0 ? title : undefined } as { name: string; title?: string };
        })
        .filter((s): s is { name: string; title?: string } => s !== null)
        .slice(0, 10);
      if (speakers.length > 0) payload.speakers = speakers;
      await api('/api/events', { method: 'POST', body: JSON.stringify(payload) });
      toast({ title: 'Событие создано', description: 'Оно уже доступно в списке мероприятий.' });
      setForm(EMPTY_FORM);
      onOpenChange(false);
      onCreated();
    } catch (e: any) {
      toast({ title: 'Не удалось создать событие', description: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto scroll-area-thin">
        <DialogHeader>
          <DialogTitle>Новое мероприятие</DialogTitle>
          <DialogDescription>
            Организуйте митап, воркшоп или вебинар. Обязательны название, описание и дата начала.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="ev-title">Название *</Label>
            <Input id="ev-title" value={form.title} onChange={set('title')} maxLength={200} placeholder="Митап BizON Community" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ev-desc">Описание *</Label>
            <Textarea id="ev-desc" value={form.description} onChange={set('description')} maxLength={5000} rows={4} placeholder="О чём событие, кто спикеры, программа" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Формат</Label>
              <Select value={form.format} onValueChange={(v) => setForm((f) => ({ ...f, format: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="online">Онлайн</SelectItem>
                  <SelectItem value="offline">Офлайн</SelectItem>
                  <SelectItem value="hybrid">Гибрид</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Тема</Label>
              <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="ev-start">Начало *</Label>
              <Input id="ev-start" type="datetime-local" value={form.startDate} onChange={set('startDate')} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ev-end">Окончание</Label>
              <Input id="ev-end" type="datetime-local" value={form.endDate} onChange={set('endDate')} />
            </div>
          </div>
          {form.format !== 'online' && (
            <div className="space-y-1.5">
              <Label htmlFor="ev-loc">Место проведения</Label>
              <Input id="ev-loc" value={form.location} onChange={set('location')} maxLength={200} placeholder="Москва, ул. Примерная, 1" />
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="ev-max">Лимит участников</Label>
              <Input id="ev-max" type="number" min="1" step="1" value={form.maxParticipants} onChange={set('maxParticipants')} placeholder="Без лимита" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ev-img">Ссылка на изображение</Label>
              <Input id="ev-img" value={form.imageUrl} onChange={set('imageUrl')} maxLength={2048} placeholder="https://…" />
            </div>
          </div>
          {/* Wave 3 S-063: платное участие, внешняя регистрация, спикеры, черновик */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="ev-price">Цена участия (люмены, 0 = бесплатно)</Label>
              <Input id="ev-price" type="number" min="0" step="1" value={form.priceLumens} onChange={set('priceLumens')} placeholder="0" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ev-reg">Внешняя регистрация (URL)</Label>
              <Input id="ev-reg" value={form.registrationUrl} onChange={set('registrationUrl')} maxLength={2048} placeholder="https://…" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ev-speakers">Спикеры (по одному в строке: «Имя | Должность»)</Label>
            <Textarea id="ev-speakers" value={form.speakersText} onChange={set('speakersText')} rows={2} placeholder="Анна Петрова | CTO, Acme" />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.asDraft}
              onChange={(e) => setForm((f) => ({ ...f, asDraft: e.target.checked }))}
              className="h-4 w-4"
            />
            Сохранить как черновик (опубликовать позже)
          </label>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
              Отмена
            </Button>
            <Button type="submit" disabled={submitting}>
              {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Создаём…</> : 'Создать событие'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
