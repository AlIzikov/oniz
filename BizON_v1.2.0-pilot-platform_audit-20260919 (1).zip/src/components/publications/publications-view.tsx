// BizON — Этап 7.3 — PublicationsView
// Долгоживущий контент (статьи, кейсы, исследования) с соавторами (до 5 авторов).
// - Список публикаций (карточки: title, type badge, authors avatars, readingTime)
// - Кнопка «Создать публикацию» → модалка с формой
// - Форма: title, type dropdown, content textarea, externalUrl, до 4 co-authors
//   (поиск через /api/users/search)
// - Pending-вкладка: приглашения, ожидающие ответа (accept/reject)
// - После создания — уведомление соавторам (на бэке) + toast
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { toast } from '@/hooks/use-toast';
import type { PublicationPublic, PublicationType } from '@/lib/types';
import {
  Plus, Loader2, ExternalLink, FileText, Clock, X, Check, Search,
  BookOpen, Lightbulb, Microscope, GraduationCap, MessagesSquare, PenLine,
  UserCheck,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// === Константы ===
const PUBLICATION_TYPES: Array<{ value: PublicationType; label: string; icon: React.ReactNode; color: string }> = [
  { value: 'ARTICLE',     label: 'Статья',          icon: <FileText className="w-3.5 h-3.5" />,        color: 'border-blue-500/40 text-blue-700 dark:text-blue-400 bg-blue-500/5' },
  { value: 'CASE_STUDY',  label: 'Кейс',            icon: <BookOpen className="w-3.5 h-3.5" />,        color: 'border-emerald-500/40 text-emerald-700 dark:text-emerald-400 bg-emerald-500/5' },
  { value: 'OPINION',     label: 'Мнение',          icon: <PenLine className="w-3.5 h-3.5" />,         color: 'border-amber-500/40 text-amber-700 dark:text-amber-400 bg-amber-500/5' },
  { value: 'RESEARCH',    label: 'Исследование',    icon: <Microscope className="w-3.5 h-3.5" />,      color: 'border-purple-500/40 text-purple-700 dark:text-purple-400 bg-purple-500/5' },
  { value: 'TUTORIAL',    label: 'Туториал',        icon: <GraduationCap className="w-3.5 h-3.5" />,   color: 'border-cyan-500/40 text-cyan-700 dark:text-cyan-400 bg-cyan-500/5' },
  { value: 'INTERVIEW',   label: 'Интервью',        icon: <MessagesSquare className="w-3.5 h-3.5" />,  color: 'border-pink-500/40 text-pink-700 dark:text-pink-400 bg-pink-500/5' },
];

const TYPE_META: Record<string, { label: string; icon: React.ReactNode; color: string }> = Object.fromEntries(
  PUBLICATION_TYPES.map((t) => [t.value, { label: t.label, icon: t.icon, color: t.color }]),
);

type Tab = 'all' | 'mine' | 'pending';

// === Helpers ===
function formatRelative(iso: string): string {
  const now = Date.now();
  const diff = now - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (minutes < 1) return 'только что';
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  if (days < 30) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU');
}

// === Main View ===
export function PublicationsView() {
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const [tab, setTab] = React.useState<Tab>('all');
  const [items, setItems] = React.useState<PublicationPublic[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [typeFilter, setTypeFilter] = React.useState<string>('all');
  const [createOpen, setCreateOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('limit', '50');
      if (tab === 'mine') params.set('mine', 'true');
      if (tab === 'pending') params.set('pending', 'true');
      if (typeFilter !== 'all') params.set('type', typeFilter);
      const res = await api<{ items: PublicationPublic[]; total: number }>(
        `/api/publications?${params.toString()}`,
      );
      setItems(res.items ?? []);
    } catch (e: any) {
      toast({ title: 'Ошибка загрузки', description: e.message, variant: 'destructive' });
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [tab, typeFilter]);

  React.useEffect(() => {
    load();
  }, [load]);

  function handleCreated(pub: PublicationPublic) {
    setItems((prev) => [pub, ...prev]);
    setCreateOpen(false);
    toast({
      title: 'Публикация создана',
      description:
        (pub.authors?.length ?? 0) > 1
          ? `Соавторы получат приглашение и уведомление`
          : 'Появится в списке ниже',
    });
  }

  async function handleAccept(pub: PublicationPublic) {
    try {
      await api(`/api/publications/${pub.id}/accept`, { method: 'POST' });
      toast({ title: 'Приглашение принято', description: 'Вы теперь соавтор публикации' });
      // В pending-вкладке — убираем из списка; в mine/all — обновляем статус
      if (tab === 'pending') {
        setItems((prev) => prev.filter((p) => p.id !== pub.id));
      } else {
        setItems((prev) =>
          prev.map((p) =>
            p.id === pub.id && p.myInvite
              ? { ...p, myInvite: { ...p.myInvite, acceptedAt: new Date().toISOString() } }
              : p,
          ),
        );
      }
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handleReject(pub: PublicationPublic) {
    try {
      await api(`/api/publications/${pub.id}/reject`, { method: 'POST' });
      toast({ title: 'Приглашение отклонено' });
      setItems((prev) => prev.filter((p) => p.id !== pub.id));
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold">Публикации</h1>
          <p className="text-sm text-muted-foreground">
            Статьи, кейсы и исследования с соавторами (до 5 авторов)
          </p>
        </div>
        <Button onClick={() => setCreateOpen(true)} size="sm" className="gap-1.5">
          <Plus className="w-4 h-4" />
          Создать публикацию
        </Button>
      </div>

      {/* Табы: Все / Мои / Приглашения */}
      <div className="flex gap-1 border-b overflow-x-auto scroll-area-thin">
        {([
          ['all',     'Все'],
          ['mine',    'Мои'],
          ['pending', 'Приглашения'],
        ] as const).map(([t, label]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              'px-3 py-1.5 text-sm border-b-2 -mb-px transition whitespace-nowrap',
              tab === t
                ? 'border-primary text-primary font-medium'
                : 'border-transparent text-muted-foreground hover:text-foreground',
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Фильтр по типу — только во all / mine */}
      {tab !== 'pending' && (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-muted-foreground">Тип:</span>
          <button
            onClick={() => setTypeFilter('all')}
            className={cn(
              'text-xs px-2 py-1 rounded-md border transition',
              typeFilter === 'all'
                ? 'border-primary bg-primary/5 text-primary'
                : 'border-transparent hover:bg-muted/50 text-muted-foreground',
            )}
          >
            Все
          </button>
          {PUBLICATION_TYPES.map((t) => (
            <button
              key={t.value}
              onClick={() => setTypeFilter(t.value)}
              className={cn(
                'inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md border transition',
                typeFilter === t.value
                  ? t.color + ' border-current font-medium'
                  : 'border-transparent hover:bg-muted/50 text-muted-foreground',
              )}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>
      )}

      {/* Список */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="p-4">
              <Skeleton className="h-4 w-1/3 mb-2" />
              <Skeleton className="h-6 w-2/3 mb-3" />
              <Skeleton className="h-3 w-1/4" />
            </Card>
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">
            {tab === 'pending'
              ? 'Нет ожидающих приглашений. Когда вас пригласят стать соавтором — оно появится здесь.'
              : tab === 'mine'
                ? 'У вас пока нет публикаций. Нажмите «Создать публикацию» выше.'
                : 'Публикаций пока нет. Создайте первую!'}
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {items.map((pub) => (
            <PublicationCard
              key={pub.id}
              pub={pub}
              onUserClick={setProfileUserId}
              onAccept={handleAccept}
              onReject={handleReject}
            />
          ))}
        </div>
      )}

      {/* Модалка создания */}
      <CreatePublicationDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={handleCreated}
      />
    </div>
  );
}

// ============================================================================
// PublicationCard — карточка публикации в списке
// ============================================================================
function PublicationCard({
  pub,
  onUserClick,
  onAccept,
  onReject,
}: {
  pub: PublicationPublic;
  onUserClick: (id: string) => void;
  onAccept: (pub: PublicationPublic) => void;
  onReject: (pub: PublicationPublic) => void;
}) {
  const meta = TYPE_META[pub.type] ?? TYPE_META.ARTICLE;
  const acceptedAuthors = pub.authors.filter((a) => a.acceptedAt);
  const pendingAuthors = pub.authors.filter((a) => !a.acceptedAt);
  const myInvitePending = pub.myInvite && !pub.myInvite.acceptedAt && pub.myInvite.role !== 'author';

  // Cover: либо внешняя ссылка как «карточка-обложка», либо нативный текст
  const hasExternal = !!pub.externalUrl;

  return (
    <Card className="hover:shadow-md transition-shadow soft-fade-in">
      <CardContent className="p-4">
        {/* Header: type badge + readingTime + дата */}
        <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
          <Badge variant="outline" className={cn('text-xs gap-1', meta.color)}>
            {meta.icon}
            {meta.label}
          </Badge>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {pub.readingTime != null && (
              <span className="inline-flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {pub.readingTime} мин
              </span>
            )}
            <span>{formatRelative(pub.publishedAt)}</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-base font-semibold leading-snug mb-2">
          {hasExternal ? (
            <a
              href={pub.externalUrl!}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:underline inline-flex items-start gap-1.5"
            >
              <span>{pub.title}</span>
              <ExternalLink className="w-3.5 h-3.5 mt-1 text-muted-foreground shrink-0" />
            </a>
          ) : (
            pub.title
          )}
        </h3>

        {/* Content preview — для нативных публикаций */}
        {!hasExternal && (
          <div className="text-sm text-foreground/80 line-clamp-3 whitespace-pre-wrap mb-3">
            {pub.content}
          </div>
        )}

        {/* Для external — короткое описание (excerpt из content) */}
        {hasExternal && pub.content && (
          <div className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {pub.content}
          </div>
        )}

        {/* Image (опционально) */}
        {pub.imageUrl && (
          <div className="rounded-lg overflow-hidden border mb-3 max-h-72">
            <img
              src={pub.imageUrl}
              alt=""
              className="w-full max-h-72 object-cover"
              onError={(e) => {
                e.currentTarget.parentElement!.style.display = 'none';
              }}
            />
          </div>
        )}

        {/* Authors: аватарки + имена + pending-бейджи */}
        <div className="flex items-center gap-2 flex-wrap pt-2 border-t">
          <div className="flex items-center -space-x-2">
            {acceptedAuthors.slice(0, 5).map((a) => (
              <button
                key={a.id}
                onClick={() => onUserClick(a.userId)}
                title={`${a.user.name} (${a.role})`}
                className="ring-2 ring-background rounded-full"
              >
                <UserAvatar name={a.user.name} avatarUrl={a.user.avatarUrl} size="sm" />
              </button>
            ))}
            {pendingAuthors.length > 0 && (
              <div
                className="ring-2 ring-background rounded-full w-8 h-8 bg-muted flex items-center justify-center text-xs font-medium text-muted-foreground"
                title={`${pendingAuthors.length} соавтор(ов) ожидает подтверждения`}
              >
                +{pendingAuthors.length}
              </div>
            )}
          </div>
          <div className="text-xs text-muted-foreground">
            {acceptedAuthors.length > 0 ? (
              <>
                {acceptedAuthors
                  .map((a) => a.user.name)
                  .slice(0, 3)
                  .join(', ')}
                {acceptedAuthors.length > 3 && ` и ещё ${acceptedAuthors.length - 3}`}
              </>
            ) : (
              <span className="italic">Автор удалён</span>
            )}
            {pendingAuthors.length > 0 && (
              <span className="ml-1 text-amber-600 dark:text-amber-400">
                · ждут {pendingAuthors.length}
              </span>
            )}
          </div>
        </div>

        {/* Если есть ожидающее приглашение для меня — accept/reject */}
        {myInvitePending && (
          <div className="mt-3 flex items-center gap-2 p-3 rounded-lg bg-amber-500/5 border border-amber-500/30">
            <div className="text-sm flex-1">Вас пригласили как соавтора</div>
            <Button size="sm" variant="outline" onClick={() => onReject(pub)} className="gap-1.5">
              <X className="w-3.5 h-3.5" />
              Отклонить
            </Button>
            <Button size="sm" onClick={() => onAccept(pub)} className="gap-1.5">
              <Check className="w-3.5 h-3.5" />
              Принять
            </Button>
          </div>
        )}

        {/* Если я уже принял — бейдж */}
        {pub.myInvite && pub.myInvite.acceptedAt && pub.myInvite.role !== 'author' && (
          <div className="mt-3 inline-flex items-center gap-1.5 text-xs px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-700 dark:text-emerald-400">
            <UserCheck className="w-3.5 h-3.5" />
            Вы — соавтор
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// CreatePublicationDialog — модалка создания публикации
// ============================================================================
function CreatePublicationDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: (pub: PublicationPublic) => void;
}) {
  const [title, setTitle] = React.useState('');
  const [type, setType] = React.useState<PublicationType>('ARTICLE');
  const [content, setContent] = React.useState('');
  const [externalUrl, setExternalUrl] = React.useState('');
  const [imageUrl, setImageUrl] = React.useState('');
  const [readingTime, setReadingTime] = React.useState('');
  const [coAuthorIds, setCoAuthorIds] = React.useState<string[]>([]);
  const [submitting, setSubmitting] = React.useState(false);

  // Search users
  const [query, setQuery] = React.useState('');
  const [searchResults, setSearchResults] = React.useState<
    Array<{ id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number }>
  >([]);
  const [searching, setSearching] = React.useState(false);

  // Reset on close
  React.useEffect(() => {
    if (!open) {
      setTitle('');
      setType('ARTICLE');
      setContent('');
      setExternalUrl('');
      setImageUrl('');
      setReadingTime('');
      setCoAuthorIds([]);
      setQuery('');
      setSearchResults([]);
    }
  }, [open]);

  // Debounced search
  React.useEffect(() => {
    if (query.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    setSearching(true);
    const t = setTimeout(() => {
      api<{ users: Array<{ id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number }> }>(
        `/api/users/search?q=${encodeURIComponent(query.trim())}&limit=10`,
      )
        .then((res) => setSearchResults(res.users ?? []))
        .catch(() => setSearchResults([]))
        .finally(() => setSearching(false));
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  function toggleCoAuthor(id: string) {
    setCoAuthorIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : prev.length < 4 ? [...prev, id] : prev,
    );
  }

  const selectedUsers = searchResults.filter((u) => coAuthorIds.includes(u.id));

  async function handleSubmit() {
    if (!title.trim() || !content.trim()) return;
    if (submitting) return;
    setSubmitting(true);
    try {
      const body: any = {
        title: title.trim(),
        type,
        content: content.trim(),
        coAuthorIds,
      };
      if (externalUrl.trim()) body.externalUrl = externalUrl.trim();
      if (imageUrl.trim()) body.imageUrl = imageUrl.trim();
      const rt = parseInt(readingTime, 10);
      if (Number.isFinite(rt) && rt > 0) body.readingTime = rt;

      const res = await api<{ publication: PublicationPublic }>('/api/publications', {
        method: 'POST',
        body: JSON.stringify(body),
      });
      onCreated(res.publication);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Создать публикацию</DialogTitle>
          <DialogDescription>
            Долгоживущий контент с соавторами (до 5 авторов всего: вы + 4 соавтора)
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Title */}
          <div className="space-y-1.5">
            <Label htmlFor="pub-title">Заголовок *</Label>
            <Input
              id="pub-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Например: «Как мы переписали бэкенд на Go за 3 месяца»"
              maxLength={240}
            />
          </div>

          {/* Type */}
          <div className="space-y-1.5">
            <Label>Тип публикации *</Label>
            <Select value={type} onValueChange={(v) => setType(v as PublicationType)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PUBLICATION_TYPES.map((t) => (
                  <SelectItem key={t.value} value={t.value}>
                    <span className="inline-flex items-center gap-2">
                      {t.icon}
                      {t.label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Content */}
          <div className="space-y-1.5">
            <Label htmlFor="pub-content">
              Содержание * {externalUrl.trim() ? '(краткое описание для карточки)' : '(нативный текст)'}
            </Label>
            <Textarea
              id="pub-content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={
                externalUrl.trim()
                  ? 'Короткое описание (2-3 предложения) для карточки в ленте'
                  : 'Полный текст публикации. Поддерживаются переводы строк.'
              }
              className="min-h-[160px] resize-y"
              maxLength={50000}
            />
            <div className="text-xs text-muted-foreground text-right">
              {content.length} / 50000
            </div>
          </div>

          {/* External URL (опционально) */}
          <div className="space-y-1.5">
            <Label htmlFor="pub-url">Внешняя ссылка (необязательно)</Label>
            <Input
              id="pub-url"
              value={externalUrl}
              onChange={(e) => setExternalUrl(e.target.value)}
              placeholder="https://habr.com/ru/articles/... или Medium, personal blog"
              type="url"
            />
            <p className="text-xs text-muted-foreground">
              Если статья уже опубликована на Habr/Medium/personal blog — укажите ссылку.
              Контент выше будет использован как краткое описание.
            </p>
          </div>

          {/* Image URL (опционально) */}
          <div className="space-y-1.5">
            <Label htmlFor="pub-image">URL обложки (необязательно)</Label>
            <Input
              id="pub-image"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://...jpg"
              type="url"
            />
          </div>

          {/* Reading time (опционально) */}
          <div className="space-y-1.5">
            <Label htmlFor="pub-rt">Время чтения, мин (необязательно)</Label>
            <Input
              id="pub-rt"
              value={readingTime}
              onChange={(e) => setReadingTime(e.target.value.replace(/[^0-9]/g, ''))}
              placeholder="5"
              inputMode="numeric"
              className="max-w-[120px]"
            />
          </div>

          {/* Co-authors */}
          <div className="space-y-1.5">
            <Label>
              Соавторы ({coAuthorIds.length} / 4)
            </Label>
            <p className="text-xs text-muted-foreground">
              Вы — автор. Можно пригласить до 4 соавторов. Они получат уведомление
              и должны принять приглашение.
            </p>

            {/* Выбранные соавторы */}
            {selectedUsers.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {selectedUsers.map((u) => (
                  <Badge
                    key={u.id}
                    variant="secondary"
                    className="gap-1 pl-1 pr-1.5 py-0.5"
                  >
                    <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="xs" />
                    <span className="text-xs">{u.name}</span>
                    <button
                      onClick={() => toggleCoAuthor(u.id)}
                      className="ml-1 hover:text-destructive"
                      aria-label={`Убрать ${u.name}`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            {/* Поиск */}
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Имя, должность или локация соавтора..."
                className="pl-8"
              />
              {searching && (
                <Loader2 className="absolute right-2.5 top-2.5 w-4 h-4 animate-spin text-muted-foreground" />
              )}
            </div>

            {/* Результаты поиска */}
            {query.trim().length >= 2 && (
              <div className="max-h-56 overflow-y-auto space-y-1 border rounded-md p-1">
                {searchResults.length === 0 && !searching && (
                  <p className="text-sm text-muted-foreground text-center py-3">
                    Ничего не найдено
                  </p>
                )}
                {searchResults.map((u) => {
                  const selected = coAuthorIds.includes(u.id);
                  const disabled = !selected && coAuthorIds.length >= 4;
                  return (
                    <button
                      key={u.id}
                      onClick={() => !disabled && toggleCoAuthor(u.id)}
                      disabled={disabled}
                      className={cn(
                        'w-full flex items-center gap-3 p-2 rounded-md border text-left transition',
                        selected
                          ? 'border-primary bg-primary/5'
                          : disabled
                            ? 'border-transparent opacity-50 cursor-not-allowed'
                            : 'border-transparent hover:bg-muted/50',
                      )}
                    >
                      <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="sm" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{u.name}</div>
                        {u.title && (
                          <div className="text-xs text-muted-foreground truncate">{u.title}</div>
                        )}
                      </div>
                      <TrustBadge ipScore={u.ipScore} level="basic" size="sm" />
                      {selected && <UserCheck className="w-4 h-4 text-primary" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
            Отмена
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!title.trim() || !content.trim() || submitting}
            className="gap-1.5"
          >
            {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
            Опубликовать
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
