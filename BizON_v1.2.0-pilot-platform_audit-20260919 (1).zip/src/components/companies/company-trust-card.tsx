'use client';

// BizON — CompanyTrustCard (Phase 2 — Company Trust)
// 4 прогресс-бара индексов доверия (employerTrust / businessTrust / deliveryTrust / transparency)
// + Overall score (крупным числом) + основание расчёта + кнопка «Почему?» → модалка.
import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import {
  ShieldCheck, Users, Briefcase, Truck, Eye, HelpCircle, Loader2,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface TrustBasis {
  culturalSignals: { avgRating: number; count: number };
  completedProjects: { count: number; avgRating: number; ratedCount: number };
  verified: { isVerified: boolean; publicSalaryJobs: number; totalActiveJobs: number };
}

interface TrustScore {
  employerTrust: number;
  businessTrust: number;
  deliveryTrust: number;
  transparency: number;
  overall: number;
  basis: TrustBasis;
}

interface CompanyTrustCardProps {
  companyId: string;
  initial?: Partial<TrustScore> | null;
}

interface IndexRow {
  key: keyof Pick<TrustScore, 'employerTrust' | 'businessTrust' | 'deliveryTrust' | 'transparency'>;
  label: string;
  hint: string;
  icon: React.ReactNode;
  color: string; // tailwind text color class for icon + value
  barClass: string; // tailwind bg-* for progress indicator
}

const INDEX_ROWS: IndexRow[] = [
  {
    key: 'employerTrust',
    label: 'Работодатель',
    hint: 'Рейтинг сотрудников (Cultural Signals)',
    icon: <Users className="w-3.5 h-3.5" />,
    color: 'text-emerald-700 dark:text-emerald-400',
    barClass: '[&>[data-slot=progress-indicator]]:bg-emerald-600',
  },
  {
    key: 'businessTrust',
    label: 'Бизнес',
    hint: 'Подтверждённые завершённые кейсы',
    icon: <Briefcase className="w-3.5 h-3.5" />,
    color: 'text-blue-700 dark:text-blue-400',
    barClass: '[&>[data-slot=progress-indicator]]:bg-blue-600',
  },
  {
    key: 'deliveryTrust',
    label: 'Доставка',
    hint: 'Качество сдачи проектов (rating > 0)',
    icon: <Truck className="w-3.5 h-3.5" />,
    color: 'text-violet-700 dark:text-violet-400',
    barClass: '[&>[data-slot=progress-indicator]]:bg-violet-600',
  },
  {
    key: 'transparency',
    label: 'Прозрачность',
    hint: 'Verified + публичные зарплаты',
    icon: <Eye className="w-3.5 h-3.5" />,
    color: 'text-amber-700 dark:text-amber-400',
    barClass: '[&>[data-slot=progress-indicator]]:bg-amber-500',
  },
];

function getOverallColor(v: number): string {
  if (v >= 70) return 'text-emerald-600 dark:text-emerald-400';
  if (v >= 50) return 'text-amber-600 dark:text-amber-400';
  if (v >= 30) return 'text-orange-600 dark:text-orange-400';
  return 'text-muted-foreground';
}

function getOverallLabel(v: number): string {
  if (v >= 70) return 'Высокое доверие';
  if (v >= 50) return 'Среднее доверие';
  if (v >= 30) return 'Низкое доверие';
  return 'Недостаточно данных';
}

export function CompanyTrustCard({ companyId, initial }: CompanyTrustCardProps) {
  const [score, setScore] = React.useState<TrustScore | null>(initial as TrustScore | null);
  const [loading, setLoading] = React.useState<boolean>(!initial);
  const [error, setError] = React.useState<string | null>(null);
  const [whyOpen, setWhyOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!companyId) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ trust: TrustScore }>(`/api/companies/${companyId}/trust`);
      setScore(res.trust);
    } catch (e: any) {
      setError(e.message ?? 'Ошибка загрузки доверия');
    } finally {
      setLoading(false);
    }
  }, [companyId]);

  React.useEffect(() => {
    if (!initial) load();
  }, [load, initial]);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-lighthouse" /> Доверие к компании
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-6 text-muted-foreground">
          <Loader2 className="w-4 h-4 animate-spin mr-2" /> Загрузка индексов…
        </CardContent>
      </Card>
    );
  }

  if (error || !score) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-lighthouse" /> Доверие к компании
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {error ?? 'Индексы доверия пока недоступны.'}
          </p>
          <Button variant="ghost" size="sm" className="mt-2" onClick={load}>Повторить</Button>
        </CardContent>
      </Card>
    );
  }

  const overall = Math.round(score.overall);
  const basis = score.basis;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center justify-between">
          <span className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-lighthouse" /> Доверие к компании
          </span>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs h-7 gap-1"
            onClick={() => setWhyOpen(true)}
          >
            <HelpCircle className="w-3.5 h-3.5" /> Почему?
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall score */}
        <div className="flex items-baseline justify-between gap-3">
          <div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Overall</div>
            <div className={cn('text-3xl font-bold tabular-nums leading-none', getOverallColor(overall))}>
              {overall}<span className="text-sm text-muted-foreground font-normal">/100</span>
            </div>
            <div className={cn('text-xs mt-0.5', getOverallColor(overall))}>{getOverallLabel(overall)}</div>
          </div>
          <div className="text-right text-xs text-muted-foreground">
            <div>Веса:</div>
            <div>35 / 25 / 25 / 15</div>
          </div>
        </div>

        {/* 4 progress bars */}
        <div className="space-y-2.5">
          {INDEX_ROWS.map((row) => {
            const v = Math.round(score[row.key] ?? 0);
            return (
              <div key={row.key}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="flex items-center gap-1.5 text-foreground/80">
                    <span className={row.color}>{row.icon}</span>
                    <span className="font-medium">{row.label}</span>
                  </span>
                  <span className={cn('tabular-nums font-semibold', row.color)}>{v}</span>
                </div>
                <Progress value={v} className={cn('h-1.5', row.barClass)} />
                <div className="text-xs text-muted-foreground mt-0.5">{row.hint}</div>
              </div>
            );
          })}
        </div>
      </CardContent>

      {/* === «Почему?» — модалка с основанием расчёта === */}
      <Dialog open={whyOpen} onOpenChange={setWhyOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-lighthouse" />
              Почему {overall}/100?
            </DialogTitle>
            <DialogDescription>
              Основание расчёта индексов доверия. Все баллы пересчитываются автоматически.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 text-sm">
            {/* Employer */}
            <div className="space-y-1">
              <div className="font-medium flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-emerald-600" /> Работодатель — {Math.round(score.employerTrust)}/100
              </div>
              <div className="text-xs text-muted-foreground pl-5">
                Cultural Signals (published, verified):{' '}
                <span className="font-medium text-foreground">{basis.culturalSignals.count}</span> отзыв(ов),
                средний рейтинг <span className="font-medium text-foreground">{basis.culturalSignals.avgRating}/5</span>.
                {' '}Штраф за малую выборку применяется при &lt;3 отзывах.
              </div>
            </div>

            {/* Business */}
            <div className="space-y-1">
              <div className="font-medium flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-blue-600" /> Бизнес — {Math.round(score.businessTrust)}/100
              </div>
              <div className="text-xs text-muted-foreground pl-5">
                Завершённых кейсов (Project COMPLETED):{' '}
                <span className="font-medium text-foreground">{basis.completedProjects.count}</span>.
                Нормализация <code className="text-xs">log1p</code> с насыщением на 20 кейсах (≈100 баллов).
              </div>
            </div>

            {/* Delivery */}
            <div className="space-y-1">
              <div className="font-medium flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-violet-600" /> Доставка — {Math.round(score.deliveryTrust)}/100
              </div>
              <div className="text-xs text-muted-foreground pl-5">
                Проектов с rating &gt; 0: <span className="font-medium text-foreground">{basis.completedProjects.ratedCount}</span>,
                средний rating <span className="font-medium text-foreground">{basis.completedProjects.avgRating}/5</span>.
                {' '}Штраф за малую выборку применяется при &lt;3 оценённых проектах.
              </div>
            </div>

            {/* Transparency */}
            <div className="space-y-1">
              <div className="font-medium flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-600" /> Прозрачность — {Math.round(score.transparency)}/100
              </div>
              <div className="text-xs text-muted-foreground pl-5 space-y-0.5">
                <div>
                  Verified (ИНН/ОГРН):{' '}
                  <span className={basis.verified.isVerified ? 'text-emerald-600 font-medium' : 'text-muted-foreground'}>
                    {basis.verified.isVerified ? '✓ да (+50)' : '✗ нет (+0)'}
                  </span>
                </div>
                <div>
                  Публичные зарплаты: <span className="font-medium text-foreground">{basis.verified.publicSalaryJobs}</span>
                  {' '}/ {basis.verified.totalActiveJobs} активных вакансий.
                  {' '}Доля × 50 (если есть вакансии).
                </div>
              </div>
            </div>

            <div className="pt-3 border-t text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Overall</span> = 0.35 × Работодатель + 0.25 × Бизнес + 0.25 × Доставка + 0.15 × Прозрачность.
              {' '}Пересчёт — через cron (recalculateAll) или автоматически при изменении данных.
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => setWhyOpen(false)}>Закрыть</Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
