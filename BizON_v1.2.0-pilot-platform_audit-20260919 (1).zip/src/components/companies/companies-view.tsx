// BizON — Companies View (список компаний: вид «Список»/«Таблица»)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from '@/components/ui/table';
import { toast } from '@/hooks/use-toast';
import {
  Building2, MapPin, Users, Briefcase, Star, Search, Plus, TrendingUp,
  List, Table as TableIcon, ExternalLink,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface CompanyListItem {
  id: string;
  name: string;
  description: string;
  logoUrl: string | null;
  coverUrl: string | null;
  industry: string | null;
  size: string | null;
  location: string | null;
  foundedYear: number | null;
  website: string | null;
  adTrustIndex: number;
  followersCount: number;
  employeesCount: number;
  activeJobsCount: number;
  reviewsCount: number;
  isFollowing: boolean;
}

export function CompaniesView() {
  const setView = useAppStore((s) => s.setView);
  const setSelectedCompanyId = useAppStore((s) => s.setSelectedCompanyId as any);
  const [companies, setCompanies] = React.useState<CompanyListItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState('');
  const [filterIndustry, setFilterIndustry] = React.useState<string | null>(null);
  // Вид отображения: сохраняем в localStorage (hydration после монтирования — без SSR-мисматча)
  const [viewMode, setViewMode] = React.useState<'list' | 'table'>('list');

  React.useEffect(() => {
    const saved = window.localStorage.getItem('bizon.companiesView');
    if (saved === 'table' || saved === 'list') setViewMode(saved);
  }, []);

  function changeViewMode(mode: 'list' | 'table') {
    setViewMode(mode);
    try { window.localStorage.setItem('bizon.companiesView', mode); } catch { /* приватный режим — не критично */ }
  }

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const q = search ? `&q=${encodeURIComponent(search)}` : '';
      const ind = filterIndustry ? `&industry=${encodeURIComponent(filterIndustry)}` : '';
      const res = await api<{ companies: CompanyListItem[] }>(`/api/companies?limit=30${q}${ind}`);
      setCompanies(res.companies);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [search, filterIndustry]);

  React.useEffect(() => { load(); }, [load]);

  const industries = Array.from(new Set(companies.map((c) => c.industry).filter(Boolean))) as string[];

  function openCompany(id: string) {
    if (setSelectedCompanyId) setSelectedCompanyId(id);
    setView('company');
  }

  async function handleFollow(e: React.MouseEvent, id: string) {
    e.stopPropagation();
    try {
      const res = await api(`/api/companies/${id}/follow`, { method: 'POST' });
      setCompanies((prev) => prev.map((c) => c.id === id ? {
        ...c,
        isFollowing: res.following,
        followersCount: res.followersCount,
      } : c));
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold">Компании</h1>
          <p className="text-sm text-muted-foreground">Откройте компанию — увидите команду, вакансии и отзывы</p>
        </div>
      </div>

      {/* Search + переключатель вида */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1 min-w-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Поиск по названию, описанию, отрасли..."
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-0.5 rounded-md border p-0.5 flex-shrink-0" role="group" aria-label="Вид отображения компаний">
          <button
            type="button"
            aria-pressed={viewMode === 'list'}
            aria-label="Вид: список"
            title="Список"
            onClick={() => changeViewMode('list')}
            className={cn(
              'inline-flex items-center justify-center w-8 h-8 rounded transition min-w-[32px]',
              viewMode === 'list' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
            )}
          >
            <List className="w-4 h-4" aria-hidden />
          </button>
          <button
            type="button"
            aria-pressed={viewMode === 'table'}
            aria-label="Вид: таблица"
            title="Таблица"
            onClick={() => changeViewMode('table')}
            className={cn(
              'inline-flex items-center justify-center w-8 h-8 rounded transition min-w-[32px]',
              viewMode === 'table' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
            )}
          >
            <TableIcon className="w-4 h-4" aria-hidden />
          </button>
        </div>
      </div>

      {/* Industry filter chips */}
      {industries.length > 0 && (
        <div className="flex gap-1.5 flex-wrap">
          <button
            onClick={() => setFilterIndustry(null)}
            className={cn(
              'px-3 py-1 text-xs rounded-full border transition',
              filterIndustry === null ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary'
            )}
          >
            Все
          </button>
          {industries.map((ind) => (
            <button
              key={ind}
              onClick={() => setFilterIndustry(ind)}
              className={cn(
                'px-3 py-1 text-xs rounded-full border transition',
                filterIndustry === ind ? 'bg-primary text-primary-foreground border-primary' : 'hover:border-primary'
              )}
            >
              {ind}
            </button>
          ))}
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 w-full rounded-xl" />)}
        </div>
      ) : companies.length === 0 ? (
        <Card className="p-8 text-center">
          <Building2 className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">Компаний не найдено</p>
        </Card>
      ) : viewMode === 'table' ? (
        <CompaniesTable companies={companies} onOpen={openCompany} />
      ) : (
        <div className="space-y-3">
          {companies.map((c) => (
            <CompanyCard key={c.id} company={c} onOpen={() => openCompany(c.id)} onFollow={(e) => handleFollow(e, c.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

/** Табличный вид компаний: лого, название, сайт, отрасль, размер, вакансии */
function CompaniesTable({ companies, onOpen }: {
  companies: CompanyListItem[];
  onOpen: (id: string) => void;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto scroll-area-thin">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[35%]">Компания</TableHead>
              <TableHead>Сайт</TableHead>
              <TableHead className="hidden md:table-cell">Отрасль</TableHead>
              <TableHead className="hidden sm:table-cell">Размер</TableHead>
              <TableHead className="text-right pr-4">Вакансии</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {companies.map((c) => (
              <TableRow
                key={c.id}
                onClick={() => onOpen(c.id)}
                className="cursor-pointer"
                aria-label={`Открыть компанию: ${c.name}`}
              >
                <TableCell>
                  <div className="flex items-center gap-2 min-w-0">
                    {c.logoUrl ? (
                      <img
                        src={c.logoUrl}
                        alt=""
                        className="w-7 h-7 rounded-md object-cover flex-shrink-0"
                        onError={(e) => { e.currentTarget.style.visibility = 'hidden'; }}
                      />
                    ) : (
                      <span
                        aria-hidden
                        className="w-7 h-7 rounded-md bg-primary/10 text-primary text-xs font-semibold flex items-center justify-center flex-shrink-0"
                      >
                        {c.name.charAt(0).toUpperCase()}
                      </span>
                    )}
                    <span className="text-sm font-medium truncate max-w-[180px]">{c.name}</span>
                  </div>
                </TableCell>
                <TableCell>
                  {c.website ? (
                    <a
                      href={c.website.startsWith('http') ? c.website : `https://${c.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="inline-flex items-center gap-1 text-xs text-lighthouse hover:underline max-w-[140px]"
                    >
                      <span className="truncate">{c.website.replace(/^https?:\/\//, '')}</span>
                      <ExternalLink className="w-3 h-3 flex-shrink-0" aria-hidden />
                      <span className="sr-only">— открыть в новой вкладке</span>
                    </a>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  <span className="text-xs text-muted-foreground block truncate max-w-[120px]">{c.industry ?? '—'}</span>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <span className="text-xs text-muted-foreground">{c.size ?? '—'}</span>
                </TableCell>
                <TableCell className="text-right pr-4">
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <Briefcase className="w-3 h-3" aria-hidden /> {c.activeJobsCount}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}

function CompanyCard({ company: c, onOpen, onFollow }: {
  company: CompanyListItem;
  onOpen: () => void;
  onFollow: (e: React.MouseEvent) => void;
}) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer" onClick={onOpen}>
      <div className="h-20 bg-gradient-to-r from-primary/15 to-lighthouse/15 relative">
        {c.coverUrl && (
          <img src={c.coverUrl} alt="" className="w-full h-full object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} />
        )}
      </div>
      <CardContent className="p-4 pt-0">
        <div className="flex items-start gap-3 -mt-8">
          <div className="w-16 h-16 rounded-xl bg-card border-4 border-card shadow-sm overflow-hidden flex-shrink-0">
            {c.logoUrl ? (
              <img src={c.logoUrl} alt={c.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-primary/10">
                <Building2 className="w-6 h-6 text-primary" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0 pt-8">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="font-semibold text-base truncate">{c.name}</h3>
                {c.industry && <Badge variant="secondary" className="text-xs">{c.industry}</Badge>}
              </div>
              <Button size="sm" variant={c.isFollowing ? 'outline' : 'default'} onClick={onFollow}>
                {c.isFollowing ? 'Вы подписаны' : 'Подписаться'}
              </Button>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mt-2">{c.description}</p>
            <div className="flex items-center gap-3 mt-3 text-xs text-muted-foreground flex-wrap">
              {c.location && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" /> {c.location}</span>}
              {c.size && <span className="flex items-center gap-0.5"><Users className="w-3 h-3" /> {c.size}</span>}
              <span className="flex items-center gap-0.5"><Briefcase className="w-3 h-3" /> {c.activeJobsCount} вакансий</span>
              <span className="flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> ATI {Math.round(c.adTrustIndex * 100)}</span>
              {c.reviewsCount > 0 && <span className="flex items-center gap-0.5"><Star className="w-3 h-3 fill-lighthouse text-lighthouse" /> {c.reviewsCount} отзывов</span>}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
