// BizON v6.2 — Company Intelligence panel «Интеллект компании» (doc_a §31/§33, Task 10-b)
// ============================================================================
// Секция на карточке компании (company-view.tsx) — ПУБЛИЧНАЯ аналитика компании,
// видна ВСЕМ просматривающим (individual и company/hr — это не приватные данные):
//   • таймлайн событий (news/job/review/cultural_signal/claim/placement/employee)
//   • сигналы доверия (4 индекса + claims + отзывы + культура)
//   • текущие потребности (открытые вакансии + топ навыков + кого нанимали)
//   • память компетенций (появляющиеся/исчезающие технологии, состав команды)
// Данные: GET /api/company/intelligence?companyId=... (Task 9-b, детерминированно).
// Свернуть/развернуть (Radix Collapsible). Честные empty states (dataNote из API);
// ошибка загрузки НЕ роняет страницу — локальная карточка с «Повторить».
// Дизайн: navy + teal; red не используется.
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import {
  BrainCircuit, ChevronDown, Newspaper, Briefcase, Star, HeartHandshake,
  ShieldCheck, UserCheck, Users, ShieldQuestion, RefreshCw,
  Sprout, Leaf, CircleDot, Info,
} from 'lucide-react';
import type { CompanyIntelligence, CompanyTimelineItem } from '@/lib/services/company-intelligence-service';
import { formatRelative } from '@/components/hr/intel-shared';

const TIMELINE_KINDS: Record<
  string,
  { icon: React.ReactNode; label: string }
> = {
  news: { icon: <Newspaper className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Новость' },
  job: { icon: <Briefcase className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Вакансия' },
  review: { icon: <Star className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Отзыв' },
  cultural_signal: { icon: <HeartHandshake className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Культура' },
  claim: { icon: <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Заявление' },
  placement: { icon: <UserCheck className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Трудоустройство' },
  employee: { icon: <Users className="w-3.5 h-3.5" aria-hidden="true" />, label: 'Сотрудник' },
};

export function CompanyIntelligencePanel({ companyId }: { companyId: string }) {
  const [data, setData] = React.useState<CompanyIntelligence | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [open, setOpen] = React.useState(true);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<CompanyIntelligence>(
        `/api/company/intelligence?companyId=${encodeURIComponent(companyId)}`,
      );
      setData(res);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Не удалось загрузить интеллект компании');
    } finally {
      setLoading(false);
    }
  }, [companyId]);

  React.useEffect(() => {
    void load();
  }, [load]);

  if (loading) {
    return (
      <Card aria-busy="true" aria-label="Загрузка интеллекта компании">
        <CardContent className="p-4 space-y-3">
          <Skeleton className="h-6 w-56" />
          <Skeleton className="h-16 w-full rounded-lg" />
          <Skeleton className="h-24 w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    return (
      <Card>
        <CardContent className="p-4">
          <p className="text-sm text-destructive" role="alert">{error ?? 'Данные недоступны'}</p>
          <Button variant="outline" size="sm" onClick={() => void load()} className="mt-2">
            <RefreshCw className="w-3.5 h-3.5 mr-1" aria-hidden="true" />
            Повторить
          </Button>
        </CardContent>
      </Card>
    );
  }

  // Публичная аналитика: показывается всем просматривающим карточку компании.
  // Все данные (открытые вакансии, отзывы, сотрудники) и так публичны —
  // гейтов по верификации/роли здесь нет; честность обеспечивают dataNote API.
  const fp = data.dataFootprint;

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <CardTitle className="flex items-center gap-2 text-base min-w-0">
              <BrainCircuit className="w-4 h-4 text-lighthouse flex-shrink-0" aria-hidden="true" />
              <span className="min-w-0">Интеллект компании</span>
              <Badge variant="outline" className="text-xs bg-lighthouse/10 text-lighthouse border-lighthouse/30 flex-shrink-0">
                память компании
              </Badge>
            </CardTitle>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" aria-expanded={open} aria-label={open ? 'Свернуть интеллект компании' : 'Развернуть интеллект компании'}>
                <ChevronDown className={cn('w-4 h-4 transition-transform', open && 'rotate-180')} aria-hidden="true" />
                {open ? 'Свернуть' : 'Развернуть'}
              </Button>
            </CollapsibleTrigger>
          </div>
        </CardHeader>

        <CollapsibleContent>
          <CardContent className="pt-0 space-y-4">
            {/* === Полнота данных (честная оценка) === */}
            <div className="flex flex-wrap gap-1.5" role="list" aria-label="Полнота данных">
              <FootprintChip label="сотрудников" value={fp.employeesCurrent} suffix="тек." />
              {fp.employeesFormer > 0 && <FootprintChip label="бывших" value={fp.employeesFormer} />}
              <FootprintChip label="отзывов" value={fp.reviews} />
              <FootprintChip label="сигналов культуры" value={fp.culturalSignals} />
              <FootprintChip label="заявлений" value={fp.claims} />
              <FootprintChip label="вакансий" value={fp.openJobs} />
              {fp.news > 0 && <FootprintChip label="новостей" value={fp.news} />}
              {fp.placements > 0 && <FootprintChip label="трудоустройств" value={fp.placements} />}
            </div>

            {/* === Сигналы доверия === */}
            <section aria-label="Сигналы доверия" className="space-y-2">
              <SectionTitle>Сигналы доверия</SectionTitle>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <TrustStat label="Работодатель" value={data.trustSignals.employerTrust} />
                <TrustStat label="Бизнес" value={data.trustSignals.businessTrust} />
                <TrustStat label="Сдача" value={data.trustSignals.deliveryTrust} />
                <TrustStat label="Прозрачность" value={data.trustSignals.transparency} />
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                <span>
                  Отзывы: <strong className="text-foreground/80">{data.trustSignals.reviews.count}</strong>
                  {data.trustSignals.reviews.avgRating !== null && ` · средняя ${data.trustSignals.reviews.avgRating}/5`}
                </span>
                {data.trustSignals.claims.total > 0 && (
                  <span>
                    Заявления: <strong className="text-foreground/80">{data.trustSignals.claims.verified}</strong> из {data.trustSignals.claims.total} подтверждено
                  </span>
                )}
                {data.trustSignals.culture.signals > 0 && (
                  <span>
                    Культурные сигналы: <strong className="text-foreground/80">{data.trustSignals.culture.signals}</strong>
                    {data.trustSignals.culture.avgRating !== null && ` · средняя ${data.trustSignals.culture.avgRating}/5`}
                  </span>
                )}
              </div>
              {data.trustSignals.claims.items.length > 0 && (
                <ul className="space-y-1 max-h-32 overflow-y-auto scroll-area-thin pr-1" aria-label="Заявления компании">
                  {data.trustSignals.claims.items.slice(0, 5).map((c) => (
                    <li key={c.id} className="flex items-start gap-1.5 text-xs p-1.5 rounded bg-muted/40">
                      {c.status === 'verified' ? (
                        <ShieldCheck className="w-3.5 h-3.5 text-success-text flex-shrink-0 mt-0.5" aria-hidden="true" />
                      ) : (
                        <ShieldQuestion className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-0.5" aria-hidden="true" />
                      )}
                      <span>
                        {c.claimText}
                        <span className="text-muted-foreground"> — {c.status === 'verified' ? 'подтверждено' : c.status === 'disputed' ? 'оспорено' : c.status === 'rejected' ? 'отклонено' : 'ожидает проверки'}</span>
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                <Info className="w-3 h-3 flex-shrink-0 mt-0.5" aria-hidden="true" />
                {data.trustSignals.dataNote}
              </p>
            </section>

            {/* === Текущие потребности === */}
            <section aria-label="Текущие потребности" className="space-y-2">
              <SectionTitle>Текущие потребности</SectionTitle>
              {data.currentNeeds.topSkills.length > 0 && (
                <div className="flex flex-wrap gap-1.5" role="list" aria-label="Топ навыков из открытых вакансий">
                  {data.currentNeeds.topSkills.map((t) => (
                    <Badge key={t.skill} variant="outline" className="text-xs bg-lighthouse/10 text-lighthouse border-lighthouse/30 gap-1">
                      {t.skill}
                      <span className="tabular-nums opacity-70">×{t.jobsCount}</span>
                    </Badge>
                  ))}
                </div>
              )}
              {data.currentNeeds.openJobs.length > 0 ? (
                <ul className="space-y-1.5 max-h-40 overflow-y-auto scroll-area-thin pr-1" aria-label="Открытые вакансии">
                  {data.currentNeeds.openJobs.slice(0, 8).map((j) => (
                    <li key={j.id} className="p-2 rounded-lg border text-xs space-y-1">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="font-medium truncate min-w-0">{j.title}</span>
                        <span className="text-muted-foreground flex-shrink-0 flex items-center gap-1.5 flex-wrap">
                          {j.level && <span>{j.level}</span>}
                          {j.location && <span>· {j.location}</span>}
                        </span>
                      </div>
                      {j.requiredSkills.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {j.requiredSkills.slice(0, 5).map((s) => (
                            <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
                          ))}
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                data.currentNeeds.hiredRoles.length > 0 && (
                  <div className="flex flex-wrap gap-1.5" aria-label="Кого нанимали раньше">
                    {data.currentNeeds.hiredRoles.slice(0, 5).map((h) => (
                      <Badge key={h.role} variant="secondary" className="text-xs gap-1">
                        {h.role} <span className="tabular-nums opacity-70">×{h.count}</span>
                      </Badge>
                    ))}
                  </div>
                )
              )}
              <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                <Info className="w-3 h-3 flex-shrink-0 mt-0.5" aria-hidden="true" />
                {data.currentNeeds.dataNote}
              </p>
            </section>

            {/* === Память компетенций === */}
            {(data.competencyMemory.skillsAppearing.length > 0 || data.competencyMemory.skillsDisappearing.length > 0 || data.competencyMemory.employeePositions.length > 0) && (
              <section aria-label="Память компетенций" className="space-y-2">
                <SectionTitle>Память компетенций</SectionTitle>
                {data.competencyMemory.skillsAppearing.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 items-center" role="list">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Sprout className="w-3 h-3 text-success-text" aria-hidden="true" /> появляются:
                    </span>
                    {data.competencyMemory.skillsAppearing.slice(0, 8).map((s) => (
                      <Badge key={s} variant="outline" className="text-xs bg-success/10 text-success-text border-success/30">{s}</Badge>
                    ))}
                  </div>
                )}
                {data.competencyMemory.skillsDisappearing.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 items-center" role="list">
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Leaf className="w-3 h-3 text-muted-foreground" aria-hidden="true" /> исчезают:
                    </span>
                    {data.competencyMemory.skillsDisappearing.slice(0, 8).map((s) => (
                      <Badge key={s} variant="outline" className="text-xs text-muted-foreground border-dashed">{s}</Badge>
                    ))}
                  </div>
                )}
                {data.competencyMemory.employeePositions.length > 0 && (
                  <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                    {data.competencyMemory.employeePositions.slice(0, 5).map((p) => (
                      <span key={p.position}>
                        {p.position}: <strong className="text-foreground/70 tabular-nums">{p.count}</strong>
                      </span>
                    ))}
                  </div>
                )}
                <p className="text-xs text-muted-foreground">{data.competencyMemory.dataNote}</p>
              </section>
            )}

            {/* === Таймлайн === */}
            <section aria-label="Таймлайн событий компании" className="space-y-2">
              <SectionTitle>Таймлайн событий</SectionTitle>
              {data.timeline.items.length === 0 ? (
                <p className="text-xs text-muted-foreground p-2">{data.timeline.dataNote}</p>
              ) : (
                <ol className="space-y-1.5 max-h-96 overflow-y-auto scroll-area-thin pr-1" aria-label="События компании">
                  {data.timeline.items.map((item, i) => (
                    <TimelineRow key={`${item.kind}-${item.at}-${i}`} item={item} />
                  ))}
                </ol>
              )}
              {data.timeline.items.length > 0 && (
                <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                  <CircleDot className="w-3 h-3 flex-shrink-0 mt-0.5" aria-hidden="true" />
                  {data.timeline.dataNote}
                </p>
              )}
            </section>

            <p className="text-xs text-muted-foreground">
              Срез собран детерминированно из данных платформы · {new Date(data.generatedAt).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
            </p>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}

// ============================================================================
// === Вспомогательные ===
// ============================================================================

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{children}</h4>
  );
}

function FootprintChip({ label, value, suffix }: { label: string; value: number; suffix?: string }) {
  return (
    <Badge variant="secondary" className="text-xs gap-1">
      <span className="tabular-nums font-semibold">{value}</span>
      {label}
      {suffix ? ` ${suffix}` : ''}
    </Badge>
  );
}

function TrustStat({ label, value }: { label: string; value: number }) {
  const v = Math.round(value);
  return (
    <div className="p-2.5 rounded-lg border bg-muted/20">
      <div className={cn('text-base font-bold tabular-nums', v >= 70 ? 'text-success-text' : v >= 30 ? 'text-lighthouse' : 'text-muted-foreground')}>
        {v}
      </div>
      <div className="text-xs text-muted-foreground leading-tight">{label}</div>
    </div>
  );
}

function TimelineRow({ item }: { item: CompanyTimelineItem }) {
  const kind = TIMELINE_KINDS[item.kind] ?? TIMELINE_KINDS.news;
  return (
    <li className="flex items-start gap-2.5 p-2 rounded-lg border bg-card hover:bg-accent/30 transition">
      <div className="w-7 h-7 rounded-full bg-lighthouse/10 text-lighthouse flex items-center justify-center flex-shrink-0">
        {kind.icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-medium leading-snug">{item.title}</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap text-xs text-muted-foreground mt-0.5">
          <span>{kind.label}</span>
          <span>·</span>
          <span>{formatRelative(item.at)}</span>
          {item.detail && (
            <>
              <span>·</span>
              <span className="truncate max-w-[16rem]">{item.detail}</span>
            </>
          )}
        </div>
      </div>
    </li>
  );
}

