// BizON — Company Hub View (по образцу Xing Company Page)
// Единая страница: cover → stats → about → employees → jobs → reviews → events → similar
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { CompanyStreamTab, CompanyWorkforceTab } from './company-stream-tab';
import { CompanyIntelligencePanel } from './company-intelligence-panel';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { toast } from '@/hooks/use-toast';
import {
  Building2, MapPin, Users, Briefcase, Star, TrendingUp, Globe, Calendar,
  ChevronLeft, ChevronRight, CheckCircle2, ExternalLink, Plus, Loader2,
  Newspaper, LayoutGrid, History, ShieldCheck,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface CompanyDetail {
  id: string;
  name: string;
  description: string;
  logoUrl: string | null;
  coverUrl: string | null;
  website: string | null;
  industry: string | null;
  size: string | null;
  location: string | null;
  foundedYear: number | null;
  adTrustIndex: number;
  followersCount: number;
  employeesCount: number;
  activeJobsCount: number;
  reviewsCount: number;
  avgRating: number;
  isFollowing: boolean;
  employees: Array<any>;
  reviews: Array<any>;
  jobs: Array<any>;
  events: Array<any>;
  similarCompanies: Array<any>;
}

export function CompanyView() {
  const companyId = useAppStore((s) => (s as any).selectedCompanyId);
  const setView = useAppStore((s) => s.setView);
  const setProfileUserId = useAppStore((s) => s.setProfileUserId);
  const [data, setData] = React.useState<CompanyDetail | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [reviewOpen, setReviewOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    if (!companyId) return;
    setLoading(true);
    try {
      const res = await api<{ company: CompanyDetail }>(`/api/companies/${companyId}`);
      setData(res.company);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [companyId]);

  React.useEffect(() => { load(); }, [load]);

  async function handleFollow() {
    if (!data) return;
    try {
      const res = await api(`/api/companies/${data.id}/follow`, { method: 'POST' });
      setData((prev) => prev ? { ...prev, isFollowing: res.following, followersCount: res.followersCount } : prev);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-20 w-full rounded-xl" />
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
    );
  }

  const c = data;

  return (
    <div className="space-y-4">
      <Button variant="ghost" size="sm" onClick={() => setView('companies')}>
        <ChevronLeft className="w-4 h-4 mr-1" /> Все компании
      </Button>

      {/* Hero with cover + logo */}
      <Card className="overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-primary/20 to-lighthouse/20 relative">
          {c.coverUrl && (
            <img src={c.coverUrl} alt="" className="w-full h-full object-cover" onError={(e) => (e.currentTarget.style.display = 'none')} />
          )}
        </div>
        <CardContent className="p-4 pt-0">
          <div className="flex items-start gap-4 -mt-12">
            <div className="w-20 h-20 rounded-2xl bg-card border-4 border-card shadow-md overflow-hidden flex-shrink-0">
              {c.logoUrl ? (
                <img src={c.logoUrl} alt={c.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-primary/10">
                  <Building2 className="w-8 h-8 text-primary" />
                </div>
              )}
            </div>
            <div className="flex-1 pt-12 min-w-0">
              <div className="flex items-start justify-between gap-2 flex-wrap">
                <div className="min-w-0">
                  <h1 className="text-2xl font-bold truncate">{c.name}</h1>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    {c.industry && <Badge variant="secondary">{c.industry}</Badge>}
                    {c.size && <Badge variant="outline">{c.size}</Badge>}
                    {c.avgRating > 0 && (
                      <span className="flex items-center gap-1 text-sm">
                        <Star className="w-4 h-4 fill-lighthouse text-lighthouse" />
                        <span className="font-semibold">{c.avgRating.toFixed(1)}</span>
                        <span className="text-muted-foreground">({c.reviewsCount})</span>
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  {c.website && (
                    <Button variant="outline" size="sm" asChild>
                      <a href={c.website} target="_blank" rel="noopener noreferrer">
                        <Globe className="w-4 h-4 mr-1" /> Сайт
                      </a>
                    </Button>
                  )}
                  <Button size="sm" variant={c.isFollowing ? 'outline' : 'default'} onClick={handleFollow}>
                    {c.isFollowing ? 'Вы подписаны' : 'Подписаться'}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Stats bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t">
            <Stat icon={<Users className="w-4 h-4" />} label="Подписчики" value={c.followersCount} />
            <Stat icon={<Building2 className="w-4 h-4" />} label="Сотрудников" value={c.employeesCount} />
            <Stat icon={<Briefcase className="w-4 h-4" />} label="Вакансии" value={c.activeJobsCount} />
            <Stat icon={<TrendingUp className="w-4 h-4" />} label="ATI" value={Math.round(c.adTrustIndex * 100)} />
          </div>

          {/* About */}
          <div className="mt-4 pt-4 border-t">
            <div className="flex items-center gap-3 text-sm text-muted-foreground mb-2 flex-wrap">
              {c.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {c.location}</span>}
              {c.foundedYear && <span>с {c.foundedYear} года</span>}
            </div>
            <p className="text-sm text-foreground/80 leading-relaxed">{c.description}</p>
          </div>
        </CardContent>
      </Card>

      {/* ===== Company Intelligence (doc_a §31/§33, Task 10-b) — память компании:
          таймлайн, сигналы доверия, текущие потребности. Публичная аналитика:
          показывается всем просматривающим; ошибки не роняют страницу. ===== */}
      <CompanyIntelligencePanel companyId={c.id} />

      {/* ===== TABS: Обзор / Лента компании (doc_a §E1) / Аналитика персонала (doc_a §E2) =====
          4-g: stream/claims/workforce/forecast backend существовал, но UI его не потреблял.
          Скрытые табы Radix не монтируются — stream грузится при монтировании таба. */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="w-full sm:w-auto flex-wrap h-auto">
          <TabsTrigger value="overview">
            <LayoutGrid className="w-3.5 h-3.5" /> Обзор
          </TabsTrigger>
          <TabsTrigger value="stream">
            <Newspaper className="w-3.5 h-3.5" /> Лента компании
          </TabsTrigger>
          <TabsTrigger value="workforce">
            <TrendingUp className="w-3.5 h-3.5" /> Аналитика персонала
          </TabsTrigger>
          <TabsTrigger value="memory">
            <History className="w-3.5 h-3.5" /> Память
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4 space-y-4">
      {/* Employees carousel (Xing-style horizontal scroller) */}
      {c.employees.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between text-base">
              <span className="flex items-center gap-2"><Users className="w-4 h-4 text-lighthouse" /> Команда ({c.employeesCount})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <HorizontalScroll>
              {c.employees.map((e: any) => (
                <button
                  key={e.id}
                  onClick={() => setProfileUserId(e.id)}
                  className="flex-shrink-0 w-32 p-3 rounded-lg border hover:border-primary hover:shadow-sm transition text-center"
                >
                  <UserAvatar name={e.name} avatarUrl={e.avatarUrl} size="lg" className="mx-auto" />
                  <div className="text-sm font-medium mt-2 truncate">{e.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{e.position}</div>
                  <TrustBadge ipScore={e.ipScore} level={e.level} size="sm" className="mt-1" />
                </button>
              ))}
            </HorizontalScroll>
          </CardContent>
        </Card>
      )}

      {/* Active jobs */}
      {c.jobs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Briefcase className="w-4 h-4 text-lighthouse" /> Активные вакансии ({c.activeJobsCount})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {c.jobs.map((j: any) => (
              <div key={j.id} className="p-3 rounded-lg border hover:border-primary transition cursor-pointer" onClick={() => setView('jobs')}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-medium text-sm">{j.title}</div>
                    <div className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{j.description}</div>
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                      {j.requiredSkills.slice(0, 3).map((s: string) => (
                        <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
                      ))}
                    </div>
                  </div>
                  {j.salaryFrom && j.salaryTo && (
                    <div className="text-xs text-right whitespace-nowrap">
                      <div className="font-medium">{j.salaryFrom.toLocaleString('ru-RU')}–{j.salaryTo.toLocaleString('ru-RU')} ₽</div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Reviews */}
      {c.reviews.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <Star className="w-4 h-4 text-lighthouse" /> Отзывы ({c.reviewsCount})
              </CardTitle>
              <Button size="sm" variant="outline" onClick={() => setReviewOpen(true)}>
                <Plus className="w-4 h-4 mr-1" /> Оставить отзыв
              </Button>
            </div>
            {c.avgRating > 0 && (
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-bold">{c.avgRating.toFixed(1)}</span>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className={cn('w-4 h-4', star <= Math.round(c.avgRating) ? 'fill-lighthouse text-lighthouse' : 'text-muted-foreground')} />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">из {c.reviewsCount} отзывов</span>
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-3">
            {c.reviews.map((r: any) => (
              <ReviewCard key={r.id} review={r} onUserClick={setProfileUserId} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Upcoming events */}
      {c.events.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Calendar className="w-4 h-4 text-lighthouse" /> Мероприятия компании
            </CardTitle>
          </CardHeader>
          <CardContent>
            <HorizontalScroll>
              {c.events.map((e: any) => (
                <div key={e.id} className="flex-shrink-0 w-64 rounded-lg border overflow-hidden hover:border-primary transition cursor-pointer" onClick={() => setView('events')}>
                  {e.imageUrl && (
                    <div className="h-24 bg-muted">
                      <img src={e.imageUrl} alt="" className="w-full h-full object-cover" onError={(ev) => (ev.currentTarget.parentElement!.style.display = 'none')} />
                    </div>
                  )}
                  <div className="p-2">
                    <div className="text-xs text-lighthouse font-medium">{formatEventDate(e.startDate)}</div>
                    <div className="text-sm font-medium line-clamp-2">{e.title}</div>
                    <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                      <Badge variant="outline" className="text-xs">{e.format}</Badge>
                    </div>
                  </div>
                </div>
              ))}
            </HorizontalScroll>
          </CardContent>
        </Card>
      )}

      {/* Similar companies (Xing-style recommendations) */}
      {c.similarCompanies.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Похожие компании</CardTitle>
          </CardHeader>
          <CardContent>
            <HorizontalScroll>
              {c.similarCompanies.map((sc: any) => (
                <button
                  key={sc.id}
                  onClick={() => {
                    (useAppStore.getState() as any).setSelectedCompanyId?.(sc.id);
                    setView('company');
                    setTimeout(() => load(), 100);
                  }}
                  className="flex-shrink-0 w-48 p-3 rounded-lg border hover:border-primary transition text-left flex items-center gap-2"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 overflow-hidden flex-shrink-0">
                    {sc.logoUrl ? (
                      <img src={sc.logoUrl} alt="" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center"><Building2 className="w-4 h-4 text-primary" /></div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{sc.name}</div>
                    <div className="text-xs text-muted-foreground">{sc.employeesCount} сотр.</div>
                  </div>
                </button>
              ))}
            </HorizontalScroll>
          </CardContent>
        </Card>
      )}
        </TabsContent>

        {/* Лента компании — 5 типов карточек из /api/companies/[id]/stream */}
        <TabsContent value="stream" className="mt-4">
          <CompanyStreamTab companyId={c.id} />
        </TabsContent>

        {/* Аналитика персонала — Workforce Gap + Talent Forecast */}
        <TabsContent value="workforce" className="mt-4">
          <CompanyWorkforceTab
            companyId={c.id}
            defaultRole={c.jobs[0]?.title}
            defaultSkills={Array.isArray(c.jobs[0]?.requiredSkills) ? (c.jobs[0].requiredSkills as string[]) : []}
          />
        </TabsContent>

        <TabsContent value="memory" className="mt-4">
          <CompanyMemoryTab companyId={c.id} />
        </TabsContent>
      </Tabs>

      {/* Review dialog */}
      <ReviewDialog
        open={reviewOpen}
        onClose={() => setReviewOpen(false)}
        companyId={c.id}
        onSubmitted={() => { setReviewOpen(false); load(); }}
      />
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="text-lighthouse">{icon}</div>
      <div>
        <div className="text-base font-bold">{value.toLocaleString('ru-RU')}</div>
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}

function ReviewCard({ review: r, onUserClick }: { review: any; onUserClick: (id: string) => void }) {
  return (
    <div className="p-3 rounded-lg border bg-muted/30">
      <div className="flex items-start gap-3">
        <button onClick={() => onUserClick(r.author.id)}>
          <UserAvatar name={r.author.name} avatarUrl={r.author.avatarUrl} size="sm" />
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={() => onUserClick(r.author.id)} className="text-sm font-medium hover:underline">{r.author.name}</button>
            {r.verifiedEmployee && (
              <Badge variant="outline" className="text-xs gap-1 border-lighthouse/40 text-lighthouse">
                <CheckCircle2 className="w-3 h-3" /> Сотрудник
              </Badge>
            )}
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className={cn('w-3 h-3', star <= r.rating ? 'fill-lighthouse text-lighthouse' : 'text-muted-foreground')} />
              ))}
            </div>
            <span className="text-xs text-muted-foreground ml-auto">{formatRelative(r.createdAt)}</span>
          </div>
          <div className="text-sm font-medium mt-1">{r.title}</div>
          {r.pros && <div className="text-xs mt-1"><span className="text-lighthouse font-medium">Плюсы:</span> {r.pros}</div>}
          {r.cons && <div className="text-xs mt-0.5"><span className="text-destructive font-medium">Минусы:</span> {r.cons}</div>}
        </div>
      </div>
    </div>
  );
}

function ReviewDialog({ open, onClose, companyId, onSubmitted }: {
  open: boolean;
  onClose: () => void;
  companyId: string;
  onSubmitted: () => void;
}) {
  const [rating, setRating] = React.useState(5);
  const [title, setTitle] = React.useState('');
  const [pros, setPros] = React.useState('');
  const [cons, setCons] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  async function handleSubmit() {
    if (!title.trim()) return;
    setLoading(true);
    try {
      await api(`/api/companies/${companyId}/reviews`, {
        method: 'POST',
        body: JSON.stringify({ rating, title, pros, cons }),
      });
      toast({ title: 'Отзыв добавлен' });
      setTitle(''); setPros(''); setCons(''); setRating(5);
      onSubmitted();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Оставить отзыв о компании</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Оценка</Label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button key={star} onClick={() => setRating(star)} className="p-1">
                  <Star className={cn('w-6 h-6 transition', star <= rating ? 'fill-lighthouse text-lighthouse' : 'text-muted-foreground')} />
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="r-title">Заголовок</Label>
            <Input id="r-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Краткая суть отзыва" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="r-pros">Плюсы</Label>
            <Textarea id="r-pros" rows={2} value={pros} onChange={(e) => setPros(e.target.value)} placeholder="Что понравилось..." />
          </div>
          <div className="space-y-1">
            <Label htmlFor="r-cons">Минусы</Label>
            <Textarea id="r-cons" rows={2} value={cons} onChange={(e) => setCons(e.target.value)} placeholder="Что можно улучшить..." />
          </div>
          <Button onClick={handleSubmit} disabled={loading || !title.trim()} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Опубликовать отзыв'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function HorizontalScroll({ children }: { children: React.ReactNode }) {
  const scrollRef = React.useRef<HTMLDivElement>(null);
  function scroll(dir: 'left' | 'right') {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === 'right' ? 240 : -240, behavior: 'smooth' });
    }
  }
  return (
    <div className="relative">
      <div ref={scrollRef} className="flex gap-2 overflow-x-auto scroll-area-thin pb-2">
        {children}
      </div>
      <button
        onClick={() => scroll('left')}
        className="absolute left-0 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-card border shadow-md flex items-center justify-center hover:bg-muted transition"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>
      <button
        onClick={() => scroll('right')}
        className="absolute right-0 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-card border shadow-md flex items-center justify-center hover:bg-muted transition"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}

function formatEventDate(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diff = d.getTime() - now.getTime();
  const days = Math.floor(diff / (24 * 60 * 60 * 1000));
  if (days === 0) return 'Сегодня';
  if (days === 1) return 'Завтра';
  if (days < 7) return `Через ${days} дн.`;
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

function formatRelative(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (minutes < 60) return `${minutes} мин назад`;
  if (hours < 24) return `${hours} ч назад`;
  if (days < 7) return `${days} дн назад`;
  return new Date(iso).toLocaleDateString('ru-RU');
}

// === Wave 4 (S-094): «Память компании» — верифицированные проекты + участники.
// §3.3: только факты (VERIFIED-проекты, люди, периоды), без рейтингов.
function CompanyMemoryTab({ companyId }: { companyId: string }) {
  const [data, setData] = React.useState<{
    company: { id: string; name: string };
    verifiedProjectsCount: number;
    uniqueParticipantsCount: number;
    projects: Array<{
      id: string; title: string; outcome: string | null; completedAt: string | null;
      members: Array<{ userId: string; name: string; participantRole: string | null }>;
    }>;
  } | null>(null);
  const [loading, setLoading] = React.useState(true);
  const setProfileUserId = useAppStore((s) => (s as any).setProfileUserId);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api<typeof data>(`/api/companies/${companyId}/memory`)
      .then((d) => { if (!cancelled) setData(d); })
      .catch(() => undefined)
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [companyId]);

  if (loading) return <Skeleton className="h-40 w-full rounded-xl" />;
  if (!data) return <p className="text-sm text-muted-foreground">Память компании недоступна.</p>;

  return (
    <div className="space-y-3">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <History className="w-4 h-4 text-lighthouse" /> Память компании
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-4 text-sm">
            <span className="flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-lighthouse" /> Верифицированных проектов: <b>{data.verifiedProjectsCount}</b></span>
            <span className="flex items-center gap-1"><Users className="w-4 h-4 text-lighthouse" /> Уникальных участников: <b>{data.uniqueParticipantsCount}</b></span>
          </div>
          {data.projects.length === 0 && (
            <p className="text-xs text-muted-foreground">Пока нет проектов, подтверждённых этой компанией как заказчиком.</p>
          )}
          {data.projects.map((p) => (
            <div key={p.id} className="p-3 rounded-lg border space-y-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium">{p.title}</span>
                {p.completedAt && <span className="text-xs text-muted-foreground">{new Date(p.completedAt).toLocaleDateString('ru-RU')}</span>}
              </div>
              {p.outcome && <p className="text-xs text-muted-foreground">{p.outcome}</p>}
              {p.members.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {p.members.slice(0, 8).map((m) => (
                    <button key={m.userId} onClick={() => setProfileUserId?.(m.userId)}
                      className="text-xs px-2 py-0.5 rounded-full border hover:bg-accent transition">
                      {m.name}{m.participantRole ? ` · ${m.participantRole}` : ''}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
