// BizON — Company Dashboard (интерфейс для юр.лиц и HR-агентств)
// Вид: вакансии компании + кандидаты на каждую + лимиты
'use client';
import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge } from '@/components/common/trust-badge';
import { InfoBanner } from '@/components/common/info-banner';
import { toast } from '@/hooks/use-toast';
import { Briefcase, Plus, Users, Loader2, Crown, TrendingUp, Eye, Check, X, Building2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { BuildTalentPanel } from '@/components/hr/build-talent-panel';
import { TeamBuilderPanel } from '@/components/hr/team-builder-panel';
import { WorkforceGatesPanel } from '@/components/hr/workforce-gates-panel';

interface CompanyJob {
  id: string; title: string; description: string; requiredSkills: string[];
  salaryFrom: number | null; salaryTo: number | null; location: string | null;
  growthScore: number; active: boolean; createdAt: string;
  applicationsCount: number;
  candidates: Array<{
    id: string; status: string; matchConfidence: number; appliedAt: string;
    user: { id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number; level: string; location: string | null };
  }>;
}
interface Limits { max: number | string; used: number; remaining: number | string; canPostMore: boolean; tier: string; }

export function CompanyDashboard() {
  const { user, setProfileUserId, setView } = useAppStore();
  const [jobs, setJobs] = React.useState<CompanyJob[]>([]);
  const [limits, setLimits] = React.useState<Limits | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [createOpen, setCreateOpen] = React.useState(false);
  const [expandedJob, setExpandedJob] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<{ jobs: CompanyJob[]; limits: Limits }>('/api/jobs');
      setJobs(res.jobs);
      setLimits(res.limits);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally { setLoading(false); }
  }, []);

  React.useEffect(() => { load(); }, [load]);

  if (loading) return <Skeleton className="h-96 w-full rounded-xl" />;

  const isHR = user?.accountType === 'hr_agency';
  const title = isHR ? 'Панель HR-агентства' : 'Панель компании';

  return (
    <div className="space-y-4">
      <InfoBanner
        icon={<Building2 className="w-4 h-4 text-white" />}
        title={title}
        description={isHR
          ? 'Управляйте вакансиями клиентов, подбирайте кандидатов через AI. Бесплатно — 1 вакансия. Pro — безлимит вакансий и регионов.'
          : 'Публикуйте вакансии, находите кандидатов через AI-подбор. Бесплатно — 1 вакансия. Business — безлимит вакансий и регионов.'}
        tip="Принцип «шведский стол»: на платном тарифе всё включено — безлимит вакансий, безлимит регионов, AI-рекрутинг, аналитика."
        dismissible
        storageKey="bizon_info_company"
      />

      {/* Limits banner */}
      {limits && (
        <Card className={cn('border-2', limits.canPostMore ? 'border-lighthouse/30' : 'border-destructive/30')}>
          <CardContent className="p-4 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{limits.used}</div>
                <div className="text-xs text-muted-foreground">вакансий</div>
              </div>
              <div className="text-muted-foreground">/</div>
              <div className="text-center">
                <div className="text-2xl font-bold">{limits.max === 'unlimited' ? '∞' : limits.max}</div>
                <div className="text-xs text-muted-foreground">{limits.max === 'unlimited' ? 'безлимит' : 'лимит'}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {limits.tier === 'free' ? (
                <Button size="sm" onClick={() => setView('subscription')}>
                  <Crown className="w-4 h-4 mr-1" /> Перейти на {isHR ? 'Pro' : 'Business'} — безлимит
                </Button>
              ) : (
                <Badge className="bg-success text-success-foreground gap-1">
                  <Check className="w-3 h-3" /> {limits.tier === 'pro' ? 'Pro' : 'Business'} — всё включено
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Create vacancy button */}
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">Вакансии ({jobs.length})</h2>
        <Button size="sm" onClick={() => setCreateOpen(true)} disabled={!limits?.canPostMore}>
          <Plus className="w-4 h-4 mr-1" /> Создать вакансию
        </Button>
      </div>

      {/* Jobs list with candidates */}
      {jobs.length === 0 ? (
        <Card className="p-8 text-center">
          <Briefcase className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">Вакансий пока нет. Создайте первую!</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {jobs.map(job => (
            <Card key={job.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <h3 className="font-semibold text-base">{job.title}</h3>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant={job.active ? 'default' : 'secondary'} className="text-xs">{job.active ? 'Активна' : 'Закрыта'}</Badge>
                      <span className="flex items-center gap-0.5 text-xs text-muted-foreground"><Users className="w-3 h-3" /> {job.applicationsCount} кандидатов</span>
                      {job.salaryFrom && job.salaryTo && <span className="text-xs text-muted-foreground">{job.salaryFrom.toLocaleString('ru-RU')}–{job.salaryTo.toLocaleString('ru-RU')} ₽</span>}
                    </div>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => setExpandedJob(expandedJob === job.id ? null : job.id)}>
                    {expandedJob === job.id ? 'Скрыть' : 'Кандидаты'}
                  </Button>
                </div>

                <p className="text-sm text-muted-foreground line-clamp-2">{job.description}</p>

                {job.requiredSkills.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {job.requiredSkills.map(s => <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>)}
                  </div>
                )}

                {/* Candidates */}
                {expandedJob === job.id && (
                  <div className="mt-4 pt-4 border-t soft-fade-in">
                    <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Кандидаты ({job.candidates.length})</div>
                    {job.candidates.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Пока нет откликов</p>
                    ) : (
                      <div className="space-y-2">
                        {job.candidates.map(c => (
                          <div key={c.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition">
                            <button onClick={() => setProfileUserId(c.user.id)}><UserAvatar name={c.user.name} avatarUrl={c.user.avatarUrl} size="sm" /></button>
                            <button onClick={() => setProfileUserId(c.user.id)} className="flex-1 min-w-0 text-left">
                              <div className="text-sm font-medium truncate">{c.user.name}</div>
                              <div className="text-xs text-muted-foreground truncate">{c.user.title ?? '—'} · {c.user.location ?? ''}</div>
                            </button>
                            <Badge variant="outline" className={cn('text-xs', c.matchConfidence >= 0.7 ? 'text-success' : '')}>
                              {Math.round(c.matchConfidence * 100)}% match
                            </Badge>
                            <TrustBadge ipScore={c.user.ipScore} level={c.user.level} size="sm" />
                            <Badge variant="secondary" className="text-xs">{statusLabel(c.status)}</Badge>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ===== Intelligence-панели HR (doc_a §34/§35/§36, Task 10-b):
          Build Talent + Team Builder + Workforce. Видны только company/hr
          сессиям (внутри панелей guard, individual → скрыто). ===== */}
      <section aria-label="Intelligence: поиск кандидатов, сборка команды, ворота найма" className="space-y-4">
        <div className="flex items-center gap-2 pt-2">
          <TrendingUp className="w-4 h-4 text-lighthouse" aria-hidden="true" />
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Intelligence</h3>
          <div className="flex-1 border-t" aria-hidden="true" />
        </div>
        <BuildTalentPanel />
        <TeamBuilderPanel />
        <WorkforceGatesPanel />
      </section>

      <CreateJobDialog open={createOpen} onClose={() => setCreateOpen(false)} onCreated={() => { setCreateOpen(false); load(); }} />
    </div>
  );
}

function CreateJobDialog({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const [title, setTitle] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [skills, setSkills] = React.useState('');
  const [salaryFrom, setSalaryFrom] = React.useState('');
  const [salaryTo, setSalaryTo] = React.useState('');
  const [location, setLocation] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  async function handleCreate() {
    if (!title.trim() || !description.trim()) return;
    setLoading(true);
    try {
      await api('/api/jobs', {
        method: 'POST',
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          requiredSkills: skills.split(',').map(s => s.trim()).filter(Boolean),
          salaryFrom: salaryFrom ? Number(salaryFrom) : null,
          salaryTo: salaryTo ? Number(salaryTo) : null,
          location: location || null,
        }),
      });
      toast({ title: 'Вакансия создана' });
      setTitle(''); setDescription(''); setSkills(''); setSalaryFrom(''); setSalaryTo(''); setLocation('');
      onCreated();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally { setLoading(false); }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader><DialogTitle>Новая вакансия</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label>Должность</Label>
            <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="Senior ML Engineer" />
          </div>
          <div className="space-y-1">
            <Label>Описание</Label>
            <Textarea rows={3} value={description} onChange={e => setDescription(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Навыки (через запятую)</Label>
            <Input value={skills} onChange={e => setSkills(e.target.value)} placeholder="Python, ML, Docker" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label>Зарплата от</Label>
              <Input type="number" value={salaryFrom} onChange={e => setSalaryFrom(e.target.value)} placeholder="300000" />
            </div>
            <div className="space-y-1">
              <Label>Зарплата до</Label>
              <Input type="number" value={salaryTo} onChange={e => setSalaryTo(e.target.value)} placeholder="500000" />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Регион</Label>
            <Input value={location} onChange={e => setLocation(e.target.value)} placeholder="Москва / Удалённо" />
          </div>
          <Button onClick={handleCreate} disabled={loading || !title.trim()} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Опубликовать'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function statusLabel(s: string) {
  return { draft: 'Черновик', submitted: 'Откликнулся', reviewed: 'Просмотрен', accepted: 'Принят', rejected: 'Отклонён' }[s] ?? s;
}
