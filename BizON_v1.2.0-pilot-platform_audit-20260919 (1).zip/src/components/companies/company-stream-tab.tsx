// BizON — Company Stream Tab + Workforce/TalentForecast Tab (задача 4-g)
// doc_a §E1: /api/companies/[id]/stream отдаёт 5 типов карточек — UI их не потреблял.
// doc_a §E2: /api/companies/[id]/workforce-gap и /api/companies/[id]/talent-forecast
// — Workforce Intelligence backend без UI.
//
// Контракт /api/companies/[id]/stream (route.ts):
//   { items: StreamItem[], total, counts: { news, projects, jobs, reviews, achievements } }
//   StreamItem — news | project | job | review | achievement, отсортированы по timestamp desc
// Контракт /api/companies/[id]/workforce-gap:
//   { gaps: [{ skill, have, need, gap, severity, note }], totalGaps, criticalGaps }
// Контракт /api/companies/[id]/talent-forecast (POST { role, requiredSkills[], count, deadlineMonths }):
//   { forecast: { marketPool, expectedReach, expectedHire, confidence, difficulty, advice[], ... } }
'use client';

import * as React from 'react';
import { api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Newspaper, Building2, Briefcase, Star, Trophy, Loader2, Lightbulb, MapPin,
  AlertTriangle, ExternalLink, TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ============================================================================
// === Типы: Company Stream ===
// ============================================================================

type StreamItemType = 'news' | 'project' | 'job' | 'review' | 'achievement';

interface StreamItemBase {
  id: string;
  type: StreamItemType;
  timestamp: string; // ISO
}

interface NewsStreamItem extends StreamItemBase {
  type: 'news';
  title: string;
  description: string | null;
  url: string;
  imageUrl: string | null;
  aiSummary: string;
  sourceDomain: string;
  publishedAt: string;
}

interface ProjectStreamItem extends StreamItemBase {
  type: 'project';
  title: string;
  description: string;
  status: string;
  outcome: string | null;
  rating: number;
  fundingType: string | null;
  tags: string[];
  startedAt: string;
  completedAt: string | null;
}

interface JobStreamItem extends StreamItemBase {
  type: 'job';
  title: string;
  description: string;
  salaryFrom: number | null;
  salaryTo: number | null;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  location: string | null;
  requiredSkills: string[];
  growthScore: number;
}

interface ReviewStreamItem extends StreamItemBase {
  type: 'review';
  rating: number;
  category: string;
  text: string;
  isAnonymous: boolean;
  isVerified: boolean;
  author: {
    id: string | null;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    ipScore: number;
    level: string;
  } | null;
}

interface AchievementStreamItem extends StreamItemBase {
  type: 'achievement';
  title: string;
  description: string | null;
  eventType: string;
}

type StreamItem =
  | NewsStreamItem
  | ProjectStreamItem
  | JobStreamItem
  | ReviewStreamItem
  | AchievementStreamItem;

interface StreamCounts {
  news: number;
  projects: number;
  jobs: number;
  reviews: number;
  achievements: number;
}

interface StreamResponse {
  items: StreamItem[];
  total: number;
  counts: StreamCounts;
}

const STREAM_META: Record<StreamItemType, { icon: React.ReactNode; label: string; iconClass: string; countLabel: string }> = {
  news: {
    icon: <Newspaper className="w-4 h-4" aria-hidden="true" />,
    label: 'Новость',
    iconClass: 'text-blue-600 dark:text-blue-400 bg-blue-500/10',
    countLabel: 'новостей',
  },
  project: {
    icon: <Building2 className="w-4 h-4" aria-hidden="true" />,
    label: 'Проект',
    iconClass: 'text-violet-600 dark:text-violet-400 bg-violet-500/10',
    countLabel: 'проектов',
  },
  job: {
    icon: <Briefcase className="w-4 h-4" aria-hidden="true" />,
    label: 'Вакансия',
    iconClass: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10',
    countLabel: 'вакансий',
  },
  review: {
    icon: <Star className="w-4 h-4" aria-hidden="true" />,
    label: 'Отзыв',
    iconClass: 'text-amber-600 dark:text-amber-400 bg-amber-500/10',
    countLabel: 'отзывов',
  },
  achievement: {
    icon: <Trophy className="w-4 h-4" aria-hidden="true" />,
    label: 'Достижение',
    iconClass: 'text-rose-600 dark:text-rose-400 bg-rose-500/10',
    countLabel: 'достижений',
  },
};

function formatStreamDate(iso: string): string {
  return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatSalary(from: number | null, to: number | null, currency: string): string | null {
  if (from == null && to == null) return null;
  const fmt = new Intl.NumberFormat('ru-RU');
  if (from != null && to != null) return `${fmt.format(from)}–${fmt.format(to)} ${currency}`;
  const v = from ?? to;
  return `${fmt.format(v ?? 0)} ${currency}`;
}

// ============================================================================
// === Компактная карточка потока ===
// ============================================================================

function StreamItemCard({ item }: { item: StreamItem }) {
  const meta = STREAM_META[item.type];
  return (
    <div className="flex gap-3 p-3 rounded-lg border hover:border-primary/40 hover:bg-muted/20 transition">
      <span className={cn('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5', meta.iconClass)} aria-hidden="true">
        {meta.icon}
      </span>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap min-w-0">
            <Badge variant="secondary" className="text-xs font-normal">{meta.label}</Badge>
            <StreamItemTitle item={item} />
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">{formatStreamDate(item.timestamp)}</span>
        </div>
        <StreamItemBody item={item} />
      </div>
    </div>
  );
}

function StreamItemTitle({ item }: { item: StreamItem }) {
  switch (item.type) {
    case 'news':
      return (
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm font-medium hover:text-lighthouse transition truncate"
        >
          {item.title}
          <ExternalLink className="w-3 h-3 inline ml-1 text-muted-foreground" aria-hidden="true" />
        </a>
      );
    case 'review':
      return (
        <span className="text-sm font-medium flex items-center gap-1.5">
          {item.author ? `${item.author.name}` : 'Анонимный отзыв'}
          <span className="flex items-center gap-0.5 text-amber-600 dark:text-amber-400 font-semibold text-xs">
            <Star className="w-3 h-3 fill-current" aria-hidden="true" /> {item.rating}
          </span>
        </span>
      );
    default:
      return <span className="text-sm font-medium truncate">{item.title}</span>;
  }
}

function StreamItemBody({ item }: { item: StreamItem }) {
  switch (item.type) {
    case 'news':
      return (
        <>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5 leading-relaxed">{item.aiSummary || item.description || ''}</p>
          <div className="text-xs text-muted-foreground/70 mt-1">{item.sourceDomain}</div>
        </>
      );
    case 'project':
      return (
        <>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
            <Badge variant="outline" className="text-xs font-normal">{item.status === 'COMPLETED' ? 'Завершён' : 'Активен'}</Badge>
            {item.rating > 0 && <span className="text-xs text-amber-600 dark:text-amber-400 font-medium">★ {item.rating.toFixed(1)}</span>}
          </div>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-1 leading-relaxed">{item.outcome ?? item.description}</p>
          {item.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {item.tags.slice(0, 5).map((t) => (
                <Badge key={t} variant="secondary" className="text-xs font-normal">{t}</Badge>
              ))}
            </div>
          )}
        </>
      );
    case 'job':
      return (
        <>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap text-xs text-muted-foreground">
            {(() => {
              const salary = formatSalary(item.salaryFrom ?? item.salaryMin, item.salaryTo ?? item.salaryMax, item.currency);
              return salary ? <span className="font-medium text-foreground">{salary}</span> : null;
            })()}
            {item.location && (
              <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" aria-hidden="true" /> {item.location}</span>
            )}
          </div>
          {item.requiredSkills.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {item.requiredSkills.slice(0, 5).map((s) => (
                <Badge key={s} variant="secondary" className="text-xs font-normal">{s}</Badge>
              ))}
            </div>
          )}
        </>
      );
    case 'review':
      return (
        <>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5 leading-relaxed">{item.text}</p>
          {item.isVerified && (
            <Badge variant="outline" className="text-xs font-normal mt-1.5 gap-1 border-lighthouse/40 text-lighthouse">
              <Star className="w-3 h-3" aria-hidden="true" /> Подтверждённый отзыв
            </Badge>
          )}
        </>
      );
    case 'achievement':
      return item.description ? (
        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5 leading-relaxed">{item.description}</p>
      ) : null;
  }
}

// ============================================================================
// === Таб «Лента компании» ===
// ============================================================================

export function CompanyStreamTab({ companyId }: { companyId: string }) {
  const [data, setData] = React.useState<StreamResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api<StreamResponse>(`/api/companies/${companyId}/stream?limit=30`)
      .then((res) => {
        if (cancelled) return;
        setData({ items: res.items ?? [], total: res.total ?? 0, counts: res.counts });
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : 'Не удалось загрузить ленту компании');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [companyId]);

  if (loading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-sm text-muted-foreground">
          <AlertTriangle className="w-6 h-6 mx-auto mb-2 text-amber-500" aria-hidden="true" />
          {error}
        </CardContent>
      </Card>
    );
  }

  if (!data || data.items.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Building2 className="w-8 h-8 mx-auto mb-2 text-muted-foreground/40" aria-hidden="true" />
          <p className="text-sm font-medium">У компании пока нет событий в ленте</p>
          <p className="text-xs text-muted-foreground mt-1">
            Новости, проекты, вакансии, отзывы и достижения появятся здесь по мере активности.
          </p>
        </CardContent>
      </Card>
    );
  }

  const counts = data.counts;
  const chips: Array<{ type: StreamItemType; value: number }> = [
    { type: 'news', value: counts.news },
    { type: 'project', value: counts.projects },
    { type: 'job', value: counts.jobs },
    { type: 'review', value: counts.reviews },
    { type: 'achievement', value: counts.achievements },
  ];

  return (
    <div className="space-y-3">
      {/* Сводка по типам карточек */}
      <div className="flex flex-wrap gap-1.5">
        {chips.filter((c) => c.value > 0).map((c) => (
          <Badge key={c.type} variant="secondary" className="text-xs font-normal gap-1">
            {STREAM_META[c.type].icon}
            {c.value} {STREAM_META[c.type].countLabel}
          </Badge>
        ))}
      </div>
      {data.items.map((item) => (
        <StreamItemCard key={item.id} item={item} />
      ))}
    </div>
  );
}

// ============================================================================
// === Типы: Workforce Gap + Talent Forecast ===
// ============================================================================

type GapSeverity = 'low' | 'medium' | 'high' | 'critical';

interface WorkforceGapItem {
  skill: string;
  have: number;
  need: number;
  gap: number;
  severity: GapSeverity | string;
  note: string;
}

interface WorkforceGapResponse {
  gaps: WorkforceGapItem[];
  totalGaps: number;
  criticalGaps: number;
}

type ForecastDifficulty = 'easy' | 'moderate' | 'hard' | 'critical';

interface TalentForecastResult {
  companyId: string;
  role: string;
  requiredSkills: string[];
  requestedCount: number;
  deadlineMonths: number;
  marketPool: number;
  expectedReach: number;
  expectedHire: number;
  confidence: number;
  difficulty: ForecastDifficulty | string;
  advice: string[];
}

const SEVERITY_RU: Record<string, { label: string; className: string }> = {
  critical: { label: 'Критично', className: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30' },
  high: { label: 'Высокий', className: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30' },
  medium: { label: 'Средний', className: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30' },
  low: { label: 'Низкий', className: 'bg-muted text-muted-foreground border-border' },
};

const DIFFICULTY_RU: Record<string, { label: string; className: string }> = {
  easy: { label: 'Легко', className: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30' },
  moderate: { label: 'Умеренно', className: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30' },
  hard: { label: 'Сложно', className: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30' },
  critical: { label: 'Критично', className: 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30' },
};

// ============================================================================
// === Таб «Аналитика персонала» ===
// ============================================================================

export function CompanyWorkforceTab({
  companyId,
  defaultRole,
  defaultSkills,
}: {
  companyId: string;
  defaultRole?: string;
  defaultSkills?: string[];
}) {
  // === Workforce Gap ===
  const [gaps, setGaps] = React.useState<WorkforceGapResponse | null>(null);
  const [gapsLoading, setGapsLoading] = React.useState(true);
  const [gapsError, setGapsError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    setGapsLoading(true);
    api<WorkforceGapResponse>(`/api/companies/${companyId}/workforce-gap`)
      .then((res) => {
        if (!cancelled) setGaps(res);
      })
      .catch((e: unknown) => {
        if (!cancelled) setGapsError(e instanceof Error ? e.message : 'Не удалось загрузить gap-анализ');
      })
      .finally(() => {
        if (!cancelled) setGapsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [companyId]);

  // === Talent Forecast (форма) ===
  const [role, setRole] = React.useState(defaultRole ?? '');
  const [skills, setSkills] = React.useState((defaultSkills ?? []).join(', '));
  const [count, setCount] = React.useState('1');
  const [months, setMonths] = React.useState('12');
  const [forecast, setForecast] = React.useState<TalentForecastResult | null>(null);
  const [forecastLoading, setForecastLoading] = React.useState(false);
  const [forecastError, setForecastError] = React.useState<string | null>(null);

  async function handleForecast() {
    const requiredSkills = skills.split(',').map((s) => s.trim()).filter(Boolean);
    const parsedCount = Number(count);
    const parsedMonths = Number(months) || 12;
    if (!role.trim() || requiredSkills.length === 0 || !Number.isFinite(parsedCount) || parsedCount < 1) {
      setForecastError('Укажите роль, хотя бы один навык и корректное число наймов');
      return;
    }
    setForecastLoading(true);
    setForecastError(null);
    try {
      const res = await api<{ forecast: TalentForecastResult }>(
        `/api/companies/${companyId}/talent-forecast`,
        {
          method: 'POST',
          body: JSON.stringify({
            role: role.trim(),
            requiredSkills,
            count: Math.round(parsedCount),
            deadlineMonths: Math.max(1, Math.round(parsedMonths)),
          }),
        },
      );
      setForecast(res.forecast);
    } catch (e: unknown) {
      setForecastError(e instanceof Error ? e.message : 'Не удалось рассчитать прогноз');
    } finally {
      setForecastLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* ── Карточка 1: Workforce Gap ── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="w-4 h-4 text-lighthouse" aria-hidden="true" />
            Workforce Gap — дефицит навыков
          </CardTitle>
        </CardHeader>
        <CardContent>
          {gapsLoading ? (
            <Skeleton className="h-32 w-full rounded-lg" />
          ) : gapsError ? (
            <p className="text-sm text-muted-foreground">{gapsError}</p>
          ) : !gaps || gaps.gaps.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-sm font-medium">Дефицитов не найдено</p>
              <p className="text-xs text-muted-foreground mt-1">Команда укомплектована под активные вакансии.</p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 mb-3 text-xs text-muted-foreground flex-wrap">
                <span>Всего дефицитов: <strong className="text-foreground">{gaps.totalGaps}</strong></span>
                {gaps.criticalGaps > 0 && (
                  <Badge className={cn('text-xs font-medium gap-1 border', SEVERITY_RU.critical.className)}>
                    <AlertTriangle className="w-3 h-3" aria-hidden="true" />
                    {gaps.criticalGaps} критичных
                  </Badge>
                )}
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Навык</TableHead>
                      <TableHead className="text-center">Есть</TableHead>
                      <TableHead className="text-center">Нужно</TableHead>
                      <TableHead className="text-center">Дефицит</TableHead>
                      <TableHead>Статус</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gaps.gaps.map((g) => {
                      const sev = SEVERITY_RU[g.severity] ?? SEVERITY_RU.low;
                      return (
                        <TableRow key={g.skill} title={g.note}>
                          <TableCell className="font-medium">{g.skill}</TableCell>
                          <TableCell className="text-center tabular-nums">{g.have}</TableCell>
                          <TableCell className="text-center tabular-nums">{g.need}</TableCell>
                          <TableCell className="text-center tabular-nums">{g.gap > 0 ? `−${g.gap}` : '0'}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={cn('text-xs font-medium', sev.className)}>{sev.label}</Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* ── Карточка 2: Talent Forecast ── */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Briefcase className="w-4 h-4 text-lighthouse" aria-hidden="true" />
            Talent Forecast — прогноз найма
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Честная оценка «Hiring Reality»: сколько подходящих кандидатов реально найти на рынке за срок.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label htmlFor="tf-role">Роль</Label>
              <Input id="tf-role" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Например, Senior ML Engineer" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="tf-skills">Навыки (через запятую)</Label>
              <Input id="tf-skills" value={skills} onChange={(e) => setSkills(e.target.value)} placeholder="Python, PyTorch, Docker" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="tf-count">Сколько нужно нанять</Label>
              <Input id="tf-count" type="number" min={1} value={count} onChange={(e) => setCount(e.target.value)} />
            </div>
            <div className="space-y-1">
              <Label htmlFor="tf-months">Срок, месяцев</Label>
              <Input id="tf-months" type="number" min={1} value={months} onChange={(e) => setMonths(e.target.value)} />
            </div>
          </div>
          <Button onClick={handleForecast} disabled={forecastLoading} className="w-full sm:w-auto">
            {forecastLoading ? (
              <Loader2 className="w-4 h-4 mr-1 animate-spin" aria-hidden="true" />
            ) : null}
            Рассчитать прогноз
          </Button>
          {forecastError && <p className="text-xs text-destructive">{forecastError}</p>}

          {forecast && (
            <div className="pt-3 border-t space-y-3 soft-fade-in">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <ForecastStat label="Маркет-пул" value={forecast.marketPool} hint="кандидатов на платформе" />
                <ForecastStat label="Реальный охват" value={forecast.expectedReach} hint="за срок" />
                <ForecastStat label="Ожидаемые наймы" value={forecast.expectedHire} hint={`из ${forecast.requestedCount} нужных`} />
                <ForecastStat label="Уверенность" value={`${Math.round(forecast.confidence * 100)}%`} hint="модели прогноза" />
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-muted-foreground">Сложность найма:</span>
                <Badge variant="outline" className={cn('text-xs font-medium', (DIFFICULTY_RU[forecast.difficulty] ?? DIFFICULTY_RU.moderate).className)}>
                  {(DIFFICULTY_RU[forecast.difficulty] ?? DIFFICULTY_RU.moderate).label}
                </Badge>
              </div>
              {forecast.advice.length > 0 && (
                <div className="space-y-1.5">
                  {forecast.advice.map((a, i) => (
                    <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-muted/40 text-xs leading-relaxed">
                      <Lightbulb className="w-3.5 h-3.5 text-amber-500 flex-shrink-0 mt-0.5" aria-hidden="true" />
                      <span>{a}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ForecastStat({ label, value, hint }: { label: string; value: number | string; hint: string }) {
  return (
    <div className="p-3 rounded-lg border bg-muted/20">
      <div className="text-lg font-bold tabular-nums">{value}</div>
      <div className="text-xs font-medium">{label}</div>
      <div className="text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}
