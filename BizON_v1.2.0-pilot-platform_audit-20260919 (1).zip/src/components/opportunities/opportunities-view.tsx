// BizON — BIZON WORK (Phase 3): 4 режима
// ============================================================================
// [🔎 Найти работу]   — существующий JobsView (поиск + фильтры)
// [🎯 Найди мне]      — AI-подбор: топ-5 вакансий с matchConfidence > 80% (Job Passport)
// [👥 Найти специалиста] — для компаний/HR: поиск по людям (навыки, уровень, локация)
// [🚀 Найти проект]   — существующий ProjectsView (marketplace)
// ============================================================================
// Радикс Tabs по умолчанию анмаунтит неактивные табы — каждый View живёт
// только когда активен, что экономит ресурсы и не плодит параллельные запросы.
'use client';

import * as React from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { JobsView } from '@/components/jobs/jobs-view';
import { ProjectsView } from '@/components/projects/projects-view';
import { FindForMeTab } from '@/components/opportunities/find-for-me-tab';
import { FindSpecialistTab } from '@/components/opportunities/find-specialist-tab';
import { Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

type WorkTab = 'find_work' | 'find_for_me' | 'find_specialist' | 'find_project';

const TABS: Array<{ id: WorkTab; label: string; emoji: string; subtitle: string }> = [
  { id: 'find_work',       label: 'Найти работу',          emoji: '🔎', subtitle: 'Поиск вакансий с фильтрами по категориям' },
  { id: 'find_for_me',     label: 'Найди мне',             emoji: '🎯', subtitle: 'AI-подбор: топ-5 вакансий с совпадением ≥ 80%' },
  { id: 'find_specialist', label: 'Найти специалиста',     emoji: '👥', subtitle: 'Для компаний и HR: поиск по людям BizON' },
  { id: 'find_project',    label: 'Найти проект',          emoji: '🚀', subtitle: 'Marketplace проектов и кейсов' },
];

export function OpportunitiesView() {
  const [tab, setTab] = React.useState<WorkTab>('find_work');
  const current = TABS.find((t) => t.id === tab) ?? TABS[0];

  return (
    <div className="space-y-4">
      {/* Заголовок раздела — BIZON WORK */}
      <div className="flex items-baseline justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-500" aria-hidden="true" />
            BIZON WORK
          </h1>
          <p className="text-sm text-muted-foreground">{current.subtitle}</p>
        </div>
      </div>

      {/* 4 таба — горизонтальный скролл на мобильных */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as WorkTab)} className="w-full">
        <TabsList
          className="w-full h-auto flex overflow-x-auto scroll-area-thin"
          aria-label="BIZON WORK — режимы"
        >
          {TABS.map((t) => (
            <TabsTrigger
              key={t.id}
              value={t.id}
              className="flex-1 min-w-[140px] gap-1.5 py-2"
            >
              <span aria-hidden="true">{t.emoji}</span>
              <span>{t.label}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Каждый TabsContent рендерится только когда активен (radix default) */}
        <TabsContent value="find_work" className={cn('mt-4 outline-none')}>
          <JobsView />
        </TabsContent>
        <TabsContent value="find_for_me" className={cn('mt-4 outline-none')}>
          <FindForMeTab />
        </TabsContent>
        <TabsContent value="find_specialist" className={cn('mt-4 outline-none')}>
          <FindSpecialistTab />
        </TabsContent>
        <TabsContent value="find_project" className={cn('mt-4 outline-none')}>
          <ProjectsView />
        </TabsContent>
      </Tabs>
    </div>
  );
}
