// BizON — BIZON WORK / Tab «Найти специалиста» (Phase 3)
// Для компаний/HR: поиск по людям. Фильтры: навыки, уровень, локация.
// Источник: /api/users (фильтры q/skill/location/accountType) + /api/users/search (по q).
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Users, Loader2, ShieldCheck, MapPin, Building2, ArrowRight, Search,
} from 'lucide-react';

interface UserListItem {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  location: string | null;
  accountType: string;
  isVerified?: boolean;
  roles?: string[];
  level?: string;
  ipScore?: number;
  company?: { id: string; name: string; logoUrl: string | null } | null;
}

function useDebounce<T>(value: T, delay: number): T {
  const [v, setV] = React.useState(value);
  React.useEffect(() => {
    const t = setTimeout(() => setV(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return v;
}

export function FindSpecialistTab() {
  const { setProfileUserId, setView } = useAppStore();
  const [users, setUsers] = React.useState<UserListItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [total, setTotal] = React.useState(0);

  // Фильтры
  const [q, setQ] = React.useState('');
  const [location, setLocation] = React.useState('');
  const [skill, setSkill] = React.useState('');
  const [level, setLevel] = React.useState<string>('all');

  const debouncedQ = useDebounce(q, 400);
  const debouncedLocation = useDebounce(location, 400);
  const debouncedSkill = useDebounce(skill, 400);

  const fetchUsers = React.useCallback(async () => {
    setLoading(true);
    try {
      // Используем /api/users — он поддерживает фильтры q/skill/location/accountType
      const params = new URLSearchParams();
      if (debouncedQ) params.set('q', debouncedQ);
      if (debouncedLocation) params.set('location', debouncedLocation);
      if (debouncedSkill) params.set('skill', debouncedSkill);
      params.set('limit', '30');
      const res = await api<{ users: UserListItem[]; total: number; hasMore: boolean }>(
        `/api/users?${params.toString()}`
      );
      let list = res.users;
      // Дополнительный фильтр по level — /api/users не поддерживает level напрямую.
      // Фильтруем на клиенте.
      if (level !== 'all') {
        list = list.filter((u) => (u.level ?? 'basic') === level);
      }
      setUsers(list);
      setTotal(res.total);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [debouncedQ, debouncedLocation, debouncedSkill, level]);

  React.useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  function openProfile(id: string) {
    setProfileUserId(id);
    setView('profile');
  }

  return (
    <div className="space-y-4">
      {/* Заголовок */}
      <div>
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Users className="w-5 h-5 text-teal-500" />
          Найти специалиста
        </h2>
        <p className="text-sm text-muted-foreground">
          Поиск по людям BizON: навыки, уровень, локация. Кликните на карточку, чтобы открыть профиль.
        </p>
      </div>

      {/* Фильтры */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Поиск по имени, должности, ролям…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="w-full pl-9"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <Input
              placeholder="Локация"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
            <Input
              placeholder="NFT-навык (например, React)"
              value={skill}
              onChange={(e) => setSkill(e.target.value)}
            />
            <Select value={level} onValueChange={setLevel}>
              <SelectTrigger>
                <SelectValue placeholder="Уровень" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все уровни</SelectItem>
                <SelectItem value="basic">Basic</SelectItem>
                <SelectItem value="extended">Extended</SelectItem>
                <SelectItem value="expert">Expert</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Найдено: {total}</span>
            <span className="inline-flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              IP-score не показывается публично
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Список специалистов */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 w-full rounded-xl" />
          ))}
        </div>
      ) : users.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground">
              Никого не найдено. Попробуйте изменить фильтры.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {users.map((u) => (
            <SpecialistCard key={u.id} user={u} onOpen={() => openProfile(u.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

function SpecialistCard({ user, onOpen }: { user: UserListItem; onOpen: () => void }) {
  const accountTypeLabel =
    user.accountType === 'company' ? 'Компания' :
    user.accountType === 'hr_agency' ? 'HR-агентство' :
    null;
  const levelLabel = user.level === 'expert' ? 'Expert' :
    user.level === 'extended' ? 'Extended' :
    user.level === 'basic' ? 'Basic' :
    null;

  return (
    <Card className="hover:shadow-md transition-shadow flex flex-col">
      <CardContent className="p-4 flex flex-col gap-3 flex-1">
        <div className="flex items-start gap-3">
          <button onClick={onOpen} aria-label={`Открыть профиль ${user.name}`}>
            <UserAvatar name={user.name} avatarUrl={user.avatarUrl} size="lg" />
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button onClick={onOpen} className="text-left hover:underline">
                <span className="font-semibold text-sm truncate">{user.name}</span>
              </button>
              {user.isVerified && (
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" aria-label="Verified" />
              )}
            </div>
            {user.title && (
              <div className="text-xs text-muted-foreground truncate">{user.title}</div>
            )}
            {user.company?.name && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5 truncate">
                <Building2 className="w-3 h-3 flex-shrink-0" />
                <span className="truncate">{user.company.name}</span>
              </div>
            )}
            {user.location && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5 truncate">
                <MapPin className="w-3 h-3 flex-shrink-0" />
                <span className="truncate">{user.location}</span>
              </div>
            )}
          </div>
        </div>

        {user.roles && user.roles.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {user.roles.slice(0, 3).map((r) => (
              <Badge key={r} variant="secondary" className="text-xs font-normal">{r}</Badge>
            ))}
            {user.roles.length > 3 && (
              <Badge variant="outline" className="text-xs">+{user.roles.length - 3}</Badge>
            )}
          </div>
        )}

        <div className="mt-auto pt-2 flex items-center gap-2">
          {accountTypeLabel && (
            <Badge variant="outline" className="text-xs">{accountTypeLabel}</Badge>
          )}
          {levelLabel && (
            <Badge variant="outline" className="text-xs">{levelLabel}</Badge>
          )}
          <Button size="sm" variant="default" className="ml-auto" onClick={onOpen}>
            Открыть профиль <ArrowRight className="w-3 h-3 ml-1" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
