// BizON — BIZON WORK / Tab «Найди мне» (Phase 5: Opportunity Engine)
// AI-подбор: топ-5 вакансий через универсальный Opportunity Engine.
// Для каждой — Job Passport (Match + Hiring Reality) + explanation «почему BizON показывает это».
//
// Источник: GET /api/opportunities?type=job&limit=5 (Opportunity Engine —
// универсальный поиск с фильтром по Intent'ам и сортировкой по
// relevance * intentAlignment * trust).
// Job Passport грузит сам себя по /api/jobs/[id]/job-passport.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import { JobPassport } from '@/components/jobs/job-passport';
import { Sparkles, RefreshCw, Briefcase, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

const TOP_N = 5;

interface OpportunityDTO {
  id: string;
  type: string;
  title: string;
  description: string | null;
  jobId: string | null;
  relevance: number;
  intentAlignment: number;
  trust: number;
  freshness: number;
  explanation: string | null;
  skills: string[];
  compensation: string | null;
  action: { label: string; view?: string; entityId?: string };
}

interface OpportunitiesResponse {
  items: OpportunityDTO[];
  total: number;
  generatedAt: string;
}

interface FindForMeTabProps {
  /** Обновить список (вызывается после apply/save в JobPassport). */
  onChanged?: () => void;
}

export function FindForMeTab({ onChanged }: FindForMeTabProps) {
  const { user } = useAppStore();
  const [opps, setOpps] = React.useState<OpportunityDTO[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [savedJobs, setSavedJobs] = React.useState<Set<string>>(new Set());
  const [appliedJobs, setAppliedJobs] = React.useState<Set<string>>(new Set());

  const load = React.useCallback(async () => {
    if (!user?.id) return;
    setLoading(true);
    try {
      const res = await api<OpportunitiesResponse>('/api/opportunities?type=job&limit=5');
      const list = Array.isArray(res.items) ? res.items : [];
      // Только возможности с реальным jobId (JobPassport нужен id вакансии)
      const filtered = list.filter((o) => !!o.jobId);
      setOpps(filtered);
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  // Загружаем сохранённые вакансии — чтобы кнопка «Сохранить» в JobPassport отражала реальное состояние.
  const loadSaved = React.useCallback(async () => {
    try {
      const res = await api<{ jobs: Array<{ id: string }> }>('/api/jobs/saved');
      setSavedJobs(new Set(res.jobs.map((j) => j.id)));
    } catch {
      // silent
    }
  }, []);

  React.useEffect(() => {
    load();
    loadSaved();
  }, [load, loadSaved]);

  async function handleToggleSave(jobId: string) {
    try {
      const res = await api<{ saved: boolean }>(`/api/jobs/${jobId}/save`, { method: 'POST' });
      setSavedJobs((prev) => {
        const next = new Set(prev);
        if (res.saved) next.add(jobId);
        else next.delete(jobId);
        return next;
      });
      toast({ title: res.saved ? 'Вакансия сохранена' : 'Удалено из избранного' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  function handleApply(jobId: string) {
    setAppliedJobs((prev) => {
      const next = new Set(prev);
      next.add(jobId);
      return next;
    });
    onChanged?.();
  }

  // === Empty state для company/hr_agency (этот таб — только для соискателей) ===
  if (user && (user.accountType === 'company' || user.accountType === 'hr_agency')) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Briefcase className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">
            Таб «Найди мне» — для соискателей. Переключитесь на «Найти специалиста», чтобы искать кандидатов.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Заголовок */}
      <div className="flex items-baseline justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-500" />
            Найди мне
          </h2>
          <p className="text-sm text-muted-foreground">
            {loading
              ? 'Загрузка...'
              : opps.length > 0
                ? `Сегодня BizON нашёл для вас ${opps.length} ${opps.length === 1 ? 'вакансию' : opps.length < 5 ? 'вакансии' : 'вакансий'} через Opportunity Engine`
                : 'Пока нет подходящих вакансий — обновите профиль и подтвердите навыки, или отметьте намерение «Ищу работу» в настройках'}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading} className="gap-1.5">
          <RefreshCw className={cn('w-3.5 h-3.5', loading && 'animate-spin')} />
          Обновить
        </Button>
      </div>

      {/* Список Job Passports с explanation-блоком над каждым */}
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-48 w-full rounded-xl" />
          ))}
        </div>
      ) : opps.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Sparkles className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground mb-3">
              BizON не нашёл подходящих вакансий через Opportunity Engine.
              Подтвердите больше навыков в профиле или отметьте намерение «Ищу работу» в Настройках —
              и фид «Найди мне» наполнится.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {opps.map((opp, idx) => {
            const jobId = opp.jobId!;
            const matchPercent = Math.round(opp.relevance * 100);
            return (
              <div key={opp.id} className="relative">
                <div className="absolute -left-1 top-3 z-10 w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center shadow-sm">
                  {idx + 1}
                </div>
                <div className="pl-5 space-y-2">
                  {/* Explanation-блок «Почему BizON показывает это» */}
                  <div className="flex items-start gap-2 p-2.5 rounded-lg bg-primary/5 border border-primary/20">
                    <Info className="w-3.5 h-3.5 text-[#1e3a8a] dark:text-blue-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-muted-foreground leading-snug">
                        {opp.explanation ?? 'BizON подобрал эту вакансию под ваш профиль.'}
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap mt-1">
                        <Badge variant="outline" className="text-xs py-0 px-1.5 h-4">
                          {matchPercent}% match
                        </Badge>
                        {opp.intentAlignment >= 0.9 && (
                          <Badge variant="outline" className="text-xs py-0 px-1.5 h-4 text-emerald-700 dark:text-emerald-300 border-emerald-500/40 bg-emerald-500/5">
                            по намерению
                          </Badge>
                        )}
                        {opp.compensation && (
                          <Badge variant="outline" className="text-xs py-0 px-1.5 h-4 text-muted-foreground">
                            {opp.compensation}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <JobPassport
                    jobId={jobId}
                    hasApplied={appliedJobs.has(jobId)}
                    isSaved={savedJobs.has(jobId)}
                    onApply={handleApply}
                    onToggleSave={handleToggleSave}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
