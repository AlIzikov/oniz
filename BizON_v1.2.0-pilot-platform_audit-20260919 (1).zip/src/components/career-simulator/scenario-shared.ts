// BizON — Career Simulator: общие типы и утилиты (Task 10-d)
//
// Единственный источник контракта POST /api/me/career-scenario для UI:
//   • career-simulator.tsx (секция «Что если?» в AI-Career-Agent, Task 10-d);
//   • career-scenario-card.tsx (Truth Profile, расширён той же trade-off-логикой).
// Сервис career-scenario-service.ts НЕ трогаем (вне зоны) — только типизируем ответ.
//
// Честность: «вероятность», «время» и «гапы» считаем ТОЛЬКО из полей ответа API;
// trade-off «остаться vs перейти» строится из метрик ответа (в API нет отдельного
// поля trade-off) и показывается только когда данных для сравнения достаточно.

// === Контракт ответа POST /api/me/career-scenario ===
export interface CareerScenarioResponse {
  targetSkill: string;
  newOpportunitiesCount: number;       // вакансий открылось дополнительно (match ≥ 0.5)
  currentMatchesCount: number;         // вакансий подходило ДО
  totalRelevantJobs: number;           // всего активных вакансий с этим навыком
  currentAvgSalaryMax: number | null;  // средняя верхняя граница з/п «сейчас»
  projectedAvgSalaryMax: number | null;// средняя верхняя граница з/п «после освоения»
  salaryGrowthPct: number | null;      // % роста з/п (или null — мало данных)
  roleTransition: { from: string; to: string } | null;
  estimatedMonths: number | null;      // ~K месяцев на освоение
  reasoning: string;
  recommendedRoles: string[];
  engine: 'llm' | 'fallback';
  generatedAt: string;
}

// === Trade-off «остаться vs освоить навык» ================================

export interface TradeOffSide {
  /** Подходящих вакансий с match ≥ 0.5 */
  jobs: number;
  /** Средняя верхняя граница з/п по этим вакансиям (₽) */
  salaryMax: number | null;
}

export interface ScenarioTradeOff {
  stay: TradeOffSide;    // «остаться» — текущий профиль
  after: TradeOffSide;   // «освоить навык» — гипотетический профиль
  /** Прирост вакансий (after.jobs − stay.jobs) */
  jobsDelta: number;
}

/**
 * Строит trade-off из метрик ответа API. Возвращает null, если сравнение
 * не имеет смысла (нет открытых вакансий и нет зарплатных данных) —
 * тогда блок не показываем вовсе.
 */
export function buildTradeOff(res: CareerScenarioResponse): ScenarioTradeOff | null {
  const stayJobs = res.currentMatchesCount;
  const afterJobs = res.currentMatchesCount + res.newOpportunitiesCount;
  const noJobsDelta = res.newOpportunitiesCount === 0;
  const noSalaryData = res.currentAvgSalaryMax == null && res.projectedAvgSalaryMax == null;
  // Сравнение показываем только когда есть хоть какой-то материал для выбора
  if (noJobsDelta && noSalaryData) return null;
  return {
    stay: { jobs: stayJobs, salaryMax: res.currentAvgSalaryMax },
    after: { jobs: afterJobs, salaryMax: res.projectedAvgSalaryMax },
    jobsDelta: res.newOpportunitiesCount,
  };
}

/**
 * «Вероятность» из данных: доля релевантных вакансий (где навык требуется),
 * которые станут доступны с освоением навыка. 0..100 или null при M=0.
 * Подпись в UI обязана говорить «доля вакансий», а не «гарантия».
 */
export function unlockSharePct(res: CareerScenarioResponse): number | null {
  if (res.totalRelevantJobs <= 0) return null;
  return Math.round((res.newOpportunitiesCount / res.totalRelevantJobs) * 100);
}

export function formatMoney(v: number): string {
  return `${v.toLocaleString('ru-RU')} ₽`;
}

export function formatSalaryGrowth(pct: number | null): string {
  if (pct == null) return '—';
  return `${pct > 0 ? '+' : ''}${pct}%`;
}

export function pluralMonths(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'месяц';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'месяца';
  return 'месяцев';
}

export function pluralJobsShort(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'вакансия';
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return 'вакансий';
  return 'вакансий';
}

/** Дисклеймер эвристической модели (обязателен в обоих UI симулятора) */
export const SCENARIO_DISCLAIMER =
  'Эвристическая модель: оценка по активным вакансиям платформы и вашему профилю на момент расчёта — это не гарантия и не предсказание.';
