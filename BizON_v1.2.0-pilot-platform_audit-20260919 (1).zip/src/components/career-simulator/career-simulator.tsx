// BizON — Career Simulator «Что если?» (Task 10-d)
//
// Секция симулятора в AI-Career-Agent (career-agent-view.tsx). НЕ дублирует
// CareerScenarioCard (Truth Profile) — обе поверхности потребляют один и тот же
// контракт POST /api/me/career-scenario и общие утилиты scenario-shared.ts.
//
// Что делает:
//   • предлагает цели сценария ИЗ ДАННЫХ ЮЗЕРА (без LLM):
//       — навыки профиля (GET /api/me/skills/graph?persist=false, read-only);
//       — навыки из вакансий, на которые юзер откликался (GET /api/jobs/applications);
//       — роли из Career Discovery (GET /api/me/career-discovery);
//     плюс ручной ввод навыка;
//   • показывает сценарий из career-scenario API: «вероятность» (доля
//     релевантных вакансий, которые откроются — честная формулировка), время,
//     гапы (roleTransition + открывающиеся роли), рост з/п;
//   • trade-off «остаться vs освоить навык» — строится из метрик ответа API
//     (отдельного поля в API нет) и показывается только при достаточных данных;
//   • Кнопка «Подготовить меня» → deep-link ?view=jobs&jobId=... (паттерн 7-b,
//     топ-вакансия по целевому навыку), фоллбек — раздел «Я» («Мои навыки»);
//   • дисклеймер «эвристическая модель» — всегда.
'use client';

import * as React from 'react';
import { api, useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from '@/hooks/use-toast';
import {
  FlaskConical,
  Loader2,
  Sparkles,
  ArrowRight,
  Clock,
  Briefcase,
  TrendingUp,
  Wallet,
  AlertCircle,
  GraduationCap,
  Send,
  Compass,
  Info,
} from 'lucide-react';
import { cn } from '@/lib/utils';
// Wave 11-e: подсказки-термины (глоссарий координатора, Wave 11)
import { TermInfo } from '@/components/common/term-tooltip';
// Волна 14: paywall люменов (Free: 1 люмен за сценарий)
import { LumenPaywallDialog, extractLumenNeed } from '@/components/common/lumen-paywall';
import {
  type CareerScenarioResponse,
  buildTradeOff,
  unlockSharePct,
  formatMoney,
  formatSalaryGrowth,
  pluralMonths,
  pluralJobsShort,
  SCENARIO_DISCLAIMER,
} from '@/components/career-simulator/scenario-shared';

// === Данные для выбора цели сценария ========================================

interface ProfileSkillChip {
  name: string;
  level: number | null;
}

interface ScenarioChips {
  profile: ProfileSkillChip[]; // навыки профиля (Skill Graph, read-only)
  applied: string[];           // навыки из вакансий, куда юзер откликался
  roles: string[];             // роли из Career Discovery
}

interface ChipsState {
  loading: boolean;
  error: string | null;
  data: ScenarioChips;
}

const EMPTY_CHIPS: ScenarioChips = { profile: [], applied: [], roles: [] };

// Лимиты чипов — чтобы выбор оставался обозримым на 390px
const MAX_PROFILE_CHIPS = 8;
const MAX_APPLIED_CHIPS = 8;
const MAX_ROLE_CHIPS = 6;

/** Tolerant-разбор Skill Graph (сервис вне зоны — форма может эволюционировать) */
function parseSkillsGraph(raw: unknown): ProfileSkillChip[] {
  if (typeof raw !== 'object' || raw === null) return [];
  const skills = (raw as { skills?: unknown }).skills;
  if (!Array.isArray(skills)) return [];
  return skills
    .map((s): ProfileSkillChip | null => {
      if (typeof s !== 'object' || s === null) return null;
      const o = s as Record<string, unknown>;
      const name =
        typeof o.skillName === 'string' ? o.skillName :
        typeof o.name === 'string' ? o.name : null;
      if (!name) return null;
      return {
        name,
        level: typeof o.currentLevel === 'number' ? o.currentLevel : null,
      };
    })
    .filter((s): s is ProfileSkillChip => s !== null)
    .slice(0, MAX_PROFILE_CHIPS);
}

export function CareerSimulator({ className }: { className?: string }) {
  const setView = useAppStore((s) => s.setView);
  const user = useAppStore((s) => s.user);
  const isFree = user?.subscriptionTier === 'free';
  // Волна 14: paywall — открывается при 402 (не хватает люменов)
  const [paywall, setPaywall] = React.useState<{ need: number; have: number } | null>(null);

  // === Выбор цели из данных юзера ===
  const [chips, setChips] = React.useState<ChipsState>({ loading: true, error: null, data: EMPTY_CHIPS });
  const [skillName, setSkillName] = React.useState('');
  const [selectedTarget, setSelectedTarget] = React.useState<string | null>(null);

  // === Сценарий ===
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState<CareerScenarioResponse | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  // === «Подготовить меня» ===
  const [preparing, setPreparing] = React.useState(false);

  // Источники целей: три read-only API, каждый терпит неудачу независимо
  React.useEffect(() => {
    let cancelled = false;
    setChips((s) => ({ ...s, loading: true, error: null }));
    Promise.all([
      api<unknown>('/api/me/skills/graph?persist=false').catch(() => null),
      api<{ applications?: Array<{ job?: { requiredSkills?: unknown } }> }>('/api/jobs/applications').catch(() => null),
      api<{ currentSearch?: unknown; suggestions?: unknown; discoveries?: unknown }>('/api/me/career-discovery').catch(() => null),
    ]).then(([graphRaw, appsRaw, discoveryRaw]) => {
      if (cancelled) return;
      const profile = parseSkillsGraph(graphRaw);
      const applied = new Set<string>();
      if (appsRaw && Array.isArray(appsRaw.applications)) {
        for (const a of appsRaw.applications) {
          const skills = a?.job?.requiredSkills;
          if (Array.isArray(skills)) {
            for (const s of skills) {
              if (typeof s === 'string' && s.trim().length >= 2) applied.add(s.trim());
            }
          }
        }
      }
      const roles = new Set<string>();
      if (discoveryRaw && typeof discoveryRaw === 'object') {
        const d = discoveryRaw as { currentSearch?: unknown; suggestions?: unknown; discoveries?: unknown };
        if (Array.isArray(d.currentSearch)) {
          for (const t of d.currentSearch) if (typeof t === 'string' && t.trim()) roles.add(t.trim());
        }
        const suggestions = Array.isArray(d.suggestions) ? d.suggestions : Array.isArray(d.discoveries) ? d.discoveries : [];
        for (const s of suggestions) {
          if (typeof s === 'object' && s !== null) {
            const title = (s as { title?: unknown }).title;
            if (typeof title === 'string' && title.trim()) roles.add(title.trim());
          }
        }
      }
      const failedAll = graphRaw === null && appsRaw === null && discoveryRaw === null;
      setChips({
        loading: false,
        error: failedAll ? 'Не удалось загрузить ваши данные — можно ввести навык вручную' : null,
        data: {
          profile,
          applied: Array.from(applied).slice(0, MAX_APPLIED_CHIPS),
          roles: Array.from(roles).slice(0, MAX_ROLE_CHIPS),
        },
      });
    });
    return () => { cancelled = true; };
  }, []);

  // === Запуск сценария (POST /api/me/career-scenario — контракт scenario-shared) ===
  const runScenario = React.useCallback(async (target: string) => {
    const trimmed = target.trim();
    if (!trimmed) {
      toast({ title: 'Введите навык или роль', variant: 'destructive' });
      return;
    }
    setSkillName(trimmed);
    setSelectedTarget(trimmed);
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await api<CareerScenarioResponse>('/api/me/career-scenario', {
        method: 'POST',
        body: JSON.stringify({ skillName: trimmed }),
      });
      setResult(res);
    } catch (e: unknown) {
      // Волна 14: 402 — не хватает люменов → диалог пополнения (после — повтор)
      const lumenNeed = extractLumenNeed(e);
      if (lumenNeed) {
        setPaywall(lumenNeed);
        setLoading(false);
        return;
      }
      const msg = e instanceof Error ? e.message : 'Не удалось построить сценарий';
      setError(msg);
      toast({ title: 'Не удалось построить сценарий', description: msg, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, []);

  // === «Подготовить меня»: deep-link ?view=jobs&jobId=... (паттерн 7-b) =====
  const handlePrepare = React.useCallback(async () => {
    if (!result) return;
    setPreparing(true);
    let navigated = false;
    try {
      const res = await api<{ jobs?: Array<{ id?: unknown }> }>(
        `/api/jobs?q=${encodeURIComponent(result.targetSkill)}&mode=quick`,
      );
      const jobId = Array.isArray(res.jobs)
        ? res.jobs.map((j) => j?.id).find((id): id is string => typeof id === 'string')
        : undefined;
      if (jobId) {
        // Полная навигация по deep-link — page.tsx на монтировании откроет
        // раздел «Работа» и детальный диалог вакансии с планом подготовки
        navigated = true;
        window.location.assign(`/?view=jobs&jobId=${encodeURIComponent(jobId)}`);
        return;
      }
      toast({
        title: 'Вакансий с этим навыком пока нет',
        description: 'Открыл раздел «Я» — составьте план в «Моих навыках».',
      });
    } catch {
      toast({ title: 'Поиск вакансии не удался', description: 'Открываю раздел «Я».' });
    } finally {
      if (!navigated) {
        setPreparing(false);
        setView('me');
      }
    }
  }, [result, setView]);

  const hasAnyChip = chips.data.profile.length > 0 || chips.data.applied.length > 0 || chips.data.roles.length > 0;
  const tradeOff = result ? buildTradeOff(result) : null;
  const unlockPct = result ? unlockSharePct(result) : null;

  return (
    <Card className={cn('overflow-hidden', className)}>
      {/* Волна 14: paywall — не хватает люменов на ИИ-сценарий */}
      <LumenPaywallDialog
        open={paywall !== null}
        onOpenChange={(o) => { if (!o) setPaywall(null); }}
        need={paywall?.need ?? 1}
        have={paywall?.have ?? 0}
        onToppedUp={() => {
          setPaywall(null);
          if (selectedTarget) runScenario(selectedTarget);
        }}
      />
      <CardHeader className="bg-gradient-to-br from-lighthouse/10 to-transparent">
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <FlaskConical className="w-4 h-4 text-lighthouse" aria-hidden="true" />
          Career Simulator
          <span className="text-xs text-muted-foreground font-normal">
            «что если освоить навык…» — без риска для карьеры
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-4">
        {/* === Выбор цели из данных юзера === */}
        <div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5">
            Цель сценария — из ваших данных <TermInfo k="career_scenario" />
          </div>
          {chips.loading && (
            <div className="flex gap-1.5 flex-wrap" aria-hidden="true">
              {[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-6 w-20 rounded-full" />)}
            </div>
          )}
          {!chips.loading && chips.error && (
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Info className="w-3 h-3 shrink-0" aria-hidden="true" />
              {chips.error}
            </p>
          )}
          {!chips.loading && !hasAnyChip && !chips.error && (
            <p className="text-xs text-muted-foreground">
              В профиле пока нет навыков и откликов — введите навык вручную ниже.
            </p>
          )}
          {!chips.loading && hasAnyChip && (
            <div className="space-y-2 max-h-44 overflow-y-auto scroll-area-thin pr-1">
              {chips.data.profile.length > 0 && (
                <ChipGroup
                  icon={<GraduationCap className="w-3 h-3 shrink-0" aria-hidden="true" />}
                  label="Навыки профиля"
                  items={chips.data.profile.map((s) => ({
                    key: `p:${s.name}`,
                    text: s.level != null ? `${s.name} · ур. ${s.level}` : s.name,
                    value: s.name,
                  }))}
                  selected={selectedTarget}
                  disabled={loading}
                  onPick={runScenario}
                />
              )}
              {chips.data.applied.length > 0 && (
                <ChipGroup
                  icon={<Send className="w-3 h-3 shrink-0" aria-hidden="true" />}
                  label="Навыки из ваших откликов"
                  items={chips.data.applied.map((s) => ({ key: `a:${s}`, text: s, value: s }))}
                  selected={selectedTarget}
                  disabled={loading}
                  onPick={runScenario}
                />
              )}
              {chips.data.roles.length > 0 && (
                <ChipGroup
                  icon={<Compass className="w-3 h-3 shrink-0" aria-hidden="true" />}
                  label="Роли, которые вы рассматривали"
                  items={chips.data.roles.map((r) => ({ key: `r:${r}`, text: r, value: r }))}
                  selected={selectedTarget}
                  disabled={loading}
                  onPick={runScenario}
                />
              )}
            </div>
          )}
        </div>

        {/* === Ручной ввод === */}
        <form
          onSubmit={(e) => { e.preventDefault(); void runScenario(skillName); }}
          className="flex gap-2"
        >
          <label htmlFor="simulator-skill-input" className="sr-only">Навык или роль для сценария</label>
          <Input
            id="simulator-skill-input"
            value={skillName}
            onChange={(e) => setSkillName(e.target.value)}
            placeholder="Например: System Design, Kubernetes…"
            maxLength={80}
            disabled={loading}
            className="flex-1 h-9"
          />
          <Button
            type="submit"
            size="sm"
            disabled={loading || !skillName.trim()}
            className="bg-lighthouse hover:bg-lighthouse/90 text-lighthouse-foreground gap-1.5"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />}
            {isFree ? 'Посчитать · 1 Л' : 'Посчитать'}
          </Button>
        </form>

        {/* === Загрузка сценария === */}
        {loading && (
          <div className="space-y-2" aria-hidden="true">
            <Skeleton className="h-16 w-full" />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full" />)}
            </div>
          </div>
        )}

        {/* === Ошибка — блок, вкладка не падает === */}
        {error && !loading && (
          <div
            role="alert"
            className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive flex items-start gap-2"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" aria-hidden="true" />
            <div>
              <div className="font-medium">Не удалось построить сценарий</div>
              <div className="text-xs opacity-80 mt-0.5">{error}</div>
            </div>
          </div>
        )}

        {/* === Результат === */}
        {result && !loading && (
          <div className="space-y-3 animate-in fade-in duration-300" aria-live="polite">
            {/* Нарратив */}
            <div className="rounded-lg border border-lighthouse/30 bg-lighthouse/5 p-3">
              <div className="text-xs font-medium text-lighthouse mb-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3" aria-hidden="true" />
                Сценарий: «{result.targetSkill}»
              </div>
              <p className="text-sm text-foreground/90 leading-relaxed">{result.reasoning}</p>
              {result.engine === 'fallback' && (
                <p className="text-xs text-muted-foreground mt-2 italic">
                  LLM недоступен — показана эвристика по вашим навыкам и вакансиям
                </p>
              )}
            </div>

            {/* Метрики: вероятность (доля вакансий) / время / рост з/п / станет доступно */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <Metric
                icon={<Briefcase className="w-3.5 h-3.5" aria-hidden="true" />}
                label="Откроется"
                value={result.newOpportunitiesCount > 0 ? `+${result.newOpportunitiesCount}` : '0'}
                hint={
                  unlockPct != null
                    ? `${unlockPct}% вакансий с навыком`
                    : `${result.totalRelevantJobs} ${pluralJobsShort(result.totalRelevantJobs)} с навыком`
                }
                positive={result.newOpportunitiesCount > 0}
              />
              <Metric
                icon={<Clock className="w-3.5 h-3.5" aria-hidden="true" />}
                label="Время"
                value={result.estimatedMonths != null ? `~${result.estimatedMonths} мес` : '—'}
                hint="оценка на освоение"
              />
              <Metric
                icon={<TrendingUp className="w-3.5 h-3.5" aria-hidden="true" />}
                label="Рост з/п"
                value={formatSalaryGrowth(result.salaryGrowthPct)}
                hint={
                  result.projectedAvgSalaryMax != null
                    ? `до ${formatMoney(result.projectedAvgSalaryMax)}`
                    : 'мало данных по з/п'
                }
                positive={(result.salaryGrowthPct ?? 0) > 0}
              />
              <Metric
                icon={<Wallet className="w-3.5 h-3.5" aria-hidden="true" />}
                label="Будет доступно"
                value={String(result.currentMatchesCount + result.newOpportunitiesCount)}
                hint="вакансий (match ≥ 50%)"
              />
            </div>

            {/* Гапы: трансформация роли + открывающиеся роли */}
            {(result.roleTransition || result.recommendedRoles.length > 0) && (
              <div className="rounded-md border p-3 bg-muted/30 space-y-2">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Гапы сценария</div>
                {result.roleTransition && (
                  <div className="flex items-center gap-2 flex-wrap text-sm">
                    <span className="font-medium">{result.roleTransition.from || 'Текущая роль'}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-lighthouse" aria-hidden="true" />
                    <span className="font-medium text-lighthouse">{result.roleTransition.to || 'новая роль'}</span>
                  </div>
                )}
                {result.recommendedRoles.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {result.recommendedRoles.map((r, i) => (
                      <Badge key={`${r}-${i}`} variant="secondary" className="text-xs">{r}</Badge>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Trade-off «остаться vs освоить навык» — только если есть данные */}
            {tradeOff && (
              <div className="rounded-md border p-3 space-y-2">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">
                  Trade-off: остаться vs освоить
                </div>
                <div className="grid grid-cols-[1fr_auto_1fr] items-stretch gap-2">
                  <TradeOffSideCard
                    title="Остаться"
                    jobs={tradeOff.stay.jobs}
                    salaryMax={tradeOff.stay.salaryMax}
                    muted
                  />
                  <div className="flex items-center" aria-hidden="true">
                    <ArrowRight className="w-4 h-4 text-lighthouse" />
                  </div>
                  <TradeOffSideCard
                    title="Освоить навык"
                    jobs={tradeOff.after.jobs}
                    salaryMax={tradeOff.after.salaryMax}
                    highlight={tradeOff.jobsDelta > 0}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Сравнение построено из метрик сценария: подходящие вакансии (match ≥ 50%) и средняя
                  верхняя граница з/п по ним. Отдельного прогноза «перейти/не перейти» платформа не даёт.
                </p>
              </div>
            )}

            {/* CTA */}
            <div className="flex flex-wrap gap-2 pt-1">
              <Button
                size="sm"
                onClick={() => void handlePrepare()}
                disabled={preparing}
                className="bg-lighthouse hover:bg-lighthouse/90 text-lighthouse-foreground gap-1.5"
              >
                {preparing ? <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" /> : <GraduationCap className="w-3.5 h-3.5" aria-hidden="true" />}
                Подготовить меня
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setView('me')}
                title="Раздел «Я» → «Мои навыки»"
                className="gap-1.5"
              >
                Мои навыки
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              «Подготовить меня» откроет ближайшую вакансию с этим навыком и план подготовки к ней.
            </p>

            {/* Дисклеймер — обязателен */}
            <p className="text-xs text-muted-foreground/80 border-t pt-2">
              {SCENARIO_DISCLAIMER}
            </p>
          </div>
        )}

        {/* === Empty state === */}
        {!result && !loading && !error && (
          <p className="text-xs text-muted-foreground">
            Выберите навык или роль из своих данных — построим сценарий «что изменится,
            если вы его освоите»: сколько вакансий откроется, сколько времени займёт и куда ведёт роль.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

// === Группа чипов одной группы-источника ===================================

function ChipGroup({
  icon,
  label,
  items,
  selected,
  disabled,
  onPick,
}: {
  icon: React.ReactNode;
  label: string;
  items: Array<{ key: string; text: string; value: string }>;
  selected: string | null;
  disabled: boolean;
  onPick: (value: string) => void;
}) {
  return (
    <div>
      <div className="text-xs text-muted-foreground flex items-center gap-1 mb-1">
        {icon}
        <span>{label}</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {items.map((it) => {
          const isSel = selected === it.value;
          return (
            <button
              key={it.key}
              type="button"
              onClick={() => onPick(it.value)}
              disabled={disabled}
              aria-pressed={isSel}
              className={cn(
                'px-2 py-0.5 rounded-full text-xs border transition disabled:opacity-50 max-w-full truncate',
                isSel
                  ? 'border-lighthouse bg-lighthouse/10 text-lighthouse font-medium'
                  : 'border-border hover:border-lighthouse hover:bg-lighthouse/5 text-foreground/80',
              )}
            >
              {it.text}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// === Метрика ===

function Metric({
  icon,
  label,
  value,
  hint,
  positive,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint?: string;
  positive?: boolean;
}) {
  return (
    <div className="rounded-md border p-2.5 bg-muted/20 min-w-0">
      <div className="flex items-center gap-1 text-xs text-muted-foreground uppercase tracking-wider mb-1">
        <span className="opacity-70 shrink-0">{icon}</span>
        <span className="truncate">{label}</span>
      </div>
      <div
        className={cn(
          'text-base font-bold tabular-nums',
          positive === true && 'text-emerald-700 dark:text-emerald-400',
        )}
      >
        {value}
      </div>
      {hint && <div className="text-xs text-muted-foreground mt-0.5 truncate">{hint}</div>}
    </div>
  );
}

// === Сторона trade-off ===

function TradeOffSideCard({
  title,
  jobs,
  salaryMax,
  muted,
  highlight,
}: {
  title: string;
  jobs: number;
  salaryMax: number | null;
  muted?: boolean;
  highlight?: boolean;
}) {
  return (
    <div
      className={cn(
        'rounded-md border p-2.5 min-w-0',
        highlight ? 'border-lighthouse/40 bg-lighthouse/5' : 'bg-muted/20',
      )}
    >
      <div className={cn('text-xs uppercase tracking-wider mb-1', muted ? 'text-muted-foreground' : 'text-lighthouse')}>
        {title}
      </div>
      <div className="text-sm font-semibold tabular-nums">
        {jobs} {pluralJobsShort(jobs)}
      </div>
      <div className="text-xs text-muted-foreground mt-0.5 truncate">
        {salaryMax != null ? `з/п до ${formatMoney(salaryMax)}` : 'з/п: мало данных'}
      </div>
    </div>
  );
}
