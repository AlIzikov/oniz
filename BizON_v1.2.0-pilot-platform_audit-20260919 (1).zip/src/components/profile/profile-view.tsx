// BizON — Profile 2.0 View (паспорт доверия)
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { TrustBadge, IpScoreRing } from '@/components/common/trust-badge';
import { StoreSection } from '@/components/store/store-section';
import { toast } from '@/hooks/use-toast';
import {
  MapPin, Briefcase, Plus, Award, FolderKanban, Star, UserPlus,
  Pencil, Check, X, Brain, Sparkles, TrendingUp, Loader2, QrCode, Cake,
  Users, FolderGit, Share2, CheckCircle2, Copy,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { QRCodeSVG } from 'qrcode.react';

interface ProfileData {
  user: any;
  skills: Array<{
    id: string;
    level: number;
    confirmationsCount: number;
    nftEligible: boolean;
    skill: { id: string; name: string; category: string | null };
  }>;
  projects: Array<any>;
  // «Общее» — только для чужого профиля
  common?: {
    commonProjects: Array<{ id: string; title: string; role: string }>;
    commonSkills: string[];
    commonConnections: number;
    commonEmployer: string | null;
  };
}

export function ProfileView() {
  const { user: currentUser, profileUserId, setUser, setView } = useAppStore();
  const [data, setData] = React.useState<ProfileData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [editing, setEditing] = React.useState(false);
  const [confirming, setConfirming] = React.useState<string | null>(null);
  const [qrOpen, setQrOpen] = React.useState(false);

  // форма редактирования
  const [form, setForm] = React.useState({ name: '', title: '', bio: '', location: '', birthday: '' });

  const userId = profileUserId ?? currentUser?.id;
  const isOwn = !profileUserId || profileUserId === currentUser?.id;

  const loadProfile = React.useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    try {
      const res = await api<ProfileData>(`/api/users/${userId}`);
      setData(res);
      if (isOwn) {
        setForm({
          name: res.user.name,
          title: res.user.title ?? '',
          bio: res.user.bio ?? '',
          location: res.user.location ?? '',
          birthday: res.user.birthday ? new Date(res.user.birthday).toISOString().split('T')[0] : '',
        });
      }
    } catch (e: any) {
      toast({ title: 'Ошибка загрузки профиля', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [userId, isOwn]);

  React.useEffect(() => { loadProfile(); }, [loadProfile]);

  async function handleSave() {
    try {
      const res = await api<{ user: any }>(`/api/users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify(form),
      });
      setUser(res.user);
      setEditing(false);
      toast({ title: 'Профиль обновлён' });
      loadProfile();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  async function handleAddConnection() {
    if (!data) return;
    try {
      await api('/api/connections', {
        method: 'POST',
        body: JSON.stringify({ toUserId: data.user.id, note: 'Хочу добавить в контакты' }),
      });
      toast({ title: 'Запрос на связь отправлен' });
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    }
  }

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    );
  }

  const u = data.user;

  return (
    <div className="space-y-4">
      {/* Header — паспорт доверия */}
      <Card className="overflow-hidden">
        <div className="h-24 bg-gradient-to-r from-primary/20 via-primary/10 to-accent" />
        <CardContent className="pt-0">
          <div className="flex items-start gap-4 -mt-12">
            <div className="rounded-full ring-4 ring-card bg-card">
              <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="xl" />
            </div>
            <div className="flex-1 pt-12 min-w-0">
              <div className="flex items-start justify-between gap-2 flex-wrap">
                <div className="min-w-0">
                  <h1 className="text-2xl font-bold truncate">{u.name}</h1>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap mt-1">
                    {u.title && <span className="flex items-center gap-1"><Briefcase className="w-3.5 h-3.5" /> {u.title}</span>}
                    {u.location && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {u.location}</span>}
                  </div>
                </div>
                {isOwn ? (
                  editing ? (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSave}><Check className="w-4 h-4 mr-1" /> Сохранить</Button>
                      <Button size="sm" variant="outline" onClick={() => setEditing(false)}><X className="w-4 h-4" /></Button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => setQrOpen(true)}>
                        <QrCode className="w-4 h-4 mr-1" /> QR
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditing(true)}>
                        <Pencil className="w-4 h-4 mr-1" /> Редактировать
                      </Button>
                    </div>
                  )
                ) : (
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => setQrOpen(true)}>
                      <QrCode className="w-4 h-4" />
                    </Button>
                    <Button size="sm" onClick={handleAddConnection}>
                      <UserPlus className="w-4 h-4 mr-1" /> Добавить в контакты
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {editing ? (
            <div className="mt-6 space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label htmlFor="p-name" className="text-xs">Имя</Label>
                  <Input id="p-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="p-title" className="text-xs">Должность</Label>
                  <Input id="p-title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
                </div>
              </div>
              <div className="space-y-1">
                <Label htmlFor="p-loc" className="text-xs">Локация</Label>
                <Input id="p-loc" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="p-bday" className="text-xs">День рождения (необязательно)</Label>
                <Input id="p-bday" type="date" value={form.birthday} onChange={(e) => setForm({ ...form, birthday: e.target.value })} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="p-bio" className="text-xs">О себе</Label>
                <Textarea id="p-bio" rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
              </div>
            </div>
          ) : (
            <>
              {u.bio && <p className="mt-4 text-sm text-foreground/80">{u.bio}</p>}
              {u.roles?.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {u.roles.map((r: string) => (
                    <Badge key={r} variant="secondary">{r}</Badge>
                  ))}
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* IP-score — breakdown (P1-6: 4 сегмента с процентами) */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="w-4 h-4 text-primary" />
            IP-score · Индивидуальный потенциал
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-6">
            <IpScoreRing ipScore={u.ipScore} size={88} />
            <div className="flex-1 space-y-2">
              <TrustBadge ipScore={u.ipScore} level={u.level} size="lg" />
              <p className="text-xs text-muted-foreground">
                Уровень доверия определяет доступные функции платформы.
                {isOwn && ' Подтверждайте навыки и завершайте проекты, чтобы расти.'}
              </p>
            </div>
          </div>

          {/* P1-6: Breakdown — из чего состоит IP-score */}
          <div className="mt-4 pt-4 border-t">
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Из чего состоит IP-score
            </div>
            <div className="space-y-2">
              {/* Проекты — 40% */}
              <BreakdownBar
                label="Завершённые проекты"
                weight="40%"
                value={u.stats?.projectsCount ?? 0}
                maxScore={40}
                color="bg-emerald-600"
                onClick={isOwn ? () => setView('projects') : undefined}
              />
              {/* Рейтинги — 30% */}
              <BreakdownBar
                label="Отзывы и рейтинги"
                weight="30%"
                value={Math.min(30, (u.stats?.projectsCount ?? 0) * 5)}
                maxScore={30}
                color="bg-blue-500"
                onClick={undefined}
              />
              {/* Навыки — 20% */}
              <BreakdownBar
                label="Подтверждённые навыки"
                weight="20%"
                value={Math.min(20, (u.stats?.skillsCount ?? 0) * 4)}
                maxScore={20}
                color="bg-purple-500"
                onClick={isOwn ? () => setView('profile') : undefined}
              />
              {/* Активность — 10% */}
              <BreakdownBar
                label="Посты и связи"
                weight="10%"
                value={Math.min(10, ((u.stats?.postsCount ?? 0) * 2) + ((u.stats?.connectionsCount ?? 0) * 1))}
                maxScore={10}
                color="bg-amber-500"
                onClick={isOwn ? () => setView('feed') : undefined}
              />
            </div>
          </div>

          {u.stats && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4 pt-4 border-t">
              <Stat label="Проекты" value={u.stats.projectsCount} />
              <Stat label="Связи" value={u.stats.connectionsCount} />
              <Stat label="Навыки" value={u.stats.skillsCount} />
              <Stat label="Посты" value={u.stats.postsCount} />
            </div>
          )}

          {/* День рождения */}
          {u.birthday && (
            <div className="flex items-center gap-2 mt-4 pt-4 border-t text-sm text-muted-foreground">
              <Cake className="w-4 h-4 text-lighthouse" />
              <span>День рождения: {new Date(u.birthday).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Progress-bar заполнения профиля (только для своего) */}
      {isOwn && u.profileCompletion !== undefined && u.profileCompletion < 100 && (
        <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="text-sm font-medium flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-lighthouse" />
                  Заполнение профиля: {u.profileCompletion}%
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Заполните профиль, чтобы повысить доверие и видимость в поиске
                </div>
              </div>
              {!editing && (
                <Button size="sm" variant="outline" onClick={() => setEditing(true)}>
                  <Pencil className="w-3 h-3 mr-1" /> Заполнить
                </Button>
              )}
            </div>
            <Progress value={u.profileCompletion} className="h-2" />
          </CardContent>
        </Card>
      )}

      {/* P2-4: Реферальная программа (только для своего профиля) */}
      {isOwn && <ReferralBlock />}

      {/* Блок «Общее» — для чужого профиля */}
      {!isOwn && data.common && (data.common.commonProjects.length > 0 || data.common.commonSkills.length > 0 || data.common.commonConnections > 0) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Share2 className="w-4 h-4 text-lighthouse" /> Общее с вами
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.common.commonProjects.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <FolderGit className="w-3 h-3" /> Общие проекты ({data.common.commonProjects.length})
                </div>
                <div className="space-y-1">
                  {data.common.commonProjects.slice(0, 5).map((p) => (
                    <div key={p.id} className="text-sm flex items-center gap-2 p-1.5 rounded-md bg-muted/40">
                      <FolderKanban className="w-3 h-3 text-muted-foreground" />
                      <span className="font-medium">{p.title}</span>
                      <Badge variant="outline" className="text-xs ml-auto">{p.role}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {data.common.commonSkills.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <Award className="w-3 h-3" /> Общие навыки ({data.common.commonSkills.length})
                </div>
                <div className="flex flex-wrap gap-1">
                  {data.common.commonSkills.map((s) => (
                    <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
                  ))}
                </div>
              </div>
            )}
            {data.common.commonConnections > 0 && (
              <div className="flex items-center gap-2 text-sm pt-2 border-t">
                <Users className="w-4 h-4 text-lighthouse" />
                <span><strong>{data.common.commonConnections}</strong> общих контактов</span>
              </div>
            )}
            {data.common.commonEmployer && (
              <div className="flex items-center gap-2 text-sm pt-2 border-t">
                <Briefcase className="w-4 h-4 text-lighthouse" />
                <span>Общий работодатель: <strong>{data.common.commonEmployer}</strong></span>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* QR Code Modal */}
      <Dialog open={qrOpen} onOpenChange={setQrOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>QR-код профиля</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4 py-4">
            <div className="p-4 bg-card text-card-foreground rounded-xl border border-border">
              <QRCodeSVG value={`https://bizon.app/u/${u.id}`} size={200} />
            </div>
            <div className="text-center">
              <div className="font-semibold">{u.name}</div>
              {u.title && <div className="text-sm text-muted-foreground">{u.title}</div>}
              <div className="text-xs text-muted-foreground mt-1">Наведите камеру телефона, чтобы открыть профиль</div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                navigator.clipboard.writeText(`https://bizon.app/u/${u.id}`);
                toast({ title: 'Ссылка скопирована' });
              }}
            >
              <Share2 className="w-3 h-3 mr-1" /> Скопировать ссылку
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Skills — живые бейджи (ТЗ 4.2.2) */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <Award className="w-4 h-4 text-primary" /> Навыки
              <Badge variant="secondary" className="ml-1">{data.skills.length}</Badge>
            </CardTitle>
            {isOwn && <AddSkillDialog onAdded={loadProfile} />}
          </div>
        </CardHeader>
        <CardContent>
          {data.skills.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              Навыков пока нет. Добавьте первый навык.
            </p>
          ) : (
            <div className="space-y-2">
              {data.skills.map((us) => (
                <SkillRow
                  key={us.id}
                  userSkill={us}
                  isOwn={isOwn}
                  onConfirm={() => setConfirming(us.id)}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirm skill dialog */}
      <ConfirmSkillDialog
        userSkillId={confirming}
        onClose={() => setConfirming(null)}
        onConfirmed={loadProfile}
        sharedProjects={data.projects.filter((p: any) => p.status === 'completed' || p.status === 'active')}
      />

      {/* Projects */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FolderKanban className="w-4 h-4 text-primary" /> Проекты
            <Badge variant="secondary" className="ml-1">{data.projects.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {data.projects.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">Нет проектов</p>
          ) : (
            <div className="space-y-2">
              {data.projects.map((p: any) => (
                <button
                  key={p.id}
                  onClick={() => { useAppStore.getState().setSelectedProjectId(p.id); setView('projects'); }}
                  className="w-full text-left p-3 rounded-lg border hover:border-primary hover:bg-accent/30 transition"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="font-medium text-sm truncate">{p.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{p.description}</div>
                      <div className="flex items-center gap-2 mt-1.5">
                        <Badge variant="outline" className="text-xs">{statusLabel(p.status)}</Badge>
                        {p.rating > 0 && (
                          <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" /> {p.rating.toFixed(1)}
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">· вы: {roleLabel(p.role)}</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* AI Recommendations — для собственного профиля */}
      {isOwn && (
        <Card className="bg-gradient-to-br from-primary/5 to-accent/30 border-primary/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="w-4 h-4 text-primary" /> AI-рекомендации
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
              AI-Career-Agent анализирует ваш профиль и предлагает следующие шаги.
            </p>
            <Button variant="default" size="sm" onClick={() => setView('career')}>
              <Brain className="w-4 h-4 mr-1" /> Запустить AI-Career-Agent
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Wave 2 — Store: «Как со мной работать» (витрина продавца, S-039) */}
      {data.user.id && <StoreSection userId={data.user.id} isOwn={isOwn} />}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="text-center">
      <div className="text-xl font-bold">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

// P1-6: BreakdownBar — полоса прогресса для каждого сегмента IP-score
function BreakdownBar({ label, weight, value, maxScore, color, onClick }: {
  label: string;
  weight: string;
  value: number;
  maxScore: number;
  color: string;
  onClick?: () => void;
}) {
  const percent = Math.min(100, (value / maxScore) * 100);
  return (
    <div
      className={onClick ? 'cursor-pointer hover:bg-accent/50 -mx-2 px-2 py-1 rounded transition' : ''}
      onClick={onClick}
    >
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="font-medium">{label}</span>
        <span className="text-muted-foreground tabular-nums">{weight} · {Math.round(value)}/{maxScore}</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className={cn('h-full rounded-full transition-all duration-500', color)} style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

function SkillRow({ userSkill, isOwn, onConfirm }: {
  userSkill: { id: string; level: number; confirmationsCount: number; nftEligible: boolean; skill: { id: string; name: string; category: string | null } };
  isOwn: boolean;
  onConfirm: () => void;
}) {
  const isVerified = userSkill.confirmationsCount > 0;
  return (
    <div className="flex items-center justify-between p-2 rounded-lg border bg-card/50">
      <div className="flex items-center gap-3 min-w-0">
        {/* Level badge */}
        <div className="flex flex-col items-center">
          <div className="text-xs text-muted-foreground">Lvl</div>
          <div className="font-bold text-sm">{userSkill.level}</div>
        </div>
        <div className="min-w-0">
          {/* Skill name with ✓ truth badge */}
          <div className="flex items-center gap-1.5">
            <span className="font-medium text-sm truncate">{userSkill.skill.name}</span>
            {isVerified && (
              <span className="flex items-center gap-0.5 text-xs text-lighthouse font-medium" title="Подтверждён через реальный проект">
                <CheckCircle2 className="w-3.5 h-3.5" /> {userSkill.confirmationsCount}
              </span>
            )}
            {userSkill.nftEligible && (
              <span className="inline-flex items-center gap-0.5 text-xs px-1 py-0.5 rounded bg-lighthouse/15 text-lighthouse font-medium">
                <Award className="w-3 h-3" /> NFT
              </span>
            )}
          </div>
          <div className="text-xs text-muted-foreground">
            {isVerified
              ? `Подтверждён ${userSkill.confirmationsCount} коллегами через проекты`
              : 'Нет подтверждений пока'}
          </div>
        </div>
      </div>
      {!isOwn && (
        <Button size="sm" variant="outline" onClick={onConfirm}>
          <Plus className="w-3 h-3 mr-1" /> Подтвердить
        </Button>
      )}
    </div>
  );
}

function AddSkillDialog({ onAdded }: { onAdded: () => void }) {
  const [name, setName] = React.useState('');
  const [level, setLevel] = React.useState('3');
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  async function handleAdd() {
    if (!name.trim()) return;
    setLoading(true);
    try {
      await api('/api/skills', {
        method: 'POST',
        body: JSON.stringify({ name: name.trim(), level: Number(level) }),
      });
      toast({ title: 'Навык добавлен' });
      setName('');
      setOpen(false);
      onAdded();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline">
          <Plus className="w-4 h-4 mr-1" /> Добавить
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Добавить навык</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="s-name">Название</Label>
            <Input id="s-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Python, React, ML..." />
          </div>
          <div className="space-y-1">
            <Label htmlFor="s-level">Уровень (1-5)</Label>
            <Input id="s-level" type="number" min="1" max="5" value={level} onChange={(e) => setLevel(e.target.value)} />
          </div>
          <Button onClick={handleAdd} disabled={loading || !name.trim()} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Добавить'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ConfirmSkillDialog({ userSkillId, onClose, onConfirmed, sharedProjects }: {
  userSkillId: string | null;
  onClose: () => void;
  onConfirmed: () => void;
  sharedProjects: any[];
}) {
  const [projectId, setProjectId] = React.useState('');
  const [comment, setComment] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (userSkillId) {
      setProjectId(sharedProjects[0]?.id ?? '');
      setComment('');
    }
  }, [userSkillId, sharedProjects]);

  async function handleConfirm() {
    if (!userSkillId || !projectId) return;
    setLoading(true);
    try {
      await api('/api/skills/confirm', {
        method: 'POST',
        body: JSON.stringify({ userSkillId, projectId, comment }),
      });
      toast({ title: 'Навык подтверждён', description: 'IP-score владельца навыка обновлён' });
      onClose();
      onConfirmed();
    } catch (e: any) {
      toast({ title: 'Ошибка', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={!!userSkillId} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Подтвердить навык</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {sharedProjects.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              По ТЗ FR-4 подтверждение навыка возможно только при наличии общего проекта.
              У вас нет общих завершённых проектов с этим пользователем.
            </p>
          ) : (
            <>
              <div className="space-y-1">
                <Label>Общий проект</Label>
                <select
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  className="w-full p-2 border rounded-md bg-background text-sm"
                >
                  {sharedProjects.map((p) => (
                    <option key={p.id} value={p.id}>{p.title}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <Label htmlFor="c-comment">Комментарий (необязательно)</Label>
                <Textarea
                  id="c-comment"
                  rows={3}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Опишите опыт работы с этим человеком..."
                />
              </div>
              <Button onClick={handleConfirm} disabled={loading || !projectId} className="w-full">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Подтвердить навык'}
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function statusLabel(s: string) {
  return { recruiting: 'Набор', active: 'Активен', completed: 'Завершён', cancelled: 'Отменён' }[s] ?? s;
}
function roleLabel(r: string) {
  return { owner: 'владелец', lead: 'лид', member: 'участник' }[r] ?? r;
}

// P2-4: Реферальный блок — пригласить друга, получить +5 IP-score
function ReferralBlock() {
  const [data, setData] = React.useState<{ code: string; link: string; stats: any } | null>(null);
  const [copied, setCopied] = React.useState(false);

  React.useEffect(() => {
    api<{ code: string; link: string; stats: any }>('/api/referral').then(setData).catch(() => {});
  }, []);

  if (!data) return null;

  return (
    <Card className="bg-lighthouse-gradient-soft border-lighthouse/20">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Users className="w-4 h-4 text-lighthouse" />
          <span className="text-sm font-semibold">Пригласите друга — +5 к IP-score обоим</span>
        </div>
        <div className="flex items-center gap-2 mb-3">
          <input
            readOnly
            value={data.link}
            className="flex-1 px-3 py-1.5 text-xs rounded-md border bg-background/50"
            onClick={(e) => (e.target as HTMLInputElement).select()}
          />
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              navigator.clipboard.writeText(data.link);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
          >
            {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
            {copied ? 'Скопировано' : 'Копировать'}
          </Button>
        </div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span>Приглашено: {data.stats.total}</span>
          <span>Награда получена: {data.stats.rewarded}</span>
          <span className="text-emerald-600 font-medium">+{data.stats.ipScoreBonus} IP-score</span>
        </div>
      </CardContent>
    </Card>
  );
}
