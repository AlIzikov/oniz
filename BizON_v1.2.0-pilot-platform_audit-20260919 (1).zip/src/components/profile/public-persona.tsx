// BizON — Public Persona (Этап 3.2 — Блок R)
// Нарративный формат публичного профиля:
//   «Делает X / Делал вместе с N,M,K / Проекты / NFT-навыки / [Спроси у коллег]»
// БЕЗ чисел (IP-score, confirmationsCount, level) — только факты и имена.
'use client';

import * as React from 'react';
import { useAppStore, api } from '@/stores/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { UserAvatar } from '@/components/common/user-avatar';
import { toast } from '@/hooks/use-toast';
import {
  Sparkles, Users, FolderKanban, Award, MessageCircleHeart,
  ArrowRight, Calendar, MessageSquareMore, Compass, Send,
  Handshake, Link2, ChevronRight, Mail, Loader2,
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { ColleagueInquiryDialog } from '@/components/colleague-inquiries/colleague-inquiry-dialog';
// Этап 4.2 — HR Persona: кнопка «Связаться» для HR-агентств
import { HrContactButton } from '@/components/hr/hr-contact-button';
// Этап 5.3 — CV блок: AI-резюме (для HR view) + Transferable skills блок
import { ResumeGeneratorDialog } from '@/components/cv/resume-generator-dialog';
// P0-3 — Evidence Graph: компактная версия для публичного профиля
import { EvidenceGraph } from '@/components/truth/evidence-graph';

interface PersonaCollaborator {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  projects: Array<{ title: string; yearRange: string }>;
  projectsCount: number;
}

interface PersonaProject {
  id: string;
  title: string;
  teamSize: number;
  yearRange: string;
  status: string;
  role: string;
}

interface PersonaNftSkill {
  skillName: string;
  level: number;
  confirmedBy: string[];
}

interface PersonaData {
  user: {
    id: string;
    name: string;
    title: string | null;
    bio: string | null;
    avatarUrl: string | null;
    roles: string[];
    accountType?: string;
    hrInvisible?: boolean;
    createdAt: string;
    professionalStatus?: string | null;
  };
  professionalSince: number;
  does: string[];
  collaborators: PersonaCollaborator[];
  collaboratorsTotal: number;
  projects: PersonaProject[];
  nftSkills: PersonaNftSkill[];
}

interface PublicPersonaProps {
  userId: string;
  /**
   * Если true — владелец смотрит «Как видят меня».
   * Скрывает кнопку «Добавить в контакты» / «Спроси у коллег» (последняя всё равно доступна как заглушка,
   * но кнопка «Добавить в контакты» скрывается).
   */
  previewMode?: boolean;
  /** Колбэк для добавления в контакты (внешняя логика). */
  onAddConnection?: () => void;
}

export function PublicPersona({ userId, previewMode = false, onAddConnection }: PublicPersonaProps) {
  const { setProfileUserId, user: currentUser } = useAppStore();
  const [data, setData] = React.useState<PersonaData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [collabLimit, setCollabLimit] = React.useState(5);
  // R9: выбранный коллега для диалога «Спроси у коллег»
  const [inquiryColleague, setInquiryColleague] = React.useState<PersonaCollaborator | null>(null);
  // Правка 3: диалог «Написать сообщение» (через /api/messages)
  const [messageOpen, setMessageOpen] = React.useState(false);

  // Этап 5.3 — HR view transferable skills
  const isHrViewer =
    !previewMode &&
    !!currentUser &&
    currentUser.id !== userId &&
    currentUser.accountType === 'hr_agency';

  const load = React.useCallback(async (limit: number) => {
    setLoading(true);
    try {
      const res = await api<PersonaData>(`/api/users/${userId}/persona?limit=${limit}`);
      setData(res);
    } catch (e: any) {
      toast({ title: 'Не удалось загрузить профиль', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load(collabLimit);
  }, [load, collabLimit]);

  // R9: можно спросить у коллег ТОЛЬКО если:
  //   • не preview mode
  //   • пользователь авторизован
  //   • это не свой собственный профиль
  //   • мы спрашиваем про aboutUser (владельца страницы)
  const canAskColleagues =
    !previewMode && !!currentUser && currentUser.id !== userId;

  if (loading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    );
  }

  const u = data.user;
  const hasMoreCollaborators = data.collaboratorsTotal > data.collaborators.length;

  return (
    <div className="space-y-4">
      {/* Header card — Имя + специальность + «с YYYY в профессии» */}
      <Card className="overflow-hidden">
        <div className="h-20 bg-gradient-to-r from-primary/15 via-accent/40 to-primary/10" />
        <CardContent className="pt-0">
          <div className="flex items-start gap-4 -mt-10">
            <div className="rounded-full ring-4 ring-card bg-card">
              <UserAvatar name={u.name} avatarUrl={u.avatarUrl} size="xl" />
            </div>
            <div className="flex-1 pt-10 min-w-0">
              <h1 className="text-2xl font-bold truncate">{u.name}</h1>
              <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2 flex-wrap">
                {u.title && <span className="font-medium text-foreground/80">{u.title}</span>}
                <span className="text-muted-foreground/70">·</span>
                <span>с {data.professionalSince} в профессии</span>
              </div>
              {u.roles && u.roles.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {u.roles.map((r) => (
                    <Badge key={r} variant="secondary" className="text-xs">{r}</Badge>
                  ))}
                </div>
              )}
              {/* Phase 3: Professional Status — бейдж (если установлен) */}
              {u.professionalStatus && (
                <div className="mt-2">
                  <ProfessionalStatusBadge status={u.professionalStatus} />
                </div>
              )}
            </div>
            {!previewMode && onAddConnection && (
              <div className="pt-10 flex gap-2 flex-wrap justify-end">
                <Button size="sm" variant="outline" onClick={onAddConnection}>
                  <Users className="w-4 h-4 mr-1" /> В контакты
                </Button>
                {/* Правка 3 — Кнопка «Написать сообщение» через /api/messages */}
                {canAskColleagues && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setMessageOpen(true)}
                  >
                    <Mail className="w-4 h-4 mr-1" /> Написать
                  </Button>
                )}
                {/* Этап 4.2 — HR Persona: кнопка «Связаться» для HR-агентств */}
                {currentUser?.accountType === 'hr_agency' &&
                  u.accountType === 'individual' && (
                    <HrContactButton
                      candidateId={u.id}
                      candidateName={u.name}
                      candidateHrInvisible={u.hrInvisible}
                    />
                  )}
              </div>
            )}
          </div>
          {u.bio && <p className="mt-4 text-sm text-foreground/80 leading-relaxed">{u.bio}</p>}

          {/* Этап 5.3 — CV блок: кнопка «Сформировать резюме» для HR viewing individual */}
          {isHrViewer && u.accountType === 'individual' && !u.hrInvisible && (
            <div className="mt-4 pt-4 border-t flex items-center justify-between gap-2 flex-wrap">
              <div className="text-xs text-muted-foreground">
                Сформируйте персонализированное резюме кандидата на основе подтверждённых навыков и проектов.
              </div>
              <ResumeGeneratorDialog
                targetUserId={u.id}
                triggerLabel="Сформировать резюме"
                triggerVariant="outline"
                triggerSize="sm"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Правка 3 — Общие контакты + Цепочка доверия (только для зарегистрированных, не preview) */}
      {canAskColleagues && (
        <>
          <CommonContactsBlock userId={u.id} userName={u.name} />
          <TrustChainBlock userId={u.id} userName={u.name} />
        </>
      )}

      {/* ДЕЛАЕТ */}
      {data.does.length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-6">
            <SectionTitle icon={<Sparkles className="w-4 h-4" />} label="ДЕЛАЕТ" />
            <div className="flex flex-wrap gap-2 mt-3">
              {data.does.map((s) => (
                <Badge key={s} variant="outline" className="px-3 py-1 text-sm font-medium">
                  {s}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ДЕЛАЛ ВМЕСТЕ С */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <SectionTitle
            icon={<Users className="w-4 h-4" />}
            label="ДЕЛАЛ ВМЕСТЕ С"
            right={
              data.collaboratorsTotal > 0 && (
                <span className="text-xs text-muted-foreground">
                  {data.collaboratorsTotal} {pluralColl(data.collaboratorsTotal)}
                </span>
              )
            }
          />
          {data.collaborators.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">
              Публичных совместных проектов пока нет.
            </p>
          ) : (
            <ul className="mt-3 space-y-3">
              {data.collaborators.map((c) => (
                <li key={c.id} className="flex items-start gap-2">
                  <button
                    type="button"
                    onClick={() => !previewMode && setProfileUserId(c.id)}
                    className={cn(
                      'flex-1 text-left flex items-start gap-3 p-2 rounded-lg transition',
                      !previewMode && 'hover:bg-accent/40'
                    )}
                    disabled={previewMode}
                  >
                    <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{c.name}</div>
                      {c.title && (
                        <div className="text-xs text-muted-foreground truncate">{c.title}</div>
                      )}
                      <div className="mt-1 space-y-0.5">
                        {c.projects.map((p, i) => (
                          <div key={i} className="text-xs text-foreground/70 flex items-start gap-1.5">
                            <span className="text-muted-foreground/60 mt-0.5">—</span>
                            <span>
                              <span className="font-medium">{p.title}</span>
                              <span className="text-muted-foreground"> · {p.yearRange}</span>
                            </span>
                          </div>
                        ))}
                        {c.projectsCount > c.projects.length && (
                          <div className="text-xs text-muted-foreground/70 pl-3">
                            ещё {c.projectsCount - c.projects.length} проектов вместе
                          </div>
                        )}
                      </div>
                    </div>
                  </button>
                  {/* R9: кнопка «Спросить» рядом с коллаборатором */}
                  {canAskColleagues && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInquiryColleague(c);
                      }}
                      title={`Спросить у ${c.name.split(' ')[0]} про ${u.name.split(' ')[0]}`}
                      className="shrink-0 mt-1 inline-flex items-center gap-1 text-xs px-2 py-1 rounded-md border border-lighthouse/30 text-lighthouse hover:bg-lighthouse/10 transition"
                    >
                      <MessageSquareMore className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Спросить</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
          {hasMoreCollaborators && (
            <button
              type="button"
              onClick={() => setCollabLimit((l) => l + 10)}
              className="mt-3 inline-flex items-center gap-1 text-sm text-primary hover:underline"
            >
              Показать ещё <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </CardContent>
      </Card>

      {/* ПРОЕКТЫ */}
      <Card>
        <CardContent className="p-4 sm:p-6">
          <SectionTitle
            icon={<FolderKanban className="w-4 h-4" />}
            label="ПРОЕКТЫ"
            right={
              data.projects.length > 0 && (
                <span className="text-xs text-muted-foreground">
                  {data.projects.length} {pluralProj(data.projects.length)}
                </span>
              )
            }
          />
          {data.projects.length === 0 ? (
            <p className="text-sm text-muted-foreground mt-3">Проектов пока нет.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {data.projects.map((p) => (
                <li
                  key={p.id}
                  className="flex items-start gap-2 p-2 rounded-lg bg-muted/30"
                >
                  <span className="text-muted-foreground/60 mt-0.5">—</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      {p.title}
                      <span className="text-muted-foreground font-normal">
                        {'  '}· команда {p.teamSize}, {p.yearRange}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1.5">
                      <Badge variant="outline" className="text-xs px-1.5 py-0">
                        {statusLabel(p.status)}
                      </Badge>
                      <span>· роль: {roleLabel(p.role)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* NFT-НАВЫКИ (факты) */}
      {data.nftSkills.length > 0 && (
        <Card>
          <CardContent className="p-4 sm:p-6">
            <SectionTitle icon={<Award className="w-4 h-4" />} label="NFT-НАВЫКИ" />
            <p className="text-xs text-muted-foreground mt-1 mb-3">
              Факты, подтверждённые коллегами через совместные проекты.
            </p>
            <ul className="space-y-2">
              {data.nftSkills.map((nft, i) => (
                <li key={`${nft.skillName}-${i}`} className="flex items-start gap-2">
                  <span className="text-muted-foreground/60 mt-0.5">—</span>
                  <div className="text-sm">
                    <span className="font-medium">{nft.skillName}</span>
                    {nft.confirmedBy.length > 0 ? (
                      <span className="text-muted-foreground">
                        {' '}— подтверждён {formatConfirmers(nft.confirmedBy)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground"> — NFT выпущен</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* P0-3 — Evidence Graph (компактная версия для публичного профиля) */}
      <EvidenceGraph userId={u.id} compact />

      {/* Этап 5.3 — HR view Transferable skills (только для HR-агентств) */}
      {isHrViewer && u.accountType === 'individual' && !u.hrInvisible && (
        <HrTransferableBlock userId={u.id} userName={u.name} />
      )}

      {/* Спроси у коллег — информационная плашка (само действие — через кнопки у каждого коллаборатора) */}
      <Card className="bg-lighthouse-gradient-soft border-lighthouse/30">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="rounded-full bg-background/60 p-2 shrink-0">
              <MessageCircleHeart className="w-5 h-5 text-lighthouse" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold">
                Хотите узнать, как с {u.name.split(' ')[0]} работается?
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">
                {canAskColleagues ? (
                  data.collaborators.length > 0
                    ? `Нажмите «Спросить» рядом с любым коллегой выше — отправим личный запрос. Никаких оценок и звёзд, только живые истории.`
                    : `У этого пользователя пока нет публичных совместных проектов. Как только они появятся — вы сможете спросить у коллег.`
                ) : (
                  `Попросите коллег поделиться опытом — без оценок и звёзд, только живые истории.`
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Footer-метка для preview-режима */}
      {previewMode && (
        <div className="text-center text-xs text-muted-foreground">
          <Calendar className="w-3 h-3 inline mr-1" />
          Это публичный вид вашего профиля — так его видят другие.
        </div>
      )}

      {/* R9: Диалог «Спроси у коллег» */}
      {inquiryColleague && (
        <ColleagueInquiryDialog
          open={!!inquiryColleague}
          onOpenChange={(o) => !o && setInquiryColleague(null)}
          colleague={inquiryColleague}
          aboutUser={{
            id: u.id,
            name: u.name,
            avatarUrl: u.avatarUrl,
          }}
        />
      )}

      {/* Правка 3 — Диалог «Написать сообщение» (POST /api/messages) */}
      {messageOpen && (
        <MessageComposeDialog
          open={messageOpen}
          onOpenChange={setMessageOpen}
          toUserId={u.id}
          toUserName={u.name}
        />
      )}
    </div>
  );
}

// ============================================================================
// Phase 3: ProfessionalStatusBadge — бейдж профессионального статуса.
// Используется в публичном профиле рядом с именем/ролью.
// Цветовая схема совпадает с настройками (settings-view.tsx).
// ============================================================================
const PROFESSIONAL_STATUS_META: Record<string, {
  label: string;
  dotClass: string;
  badgeClass: string;
}> = {
  active_searching: {
    label: 'Активно ищу работу',
    dotClass: 'bg-emerald-500',
    badgeClass: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30',
  },
  open_to_offers: {
    label: 'Открыт предложениям',
    dotClass: 'bg-blue-500',
    badgeClass: 'bg-blue-500/10 text-blue-700 dark:text-blue-300 border-blue-500/30',
  },
  open_to_projects: {
    label: 'Ищу проект',
    dotClass: 'bg-amber-500',
    badgeClass: 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30',
  },
  open_to_consulting: {
    label: 'Готов к консультациям',
    dotClass: 'bg-purple-500',
    badgeClass: 'bg-purple-500/10 text-purple-700 dark:text-purple-300 border-purple-500/30',
  },
  not_searching: {
    label: 'Не ищу',
    dotClass: 'bg-muted-foreground',
    badgeClass: 'bg-muted/40 text-muted-foreground border-border',
  },
};

export function ProfessionalStatusBadge({ status }: { status: string | null }) {
  if (!status) return null;
  const meta = PROFESSIONAL_STATUS_META[status];
  if (!meta) return null;
  return (
    <Badge
      variant="outline"
      className={`text-xs gap-1.5 ${meta.badgeClass}`}
      title={meta.label}
    >
      <span
        className={`w-2 h-2 rounded-full inline-block ${meta.dotClass}`}
        aria-hidden
      />
      {meta.label}
    </Badge>
  );
}

function SectionTitle({
  icon,
  label,
  right,
}: {
  icon: React.ReactNode;
  label: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <span className="text-muted-foreground">{icon}</span>
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </span>
      </div>
      {right}
    </div>
  );
}

function statusLabel(s: string) {
  return (
    { recruiting: 'Набор', active: 'Активен', completed: 'Завершён', cancelled: 'Отменён' } as Record<string, string>
  )[s] ?? s;
}

function roleLabel(r: string) {
  return ({ owner: 'владелец', lead: 'лид', member: 'участник' } as Record<string, string>)[r] ?? r;
}

function pluralColl(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'коллега';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'коллеги';
  return 'коллег';
}

function pluralProj(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'проект';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'проекта';
  return 'проектов';
}

function formatConfirmers(names: string[]): string {
  if (names.length === 0) return '';
  if (names.length === 1) return `${shortName(names[0])}`;
  if (names.length === 2) return `${shortName(names[0])} и ${shortName(names[1])}`;
  return `${shortName(names[0])}, ${shortName(names[1])} и другими`;
}

function shortName(fullName: string): string {
  // «Мария Иванова» → «М. Ивановой» (для нарратива)
  const parts = fullName.trim().split(/\s+/);
  if (parts.length < 2) return fullName;
  const first = parts[0];
  const last = parts[parts.length - 1];
  const initial = first[0]?.toUpperCase() ?? '';
  // Склонение фамилии в творительный падеж — упрощённо: «Иванова» → «Ивановой»
  const lastNameTvr = declineLastNameTvr(last);
  return `${initial}. ${lastNameTvr}`;
}

// Очень упрощённое склонение русских фамилий в творительный падеж для нарратива
function declineLastNameTvr(last: string): string {
  if (!last) return last;
  // Женские на -ова/-ева/-ёва/-на
  if (/ова$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/ева$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/ёва$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/на$/i.test(last)) return last.slice(0, -1) + 'ой';
  if (/ская$/i.test(last)) return last.slice(0, -2) + 'ой';
  if (/цкая$/i.test(last)) return last.slice(0, -2) + 'ой';
  // Мужские на -ов/-ев/-ёв/-ин/-ын/-ский/-цкий
  if (/ов$/i.test(last)) return last + 'ым';
  if (/ев$/i.test(last)) return last + 'ым';
  if (/ёв$/i.test(last)) return last + 'ым';
  if (/ин$/i.test(last)) return last + 'ым';
  if (/ын$/i.test(last)) return last + 'ым';
  if (/ский$/i.test(last)) return last.slice(0, -2) + 'им';
  if (/цкий$/i.test(last)) return last.slice(0, -2) + 'им';
  // fallback
  return last;
}

// ============================================================================
// Этап 5.3 — HR Transferable skills блок
// Показывается только HR-агентствам (currentUser.accountType='hr_agency') при просмотре
// профиля кандидата (individual). Загружает /api/users/[id]/transferable.
// Хобби показываются только если кандидат дал opt-in (showHobbiesToHr=true).
// ============================================================================
interface TransferableResponse {
  user: {
    id: string;
    name: string;
    title: string | null;
    bio: string | null;
    ipScore: number;
    level: string;
    avatarUrl: string | null;
  };
  confirmedSkills: Array<{
    id: string;
    name: string;
    level: number;
    verificationLevel: string;
    confirmationsCount: number;
  }>;
  hobbies: string[]; // полный список — только если showHobbiesToHr=true
  hobbiesCount: number; // счётчик всегда показывается
  hobbiesVisible: boolean;
  annotation: string;
  engine: 'llm' | 'fallback';
}

function HrTransferableBlock({ userId, userName }: { userId: string; userName: string }) {
  const [data, setData] = React.useState<TransferableResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [invitationOpen, setInvitationOpen] = React.useState(false);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<TransferableResponse>(`/api/users/${userId}/transferable`);
      setData(res);
    } catch (e: any) {
      // 403 = Privacy Shield / не HR
      setError(e?.message ?? 'Не удалось загрузить transferable skills');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <Card className="border-lighthouse/30">
        <CardContent className="p-4 sm:p-6 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    // Тихая ошибка — не показываем HR'у детали, просто не рендерим блок
    // (Privacy Shield — кандидат сам решил не быть видимым)
    return null;
  }

  return (
    <Card className="border-lighthouse/30 bg-lighthouse-gradient-soft">
      <CardContent className="p-4 sm:p-6 space-y-3">
        <SectionTitle
          icon={<Compass className="w-4 h-4 text-lighthouse" />}
          label="TRANSFERABLE SKILLS"
          right={
            <Badge variant="outline" className="text-xs gap-1">
              {data.engine === 'llm' ? 'AI-аннотация' : 'Из фактов'}
            </Badge>
          }
        />

        {/* AI-аннотация: «Сильные стороны: X, Y. Transferable для: A, B, C.» */}
        <p className="text-sm leading-relaxed pt-1">{data.annotation}</p>

        {/* Подтверждённые навыки */}
        {data.confirmedSkills.length > 0 && (
          <div className="pt-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Подтверждённые навыки ({data.confirmedSkills.length})
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.confirmedSkills.slice(0, 12).map((s) => (
                <Badge key={s.id} variant="secondary" className="text-xs gap-1">
                  {s.name}
                  <span className="text-xs text-muted-foreground">·{s.level}/5</span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Хобби — только если showHobbiesToHr=true */}
        {data.hobbiesVisible && data.hobbies.length > 0 ? (
          <div className="pt-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
              Хобби (видны по opt-in кандидата)
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.hobbies.map((h, i) => (
                <Badge key={`${h}-${i}`} variant="outline" className="text-xs">
                  {h}
                </Badge>
              ))}
            </div>
          </div>
        ) : data.hobbiesCount > 0 ? (
          <div className="pt-2 text-xs text-muted-foreground italic">
            У кандидата {data.hobbiesCount}{' '}
            {data.hobbiesCount === 1 ? 'хобби' : data.hobbiesCount < 5 ? 'хобби' : 'хобби'}, но он не дал согласия
            на показ HR. Список анонимизирован.
          </div>
        ) : null}

        {/* Кнопка «Отправить персонализированное приглашение» */}
        <div className="pt-3 border-t flex justify-end">
          <Button size="sm" variant="outline" onClick={() => setInvitationOpen(true)} className="gap-1.5">
            <Send className="w-3.5 h-3.5" />
            Отправить персонализированное приглашение
          </Button>
        </div>
      </CardContent>

      {/* Диалог «Персонализированное приглашение» — пока заглушка */}
      {invitationOpen && (
        <InvitationDialog
          open={invitationOpen}
          onOpenChange={setInvitationOpen}
          candidateId={userId}
          candidateName={userName}
          annotation={data.annotation}
        />
      )}
    </Card>
  );
}

// ============================================================================
// Заглушка: диалог персонализированного приглашения
// В продакшене — должно открывать HrContactButton с предзаполненным сообщением
// из AI-аннотации transferable skills. Пока — простая обёртка.
// ============================================================================
function InvitationDialog({
  open,
  onOpenChange,
  candidateId,
  candidateName,
  annotation,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  candidateId: string;
  candidateName: string;
  annotation: string;
}) {
  // Используем существующий HrContactButton внутри диалога — он уже умеет отправлять
  // контакт с сообщением. Предзаполним сообщение аннотацией transferable skills.
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-4 h-4 text-lighthouse" />
            Персонализированное приглашение для {candidateName}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-lg bg-muted/40 border border-muted p-3 text-xs text-muted-foreground">
            <div className="font-medium text-foreground mb-1">AI-контекст кандидата:</div>
            {annotation}
          </div>
          <p className="text-sm text-muted-foreground">
            Нажмите кнопку ниже, чтобы инициировать контакт. Лимит — 1 контакт в неделю на кандидата.
          </p>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Отмена
            </Button>
            <HrContactButton
              candidateId={candidateId}
              candidateName={candidateName}
              // Сообщение предзаполнить аннотацией — пользователь увидит поле и сможет отредактировать
            />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// Правка 3 — Блок «Общие контакты» (как Vings/XING)
// Загружает /api/users/[id]/common-contacts, показывает до 3 аватаров + «+N»
// ============================================================================
interface CommonContact {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
}
interface CommonContactsResponse {
  contacts: CommonContact[];
  total: number;
}

function CommonContactsBlock({ userId, userName }: { userId: string; userName: string }) {
  const { setProfileUserId } = useAppStore();
  const [data, setData] = React.useState<CommonContactsResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api<CommonContactsResponse>(`/api/users/${userId}/common-contacts`);
      setData(res);
    } catch (e: any) {
      setError(e?.message ?? 'Не удалось загрузить общих контактов');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  return (
    <Card>
      <CardContent className="p-4 sm:p-6">
        <SectionTitle
          icon={<Handshake className="w-4 h-4" />}
          label="ОБЩИЕ КОНТАКТЫ"
          right={
            !loading && data ? (
              <span className="text-xs text-muted-foreground">
                {data.total} {pluralCommon(data.total)}
              </span>
            ) : null
          }
        />

        {loading ? (
          <div className="flex items-center gap-2 mt-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-9 h-9 rounded-full" />
          </div>
        ) : error ? (
          <p className="text-xs text-muted-foreground mt-3">
            Не удалось загрузить общих контактов.
          </p>
        ) : !data || data.total === 0 ? (
          <p className="text-sm text-muted-foreground mt-3">
            Нет общих контактов с {userName.split(' ')[0]}.
          </p>
        ) : (
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            {/* До 3 аватаров */}
            {data.contacts.slice(0, 3).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setProfileUserId(c.id)}
                title={c.title ? `${c.name} · ${c.title}` : c.name}
                className="group flex flex-col items-center gap-1 transition hover:opacity-80"
              >
                <div className="rounded-full ring-2 ring-background">
                  <UserAvatar name={c.name} avatarUrl={c.avatarUrl} size="sm" />
                </div>
                <span className="text-xs text-muted-foreground max-w-[60px] truncate">
                  {c.name.split(' ')[0]}
                </span>
              </button>
            ))}
            {/* «+N» если больше */}
            {data.total > 3 && (
              <div
                className="flex items-center justify-center w-8 h-8 rounded-full bg-muted text-xs font-semibold text-muted-foreground ring-2 ring-background"
                title={`Ещё ${data.total - 3} общих контактов`}
              >
                +{data.total - 3}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Правка 3 — Блок «Цепочка доверия» (killer feature)
// POST /api/ai/matchmaker { toUserId } → визуализация пути
// ============================================================================
interface MatchmakerPathUser {
  userId: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  ipScore: number;
}
interface MatchmakerPathResponse {
  found: boolean;
  path: MatchmakerPathUser[];
  confidence: number;
  introducerId: string | null;
  introTemplate: string;
}

function TrustChainBlock({ userId, userName }: { userId: string; userName: string }) {
  const { setProfileUserId, user: currentUser } = useAppStore();
  const [data, setData] = React.useState<MatchmakerPathResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Существующий /api/ai/matchmaker POST принимает { toUserId }.
      // Находит кратчайший путь в графе доверия (5 рукопожатий).
      const res = await api<MatchmakerPathResponse>(`/api/ai/matchmaker`, {
        method: 'POST',
        body: JSON.stringify({ toUserId: userId }),
      });
      setData(res);
    } catch (e: any) {
      // 429 — rate limit по тарифу; не показываем как ошибку, просто «Нет цепочки»
      setError(e?.message ?? 'Не удалось построить цепочку доверия');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  React.useEffect(() => {
    load();
  }, [load]);

  // Число «рукопожатий» = число рёбер = path.length - 1
  // path[0] = я, path[last] = целевой пользователь.
  // Прямая связь (path.length === 2) — «Вы связаны напрямую»
  const handshakes = data?.path?.length ? data.path.length - 1 : 0;
  const isDirect = handshakes === 1;

  return (
    <Card className="bg-lighthouse-gradient-soft border-lighthouse/30">
      <CardContent className="p-4 sm:p-6">
        <SectionTitle
          icon={<Link2 className="w-4 h-4 text-lighthouse" />}
          label="ЦЕПОЧКА ДОВЕРИЯ"
          right={
            !loading && data?.found ? (
              <span className="text-xs text-muted-foreground">
                {isDirect ? 'напрямую' : `${handshakes} рукопожатия`}
              </span>
            ) : null
          }
        />

        {loading ? (
          <div className="flex items-center gap-2 mt-3">
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-8 h-1.5" />
            <Skeleton className="w-9 h-9 rounded-full" />
            <Skeleton className="w-8 h-1.5" />
            <Skeleton className="w-9 h-9 rounded-full" />
          </div>
        ) : !data || !data.found ? (
          <p className="text-sm text-muted-foreground mt-3">
            Нет цепочки доверия до {userName.split(' ')[0]}.
            {error && error.includes('лимит') && (
              <span className="block mt-1 text-xs text-amber-600 dark:text-amber-400">
                {error}
              </span>
            )}
          </p>
        ) : isDirect ? (
          <div className="mt-3 flex items-center gap-2 text-sm">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-lighthouse/15 text-lighthouse font-medium">
              <Handshake className="w-3.5 h-3.5" />
              Вы связаны напрямую
            </span>
          </div>
        ) : (
          <div className="mt-3 flex items-center gap-1.5 flex-wrap">
            {/* «Ты» — первый узел пути */}
            <PathNode
              name={currentUser?.name ?? 'Вы'}
              avatarUrl={currentUser?.avatarUrl ?? null}
              isMe
            />
            {/* Промежуточные узлы + целевой */}
            {data.path.slice(1).map((node, idx) => (
              <React.Fragment key={node.userId}>
                <Arrow />
                <PathNode
                  name={node.name}
                  avatarUrl={node.avatarUrl}
                  isLast={idx === data.path.length - 2}
                  onClick={() =>
                    idx !== data.path.length - 2 && setProfileUserId(node.userId)
                  }
                />
              </React.Fragment>
            ))}
          </div>
        )}

        {!loading && data?.found && !isDirect && data.path.length > 2 && (
          <p className="text-xs text-muted-foreground mt-2">
            Через {shortFirstName(data.path[1].name)} можно попросить интро.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function PathNode({
  name,
  avatarUrl,
  isMe = false,
  isLast = false,
  onClick,
}: {
  name: string;
  avatarUrl: string | null;
  isMe?: boolean;
  isLast?: boolean;
  onClick?: () => void;
}) {
  const inner = (
    <>
      <div
        className={cn(
          'rounded-full ring-2 ring-background',
          isMe && 'ring-lighthouse/30'
        )}
      >
        <UserAvatar name={name} avatarUrl={avatarUrl} size="sm" />
      </div>
      <span
        className={cn(
          'text-xs mt-1 max-w-[64px] truncate',
          isLast ? 'font-medium text-foreground' : 'text-muted-foreground'
        )}
      >
        {isMe ? 'Вы' : name.split(' ')[0]}
      </span>
    </>
  );

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        title={name}
        className="group flex flex-col items-center gap-0.5 transition hover:opacity-80"
      >
        {inner}
      </button>
    );
  }
  return (
    <div className="flex flex-col items-center gap-0.5" title={name}>
      {inner}
    </div>
  );
}

function Arrow() {
  return (
    <ChevronRight className="w-4 h-4 text-muted-foreground/60 self-center mt-[-12px]" />
  );
}

// ============================================================================
// Правка 3 — Диалог «Написать сообщение» (POST /api/messages)
// ============================================================================
function MessageComposeDialog({
  open,
  onOpenChange,
  toUserId,
  toUserName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  toUserId: string;
  toUserName: string;
}) {
  const [content, setContent] = React.useState('');
  const [sending, setSending] = React.useState(false);

  const handleSend = async () => {
    const trimmed = content.trim();
    if (!trimmed) {
      toast({ title: 'Введите текст сообщения', variant: 'destructive' });
      return;
    }
    setSending(true);
    try {
      await api('/api/messages', {
        method: 'POST',
        body: JSON.stringify({ toUserId, content: trimmed }),
      });
      toast({ title: `Сообщение отправлено для ${toUserName.split(' ')[0]}` });
      setContent('');
      onOpenChange(false);
    } catch (e: any) {
      toast({
        title: 'Не удалось отправить',
        description: e?.message,
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-lighthouse" />
            Написать {toUserName.split(' ')[0]}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`Здравствуйте, ${toUserName.split(' ')[0]}! ...`}
            rows={5}
            maxLength={2000}
            disabled={sending}
          />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Максимум 2000 символов</span>
            <span>{content.length}/2000</span>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={sending}
            >
              Отмена
            </Button>
            <Button size="sm" onClick={handleSend} disabled={sending || !content.trim()}>
              {sending ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> Отправка...
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5 mr-1" /> Отправить
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Вспомогательные plural/имя для блоков Правки 3
function pluralCommon(n: number) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return 'общий контакт';
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return 'общих контакта';
  return 'общих контактов';
}

function shortFirstName(fullName: string): string {
  return fullName.trim().split(/\s+/)[0] ?? fullName;
}
