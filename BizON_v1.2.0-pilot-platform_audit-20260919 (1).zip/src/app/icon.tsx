// BizON — Favicon (P2-8: SVG, масштабируемый для всех размеров)
import { ImageResponse } from 'next/og';

export const size = { width: 32, height: 32 };
export const contentType = 'image/png';

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, #1e3a8a 0%, #059669 100%)',
          borderRadius: 6,
        }}
      >
        <span style={{ fontSize: 14, fontWeight: 800, color: 'white' }}>B</span>
      </div>
    ),
    { ...size }
  );
}
