// BizON — Public Professional Passport page (/p/[token])
// P0-4: Публичная визитка verified репутации.
//
// Особенности:
//   • Server Component — рендерится на сервере (без auth), SEO-friendly
//   • Никакого PII (email / phone / location / birthday)
//   • IP-score НЕ показывается числом — только level
//   • QR-код генерируется серверно (qrcode.toDataURL) → встраивается как data URL
//   • Sticky footer (Tailwind: min-h-screen flex flex-col + footer mt-auto)
//   • Responsive (mobile-first, sm:/md:/lg: брейкпоинты)
//   • CTA «Открыть в BizON» — ведёт на главную (регистрация)
//
// Если token невалиден / паспорт выключен — показываем notFound-карточку
// (без раскрытия, существует ли пользователь).

import { NextRequest } from 'next/server';
import QRCode from 'qrcode';
import { PassportService } from '@/lib/services/passport-service';
import type {
  ProfessionalPassport,
  PassportVerifiedSkill,
  PassportProject,
  PassportRecommendation,
  PassportCareerEntry,
  PassportClaim,
} from '@/lib/services/passport-service';
import {
  ProfessionTemplateService,
  type ProfessionType,
  type SectionConfig,
} from '@/lib/services/profession-template-service';
import { AuthorChip } from '@/components/trust/author-chip';
import {
  ShieldCheck,
  BadgeCheck,
  FolderKanban,
  Award,
  Quote,
  Briefcase,
  Calendar,
  Users,
  QrCode as QrIcon,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  TrendingUp,
  Stethoscope,
  Scale,
  Cpu,
  Building2,
  Palette,
  Code2,
  GraduationCap,
  Trophy,
  BriefcaseMedical,
  Layers,
} from 'lucide-react';

export const runtime = 'nodejs';
// force-dynamic: публичная страница рендерится при каждом запросе (no SSG, no ISR).
// Причина: token-based доступ — нет смысла кэшировать на CDN. Зато избегаем
// тяжёлой static-generation фазы во время next build (которая OOM-ит sandbox).
export const dynamic = 'force-dynamic';
export const fetchCache = 'force-no-store';

type Params = { params: Promise<{ token: string }> };

export async function generateMetadata({ params }: Params) {
  const { token } = await params;
  const passport = await PassportService.getByToken(token);
  if (!passport) {
    return {
      title: 'Passport не найден — BizON',
      description: 'Публичная визитка недоступна или была отключена владельцем.',
      robots: { index: false, follow: false },
    };
  }
  const title = `${passport.user.name} — Professional Passport · BizON`;
  const description = passport.user.title
    ? `${passport.user.name}, ${passport.user.title}. Verified репутация в BizON.`
    : `${passport.user.name}. Verified репутация в BizON.`;
  return {
    title,
    description,
    robots: { index: false, follow: false }, // не индексируем публичные паспорта (privacy)
    openGraph: {
      title,
      description,
      type: 'profile',
      siteName: 'BizON',
    },
  };
}

export default async function PassportPage({ params }: Params) {
  const { token } = await params;
  const passport = await PassportService.getByToken(token);

  if (!passport) {
    return <NotFoundCard />;
  }

  // P1: Profession templates — определяем тип профессии по title/roles/skills
  const professionType = ProfessionTemplateService.detectProfessionType({
    title: passport.user.title,
    roles: passport.user.roles ?? [],
    skills: passport.verifiedSkills.map((s) => ({ name: s.name })),
  });

  // QR-код — указывает на ту же публичную страницу (origin подставится клиентом
  // при сканировании — точнее, QR содержит абсолютный URL с того origin, с которого
  // рендерится страница). Server component: используем host из headers запроса.
  // В preview-среде это preview-домен z.ai; в prod — bizon.app.
  // token в URL — приватный, но QR на странице — для самого владельца / его гостей.
  const absoluteUrl = await buildAbsoluteUrl(token);
  let qrDataUrl: string | null = null;
  try {
    qrDataUrl = await QRCode.toDataURL(absoluteUrl, {
      width: 240,
      margin: 2,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#0a0e27',
        light: '#ffffff',
      },
    });
  } catch (e) {
    console.error('[passport page] QR generation failed:', e);
  }

  return (
    <PassportCard
      passport={passport}
      qrDataUrl={qrDataUrl}
      absoluteUrl={absoluteUrl}
      professionType={professionType}
    />
  );
}

// ---------- helper: построить абсолютный URL ----------

async function buildAbsoluteUrl(token: string): Promise<string> {
  // В server component не всегда доступны headers (особенно в ISR).
  // Fallback на bizon.app (prod). Если есть доступ к request — используем host.
  try {
    // В Next 16 можно использовать next/headers (server-only)
    const { headers } = await import('next/headers');
    const h = await headers();
    const host = h.get('x-forwarded-host') || h.get('host') || 'bizon.app';
    const proto = h.get('x-forwarded-proto') || (host.startsWith('localhost') ? 'http' : 'https');
    return `${proto}://${host}/p/${token}`;
  } catch {
    return `https://bizon.app/p/${token}`;
  }
}

// ---------- основной компонент визитки ----------

function PassportCard({
  passport,
  qrDataUrl,
  absoluteUrl,
  professionType,
}: {
  passport: ProfessionalPassport;
  qrDataUrl: string | null;
  absoluteUrl: string;
  professionType: ProfessionType;
}) {
  const { user, trust, verifiedSkills, projects, evidence, recommendations, career, claims } = passport;
  const levelLabel = LEVEL_LABELS[trust.level] ?? trust.level;
  const levelClasses = LEVEL_CLASSES[trust.level] ?? 'bg-muted text-foreground';
  // P1: Profession templates — секции для текущего типа профессии
  const sections = ProfessionTemplateService.getTemplateSections(professionType);
  const professionLabel = ProfessionTemplateService.getProfessionTypeLabel(professionType);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-emerald-50/30 dark:from-slate-950 dark:via-slate-900 dark:to-emerald-950/20">
      {/* NAV */}
      <nav className="border-b bg-card/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <a href="/" className="text-2xl font-extrabold tracking-tight flex items-center gap-2">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span>
            <span className="text-emerald-700 dark:text-emerald-500">ON</span>
            <span className="text-xs text-muted-foreground font-normal hidden sm:inline">
              · Professional Passport
            </span>
          </a>
          <a
            href="/"
            className="px-4 py-1.5 text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition flex items-center gap-1.5"
          >
            Открыть в BizON <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </nav>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 sm:py-10 space-y-6">
        {/* === HERO CARD === */}
        <section className="rounded-2xl border bg-card shadow-sm overflow-hidden">
          <div className="bg-gradient-to-br from-[#1e3a8a] to-emerald-700 h-2" />
          <div className="p-5 sm:p-8">
            <div className="flex flex-col sm:flex-row items-start gap-5">
              {/* Avatar */}
              <AvatarBlock name={user.name} avatarUrl={user.avatarUrl} />

              {/* Name + title + meta */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                    {user.name}
                  </h1>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${levelClasses}`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {levelLabel}
                  </span>
                  {/* P1: Profession type badge (кроме default — он неинформативен) */}
                  {professionType !== 'default' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-700 dark:text-purple-300 border border-purple-500/30">
                      {renderProfessionIcon(professionType)}
                      {professionLabel}
                    </span>
                  )}
                </div>
                {user.title && (
                  <p className="text-base sm:text-lg text-muted-foreground mt-1">
                    {user.title}
                  </p>
                )}
                <div className="flex items-center gap-4 text-xs text-muted-foreground mt-3 flex-wrap">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    В профессии с {user.professionalSince}
                  </span>
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Evidence Coverage {Math.round(evidence.evidenceCoverage * 100)}%
                  </span>
                </div>
              </div>

              {/* QR — справа на десктопе, скрыт на мобиле (для мобилы показываем ниже) */}
              {qrDataUrl && (
                <div className="hidden md:flex flex-col items-center gap-1">
                  <img
                    src={qrDataUrl}
                    alt={`QR-код на Professional Passport ${user.name}`}
                    width={120}
                    height={120}
                    className="rounded-lg border bg-white p-1"
                  />
                  <span className="text-xs text-muted-foreground">Сканируйте</span>
                </div>
              )}
            </div>

            {/* QR для мобилы */}
            {qrDataUrl && (
              <div className="md:hidden mt-4 flex justify-center">
                <div className="flex flex-col items-center gap-1">
                  <img
                    src={qrDataUrl}
                    alt={`QR-код ${user.name}`}
                    width={140}
                    height={140}
                    className="rounded-lg border bg-white p-1"
                  />
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <QrIcon className="w-3 h-3" /> Отсканируйте, чтобы открыть
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Trust breakdown (без score) */}
          <div className="border-t bg-muted/30 px-5 sm:px-8 py-4">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" />
              Структура доверия
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <BreakdownBar label="Проекты" value={trust.breakdown.projects} />
              <BreakdownBar label="Отзывы коллег" value={trust.breakdown.peerRating} />
              <BreakdownBar label="Навыки" value={trust.breakdown.skills} />
              <BreakdownBar label="Активность" value={trust.breakdown.activity} />
            </div>
            <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
              BizON показывает уровень доверия ({levelLabel}), а не числовой рейтинг.
              Это сознательное решение — репутация не должна выглядеть как «социальный кредит».
            </p>
          </div>
        </section>

        {/* === P1: PROFESSION TEMPLATES — динамические секции === */}
        <TemplateSections
          sections={sections}
          passport={passport}
          verifiedSkills={verifiedSkills}
          projects={projects}
          evidence={evidence}
          recommendations={recommendations}
          career={career}
          claims={claims}
        />

        {/* === CTA === */}
        <section className="rounded-2xl bg-gradient-to-br from-[#1e3a8a] to-emerald-700 text-white p-6 sm:p-8 text-center">
          <Sparkles className="w-8 h-8 mx-auto mb-3 opacity-90" />
          <h2 className="text-xl sm:text-2xl font-bold mb-2">
            Хотите такой же паспорт?
          </h2>
          <p className="text-white/85 text-sm sm:text-base mb-5 max-w-xl mx-auto">
            BizON — профессиональная сеть, где репутация подтверждается действиями,
            а не лайками. Создайте аккаунт и строяйте verified репутацию.
          </p>
          <a
            href="/"
            className="inline-flex items-center gap-2 px-6 py-3 text-base font-semibold bg-white text-[#1e3a8a] rounded-lg hover:bg-white/90 transition shadow-lg"
          >
            Открыть в BizON <ArrowRight className="w-4 h-4" />
          </a>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t bg-card/50 mt-auto">
        <div className="max-w-5xl mx-auto px-4 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground text-center sm:text-left">
            <span className="font-semibold text-foreground">{user.name}</span> · Professional Passport
            <span className="block text-xs mt-0.5">
              Powered by{' '}
              <a href="/" className="font-semibold text-[#1e3a8a] dark:text-blue-400 hover:underline">
                BizON
              </a>{' '}
              · Verified reputation, not social credit.
            </span>
          </div>
          <div className="text-xs text-muted-foreground/70">
            Сгенерирован {new Date(passport.generatedAt).toLocaleString('ru-RU')}
          </div>
        </div>
      </footer>
    </div>
  );
}

// ---------- sub-components ----------

const LEVEL_LABELS: Record<string, string> = {
  basic: 'Базовый уровень',
  extended: 'Проверенный',
  expert: 'Эксперт',
};

const LEVEL_CLASSES: Record<string, string> = {
  basic: 'bg-muted text-foreground',
  extended: 'bg-blue-500/10 text-[#1e3a8a] dark:text-blue-300 border border-blue-500/30',
  expert: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40',
};

function AvatarBlock({ name, avatarUrl }: { name: string; avatarUrl: string | null }) {
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase() ?? '')
    .join('');
  if (avatarUrl) {
    return (
      <img
        src={avatarUrl}
        alt={`Аватар ${name}`}
        width={96}
        height={96}
        className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-4 border-background shadow-md flex-shrink-0"
      />
    );
  }
  return (
    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-br from-[#1e3a8a] to-emerald-700 text-white flex items-center justify-center text-2xl font-bold shadow-md flex-shrink-0">
      {initials || '?'}
    </div>
  );
}

function BreakdownBar({ label, value }: { label: string; value: number }) {
  const pct = Math.round(value * 100);
  return (
    <div>
      <div className="flex justify-between items-baseline mb-1">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-semibold tabular-nums">{pct}%</span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-[#1e3a8a] to-emerald-600"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function SectionCard({
  icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border bg-card shadow-sm">
      <div className="px-5 sm:px-6 pt-5 pb-3 border-b">
        <div className="flex items-center gap-2">
          {icon}
          <h2 className="text-base sm:text-lg font-bold">{title}</h2>
        </div>
        {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      <div className="p-5 sm:p-6">{children}</div>
    </section>
  );
}

// ============================================================================
// P1: PROFESSION TEMPLATES — динамический рендер секций по шаблону профессии
// ============================================================================

function renderProfessionIcon(type: ProfessionType): React.ReactNode {
  const cls = 'w-3.5 h-3.5';
  switch (type) {
    case 'doctor': return <Stethoscope className={cls} />;
    case 'lawyer': return <Scale className={cls} />;
    case 'engineer': return <Cpu className={cls} />;
    case 'executive': return <Building2 className={cls} />;
    case 'designer': return <Palette className={cls} />;
    case 'developer': return <Code2 className={cls} />;
    default: return <Briefcase className={cls} />;
  }
}

// Иконка секции по умолчанию — выбирается по source
function renderSectionIcon(source: SectionConfig['source'], professionType: ProfessionType): React.ReactNode {
  const cls = 'w-4 h-4 text-emerald-600';
  // Сначала специфичные иконки для типа профессии (более контекстные)
  if (professionType === 'doctor') {
    if (source === 'career') return <BriefcaseMedical className={cls} />;
    if (source === 'claims') return <GraduationCap className={cls} />;
  }
  if (professionType === 'lawyer') {
    if (source === 'claims') return <GraduationCap className={cls} />;
  }
  if (professionType === 'engineer') {
    if (source === 'skillsSubset') return <Cpu className={cls} />;
    if (source === 'industries') return <Layers className={cls} />;
  }
  if (professionType === 'developer') {
    if (source === 'skillsSubset') return <Code2 className={cls} />;
  }
  if (professionType === 'executive') {
    if (source === 'companies') return <Building2 className={cls} />;
    if (source === 'industries') return <Layers className={cls} />;
  }
  if (professionType === 'designer') {
    if (source === 'skillsSubset') return <Palette className={cls} />;
  }
  // Иконки по умолчанию для общих источников
  switch (source) {
    case 'verifiedSkills':
    case 'skillsSubset':
      return <Award className={cls} />;
    case 'projects':
    case 'projectsByRole':
    case 'projectsByTag':
      return <FolderKanban className={cls} />;
    case 'recommendations':
      return <Quote className={cls} />;
    case 'career':
    case 'companies':
      return <Briefcase className={cls} />;
    case 'evidence':
      return <BadgeCheck className={cls} />;
    case 'claims':
      return <Trophy className={cls} />;
    case 'industries':
      return <Layers className={cls} />;
    default:
      return <FolderKanban className={cls} />;
  }
}

// === TemplateSections: рендерит массив секций по конфигу ===

function TemplateSections({
  sections,
  passport,
  verifiedSkills,
  projects,
  evidence,
  recommendations,
  career,
  claims,
}: {
  sections: SectionConfig[];
  passport: ProfessionalPassport;
  verifiedSkills: PassportVerifiedSkill[];
  projects: PassportProject[];
  evidence: ProfessionalPassport['evidence'];
  recommendations: PassportRecommendation[];
  career: PassportCareerEntry[];
  claims: PassportClaim[];
}) {
  // Профессия нужна для выбора иконок — берём из паспорта (передаётся через parent scope)
  // Здесь мы знаем профессию косвенно — через иконки, переданные из PassportCard.
  // Чтобы не прокидывать professionType отдельным пропсом, вычислим ещё раз.
  const professionType = ProfessionTemplateService.detectProfessionType({
    title: passport.user.title,
    roles: passport.user.roles ?? [],
    skills: verifiedSkills.map((s) => ({ name: s.name })),
  });

  return (
    <>
      {sections.map((section) => {
        const rendered = renderSectionContent({
          section,
          verifiedSkills,
          projects,
          evidence,
          recommendations,
          career,
          claims,
        });
        // Если данных нет и hideIfEmpty != false — скрываем секцию
        if (rendered == null && section.hideIfEmpty !== false) return null;
        return (
          <SectionCard
            key={section.key}
            icon={renderSectionIcon(section.source, professionType)}
            title={section.title}
            subtitle={section.subtitle}
          >
            {rendered ?? <EmptySection />}
          </SectionCard>
        );
      })}
    </>
  );
}

// === renderSectionContent: выбирает данные по source и возвращает JSX или null ===

function renderSectionContent(input: {
  section: SectionConfig;
  verifiedSkills: PassportVerifiedSkill[];
  projects: PassportProject[];
  evidence: ProfessionalPassport['evidence'];
  recommendations: PassportRecommendation[];
  career: PassportCareerEntry[];
  claims: PassportClaim[];
}): React.ReactNode {
  const { section, verifiedSkills, projects, evidence, recommendations, career, claims } = input;

  switch (section.source) {
    // ---------- Навыки (все) ----------
    case 'verifiedSkills': {
      if (verifiedSkills.length === 0) return null;
      return (
        <div className="flex flex-wrap gap-2">
          {verifiedSkills.map((s, i) => (
            <VerifiedSkillBadge key={`${s.name}-${i}`} skill={s} />
          ))}
        </div>
      );
    }

    // ---------- Подмножество навыков (по ключевым словам) ----------
    case 'skillsSubset': {
      const kws = section.skillKeywords ?? [];
      if (kws.length === 0) return null;
      const kwsLower = kws.map((k) => k.toLowerCase());
      const filtered = verifiedSkills.filter((s) =>
        kwsLower.some((k) => s.name.toLowerCase().includes(k)),
      );
      if (filtered.length === 0) return null;
      return (
        <div className="flex flex-wrap gap-2">
          {filtered.map((s, i) => (
            <VerifiedSkillBadge key={`${s.name}-${i}`} skill={s} />
          ))}
        </div>
      );
    }

    // ---------- Проекты (все) ----------
    case 'projects': {
      if (projects.length === 0) return null;
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {projects.map((p) => (
            <ProjectCard key={p.id} project={p} />
          ))}
        </div>
      );
    }

    // ---------- Проекты по роли участника ----------
    case 'projectsByRole': {
      if (!section.projectRole || projects.length === 0) return null;
      const filtered = projects.filter((p) => p.role === section.projectRole);
      if (filtered.length === 0) return null;
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((p) => (
            <ProjectCard key={p.id} project={p} />
          ))}
        </div>
      );
    }

    // ---------- Проекты по тегу (теги не хранятся в PassportProject — фильтруем по title) ----------
    case 'projectsByTag': {
      if (!section.projectTag || projects.length === 0) return null;
      const tagLower = section.projectTag.toLowerCase();
      const filtered = projects.filter((p) => p.title.toLowerCase().includes(tagLower));
      if (filtered.length === 0) return null;
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map((p) => (
            <ProjectCard key={p.id} project={p} />
          ))}
        </div>
      );
    }

    // ---------- Recommendations ----------
    case 'recommendations': {
      if (recommendations.length === 0) return null;
      return (
        <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
          {recommendations.map((r, i) => (
            <RecommendationCard key={i} rec={r} />
          ))}
        </div>
      );
    }

    // ---------- Career timeline ----------
    case 'career': {
      if (career.length === 0) return null;
      return (
        <ol className="relative border-l-2 border-muted ml-2 space-y-4 pl-5">
          {career.map((c, i) => (
            <CareerItem key={i} item={c} />
          ))}
        </ol>
      );
    }

    // ---------- Evidence Coverage (статистика claims) ----------
    case 'evidence': {
      return (
        <>
          <div className="grid grid-cols-3 gap-3">
            <StatBlock value={String(evidence.totalClaims)} label="Всего утверждений" />
            <StatBlock value={String(evidence.verifiedClaims)} label="Подтверждено" />
            <StatBlock
              value={`${Math.round(evidence.evidenceCoverage * 100)}%`}
              label="Coverage"
              highlight
            />
          </div>
          <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#1e3a8a] to-emerald-600"
              style={{ width: `${Math.round(evidence.evidenceCoverage * 100)}%` }}
            />
          </div>
        </>
      );
    }

    // ---------- Claims (с опциональным фильтром по type) ----------
    case 'claims': {
      const filtered = section.claimType
        ? claims.filter((c) => c.type === section.claimType)
        : claims;
      if (filtered.length === 0) return null;
      return (
        <ul className="space-y-2">
          {filtered.map((c) => (
            <li key={c.id} className="rounded-lg border bg-background p-3">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h4 className="text-sm font-semibold leading-snug">{c.title}</h4>
                <ClaimStatusBadge status={c.status} />
              </div>
              {c.description && (
                <p className="text-xs text-muted-foreground leading-relaxed">{c.description}</p>
              )}
            </li>
          ))}
        </ul>
      );
    }

    // ---------- Industries: уникальные отрасли из company names в career ----------
    case 'industries': {
      // Упрощённо: извлекаем уникальные компании из career (как proxy для отраслей)
      const companies = Array.from(new Set(career.map((c) => c.company).filter(Boolean)));
      if (companies.length === 0) return null;
      return (
        <div className="flex flex-wrap gap-2">
          {companies.map((c) => (
            <span
              key={c}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full border bg-muted/30 text-sm"
            >
              <Layers className="w-3 h-3 text-emerald-600" />
              {c}
            </span>
          ))}
        </div>
      );
    }

    // ---------- Companies: уникальные компании из career ----------
    case 'companies': {
      const uniqueCompanies = Array.from(new Set(career.map((c) => c.company).filter(Boolean)));
      if (uniqueCompanies.length === 0) return null;
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {uniqueCompanies.map((c) => {
            const entries = career.filter((ce) => ce.company === c);
            const latest = entries[0];
            return (
              <div key={c} className="rounded-lg border bg-background p-3">
                <div className="flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                  <div className="min-w-0">
                    <div className="text-sm font-semibold truncate">{c}</div>
                    {latest.title && (
                      <div className="text-xs text-muted-foreground truncate">{latest.title}</div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      );
    }

    default:
      return null;
  }
}

function EmptySection(): React.ReactNode {
  return (
    <div className="text-center py-6 text-sm text-muted-foreground">
      Данные пока не добавлены
    </div>
  );
}

function ClaimStatusBadge({ status }: { status: string }) {
  const labels: Record<string, string> = {
    claimed: 'Заявлено',
    verified: 'Подтверждено',
    project_verified: 'Project-verified',
    expert_verified: 'Expert-verified',
  };
  const classes: Record<string, string> = {
    claimed: 'bg-muted text-muted-foreground',
    verified: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
    project_verified: 'bg-blue-500/10 text-blue-700 dark:text-blue-300',
    expert_verified: 'bg-amber-500/10 text-amber-700 dark:text-amber-300',
  };
  return (
    <span
      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${classes[status] ?? 'bg-muted text-muted-foreground'}`}
    >
      <CheckCircle2 className="w-2.5 h-2.5" />
      {labels[status] ?? status}
    </span>
  );
}

const VERIFICATION_LABELS: Record<string, string> = {
  claimed: 'Заявлен',
  verified: 'Подтверждён',
  project_verified: 'Project-verified',
  expert_verified: 'Expert-verified',
};

const VERIFICATION_CLASSES: Record<string, string> = {
  claimed: 'bg-muted text-muted-foreground border-border',
  verified: 'bg-blue-500/10 text-[#1e3a8a] dark:text-blue-300 border-blue-500/30',
  project_verified: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/40',
  expert_verified: 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/40',
};

function VerifiedSkillBadge({ skill }: { skill: PassportVerifiedSkill }) {
  const vLabel = VERIFICATION_LABELS[skill.verificationLevel] ?? skill.verificationLevel;
  const vClass = VERIFICATION_CLASSES[skill.verificationLevel] ?? 'bg-muted text-foreground';
  return (
    <div
      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm ${vClass}`}
      title={skill.confirmedBy.length > 0 ? `Подтвердили: ${skill.confirmedBy.join(', ')}` : vLabel}
    >
      <span className="font-medium">{skill.name}</span>
      {skill.verificationLevel !== 'claimed' && (
        <span className="flex items-center gap-1 text-xs uppercase tracking-wider">
          <CheckCircle2 className="w-3 h-3" />
          {vLabel}
        </span>
      )}
      {skill.confirmedBy.length > 0 && (
        <span className="text-xs opacity-80">
          · {skill.confirmedBy.length} {pluralizeConfirmers(skill.confirmedBy.length)}
        </span>
      )}
    </div>
  );
}

function pluralizeConfirmers(n: number): string {
  if (n === 1) return 'подтверждение';
  if (n >= 2 && n <= 4) return 'подтверждения';
  return 'подтверждений';
}

const PROJECT_STATUS_LABELS: Record<string, string> = {
  IDEA: 'Идея',
  PROPOSAL: 'Предложение',
  ACTIVE: 'В работе',
  ON_HOLD: 'На паузе',
  COMPLETED: 'Завершён',
  CANCELLED: 'Отменён',
};

const PROJECT_ROLE_LABELS: Record<string, string> = {
  FOUNDER: 'Основатель',
  CO_FOUNDER: 'Кофаундер',
  CONTRIBUTOR: 'Участник',
  MENTOR: 'Ментор',
  OBSERVER: 'Наблюдатель',
};

function ProjectCard({ project }: { project: PassportProject }) {
  return (
    <article className="rounded-xl border bg-background p-4 hover:shadow-sm transition">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="font-semibold text-sm leading-snug">{project.title}</h3>
        <span className="text-xs px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground whitespace-nowrap">
          {PROJECT_STATUS_LABELS[project.status] ?? project.status}
        </span>
      </div>
      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
        <span className="flex items-center gap-1">
          <Briefcase className="w-3 h-3" />
          {PROJECT_ROLE_LABELS[project.role] ?? project.role}
        </span>
        <span className="flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          {project.period}
        </span>
        <span className="flex items-center gap-1">
          <Users className="w-3 h-3" />
          {project.teamSize} {project.teamSize === 1 ? 'человек' : project.teamSize < 5 ? 'человека' : 'человек'}
        </span>
      </div>
      {project.result && (
        <p className="text-xs text-foreground/80 mt-2 leading-relaxed bg-muted/40 rounded px-2 py-1.5">
          {project.result}
        </p>
      )}
    </article>
  );
}

function StatBlock({
  value,
  label,
  highlight,
}: {
  value: string;
  label: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={`rounded-xl border p-3 text-center ${
        highlight ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-muted/30'
      }`}
    >
      <div className={`text-2xl font-extrabold tabular-nums ${highlight ? 'text-emerald-700 dark:text-emerald-400' : ''}`}>
        {value}
      </div>
      <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
        {label}
      </div>
    </div>
  );
}

function RecommendationCard({ rec }: { rec: PassportRecommendation }) {
  const roleLabel = rec.role
    ? ROLE_LABELS[rec.role] ?? rec.role
    : null;
  return (
    <figure className="rounded-xl border bg-background p-4">
      <div className="flex items-start gap-3">
        <Quote className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          {rec.text && (
            <blockquote className="text-sm text-foreground/90 leading-relaxed italic">
              «{rec.text}»
            </blockquote>
          )}
          <figcaption className="flex items-center gap-2 mt-2 text-xs text-muted-foreground flex-wrap">
            <span className="font-semibold text-foreground">— {rec.from}</span>
            {'authorLevel' in rec && rec.authorLevel && <AuthorChip level={rec.authorLevel} />}
            {roleLabel && (
              <span className="px-1.5 py-0.5 rounded-full bg-muted text-xs">{roleLabel}</span>
            )}
            <span>· {new Date(rec.date).toLocaleDateString('ru-RU')}</span>
          </figcaption>
        </div>
      </div>
    </figure>
  );
}

const ROLE_LABELS: Record<string, string> = {
  colleague: 'Коллега',
  manager: 'Менеджер',
  client: 'Клиент',
  expert: 'Эксперт',
};

function CareerItem({ item }: { item: PassportCareerEntry }) {
  return (
    <li className="relative">
      <span
        className={`absolute -left-[27px] top-1 w-3 h-3 rounded-full border-2 border-background ${
          item.current ? 'bg-emerald-500' : 'bg-muted-foreground/40'
        }`}
      />
      <div className="flex items-start justify-between gap-2 flex-wrap">
        <div>
          <div className="text-sm font-semibold">{item.title}</div>
          <div className="text-xs text-muted-foreground">{item.company}</div>
        </div>
        <span className="text-xs text-muted-foreground whitespace-nowrap">{item.period}</span>
      </div>
    </li>
  );
}

// ---------- NotFoundCard (без раскрытия) ----------

function NotFoundCard() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <nav className="border-b bg-card/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <a href="/" className="text-2xl font-extrabold tracking-tight">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span>
            <span className="text-emerald-700 dark:text-emerald-500">ON</span>
          </a>
          <a
            href="/"
            className="px-4 py-1.5 text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition flex items-center gap-1.5"
          >
            Открыть в BizON <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </nav>
      <main className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="max-w-md w-full text-center">
          <div className="w-16 h-16 mx-auto rounded-full bg-muted flex items-center justify-center mb-4">
            <ShieldCheck className="w-8 h-8 text-muted-foreground" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Passport не найден</h1>
          <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
            Ссылка недействительна или владелец отключил публичный паспорт.
            Это могло произойти, если ссылка была перегенерирована или срок её действия истёк.
          </p>
          <a
            href="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition"
          >
            Перейти на BizON <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </main>
      <footer className="border-t bg-card/50 mt-auto py-6 text-center text-xs text-muted-foreground">
        BizON · Verified reputation, not social credit.
      </footer>
    </div>
  );
}
