import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { SkipToContent } from "@/components/common/skip-to-content";

// P1-17: Inter — гуманистичный шрифт, лучше для trust-бренда чем Roboto
const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://bizon.app'),
  title: "BizON — профессиональная сеть доверия",
  description:
    "BizON — деловая соцсеть нового поколения. Репутация подтверждается действиями, а не лайками. AI-агенты находят связи, вакансии и карьерные траектории.",
  keywords: [
    "BizON",
    "профессиональная сеть",
    "аналог LinkedIn в России",
    "найти работу через знакомых",
    "профессиональная сеть для IT",
    "доверие",
    "Trust Graph",
    "IP-score",
    "AI-Matchmaker",
    "карьера",
    "HR-Tech",
  ],
  authors: [{ name: "BizON Systems" }],
  icons: {
    icon: "/lighthouse-logo.jpg",
  },
  openGraph: {
    title: "BizON — профессиональная сеть доверия",
    description: "Не сеть контактов. Сеть доверия. AI-агенты, IP-score, карьерные траектории.",
    siteName: "BizON",
    type: "website",
    locale: "ru_RU",
  },
  twitter: {
    card: "summary_large_image",
    title: "BizON — профессиональная сеть доверия",
    description: "Не сеть контактов. Сеть доверия.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        {/* P2-1: Yandex Metrica — для аналитики (РФ) */}
        {process.env.NODE_ENV === 'production' && (
          <script
            dangerouslySetInnerHTML={{
              __html: `
                (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
                m[i].l=1*new Date();
                for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
                k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
                (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
                ym(${process.env.NEXT_PUBLIC_YM_ID || 0}, "init", {
                  clickmap:true,
                  trackLinks:true,
                  accurateTrackBounce:true,
                  webvisor:true
                });
              `,
            }}
          />
        )}
        {/* P2-1: GA4 — для глобальной аналитики */}
        {process.env.NODE_ENV === 'production' && process.env.NEXT_PUBLIC_GA_ID && (
          <>
            <script async src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GA_ID}`} />
            <script
              dangerouslySetInnerHTML={{
                __html: `
                  window.dataLayer = window.dataLayer || [];
                  function gtag(){dataLayer.push(arguments);}
                  gtag('js', new Date());
                  gtag('config', '${process.env.NEXT_PUBLIC_GA_ID}');
                `,
              }}
            />
          </>
        )}
      </head>
      <body
        className={`${inter.variable} font-sans antialiased bg-background text-foreground`}
      >
        {/* FIX-04 (P2): WCAG 2.4.1 Bypass Blocks — первая фокусируемая ссылка */}
        <SkipToContent />
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
