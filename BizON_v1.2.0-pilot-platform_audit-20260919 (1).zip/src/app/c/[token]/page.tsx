// BizON — Public Company Passport page (/c/[token])
// Phase 10: Публичная визитка компании.
//
// Особенности:
//   • Server Component — рендерится на сервере (без auth), SEO-friendly
//   • Только публичные данные: name, industry, logoUrl, isVerified, inn, trust, projects[..3], vacancies[..3], culturalSignals
//   • НЕ показывает внутренние поля (culturalScore, adTrustIndex internals, email/phone)
//   • QR-код генерируется серверно (qrcode.toDataURL) → встраивается как data URL
//   • Responsive (mobile-first, sm:/md:/lg: брейкпоинты)
//   • CTA «Открыть в BizON» — ведёт на главную (регистрация)
//
// Если token невалиден / паспорт выключен — показываем notFound-карточку
// (без раскрытия, существует ли компания).

import { NextRequest } from 'next/server';
import QRCode from 'qrcode';
import { CompanyPassportService } from '@/lib/services/company-passport-service';
import type {
  CompanyPassport,
  PassportProject,
  PassportVacancy,
} from '@/lib/services/company-passport-service';
import {
  ShieldCheck,
  BadgeCheck,
  FolderKanban,
  Briefcase,
  MapPin,
  Users,
  Calendar,
  Building2,
  Globe,
  QrCode as QrIcon,
  Sparkles,
  ArrowRight,
  Star,
  TrendingUp,
  Truck,
  Eye,
  CheckCircle2,
  Sparkle,
} from 'lucide-react';

export const runtime = 'nodejs';
// force-dynamic: публичная страница рендерится при каждом запросе (no SSG, no ISR).
// Причина: token-based доступ — нет смысла кэшировать на CDN. Зато избегаем
// тяжёлой static-generation фазы во время next build (которая OOM-ит sandbox).
export const dynamic = 'force-dynamic';
export const fetchCache = 'force-no-store';

type Params = { params: Promise<{ token: string }> };

export async function generateMetadata({ params }: Params) {
  const { token } = await params;
  const passport = await CompanyPassportService.getByToken(token);
  if (!passport) {
    return {
      title: 'Company Passport не найден — BizON',
      description: 'Публичная визитка компании недоступна или была отключена владельцем.',
      robots: { index: false, follow: false },
    };
  }
  const title = `${passport.company.name} — Company Passport · BizON`;
  const description = passport.company.description
    ? `${passport.company.name}. ${passport.company.description.slice(0, 140)}`
    : `${passport.company.name}. Verified репутация компании в BizON.`;
  return {
    title,
    description,
    robots: { index: false, follow: false }, // не индексируем (privacy)
    openGraph: {
      title,
      description,
      type: 'website',
      siteName: 'BizON',
    },
  };
}

export default async function CompanyPassportPage({ params }: Params) {
  const { token } = await params;
  const passport = await CompanyPassportService.getByToken(token);

  if (!passport) {
    return <NotFoundCard />;
  }

  // QR-код → указывает на ту же публичную страницу.
  const absoluteUrl = await buildAbsoluteUrl(token);
  let qrDataUrl: string | null = null;
  try {
    qrDataUrl = await QRCode.toDataURL(absoluteUrl, {
      width: 240,
      margin: 2,
      errorCorrectionLevel: 'M',
      color: { dark: '#0a0e27', light: '#ffffff' },
    });
  } catch (e) {
    console.error('[company-passport page] QR generation failed:', e);
  }

  return <PassportCard passport={passport} qrDataUrl={qrDataUrl} absoluteUrl={absoluteUrl} />;
}

// ---------- helper: построить абсолютный URL ----------

async function buildAbsoluteUrl(token: string): Promise<string> {
  try {
    const { headers } = await import('next/headers');
    const h = await headers();
    const host = h.get('x-forwarded-host') || h.get('host') || 'bizon.app';
    const proto = h.get('x-forwarded-proto') || (host.startsWith('localhost') ? 'http' : 'https');
    return `${proto}://${host}/c/${token}`;
  } catch {
    return `https://bizon.app/c/${token}`;
  }
}

// ---------- основной компонент визитки ----------

function PassportCard({
  passport,
  qrDataUrl,
  absoluteUrl,
}: {
  passport: CompanyPassport;
  qrDataUrl: string | null;
  absoluteUrl: string;
}) {
  const { company, trust, projects, vacancies, culturalSignals } = passport;
  const sizeLabel = SIZE_LABELS[company.size ?? ''] ?? company.size;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-blue-50/30 dark:from-slate-950 dark:via-slate-900 dark:to-blue-950/20">
      {/* NAV */}
      <nav className="border-b bg-card/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <a href="/" className="text-2xl font-extrabold tracking-tight flex items-center gap-2">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span>
            <span className="text-emerald-700 dark:text-emerald-500">ON</span>
            <span className="text-xs text-muted-foreground font-normal hidden sm:inline">
              · Company Passport
            </span>
          </a>
          <a
            href="/"
            className="px-4 py-1.5 text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition flex items-center gap-1.5"
          >
            Открыть в BizON <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </nav>

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 sm:py-10 space-y-6">
        {/* === HERO CARD === */}
        <section className="rounded-2xl border bg-card shadow-sm overflow-hidden">
          <div className="bg-gradient-to-br from-[#1e3a8a] to-emerald-700 h-2" />
          <div className="p-5 sm:p-8">
            <div className="flex flex-col sm:flex-row items-start gap-5">
              {/* Logo */}
              <LogoBlock name={company.name} logoUrl={company.logoUrl} />

              {/* Name + meta */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                    {company.name}
                  </h1>
                  {company.isVerified && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40">
                      <BadgeCheck className="w-3.5 h-3.5" />
                      Verified
                    </span>
                  )}
                </div>
                {company.industry && (
                  <p className="text-base sm:text-lg text-muted-foreground mt-1">
                    {company.industry}
                  </p>
                )}
                {company.description && (
                  <p className="text-sm text-foreground/80 mt-2 leading-relaxed line-clamp-3">
                    {company.description}
                  </p>
                )}
                <div className="flex items-center gap-4 text-xs text-muted-foreground mt-3 flex-wrap">
                  {company.location && (
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      {company.location}
                    </span>
                  )}
                  {sizeLabel && (
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {sizeLabel}
                    </span>
                  )}
                  {company.foundedYear && (
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      с {company.foundedYear}
                    </span>
                  )}
                  {company.inn && (
                    <span className="flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5" />
                      ИНН {company.inn}
                    </span>
                  )}
                  {company.website && (
                    <a
                      href={company.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 hover:text-foreground transition"
                    >
                      <Globe className="w-3.5 h-3.5" />
                      Сайт
                    </a>
                  )}
                </div>
              </div>

              {/* QR — справа на десктопе, скрыт на мобиле */}
              {qrDataUrl && (
                <div className="hidden md:flex flex-col items-center gap-1">
                  <img
                    src={qrDataUrl}
                    alt={`QR-код на Company Passport ${company.name}`}
                    width={120}
                    height={120}
                    className="rounded-lg border bg-white p-1"
                  />
                  <span className="text-xs text-muted-foreground">Сканируйте</span>
                </div>
              )}
            </div>

            {/* QR для мобилы */}
            {qrDataUrl && (
              <div className="md:hidden mt-4 flex justify-center">
                <div className="flex flex-col items-center gap-1">
                  <img
                    src={qrDataUrl}
                    alt={`QR-код ${company.name}`}
                    width={140}
                    height={140}
                    className="rounded-lg border bg-white p-1"
                  />
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <QrIcon className="w-3 h-3" /> Отсканируйте, чтобы открыть
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Trust breakdown (4 индекса — НЕ overall число крупно, только как контекст) */}
          <div className="border-t bg-muted/30 px-5 sm:px-8 py-4">
            <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" />
              Company Trust — 4 индекса доверия
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <TrustIndexBar
                label="Работодатель"
                value={trust.employerTrust}
                Icon={Users}
                color="from-emerald-500 to-emerald-600"
              />
              <TrustIndexBar
                label="Бизнес"
                value={trust.businessTrust}
                Icon={Briefcase}
                color="from-blue-500 to-blue-600"
              />
              <TrustIndexBar
                label="Доставка"
                value={trust.deliveryTrust}
                Icon={Truck}
                color="from-violet-500 to-violet-600"
              />
              <TrustIndexBar
                label="Прозрачность"
                value={trust.transparency}
                Icon={Eye}
                color="from-amber-500 to-amber-600"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
              Каждый индекс — 0..100, рассчитан из verified Cultural Signals, завершённых
              кейсов, рейтинга сдачи и прозрачности. BizON показывает индексы, а не единый
              рейтинг — чтобы не превращать репутацию в «социальный кредит».
            </p>
          </div>
        </section>

        {/* === PROJECTS (3 кейса) === */}
        {projects.length > 0 && (
          <SectionCard
            icon={<FolderKanban className="w-4 h-4 text-[#1e3a8a] dark:text-blue-400" />}
            title="Кейсы"
            subtitle="Завершённые проекты с проверяемыми результатами"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {projects.map((p) => (
                <ProjectCard key={p.id} project={p} />
              ))}
            </div>
          </SectionCard>
        )}

        {/* === VACANCIES (3) === */}
        {vacancies.length > 0 && (
          <SectionCard
            icon={<Briefcase className="w-4 h-4 text-[#1e3a8a] dark:text-blue-400" />}
            title="Открытые вакансии"
            subtitle="Активные позиции — откликайтесь через BizON"
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {vacancies.map((v) => (
                <VacancyCard key={v.id} vacancy={v} />
              ))}
            </div>
          </SectionCard>
        )}

        {/* === CULTURAL SIGNALS === */}
        {culturalSignals.count > 0 && (
          <SectionCard
            icon={<Star className="w-4 h-4 text-amber-500" />}
            title="Cultural Signals"
            subtitle="Отзывы verified сотрудников о культуре компании"
          >
            <div className="flex items-center gap-6 flex-wrap">
              <div className="text-center">
                <div className="text-5xl font-extrabold tabular-nums text-amber-600 dark:text-amber-400 leading-none">
                  {culturalSignals.avgRating.toFixed(1)}
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
                  из 5.0
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1 mb-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={
                        s <= Math.round(culturalSignals.avgRating)
                          ? 'w-5 h-5 fill-amber-400 text-amber-400'
                          : 'w-5 h-5 text-muted-foreground/30'
                      }
                    />
                  ))}
                  <span className="ml-2 text-sm font-semibold tabular-nums">
                    {culturalSignals.avgRating.toFixed(1)}
                  </span>
                </div>
                <div className="text-xs text-muted-foreground">
                  На основе {culturalSignals.count}{' '}
                  {culturalSignals.count === 1
                    ? 'отзыва'
                    : culturalSignals.count < 5
                      ? 'отзывов'
                      : 'отзывов'}{' '}
                  verified сотрудников
                </div>
              </div>
            </div>
          </SectionCard>
        )}

        {/* === CTA === */}
        <section className="rounded-2xl bg-gradient-to-br from-[#1e3a8a] to-emerald-700 text-white p-6 sm:p-8 text-center">
          <Sparkles className="w-8 h-8 mx-auto mb-3 opacity-90" />
          <h2 className="text-xl sm:text-2xl font-bold mb-2">
            Хотите работать с {company.name}?
          </h2>
          <p className="text-white/85 text-sm sm:text-base mb-5 max-w-xl mx-auto">
            BizON — профессиональная сеть, где репутация компаний и кандидатов подтверждается
            действиями. Откройте профиль компании в BizON, чтобы увидеть больше кейсов,
            вакансий и отзывов сотрудников.
          </p>
          <a
            href="/"
            className="inline-flex items-center gap-2 px-6 py-3 text-base font-semibold bg-white text-[#1e3a8a] rounded-lg hover:bg-white/90 transition shadow-lg"
          >
            Открыть в BizON <ArrowRight className="w-4 h-4" />
          </a>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t bg-card/50 mt-auto">
        <div className="max-w-5xl mx-auto px-4 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground text-center sm:text-left">
            <span className="font-semibold text-foreground">{company.name}</span> · Company Passport
            <span className="block text-xs mt-0.5">
              Powered by{' '}
              <a
                href="/"
                className="font-semibold text-[#1e3a8a] dark:text-blue-400 hover:underline"
              >
                BizON
              </a>{' '}
              · Verified reputation, not social credit.
            </span>
          </div>
          <div className="text-xs text-muted-foreground/70">
            Сгенерирован {new Date(passport.generatedAt).toLocaleString('ru-RU')}
          </div>
        </div>
      </footer>
    </div>
  );
}

// ---------- sub-components ----------

const SIZE_LABELS: Record<string, string> = {
  '1-10': '1–10 сотрудников',
  '11-50': '11–50 сотрудников',
  '51-200': '51–200 сотрудников',
  '201-1000': '201–1000 сотрудников',
  '1000+': '1000+ сотрудников',
};

function LogoBlock({ name, logoUrl }: { name: string; logoUrl: string | null }) {
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase() ?? '')
    .join('');
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={`Логотип ${name}`}
        width={96}
        height={96}
        className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-background shadow-md flex-shrink-0"
      />
    );
  }
  return (
    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gradient-to-br from-[#1e3a8a] to-emerald-700 text-white flex items-center justify-center text-2xl font-bold shadow-md flex-shrink-0">
      {initials || '?'}
    </div>
  );
}

function TrustIndexBar({
  label,
  value,
  Icon,
  color,
}: {
  label: string;
  value: number;
  Icon: React.ComponentType<{ className?: string }>;
  color: string;
}) {
  const pct = Math.round(value);
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Icon className="w-3 h-3" />
          {label}
        </span>
        <span className="text-xs font-bold tabular-nums">{pct}</span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${color} transition-all`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function SectionCard({
  icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border bg-card shadow-sm">
      <div className="px-5 sm:px-6 pt-5 pb-3 border-b">
        <div className="flex items-center gap-2">
          {icon}
          <h2 className="text-base sm:text-lg font-bold">{title}</h2>
        </div>
        {subtitle && <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      <div className="p-5 sm:p-6">{children}</div>
    </section>
  );
}

function ProjectCard({ project }: { project: PassportProject }) {
  const tags = project.tags
    ? project.tags.split(',').map((t) => t.trim()).filter(Boolean).slice(0, 4)
    : [];
  return (
    <article className="rounded-xl border bg-background p-4 hover:shadow-sm transition">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="font-semibold text-sm leading-snug">{project.title}</h3>
        <span className="text-xs px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 whitespace-nowrap flex items-center gap-0.5">
          <CheckCircle2 className="w-3 h-3" />
          Кейс
        </span>
      </div>
      {project.outcome && (
        <p className="text-xs text-foreground/80 mt-1 leading-relaxed bg-muted/40 rounded px-2 py-1.5">
          {project.outcome}
        </p>
      )}
      {project.rating > 0 && (
        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
          <span className="font-semibold tabular-nums">{project.rating.toFixed(1)}</span>
          <span>/ 5.0</span>
        </div>
      )}
      {tags.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {tags.map((t, i) => (
            <span key={i} className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
              {t}
            </span>
          ))}
        </div>
      )}
      {project.completedAt && (
        <div className="text-xs text-muted-foreground mt-2">
          Завершён {new Date(project.completedAt).toLocaleDateString('ru-RU')}
        </div>
      )}
    </article>
  );
}

const VERIFICATION_LABELS: Record<string, string> = {
  draft: 'Черновик',
  posted: 'Опубликована',
  verified: 'Verified Vacancy',
};

function VacancyCard({ vacancy }: { vacancy: PassportVacancy }) {
  const salary = formatSalary(vacancy);
  const vLabel = VERIFICATION_LABELS[vacancy.verificationStatus] ?? vacancy.verificationStatus;
  const isVerified = vacancy.verificationStatus === 'verified';
  return (
    <article className="rounded-xl border bg-background p-4 hover:shadow-sm transition">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="font-semibold text-sm leading-snug line-clamp-2">{vacancy.title}</h3>
        {isVerified && (
          <span className="inline-flex items-center gap-0.5 text-xs px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 whitespace-nowrap">
            <BadgeCheck className="w-3 h-3" /> Verified
          </span>
        )}
      </div>
      <p className="text-xs text-muted-foreground line-clamp-2">{vacancy.description}</p>
      {salary && (
        <div className="text-sm font-semibold text-foreground mt-2 tabular-nums">{salary}</div>
      )}
      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2 flex-wrap">
        {vacancy.location && (
          <span className="flex items-center gap-0.5">
            <MapPin className="w-3 h-3" /> {vacancy.location}
          </span>
        )}
        {vacancy.boosted && (
          <span className="flex items-center gap-0.5 text-amber-700 dark:text-amber-300">
            <Sparkle className="w-3 h-3" /> Boosted
          </span>
        )}
        <span className="px-1.5 py-0.5 rounded bg-muted">{vLabel}</span>
      </div>
    </article>
  );
}

function formatSalary(v: PassportVacancy): string | null {
  const min = v.salaryMin ?? v.salaryFrom;
  const max = v.salaryMax ?? v.salaryTo;
  if (min != null && max != null) {
    return `${Number(min).toLocaleString('ru-RU')}–${Number(max).toLocaleString('ru-RU')} ₽`;
  }
  if (min != null) return `от ${Number(min).toLocaleString('ru-RU')} ₽`;
  if (max != null) return `до ${Number(max).toLocaleString('ru-RU')} ₽`;
  return null;
}

// ---------- NotFoundCard (без раскрытия) ----------

function NotFoundCard() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <nav className="border-b bg-card/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
          <a href="/" className="text-2xl font-extrabold tracking-tight">
            <span className="text-[#1e3a8a] dark:text-blue-400">Biz</span>
            <span className="text-emerald-700 dark:text-emerald-500">ON</span>
          </a>
          <a
            href="/"
            className="px-4 py-1.5 text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition flex items-center gap-1.5"
          >
            Открыть в BizON <ArrowRight className="w-3.5 h-3.5" />
          </a>
        </div>
      </nav>
      <main className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="max-w-md w-full text-center">
          <div className="w-16 h-16 mx-auto rounded-full bg-muted flex items-center justify-center mb-4">
            <ShieldCheck className="w-8 h-8 text-muted-foreground" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Company Passport не найден</h1>
          <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
            Ссылка недействительна или владелец отключил публичный паспорт компании.
            Это могло произойти, если ссылка была перегенерирована или срок её действия истёк.
          </p>
          <a
            href="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition"
          >
            Перейти на BizON <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </main>
      <footer className="border-t bg-card/50 mt-auto py-6 text-center text-xs text-muted-foreground">
        BizON · Verified reputation, not social credit.
      </footer>
    </div>
  );
}
