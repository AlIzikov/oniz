// BizON — 404 страница с маяком
import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-6 p-6">
      {/* Лого маяка */}
      <div className="w-24 h-24 rounded-2xl overflow-hidden shadow-lg">
        <img src="/lighthouse-logo.jpg" alt="BizON" className="w-full h-full object-cover" />
      </div>

      {/* Туман — маяк временно недоступен */}
      <div className="text-center">
        <div className="text-6xl font-bold text-muted-foreground/30">404</div>
        <h1 className="text-xl font-semibold mt-2">Свет маяка не достиг этой страницы</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Возможно, страница была перемещена или удалена.
        </p>
      </div>

      <Link
        href="/"
        className="px-6 py-2.5 rounded-lg lighthouse-gradient text-white font-medium hover:opacity-90 transition"
      >
        Вернуться к маяку
      </Link>

      <p className="text-xs text-muted-foreground">
        BizON — Маяк в цифровом мире
      </p>
    </div>
  );
}
