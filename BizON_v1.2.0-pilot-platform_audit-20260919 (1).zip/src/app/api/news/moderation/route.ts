// BizON API — /api/news/moderation (admin only)
// Этап 5.1 — NB блок: список pending NewsCard для модератора.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли

// NewsCardPublic отсутствует в '@/lib/types' — локальный контракт Этапа 5.1 (NB блок)
interface NewsCardPublic {
  id: string;
  url: string;
  title: string;
  description: string | null;
  imageUrl: string | null;
  aiSummary: string;
  tags: string[];
  sourceDomain: string;
  publishedAt: string;
  category: string;
  advertiserId: string | null;
  advertiserName: string | null;
  erirToken: string | null;
  recommendedBy: string | null;
  recommendedType: string | null;
}

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  if (!isAdminRole(user.roles)) return errorJson('Доступ только для администратора', 403);

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 50), 100);
  const offset = Math.max(Number(req.nextUrl.searchParams.get('offset') ?? 0), 0);
  const status = req.nextUrl.searchParams.get('status') ?? 'pending';

  const cards = await db.newsCard.findMany({
    where: { status },
    orderBy: [{ createdAt: 'desc' }],
    take: limit,
    skip: offset,
  });

  const result: NewsCardPublic[] = cards.map((c) => ({
    id: c.id,
    url: c.url,
    title: c.title,
    description: c.description,
    imageUrl: c.imageUrl,
    aiSummary: c.aiSummary,
    tags: c.tags ? JSON.parse(c.tags) : [],
    sourceDomain: c.sourceDomain,
    publishedAt: c.publishedAt.toISOString(),
    category: c.category,
    advertiserId: c.advertiserId,
    advertiserName: c.advertiserName,
    erirToken: c.erirToken,
    recommendedBy: c.recommendedBy,
    recommendedType: c.recommendedType,
  }));

  return json({ items: result, total: result.length });
}
