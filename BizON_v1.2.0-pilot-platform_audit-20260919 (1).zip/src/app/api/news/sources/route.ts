// BizON API — /api/news/sources (Этап 5.1)
// Управление источниками новостей:
//   • individual: сохраняет в user.newsSources (до 5 URL — блог, Twitter и пр.)
//   • company / hr_agency: сохраняет в company.newsSources (до 5 URL компании)
//
// Body: { sources: string[] } — массив URL (до 5, каждый ≤ 2048 символов, http/https)
//
// 9-c (doc_a §14-15 «News Bridge: прозрачность источников»): GET расширен
// АДДИТИВНО — прежнее поле `sources` не изменено (обратная совместимость),
// добавлены блоки для UI-транспарентности ленты:
//   • active.own         — источники текущего пользователя (= sources)
//   • active.companies   — компании с подключёнными newsSources (id/name/domains)
//   • active.platform    — базовый пул BizON из scripts/cron-fetch-news.js
//   • companyDomains     — плоский маппинг домен → компания (для бейджей у новостей)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isUrlSafeForStorage } from '@/lib/security/ssrf';

export const runtime = 'nodejs';

const MAX_SOURCES = 5;
const MAX_URL_LENGTH = 2048;

// Базовый пул BizON — зеркало FALLBACK_SOURCES из scripts/cron-fetch-news.js
// (vc.ru, habr.com, rb.ru). Именно он питает ленту, когда ни у пользователя,
// ни у компаний нет подключённых RSS.
const PLATFORM_POOL: { domain: string; label: string }[] = [
  { domain: 'vc.ru', label: 'vc.ru' },
  { domain: 'habr.com', label: 'Хабр' },
  { domain: 'rb.ru', label: 'rb.ru' },
];

// Извлечение домена из URL (без www, lowercase). Некорректный URL → null.
function extractDomain(url: string): string | null {
  try {
    const u = new URL(url);
    return u.hostname.replace(/^www\./, '').toLowerCase() || null;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Для individual — берём из user.newsSources
  // Для company/hr_agency — берём из company.newsSources (если есть companyId)
  let sources: string[] = [];
  if (user.accountType === 'individual') {
    // newsSources есть в схеме User, но отсутствует в auth-DTO — читаем из БД
    const dbUser = await db.user.findUnique({
      where: { id: user.id },
      select: { newsSources: true },
    });
    if (dbUser?.newsSources) {
      try { sources = JSON.parse(dbUser.newsSources); } catch { sources = []; }
    }
  } else if (user.companyId) {
    const company = await db.company.findUnique({ where: { id: user.companyId }, select: { newsSources: true } });
    if (company?.newsSources) {
      try { sources = JSON.parse(company.newsSources); } catch { sources = []; }
    }
  }

  sources = Array.isArray(sources) ? sources : [];

  // === 9-c: компании-источники ленты (Company.newsSources) ===
  // Читаем все компании с непустым newsSources и разбираем URL → домены.
  let companies: { id: string; name: string; domains: string[]; sourceCount: number }[] = [];
  const companyDomains: { domain: string; companyId: string; companyName: string }[] = [];
  try {
    const rows = await db.company.findMany({
      where: { newsSources: { not: null } },
      select: { id: true, name: true, newsSources: true },
    });
    for (const c of rows) {
      let urls: string[] = [];
      try { urls = c.newsSources ? JSON.parse(c.newsSources) : []; } catch { urls = []; }
      if (!Array.isArray(urls) || urls.length === 0) continue;
      const domains = urls
        .map((u) => extractDomain(String(u)))
        .filter((d): d is string => Boolean(d));
      const unique = Array.from(new Set(domains));
      if (unique.length === 0) continue;
      companies.push({ id: c.id, name: c.name, domains: unique, sourceCount: urls.length });
      for (const d of unique) {
        companyDomains.push({ domain: d, companyId: c.id, companyName: c.name });
      }
    }
  } catch {
    // Транспарентность — не критичный путь: при ошибке просто отдаём пустые списки.
    companies = [];
  }

  return json({
    sources,
    active: {
      own: sources,
      companies,
      platform: PLATFORM_POOL,
    },
    companyDomains,
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  let body: any = null;
  try { body = await req.json(); } catch { return errorJson('Некорректный JSON', 400); }

  const raw = body?.sources;
  if (!Array.isArray(raw)) {
    return errorJson('sources должен быть массивом URL', 422);
  }
  if (raw.length > MAX_SOURCES) {
    return errorJson(`Максимум ${MAX_SOURCES} источников`, 422);
  }

  // Валидация каждого URL
  const sources: string[] = [];
  for (const url of raw) {
    if (typeof url !== 'string' || url.length === 0) continue;
    if (url.length > MAX_URL_LENGTH) {
      return errorJson(`URL слишком длинный (>${MAX_URL_LENGTH} символов): ${url.slice(0, 60)}...`, 422);
    }
    try {
      const u = new URL(url);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') {
        return errorJson(`Протокол ${u.protocol} не разрешён (только http/https): ${url}`, 422);
      }
    } catch {
      return errorJson(`Некорректный URL: ${url}`, 422);
    }
    // SSRF-проверка — не разрешаем сохранять приватные URL в БД
    const safe = await isUrlSafeForStorage(url);
    if (!safe) {
      return errorJson(`URL указывает на приватную сеть и не может быть сохранён: ${url}`, 422);
    }
    sources.push(url.trim());
  }

  const jsonSources = JSON.stringify(sources);

  if (user.accountType === 'individual') {
    await db.user.update({ where: { id: user.id }, data: { newsSources: jsonSources } });
  } else if (user.companyId) {
    // Проверяем, что пользователь принадлежит компании
    await db.company.update({ where: { id: user.companyId }, data: { newsSources: jsonSources } });
  } else {
    return errorJson('У вас нет привязанной компании. Сначала создайте/привяжите компанию в профиле.', 422);
  }

  return json({ ok: true, sources });
}
