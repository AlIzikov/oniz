// BizON API — /api/news
// Этап 5.1 — NB блок: список опубликованных NewsCard для ленты.
// Параметры: category (news | ad | industry), limit, offset
// Возвращает карточки со status='published', отсортированные по publishedAt desc.
// Wave 15: поле platformRecommended — первая неделя после публикации карточка
// помечается платформенной рекомендацией «Рекомендовано BizON».
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { NewsScoreService } from '@/lib/services/news-score-service';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

// NewsCardPublic отсутствует в '@/lib/types' — локальный контракт Этапа 5.1 (NB блок)
interface NewsCardPublic {
  id: string;
  url: string;
  title: string;
  description: string | null;
  imageUrl: string | null;
  aiSummary: string;
  tags: string[];
  sourceDomain: string;
  publishedAt: string;
  category: string;
  advertiserId: string | null;
  advertiserName: string | null;
  erirToken: string | null;
  recommendedBy: string | null;
  recommendedType: string | null;
  platformRecommended: boolean;
  // W4.3: BizON News Score (0..100) и факторы — объяснимое ранжирование ленты
  newsScore?: number;
  newsScoreFactors?: {
    relevance: number; authority: number; freshness: number;
    engagement: number; bizonRelevance: number; quality: number;
  };
}

export const runtime = 'nodejs';

const MAX_LIMIT = 50;
// Окошко платформенной рекомендации: неделя с момента публикации
const BIZON_RECOMMEND_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 20), MAX_LIMIT);
  const offset = Math.max(Number(req.nextUrl.searchParams.get('offset') ?? 0), 0);
  const category = req.nextUrl.searchParams.get('category'); // news | ad | industry

  const where: any = { status: 'published' };
  if (category) where.category = category;

  const cards = await db.newsCard.findMany({
    where,
    orderBy: [{ publishedAt: 'desc' }],
    take: limit,
    skip: offset,
  });

  // W4.3: BizON News Score — серверный детерминированный скор (0..100) для
  // РАНЖИРОВАНИЯ ленты. Экосистемная составляющая считается батчем ниже.
  const scored = await Promise.all(
    cards.map(async (c) => ({
      card: c,
      scored: await NewsScoreService.computeWithEcosystem({
        tags: c.tags,
        sourceDomain: c.sourceDomain,
        category: c.category,
        publishedAt: c.publishedAt,
        description: c.description,
        aiSummary: c.aiSummary,
        status: c.status,
      }),
    })),
  );
  scored.sort((a, b) => b.scored.score - a.scored.score);

  const now = Date.now();
  const result: NewsCardPublic[] = scored.map(({ card: c, scored: sc }) => ({
    id: c.id,
    url: c.url,
    title: c.title,
    description: c.description,
    imageUrl: c.imageUrl,
    aiSummary: c.aiSummary,
    tags: c.tags ? JSON.parse(c.tags) : [],
    sourceDomain: c.sourceDomain,
    publishedAt: c.publishedAt.toISOString(),
    category: c.category,
    advertiserId: c.advertiserId,
    advertiserName: c.advertiserName,
    erirToken: c.erirToken,
    recommendedBy: c.recommendedBy,
    recommendedType: c.recommendedType,
    // Первая неделя после публикации — BizON рекомендует новость всем
    platformRecommended: now - c.publishedAt.getTime() < BIZON_RECOMMEND_WINDOW_MS,
    // W4.3: скор и его факторы (объяснимое ранжирование, не «магическое число»)
    newsScore: sc.score,
    newsScoreFactors: sc.factors,
  }));

  return json({ items: result, total: result.length });
}
