// BizON API — /api/news/recommend
// Wave 15 — «Поделиться новостью»: пользователь направляет NewsCard конкретному
// пользователю. Создаёт NewsShare (адресную рекомендацию — видна ТОЛЬКО получателю
// в его ленте с атрибуцией «Рекомендовано {имя отправителя}») + Notification.
// Повторная отправка той же карточки тому же получателю — идемпотентна (upsert).
// FIX-07: withRoute — auth 401, zod-схема recommendNews (whitelist, strip),
// единый маппинг ошибок; без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { nameToInstrumental } from '@/lib/russian-cases';

export const runtime = 'nodejs';

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const { newsCardId, toUserId, message } = ctx.data as {
      newsCardId: string;
      toUserId: string;
      message?: string;
    };

    if (toUserId === user.id) {
      return errorJson('Нельзя рекомендовать самому себе', 422);
    }
    const trimmedMessage = typeof message === 'string' ? message.trim().slice(0, 500) : '';

    // Проверяем, что карточка существует и опубликована
    const card = await db.newsCard.findUnique({ where: { id: newsCardId } });
    if (!card) return errorJson('Карточка не найдена', 404);
    if (card.status !== 'published') return errorJson('Карточка не опубликована', 422);

    // Проверяем, что получатель существует
    const toUser = await db.user.findUnique({ where: { id: toUserId }, select: { id: true, name: true } });
    if (!toUser) return errorJson('Получатель не найден', 404);

    // Адресная рекомендация: повторная отправка той же карточки тому же получателю
    // НЕ создаёт дубль и НЕ спамит уведомлением (идемпотентность)
    const existing = await db.newsShare.findUnique({
      where: { cardId_fromUserId_toUserId: { cardId: newsCardId, fromUserId: user.id, toUserId } },
    });

    const share = existing
      ? await db.newsShare.update({
          where: { id: existing.id },
          data: { message: trimmedMessage || undefined },
        })
      : await db.newsShare.create({
          data: { cardId: newsCardId, fromUserId: user.id, toUserId, message: trimmedMessage || null },
        });

    // Уведомление получателю — только при первой отправке
    if (!existing) {
      const notif = await db.notification.create({
        data: {
          userId: toUserId,
          type: 'news_recommended',
          title: `${user.name} рекомендует новость`,
          content: trimmedMessage || card.title,
          link: '/feed',
        },
      }).catch(() => null);
      if (notif) notifyNotificationNew(toUserId, notif);
    }

    return json({
      ok: true,
      shareId: share.id,
      notified: toUser.name,
      attribution: `Рекомендовано ${nameToInstrumental(user.name)}`,
      alreadyShared: Boolean(existing),
    });
  },
  { schema: schemas.recommendNews, rateLimit: { key: 'news:recommend', limit: 10, windowMs: 60 * 60 * 1000 } },
);
