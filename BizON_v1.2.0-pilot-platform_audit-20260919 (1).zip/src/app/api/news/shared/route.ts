// BizON API — /api/news/shared
// Wave 15 — «Поделиться новостью»: список новостей, которые отправили ТЕКУЩЕМУ
// пользователю (адресные рекомендации). Рендерится в ленте блоком «Рекомендовано вам»
// с атрибуцией «Рекомендовано {имя отправителя}» и комментарием отправителя.
// Платформенная рекомендация «Рекомендовано BizON» живёт 7 дней с публикации
// (platformRecommended) — видна на любых свежих карточках без адресной атрибуции.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const MAX_LIMIT = 30;

// Окошко платформенной рекомендации: неделя с момента публикации
export const BIZON_RECOMMEND_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

interface SharedCardPublic {
  shareId: string;
  message: string | null;
  sharedAt: string;
  fromUser: { id: string; name: string; title: string | null; avatarUrl: string | null; ipScore: number };
  card: {
    id: string;
    url: string;
    title: string;
    description: string | null;
    imageUrl: string | null;
    aiSummary: string;
    tags: string[];
    sourceDomain: string;
    publishedAt: string;
    category: string;
    platformRecommended: boolean;
  };
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 10), MAX_LIMIT);

  const shares = await db.newsShare.findMany({
    where: { toUserId: user.id, card: { status: 'published' } },
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: {
      fromUser: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true } },
      card: true,
    },
  });

  const now = Date.now();
  const items: SharedCardPublic[] = shares.map((s) => ({
    shareId: s.id,
    message: s.message,
    sharedAt: s.createdAt.toISOString(),
    fromUser: {
      id: s.fromUser.id,
      name: s.fromUser.name,
      title: s.fromUser.title,
      avatarUrl: s.fromUser.avatarUrl,
      ipScore: s.fromUser.ipScore,
    },
    card: {
      id: s.card.id,
      url: s.card.url,
      title: s.card.title,
      description: s.card.description,
      imageUrl: s.card.imageUrl,
      aiSummary: s.card.aiSummary,
      tags: s.card.tags ? JSON.parse(s.card.tags) : [],
      sourceDomain: s.card.sourceDomain,
      publishedAt: s.card.publishedAt.toISOString(),
      category: s.card.category,
      // Первая неделя после публикации — BizON рекомендует новость всем
      platformRecommended: now - s.card.publishedAt.getTime() < BIZON_RECOMMEND_WINDOW_MS,
    },
  }));

  return json({ items, total: items.length });
}
