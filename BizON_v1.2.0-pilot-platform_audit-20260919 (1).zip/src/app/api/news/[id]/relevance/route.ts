// BizON API — /api/news/[id]/relevance
// P0: «Почему это важно для вас» — AI-связь новости с профилем пользователя.
//
// Логика:
//   1. Auth required (cookie 'bizon_session' или Authorization: Bearer).
//   2. Загружаем новость по id.
//   3. Загружаем профиль пользователя (навыки, компания, проекты, employments).
//   4. Пытаемся через LLM (z-ai-web-dev-sdk) — даёт тонкие причины.
//   5. При ошибке LLM — fallback на детерминированную эвристику:
//      • Сравниваем tags новости с user skills
//      • Сравниваем sourceDomain с user companies (website)
//      • Сравниваем категорию / текст новости с user industry
//      • Сравниваем tags новости с project tags/requiredSkills
//   6. Возвращаем { relevant: boolean, reasons: [{ type, text, action? }] }
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { NewsRelevanceService } from '@/lib/services/news-relevance-service';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(_req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const result = await NewsRelevanceService.analyze(user.id, id);
    return json(result);
  } catch (e: any) {
    console.error('[/api/news/[id]/relevance] error:', e?.message ?? e);
    // Graceful degradation: возвращаем non-relevant, чтобы UI не падал.
    return json({ relevant: false, reasons: [], engine: 'heuristic' as const });
  }
}
