// BizON API — /api/news/[id]/moderate (admin only)
// Этап 5.1 — NB блок: модератор публикует/отклоняет/перегенерирует AI-резюме.
// Body: { action: 'publish' | 'reject' | 'regenerate' }
// Task 4-h: LLM-перегенерация резюме идёт через AIGateway (rate limit, кэш,
// Sovereignty); прямой вызов z-ai-web-dev-sdk остался только внутри llm-колбэка.
import { getZaiClient as getZai, type ZaiClient } from '@/lib/ai-core/llm-client'; // W1.6: SDK только в ai-core

import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers'; // FIX-07: withRoute
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { schemas } from '@/lib/validation';
import { AIGateway } from '@/lib/ai-core';

// NewsCardPublic — локальная версия (контракт Этапа 5.1, отсутствует в '@/lib/types').
interface NewsCardPublic {
  id: string;
  url: string;
  title: string;
  description: string | null;
  imageUrl: string | null;
  aiSummary: string;
  tags: string[];
  sourceDomain: string;
  publishedAt: string;
  category: string;
  advertiserId: string | null;
  advertiserName: string | null;
  erirToken: string | null;
  recommendedBy: string | null;
  recommendedType: string | null;
}



function errMessage(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/**
 * AI-резюме новости через AIGateway (операция 'news.summary').
 * @param userId — актёр, запустивший перегенерацию (админ): на нём вешается rate limit.
 * Данные (title/description) — публичный контент новости (класс C), PII не содержит.
 * cacheTtlMs: 0 — «regenerate» семантически требует СВЕЖИЙ ответ, кэш отключён.
 */
async function generateNewsSummary(
  userId: string,
  title: string,
  description?: string | null,
): Promise<string> {
  try {
    const result = await AIGateway.run<string>({
      userId,
      operation: 'news.summary',
      fields: [],
      priority: 'normal',
      cacheTtlMs: 0,
      data: { title, description: description ?? '' },
      llm: async () => {
        try {
          const zai = await getZai();
          const response = await zai.chat.completions.create({
            messages: [
              {
                role: 'user',
                content: `Сделай краткое резюме этой статьи в 50-100 символов на русском: ${title} ${description ?? ''}`.slice(0, 1500),
              },
            ],
            thinking: { type: 'disabled' },
            temperature: 0.3,
            max_tokens: 120,
          });
          const content = (response.choices?.[0]?.message?.content ?? '').trim();
          if (!content) return title.slice(0, 100);
          // Усекаем до 100 символов и обрезаем по последнему пробелу (без разрыва слова)
          const truncated = content.slice(0, 100);
          const lastSpace = truncated.lastIndexOf(' ');
          const summary = lastSpace > 40 ? truncated.slice(0, lastSpace) : truncated;
          // Минимум 50 символов — если меньше, дополняем из title
          if (summary.length < 50) {
            return (summary + ' ' + title).slice(0, 100).trim();
          }
          return summary;
        } catch (e: unknown) {
          console.error('[AI-News-Summary] LLM error:', errMessage(e));
          return null; // → gateway fallback
        }
      },
      fallback: () => {
        // Fallback: усечённое title + description
        const fb = `${title} ${description ?? ''}`.slice(0, 100).trim();
        return fb || title.slice(0, 100);
      },
    });
    return result?.value ?? title.slice(0, 100); // null = rate limit gateway
  } catch (e: unknown) {
    console.error('[AI-News-Summary] gateway error:', errMessage(e));
    return title.slice(0, 100);
  }
}

export const runtime = 'nodejs';

function toPublic(c: any): NewsCardPublic {
  return {
    id: c.id,
    url: c.url,
    title: c.title,
    description: c.description,
    imageUrl: c.imageUrl,
    aiSummary: c.aiSummary,
    tags: c.tags ? JSON.parse(c.tags) : [],
    sourceDomain: c.sourceDomain,
    publishedAt: c.publishedAt.toISOString(),
    category: c.category,
    advertiserId: c.advertiserId,
    advertiserName: c.advertiserName,
    erirToken: c.erirToken,
    recommendedBy: c.recommendedBy,
    recommendedType: c.recommendedType,
  };
}

// FIX-07: withRoute — auth 401, zod-схема moderateNews (action whitelist),
// единый маппинг ошибок; без сырых e.message для 5xx.
export const POST = withRoute<{ id: string }>(
  async (req, ctx) => {
    const { id } = ctx.params;
    const user = ctx.user!;
    if (!isAdminRole(user.roles)) return errorJson('Доступ только для администратора', 403);

    const { action } = ctx.data as { action: 'publish' | 'reject' | 'regenerate' };

    const card = await db.newsCard.findUnique({ where: { id } });
    if (!card) return errorJson('Карточка не найдена', 404);

    if (action === 'publish') {
      const updated = await db.newsCard.update({
        where: { id },
        data: { status: 'published' },
      });
      return json({ ok: true, card: toPublic(updated) });
    }

    if (action === 'reject') {
      const updated = await db.newsCard.update({
        where: { id },
        data: { status: 'rejected' },
      });
      return json({ ok: true, card: toPublic(updated) });
    }

    // regenerate — новый LLM-вызов для AI-резюме (через AIGateway, от лица админа)
    const newSummary = await generateNewsSummary(user.id, card.title, card.description);
    const updated = await db.newsCard.update({
      where: { id },
      data: { aiSummary: newSummary },
    });
    return json({ ok: true, card: toPublic(updated) });
  },
  { schema: schemas.moderateNews },
);
