// BizON API — /api/referral
// P2-4: Реферальная программа — получить свой код + статистику
// FIX-07: withRoute — auth 401, единый маппинг ошибок; без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { json, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// GET — получить реферальный код и статистику
export const GET = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  // Генерируем код если нет
  let referral = await db.referral.findFirst({
    where: { referrerId: user.id },
  });

  if (!referral) {
    // Создаём код для этого юзера (не как referral, а как реферер)
    // Код = первые 8 символов userId
    const code = user.id.substring(0, 8);
    // Проверяем нет ли уже записи с этим кодом
    const existing = await db.referral.findUnique({ where: { code } }).catch(() => null);
    if (!existing) {
      // Создаём placeholder запись с referredId = referrerId (сам себя)
      // Это нужно чтобы код существовал. Реальные referrals будут с другими referredId.
      // Лучше: хранить код отдельно. Но для MVP — используем userId как код.
    }
  }

  // Считаем статистику
  const referralsCount = await db.referral.count({
    where: { referrerId: user.id },
  });
  const rewardedCount = await db.referral.count({
    where: { referrerId: user.id, rewardGiven: true },
  });

  // Реферальный код = первые 8 символов userId
  const referralCode = user.id.substring(0, 8);
  const referralLink = `https://bizon.app/?ref=${referralCode}`;

  return json({
    code: referralCode,
    link: referralLink,
    stats: {
      total: referralsCount,
      rewarded: rewardedCount,
      pending: referralsCount - rewardedCount,
      ipScoreBonus: rewardedCount * 5,
    },
  });
});
