// BizON API — /api/hr-organizations
// Phase 2 — HR Organization: кадровое агентство с командой рекрутеров.
//
// POST — создать HrOrganization (только accountType='hr_agency').
//        При создании автоматически создаётся Recruiter для текущего пользователя
//        (он становится «owner-рекрутером» организации).
// GET  — получить текущую организацию пользователя (по recruiter.userId).
//        Если пользователь не рекрутер — возвращает null (организации нет).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';
import { HrTrustService } from '@/lib/services/hr-trust-service';

export const runtime = 'nodejs';

const MAX_NAME_LENGTH = 200;
const MAX_INN_LENGTH = 20;
const MAX_SPECIALIZATION_LENGTH = 200;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Находим recruiter-запись текущего пользователя
  const recruiter = await db.recruiter.findUnique({
    where: { userId: user.id },
    include: {
      organization: {
        select: {
          id: true,
          name: true,
          inn: true,
          isVerified: true,
          verifiedAt: true,
          specialization: true,
          agencyTrust: true,
          createdAt: true,
        },
      },
    },
  });

  if (!recruiter) {
    // Пользователь не привязан к организации
    return json({ organization: null, recruiter: null });
  }

  return json({
    organization: {
      ...recruiter.organization,
      agencyTrust: Math.round(recruiter.organization.agencyTrust * 100) / 100,
      verifiedAt: recruiter.organization.verifiedAt?.toISOString() ?? null,
      createdAt: recruiter.organization.createdAt.toISOString(),
    },
    recruiter: {
      id: recruiter.id,
      recruiterTrust: Math.round(recruiter.recruiterTrust * 100) / 100,
      joinedAt: recruiter.joinedAt.toISOString(),
    },
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только HR-агентство может создать организацию
  if (user.accountType !== 'hr_agency') {
    return errorJson('Только HR-агентства могут создавать организацию', 403);
  }

  // Проверяем, что у пользователя ещё нет организации
  const existing = await db.recruiter.findUnique({
    where: { userId: user.id },
    select: { id: true, organizationId: true },
  });
  if (existing) {
    return errorJson('У вас уже есть организация', 409);
  }

  // Rate limit
  const rl = checkUserRateLimit(
    user.id,
    'hr-organizations:create',
    ...MUTATION_LIMITS.eventsCreate,
  );
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { name, inn, specialization } = body ?? {};

    // === Валидация ===
    if (!name || typeof name !== 'string' || !name.trim() || name.length > MAX_NAME_LENGTH) {
      return errorJson(`name обязателен (макс. ${MAX_NAME_LENGTH} символов)`, 422);
    }
    if (inn !== undefined && inn !== null) {
      if (typeof inn !== 'string' || inn.length > MAX_INN_LENGTH) {
        return errorJson(`inn должен быть строкой (макс. ${MAX_INN_LENGTH} символов)`, 422);
      }
    }
    if (specialization !== undefined && specialization !== null) {
      if (typeof specialization !== 'string' || specialization.length > MAX_SPECIALIZATION_LENGTH) {
        return errorJson(`specialization слишком длинный (макс. ${MAX_SPECIALIZATION_LENGTH})`, 422);
      }
    }

    // Создаём организацию + owner-рекрутера в одной транзакции
    const organization = await db.$transaction(async (tx) => {
      const org = await tx.hrOrganization.create({
        data: {
          name: name.trim(),
          inn: inn?.trim() || null,
          specialization: specialization?.trim() || null,
        },
      });

      // Создаём recruiter-запись для текущего пользователя (owner)
      await tx.recruiter.create({
        data: {
          userId: user.id,
          organizationId: org.id,
        },
      });

      return org;
    });

    // Рассчитываем начальный agencyTrust (0, т.к. placements ещё нет)
    await HrTrustService.calculateAgencyTrust(organization.id).catch((e) =>
      console.error('[hr-organizations/create] agencyTrust calc error:', e),
    );

    return json(
      {
        organization: {
          id: organization.id,
          name: organization.name,
          inn: organization.inn,
          isVerified: organization.isVerified,
          verifiedAt: organization.verifiedAt?.toISOString() ?? null,
          specialization: organization.specialization,
          agencyTrust: organization.agencyTrust,
          createdAt: organization.createdAt.toISOString(),
        },
      },
      201,
    );
  } catch (e) {
    console.error('[hr-organizations/create] error:', e);
    return errorJson('Ошибка создания организации', 500);
  }
}
