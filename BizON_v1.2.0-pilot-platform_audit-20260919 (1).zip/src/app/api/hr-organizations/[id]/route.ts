// BizON API — /api/hr-organizations/[id]
// Phase 2 — детали HR-организации + список recruiters + placements (агрегированно).
//
// GET — детали организации. Доступ: владелец-рекрутер (любой recruiter этой org),
//        либо любой аутентифицированный пользователь (публичный профиль HR).
//        Возвращает: organization, recruiters (с names), placementsCount.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { HrTrustService } from '@/lib/services/hr-trust-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const organization = await db.hrOrganization.findUnique({
    where: { id },
    include: {
      recruiters: {
        select: {
          id: true,
          userId: true,
          recruiterTrust: true,
          joinedAt: true,
          user: {
            select: { id: true, name: true, avatarUrl: true, title: true, isVerified: true },
          },
        },
        orderBy: { joinedAt: 'asc' },
      },
    },
  });

  if (!organization) return errorJson('Организация не найдена', 404);

  // Публичные placements этой организации (агрегированно по всем рекрутерам)
  const recruiterUserIds = organization.recruiters.map((r) => r.userId);
  const placements = await db.placement.findMany({
    where: {
      hrAgencyId: { in: recruiterUserIds },
      isPublic: true,
    },
    orderBy: { placedAt: 'desc' },
    take: 50,
    include: {
      company: { select: { id: true, name: true, logoUrl: true, industry: true } },
      candidate: { select: { id: true, name: true, avatarUrl: true, title: true } },
    },
  });

  // Является ли текущий пользователь рекрутером этой организации
  const isMember = organization.recruiters.some((r) => r.userId === user.id);

  // Если владелец/рекрутер — пересчитываем agencyTrust в фоне
  if (isMember) {
    HrTrustService.calculateAgencyTrust(organization.id).catch(() => {});
  }

  return json({
    organization: {
      id: organization.id,
      name: organization.name,
      inn: organization.inn,
      isVerified: organization.isVerified,
      verifiedAt: organization.verifiedAt?.toISOString() ?? null,
      specialization: organization.specialization,
      agencyTrust: Math.round(organization.agencyTrust * 100) / 100,
      createdAt: organization.createdAt.toISOString(),
    },
    isMember,
    recruiters: organization.recruiters.map((r) => ({
      id: r.id,
      userId: r.userId,
      recruiterTrust: Math.round(r.recruiterTrust * 100) / 100,
      joinedAt: r.joinedAt.toISOString(),
      user: r.user,
    })),
    placements: placements.map((p) => ({
      id: p.id,
      candidateName: p.candidateName,
      jobTitle: p.jobTitle,
      placedAt: p.placedAt.toISOString(),
      confirmedByCandidate: p.confirmedByCandidate,
      confirmedByCompany: p.confirmedByCompany,
      isPublic: p.isPublic,
      company: p.company,
      candidate: p.candidateId ? p.candidate : null,
    })),
  });
}
