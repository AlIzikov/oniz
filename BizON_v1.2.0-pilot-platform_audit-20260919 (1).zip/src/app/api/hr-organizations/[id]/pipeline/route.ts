// BizON API — /api/hr-organizations/[id]/pipeline
// Phase 2 — список placements организации по статусам.
//
// GET — возвращает placements всех рекрутеров организации, сгруппированные по
//        статусам: confirmed (обе стороны подтвердили), pending (ждёт), rejected (нет).
//        Доступ: рекрутеры организации (полная картина) или аутентифицированные
//        пользователи (только публичные placements).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id: organizationId } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const organization = await db.hrOrganization.findUnique({
    where: { id: organizationId },
    include: {
      recruiters: {
        select: { userId: true },
      },
    },
  });
  if (!organization) return errorJson('Организация не найдена', 404);

  // Является ли текущий пользователь рекрутером этой организации
  const isMember = organization.recruiters.some((r) => r.userId === user.id);
  const recruiterUserIds = organization.recruiters.map((r) => r.userId);

  const placements = await db.placement.findMany({
    where: {
      hrAgencyId: { in: recruiterUserIds },
      // Если не member — только публичные
      ...(isMember ? {} : { isPublic: true }),
    },
    orderBy: { placedAt: 'desc' },
    take: 200,
    include: {
      hrAgency: { select: { id: true, name: true, avatarUrl: true } },
      company: { select: { id: true, name: true, logoUrl: true, industry: true } },
      candidate: { select: { id: true, name: true, avatarUrl: true, title: true } },
    },
  });

  // Группировка по статусам
  const pipeline = {
    confirmed: placements.filter(
      (p) => p.confirmedByCandidate && p.confirmedByCompany,
    ),
    pendingCandidate: placements.filter(
      (p) => !p.confirmedByCandidate,
    ),
    pendingCompany: placements.filter(
      (p) => p.confirmedByCandidate && !p.confirmedByCompany,
    ),
  };

  const toPublic = (p: typeof placements[number]) => ({
    id: p.id,
    candidateName: p.candidateName,
    jobTitle: p.jobTitle,
    placedAt: p.placedAt.toISOString(),
    confirmedByCandidate: p.confirmedByCandidate,
    confirmedByCompany: p.confirmedByCompany,
    isPublic: p.isPublic,
    hrAgency: p.hrAgency,
    company: p.company,
    candidate: p.candidateId ? p.candidate : null,
  });

  return json({
    isMember,
    counts: {
      confirmed: pipeline.confirmed.length,
      pendingCandidate: pipeline.pendingCandidate.length,
      pendingCompany: pipeline.pendingCompany.length,
      total: placements.length,
    },
    pipeline: {
      confirmed: pipeline.confirmed.map(toPublic),
      pendingCandidate: pipeline.pendingCandidate.map(toPublic),
      pendingCompany: pipeline.pendingCompany.map(toPublic),
    },
  });
}
