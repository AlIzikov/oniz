// BizON API — /api/hr-organizations/[id]/recruiters
// Phase 2 — добавить рекрутера в организацию.
//
// POST — только existing-рекрутер организации может приглашать новых.
//        Body: { userId } — должен быть accountType='hr_agency' и не быть
//        уже рекрутером другой организации.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id: organizationId } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Проверяем, что текущий пользователь — рекрутер этой организации
  const currentRecruiter = await db.recruiter.findFirst({
    where: { userId: user.id, organizationId },
    select: { id: true },
  });
  if (!currentRecruiter) {
    return errorJson('Вы не являетесь рекрутером этой организации', 403);
  }

  // Проверяем существование организации
  const organization = await db.hrOrganization.findUnique({
    where: { id: organizationId },
    select: { id: true, name: true },
  });
  if (!organization) return errorJson('Организация не найдена', 404);

  // Rate limit
  const rl = checkUserRateLimit(
    user.id,
    'hr-organizations:recruiters:add',
    ...MUTATION_LIMITS.eventsCreate,
  );
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { userId } = body ?? {};

    if (!userId || typeof userId !== 'string') {
      return errorJson('userId обязателен', 422);
    }

    // Целевой пользователь должен быть HR-агентством
    const targetUser = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, accountType: true },
    });
    if (!targetUser) return errorJson('Пользователь не найден', 404);
    if (targetUser.accountType !== 'hr_agency') {
      return errorJson('Можно добавлять только HR-агентства', 422);
    }
    if (targetUser.id === user.id) {
      return errorJson('Вы уже рекрутер этой организации', 422);
    }

    // Проверяем, что пользователь ещё не привязан к другой организации
    const existingRecruiter = await db.recruiter.findUnique({
      where: { userId: targetUser.id },
      select: { id: true, organizationId: true },
    });
    if (existingRecruiter) {
      return errorJson('Пользователь уже является рекрутером другой организации', 409);
    }

    const recruiter = await db.recruiter.create({
      data: {
        userId: targetUser.id,
        organizationId,
      },
      include: {
        user: {
          select: { id: true, name: true, avatarUrl: true, title: true, isVerified: true },
        },
      },
    });

    // Уведомляем нового рекрутера
    await db.notification
      .create({
        data: {
          userId: targetUser.id,
          type: 'hr_placement',
          title: 'Вас добавили в HR-организацию',
          content: `Вы стали рекрутером в «${organization.name}». Теперь ваши placements засчитываются в Agency Trust организации.`,
          link: '/dashboard',
        },
      })
      .catch((e) => console.error('[hr-organizations/recruiters] notification error:', e));

    return json(
      {
        recruiter: {
          id: recruiter.id,
          userId: recruiter.userId,
          recruiterTrust: recruiter.recruiterTrust,
          joinedAt: recruiter.joinedAt.toISOString(),
          user: recruiter.user,
        },
      },
      201,
    );
  } catch (e) {
    console.error('[hr-organizations/recruiters/create] error:', e);
    return errorJson('Ошибка добавления рекрутера', 500);
  }
}
