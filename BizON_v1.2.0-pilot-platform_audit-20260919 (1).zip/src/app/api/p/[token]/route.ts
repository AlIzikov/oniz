// BizON API — GET /api/p/[token]
// P0-4: Professional Passport — публичный endpoint (без auth).
//
// Возвращает verified репутацию пользователя по непредсказуемому token.
// Принципы приватности:
//   • Без auth — любой с ссылкой может посмотреть
//   • Без email / phone / location / birthday
//   • Без IP-score ЧИСЛО — только level (basic | extended | expert)
//   • Если passportEnabled=false → 404 (без раскрытия, что юзер существует)
//
// Anti-scraping:
//   • token — 64 hex символа (32 байта энтропии) — неперебираемый
//   • Не отдаём userId в ответе (по нему нельзя деанонимизировать)
//   • Cache-Control: public, max-age=300 — кэшируется на 5 минут (но token в URL — приватный)
//
// Используется:
//   • Публичной страницей /p/[token] (server component fetch)
//   • Внешними потребителями (если кто-то встроит iframe / API)

import { NextRequest } from 'next/server';
import { json, errorJson } from '@/lib/api-helpers';
import { PassportService } from '@/lib/services';

export const runtime = 'nodejs';
// Публичный endpoint — кэшируем на 5 мин (token в URL = приватный, но ответ статичен)
export const revalidate = 300;

export async function GET(_req: NextRequest, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;

  if (!token || typeof token !== 'string' || token.length < 16) {
    return errorJson('Passport не найден', 404);
  }

  const passport = await PassportService.getByToken(token);
  if (!passport) {
    // Та же ошибка что и для невалидного token — не раскрываем существование
    return errorJson('Passport не найден', 404);
  }

  return json(passport, 200, {
    headers: {
      'Cache-Control': 'public, max-age=300',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
