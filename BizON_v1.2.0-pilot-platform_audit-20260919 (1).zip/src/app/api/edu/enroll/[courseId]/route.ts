// BizON API — /api/edu/enroll/[courseId] (Этап 5.5 — EDU)
// POST — записать текущего пользователя на курс.
// Уникальное ограничение (userId, courseId) обеспечивается на уровне схемы.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ courseId: string }> }) {
  const { courseId } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'edu:enroll', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson(`Слишком много записей. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const course = await db.course.findUnique({ where: { id: courseId } });
  if (!course) return errorJson('Курс не найден', 404);

  // Если уже записан — возвращаем существующую запись (идемпотентность)
  const existing = await db.userCourse.findUnique({
    where: { userId_courseId: { userId: user.id, courseId } },
  }).catch(() => null);

  if (existing) {
    return json({
      enrollment: {
        id: existing.id,
        status: existing.status,
        startedAt: existing.startedAt.toISOString(),
        completedAt: existing.completedAt?.toISOString() ?? null,
        certificateNftId: existing.certificateNftId,
      },
      alreadyEnrolled: true,
    });
  }

  const enrollment = await db.userCourse.create({
    data: {
      userId: user.id,
      courseId,
      status: 'in_progress',
    },
  });

  // Создаём notification для пользователя (для RT/SSE проверки)
  const notif = await db.notification.create({
    data: {
      userId: user.id,
      type: 'system',
      title: 'Вы записались на курс',
      content: `Курс «${course.title}» от ${course.provider} добавлен в ваш список обучения.`,
      link: null,
    },
  }).catch((e) => {
    console.error('[edu/enroll] notification create failed:', e);
    return null;
  });
  if (notif) notifyNotificationNew(user.id, notif);

  return json({
    enrollment: {
      id: enrollment.id,
      status: enrollment.status,
      startedAt: enrollment.startedAt.toISOString(),
      completedAt: enrollment.completedAt?.toISOString() ?? null,
      certificateNftId: enrollment.certificateNftId,
    },
    alreadyEnrolled: false,
  }, 201);
}
