// BizON API — /api/edu/complete/[userCourseId] (Этап 5.5 — EDU)
// POST — отметить курс завершённым. Если у пользователя есть NFT-инфраструктура —
// попытаться выдать NFT-сертификат (заглушка: генерируем локальный ID, т.к.
// on-chain minting требует web3-провайдера и выходит за рамки этапа 5.5).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ userCourseId: string }> }) {
  const { userCourseId } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'edu:complete', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const enrollment = await db.userCourse.findUnique({
    where: { id: userCourseId },
    include: { course: true },
  });
  if (!enrollment) return errorJson('Запись на курс не найдена', 404);
  if (enrollment.userId !== user.id) {
    return errorJson('Можно завершать только свои курсы', 403);
  }

  if (enrollment.status === 'completed') {
    return json({
      enrollment: {
        id: enrollment.id,
        status: enrollment.status,
        startedAt: enrollment.startedAt.toISOString(),
        completedAt: enrollment.completedAt?.toISOString() ?? null,
        certificateNftId: enrollment.certificateNftId,
      },
      alreadyCompleted: true,
    });
  }

  // Заглушка NFT-сертификата: генерируем локальный ID (в проде — mint on Polygon).
  // Это позволяет UI показывать «сертификат получен» без интеграции с web3.
  const certificateNftId = `bizon-edu-cert-${enrollment.id}-${Date.now().toString(36)}`;

  const updated = await db.userCourse.update({
    where: { id: userCourseId },
    data: {
      status: 'completed',
      completedAt: new Date(),
      certificateNftId,
    },
  });

  // Уведомление о завершении + выданном сертификате
  const notif = await db.notification.create({
    data: {
      userId: user.id,
      type: 'system',
      title: 'Курс завершён 🎓',
      content: `Поздравляем! Курс «${enrollment.course.title}» завершён. NFT-сертификат: ${certificateNftId}`,
      link: null,
    },
  }).catch((e) => {
    console.error('[edu/complete] notification create failed:', e);
    return null;
  });
  if (notif) notifyNotificationNew(user.id, notif);

  return json({
    enrollment: {
      id: updated.id,
      status: updated.status,
      startedAt: updated.startedAt.toISOString(),
      completedAt: updated.completedAt!.toISOString(),
      certificateNftId: updated.certificateNftId,
    },
    certificateNftId,
    alreadyCompleted: false,
  });
}
