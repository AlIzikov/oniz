// BizON API — /api/edu/recommendations (Этап 5.5 — EDU)
// Анализирует Truth Gap текущего пользователя и возвращает 3-5 курсов из каталога.
// Логика:
//   1. Загружаем userSkills, выделяем слабые (verifiedScore < selfAssessment, или verificationLevel='claimed').
//   2. Загружаем каталог курсов (Course).
//   3. Вызываем AI-рекомендатель (lib/ai.ts -> runEduRecommender).
//   4. Возвращаем рекомендованные курсы + rationale.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { runEduRecommender } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Rate limit (используем AI-лимит по тарифу)
  const [max, windowMs] = getAiLimitKey('career', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:edu:recommendations', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит рекомендаций исчерпан (${max} в час). Повторите через ${rl.retryAfter} секунд.`,
      429
    );
  }

  try {
    // 1. Слабые навыки пользователя (Truth Gap)
    const userSkills = await db.userSkill.findMany({
      where: { userId: user.id },
      include: { skill: true },
    });

    // Truth Gap — навыки, где:
    //   - selfAssessment !== null && verifiedScore !== null && verifiedScore < selfAssessment
    //   - ИЛИ verificationLevel === 'claimed' (нет подтверждений)
    const weakSkills = userSkills
      .filter((us) => {
        if (us.verificationLevel === 'claimed') return true;
        if (
          us.selfAssessment !== null &&
          us.verifiedScore !== null &&
          us.verifiedScore < us.selfAssessment
        ) {
          return true;
        }
        return false;
      })
      .map((us) => ({
        name: us.skill.name,
        selfAssessment: us.selfAssessment,
        verifiedScore: us.verifiedScore,
        verificationLevel: us.verificationLevel,
      }))
      .slice(0, 30); // лимит для контекста LLM

    // 2. Каталог курсов
    const courses = await db.course.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100, // ограничиваем для контекста
    });

    // 3. AI-рекомендации
    const result = await runEduRecommender({
      userName: user.name,
      userTitle: user.title,
      weakSkills,
      catalog: courses.map((c) => ({
        id: c.id,
        title: c.title,
        provider: c.provider,
        category: c.category,
        url: c.url,
        durationHours: c.durationHours,
      })),
    });

    // 4. Подгружаем полные объекты рекомендованных курсов + статус записи пользователя
    const recommendedCourses = await db.course.findMany({
      where: { id: { in: result.courseIds } },
      include: {
        enrollments: {
          where: { userId: user.id },
          select: { id: true, status: true, completedAt: true, certificateNftId: true, startedAt: true },
        },
      },
    });

    // Сохраняем порядок рекомендаций как их вернул AI
    const ordered = result.courseIds
      .map((id) => recommendedCourses.find((c) => c.id === id))
      .filter(Boolean)
      .map((c) => ({
        id: c!.id,
        title: c!.title,
        provider: c!.provider,
        providerId: c!.providerId,
        url: c!.url,
        durationHours: c!.durationHours,
        category: c!.category,
        // enrollments[0] — это запись текущего пользователя (если есть)
        enrollment: c!.enrollments[0]
          ? {
              id: c!.enrollments[0].id,
              status: c!.enrollments[0].status,
              startedAt: c!.enrollments[0].startedAt.toISOString(),
              completedAt: c!.enrollments[0].completedAt?.toISOString() ?? null,
              certificateNftId: c!.enrollments[0].certificateNftId,
            }
          : null,
      }));

    return json({
      courses: ordered,
      rationale: result.rationale,
      engine: result.engine,
      weakSkillsCount: weakSkills.length,
    });
  } catch (e: any) {
    console.error('[edu/recommendations] error:', e);
    return errorJson('Ошибка подбора курсов. Попробуйте позже.', 500);
  }
}
