// BizON API — /api/edu/courses (Этап 5.5 — EDU)
// GET — список курсов с опциональным фильтром по category (?category=IT).
// POST — admin: создание нового курса в каталоге.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли

export const runtime = 'nodejs';

const ALLOWED_PROVIDERS = new Set([
  'Coursera',
  'Udemy',
  'Skillbox',
  'BizON Academy',
  'Stepik',
  'edX',
  'Pluralsight',
]);

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const category = req.nextUrl.searchParams.get('category')?.trim() || undefined;
  const provider = req.nextUrl.searchParams.get('provider')?.trim() || undefined;
  const q = req.nextUrl.searchParams.get('q')?.trim() || undefined;

  const where: any = {};
  if (category) where.category = category;
  if (provider) where.provider = provider;
  if (q) {
    where.title = { contains: q };
  }

  const courses = await db.course.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      enrollments: {
        where: { userId: user.id },
        select: { id: true, status: true, completedAt: true, startedAt: true, certificateNftId: true },
      },
    },
  });

  return json({
    courses: courses.map((c) => ({
      id: c.id,
      title: c.title,
      provider: c.provider,
      providerId: c.providerId,
      url: c.url,
      durationHours: c.durationHours,
      category: c.category,
      createdAt: c.createdAt.toISOString(),
      enrollment: c.enrollments[0]
        ? {
            id: c.enrollments[0].id,
            status: c.enrollments[0].status,
            startedAt: c.enrollments[0].startedAt.toISOString(),
            completedAt: c.enrollments[0].completedAt?.toISOString() ?? null,
            certificateNftId: c.enrollments[0].certificateNftId,
          }
        : null,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только admin может создавать курсы в каталоге (FIX-02: isAdminRole)
  if (!isAdminRole(user.roles)) {
    return errorJson('Только администратор может добавлять курсы в каталог', 403);
  }

  try {
    const body = await req.json();
    const {
      title,
      provider,
      providerId,
      url,
      durationHours,
      category,
    } = body ?? {};

    // Валидация
    if (typeof title !== 'string' || title.trim().length === 0 || title.length > 300) {
      return errorJson('title обязателен (строка 1-300 символов)', 422);
    }
    if (typeof provider !== 'string' || !ALLOWED_PROVIDERS.has(provider)) {
      return errorJson(
        `provider должен быть одним из: ${Array.from(ALLOWED_PROVIDERS).join(', ')}`,
        422
      );
    }
    if (typeof url !== 'string' || url.length === 0 || url.length > 2048) {
      return errorJson('url обязателен (строка до 2048 символов)', 422);
    }
    try {
      const u = new URL(url);
      if (u.protocol !== 'https:' && u.protocol !== 'http:') {
        return errorJson('url должен быть http/https', 422);
      }
    } catch {
      return errorJson('Некорректный url', 422);
    }
    if (typeof category !== 'string' || category.trim().length === 0 || category.length > 100) {
      return errorJson('category обязателен (строка 1-100 символов)', 422);
    }
    if (durationHours !== undefined && durationHours !== null) {
      const n = Number(durationHours);
      if (!Number.isFinite(n) || n < 0 || n > 10000) {
        return errorJson('durationHours должен быть числом 0-10000', 422);
      }
    }
    if (providerId !== undefined && providerId !== null) {
      if (typeof providerId !== 'string' || providerId.length > 200) {
        return errorJson('providerId должен быть строкой до 200 символов', 422);
      }
    }

    const course = await db.course.create({
      data: {
        title: title.trim(),
        provider,
        providerId: providerId?.trim() || null,
        url: url.trim(),
        durationHours: durationHours != null ? Number(durationHours) : null,
        category: category.trim(),
      },
    });

    return json({ course }, 201);
  } catch (e) {
    console.error('[edu/courses/create] error:', e);
    return errorJson('Ошибка создания курса', 500);
  }
}
