// BizON API — /api/events
// Использует EventService (микросервисный слой)
//
// fix-adversarial (ADV-B112, red team): POST мигрирован в withRoute —
// zod-схема (title ≤200, description ≤5000, maxParticipants — положительное
// целое), URL-гейт isUrlSafeForStorage для imageUrl (запрет javascript:/data:/
// приватных сетей), санитайзер пользовательского текста. Мусорный вход → 4xx,
// а не 500; XSS/протокол-носители не сохраняются.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { getUserFromRequest } from '@/lib/auth';
import { EventService } from '@/lib/services';
import { isUrlSafeForStorage } from '@/lib/security/ssrf';
import { sanitizeUserText } from '@/lib/sanitize';
import { z } from 'zod';

export const runtime = 'nodejs';

const targetingSchema = z.object({
  skills: z.array(z.string().trim().min(1).max(50)).max(20).optional(),
  industries: z.array(z.string().trim().min(1).max(50)).max(20).optional(),
  locations: z.array(z.string().trim().min(1).max(100)).max(20).optional(),
});

const createEventSchema = z.object({
  title: z.string().trim().min(1).max(200),
  description: z.string().trim().min(1).max(5000),
  format: z.enum(['online', 'offline', 'hybrid']).optional(),
  category: z.string().trim().max(50).optional(),
  startDate: z.string().min(1),
  endDate: z.string().optional(),
  location: z.string().max(200).optional(),
  imageUrl: z.string().max(2048).optional(),
  maxParticipants: z.number().int().positive().max(1_000_000).optional(),
  companyId: z.string().max(64).optional(),
  targeting: targetingSchema.optional(),
  // Wave 3 S-063: цена участия / внешняя регистрация / черновик / спикеры
  priceLumens: z.number().int().min(0).max(100_000).optional(),
  registrationUrl: z.string().max(2048).optional(),
  asDraft: z.boolean().optional(),
  speakers: z
    .array(z.object({ name: z.string().trim().min(1).max(120), title: z.string().trim().max(160).optional() }))
    .max(10)
    .optional(),
});

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const sp = req.nextUrl.searchParams;
  const format = sp.get('format') ?? undefined;
  const category = sp.get('category') ?? undefined;
  const q = sp.get('q') ?? undefined;

  // Wave 3 S-066: поиск по 5 полям (q) ИЛИ обычный список; S-067: напоминания
  const events = q
    ? await EventService.search(user.id, q, format ?? undefined, category ?? undefined)
    : await EventService.list(user.id, format ?? undefined, category ?? undefined);
  const remindersSent = await EventService.checkReminders(user.id).catch(() => 0);

  return json({
    remindersSent,
    events: events.map((e: any) => ({
      id: e.id,
      title: e.title,
      description: e.description,
      format: e.format,
      category: e.category,
      startDate: e.startDate.toISOString(),
      endDate: e.endDate?.toISOString() ?? null,
      location: e.location,
      imageUrl: e.imageUrl,
      maxParticipants: e.maxParticipants,
      trustScore: e.trustScore,
      targeting: e.targeting ? JSON.parse(e.targeting) : null,
      // Wave 3 S-063: цена/внешняя регистрация/lifecycle/спикеры
      priceLumens: e.priceLumens,
      registrationUrl: e.registrationUrl,
      status: e.status,
      speakers: e.speakers ?? [],
      company: e.company,
      organizer: e.organizer,
      participantsCount: e._count.participants,
      myStatus: e.participants.length > 0 ? e.participants[0].status : null,
    })),
  });
}

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user;
    if (user.subscriptionTier === 'free') {
      return errorJson('Создание мероприятий доступно на Pro и Business', 403);
    }

    const { title, description, format, category, startDate, endDate, location, imageUrl, maxParticipants, companyId, targeting, priceLumens, registrationUrl, asDraft, speakers } =
      ctx.data as {
        title: string;
        description: string;
        format?: 'online' | 'offline' | 'hybrid';
        category?: string;
        startDate: string;
        endDate?: string;
        location?: string;
        imageUrl?: string;
        maxParticipants?: number;
        companyId?: string;
        targeting?: { skills?: string[]; industries?: string[]; locations?: string[] };
        priceLumens?: number;
        registrationUrl?: string;
        asDraft?: boolean;
        speakers?: Array<{ name: string; title?: string }>;
      };

    // Wave 2 S-041: Premium-таргетинг — только платным тарифам (создание
    // мероприятия уже Pro/Business, но явный гейт честнее при будущих изменениях).
    let targetingJson: string | null = null;
    if (targeting && (targeting.skills?.length || targeting.industries?.length || targeting.locations?.length)) {
      targetingJson = JSON.stringify({
        skills: (targeting.skills ?? []).map(sanitizeUserText),
        industries: (targeting.industries ?? []).map(sanitizeUserText),
        locations: (targeting.locations ?? []).map(sanitizeUserText),
      });
    }

    // fix-adversarial (ADV-B112): валидность дат — new Date('garbage') → NaN →
    // Invalid Date в БД; невалидная дата → 422.
    const start = new Date(startDate);
    if (Number.isNaN(start.getTime())) return errorJson('startDate — некорректная дата', 422);
    let endDateNorm: Date | null = null;
    if (endDate) {
      const end = new Date(endDate);
      if (Number.isNaN(end.getTime())) return errorJson('endDate — некорректная дата', 422);
      endDateNorm = end;
    }

    // fix-adversarial (ADV-B112): URL-гейт — javascript:/data:/приватные сети
    let safeImageUrl: string | null = null;
    if (imageUrl) {
      const isSafe = await isUrlSafeForStorage(imageUrl);
      if (!isSafe) {
        return errorJson('URL изображения небезопасен (приватная сеть или запрещённый протокол)', 422);
      }
      safeImageUrl = imageUrl;
    }

    const event = await db.event.create({
      data: {
        // fix-adversarial (ADV-B112): stored-XSS носители вырезаются на входе
        title: sanitizeUserText(title),
        description: sanitizeUserText(description),
        format: format ?? 'online',
        category: category ?? 'meetup',
        startDate: start,
        endDate: endDateNorm,
        location: location ? sanitizeUserText(location) : null,
        imageUrl: safeImageUrl,
        maxParticipants: maxParticipants ?? null,
        organizerId: user.id,
        companyId: companyId ?? null,
        targeting: targetingJson,
        priceLumens: priceLumens && priceLumens > 0 ? priceLumens : null,
        registrationUrl: registrationUrl ? sanitizeUserText(registrationUrl) : null,
        status: asDraft ? 'draft' : 'published',
        trustScore: 0.5 + (user.ipScore / 200),
      },
    });

    // Спикеры (S-063): после создания события
    if (speakers && speakers.length > 0) {
      await EventService.setSpeakers(user.id, event.id, speakers).catch(() => undefined);
    }

    return json({ event }, 201);
  },
  { schema: createEventSchema },
);
