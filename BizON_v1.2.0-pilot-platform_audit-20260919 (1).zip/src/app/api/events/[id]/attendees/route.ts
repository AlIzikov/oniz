// BizON API — /api/events/[id]/attendees
// Этап 7.1 EVT: список участников мероприятия (для блока «С кем вы пересеклись?»).
// Возвращает участников со status = 'going' и флаг isPast (мероприятие уже прошло).
//
// GET /api/events/[id]/attendees
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { EventService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const result = await EventService.list(user.id);
    return json(result);
  } catch (e: any) {
    return errorJson(e.message ?? 'Мероприятие не найдено', 404);
  }
}
