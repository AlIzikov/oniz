// BizON API — /api/events/[id]/cancel (Wave 3, S-064): отмена + уведомление «going».
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { EventService } from '@/lib/services/event-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const event = await EventService.cancelEvent(ctx.user.id, ctx.params.id);
  return NextResponse.json({ id: event.id, status: event.status });
}, { rateLimit: { key: 'event-cancel', limit: 30, windowMs: 60 * 60 * 1000 } });
