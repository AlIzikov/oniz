// BizON API — /api/events/[id]/publish (Wave 3, S-064): черновик → опубликовано.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { EventService } from '@/lib/services/event-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const event = await EventService.publishEvent(ctx.user.id, ctx.params.id);
  return NextResponse.json({ id: event.id, status: event.status });
}, { rateLimit: { key: 'event-publish', limit: 30, windowMs: 60 * 60 * 1000 } });
