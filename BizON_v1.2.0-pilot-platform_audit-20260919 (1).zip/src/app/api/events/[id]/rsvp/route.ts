// BizON API — /api/events/[id]/rsvp
// Использует EventService
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { EventService } from '@/lib/services';
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { sanitizeUserText } from '@/lib/sanitize';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { status } = body ?? {};
    if (!['going', 'interested', 'not_going'].includes(status)) {
      return errorJson('status: going | interested | not_going', 422);
    }
    const wasNew = !(await db.eventParticipant.findUnique({
      where: { eventId_userId: { eventId: id, userId: user.id } },
    }).catch(() => null));
    const event_ = await db.event.findUnique({ where: { id }, select: { organizerId: true, title: true } });
    await EventService.rsvp(id, user.id, status);

    // Направление В: организатору — уведомление о первом RSVP участника
    // (повторные смены статуса не спамят). Live-пуш — рельсы направления Б.
    if (wasNew && event_?.organizerId && event_.organizerId !== user.id) {
      const statusText = status === 'going' ? 'идёт' : status === 'interested' ? 'заинтересован' : 'отказался';
      const notif = await db.notification.create({
        data: {
          userId: event_.organizerId,
          type: 'event_rsvp',
          title: `${user.name} — ${statusText} на «${sanitizeUserText(event_.title).slice(0, 80)}»`,
          content: status === 'going' ? 'Участник подтвердил участие.' : status === 'interested' ? 'Участник отметил интерес.' : null,
          link: '/events',
        },
      }).catch(() => null);
      if (notif) notifyNotificationNew(event_.organizerId, notif);
    }

    return json({ status });
  } catch (e: any) {
    return errorJson(e.message, 400);
  }
}
