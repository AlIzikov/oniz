// BizON API — /api/reputation/evidence
// GPT Truth Engine (B1/A4): aggregated evidence для пользователя
// Возвращает ipScore, level, breakdown, evidence (verifiedProjects/Skills, recommendations, claims),
// evidenceCoverage (0-1)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // userId из query (?userId=...) или текущий пользователь
  const targetUserId = req.nextUrl.searchParams.get('userId') ?? user.id;

  const fullUser = await db.user.findUnique({
    where: { id: targetUserId },
    select: { id: true, ipScore: true, level: true },
  });
  if (!fullUser) return errorJson('Пользователь не найден', 404);

  // === breakdown (как в recomputeIpScore, но без записи в БД) ===
  const [memberships, ratings, skillsRaw, activity] = await Promise.all([
    db.projectMember.findMany({
      where: { userId: targetUserId },
      include: { project: { select: { status: true, rating: true, id: true, title: true } } },
    }),
    db.projectMember.findMany({
      where: { userId: targetUserId, project: { status: 'completed' } },
      select: { project: { select: { rating: true } } },
    }),
    db.userSkill.findMany({
      where: { userId: targetUserId },
      include: { skill: true, confirmations: { select: { confirmerId: true } } },
    }),
    db.reputationEvent.count({
      where: {
        userId: targetUserId,
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
  ]);

  const totalProjects = memberships.length;
  const completedProjects = memberships.filter((m) => m.project.status === 'completed');
  const A = totalProjects === 0 ? 0 : completedProjects.length / Math.max(3, totalProjects);

  const ratingValues = ratings.map((r) => r.project.rating).filter((r) => r > 0);
  const avgRating = ratingValues.length === 0
    ? 0
    : ratingValues.reduce((a, b) => a + b, 0) / ratingValues.length;
  const B = avgRating / 5;

  const totalConfirmations = skillsRaw.reduce((sum, s) => sum + s.confirmationsCount, 0);
  const C = Math.log1p(totalConfirmations) / Math.log1p(20);

  const D = Math.min(activity / 7, 1);

  const ipScore = fullUser.ipScore;
  const level = fullUser.level as 'basic' | 'extended' | 'expert';

  // === evidence ===
  // verifiedProjects: завершённые проекты с rating > 0
  const verifiedProjects = completedProjects
    .filter((m) => m.project.rating > 0)
    .map((m) => ({
      id: m.project.id,
      title: m.project.title,
      rating: m.project.rating,
      role: m.role,
    }));

  // verifiedSkills: userSkills с хотя бы одним подтверждением
  const verifiedSkills = skillsRaw
    .filter((s) => s.confirmationsCount > 0)
    .map((s) => ({
      id: s.id,
      skill: s.skill.name,
      level: s.level,
      confirmationsCount: s.confirmationsCount,
      verificationLevel: s.verificationLevel,
      selfAssessment: s.selfAssessment,
      verifiedScore: s.verifiedScore,
    }));

  // recommendations: уникальные пользователи, подтвердившие ≥1 skill
  const uniqueRecommenders = new Set<string>();
  skillsRaw.forEach((s) => s.confirmations.forEach((c) => uniqueRecommenders.add(c.confirmerId)));
  const recommendations = uniqueRecommenders.size;

  // claims: total / verified / pending
  const claims = await db.claim.findMany({
    where: { userId: targetUserId },
    select: { id: true, status: true, verifications: { select: { status: true } } },
  });
  const claimsTotal = claims.length;
  const claimsVerified = claims.filter((c) => c.status !== 'claimed').length;
  const claimsPending = claims.filter(
    (c) => c.status === 'claimed' || c.verifications.some((v) => v.status === 'pending'),
  ).length;

  // evidenceCoverage: доля claims со статусом выше "claimed"
  const evidenceCoverage = claimsTotal === 0 ? 0 : claimsVerified / claimsTotal;

  return json({
    userId: targetUserId,
    ipScore,
    level,
    breakdown: {
      projects: Number(A.toFixed(3)),
      ratings: Number(B.toFixed(3)),
      skills: Number(C.toFixed(3)),
      activity: Number(D.toFixed(3)),
    },
    evidence: {
      verifiedProjects,
      verifiedSkills,
      recommendations,
      claims: {
        total: claimsTotal,
        verified: claimsVerified,
        pending: claimsPending,
      },
    },
    evidenceCoverage: Number(evidenceCoverage.toFixed(3)),
  });
}
