// BizON API — /api/reputation/recalculate
// Принудительный пересчёт IP-score текущего пользователя
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { recomputeIpScore } from '@/lib/reputation';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const result = await recomputeIpScore(user.id);
  return json({
    userId: user.id,
    ipScore: result.ipScore,
    level: result.level,
    scoreBreakdown: result.breakdown,
  });
}
