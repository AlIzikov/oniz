// BizON API — /api/reputation/snapshots
// GPT Truth Engine (B1): история IP-score для графика
// GET: последние 30 snapshots, POST: создание snapshot (крон / при изменении IP-score)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS, getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { ReputationService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const userId = req.nextUrl.searchParams.get('userId') ?? user.id;

  const snapshots = await db.reputationSnapshot.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take: 30,
  });

  return json({
    snapshots: snapshots.map((s) => ({
      id: s.id,
      ipScore: s.ipScore,
      level: s.level,
      breakdown: {
        projectsScore: s.projectsScore,
        ratingsScore: s.ratingsScore,
        skillsScore: s.skillsScore,
        activityScore: s.activityScore,
      },
      evidenceCoverage: s.evidenceCoverage,
      createdAt: s.createdAt.toISOString(),
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'reputation:snapshot', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    // Пересчитываем IP-score, чтобы получить актуальный breakdown
    const recomputed = await ReputationService.recompute(user.id);
    const breakdown = recomputed.breakdown;

    // evidenceCoverage: доля верифицированных claims
    const claims = await db.claim.findMany({
      where: { userId: user.id },
      select: { status: true },
    });
    const claimsTotal = claims.length;
    const claimsVerified = claims.filter((c) => c.status !== 'claimed').length;
    const evidenceCoverage = claimsTotal === 0 ? 0 : claimsVerified / claimsTotal;

    const snapshot = await db.reputationSnapshot.create({
      data: {
        userId: user.id,
        ipScore: recomputed.ipScore,
        level: recomputed.level,
        projectsScore: Math.round((breakdown.projects ?? 0) * 100),
        ratingsScore: Math.round((breakdown.peerRating ?? 0) * 100),
        skillsScore: Math.round((breakdown.skills ?? 0) * 100),
        activityScore: Math.round((breakdown.activity ?? 0) * 100),
        evidenceCoverage,
      },
    });

    AuditLog.log({
      actorId: user.id,
      action: 'create',
      resource: 'reputation_snapshot',
      resourceId: snapshot.id,
      ip: getClientIP(req),
      metadata: { ipScore: snapshot.ipScore, level: snapshot.level },
    });

    return json({ snapshot }, 201);
  } catch (e) {
    console.error('[reputation/snapshots/create] error:', e);
    return errorJson('Ошибка создания snapshot', 500);
  }
}
