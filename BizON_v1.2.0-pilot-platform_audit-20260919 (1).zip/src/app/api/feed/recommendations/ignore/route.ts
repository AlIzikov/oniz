// BizON API — POST /api/feed/recommendations/ignore
// Правка 4-c — анти-эхо-камера (PDF doc_agents, стр. 23-32).
// Персист кнопки «Не интересно» / «Не моё»: тема сохраняется в IgnoredTopic
// и с этого момента вырезается из выдачи:
//   • /api/feed/recommendations (source='feed', фильтр в GET-роуте);
//   • /api/jobs (source='jobs'|'feed' — v6.1 Task 7-c: по targetId и теме в title).
// Идемпотентно: повторный клик по той же теме — upsert, дубликаты игнорируются.
//
// v6.1 (Task 7-c) — расширение body (Explicit Negative Intent, Стратегия п.14):
//   { topic, itemType?, source?, reason?, targetId? }
//   itemType: job | person | event | company | profession
//   source:   feed | jobs | search | coach (default feed)
//   reason:   salary | location | company | profession | level_low | level_high |
//             travel | schedule | industry | other
//   targetId: id конкретной сущности (null = скрыта тема целиком)
// Ответ прежний: { ok, topic, itemType, source }.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { cache } from '@/lib/cache';
import { validate, z } from '@/lib/validation';

export const runtime = 'nodejs';

const ignoreSchema = z.object({
  topic: z.string().min(1).max(120),
  itemType: z.enum(['job', 'person', 'event', 'company', 'profession']).optional(),
  source: z.enum(['feed', 'jobs', 'search', 'coach']).optional(),
  reason: z
    .enum([
      'salary',
      'location',
      'company',
      'profession',
      'level_low',
      'level_high',
      'travel',
      'schedule',
      'industry',
      'other',
    ])
    .optional(),
  targetId: z.string().max(64).optional(),
});

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }

  const parsed = validate(ignoreSchema, body);
  if (!parsed.ok) {
    return errorJson(
      'topic обязателен (1-120 символов); itemType — job|person|event|company|profession; source — feed|jobs|search|coach; reason — salary|location|company|profession|level_low|level_high|travel|schedule|industry|other; targetId — id сущности',
      422,
    );
  }

  // Нормализация: lowercase + trim — единый формат с фильтром выдачи
  const topic = parsed.data.topic.toLowerCase().trim();
  if (topic.length === 0) return errorJson('topic не может быть пустым', 422);

  const source = parsed.data.source ?? 'feed';

  try {
    await db.ignoredTopic.upsert({
      where: { userId_topic: { userId: user.id, topic } },
      update: {}, // дубликат — ничего не меняем (идемпотентность)
      create: {
        userId: user.id,
        topic,
        source,
        itemType: parsed.data.itemType ?? null,
        reason: parsed.data.reason ?? null,
        targetId: parsed.data.targetId ?? null,
      },
    });
  } catch {
    // Гонка параллельных запросов / конфликт unique — считаем успехом:
    // тема в любом случае присутствует в IgnoredTopic.
  }

  // Инвалидация кэша рекомендаций, чтобы следующий GET пересчитался с фильтром
  cache.delete(`feed-recs:${user.id}`);

  return json({ ok: true, topic, itemType: parsed.data.itemType ?? null, source });
}
