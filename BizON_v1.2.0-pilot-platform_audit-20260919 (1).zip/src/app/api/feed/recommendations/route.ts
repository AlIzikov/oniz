// BizON API — /api/feed/recommendations (Правка 4 — Лента рекомендаций как Vings)
// Правка 4-c — анти-эхо-камера (PDF doc_agents, стр. 23-32):
//   1. Игнорируемые темы (IgnoredTopic, source in ['feed','coach']) вырезаются
//      из всех блоков до выдачи (lowercase + частичное вхождение для составных тем).
//   2. Epsilon-Greedy exploration (~15%): часть карточек заменяется случайными
//      элементами «хвоста» того же пула (не top-N), помечаются exploration/reason.
//   3. Семантическое расширение вакансий 70/20/10: точный навык / синонимы
//      (SkillSynonym, вес 0.5-0.8) / «неожиданные но логичные» (вес <0.4).
// Возвращает 4 массива (по 4 элемента каждый) + единый interleaved-поток:
//   - jobs:       топ-4 вакансии (70% точный навык / 20% синонимы / 10% неожиданные)
//   - people:     4 пользователя с общими контактами (2-е рукопожатия).
//                 Фолбэк: пользователи с высоким IP-score, если общих нет.
//   - events:     ближайшие 4 события (startDate >= now)
//   - companies:  4 компании с лучшим culturalScore (фолбэк: adTrustIndex).
//                 Для каждой — средний рейтинг по CompanyReview и число активных вакансий.
//   - interleaved: те же карточки единым round-robin-потоком (Task 9-a, A4 —
//                 интерливинг источников как в doc_agents стр. 26; каждый элемент
//                 несёт kind + source; поля jobs/people/events/companies сохранены).
//
// Task 9-a (doc_agents, правки A2/A4/A7/B12):
//   - A2 Decay Function: weight = 1/(1 + days_since × 0.1) (doc_agents стр. 25).
//     Применяется к каждому сигналу интереса по его возрасту:
//       • история просмотров (ActionEvent type='job_viewed', createdAt) → implicit-буст;
//       • интересы-навыки (UserSkill.createdAt) → поле interestWeight карточки вакансии
//         и тай-брейкер ранжирования внутри тиров;
//       • SkillSynonym-хиты → semanticWeight тиражируется с decay-весом навыка-
//         источника (в SkillSynonym даты нет — возраст сигнала = возраст навыка юзера).
//   - A7 Implicit feedback: просмотры вакансий временно (decay) повышают вес
//     связанных тем/навыков в персональной ленте (implicitBoost к matchConfidence).
//   - B12(b): подтверждённые инсайты коуча (ActionEvent type='coach_insight_confirmed')
//     поднимают вес связанного контента (coachBoost к matchConfidence, source='coach') —
//     критерий приёмки ТЗ №3 «рекомендации обновляются после подтверждения».
//   - A4 Interleaving: каждая карточка несёт source ('skill' | 'semantic' |
//     'exploration' | 'following' | 'trending' | 'coach') и попадает в единый
//     interleaved-поток (round-robin по блокам; diversity 70/20/10 сохраняется
//     внутри jobs-блока, exploration-механика — поверх).
//
// Task 10-c (doc_agents A7, dwell-time):
//   - Dwell-сигнал: ActionEvent(type='feed_dwell') — агрегированное время
//     просмотра карточек ленты (пишет POST /api/feed/dwell, дедуп 1/карточка/сутки,
//     metadata без PII: itemType/itemId/topic/seconds).
//   - Веса: dwell ≥10с по topic/навыку — полный сигнал, 3..10с — частичный
//     (linear seconds/10), <3с — НЕ сигнал; буст с decay 1/(1+days×0.1)
//     (консистентно с A2/9-a) → поле dwellBoost карточки вакансии к matchConfidence
//     (cap 0.15 — слабее явных просмотров job_viewed, cap которых 0.25).
//   - Обратная совместимость: прежние поля/массивы ответа не изменены; dwellBoost
//     — опциональное поле, отсутствует при нулевом сигнале.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { cache, CACHE_TTL } from '@/lib/cache';
import { detectSphere, tokenizeJobTitle } from '@/lib/services/coach-service';

export const runtime = 'nodejs';

// ============================================================================
// Константы анти-эхо-камеры и весов
// ============================================================================
const DAY_MS = 24 * 60 * 60 * 1000;
/** A2: константа decay-формулы doc_agents: weight = 1/(1 + days_since * 0.1) */
const DECAY_ALPHA = 0.1;
/** A7: окно неявного фидбэка — просмотры вакансий за N дней */
const IMPLICIT_WINDOW_DAYS = 14;
/** A7: коэффициент implicit-буста (cap ниже) — 5 свежих просмотров темы ≈ +0.25 */
const IMPLICIT_BOOST_PER_WEIGHT = 0.05;
const IMPLICIT_BOOST_CAP = 0.25;
/** B12(b): окно действия coach-сигнала и величины буста (детерминированно, без LLM) */
const COACH_WINDOW_DAYS = 30;
const COACH_TOKEN_BOOST = 0.2;   // job_interest:<token> → буст вакансий с этим токеном
const COACH_SPHERE_BOOST = 0.15; // career_shift sphere → буст вакансий той же сферы
/** Окно «истории интересов» (UserSkill.createdAt) — не ограничено, decay сам гасит старое */

// Task 10-c (A7 dwell): параметры dwell-сигнала (feed_dwell)
/** Окно dwell-сигнала — как у явных просмотров (IMPLICIT_WINDOW_DAYS) */
const DWELL_WINDOW_DAYS = 14;
/** dwell ≥10с — полный сигнал интереса; 3..10с — частичный (linear seconds/10) */
const DWELL_FULL_SECONDS = 10;
/** dwell <3с — НЕ сигнал (клик-мимо / случайная прокрутка) */
const DWELL_MIN_SECONDS = 3;
/** dwell-буст: коэффициент и cap (слабее явных просмотров: cap 0.15 vs 0.25) */
const DWELL_BOOST_PER_WEIGHT = 0.05;
const DWELL_BOOST_CAP = 0.15;

// ============================================================================
// Типы карточек. Explorable — поля анти-эхо-камеры (Epsilon-Greedy).
// source (A4) — какой поток рекомендаций поместил карточку в выдачу:
//   skill      — точное совпадение навыка (jobs, tier exact)
//   semantic   — семантическое расширение через синонимы (jobs, tier synonym)
//   exploration— разведка (jobs tier surprise + карточки, заменённые Epsilon-Greedy)
//   following  — социальный граф (люди через общие контакты)
//   trending   — общеплатформенные топы (люди по ipScore, события, компании)
//   coach      — подтверждённый инсайт коуча (B12b)
// ============================================================================
type RecSource = 'skill' | 'semantic' | 'exploration' | 'following' | 'trending' | 'coach';

type Explorable = {
  exploration?: boolean;
  reason?: string;
};

type SemanticTier = 'exact' | 'synonym' | 'surprise';

type JobRec = Explorable & {
  id: string;
  title: string;
  company: string;
  location: string | null;
  // === Этап 5.2 JOB v2: канонические salaryMin/salaryMax, фолбэк на legacy ===
  salaryFrom: number | null;
  salaryTo: number | null;
  currency: string;
  matchConfidence: number;
  companyId: string | null;
  // 70/20/10: из какого тира семантического расширения попала карточка
  semanticTier: SemanticTier;
  // вес семантического расширения (synonym: 0.5-0.8 × decay навыка-источника, surprise: <0.4)
  semanticWeight?: number;
  // === Task 9-a: источник карточки (A4) и decay/буст-разбивка весов (A2/A7/B12) ===
  source: RecSource;
  /** A2: decayed вес совпавших интересов-навыков юзера 1/(1+days×0.1), 0..1 */
  interestWeight?: number;
  /** A7: буст от истории просмотров (decay по ActionEvent.createdAt), 0..0.25 */
  implicitBoost?: number;
  /** B12(b): буст от подтверждённого инсайта коуча, 0.15..0.2 */
  coachBoost?: number;
  /** Task 10-c (A7 dwell): буст от dwell-времени карточек ленты (decay по createdAt), 0..0.15 */
  dwellBoost?: number;
};

type PeopleRec = Explorable & {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  location: string | null;
  level: string;
  ipScore: number;
  companyName: string | null;
  commonContacts: number;
  /** A4: источник карточки (A4) */
  source: RecSource;
};

type EventRec = Explorable & {
  id: string;
  title: string;
  startDate: string;
  endDate: string | null;
  format: string;
  location: string | null;
  organizerName: string;
  participantsCount: number;
  /** A4: источник карточки (A4) */
  source: RecSource;
};

type CompanyRec = Explorable & {
  id: string;
  name: string;
  logoUrl: string | null;
  industry: string | null;
  activeJobsCount: number;
  rating: number | null;
  culturalScore: number;
  /** A4: источник карточки (A4) */
  source: RecSource;
};

/** Элемент единого interleaved-потока (A4, doc_agents стр. 26) */
type InterleavedEntry =
  | { kind: 'job'; source: RecSource; item: JobRec }
  | { kind: 'person'; source: RecSource; item: PeopleRec }
  | { kind: 'event'; source: RecSource; item: EventRec }
  | { kind: 'company'; source: RecSource; item: CompanyRec };

// ============================================================================
// A2: Decay Function из doc_agents (стр. 25): weight = 1/(1 + days_since * 0.1)
//   вчера → 1.0; месяц назад → 0.25; год назад → 0.03.
// ============================================================================
function decayWeight(since: Date, now = Date.now()): number {
  const days = Math.max(0, (now - since.getTime()) / DAY_MS);
  return 1 / (1 + days * DECAY_ALPHA);
}

// ============================================================================
// Анти-эхо-камера: фильтрация игнорируемых тем (IgnoredTopic feed|coach)
// ============================================================================

/** Нормализация тем: lowercase + trim + дедупликация. */
function normalizeIgnoredTopics(rows: Array<{ topic: string }>): string[] {
  const out = new Set<string>();
  for (const r of rows) {
    const t = r.topic.toLowerCase().trim();
    if (t.length > 0) out.add(t);
  }
  return [...out];
}

/**
 * Совпадение текстового поля с игнорируемой темой.
 * Точное равенство работает всегда; частичное вхождение (для составных тем
 * вроде «frontend разработка») — только для тем длиной ≥3, чтобы короткие
 * темы не выкашивали всё подряд (те ловятся точным равенством).
 */
function textMatchesTopic(text: string | null | undefined, topic: string): boolean {
  if (!text) return false;
  const lower = text.toLowerCase();
  if (lower === topic) return true;
  return topic.length >= 3 && lower.includes(topic);
}

/**
 * Совпадение навыка вакансии с темой. Дополнительно к textMatchesTopic
 * проверяет обратное направление для составных тем: тема «frontend js»
 * ловит навык «js».
 */
function skillMatchesTopic(skill: string, topic: string): boolean {
  const s = skill.toLowerCase().trim();
  if (s.length === 0) return false;
  if (s === topic) return true;
  if (topic.length < 3) return false;
  return s.includes(topic) || topic.includes(s);
}

function jobMatchesIgnored(title: string, skills: string[], topics: string[]): boolean {
  for (const t of topics) {
    if (textMatchesTopic(title, t)) return true;
    for (const s of skills) {
      if (skillMatchesTopic(s, t)) return true;
    }
  }
  return false;
}

function matchesIgnoredTopics(texts: Array<string | null | undefined>, topics: string[]): boolean {
  for (const t of topics) {
    for (const text of texts) {
      if (textMatchesTopic(text, t)) return true;
    }
  }
  return false;
}

function parseMetadata(raw: string | null): Record<string, unknown> {
  if (!raw) return {};
  try {
    const parsed: unknown = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}

// ============================================================================
// Семантическое расширение 70/20/10: синонимы навыков пользователя.
// expandSynonyms в semantic-search-service не экспортируется (а модифицировать
// тот файл условиями задачи запрещено), поэтому эквивалентный запрос к
// SkillSynonym выполняется локально: прямое направление (синонимы канонических
// навыков юзера) + обратное (навык юзера зарегистрирован как синоним другого
// канонического навыка → берём его имя).
//
// Task 9-a (A2): возвращается Map<термин, decayed-вес источника> — вес синонима
// наследует возраст сигнала (UserSkill.createdAt навыка, породившего расширение;
// в самой таблице SkillSynonym даты нет). Свежий навык → вес 1.0 (старое
// поведение), годовалый → ~0.5 (умножение в semanticWeight ниже).
// ============================================================================
async function buildSkillSynonymTerms(
  userSkills: Array<{ id: string; name: string; createdAt: Date }>
): Promise<Map<string, number>> {
  const out = new Map<string, number>();
  if (userSkills.length === 0) return out;
  const canonical = new Set(
    userSkills.map((s) => s.name.toLowerCase().trim()).filter((n) => n.length > 0)
  );
  // A2: decayed вес каждого интереса-навыка (источник сигнала расширения)
  const weightBySkillId = new Map(userSkills.map((s) => [s.id, decayWeight(s.createdAt)]));

  const forward = await db.skillSynonym
    .findMany({
      where: { skillId: { in: userSkills.map((s) => s.id) } },
      select: { skillId: true, synonym: true },
    })
    .catch(() => []);
  for (const r of forward) {
    const syn = r.synonym.toLowerCase().trim();
    if (!syn) continue;
    const w = weightBySkillId.get(r.skillId) ?? 1;
    out.set(syn, Math.max(out.get(syn) ?? 0, w));
  }

  const reverse = await db.skillSynonym
    .findMany({
      where: { synonym: { in: [...canonical] } },
      select: { synonym: true, skillId: true },
    })
    .catch(() => []);
  if (reverse.length > 0) {
    // Внимание: SkillSynonym — «плоская» таблица (skillId String, без relation),
    // имена канонических навыков достаём отдельным запросом (как и раньше).
    const canonicalSkills = await db.skill.findMany({
      where: { id: { in: reverse.map((r) => r.skillId) } },
      select: { id: true, name: true },
    });
    const nameById = new Map(canonicalSkills.map((s) => [s.id, s.name.toLowerCase().trim()]));
    // A2: вес обратного направления — decay навыка ЮЗЕРА, зарегистрированного
    // как синоним канонического навыка (r.synonym = имя навыка юзера)
    const weightByLowerName = new Map(
      userSkills.map((s) => [s.name.toLowerCase().trim(), decayWeight(s.createdAt)])
    );
    for (const r of reverse) {
      const name = nameById.get(r.skillId);
      if (!name) continue;
      const w = weightByLowerName.get(r.synonym.toLowerCase().trim()) ?? 1;
      out.set(name, Math.max(out.get(name) ?? 0, w));
    }
  }

  // Канонические имена уже покрыты точным матчем — из синонимов убираем
  for (const c of canonical) out.delete(c);
  return out;
}

// ============================================================================
// 70/20/10: выбор вакансий по тирам
// ============================================================================
type TieredJob = { rec: JobRec; tier: SemanticTier; synHits: number };

/**
 * Ранжирование внутри тира: matchConfidence (уже с implicit/coach-бустами),
 * затем decayed interestWeight (A2: свежие интересы выигрывают ties), затем id
 * (детерминированность при равенстве).
 */
function byRank(a: TieredJob, b: TieredJob): number {
  const d = b.rec.matchConfidence - a.rec.matchConfidence;
  if (d !== 0) return d;
  const dw = (b.rec.interestWeight ?? 0) - (a.rec.interestWeight ?? 0);
  if (dw !== 0) return dw;
  return a.rec.id.localeCompare(b.rec.id);
}
const byWeight = (a: TieredJob, b: TieredJob) =>
  (b.rec.semanticWeight ?? 0) - (a.rec.semanticWeight ?? 0) || byRank(a, b);

/**
 * Раскладывает n слотов: ~70% exact, ~20% synonym, ~10% surprise.
 * Если в тире меньше кандидатов, чем слотов — добивка из более приоритетных
 * тиров (exact → synonym → surprise), чтобы блок всегда был полным.
 */
function selectJobs702010(pool: TieredJob[], n: number): { selected: TieredJob[]; rest: TieredJob[] } {
  const exact = pool.filter((p) => p.tier === 'exact').sort(byRank);
  const synonym = pool.filter((p) => p.tier === 'synonym').sort(byWeight);
  const surprise = pool.filter((p) => p.tier === 'surprise').sort(byRank);

  const exactCount = Math.round(n * 0.7);
  const synCount = Math.min(Math.round(n * 0.2), Math.max(0, n - exactCount));
  const surpriseCount = Math.max(0, n - exactCount - synCount);

  const picked: TieredJob[] = [];
  const pickedIds = new Set<string>();
  const takeFrom = (list: TieredJob[], count: number) => {
    for (const item of list) {
      if (count <= 0 || picked.length >= n) break;
      if (pickedIds.has(item.rec.id)) continue;
      picked.push(item);
      pickedIds.add(item.rec.id);
      count -= 1;
    }
  };
  takeFrom(exact, exactCount);
  takeFrom(synonym, synCount);
  takeFrom(surprise, surpriseCount);
  // Добивка недостающих слотов (пустые тиры не должны оставлять дыры)
  takeFrom(exact, n);
  takeFrom(synonym, n);
  takeFrom(surprise, n);

  const rest = pool.filter((p) => !pickedIds.has(p.rec.id));
  return { selected: picked, rest };
}

// ============================================================================
// Анти-эхо-камера: Epsilon-Greedy exploration (~15%)
// ============================================================================
const EXPLORATION_REASON = 'Случайная находка — расширяем кругозор';

function shuffleIndices(length: number): number[] {
  const a = Array.from({ length }, (_, i) => i);
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a;
}

/**
 * Заменяет до `count` карточек на случайные элементы из «хвоста» того же пула
 * (не top-N). Позиция 0 (лучший match блока) не трогается — разведка
 * вытесняет середину выдачи, а не самое релевантное.
 * Task 9-a (A4): заменённая карточка получила место в выдаче благодаря
 * разведке → её source переключается на 'exploration' (флаг exploration
 * и reason сохраняются).
 */
function applyExploration(
  blocks: Array<Array<Explorable & { source?: RecSource }>>,
  pools: Array<Array<Explorable & { source?: RecSource }>>,
  count: number
): number {
  if (count <= 0) return 0;
  const candidateBlocks = shuffleIndices(blocks.length).filter(
    (i) => blocks[i].length > 1 && pools[i].length > 0
  );
  let replaced = 0;
  for (const bi of candidateBlocks) {
    if (replaced >= count) break;
    const block = blocks[bi];
    const pool = pools[bi];
    const pos = 1 + Math.floor(Math.random() * (block.length - 1));
    const poolIdx = Math.floor(Math.random() * pool.length);
    const item = pool.splice(poolIdx, 1)[0];
    if (!item) continue;
    item.exploration = true;
    item.reason = EXPLORATION_REASON;
    item.source = 'exploration';
    block[pos] = item;
    replaced += 1;
  }
  return replaced;
}

// ============================================================================
// A4: интерливинг источников — round-robin по блокам (jobs → people → events →
// companies). Порядок внутри каждого блока сохраняется, карточки разных
// источников чередуются; diversity 70/20/10 остаётся внутри jobs-блока,
// exploration-замены распределены до интерливинга.
// ============================================================================
function interleaveRoundRobin<T>(lists: T[][]): T[] {
  const maxLen = lists.reduce((m, l) => Math.max(m, l.length), 0);
  const out: T[] = [];
  for (let i = 0; i < maxLen; i++) {
    for (const list of lists) {
      if (i < list.length) out.push(list[i]);
    }
  }
  return out;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Phase 16: кэш 5 минут по userId — рекомендации дорогие (4 блока с JOIN'ами
  // по userSkill/job/connection/event/company). Для пользователя не должны
  // пересчитываться на каждый polling-запрос.
  // Инвалидация: cache.delete(`feed-recs:${user.id}`) при apply-to-job /
  // new-connection / new-skill-confirmation / «Не интересно» (ignore-роут) /
  // job.viewed и intent.changed (Task 9-a: подписчики Event Bus).
  const cacheKey = `feed-recs:${user.id}`;
  const cached = cache.get<unknown>(cacheKey);
  if (cached !== null) return json(cached);

  const result = await computeFeedRecommendations(user.id, user.location);
  cache.set(cacheKey, result, CACHE_TTL.MEDIUM);
  return json(result);
}

async function computeFeedRecommendations(userId: string, userLocation: string | null) {
  // Игнорируемые темы — из фида и коуча (анти-эхо-камера едина для обоих источников)
  // + сигналы для decay-весов: история просмотров (A7) и подтверждённые инсайты (B12b).
  const [userSkills, ignoredRows, viewEvents, coachEvents, dwellEvents] = await Promise.all([
    db.userSkill.findMany({
      where: { userId },
      include: { skill: true },
    }),
    db.ignoredTopic.findMany({
      where: { userId, source: { in: ['feed', 'coach'] } },
      select: { topic: true },
    }),
    // A7: неявный фидбэк — просмотры вакансий за окно (ActionEvent пишет
    // POST /api/jobs/[id]/view, дедуп 1/сутки там же)
    db.actionEvent.findMany({
      where: {
        userId,
        type: 'job_viewed',
        createdAt: { gte: new Date(Date.now() - IMPLICIT_WINDOW_DAYS * DAY_MS) },
      },
      select: { metadata: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      take: 100,
    }),
    // B12(b): подтверждённые инсайты коуча (пишет CoachService.confirmInsight)
    db.actionEvent.findMany({
      where: {
        userId,
        type: 'coach_insight_confirmed',
        createdAt: { gte: new Date(Date.now() - COACH_WINDOW_DAYS * DAY_MS) },
      },
      select: { metadata: true },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
    // Task 10-c (A7 dwell): агрегированное время просмотра карточек ленты
    // (пишет POST /api/feed/dwell; metadata {itemType,itemId,topic,seconds} — без PII)
    db.actionEvent.findMany({
      where: {
        userId,
        type: 'feed_dwell',
        createdAt: { gte: new Date(Date.now() - DWELL_WINDOW_DAYS * DAY_MS) },
      },
      select: { metadata: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      take: 100,
    }),
  ]);
  const ignoredTopics = normalizeIgnoredTopics(ignoredRows);

  // A2: decayed вес каждого интереса-навыка юзера: 1/(1 + days_since × 0.1)
  const skillInterestWeights = new Map<string, number>();
  for (const us of userSkills) {
    const name = us.skill.name.toLowerCase().trim();
    if (!name) continue;
    skillInterestWeights.set(name, Math.max(skillInterestWeights.get(name) ?? 0, decayWeight(us.createdAt)));
  }
  const userSkillSet = new Set(skillInterestWeights.keys());

  const synonymTerms = await buildSkillSynonymTerms(
    userSkills.map((us) => ({ id: us.skillId, name: us.skill.name, createdAt: us.createdAt }))
  );

  // A7: decayed вес темы по истории просмотров: Σ 1/(1+days×0.1) по событиям.
  // Токены — из jobTitle просмотров (контракт metadata с view-роутом, Task 7-c).
  const implicitWeights = new Map<string, number>();
  for (const ev of viewEvents) {
    const jobTitle = parseMetadata(ev.metadata)['jobTitle'];
    if (typeof jobTitle !== 'string' || jobTitle.length === 0) continue;
    const w = decayWeight(ev.createdAt);
    for (const tok of new Set(tokenizeJobTitle(jobTitle))) {
      implicitWeights.set(tok, (implicitWeights.get(tok) ?? 0) + w);
    }
  }

  // B12(b): coach-сигналы — токен job_interest и/или сфера career_shift.
  // При нескольких подтверждениях берём самое свежее (orderBy desc, первый).
  let coachToken: string | null = null;
  let coachSphere: string | null = null;
  for (const ev of coachEvents) {
    const meta = parseMetadata(ev.metadata);
    if (!coachToken && typeof meta.token === 'string' && meta.token.length >= 3) {
      coachToken = meta.token.toLowerCase();
    }
    if (!coachSphere && typeof meta.viewedSphere === 'string' && meta.viewedSphere.length >= 2) {
      coachSphere = meta.viewedSphere;
    }
    if (coachToken && coachSphere) break;
  }

  // Task 10-c (A7 dwell): decayed вес темы по времени просмотра карточек.
  //   dwell ≥10с → strength 1.0; 3..10с → linear (seconds/10); <3с → сигнал отбрасывается
  //   (клик-мимо не должен качать ленту). Вес события = decay(createdAt) × strength.
  // Тема — topic карточки (заголовок вакансии / имя / название): токенизируется так же,
  // как заголовки просмотров (tokenizeJobTitle) + вся строка целиком для точных тем.
  const dwellWeights = new Map<string, number>();
  for (const ev of dwellEvents) {
    const meta = parseMetadata(ev.metadata);
    const seconds = typeof meta.seconds === 'number' && Number.isFinite(meta.seconds) ? meta.seconds : 0;
    if (seconds < DWELL_MIN_SECONDS) continue; // <3с — не бустить (doc_agents A7)
    const topic = typeof meta.topic === 'string' ? meta.topic.trim() : '';
    if (!topic) continue;
    const strength = Math.min(1, seconds / DWELL_FULL_SECONDS); // ≥10с → 1.0
    const w = decayWeight(ev.createdAt) * strength;
    const tokens = new Set<string>([topic.toLowerCase()]);
    for (const tok of tokenizeJobTitle(topic)) tokens.add(tok);
    for (const tok of tokens) {
      if (tok.length < 3) continue; // сверхкороткие токены не бустим (шум)
      dwellWeights.set(tok, (dwellWeights.get(tok) ?? 0) + w);
    }
  }

  // ========================================================================
  // 1) Jobs: 70/20/10 по тирам (точный навык / синонимы / неожиданные)
  // ========================================================================
  const jobsRaw = await db.job.findMany({
    where: { active: true },
    orderBy: { createdAt: 'desc' },
    take: 30,
    include: {
      hiringManager: { select: { id: true, name: true } },
    },
  });

  const tieredJobs: TieredJob[] = [];
  for (const j of jobsRaw) {
    const requiredSkills = j.requiredSkills
      ? j.requiredSkills.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
    // Анти-эхо-камера: скип вакансий по игнорируемой теме (заголовок/навыки)
    if (jobMatchesIgnored(j.title, requiredSkills, ignoredTopics)) continue;

    const jSkillsLower = requiredSkills.map((s) => s.toLowerCase());

    // A2: точные хиты взвешиваются decayed весом интереса (свежий навык → 1.0)
    let exactHits = 0;
    let matchedWeightSum = 0;
    for (const s of jSkillsLower) {
      const w = skillInterestWeights.get(s);
      if (w !== undefined) {
        exactHits += 1;
        matchedWeightSum += w;
      }
    }
    const synHits = jSkillsLower.filter((s) => synonymTerms.has(s)).length;
    // Базовый match: доля требуемых навыков, которые есть у юзера.
    // При свежих навыках (вес 1.0) совпадает со старой формулой exactHits/length.
    const match = requiredSkills.length === 0 ? 0.3 : exactHits / requiredSkills.length;
    // A2: средний decayed вес совпавших интересов — виден в карточке и
    // работает тай-брейкером ранжирования внутри тиров
    const interestWeight = exactHits > 0 ? matchedWeightSum / exactHits : 0;

    // Токены вакансии: навыки + токены заголовка (для implicit/coach-матча)
    const jobTokens = new Set<string>([...jSkillsLower, ...tokenizeJobTitle(j.title)]);

    // A7: implicit-буст от просмотров (decay по возрасту событий)
    let implicitHitWeight = 0;
    for (const tok of jobTokens) {
      const w = implicitWeights.get(tok);
      if (w) implicitHitWeight += w;
    }
    const implicitBoost = Math.min(IMPLICIT_BOOST_CAP, IMPLICIT_BOOST_PER_WEIGHT * implicitHitWeight);

    // B12(b): coach-буст от подтверждённого инсайта
    let coachBoost = 0;
    if (coachToken && jobTokens.has(coachToken)) coachBoost = Math.max(coachBoost, COACH_TOKEN_BOOST);
    if (
      coachSphere &&
      detectSphere(`${j.title} ${requiredSkills.join(' ')}`) === coachSphere
    ) {
      coachBoost = Math.max(coachBoost, COACH_SPHERE_BOOST);
    }

    // Task 10-c (A7 dwell): буст от времени просмотра карточек ленты — по токенам
    // темы (заголовок, навыки, а также dwell на человека/компанию/событие с тем же токеном)
    let dwellHitWeight = 0;
    for (const tok of jobTokens) {
      const w = dwellWeights.get(tok);
      if (w) dwellHitWeight += w;
    }
    const dwellBoost = Math.min(DWELL_BOOST_CAP, DWELL_BOOST_PER_WEIGHT * dwellHitWeight);

    let tier: SemanticTier = 'exact';
    let semanticWeight: number | undefined;
    if (exactHits === 0 && synHits > 0) {
      // 20% — синонимы/смежные навыки; базовый вес 0.5-0.8 × decay навыка-источника
      tier = 'synonym';
      let synSourceWeight = 0;
      for (const s of jSkillsLower) synSourceWeight = Math.max(synSourceWeight, synonymTerms.get(s) ?? 0);
      semanticWeight = Math.min(0.8, Math.max(0.1, (0.5 + 0.15 * synHits) * (0.5 + 0.5 * synSourceWeight)));
    } else if (
      exactHits === 0 &&
      synHits === 0 &&
      userLocation &&
      j.location &&
      j.location.toLowerCase().includes(userLocation.toLowerCase())
    ) {
      // 10% — «неожиданные но логичные»: нет пересечения по навыкам,
      // но совпадает локация пользователя; вес <0.4
      tier = 'surprise';
      semanticWeight = 0.35;
    }

    // A4: source карточки — почему она в выдаче
    const source: RecSource =
      coachBoost > 0 ? 'coach' : tier === 'exact' ? 'skill' : tier === 'synonym' ? 'semantic' : 'exploration';

    tieredJobs.push({
      tier,
      synHits,
      rec: {
        id: j.id,
        title: j.title,
        company: j.company,
        location: j.location,
        salaryFrom: j.salaryMin ?? j.salaryFrom,
        salaryTo: j.salaryMax ?? j.salaryTo,
        currency: j.currency,
        matchConfidence: Math.min(1, match + implicitBoost + coachBoost + dwellBoost),
        companyId: j.companyId ?? null,
        semanticTier: tier,
        semanticWeight,
        source,
        interestWeight,
        implicitBoost,
        coachBoost,
        // Опционально: поле появляется только при ненулевом dwell-сигнале
        ...(dwellBoost > 0 ? { dwellBoost } : {}),
      },
    });
  }

  const jobsSel = selectJobs702010(tieredJobs, 4);
  const jobs = jobsSel.selected.map((p) => p.rec);
  const jobsRest = jobsSel.rest.map((p) => p.rec);

  // ========================================================================
  // 2) People: 4 пользователя с общими контактами (2-е рукопожатия)
  //    Пул расширен до 8 — хвост идёт в exploration-пул Epsilon-Greedy.
  //    A4: source='following' (социальный граф), фолбэк — 'trending'.
  // ========================================================================
  // Шаг 1: мои прямые контакты (status=accepted)
  const myConnections = await db.connection.findMany({
    where: {
      OR: [
        { fromUserId: userId, status: 'accepted' },
        { toUserId: userId, status: 'accepted' },
      ],
    },
    select: { fromUserId: true, toUserId: true },
  });
  const myContactIds = new Set(
    myConnections.flatMap((c) => [c.fromUserId, c.toUserId]).filter((id) => id !== userId)
  );

  let people: PeopleRec[] = [];
  let peoplePool: PeopleRec[] = [];

  if (myContactIds.size > 0) {
    // Шаг 2: связи моих контактов (2-е рукопожатия)
    const secondDegree = await db.connection.findMany({
      where: {
        OR: [
          { fromUserId: { in: Array.from(myContactIds) }, status: 'accepted' },
          { toUserId: { in: Array.from(myContactIds) }, status: 'accepted' },
        ],
      },
      select: { fromUserId: true, toUserId: true },
    });

    // Шаг 3: считаем для каждого кандидата число общих контактов
    // candidateId -> Set<commonContactId>
    const candidateContacts = new Map<string, Set<string>>();
    for (const c of secondDegree) {
      // Если c.fromUserId — мой контакт, то c.toUserId — кандидат (2-е рукопожатие)
      if (myContactIds.has(c.fromUserId) && c.toUserId !== userId && !myContactIds.has(c.toUserId)) {
        if (!candidateContacts.has(c.toUserId)) candidateContacts.set(c.toUserId, new Set());
        candidateContacts.get(c.toUserId)!.add(c.fromUserId);
      }
      // И наоборот
      if (myContactIds.has(c.toUserId) && c.fromUserId !== userId && !myContactIds.has(c.fromUserId)) {
        if (!candidateContacts.has(c.fromUserId)) candidateContacts.set(c.fromUserId, new Set());
        candidateContacts.get(c.fromUserId)!.add(c.toUserId);
      }
    }

    // Шаг 4: сортируем по числу общих контактов, берём топ-8 (4 + хвост для разведки)
    const topCandidates = Array.from(candidateContacts.entries())
      .map(([id, contacts]) => ({ id, commonCount: contacts.size }))
      .sort((a, b) => b.commonCount - a.commonCount)
      .slice(0, 8);

    if (topCandidates.length > 0) {
      const candidates = await db.user.findMany({
        where: { id: { in: topCandidates.map((c) => c.id) } },
        select: {
          id: true,
          name: true,
          title: true,
          avatarUrl: true,
          location: true,
          level: true,
          ipScore: true,
          company: { select: { name: true } },
        },
      });
      // Сохраняем порядок сортировки + фильтр игнорируемых тем (по роли)
      const mapped = topCandidates
        .map((tc) => {
          const u = candidates.find((c) => c.id === tc.id);
          if (!u) return null;
          return {
            id: u.id,
            name: u.name,
            title: u.title,
            avatarUrl: u.avatarUrl,
            location: u.location,
            level: u.level,
            ipScore: u.ipScore,
            companyName: u.company?.name ?? null,
            commonContacts: tc.commonCount,
            source: 'following' as RecSource,
          } as PeopleRec;
        })
        .filter((p): p is PeopleRec => p !== null)
        .filter((p) => !matchesIgnoredTopics([p.title], ignoredTopics));
      people = mapped.slice(0, 4);
      peoplePool = mapped.slice(4);
    }
  }

  // Фолбэк: если 2-х рукопожатий нет — берём пользователей с высоким IP-score
  if (people.length === 0) {
    const fallback = await db.user.findMany({
      where: { id: { not: userId } },
      take: 8,
      orderBy: { ipScore: 'desc' },
      select: {
        id: true,
        name: true,
        title: true,
        avatarUrl: true,
        location: true,
        level: true,
        ipScore: true,
        company: { select: { name: true } },
      },
    });
    const mapped = fallback
      .map((u) => ({
        id: u.id,
        name: u.name,
        title: u.title,
        avatarUrl: u.avatarUrl,
        location: u.location,
        level: u.level,
        ipScore: u.ipScore,
        companyName: u.company?.name ?? null,
        commonContacts: 0,
        source: 'trending' as RecSource,
      }))
      .filter((p) => !matchesIgnoredTopics([p.title], ignoredTopics));
    people = mapped.slice(0, 4);
    peoplePool = mapped.slice(4);
  }

  // ========================================================================
  // 3) Events: ближайшие (startDate >= now). Пул 12 — хвост для разведки.
  //    A4: source='trending' (общеплатформенная лента ближайших событий).
  // ========================================================================
  const eventsRaw = await db.event.findMany({
    where: { startDate: { gte: new Date() } },
    orderBy: { startDate: 'asc' },
    take: 12,
    include: {
      organizer: { select: { id: true, name: true } },
      company: { select: { id: true, name: true } },
      _count: { select: { participants: { where: { status: 'going' } } } },
    },
  });

  const allEvents: EventRec[] = eventsRaw
    .map((e) => ({
      id: e.id,
      title: e.title,
      startDate: e.startDate.toISOString(),
      endDate: e.endDate?.toISOString() ?? null,
      format: e.format,
      location: e.location,
      organizerName: e.organizer?.name ?? e.company?.name ?? 'BizON',
      participantsCount: e._count.participants,
      source: 'trending' as RecSource,
    }))
    .filter((e) => !matchesIgnoredTopics([e.title], ignoredTopics));
  const events = allEvents.slice(0, 4);
  const eventsRest = allEvents.slice(4);

  // ========================================================================
  // 4) Companies: лучшие по culturalScore (фолбэк: adTrustIndex).
  //    Пул 12 — хвост для разведки; рейтинг считается для всего пула.
  //    A4: source='trending' (культурный скор — общеплатформенный топ).
  // ========================================================================
  const companiesRaw = await db.company.findMany({
    orderBy: [{ culturalScore: 'desc' }, { adTrustIndex: 'desc' }, { name: 'asc' }],
    take: 12,
    include: {
      _count: {
        select: {
          jobs: { where: { active: true } },
          reviews: true,
        },
      },
    },
  });

  const allCompanyIds = companiesRaw.map((c) => c.id);
  const reviewsAgg = await db.companyReview.groupBy({
    by: ['companyId'],
    where: { companyId: { in: allCompanyIds } },
    _avg: { rating: true },
  });
  const ratingMap = new Map(reviewsAgg.map((r) => [r.companyId, r._avg.rating ?? 0]));

  const allCompanies: CompanyRec[] = companiesRaw
    .map((c) => ({
      id: c.id,
      name: c.name,
      logoUrl: c.logoUrl,
      industry: c.industry,
      activeJobsCount: c._count.jobs,
      rating: ratingMap.get(c.id) ?? null,
      culturalScore: c.culturalScore ?? c.adTrustIndex,
      source: 'trending' as RecSource,
    }))
    // Анти-эхо-камера: скип компаний по игнорируемой теме (название/индустрия)
    .filter((c) => !matchesIgnoredTopics([c.name, c.industry], ignoredTopics));
  const companies = allCompanies.slice(0, 4);
  const companiesRest = allCompanies.slice(4);

  // ========================================================================
  // Анти-эхо-камера: Epsilon-Greedy exploration (~15%)
  // При выдаче ≥6 позиций минимум одна карточка заменяется случайной из
  // хвоста пула (exploration: true + reason + source='exploration').
  // ========================================================================
  const totalRecs = jobs.length + people.length + events.length + companies.length;
  if (totalRecs >= 6) {
    const explorationCount = Math.min(3, Math.max(1, Math.round(totalRecs * 0.15)));
    const blocks: Array<Array<Explorable & { source?: RecSource }>> = [jobs, people, events, companies];
    const pools: Array<Array<Explorable & { source?: RecSource }>> = [jobsRest, peoplePool, eventsRest, companiesRest];
    applyExploration(blocks, pools, explorationCount);
  }

  // ========================================================================
  // A4: единый interleaved-поток (doc_agents стр. 26) — round-robin
  // jobs → people → events → companies. Обратно совместимо: старые массивы
  // jobs/people/events/companies не изменены (кроме добавления поля source).
  // ========================================================================
  const interleaved: InterleavedEntry[] = interleaveRoundRobin<InterleavedEntry>([
    jobs.map((j) => ({ kind: 'job' as const, source: j.source, item: j })),
    people.map((p) => ({ kind: 'person' as const, source: p.source, item: p })),
    events.map((e) => ({ kind: 'event' as const, source: e.source, item: e })),
    companies.map((c) => ({ kind: 'company' as const, source: c.source, item: c })),
  ]);

  return { jobs, people, events, companies, interleaved };
}
