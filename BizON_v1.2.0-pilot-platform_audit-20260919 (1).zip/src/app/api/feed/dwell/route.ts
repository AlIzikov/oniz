// BizON API — POST /api/feed/dwell (Task 10-c, doc_agents A7: «implicit feedback:
// время просмотра»)
//
// Принимает АГРЕГИРОВАННЫЙ dwell-пакет с фронта (src/components/feed/dwell-tracking.ts):
// карточки ленты, которые пользователь видел ≥50% площади (IntersectionObserver),
// с накопленными секундами видимости за сессию. Транспорт — sendBeacon/keepalive
// при уходе со страницы, поэтому роут максимально лёгкий и fail-safe.
//
// КОНТРАКТ:
//   POST { items: [{ itemType: 'job'|'person'|'event'|'company', itemId: string,
//                   topic?: string, seconds: number }] }
//   Ограничения: ≤50 items; seconds — целое 1..300; topic ≤200 символов
//   (клиент отправляет ≤120; сервер trunc'ает, не отвергает).
//   Ответ: { ok: true, counted: number } — counted = сколько событий реально
//   записано (дедуплицированные не считаются).
//
// ХРАНЕНИЕ (паттерн 7-c, POST /api/jobs/[id]/view):
//   db.actionEvent.create(type='feed_dwell', metadata {itemType,itemId,topic,seconds},
//   isPublic=false — поведение приватно, в Professional Moments не попадает).
//   Дедуп: ≤1 события 'feed_dwell' на пользователя/карточку в UTC-сутки —
//   повторные сессии в тот же день не дублируют записи.
//
// ПРИВАТНОСТЬ (doc_agents стр. 31 «собираем только то, что нужно»):
//   в metadata ТОЛЬКО itemId/topic/seconds (+itemType) — без PII, без таймингов,
//   без UA/IP. topic — содержимое уже показанной карточки (заголовок вакансии /
//   имя человека / название компании), совместимо с темами IgnoredTopic.
//
// ВЕСА ЛЕНТЫ: GET /api/feed/recommendations читает 'feed_dwell' за окно 14 дней
// и бустит карточки по topic/навыку с decay 1/(1+days×0.1) (консистентно с A2,
// Task 9-a): dwell ≥10с — полный сигнал, 3..10с — частичный, <3с — не сигнал.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { cache } from '@/lib/cache';

export const runtime = 'nodejs';

const DWELL_EVENT_TYPE = 'feed_dwell';

// Серверные лимиты (зеркалят клиентские константы dwell-tracking.ts)
const MAX_ITEMS_PER_BATCH = 50;
const MAX_SECONDS = 300;
const MIN_SECONDS = 1;
const MAX_TOPIC_LENGTH = 200;
const MAX_ITEM_ID_LENGTH = 128;

const ALLOWED_ITEM_TYPES = ['job', 'person', 'event', 'company'] as const;
type DwellItemType = (typeof ALLOWED_ITEM_TYPES)[number];

const ITEM_TYPE_LABELS: Record<DwellItemType, string> = {
  job: 'вакансию',
  person: 'профиль',
  event: 'событие',
  company: 'компанию',
};

interface DwellInputItem {
  itemType: DwellItemType;
  itemId: string;
  topic: string | null;
  seconds: number;
}

function isDwellItemType(v: unknown): v is DwellItemType {
  return typeof v === 'string' && (ALLOWED_ITEM_TYPES as readonly string[]).includes(v);
}

/** Безопасный парс metadata-JSON (паттерн 7-c). */
function parseMetadata(raw: string | null): Record<string, unknown> {
  if (!raw) return {};
  try {
    const parsed: unknown = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // --- Парсинг тела (sendBeacon/keepalive — всегда application/json от клиента) ---
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON в теле запроса', 400);
  }
  return handleDwell(body, user.id);
}

async function handleDwell(body: unknown, userId: string): Promise<Response> {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) {
    return errorJson('Ожидается объект { items: [...] }', 400);
  }
  const rawItems = (body as { items?: unknown }).items;
  if (!Array.isArray(rawItems) || rawItems.length === 0) {
    return errorJson('items: ожидается непустой массив', 400);
  }
  if (rawItems.length > MAX_ITEMS_PER_BATCH) {
    return errorJson(`items: не более ${MAX_ITEMS_PER_BATCH} позиций за пачку`, 400);
  }

  // --- Валидация и нормализация каждого item ---
  // Внутри пачки дедуплицируем по ключу (оставляем максимум seconds) —
  // «1 карточка = 1 агрегат за пачку».
  const byKey = new Map<string, DwellInputItem>();
  for (let i = 0; i < rawItems.length; i++) {
    const raw = rawItems[i];
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
      return errorJson(`items[${i}]: ожидается объект`, 400);
    }
    const it = raw as Record<string, unknown>;

    if (!isDwellItemType(it.itemType)) {
      return errorJson(`items[${i}].itemType: допустимы job|person|event|company`, 400);
    }
    if (typeof it.itemId !== 'string' || it.itemId.trim().length === 0) {
      return errorJson(`items[${i}].itemId: обязательная непустая строка`, 400);
    }
    if (it.itemId.length > MAX_ITEM_ID_LENGTH) {
      return errorJson(`items[${i}].itemId: не более ${MAX_ITEM_ID_LENGTH} символов`, 400);
    }
    if (
      typeof it.seconds !== 'number' ||
      !Number.isFinite(it.seconds) ||
      !Number.isInteger(it.seconds) ||
      it.seconds < MIN_SECONDS ||
      it.seconds > MAX_SECONDS
    ) {
      return errorJson(`items[${i}].seconds: целое число от ${MIN_SECONDS} до ${MAX_SECONDS}`, 400);
    }
    let topic: string | null = null;
    if (it.topic !== undefined && it.topic !== null) {
      if (typeof it.topic !== 'string') {
        return errorJson(`items[${i}].topic: строка или null`, 400);
      }
      topic = it.topic.trim().slice(0, MAX_TOPIC_LENGTH) || null;
    }

    const itemId = it.itemId.trim();
    const key = `${it.itemType}:${itemId}`;
    const prev = byKey.get(key);
    if (!prev || prev.seconds < it.seconds) {
      byKey.set(key, { itemType: it.itemType, itemId, topic, seconds: it.seconds });
    }
  }

  // --- Дедуп в БД: ≤1 'feed_dwell' на пользователя/карточку в UTC-сутки (паттерн 7-c) ---
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);

  const todayEvents = await db.actionEvent
    .findMany({
      where: {
        userId,
        type: DWELL_EVENT_TYPE,
        createdAt: { gte: startOfDay },
      },
      select: { metadata: true },
      take: 200,
    })
    .catch(() => []);

  const seenToday = new Set<string>();
  for (const ev of todayEvents) {
    const meta = parseMetadata(ev.metadata);
    if (typeof meta.itemType === 'string' && typeof meta.itemId === 'string') {
      seenToday.add(`${meta.itemType}:${meta.itemId}`);
    }
  }

  // --- Запись новых событий (FIX-06: один createMany вместо N create в цикле) ---
  const rows: {
    userId: string;
    type: string;
    title: string;
    description: null;
    metadata: string;
    isPublic: boolean;
  }[] = [];
  for (const item of byKey.values()) {
    const key = `${item.itemType}:${item.itemId}`;
    if (seenToday.has(key)) continue;
    seenToday.add(key); // защита от дубликатов внутри пачки при гонке
    rows.push({
      userId,
      type: DWELL_EVENT_TYPE,
      title: item.topic
        ? `Изучал ${ITEM_TYPE_LABELS[item.itemType]} «${item.topic.slice(0, 120)}» — ${item.seconds} с`
        : `Изучал ${ITEM_TYPE_LABELS[item.itemType]} — ${item.seconds} с`,
      description: null,
      // ПРИВАТНОСТЬ: только itemId/topic/seconds (+itemType). Без PII.
      metadata: JSON.stringify({
        itemType: item.itemType,
        itemId: item.itemId,
        topic: item.topic,
        seconds: item.seconds,
      }),
      isPublic: false, // поведение приватно — не попадает в Professional Moments
    });
  }

  let counted = 0;
  if (rows.length > 0) {
    try {
      await db.actionEvent.createMany({ data: rows });
      counted = rows.length;
    } catch (e) {
      console.error('[api/feed/dwell] actionEvent.createMany failed:', e);
    }
  }

  // Новые сигналы — сбросить кэш персональных рекомендаций, чтобы следующий
  // GET /api/feed/recommendations пересчитался с dwell-бустом (как делают
  // подписчики job.viewed / intent.changed).
  if (counted > 0) {
    cache.delete(`feed-recs:${userId}`);
  }

  return json({ ok: true, counted });
}
