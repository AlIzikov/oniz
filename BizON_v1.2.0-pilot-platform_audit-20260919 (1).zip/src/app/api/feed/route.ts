// BizON API — /api/feed (Лента новостей)
// Использует FeedService (микросервисный слой)
// Режимы: all | posts | achievements
// Подразделы (sub): recommended | all | friends | mine | favorites | favGroups | favNews
// Параметры: random=true → перемешать посты (для кнопки «Случайные новости»)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { FeedService, type FeedSubSection } from '@/lib/services';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = Number(req.nextUrl.searchParams.get('limit') ?? 20);
  const offset = Number(req.nextUrl.searchParams.get('offset') ?? 0);
  const mode = (req.nextUrl.searchParams.get('mode') ?? 'all') as 'all' | 'posts' | 'achievements';
  const subSection = (req.nextUrl.searchParams.get('sub') ?? 'recommended') as FeedSubSection;
  const random = req.nextUrl.searchParams.get('random') === 'true';

  const result = await FeedService.getFeed(user.id, { limit, offset, mode, subSection, random });

  // Event Bus: лента обновлена (ошибки шины не влияют на выдачу)
  EventBus.publish('feed.refreshed', {
    userId: user.id,
    count: Array.isArray(result.items) ? result.items.length : undefined,
    sub: subSection,
  }).catch(() => undefined);

  return json(result);
}
