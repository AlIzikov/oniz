// BizON API — /api/hr-contacts
// Этап 4.2 — Privacy Shield: HR-агентство инициирует контакт с кандидатом.
// POST — HR отправляет контактному лицу кандидата сообщение.
//        Валидация:
//          • только accountType='hr_agency' может инициировать
//          • если кандидат hrInvisible=true → отказ (Privacy Shield)
//          • лимит 1 контакт/неделю от одного HR к одному кандидату
//            (через unique constraint [hrAgencyId, candidateId, weekKey])
//          • если есть активный блок от этого кандидата в последние 7 дней → отказ
// GET  — для текущего HR: список отправленных им контактов (опционально ?status=)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const MAX_MESSAGE_LENGTH = 2000;
const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

/**
 * ISO-неделя: формат "2026-W36".
 * Вычисляется по UTC, чтобы избежать проблем с таймзонами.
 * Не экспортируем — Next.js не позволяет route.ts иметь произвольные экспорты.
 */
function getWeekKey(date: Date = new Date()): string {
  // ISO week algorithm
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  // Понедельник = 1, воскресенье = 7
  const dayNum = d.getUTCDay() === 0 ? 7 : d.getUTCDay();
  // Четверг этой же недели (ISO неделя определяется по четвергу)
  const thursday = new Date(d);
  thursday.setUTCDate(d.getUTCDate() + (4 - dayNum));
  const year = thursday.getUTCFullYear();
  // 1 января года, в который попадает четверг
  const firstThursday = new Date(Date.UTC(year, 0, 4));
  const firstDayNum = firstThursday.getUTCDay() === 0 ? 7 : firstThursday.getUTCDay();
  const firstMonday = new Date(firstThursday);
  firstMonday.setUTCDate(firstThursday.getUTCDate() - (firstDayNum - 1));
  const weekNum = Math.floor((thursday.getTime() - firstMonday.getTime()) / (7 * 24 * 60 * 60 * 1000)) + 1;
  return `${year}-W${String(weekNum).padStart(2, '0')}`;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Для HR — список отправленных контактов
  if (user.accountType === 'hr_agency') {
    const status = req.nextUrl.searchParams.get('status') ?? 'all';
    const where: any = { hrAgencyId: user.id };
    if (status !== 'all') where.status = status;
    const contacts = await db.hrContact.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: {
        candidate: {
          select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true },
        },
      },
    });
    return json({
      contacts: contacts.map((c) => ({
        id: c.id,
        message: c.message,
        status: c.status,
        initiatedBy: c.initiatedBy,
        weekKey: c.weekKey,
        createdAt: c.createdAt.toISOString(),
        candidate: c.candidate,
      })),
    });
  }

  // Для individual — список входящих контактов
  const status = req.nextUrl.searchParams.get('status') ?? 'all';
  const where: any = { candidateId: user.id };
  if (status !== 'all') where.status = status;
  const contacts = await db.hrContact.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      hrAgency: {
        select: { id: true, name: true, title: true, avatarUrl: true, isVerified: true, companyId: true },
      },
    },
  });
  return json({
    contacts: contacts.map((c) => ({
      id: c.id,
      message: c.message,
      status: c.status,
      initiatedBy: c.initiatedBy,
      weekKey: c.weekKey,
      createdAt: c.createdAt.toISOString(),
      hrAgency: c.hrAgency,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только HR-агентство может инициировать контакт
  if (user.accountType !== 'hr_agency') {
    return errorJson('Только HR-агентства могут инициировать контакт', 403);
  }

  const rl = checkUserRateLimit(
    user.id,
    'hrContacts:create',
    ...MUTATION_LIMITS.connectionsCreate,
  );
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { candidateId, message } = body ?? {};

    if (!candidateId || typeof candidateId !== 'string') {
      return errorJson('candidateId обязателен', 422);
    }
    if (candidateId === user.id) {
      return errorJson('Нельзя контактировать с самим собой', 422);
    }
    if (message !== undefined && message !== null) {
      if (typeof message !== 'string' || message.length > MAX_MESSAGE_LENGTH) {
        return errorJson(`message слишком длинный (макс. ${MAX_MESSAGE_LENGTH} символов)`, 422);
      }
    }

    // Проверяем существование кандидата
    const candidate = await db.user.findUnique({
      where: { id: candidateId },
      select: { id: true, name: true, accountType: true, hrInvisible: true },
    });
    if (!candidate) return errorJson('Кандидат не найден', 404);

    // === Privacy Shield: кандидат может быть невидим для HR ===
    if (candidate.hrInvisible) {
      return errorJson(
        'Кандидат отключил контакты от HR-агентств (Privacy Shield)',
        403,
      );
    }

    // === Проверка активного блока от кандидата в последние 7 дней ===
    // Если кандидат ранее блокировал этого HR, и блок ещё действует — отказ
    const weekAgo = new Date(Date.now() - WEEK_MS);
    const activeBlock = await db.hrContact.findFirst({
      where: {
        hrAgencyId: user.id,
        candidateId,
        status: 'blocked',
        createdAt: { gte: weekAgo },
      },
      select: { id: true, createdAt: true },
    });
    if (activeBlock) {
      const unblockAt = new Date(activeBlock.createdAt.getTime() + WEEK_MS);
      const daysLeft = Math.ceil((unblockAt.getTime() - Date.now()) / (24 * 60 * 60 * 1000));
      return errorJson(
        `Кандидат заблокировал вас. Блок истекает через ${daysLeft} дн.`,
        403,
      );
    }

    // === Лимит 1 контакт/неделю от одного HR к одному кандидату ===
    // Реализован через unique constraint [hrAgencyId, candidateId, weekKey]
    const weekKey = getWeekKey();
    try {
      const contact = await db.hrContact.create({
        data: {
          hrAgencyId: user.id,
          candidateId,
          initiatedBy: 'hr',
          message: message?.trim() || null,
          status: 'active',
          weekKey,
        },
      });

      // Уведомляем кандидата
      await db.notification
        .create({
          data: {
            userId: candidateId,
            type: 'hr_contact',
            title: 'HR-агентство связалось с вами',
            content: message?.trim()
              ? `${user.name}: ${message.trim().slice(0, 100)}${message.length > 100 ? '…' : ''}`
              : `${user.name} хочет обсудить с вами вакансию.`,
            link: '/settings',
          },
        })
        .catch((e) => console.error('[hr-contacts/create] notification error:', e));

      return json(
        {
          contact: {
            id: contact.id,
            status: contact.status,
            initiatedBy: contact.initiatedBy,
            weekKey: contact.weekKey,
            createdAt: contact.createdAt.toISOString(),
          },
        },
        201,
      );
    } catch (e: any) {
      // Unique constraint violation = уже контактировал на этой неделе
      if (e?.code === 'P2002') {
        return errorJson(
          'Вы уже связывались с этим кандидатом на этой неделе. Лимит — 1 контакт/неделю.',
          429,
        );
      }
      throw e;
    }
  } catch (e) {
    console.error('[hr-contacts/create] error:', e);
    return errorJson('Ошибка создания контакта', 500);
  }
}
