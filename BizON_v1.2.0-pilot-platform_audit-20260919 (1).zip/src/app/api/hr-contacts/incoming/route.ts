// BizON API — /api/hr-contacts/incoming
// Этап 4.2 — Privacy Shield: для кандидата — кто меня контактил за неделю.
// Возвращаем только контакты за последние 7 дней (weekKey текущей недели),
// чтобы кандидату было удобно управлять активными контактами.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Любой пользователь может видеть свои входящие HR-контакты
  // (даже если сейчас у него accountType='individual', но раньше был hr_agency и т.п.)
  const weekAgo = new Date(Date.now() - WEEK_MS);

  const contacts = await db.hrContact.findMany({
    where: {
      candidateId: user.id,
      createdAt: { gte: weekAgo },
    },
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: {
      hrAgency: {
        select: {
          id: true,
          name: true,
          title: true,
          avatarUrl: true,
          isVerified: true,
          companyId: true,
        },
      },
    },
  });

  return json({
    contacts: contacts.map((c) => ({
      id: c.id,
      message: c.message,
      status: c.status,
      initiatedBy: c.initiatedBy,
      weekKey: c.weekKey,
      createdAt: c.createdAt.toISOString(),
      hrAgency: c.hrAgency,
    })),
  });
}
