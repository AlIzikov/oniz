// BizON API — POST /api/me/delete-account
// Этап 8.2 (DEL) — GDPR / 152-ФЗ: soft-delete аккаунта.
//
// Что делает:
//   • Помечает user.deletedAt = now() (новое поле в schema)
//   • НЕ удаляет данные сразу — пользователь может восстановить аккаунт
//     (через поддержку) в течение 30 дней
//   • Через 30 дней cron-cleanup-deleted.js физически удаляет запись
//     (каскад через onDelete: Cascade на связанных моделях)
//   • Логирует действие в AuditLog (152-ФЗ ст. 19 — фиксация фактов обработки PII)
//   • Инвалидирует все активные сессии пользователя (logout)
//
// Идемпотентно: повторный вызов возвращает 200, но не меняет deletedAt
// (используется уже установленное значение).

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { clearSessionCookie } from '@/lib/auth';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Идемпотентность: если уже помечен — возвращаем существующее состояние
  const existing = (user as { deletedAt?: Date | null }).deletedAt;
  if (existing) {
    return json({
      status: 'already_scheduled',
      deletedAt: new Date(existing).toISOString(),
      scheduledPurgeAt: new Date(
        new Date(existing).getTime() + 30 * 24 * 60 * 60 * 1000
      ).toISOString(),
      message: 'Аккаунт уже помечен на удаление. Через 30 дней данные будут удалены полностью.',
    });
  }

  const now = new Date();
  const purgeAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

  // 1) Помечаем аккаунт как soft-deleted.
  //    Данные остаются в БД 30 дней для возможности восстановления;
  //    auth.ts блокирует доступ (getUserFromRequest → null, loginUser → ошибка).
  await db.user.update({
    where: { id: user.id },
    data: { deletedAt: now },
  });

  // 2) Инвалидируем все активные сессии (logout на всех устройствах).
  //    Это предотвращает дальнейший доступ через украденный токен.
  try {
    await db.session.deleteMany({ where: { userId: user.id } });
  } catch (e) {
    // Не критично — сессия истечёт сама по TTL
    console.error('[delete-account] session cleanup failed:', e);
  }

  // 3) AuditLog — фиксируем факт запроса удаления (152-ФЗ ст. 19)
  await db.auditLog.create({
    data: {
      actorId: user.id,
      action: 'account_soft_delete',
      resource: 'user',
      resourceId: user.id,
      metadata: JSON.stringify({
        deletedAt: now.toISOString(),
        scheduledPurgeAt: purgeAt.toISOString(),
        reason: 'user_request',
        // ip / userAgent — добавляем только если middleware проксирует
        userAgent: req.headers.get('user-agent')?.slice(0, 200) ?? null,
      }),
    },
  });

  // 4) Очищаем cookie на клиенте (если запрос шёл через браузер)
  try {
    await clearSessionCookie();
  } catch (e) {
    // В API route (Next 16) cookies() работает только в Server Components / Route Handlers
    // с правильным контекстом. Игнорируем ошибку — клиент сам сбросит cookie.
    console.error('[delete-account] clearSessionCookie failed:', e);
  }

  return json({
    status: 'scheduled',
    deletedAt: now.toISOString(),
    scheduledPurgeAt: purgeAt.toISOString(),
    message:
      'Аккаунт помечен на удаление. Через 30 дней (или ранее по запросу поддержки) ' +
      'все данные будут удалены безвозвратно. До этого момента вы можете восстановить ' +
      'аккаунт, обратившись в поддержку.',
    // Подсказка клиенту: необходимо разлогиниться локально
    logout: true,
  });
}
