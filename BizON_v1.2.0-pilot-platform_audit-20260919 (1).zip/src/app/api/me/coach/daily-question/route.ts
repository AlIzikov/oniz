import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CoachService } from '@/lib/services/coach-service';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const question = await CoachService.generateDailyQuestion(user.id);

    // Event Bus: вопрос дня сгенерирован. Публикуем только для действительно
    // нового вопроса (повторные GET возвращают существующий вопрос дня).
    if (Date.now() - question.createdAt.getTime() < 60_000) {
      EventBus.publish('coach.question.generated', {
        userId: user.id,
        questionId: question.id,
        category: question.category,
      }).catch(() => undefined);
    }

    return json({ question });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
