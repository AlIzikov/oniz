import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CoachService } from '@/lib/services/coach-service';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const body = await req.json();
    const { questionId, answer } = body ?? {};
    if (!questionId || !answer) return errorJson('questionId и answer обязательны', 422);
    const result = await CoachService.answerQuestion(user.id, questionId, answer);

    // Event Bus: пользователь ответил на вопрос дня (ошибки шины не влияют на ответ API)
    if (result.ok) {
      EventBus.publish('coach.question.answered', { userId: user.id, questionId }).catch(() => undefined);
    }

    return json(result);
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
