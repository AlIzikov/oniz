import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CoachService } from '@/lib/services/coach-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const rl = checkUserRateLimit(user.id, 'ai:discover', 10, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);
  try {
    const insights = await CoachService.discoverHiddenPotential(user.id);
    return json({ insights });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Ошибка';
    return errorJson(message, 500);
  }
}
