import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CoachService } from '@/lib/services/coach-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const status = req.nextUrl.searchParams.get('status') ?? undefined;
    const insights = await CoachService.getInsights(user.id, status);
    return json({ insights });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Ошибка';
    return errorJson(message, 500);
  }
}
