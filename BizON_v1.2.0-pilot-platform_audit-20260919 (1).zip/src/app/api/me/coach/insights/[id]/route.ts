import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CoachService } from '@/lib/services/coach-service';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

interface PatchInsightBody {
  confirmed?: unknown;
  // ТЗ doc_agents: «Пропустить вопрос» — статус инсайта не меняется (остаётся new)
  status?: unknown;
}

/**
 * Task 9-a (B13): intentType для события intent.changed из подтверждённого инсайта.
 *  - job_interest с токеном → «job_interest:<token>» (конкретное направление);
 *  - остальные → insightType (career_shift | hidden_talent | ...).
 */
function insightToIntentType(insightType: string, sourceData: string | null): string {
  if (insightType === 'job_interest' && sourceData) {
    try {
      const parsed: unknown = JSON.parse(sourceData);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        const token = (parsed as Record<string, unknown>)['token'];
        if (typeof token === 'string' && token.length >= 3) return `job_interest:${token.toLowerCase()}`;
      }
    } catch {
      // повреждённый JSON — fallback на insightType
    }
  }
  return insightType;
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const { id } = await ctx.params;
    const body = (await req.json().catch(() => null)) as PatchInsightBody | null;
    const parsed: PatchInsightBody = body ?? {};

    // Пропуск («Пропустить вопрос»): статус не меняется, помечается sourceData.skipped
    if (parsed.status === 'skipped') {
      const skipped = await CoachService.skipInsight(user.id, id);
      return json(skipped);
    }

    const confirmed = Boolean(parsed.confirmed);
    const result = await CoachService.confirmInsight(user.id, id, confirmed);

    // Event Bus: инсайт коуча подтверждён/отклонён (ошибки шины не влияют на ответ API)
    if (result.ok) {
      EventBus.publish('coach.insight.confirmed', { userId: user.id, insightId: id, confirmed }).catch(() => undefined);

      // Task 9-a (B13, doc_agents стр. 41 «OnInsightConfirmed → пересчёт рекомендаций»):
      // после подтверждения публикуем intent.changed — подписчик шины сбрасывает кэш
      // персональной ленты, и следующий GET /api/feed/recommendations пересчитывается
      // уже с coach-бустом (ActionEvent coach_insight_confirmed из confirmInsight).
      if (confirmed && result.ok) {
        const insight = result.insight;
        if (insight) {
          const intentType = insightToIntentType(insight.insightType, insight.sourceData);
          EventBus.publish('intent.changed', { userId: user.id, intentType }).catch(() => undefined);
        }
      }
    }

    return json(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Ошибка';
    return errorJson(message, 500);
  }
}
