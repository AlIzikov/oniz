// BizON API — GET /api/me/credentials (Wave 6, S-140).
// W3C Verifiable Credentials: verified-навыки + клиент-подтверждённые проекты,
// подпись HMAC платформы. §3.3: только факты, без чисел доверия.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { VCExportService } from '@/lib/services/vc-export-service';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const { credentials } = await VCExportService.exportCredentials(ctx.user.id);
  return NextResponse.json({ credentials, count: credentials.length });
});
