// BizON API — /api/me/career-discovery (Phase 3 — Career Discovery)
// Анализирует подтверждённые навыки + проекты пользователя.
// Предлагает 3-5 ролей, которые пользователь НЕ искал, но подходит.
//
// Эвристика (простая, по ТЗ):
//   1. Получаем подтверждённые навыки пользователя (verificationLevel != 'claimed')
//   2. Получаем заголовки вакансий, на которые пользователь уже откликнулся
//      (JobApplication со status != 'withdrawn') — это «то, что он искал»
//   3. Ищем активные вакансии, для которых:
//        - computeJobMatch(userSkills, ipScore, job) > 0.80
//        - title НЕ содержит значимых слов из уже откликнутых вакансий
//   4. Группируем по title (берём топ-1 представителя), сортируем по match, берём top 5
//   5. Возвращаем { currentSearch: [...], suggestions: [{ job, matchPct, reason }] }
//
// Пример ответа:
//   {
//     "currentSearch": ["Генеральный директор"],
//     "suggestions": [
//       { "jobId": "...", "title": "Директор по развитию", "company": "...", "matchPct": 96, "reason": "..." },
//       ...
//     ]
//   }
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { computeJobMatch } from '@/lib/ai';

export const runtime = 'nodejs';

// Стоп-слова для нормализации title (не считаются «значимыми» для сравнения ролей).
// Если title отклика состоит только из стоп-слов — он не блокирует suggestions.
const STOP_WORDS = new Set<string>([
  'и', 'или', 'по', 'на', 'в', 'с', 'без', 'для', 'а', 'но', 'же', 'ли',
  'the', 'and', 'or', 'for', 'with', 'without', 'to', 'in', 'at', 'of',
  'junior', 'middle', 'senior', 'lead', 'head', 'chief', 'vp', 'ceo', 'cto',
  'co', 'cfo', 'cmo', 'coo', 'cio',
]);

function tokenizeTitle(title: string): string[] {
  return (title ?? '')
    .toLowerCase()
    .split(/[\s,\/\-()_.]+/)
    .map((t) => t.trim())
    .filter((t) => t.length >= 3 && !STOP_WORDS.has(t));
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // 1. Подтверждённые навыки пользователя
  const userSkillsRows = await db.userSkill.findMany({
    where: { userId: user.id, verificationLevel: { not: 'claimed' } },
    include: { skill: true },
  });
  const userSkills = userSkillsRows.map((us) => us.skill.name);

  // Если подтверждённых навыков нет — ничего не предлагаем.
  if (userSkills.length === 0) {
    return json({
      currentSearch: [],
      suggestions: [],
      reason: 'Нет подтверждённых навыков. Подтвердите навыки в профиле, чтобы BizON предложил альтернативные роли.',
    });
  }

  // 2. Заголовки откликов пользователя («то, что он искал»)
  const myApplications = await db.jobApplication.findMany({
    where: { userId: user.id, status: { not: 'withdrawn' } },
    include: { job: { select: { title: true } } },
  });
  const currentSearchTitles = Array.from(
    new Set(myApplications.map((a) => a.job.title).filter(Boolean)),
  );
  // Собираем множество «значимых» токенов из откликов — для исключения похожих ролей.
  const appliedTokens = new Set<string>();
  for (const t of currentSearchTitles) {
    for (const tok of tokenizeTitle(t)) appliedTokens.add(tok);
  }

  // 3. Загружаем активные вакансии (ограничение 200 — чтобы не положить БД на большой выдаче)
  const jobs = await db.job.findMany({
    where: { active: true },
    select: {
      id: true,
      title: true,
      company: true,
      companyId: true,
      requiredSkills: true,
      growthScore: true,
      location: true,
      salaryMin: true,
      salaryMax: true,
      salaryFrom: true,
      salaryTo: true,
      currency: true,
      createdAt: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });

  // 4. Считаем match для каждой, фильтруем > 0.80 и title без пересечений с appliedTokens
  const MIN_MATCH = 0.80;
  const candidates = jobs
    .map((j) => {
      const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
      const match = computeJobMatch(userSkills, user.ipScore, {
        requiredSkills,
        growthScore: j.growthScore ?? 0.5,
      });
      return { job: j, requiredSkills, match };
    })
    .filter(({ job, match }) => {
      if (match < MIN_MATCH) return false;
      // Title не должен содержать значимых слов из appliedTokens
      const tokens = tokenizeTitle(job.title);
      const overlap = tokens.some((t) => appliedTokens.has(t));
      if (overlap) return false;
      // Также исключаем точное совпадение title с уже откликнутыми
      if (currentSearchTitles.some((t) => t.toLowerCase() === job.title.toLowerCase())) return false;
      return true;
    });

  // 5. Группируем по нормализованному title — берём лучшего представителя на роль.
  //    Группировка нужна чтобы не предлагать 5 одинаковых «Директор по развитию» из разных компаний.
  const byTitleKey = new Map<string, { job: typeof jobs[number]; requiredSkills: string[]; match: number }>();
  for (const c of candidates) {
    const key = c.job.title.toLowerCase().trim();
    const existing = byTitleKey.get(key);
    if (!existing || c.match > existing.match) {
      byTitleKey.set(key, c);
    }
  }

  // 6. Сортируем по match, берём top 5
  const top = Array.from(byTitleKey.values())
    .sort((a, b) => b.match - a.match)
    .slice(0, 5);

  // 7. Формируем человекочитаемый reason для каждой роли
  const suggestions = top.map(({ job, requiredSkills, match }) => {
    const matchPct = Math.round(match * 100);
    const matchedSkills = requiredSkills.filter((s) => userSkills.map((us) => us.toLowerCase()).includes(s.toLowerCase()));
    const reasonParts: string[] = [];
    if (matchedSkills.length > 0) {
      reasonParts.push(`${matchedSkills.length} совпадающих навыков`);
    }
    if (user.ipScore > 0) reasonParts.push(`Trust ${user.ipScore}`);
    if ((job.growthScore ?? 0) >= 0.6) reasonParts.push('высокий потенциал роста');
    const reason = reasonParts.length > 0
      ? `Подходит: ${reasonParts.join(', ')}`
      : 'Профиль соответствует требованиям вакансии';
    return {
      jobId: job.id,
      title: job.title,
      company: job.company,
      companyId: job.companyId ?? null,
      location: job.location,
      matchPct,
      matchConfidence: Number(match.toFixed(3)),
      reason,
      matchedSkills,
      salaryMin: job.salaryMin ?? job.salaryFrom,
      salaryMax: job.salaryMax ?? job.salaryTo,
      currency: job.currency,
      createdAt: job.createdAt.toISOString(),
    };
  });

  return json({
    currentSearch: currentSearchTitles,
    // Спецификационный ключ Phase 3: `discoveries` (алиас для `suggestions`).
    // Существующие UI (bizon-discover) используют `suggestions` — оставляем оба.
    discoveries: suggestions,
    suggestions,
    userSkillsCount: userSkills.length,
    scannedJobs: jobs.length,
  });
}
