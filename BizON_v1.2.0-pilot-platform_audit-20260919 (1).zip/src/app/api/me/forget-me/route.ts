// BizON API — POST /api/me/forget-me
// Этап 8.2 (DEL) — GDPR ст. 17 / 152-ФЗ: право на забвение.
//
// В отличие от /api/me/delete-account (soft-delete с 30-дневным окном),
// forget-me НЕМЕДЛЕННО удаляет все PII пользователя. Используется, когда
// пользователь хочет «забыть его» прямо сейчас.
//
// Что делает:
//   • Удаляет все PII: email, emailHash, emailEncrypted, bio, bioEncrypted,
//     location, locationEncrypted, phone, phoneEncrypted, avatarUrl, title,
//     birthday, hobbies, newsSources
//   • Анонимизирует name → "Удалённый пользователь" (для сохранения целостности
//     графа доверия: связи и подтверждения остаются, но без имени автора)
//   • Сбрасывает passwordHash — пользователь больше не может войти
//   • Инвалидирует все сессии (logout на всех устройствах)
//   • Помечает deletedAt = now() (дальнейший доступ через API невозможен)
//   • Логирует в AuditLog (152-ФЗ ст. 19)
//
// Что НЕ удаляется (внимание!):
//   • Сама запись User (для FK-целостности графа)
//   • Connections (связи) — остаются, но отображаются без имени
//   • SkillConfirmation других пользователей (где этот user — confirmer) —
//     остаются, но без имени автора. Если confirmer = этот user — остаются
//     как anonymous.
//   • AuditLog — обязаны хранить 2 года по 152-ФЗ ст. 19 (но без PII)
//   • Сообщения и комментарии — остаются (т.к. участники диалога тоже имеют
//     право на свои данные). Автор отображается как "Удалённый пользователь".
//
// Идемпотентно: повторный вызов вернёт 410 (аккаунт уже забыли).

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { clearSessionCookie } from '@/lib/auth';

export const runtime = 'nodejs';

const FORGOTTEN_NAME = 'Удалённый пользователь';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Идемпотентность: если уже забыли — 410
  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт уже удалён', 410);
  }

  const now = new Date();

  // 1) Анонимизируем запись User: очищаем ВСЕ PII поля + сбрасываем passwordHash.
  //    Генерируем "мусорный" passwordHash, чтобы никто не мог войти (даже если
  //    знает старый пароль). Формат как у pbkdf2-хэша, но со случайным значением.
  const randomHashBytes = crypto.getRandomValues(new Uint8Array(32));
  const randomHashHex = Array.from(randomHashBytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const junkPasswordHash = `pbkdf2$600000$00000000000000000000000000000000$${randomHashHex}`;

  await db.user.update({
    where: { id: user.id },
    data: {
      // PII plaintext → null
      email: null,
      bio: null,
      location: null,
      phone: null,
      title: null,
      avatarUrl: null,
      birthday: null,
      hobbies: '',
      newsSources: null,
      // PII encrypted → null
      emailEncrypted: null,
      bioEncrypted: null,
      locationEncrypted: null,
      phoneEncrypted: null,
      // emailHash — unique, устанавливаем в null (разрешено схемой).
      // Это предотвращает поиск старого email после забвения.
      emailHash: null,
      // Имя → "Удалённый пользователь" (для отображения в графе/связях)
      name: FORGOTTEN_NAME,
      // passwordHash → случайный мусор (вход невозможен)
      passwordHash: junkPasswordHash,
      // 2FA отключаем
      twoFactorEnabled: false,
      twoFactorSecret: null,
      // Помечаем аккаунт на удаление — cron физически удалит запись через 30 дней,
      // но связи/подтверждения других пользователей (где этот user — confirmer)
      // останутся как anonymous (благодаря onDelete: SetNull или CASCADE).
      deletedAt: now,
    },
  });

  // 2) Инвалидируем все сессии пользователя
  try {
    await db.session.deleteMany({ where: { userId: user.id } });
  } catch (e) {
    console.error('[forget-me] session cleanup failed:', e);
  }

  // 3) AuditLog — фиксируем факт применения права на забвение (152-ФЗ ст. 19).
  //    ВАЖНО: AuditLog обязан хранить факт обработки PII 2 года, но сам не должен
  //    содержать PII. actorId — это ID записи (не PII), он остаётся.
  await db.auditLog.create({
    data: {
      actorId: user.id,
      action: 'right_to_be_forgotten',
      resource: 'user',
      resourceId: user.id,
      metadata: JSON.stringify({
        appliedAt: now.toISOString(),
        scheduledPurgeAt: new Date(
          now.getTime() + 30 * 24 * 60 * 60 * 1000
        ).toISOString(),
        legalBasis: ['GDPR Art. 17', '152-FZ Art. 14'],
        // НЕ сохраняем email/name — это и есть PII, который мы удаляем
        userAgent: req.headers.get('user-agent')?.slice(0, 200) ?? null,
      }),
    },
  });

  // 4) Очищаем cookie на клиенте
  try {
    await clearSessionCookie();
  } catch (e) {
    console.error('[forget-me] clearSessionCookie failed:', e);
  }

  return json({
    status: 'forgotten',
    appliedAt: now.toISOString(),
    scheduledPurgeAt: new Date(
      now.getTime() + 30 * 24 * 60 * 60 * 1000
    ).toISOString(),
    message:
      'Право на забвение применено. Все ваши PII немедленно удалены. ' +
      'Имя в графе доверия заменено на «Удалённый пользователь». ' +
      'Запись аккаунта будет физически удалена через 30 дней. ' +
      'Восстановление невозможно.',
    logout: true,
  });
}
