// BizON API — /api/me/signals
// P0: BIZON SIGNAL — «на рынке происходит кое-что интересное».
//
// Возвращает 0-5 рыночных сигналов для текущего пользователя:
//   • skill_trend            — спрос на навык X вырос на N%
//   • new_company            — компания из отрасли пользователя нанимает
//   • skill_gap_opportunity  — если подтвердите навык X, откроется N новых возможностей
//   • market_shift           — в вашей отрасли растёт спрос на Y
//
// Источник: BizonSignalService.getSignals(userId).
// Auth required: cookie 'bizon_session' или Authorization: Bearer <token>.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { BizonSignalService } from '@/lib/services/bizon-signal-service';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest) {
  const user = await getUserFromRequest(_req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const signals = await BizonSignalService.getSignals(user.id);
    return json({
      items: signals,
      total: signals.length,
      generatedAt: new Date().toISOString(),
    });
  } catch (e: any) {
    console.error('[/api/me/signals] error:', e?.message ?? e);
    // Graceful degradation: возвращаем пустой массив, чтобы UI не падал.
    return json({ items: [], total: 0, generatedAt: new Date().toISOString() });
  }
}
