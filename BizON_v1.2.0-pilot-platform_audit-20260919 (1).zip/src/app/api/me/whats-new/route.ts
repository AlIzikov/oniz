// BizON API — /api/me/whats-new
// Этап 3.1 — UX-NAV: агрегированная дельта «Что изменилось с вашего визита».
// P0-1 — Professional Truth Dashboard: расширяем ответ тремя блоками:
//   • trustHero      — IP-score + level + delta30days + breakdown (6 осей)
//   • recentEvents   — последние 5 ReputationEvent с типом и +Trust
//   • opportunities  — счётчики (вакансии match>70%, проекты IDEA/PROPOSAL, интро)
// P0-1 (минимум): top-level shortcuts для первого экрана WhatsNewTab:
//   • trustScore          — user.ipScore (alias для trustHero.score)
//   • trustLevel          — user.level   (alias для trustHero.level)
//   • trustDelta30        — last snapshot − snapshot ≥30 дней назад
//   • opportunitiesCount  — { jobs, projects } (короткие ключи)
//
// Окно по умолчанию, если lastVisitAt нет — 7 дней.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { levelFromScore } from '@/lib/reputation';
import { cache, CACHE_TTL } from '@/lib/cache';
import type { TrustLevel } from '@/lib/types';

export const runtime = 'nodejs';

const DEFAULT_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

// Маппинг типов ReputationEvent в человекочитаемые русские подписи и иконки-мета
const EVENT_LABEL_RU: Record<string, string> = {
  project_completed: 'Проект подтверждён',
  skill_confirmed: 'Навык подтверждён',
  positive_review: 'Новая рекомендация',
  intro_sent: 'Интро отправлено',
  connection_accepted: 'Новая связь',
  post_published: 'Опубликован пост',
  job_matched: 'AI-подбор вакансии',
  ad_clicked: 'Реклама',
};

// Типы событий, которые показываются в блоке «Что изменилось» (только позитивные)
const RECENT_EVENT_TYPES = [
  'project_completed',
  'skill_confirmed',
  'positive_review',
  'intro_sent',
];

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Точка отсчёта: previous lastVisitAt (возвращённый клиенту в /api/auth/me),
  // но если его нет — берём неделю назад.
  const sinceParam = req.nextUrl.searchParams.get('since');
  const since = sinceParam
    ? new Date(sinceParam)
    : new Date(Date.now() - DEFAULT_WINDOW_MS);

  const sinceDate = isNaN(since.getTime())
    ? new Date(Date.now() - DEFAULT_WINDOW_MS)
    : since;

  // Phase 16: кэш 30 секунд по userId+since — дельта «что нового» не должна
  // пересчитываться на каждый Polling-запрос (UI может тянуть каждые 10-15с).
  // lastVisitAt берётся из user (объект уже загружен в auth), поэтому в кэше
  // оставляем asOf-метку, чтобы исключить «залипание» при смене визита.
  const cacheKey = `whats-new:${user.id}:${sinceDate.toISOString().slice(0, 16)}`;
  const cached = cache.get<unknown>(cacheKey);
  if (cached !== null) return json(cached);

  const result = await computeWhatsNew(user, sinceDate);
  cache.set(cacheKey, result, CACHE_TTL.SHORT);
  return json(result);
}

type AuthUser = NonNullable<Awaited<ReturnType<typeof getUserFromRequest>>>;

async function computeWhatsNew(
  user: AuthUser,
  sinceDate: Date,
) {

  // ========================================================================
  // ПАРАЛЛЕЛЬНЫЕ ЗАПРОСЫ — старые (дельта с визита) + новые (P0-1)
  // ========================================================================
  const since30days = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const [
    unreadNotifications,
    newCommentsOnOwnPosts,
    newConfirmations,
    newProjectInvites,
    snapshotsSince,
    snapshotsBefore,
    pendingColleagueInquiries,

    // === P0-1: Professional Truth Dashboard ===
    latestSnapshot,
    baseline30Snapshot,
    recentEvents,
    openProjects,
    userSkillNames,
    activeJobs,
    myAppliedJobIds,
    introCount30,

    // === Phase 3: WHILE YOU WERE AWAY — счётчики с прошлого визита ===
    profileViewsSince,
    recommendationsSince,
    newJobsSince,
    newPeopleFromAreaSince,
  ] = await Promise.all([
    // --- Старые запросы (дельта с визита) ---
    db.notification.count({
      where: { userId: user.id, isRead: false },
    }),
    db.postComment.count({
      where: {
        post: { authorId: user.id },
        createdAt: { gte: sinceDate },
      },
    }),
    db.skillConfirmation.count({
      where: {
        userSkill: { userId: user.id },
        createdAt: { gte: sinceDate },
      },
    }),
    db.projectMember.count({
      where: {
        userId: user.id,
        joinedAt: { gte: sinceDate },
      },
    }),
    db.reputationSnapshot.findMany({
      where: { userId: user.id, createdAt: { gte: sinceDate } },
      orderBy: { createdAt: 'asc' },
      select: { ipScore: true, createdAt: true },
    }),
    db.reputationSnapshot.findFirst({
      where: { userId: user.id, createdAt: { lt: sinceDate } },
      orderBy: { createdAt: 'desc' },
      select: { ipScore: true, createdAt: true },
    }),
    db.colleagueInquiry.count({
      where: {
        toUserId: user.id,
        status: 'pending',
        expiresAt: { gt: new Date() },
      },
    }),

    // --- P0-1: TRUST HERO ---
    // Последний snapshot (для breakdown)
    db.reputationSnapshot.findFirst({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        ipScore: true,
        level: true,
        projectsScore: true,
        ratingsScore: true,
        skillsScore: true,
        activityScore: true,
        evidenceCoverage: true,
        createdAt: true,
      },
    }),
    // Snapshot 30 дней назад (baseline для delta30days)
    db.reputationSnapshot.findFirst({
      where: { userId: user.id, createdAt: { lt: since30days } },
      orderBy: { createdAt: 'desc' },
      select: { ipScore: true },
    }),

    // --- P0-1: RECENT EVENTS ---
    // Последние 5 позитивных ReputationEvent
    db.reputationEvent.findMany({
      where: {
        userId: user.id,
        eventType: { in: RECENT_EVENT_TYPES },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        id: true,
        eventType: true,
        impactScore: true,
        weight: true,
        payload: true,
        createdAt: true,
      },
    }),

    // --- P0-1: OPPORTUNITIES / PROJECTS ---
    // Публичные проекты в стадии IDEA / PROPOSAL, не свои
    db.project.count({
      where: {
        status: { in: ['IDEA', 'PROPOSAL'] },
        visibility: 'PUBLIC',
        ownerId: { not: user.id },
      },
    }),

    // --- P0-1: OPPORTUNITIES / JOBS ---
    // Имена подтверждённых навыков пользователя (для расчёта match>70%)
    db.userSkill.findMany({
      where: { userId: user.id, verificationLevel: { not: 'claimed' } },
      include: { skill: { select: { name: true } } },
    }),

    // Активные вакансии (берём необходимый минимум для расчёта match)
    db.job.findMany({
      where: { active: true },
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: { id: true, requiredSkills: true },
    }),

    // Вакансии, на которые пользователь уже откликнулся (исключаем их из счётчика)
    db.jobApplication.findMany({
      where: { userId: user.id, status: { not: 'withdrawn' } },
      select: { jobId: true },
    }),

    // --- P0-1: OPPORTUNITIES / INTROS ---
    // Кол-во intro_sent событий за последние 30 дней
    db.reputationEvent.count({
      where: {
        userId: user.id,
        eventType: 'intro_sent',
        createdAt: { gte: since30days },
      },
    }),

    // === Phase 3: WHILE YOU WERE AWAY — счётчики с прошлого визита ===
    // Только если lastVisitAt > 1 дня назад. Используем lastVisitAt как точку отсчёта,
    // либо fallback на неделю (DEFAULT_WINDOW_MS).
    db.actionEvent.count({
      where: {
        userId: user.id,
        type: 'company_viewed_profile',
        createdAt: { gte: sinceDate },
      },
    }),
    db.actionEvent.count({
      where: {
        userId: user.id,
        type: 'recommendation_received',
        createdAt: { gte: sinceDate },
      },
    }),
    // Новые вакансии за период (любая компания)
    db.job.count({
      where: {
        active: true,
        createdAt: { gte: sinceDate },
      },
    }),
    // Новые люди из той же области (по locationEncrypted)
    user.locationEncrypted
      ? db.user.count({
          where: {
            deletedAt: null,
            id: { not: user.id },
            locationEncrypted: user.locationEncrypted,
            createdAt: { gte: sinceDate },
          },
        })
      : Promise.resolve(0),
  ]);

  // ========================================================================
  // СЧИТАЕМ ДЕЛЬТУ IP-SCORE (за период с визита) — для обратной совместимости
  // ========================================================================
  const baselineScore = snapshotsBefore?.ipScore ?? snapshotsSince[0]?.ipScore ?? user.ipScore;
  const latestScore = snapshotsSince.length > 0
    ? snapshotsSince[snapshotsSince.length - 1].ipScore
    : user.ipScore;
  const trustDelta = latestScore - baselineScore;

  // ========================================================================
  // P0-1: TRUST HERO — score / level / delta30days / breakdown (6 осей)
  // ========================================================================
  const trustHeroScore = user.ipScore;
  const trustHeroLevel: TrustLevel =
    (user.level as TrustLevel) || levelFromScore(user.ipScore);
  const baseline30 = baseline30Snapshot?.ipScore ?? null;
  const delta30days =
    baseline30 !== null ? trustHeroScore - baseline30 : null;

  // breakdown: на основе 4-осевого snapshot → 6-осевой (для UI Truth Hero)
  // Снапшот хранит projectsScore / ratingsScore / skillsScore / activityScore (0..100)
  const snap = latestSnapshot;
  const pScore = snap?.projectsScore ?? 0;
  const rScore = snap?.ratingsScore ?? 0;
  const sScore = snap?.skillsScore ?? 0;
  const aScore = snap?.activityScore ?? 0;

  // 6 осей из аудита (Часть 8):
  //   Компетентность / Надёжность / Delivery / Leadership / Collaboration / Expertise
  const breakdown = {
    competence: sScore,                                // навыки → компетентность
    reliability: rScore,                               // рейтинги → надёжность
    delivery: pScore,                                  // завершённые проекты → delivery
    leadership: Math.min(100, Math.round(pScore * 1.1)), // лидерство ≈ delivery*
    collaboration: aScore,                             // активность → collaboration
    expertise: Math.min(100, Math.round(trustHeroScore * 0.95)), // общий
  };

  // ========================================================================
  // P0-1: RECENT EVENTS — последние 5 позитивных ReputationEvent
  //   Каждое событие получает:
  //     • labelRu — подпись на русском
  //     • deltaTrust — +N (для отображения «+18 Trust»)
  //     • isStar — ★ для positive_review (без числа в аудите)
  // ========================================================================
  const recentEventsOut = recentEvents.map((ev) => {
    let payload: Record<string, any> = {};
    try {
      payload = ev.payload ? JSON.parse(ev.payload) : {};
    } catch {
      payload = {};
    }

    // Дельта Trust: для project_completed и skill_confirmed — есть impactScore (0..1)
    // Масштабируем impact в видимый +N (по аналогии с аудитом: +18 / +7).
    // Для positive_review (★ Новая рекомендация) — без числа (isStar = true).
    const isStar = ev.eventType === 'positive_review';
    let deltaTrust: number | null = null;
    if (!isStar) {
      // Базовый множитель по типу события (для наглядности)
      const baseByType: Record<string, number> = {
        project_completed: 22,
        skill_confirmed: 9,
        intro_sent: 4,
        connection_accepted: 3,
      };
      const base = baseByType[ev.eventType] ?? 5;
      // impactScore 0..1 → коэффициент 0.5..1.5
      const k = 0.5 + Math.min(1, ev.impactScore) * 1.0;
      deltaTrust = Math.max(1, Math.round(base * k));
    }

    // Контекст: имя навыка / название проекта / имя коллеги — для подписи
    let contextName: string | null = null;
    if (ev.eventType === 'skill_confirmed' && payload.skillName) {
      contextName = String(payload.skillName);
    } else if (ev.eventType === 'project_completed' && payload.projectTitle) {
      contextName = String(payload.projectTitle);
    } else if (ev.eventType === 'positive_review' && payload.fromName) {
      contextName = String(payload.fromName);
    } else if (ev.eventType === 'intro_sent' && payload.to) {
      contextName = String(payload.to);
    }

    return {
      id: ev.id,
      eventType: ev.eventType,
      labelRu: EVENT_LABEL_RU[ev.eventType] ?? ev.eventType,
      contextName,
      deltaTrust,
      isStar,
      createdAt: ev.createdAt.toISOString(),
    };
  });

  // ========================================================================
  // P0-1: OPPORTUNITIES — счётчики
  //   • jobsCount  — активные вакансии с match>70% (по verified skills), без откликов
  //   • projectsCount — публичные IDEA/PROPOSAL, не свои
  //   • introCount — intro_sent события за 30 дней
  // ========================================================================
  const appliedJobIds = new Set(myAppliedJobIds.map((a) => a.jobId));
  const verifiedSkillNames = userSkillNames.map((s) => s.skill.name.toLowerCase());

  let jobsCount = 0;
  for (const j of activeJobs) {
    if (appliedJobIds.has(j.id)) continue;
    const req = j.requiredSkills
      ? j.requiredSkills.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)
      : [];
    if (req.length === 0) continue;
    const overlap = req.filter((s) => verifiedSkillNames.includes(s)).length;
    const match = overlap / req.length;
    if (match >= 0.7) jobsCount += 1;
  }

  // ========================================================================
  // Phase 3: WHILE YOU WERE AWAY
  // Если пользователь не заходил > 1 дня — добавляем объект whileAway с
  // счётчиками событий, произошедших с прошлого визита.
  // Если < 1 дня — whileAway = null (UI не показывает баннер).
  // ========================================================================
  const DAY_MS = 24 * 60 * 60 * 1000;
  // Поля User.lastVisitAt нет в текущей схеме — используем последний Session как прокси последнего визита.
  const lastSession = await db.session.findFirst({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    select: { createdAt: true },
  });
  const lastVisit = lastSession?.createdAt ?? null;
  let whileAway: {
    daysAway: number;
    profileViews: number;
    companyJobsAdded: number;
    skillsConfirmed: number;
    newPeopleFromArea: number;
    aiRecommendation: number;
    since: string;
  } | null = null;

  if (lastVisit) {
    const msAway = Date.now() - lastVisit.getTime();
    const daysAway = Math.max(1, Math.floor(msAway / DAY_MS));
    if (msAway >= DAY_MS) {
      whileAway = {
        daysAway,
        profileViews: profileViewsSince,
        companyJobsAdded: newJobsSince,
        skillsConfirmed: newConfirmations,
        newPeopleFromArea: newPeopleFromAreaSince,
        aiRecommendation: recommendationsSince,
        since: lastVisit.toISOString(),
      };
    }
  }

  // 4-g fix (pre-existing bug): computeWhatsNew возвращала json(...) — объект Response.
  // GET-хендлер оборачивал его вторым json() → JSON.stringify(Response) = "{}".
  // Теперь возвращаем plain-объект; сериализацию делает только хендлер.
  return {
    since: sinceDate.toISOString(),
    lastVisitAt: lastVisit?.toISOString() ?? null,
    deltas: {
      messages: unreadNotifications,
      commentsOnOwnPosts: newCommentsOnOwnPosts,
      confirmations: newConfirmations,
      projectInvites: newProjectInvites,
      trustDelta,
      baselineScore,
      latestScore,
      // R9: входящие запросы от коллег
      colleagueInquiries: pendingColleagueInquiries,
    },
    // === P0-1: Professional Truth Dashboard (структурированный объект) ===
    trustHero: {
      score: trustHeroScore,
      level: trustHeroLevel,
      delta30days,
      breakdown,
      evidenceCoverage: snap?.evidenceCoverage ?? null,
    },
    recentEvents: recentEventsOut,
    opportunities: {
      jobsCount,
      projectsCount: openProjects,
      introCount: introCount30,
    },
    // === P0-1: top-level shortcuts (минимальный контракт WhatsNewTab) ===
    // Удобные алиасы для первого экрана — клиенту не нужно лазить вглубь
    // доверенного объекта trustHero / opportunities.
    trustScore: trustHeroScore,                            // = user.ipScore
    trustLevel: trustHeroLevel,                            // = user.level (basic|extended|expert)
    trustDelta30: delta30days,                             // last snapshot − snapshot ≥30 дней назад
    opportunitiesCount: {
      jobs: jobsCount,                                     // вакансии с match ≥ 70% (без откликов)
      projects: openProjects,                              // публичные IDEA/PROPOSAL, не свои
    },
    // === Phase 3: WHILE YOU WERE AWAY ===
    // null если lastVisitAt < 1 дня назад (UI не показывает баннер).
    whileAway,
  };
}
