// BizON API — GET /api/me/profile-views
// Phase 3: кто посмотрел профиль текущего пользователя.
// Возвращает топ-10 просмотров за последние 30 дней.
// Формат: { views: [{ viewerId, viewerName, viewerTitle, viewerAvatar, viewedAt }], total }
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// Окно: 30 дней
const WINDOW_MS = 30 * 24 * 60 * 60 * 1000;
const TOP_LIMIT = 10;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const since = new Date(Date.now() - WINDOW_MS);

  // 1. Считаем общее число уникальных просмотров за 30 дней (для total)
  // Берём все записи, считаем количество — это total просмотров (не уникальных viewer).
  // В спеке указано total без уточнения; берём число просмотров (включая дубли, но
  // т.к. у нас дедупликация 24ч — это и есть «уникальные в день»).
  const [views, total] = await Promise.all([
    db.profileView.findMany({
      where: {
        viewedId: user.id,
        viewedAt: { gte: since },
      },
      include: {
        viewer: {
          select: {
            id: true,
            name: true,
            title: true,
            avatarUrl: true,
            deletedAt: true,
          },
        },
      },
      orderBy: { viewedAt: 'desc' },
      take: TOP_LIMIT,
    }),
    db.profileView.count({
      where: {
        viewedId: user.id,
        viewedAt: { gte: since },
      },
    }),
  ]);

  // Фильтруем удалённых viewers (deletedAt не null)
  const safeViews = views
    .filter((v) => v.viewer && !v.viewer.deletedAt)
    .map((v) => ({
      viewerId: v.viewer.id,
      viewerName: v.viewer.name,
      viewerTitle: v.viewer.title,
      viewerAvatar: v.viewer.avatarUrl,
      viewedAt: v.viewedAt.toISOString(),
    }));

  return json({
    views: safeViews,
    total,
  });
}
