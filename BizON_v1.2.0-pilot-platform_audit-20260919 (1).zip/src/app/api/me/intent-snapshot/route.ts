// BizON API — GET /api/me/intent-snapshot (W4.2, этап 4 аудита)
// Единый снимок намерения: intents + research + profile signals + наблюдаемое
// поведение. Потребители: поиск, карьера, лента — один источник вместо трёх
// независимых AI-профилей.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { UnifiedIntentService } from '@/lib/services/unified-intent-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const snapshot = await UnifiedIntentService.snapshot(user.id);
  return json(snapshot);
}
