// BizON API — /api/me/relationship/[userId] (Wave 1, S-023).
// Режим просмотра профиля определяет СЕРВЕР: contact (accepted-связь) |
// stranger (всё остальное). Клиент не решает сам — принцип «гейт на бэкенде».
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export const GET = withRoute<{ userId: string }>(async (_req, ctx) => {
  const other = ctx.params.userId;
  if (other === ctx.user.id) {
    return NextResponse.json({ mode: 'self', kind: null });
  }
  const conn = await db.connection.findFirst({
    where: {
      status: 'accepted',
      OR: [
        { fromUserId: ctx.user.id, toUserId: other },
        { fromUserId: other, toUserId: ctx.user.id },
      ],
    },
    select: { kind: true, lastVerifiedAt: true, provenance: true },
  });
  if (conn) {
    return NextResponse.json({
      mode: 'contact',
      kind: conn.kind,
      provenance: conn.provenance,
      // Свежесть подтверждения словами, не числом (§3.3)
      verifiedRecently: conn.lastVerifiedAt ? Date.now() - conn.lastVerifiedAt.getTime() < 90 * 86_400_000 : false,
    });
  }
  return NextResponse.json({ mode: 'stranger', kind: null });
});
