// BizON API — GET /api/me/trust-state
// Этап 8.1 (T) — Trust ≠ Currency.
//
// Возвращает ВНУТРЕННЕЕ состояние доверия текущего пользователя:
//   { score, level, trend30days, delta30days, nonTransferable: true }
//
// Принципы:
//   • Только для самого владельца (никакого обмена между аккаунтами).
//   • Trust — это метрика наблюдения, не валюта.
//   • Любые «transfer trust» endpoints — deprecated (410 Gone).
//
// Если нужны deprecated-ответы для старых клиентов, ищущих /api/wallet/transfer —
// см. /api/wallet/transfer/route.ts (возвращает 410 Gone).

import { NextRequest } from 'next/server';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';
import { TrustStateService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest) {
  const user = await getUserFromRequest(_req);
  if (!user) return errorJson('Не авторизован', 401);

  // Soft-deleted пользователь не должен получать trust-state
  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  const state = await TrustStateService.getTrustState(user.id);
  if (!state) return errorJson('Пользователь не найден', 404);

  return json({ trustState: state });
}
