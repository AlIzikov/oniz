// BizON API — /api/me/blind-spots
// P0: «Слепые зоны» — недооценённые сильные стороны пользователя.
//
// GET — анализирует профиль и возвращает массив BlindSpot[]:
//   • skill_gap: навыки где verifiedScore > selfAssessment + 15
//   • role_mismatch: title не соответствует фактическим ролям в проектах
//
// Auth required. Возвращает { spots: BlindSpot[], generatedAt: string }.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { BlindSpotsService } from '@/lib/services/blind-spots-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const spots = await BlindSpotsService.analyze(user.id);
    return json({
      spots,
      generatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error('[blind-spots] GET error:', e);
    return errorJson('Ошибка анализа слепых зон', 500);
  }
}
