// BizON API — GET /api/me/trust-explain
// P0-2: Explainable Trust — breakdown IP-score по 6 категориям.
//
// Принципы (ЧАСТЬ 9 AUDIT):
//   • IP-score НЕ публичный — только владелец видит число.
//   • Trust обязан быть explainable: пользователь видит «почему X»,
//     а не абстрактный балл.
//
// Возвращает:
//   {
//     score, level, breakdown { competence, reliability, delivery,
//     leadership, collaboration, expertise },
//     basis { verifiedProjects, verifiedSkills, recommendations,
//             verifiedResults, professionalInteractions },
//     delta30days, trend[]
//   }
//
// Формулы breakdown — псевдо (можно улучшить позже). Основаны на
// существующих данных: UserSkill (verificationLevel), ProjectMember,
// Project.rating, NFTSkill.

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { cache, CACHE_TTL } from '@/lib/cache';
import { levelFromScore } from '@/lib/reputation';
import type { TrustLevel } from '@/lib/types';

export const runtime = 'nodejs';

// Псевдо-формулы: константы подобраны так, чтобы при типичной активности
// (7 проектов, 11 навыков, 8 рекомендаций) получались значения 80-95.
const COMPETENCE_PER_SKILL = 9;      // 11 verified → 99
const RELIABILITY_PER_PROJECT = 14;  // 7 completed  → 98
const LEADERSHIP_PER_ROLE = 16;      // 5 founder    → 80
const COLLAB_PER_COLLEAGUE = 5;      // 18 colleagues→ 90
const EXPERTISE_PER_NFT = 15;        // 6 NFT        → 90

function clamp(n: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, n));
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Soft-deleted пользователь не должен получать explain
  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  const userId = user.id;

  // Phase 16: кэш 5 минут по userId — trust-explain дорогой (6 запросов в БД).
  // Инвалидируется при новых подтверждениях навыков / завершении проекта
  // (см. cache.invalidatePrefix(`trust-explain:${userId}:`) в mutations).
  const cacheKey = `trust-explain:${userId}`;
  const hit = cache.get<unknown>(cacheKey);
  if (hit !== null) return json(hit);

  const result = await computeTrustExplain(userId);
  if (result) cache.set(cacheKey, result, CACHE_TTL.MEDIUM);
  return result ? json(result) : errorJson('Пользователь не найден', 404);
}

async function computeTrustExplain(userId: string) {

  // === Один batched-запрос всех нужных данных ===
  const [userRow, memberships, skillsRaw, nftSkillsCount, claimsRaw, reputationEventsCount] =
    await Promise.all([
      db.user.findUnique({
        where: { id: userId },
        select: { ipScore: true, level: true },
      }),
      // Все проекты пользователя (для reliability/delivery/leadership/collaboration)
      db.projectMember.findMany({
        where: { userId },
        include: {
          project: {
            select: {
              id: true,
              status: true,
              rating: true,
              outcome: true,
              members: { select: { userId: true } },
            },
          },
        },
      }),
      // Все UserSkill (для competence: verificationLevel != 'claimed')
      db.userSkill.findMany({
        where: { userId },
        select: {
          id: true,
          verificationLevel: true,
          confirmationsCount: true,
          confirmations: { select: { confirmerId: true } },
        },
      }),
      // NFT-навыки (для expertise)
      db.nFTSkill.count({
        where: { userId, status: { in: ['minted', 'confirmed'] } },
      }),
      // Claims (для verifiedResults: status != 'claimed')
      db.claim.findMany({
        where: { userId },
        select: { id: true, status: true },
      }),
      // Активность (professionalInteractions)
      db.reputationEvent.count({ where: { userId } }),
    ]);

  if (!userRow) return null;

  // === Обработка данных ===

  // 1. Competence — verified skills (verificationLevel != 'claimed')
  const verifiedSkills = skillsRaw.filter(
    (s) => s.verificationLevel !== 'claimed',
  );
  const competence = clamp(verifiedSkills.length * COMPETENCE_PER_SKILL);

  // 2. Reliability — завершённые проекты
  const completedProjects = memberships.filter(
    (m) => m.project.status === 'completed',
  );
  const reliability = clamp(completedProjects.length * RELIABILITY_PER_PROJECT);

  // 3. Delivery — проекты с rating > 0 (средний рейтинг)
  const ratedProjects = memberships.filter(
    (m) => m.project.rating > 0,
  );
  const avgRating =
    ratedProjects.length === 0
      ? 0
      : ratedProjects.reduce((sum, m) => sum + m.project.rating, 0) /
        ratedProjects.length;
  const delivery = clamp(Math.round((avgRating / 5) * 100));

  // 4. Leadership — проекты где роль = FOUNDER/CO_FOUNDER
  const founderProjects = memberships.filter(
    (m) => m.role === 'FOUNDER' || m.role === 'CO_FOUNDER',
  );
  const leadership = clamp(founderProjects.length * LEADERSHIP_PER_ROLE);

  // 5. Collaboration — уникальные коллеги (ProjectMember на общих проектах)
  const colleagueIds = new Set<string>();
  for (const m of memberships) {
    for (const other of m.project.members) {
      if (other.userId !== userId) colleagueIds.add(other.userId);
    }
  }
  const collaboration = clamp(colleagueIds.size * COLLAB_PER_COLLEAGUE);

  // 6. Expertise — NFT-навыки (UserSkill с NFTSkill minted/confirmed)
  const expertise = clamp(nftSkillsCount * EXPERTISE_PER_NFT);

  // === basis — основание доверия (видимые пользователю факты) ===

  // verifiedProjects: завершённые проекты с rating > 0
  const verifiedProjectsBasis = completedProjects.filter(
    (m) => m.project.rating > 0,
  ).length;

  // verifiedSkills: UserSkill с verificationLevel != 'claimed'
  const verifiedSkillsBasis = verifiedSkills.length;

  // recommendations: уникальные пользователи, подтвердившие ≥1 skill
  const uniqueRecommenders = new Set<string>();
  skillsRaw.forEach((s) =>
    s.confirmations.forEach((c) => uniqueRecommenders.add(c.confirmerId)),
  );
  const recommendationsBasis = uniqueRecommenders.size;

  // verifiedResults: claims со статусом выше 'claimed'
  const verifiedResultsBasis = claimsRaw.filter(
    (c) => c.status !== 'claimed',
  ).length;

  // professionalInteractions: всего reputation events
  const professionalInteractionsBasis = reputationEventsCount;

  // === score & level ===
  const score = userRow.ipScore;
  const level: TrustLevel =
    (userRow.level as TrustLevel) || levelFromScore(score);

  // === trend & delta30days — из ReputationSnapshot ===
  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const [snapshots, baselineSnapshot] = await Promise.all([
    db.reputationSnapshot.findMany({
      where: { userId, createdAt: { gte: since } },
      orderBy: { createdAt: 'asc' },
      select: {
        id: true,
        ipScore: true,
        level: true,
        projectsScore: true,
        ratingsScore: true,
        skillsScore: true,
        activityScore: true,
        evidenceCoverage: true,
        createdAt: true,
      },
    }),
    db.reputationSnapshot.findFirst({
      where: { userId, createdAt: { lt: since } },
      orderBy: { createdAt: 'desc' },
      select: { ipScore: true },
    }),
  ]);

  const baselineScore = baselineSnapshot?.ipScore ?? snapshots[0]?.ipScore ?? score;
  const delta30days = score - baselineScore;

  const trend = snapshots.map((s) => ({
    id: s.id,
    ipScore: s.ipScore,
    level: s.level,
    breakdown: {
      projectsScore: s.projectsScore,
      ratingsScore: s.ratingsScore,
      skillsScore: s.skillsScore,
      activityScore: s.activityScore,
    },
    evidenceCoverage: s.evidenceCoverage,
    createdAt: s.createdAt.toISOString(),
  }));

  return {
    score,
    level,
    breakdown: {
      competence,
      reliability,
      delivery,
      leadership,
      collaboration,
      expertise,
    },
    basis: {
      verifiedProjects: verifiedProjectsBasis,
      verifiedSkills: verifiedSkillsBasis,
      recommendations: recommendationsBasis,
      verifiedResults: verifiedResultsBasis,
      professionalInteractions: professionalInteractionsBasis,
    },
    delta30days,
    trend,
    // Явная пометка: trust — explainable, не чёрный ящик
    explainable: true as const,
  };
}
