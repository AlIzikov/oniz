// BizON API — GET /api/me/talent-forecast (v6.2, Task 10-a, doc_a §58)
//
// User-facing read-only обёртка над TalentForecastService.forecastScenarios
// (сервис НЕ правится). Существующий talent-forecast — только company-facing
// (POST /api/companies/[id]/talent-forecast), для пользователя «Я» роута не было.
//
// Семантика для пользователя («Ваши сценарии»): прогноз строится так, как будто
// работодатель ищет специалиста с профилем пользователя — отсюда видно,
// сколько на платформе конкурентов с такими же навыками (marketPool) и насколько
// такой профиль дефицитен (сложность найма для работодателя).
//
// Параметры (все опциональны; без них выводятся из профиля):
//   ?role=<текст>          — иначе user.professionalStatus → текущая CareerEntry.title
//   ?skills=A,B,C          — иначе топ-6 навыков пользователя (level/confirmations/возраст)
//   ?count=<int>           — иначе число активных вакансий с этими навыками (спрос)
//   ?deadlineMonths=<int>  — иначе 12 (передаётся в сервис, влияет на baseForecast)
//
// Ответ: { role, requiredSkills, requestedCount, demandJobs, paramsSource,
//          hasSkills, baseForecast, scenarios, summary, note, generatedAt }
//   • baseForecast/scenarios/summary/note — из существующего forecastScenarios
//   • demandJobs — активных вакансий с этими навыками (спрос, честная эвристика CSV-матча)
//   • companyId НЕ возвращается: для user-facing вида он не значим (в сервисе
//     влияет только на company-совет, который в UI пользователя не показывается)
//
// Read-only: никаких записей в БД; ошибки профиля не роняют роут (fail-open к дефолтам).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { TalentForecastService } from '@/lib/services/talent-forecast-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

/** Сколько навыков пользователя берём в прогноз (панель — дайджест, не таблица). */
const TOP_SKILLS_LIMIT = 6;

/** Дефолтная роль, если профиль не заполнен (честно видно в UI как «профиль не указан»). */
const DEFAULT_ROLE = 'Специалист';

function parseCsv(value: string | null): string[] {
  if (!value) return [];
  return value
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 12);
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // session.user приходит целиком (include: { user: true } в auth.ts), поэтому
  // professionalStatus есть в рантайме, но не объявлен в возвращаемом типе
  // getUserFromRequest — сужаем локально (10-a), lib/ не трогаем.
  const professionalStatus = (user as { professionalStatus?: string | null })
    .professionalStatus;

  const rl = checkUserRateLimit(user.id, 'me:talent-forecast', 20, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);

  try {
    const { searchParams } = new URL(req.url);
    const roleParam = searchParams.get('role')?.trim() || '';
    const skillsParam = parseCsv(searchParams.get('skills'));
    const countParamRaw = searchParams.get('count');
    const deadlineMonths = Math.min(60, Math.max(1, Number(searchParams.get('deadlineMonths') ?? 12) || 12));

    // --- 1. Роль: query → professionalStatus → текущая карьерная запись ---
    let role = roleParam;
    let roleSource: 'query' | 'profile' | 'default' = roleParam ? 'query' : 'default';
    if (!role) {
      if (professionalStatus && professionalStatus.trim()) {
        role = professionalStatus.trim();
        roleSource = 'profile';
      } else {
        const currentEntry = await db.careerEntry.findFirst({
          where: { userId: user.id },
          orderBy: [{ isCurrent: 'desc' }, { startDate: 'desc' }, { createdAt: 'desc' }],
          select: { title: true },
        });
        if (currentEntry && currentEntry.title.trim()) {
          role = currentEntry.title.trim();
          roleSource = 'profile';
        }
      }
    }
    if (!role) role = DEFAULT_ROLE;

    // --- 2. Навыки: query → топ-6 профиля (level → confirmations → давние) ---
    let requiredSkills: string[] = skillsParam;
    const skillsSource: 'query' | 'profile' = skillsParam.length > 0 ? 'query' : 'profile';
    if (requiredSkills.length === 0) {
      const userSkills = await db.userSkill.findMany({
        where: { userId: user.id },
        include: { skill: { select: { name: true } } },
        orderBy: [{ level: 'desc' }, { confirmationsCount: 'desc' }, { createdAt: 'asc' }],
        take: TOP_SKILLS_LIMIT,
      });
      requiredSkills = userSkills
        .map((us) => us.skill?.name)
        .filter((name): name is string => Boolean(name && name.trim()));
    }
    // Дедуп без изменения регистра (канонические имена Skill уникальны по базе)
    requiredSkills = Array.from(new Set(requiredSkills));

    // --- 3. Спрос (count): query → активные вакансии с этими навыками ---
    let requestedCount = countParamRaw !== null ? Math.max(0, Number(countParamRaw) || 0) : -1;
    let demandJobs = requestedCount >= 0 ? requestedCount : 0;
    let countSource: 'query' | 'active_jobs' | 'fallback' = 'fallback';
    if (requestedCount < 0) {
      if (requiredSkills.length > 0) {
        // Честная эвристика: CSV requiredSkills у Job → пересечение в JS
        // (детерминированно, без зависимости от LIKE-регистрозависимости БД)
        const activeJobs = await db.job.findMany({
          where: { active: true },
          select: { requiredSkills: true },
          take: 500,
        });
        const needle = new Set(requiredSkills.map((s) => s.toLowerCase()));
        demandJobs = activeJobs.filter((j) =>
          j.requiredSkills
            .split(',')
            .map((s) => s.trim().toLowerCase())
            .some((s) => needle.has(s)),
        ).length;
      } else {
        demandJobs = 0;
      }
      requestedCount = demandJobs > 0 ? demandJobs : 1;
      countSource = demandJobs > 0 ? 'active_jobs' : 'fallback';
    } else {
      countSource = 'query';
      demandJobs = requestedCount;
    }

    // --- 4. Существующий сервис (без правок): forecastScenarios ---
    // companyId в математике не участвует (только company-совет, который в
    // user-facing UI не показывается) — передаём собственную компанию пользователя
    // либо нейтральный 'me'.
    const result = await TalentForecastService.forecastScenarios(user.companyId ?? 'me', {
      role,
      requiredSkills,
      count: requestedCount,
      deadlineMonths,
    });

    return json({
      role: result.role,
      requiredSkills: result.requiredSkills,
      requestedCount: result.requestedCount,
      demandJobs,
      paramsSource: { role: roleSource, skills: skillsSource, count: countSource },
      hasSkills: requiredSkills.length > 0,
      baseForecast: result.baseForecast,
      scenarios: result.scenarios,
      summary: result.summary,
      note: result.note,
      generatedAt: new Date().toISOString(),
    });
  } catch (e: unknown) {
    console.error('[api/me/talent-forecast GET] error:', e);
    return errorJson('Не удалось построить сценарии. Попробуйте позже.', 500);
  }
}
