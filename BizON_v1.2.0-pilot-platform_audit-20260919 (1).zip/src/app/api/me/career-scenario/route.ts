// BizON API — /api/me/career-scenario (P1: «Что если получить навык X»)
// POST body: { skillName: string }
// Возвращает сценарий карьерной симуляции:
//   - newOpportunitiesCount (сколько вакансий открывается)
//   - roleTransition (from → to)
//   - salaryGrowthPct (% роста)
//   - estimatedMonths (~K месяцев)
//   - reasoning (человекочитаемое объяснение)
//   - engine: 'llm' | 'fallback'
// FIX-07: withRoute — auth 401, zod-схема careerScenario (skillName ≤80, strip),
// единый маппинг ошибок; сырой e.message для 5xx больше не возвращается.
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { CareerScenarioService } from '@/lib/services/career-scenario-service';
import { LumenService } from '@/lib/services/lumen-service';

export const runtime = 'nodejs';

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const { skillName } = ctx.data as { skillName: string };

    let spent = false;
    let spendTransactionId: string | undefined;
    try {
      // === Волна 14: ИИ-действия за люмены ===
      // Free: 1 люмен за сценарий; Pro/Business — безлимит.
      if (user.subscriptionTier === 'free') {
        const spend = await LumenService.spend(user.id, 'career_scenario');
        if (!spend.ok) {
          if (spend.code === 'insufficient') {
            return json(
              {
                error: `Недостаточно люменов: нужно ${spend.need}, есть ${spend.have}. Пополните кошелёк — 1 ₽ = 1 люмен.`,
                need: spend.need,
                have: spend.have,
              },
              402
            );
          }
          return errorJson('Неизвестное ИИ-действие', 422);
        }
        spent = true;
      spendTransactionId = spend.ok ? spend.transactionId : undefined;
      }

      const result = await CareerScenarioService.simulate(user.id, skillName.trim());

      // Честность: если LLM недоступен и вернулся fallback — люмен возвращается
      let lumenRefunded = false;
      if (result?.engine === 'fallback' && spent) {
        await LumenService.refund(user.id, 'career_scenario', 'fallback-движок — люмен возвращён', spendTransactionId);
        lumenRefunded = true;
        spent = false;
      }

      return json({ ...result, lumenRefunded });
    } catch (e: unknown) {
      // Честность: списание прошло, но симуляция упала — возвращаем люмен
      if (spent) {
        await LumenService.refund(user.id, 'career_scenario', 'Ошибка симуляции — люмен возвращён', spendTransactionId);
      }
      // FIX-07: пробрасываем дальше — withRoute залогирует одной строкой и вернёт
      // общий 500 без сырого e.message (BizonError сохранит свой статус).
      throw e;
    }
  },
  { schema: schemas.careerScenario },
);
