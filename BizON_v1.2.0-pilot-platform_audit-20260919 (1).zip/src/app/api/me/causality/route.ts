// BizON API — GET /api/me/causality
//
// Professional Causality Engine (doc_a §55, Task 9-f) — персональные гипотезы
// причинности «действие → карьерный исход» (топ-K≤5) с методологической честностью:
// temporal precedence, effect size, confidence low/medium/high, ярлык
// «корреляция; механизм правдоподобен/не проверен» (без LLM, детерминированно).
//
// Мало данных → 200 с честным empty state «Собираем наблюдения» (никаких
// выдуманных корреляций). Вычисления: src/lib/services/causality-engine-service.ts,
// кэш в памяти TTL 10 минут, окно 180 дней, лимит последних 1000 событий.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CausalityEngine } from '@/lib/services/causality-engine-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const result = await CausalityEngine.getPersonalHypotheses(user.id);
    return json(result);
  } catch (e) {
    console.error('[me/causality] failed:', e);
    return errorJson('Не удалось рассчитать гипотезы причинности', 500);
  }
}
