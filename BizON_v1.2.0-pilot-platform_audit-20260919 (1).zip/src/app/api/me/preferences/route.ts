// BizON API — /api/me/preferences
// P0: Персонализация при регистрации — «Что вам интересно?»
//
// POST — сохранить preferences (массив строк):
//   body: { interests: string[], goals: string[], exploreQuiz?: Record<string,string> }
//   interests — что интересно (10 опций: career, business, hiring, projects,
//               expertise, partnerships, management, technology, learning, clients)
//   goals — что хочет от BizON (6 опций: find_job, find_people, find_clients,
//           find_partners, grow_career, show_expertise)
//   exploreQuiz (Wave 11, 11-d) — ответы опросника «Помогите BizON понять вас
//               лучше»: { q1..q6 → ответ }, white-list ALLOWED_QUIZ_VALUES ниже
//               (синхронизирован с EXPLORE_QUIZ_* в src/components/jobs/jobs-types.ts).
//               POST БЕЗ ключа exploreQuiz (например, онбординг пишет только
//               interests/goals) сохранённый опросник НЕ затирает.
//
// GET — получить preferences:
//   { interests: string[], goals: string[], exploreQuiz: Record<string,string>, configured: boolean }
//   configured = interests|goals не пусты ИЛИ опросник пройден (exploreQuiz не пуст).
//
// Auth required. Сохраняется в User.preferences (JSON-строка).
import { db } from '@/lib/db';
import { json, withRoute } from '@/lib/api-helpers'; // FIX-07: withRoute

export const runtime = 'nodejs';

// Разрешённые значения — white-list (защита от мусора)
const ALLOWED_INTERESTS = new Set([
  'career',
  'business',
  'hiring',
  'projects',
  'expertise',
  'partnerships',
  'management',
  'technology',
  'learning',
  'clients',
]);
const ALLOWED_GOALS = new Set([
  'find_job',
  'find_people',
  'find_clients',
  'find_partners',
  'grow_career',
  'show_expertise',
]);

// Wave 11 (11-d): white-list ответов опросника — ключ вопроса → допустимые значения
// (синхронизировано с EXPLORE_QUIZ_QUESTIONS в src/components/jobs/jobs-types.ts)
const ALLOWED_QUIZ_VALUES: Record<string, Set<string>> = {
  q1: new Set(['income_growth', 'new_experience', 'stability', 'scale_role']),
  q2: new Set(['office', 'hybrid', 'remote', 'any_format']),
  q3: new Set(['salary_critical', 'salary_important', 'salary_secondary']),
  q4: new Set(['travel_often', 'travel_sometimes', 'travel_no']),
  q5: new Set(['same_domain', 'adjacent_domain', 'new_domain']),
  q6: new Set(['same_level', 'next_level', 'switch_direction']),
};
const MAX_ITEMS = 10;
const MAX_QUIZ_ANSWERS = 6; // один ответ на каждый из 6 вопросов

interface PreferencesPayload {
  interests: string[];
  goals: string[];
  exploreQuiz: Record<string, string>;
}

function emptyPrefs(): PreferencesPayload {
  return { interests: [], goals: [], exploreQuiz: {} };
}

/** White-list опросника: неизвестные ключи/значения фильтруются, максимум 6 пар. */
function sanitizeQuiz(raw: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return out;
  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (Object.keys(out).length >= MAX_QUIZ_ANSWERS) break;
    const allowed = ALLOWED_QUIZ_VALUES[key];
    if (!allowed || typeof value !== 'string') continue; // мусорный ключ/значение — выбрасываем
    if (allowed.has(value)) out[key] = value;
  }
  return out;
}

function sanitize(raw: unknown): PreferencesPayload {
  const src = (typeof raw === 'object' && raw !== null ? raw : {}) as {
    interests?: unknown;
    goals?: unknown;
    exploreQuiz?: unknown;
  };
  // Array.isArray сужает unknown до unknown[]; type-predicate даёт string[]
  // (иначе new Set(any) выводится как Set<unknown>)
  const interests = Array.isArray(src.interests)
    ? Array.from(new Set(src.interests.filter((x): x is string => typeof x === 'string' && ALLOWED_INTERESTS.has(x)))).slice(0, MAX_ITEMS)
    : [];
  const goals = Array.isArray(src.goals)
    ? Array.from(new Set(src.goals.filter((x): x is string => typeof x === 'string' && ALLOWED_GOALS.has(x)))).slice(0, MAX_ITEMS)
    : [];
  return { interests, goals, exploreQuiz: sanitizeQuiz(src.exploreQuiz) };
}

function isConfigured(prefs: PreferencesPayload): boolean {
  return prefs.interests.length > 0 || prefs.goals.length > 0 || Object.keys(prefs.exploreQuiz).length > 0;
}

/** Читает и санитизирует сохранённые preferences из User.preferences (JSON-строка). */
async function readPrefs(userId: string): Promise<PreferencesPayload> {
  const dbUser = await db.user.findUnique({
    where: { id: userId },
    select: { preferences: true },
  });
  if (!dbUser?.preferences) return emptyPrefs();
  try {
    return sanitize(JSON.parse(dbUser.preferences));
  } catch {
    // Битый JSON — возвращаем пустые
    return emptyPrefs();
  }
}

// FIX-07: withRoute — auth 401, единый маппинг ошибок; валидация — собственный
// whitelist-санитайзер ниже (схема не подключена, чтобы не ломать контракты онбординга).
export const GET = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  const prefs = await readPrefs(user.id);

  return json({
    interests: prefs.interests,
    goals: prefs.goals,
    exploreQuiz: prefs.exploreQuiz,
    configured: isConfigured(prefs),
  });
});

export const POST = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  const body: unknown = ctx.data;
  const prefs = sanitize(body);

  // Wave 11 (11-d): тело БЕЗ ключа exploreQuiz (существующий контракт
  // онбординга {interests, goals}) — сохраняем ранее пройденный опросник.
  const hasQuizKey = typeof body === 'object' && body !== null && 'exploreQuiz' in body;
  if (!hasQuizKey) {
    const existing = await readPrefs(user.id);
    prefs.exploreQuiz = existing.exploreQuiz;
  }

  await db.user.update({
    where: { id: user.id },
    data: { preferences: JSON.stringify(prefs) },
  });

  return json({
    interests: prefs.interests,
    goals: prefs.goals,
    exploreQuiz: prefs.exploreQuiz,
    configured: isConfigured(prefs),
  });
});
