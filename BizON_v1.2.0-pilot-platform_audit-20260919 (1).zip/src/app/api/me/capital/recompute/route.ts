import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CapitalService } from '@/lib/services/capital-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const rl = checkUserRateLimit(user.id, 'capital:recompute', 10, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);
  try {
    await CapitalService.recompute(user.id);
    const capital = await CapitalService.get(user.id);

    // Event Bus: капитал пересчитан (ошибки шины не влияют на ответ API)
    EventBus.publish('capital.recomputed', {
      userId: user.id,
      total: capital?.total ?? 0,
    }).catch(() => undefined);

    return json({ capital, recomputedAt: new Date().toISOString() });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
