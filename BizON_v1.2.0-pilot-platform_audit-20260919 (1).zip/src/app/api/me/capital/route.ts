import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CapitalService } from '@/lib/services/capital-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const capital = await CapitalService.get(user.id);
    const trend = await CapitalService.getTrend(user.id);
    return json({ capital, trend });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
