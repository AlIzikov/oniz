// BizON API — /api/me/intent/[id] (Phase 5: Professional Intent)
// DELETE — удалить/деактивировать намерение по id.
//          Explicit → isActive=false (можно реактивировать).
//          Inferred → физически удаляется (будет пересчитан).
import { NextRequest } from 'next/server';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';
import { IntentService } from '@/lib/services/intent-service';

export const runtime = 'nodejs';

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id: intentId } = await params;
  if (!intentId) return errorJson('intentId обязателен', 422);

  await IntentService.removeIntent(user.id, intentId);
  return json({ ok: true });
}
