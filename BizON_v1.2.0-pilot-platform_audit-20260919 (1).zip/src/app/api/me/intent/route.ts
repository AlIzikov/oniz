// BizON API — /api/me/intent (Phase 5: Professional Intent)
// GET  — все активные намерения (explicit + inferred)
// POST — установить explicit намерение (body: { type })
//        Если такое explicit уже активно — no-op (200).
//        Параллельно запускает inferIntent в fire-and-forget.
import { NextRequest } from 'next/server';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';
import { IntentService, ALL_INTENT_TYPES } from '@/lib/services/intent-service';
import type { IntentType } from '@/lib/services/intent-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const intents = await IntentService.getActiveIntents(user.id);

  // Fire-and-forget: пересчитываем inferred (не блокируя ответ).
  // Это держит inferred-намерения актуальными на каждый запрос (без отдельного cron'а).
  IntentService.inferIntent(user.id).catch((e) => {
    console.error('[api/me/intent GET] inferIntent failed:', e);
  });

  return json({
    intents,
    availableTypes: ALL_INTENT_TYPES,
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { type } = body ?? {};
    if (typeof type !== 'string' || !ALL_INTENT_TYPES.includes(type as IntentType)) {
      return errorJson(
        `type должен быть одним из: ${ALL_INTENT_TYPES.join(', ')}`,
        422,
      );
    }

    const intent = await IntentService.setExplicitIntent(user.id, type as IntentType);
    return json({ intent }, 201);
  } catch (e: any) {
    console.error('[api/me/intent POST] error:', e);
    return errorJson('Ошибка сохранения намерения', 500);
  }
}
