// BizON v6 — HOME-метрики доверия (doc_a п.1, Task 10-c)
//
// GET /api/me/home-metrics — совокупный ответ для HOME-дашборда (dashboard-view):
//   {
//     trust:   { score, factors, explanations, summary, formulaVersion, metrics, computedAt },
//     network: { score, acceptedConnections, secondDegreeReach, recommendationsReceived,
//                distinctConfirmers, summary, computedAt },
//     activity:{ score, events30d, activeDays30d, publicMoments30d, windowDays,
//                summary, computedAt },
//     computedAt
//   }
//
// Professional Trust — «новый стандарт доверия» (doc_a §41), primary-метрика HOME.
// IP-score остаётся легаси-вторичным и отдаётся прежними роутами — здесь его нет.
// Network Influence и Activity — ОТДЕЛЬНЫЕ метрики (в формулу Trust не входят):
//   Network — из связей/рекомендаций (computeNetworkInfluence),
//   Activity — из ActionEvent за 30 дней (computeActivityMetrics).
// Все расчёты детерминированные, read-only (ничего не пишут в БД, кроме штатного
// upsert TrustIndex внутри getProfessionalTrust с кэшем 24ч).
//
// Примечание по зоне: роут создан как read-only точка потребления аддитивных
// экспортов professional-trust-service.ts (зона Task 10-c: HOME-метрики);
// существующий /api/me/professional-trust не изменялся.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { getHomeTrustMetrics } from '@/lib/services/professional-trust-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const data = await getHomeTrustMetrics(user.id);
    return json(data);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Ошибка расчёта метрик';
    return errorJson(message, 500);
  }
}
