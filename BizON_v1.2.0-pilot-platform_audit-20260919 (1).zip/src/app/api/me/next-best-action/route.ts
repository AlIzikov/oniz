// BizON API — /api/me/next-best-action
// P0: «Что сделать сейчас» — одно конкретное действие для пользователя.
//
// GET — анализирует профиль и возвращает NextBestAction или null.
// Auth required. Возвращает { action: NextBestAction | null, generatedAt: string }.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { NextBestActionService } from '@/lib/services/next-best-action-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const action = await NextBestActionService.getAction(user.id);
    return json({
      action,
      generatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error('[next-best-action] GET error:', e);
    return errorJson('Ошибка подбора действия', 500);
  }
}
