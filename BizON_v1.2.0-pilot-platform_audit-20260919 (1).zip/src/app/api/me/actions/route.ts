// BizON API — /api/me/actions
// R10: Actions Timeline — список подтверждённых действий текущего пользователя.
// Поддерживает пагинацию и фильтр по типу события.
import { NextRequest } from 'next/server';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';
import { ActionEventService, type ActionEventType } from '@/lib/services';

export const runtime = 'nodejs';

const ALLOWED_TYPES: ActionEventType[] = [
  // R10 — базовые
  'nft_skill_received',
  'project_completed',
  'project_started',
  'community_joined',
  'article_published',
  'claim_verified',
  // P0-5 — Professional Moments
  'trust_up',
  'evidence_added',
  'skill_verified',
  'recommendation_received',
  'project_verified',
  'new_opportunity',
  'company_viewed_profile',
  'recruiter_invitation',
  'blind_spot_discovered',
];

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const type = req.nextUrl.searchParams.get('type') as ActionEventType | 'all' | null;
  const limit = Number(req.nextUrl.searchParams.get('limit') ?? 30);
  const offset = Number(req.nextUrl.searchParams.get('offset') ?? 0);

  // Валидация типа
  const safeType =
    !type || type === 'all' || ALLOWED_TYPES.includes(type as ActionEventType)
      ? (type as ActionEventType | 'all')
      : 'all';

  const result = await ActionEventService.getActionsForUser(user.id, {
    limit,
    offset,
    type: safeType,
    includePrivate: true, // владелец видит все свои события
  });

  const stats = await ActionEventService.getStats(user.id);

  return json({ ...result, stats });
}
