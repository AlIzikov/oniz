import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { BizonAICore, type InsightType } from '@/lib/ai-core';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const ALLOWED: InsightType[] = ['signal', 'moment', 'blind_spot', 'next_action', 'opportunity', 'scenario'];

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const rl = checkUserRateLimit(user.id, 'ai:analyze', 10, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);
  try {
    const body = await req.json();
    const { question, insightType, event } = body ?? {};
    const type: InsightType = (insightType && ALLOWED.includes(insightType)) ? insightType : 'moment';
    const insight = await BizonAICore.analyze(user.id, { question, insightType: type, event });
    if (!insight) return json({ insight: null, message: 'Не удалось сгенерировать инсайт' });
    return json({ insight });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
