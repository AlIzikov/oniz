// BizON API — POST /api/me/export-data
// Этап 8.2 (DEL) — GDPR ст. 20 / 152-ФЗ ст. 14: право на экспорт данных.
//
// Возвращает ВСЕ данные пользователя как JSON. Не делает ссылку на скачивание —
// для MVP проще отдать весь JSON одним ответом. Если данных много — клиент
// сохраняет файл через диалог сохранения.
//
// Содержимое экспорта:
//   • profile — профиль (PII в открытом виде, т.к. запрашивает сам владелец)
//   • posts — публикации автора
//   • comments — комментарии автора
//   • projects — участие в проектах (с ролью и рейтингом)
//   • skills — навыки и подтверждения
//   • connections — связи
//   • events — организованные и посещённые события
//   • communities — созданные и подписанные сообщества
//   • messages — личные сообщения (без вложений)
//   • notifications — отправленные уведомления
//   • jobApplications — отклики на вакансии
//   • resumes / careerCompasses — сгенерированные резюме и компасы
//   • nftSkills — NFT-навыки
//   • daoVotes — голоса в DAO
//   • referrals — рефералы (сделанные и полученный)
//   • claims — клеймы (Truth Engine) + верификации
//   • savedItems — сохранённые посты/вакансии/объявления
//   • auditLog — события аудита (где actor = пользователь)
//   • reputationSnapshots — история IP-score
//   • meta — версия экспорта, дата, формат
//
// AuditLog: пишем запись read_pii/user (152-ФЗ ст. 19).

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { decrypt } from '@/lib/security/crypto';

export const runtime = 'nodejs';

const EXPORT_VERSION = '1.0.0';
const EXPORT_FORMAT = 'bizon-gdpr-export-v1';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const exportedAt = new Date();

  // Параллельно грузим ВСЕ связанные сущности.
  // Поля соответствуют prisma/schema.prisma — обновлять при изменении схемы.
  const [
    profile,
    posts,
    comments,
    projects,
    skillsRaw,
    skillsConfirmations,
    connectionsFrom,
    connectionsTo,
    eventsOrganized,
    eventParticipations,
    communitiesOwned,
    communityMemberships,
    communityPosts,
    messages,
    conversationsFrom,
    conversationsTo,
    notifications,
    jobApplications,
    resumes,
    careerCompasses,
    nftSkills,
    daoProposals,
    daoVotes,
    referralsMade,
    referredBy,
    claims,
    claimVerifications,
    savedPosts,
    savedJobs,
    savedAds,
    auditLog,
    reputationSnapshots,
    careerEntries,
    hrContactsInitiated,
    hrContactsReceived,
    placementsAsHr,
    placementsAsCandidate,
    colleagueInquiriesSent,
    colleagueInquiriesReceived,
    colleagueInquiriesAbout,
    actionEvents,
    userCourses,
    adImpressions,
    followCompanies,
    companyReviews,
    culturalSignals,
  ] = await Promise.all([
    // 1. Профиль
    db.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        email: true,
        emailEncrypted: true,
        name: true,
        title: true,
        bio: true,
        bioEncrypted: true,
        location: true,
        locationEncrypted: true,
        phone: true,
        phoneEncrypted: true,
        avatarUrl: true,
        birthday: true,
        ipScore: true,
        level: true,
        roles: true,
        accountType: true,
        companyId: true,
        companyPublic: true,
        subscriptionTier: true,
        subscriptionUntil: true,
        isVerified: true,
        verifiedAt: true,
        hrInvisible: true,
        hobbies: true,
        crossDomainOptIn: true,
        showHobbiesToHr: true,
        onboardingStep: true,
        twoFactorEnabled: true,
        newsSources: true,
        notificationSettings: true,
        dndEnabled: true,
        createdAt: true,
        updatedAt: true,
      },
    }),

    // 2. Посты
    db.post.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, content: true, type: true, tags: true,
        imageUrl: true, likesCount: true, commentsCount: true,
        isHidden: true, createdAt: true, updatedAt: true,
      },
    }),

    // 3. Комментарии
    db.postComment.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, postId: true, content: true, createdAt: true },
    }),

    // 4. Проекты (через memberships)
    db.projectMember.findMany({
      where: { userId: user.id },
      include: {
        project: {
          select: {
            id: true, title: true, description: true, status: true,
            rating: true, startedAt: true, completedAt: true, createdAt: true,
            ownerId: true, fundingType: true, visibility: true, budget: true,
          },
        },
      },
      orderBy: { joinedAt: 'desc' },
    }),

    // 5. Навыки пользователя
    db.userSkill.findMany({
      where: { userId: user.id },
      include: { skill: { select: { id: true, name: true, category: true } } },
      orderBy: { createdAt: 'desc' },
    }),

    // 5b. Подтверждения навыков (где confirmer = user)
    db.skillConfirmation.findMany({
      where: { confirmerId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, comment: true, createdAt: true,
        userSkill: { select: { userId: true, skill: { select: { name: true } } } },
        project: { select: { id: true, title: true } },
      },
    }),

    // 6. Связи (исходящие)
    db.connection.findMany({
      where: { fromUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, toUserId: true, status: true, note: true, createdAt: true },
    }),

    // 6b. Связи (входящие)
    db.connection.findMany({
      where: { toUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, fromUserId: true, status: true, note: true, createdAt: true },
    }),

    // 7. События (организованные) — schema: startDate, endDate
    db.event.findMany({
      where: { organizerId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, title: true, description: true, format: true, category: true,
        startDate: true, endDate: true, location: true, createdAt: true,
      },
    }),

    // 7b. Участие в событиях
    db.eventParticipant.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, status: true, createdAt: true,
        event: { select: { id: true, title: true, startDate: true } },
      },
    }),

    // 8. Сообщества (созданные)
    db.community.findMany({
      where: { ownerId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, name: true, slug: true, description: true, category: true, createdAt: true },
    }),

    // 8b. Членство в сообществах
    db.communityMember.findMany({
      where: { userId: user.id },
      orderBy: { joinedAt: 'desc' },
      select: {
        id: true, role: true, joinedAt: true,
        community: { select: { id: true, name: true, slug: true } },
      },
    }),

    // 8c. Посты в сообществах (автор)
    db.communityPost.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, content: true, communityId: true, createdAt: true },
    }),

    // 9. Сообщения
    db.message.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, conversationId: true, content: true, isRead: true, createdAt: true },
    }),

    // 9b. Диалоги (отправитель)
    db.conversation.findMany({
      where: { fromUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, toUserId: true, lastMessageAt: true, createdAt: true },
    }),

    // 9c. Диалоги (получатель)
    db.conversation.findMany({
      where: { toUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, fromUserId: true, lastMessageAt: true, createdAt: true },
    }),

    // 10. Уведомления — schema: content (не body)
    db.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, type: true, title: true, content: true, link: true, isRead: true, createdAt: true },
    }),

    // 11. Отклики на вакансии
    db.jobApplication.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, status: true, matchConfidence: true, aiSummary: true,
        coverLetter: true, applyPath: true, hiringManagerResponse: true,
        createdAt: true, updatedAt: true,
        job: { select: { id: true, title: true, companyId: true } },
      },
    }),

    // 12. Резюме — schema: type, content, aiGenerated, editedAt, createdAt (без updatedAt)
    db.resume.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, type: true, content: true, aiGenerated: true, editedAt: true, createdAt: true },
    }),

    // 12b. Карьерные компасы
    db.careerCompass.findMany({
      where: { userId: user.id },
      orderBy: { generatedAt: 'desc' },
      select: { id: true, currentRole: true, currentDomain: true, transferableSkills: true, suggestedDomains: true, generatedAt: true },
    }),

    // 13. NFT-навыки — schema: metadataUri, weight Float, decayStatus (без tokenUri, isStale)
    db.nFTSkill.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, tokenId: true, contractAddress: true, skillName: true, level: true,
        endorsementsCount: true, mintedAt: true, status: true, metadataUri: true,
        weight: true, lastConfirmedAt: true, decayStatus: true, createdAt: true,
        userSkillId: true,
      },
    }),

    // 14. DAO-предложения — schema: proposerId (не authorId)
    db.daoProposal.findMany({
      where: { proposerId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, description: true, type: true, status: true, startDate: true, endDate: true, createdAt: true },
    }),

    // 14b. DAO-голоса
    db.daoVote.findMany({
      where: { voterId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, proposalId: true, vote: true, weight: true, createdAt: true },
    }),

    // 15. Рефералы (отправленные)
    db.referral.findMany({
      where: { referrerId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, code: true, referredId: true, rewardGiven: true, createdAt: true },
    }),

    // 15b. Реферал (кто меня пригласил)
    db.referral.findFirst({
      where: { referredId: user.id },
      select: { id: true, code: true, referrerId: true, rewardGiven: true, createdAt: true },
    }),

    // 16. Claims (Truth Engine) — schema: type, title, description, status (без subtype)
    db.claim.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, type: true, title: true, description: true, status: true, evidence: true, createdAt: true, updatedAt: true },
    }),

    // 16b. Верификации клеймов (где verifier = user)
    db.claimVerification.findMany({
      where: { verifierId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, status: true, role: true, comment: true, createdAt: true,
        claim: { select: { id: true, title: true, userId: true } },
      },
    }),

    // 17. Saved posts
    db.savedPost.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, postId: true, createdAt: true },
    }),

    // 17b. Saved jobs
    db.savedJob.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, jobId: true, createdAt: true },
    }),

    // 17c. Saved ads
    db.savedAd.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, adId: true, createdAt: true },
    }),

    // 18. Audit log (где actor = user)
    db.auditLog.findMany({
      where: { actorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, action: true, resource: true, resourceId: true, metadata: true, createdAt: true },
    }),

    // 19. Reputation snapshots — schema: projectsScore/ratingsScore/skillsScore/activityScore/evidenceCoverage
    db.reputationSnapshot.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, ipScore: true, level: true,
        projectsScore: true, ratingsScore: true, skillsScore: true, activityScore: true,
        evidenceCoverage: true, createdAt: true,
      },
    }),

    // 20. Career entries
    db.careerEntry.findMany({
      where: { userId: user.id },
      orderBy: { startDate: 'desc' },
      select: { id: true, company: true, position: true, startDate: true, endDate: true, description: true, location: true, verificationLevel: true, createdAt: true },
    }),

    // 21. HR-контакты (инициированные) — schema: hrAgencyId, message (не note/hrId)
    db.hrContact.findMany({
      where: { hrAgencyId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, candidateId: true, initiatedBy: true, message: true, status: true, weekKey: true, createdAt: true },
    }),

    // 21b. HR-контакты (полученные)
    db.hrContact.findMany({
      where: { candidateId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, hrAgencyId: true, initiatedBy: true, message: true, status: true, weekKey: true, createdAt: true },
    }),

    // 22. Placements (как HR) — schema: companyId, jobTitle, placedAt, confirmedByCandidate/Company, isPublic (без jobId/status)
    db.placement.findMany({
      where: { hrAgencyId: user.id },
      orderBy: { placedAt: 'desc' },
      select: { id: true, candidateId: true, candidateName: true, companyId: true, jobTitle: true, placedAt: true, confirmedByCandidate: true, confirmedByCompany: true, isPublic: true },
    }),

    // 22b. Placements (как кандидат)
    db.placement.findMany({
      where: { candidateId: user.id },
      orderBy: { placedAt: 'desc' },
      select: { id: true, hrAgencyId: true, candidateName: true, companyId: true, jobTitle: true, placedAt: true, confirmedByCandidate: true, confirmedByCompany: true, isPublic: true },
    }),

    // 23. Colleague inquiries (отправленные) — schema: message (не question)
    db.colleagueInquiry.findMany({
      where: { fromUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, toUserId: true, aboutUserId: true, message: true, status: true, response: true, isAnonymous: true, createdAt: true, answeredAt: true, expiresAt: true },
    }),

    // 23b. Colleague inquiries (полученные)
    db.colleagueInquiry.findMany({
      where: { toUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, fromUserId: true, aboutUserId: true, message: true, status: true, response: true, isAnonymous: true, createdAt: true, answeredAt: true, expiresAt: true },
    }),

    // 23c. Colleague inquiries (about user)
    db.colleagueInquiry.findMany({
      where: { aboutUserId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, fromUserId: true, toUserId: true, message: true, status: true, response: true, isAnonymous: true, createdAt: true, answeredAt: true, expiresAt: true },
    }),

    // 24. Action events (timeline)
    db.actionEvent.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, type: true, title: true, description: true, isPublic: true, metadata: true, createdAt: true },
    }),

    // 25. User courses (EDU) — schema: status, startedAt, completedAt, certificateNftId (без progress/createdAt)
    db.userCourse.findMany({
      where: { userId: user.id },
      orderBy: { startedAt: 'desc' },
      select: {
        id: true, status: true, startedAt: true, completedAt: true, certificateNftId: true,
        course: { select: { id: true, title: true, provider: true } },
      },
    }),

    // 26. Ad impressions — schema: clicked (не action)
    db.adImpression.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, adId: true, clicked: true, createdAt: true },
    }),

    // 27. Company follows
    db.companyFollower.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, companyId: true, createdAt: true },
    }),

    // 28. Company reviews — schema: authorId (не userId)
    db.companyReview.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, companyId: true, rating: true, title: true, pros: true, cons: true, verifiedEmployee: true, createdAt: true },
    }),

    // 29. Cultural signals — schema: authorId (не userId)
    db.culturalSignal.findMany({
      where: { authorId: user.id },
      orderBy: { createdAt: 'desc' },
      select: { id: true, companyId: true, rating: true, category: true, text: true, isAnonymous: true, isVerified: true, status: true, createdAt: true },
    }),
  ]);

  if (!profile) {
    return errorJson('Профиль не найден', 404);
  }

  // Расшифровываем PII для владельца (он имеет право видеть свои данные в открытом виде)
  const decryptedProfile = {
    ...profile,
    email: profile.emailEncrypted ? decrypt(profile.emailEncrypted) : (profile.email || null),
    bio: profile.bioEncrypted ? decrypt(profile.bioEncrypted) : (profile.bio || null),
    location: profile.locationEncrypted ? decrypt(profile.locationEncrypted) : (profile.location || null),
    phone: profile.phoneEncrypted ? decrypt(profile.phoneEncrypted) : (profile.phone || null),
    emailEncrypted: undefined,
    bioEncrypted: undefined,
    locationEncrypted: undefined,
    phoneEncrypted: undefined,
    birthday: profile.birthday?.toISOString() ?? null,
    subscriptionUntil: profile.subscriptionUntil?.toISOString() ?? null,
    verifiedAt: profile.verifiedAt?.toISOString() ?? null,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt.toISOString(),
  };

  const exportPayload = {
    meta: {
      format: EXPORT_FORMAT,
      version: EXPORT_VERSION,
      exportedAt: exportedAt.toISOString(),
      userId: user.id,
      legalBasis: ['GDPR Art. 20', '152-FZ Art. 14'],
      note: 'Полная выгрузка данных пользователя. PII поля расшифрованы, т.к. запрашивает сам владелец.',
    },
    profile: decryptedProfile,
    posts: posts.map((p) => ({ ...p, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() })),
    comments: comments.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })),
    projects: projects.map((pm) => ({
      membershipId: pm.id,
      role: pm.role,
      joinedAt: pm.joinedAt.toISOString(),
      exitedAt: pm.exitedAt?.toISOString() ?? null,
      exitState: pm.exitState,
      exitReason: pm.exitReason,
      project: {
        ...pm.project,
        startedAt: pm.project.startedAt.toISOString(),
        completedAt: pm.project.completedAt?.toISOString() ?? null,
        createdAt: pm.project.createdAt.toISOString(),
      },
    })),
    skills: skillsRaw.map((us) => ({
      userSkillId: us.id,
      level: us.level,
      confirmationsCount: us.confirmationsCount,
      verificationLevel: us.verificationLevel,
      selfAssessment: us.selfAssessment,
      verifiedScore: us.verifiedScore,
      decayed: us.decayed,
      nftEligible: us.nftEligible,
      createdAt: us.createdAt.toISOString(),
      skill: us.skill,
    })),
    skillsConfirmations: skillsConfirmations.map((sc) => ({
      id: sc.id,
      comment: sc.comment,
      createdAt: sc.createdAt.toISOString(),
      userSkillUserId: sc.userSkill.userId,
      userSkillName: sc.userSkill.skill.name,
      projectTitle: sc.project.title,
    })),
    connections: {
      outgoing: connectionsFrom.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })),
      incoming: connectionsTo.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })),
    },
    events: {
      organized: eventsOrganized.map((e) => ({
        ...e,
        startDate: e.startDate.toISOString(),
        endDate: e.endDate?.toISOString() ?? null,
        createdAt: e.createdAt.toISOString(),
      })),
      participations: eventParticipations.map((ep) => ({
        id: ep.id,
        status: ep.status,
        createdAt: ep.createdAt.toISOString(),
        eventTitle: ep.event.title,
        eventStartDate: ep.event.startDate.toISOString(),
      })),
    },
    communities: {
      owned: communitiesOwned.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })),
      memberships: communityMemberships.map((m) => ({
        id: m.id, role: m.role, joinedAt: m.joinedAt.toISOString(),
        community: m.community,
      })),
      posts: communityPosts.map((p) => ({ ...p, createdAt: p.createdAt.toISOString() })),
    },
    messages: messages.map((m) => ({ ...m, createdAt: m.createdAt.toISOString() })),
    conversations: {
      outgoing: conversationsFrom.map((c) => ({
        ...c,
        lastMessageAt: c.lastMessageAt.toISOString(),
        createdAt: c.createdAt.toISOString(),
      })),
      incoming: conversationsTo.map((c) => ({
        ...c,
        lastMessageAt: c.lastMessageAt.toISOString(),
        createdAt: c.createdAt.toISOString(),
      })),
    },
    notifications: notifications.map((n) => ({ ...n, createdAt: n.createdAt.toISOString() })),
    jobApplications: jobApplications.map((ja) => ({
      ...ja,
      createdAt: ja.createdAt.toISOString(),
      updatedAt: ja.updatedAt.toISOString(),
    })),
    resumes: resumes.map((r) => ({
      ...r,
      editedAt: r.editedAt?.toISOString() ?? null,
      createdAt: r.createdAt.toISOString(),
    })),
    careerCompasses: careerCompasses.map((cc) => ({ ...cc, generatedAt: cc.generatedAt.toISOString() })),
    nftSkills: nftSkills.map((n) => ({
      ...n,
      mintedAt: n.mintedAt?.toISOString() ?? null,
      lastConfirmedAt: n.lastConfirmedAt?.toISOString() ?? null,
      createdAt: n.createdAt.toISOString(),
    })),
    dao: {
      proposals: daoProposals.map((p) => ({
        ...p,
        startDate: p.startDate.toISOString(),
        endDate: p.endDate.toISOString(),
        createdAt: p.createdAt.toISOString(),
      })),
      votes: daoVotes.map((v) => ({ ...v, createdAt: v.createdAt.toISOString() })),
    },
    referrals: {
      made: referralsMade.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })),
      referredBy: referredBy
        ? { ...referredBy, createdAt: referredBy.createdAt.toISOString() }
        : null,
    },
    truth: {
      claims: claims.map((c) => ({ ...c, createdAt: c.createdAt.toISOString(), updatedAt: c.updatedAt.toISOString() })),
      verifications: claimVerifications.map((v) => ({
        ...v,
        createdAt: v.createdAt.toISOString(),
      })),
    },
    savedItems: {
      posts: savedPosts.map((s) => ({ ...s, createdAt: s.createdAt.toISOString() })),
      jobs: savedJobs.map((s) => ({ ...s, createdAt: s.createdAt.toISOString() })),
      ads: savedAds.map((s) => ({ ...s, createdAt: s.createdAt.toISOString() })),
    },
    auditLog: auditLog.map((a) => ({ ...a, createdAt: a.createdAt.toISOString() })),
    reputationSnapshots: reputationSnapshots.map((rs) => ({
      ...rs,
      createdAt: rs.createdAt.toISOString(),
    })),
    careerEntries: careerEntries.map((ce) => ({
      ...ce,
      startDate: ce.startDate?.toISOString() ?? null,
      endDate: ce.endDate?.toISOString() ?? null,
      createdAt: ce.createdAt.toISOString(),
    })),
    hr: {
      contactsInitiated: hrContactsInitiated.map((h) => ({ ...h, createdAt: h.createdAt.toISOString() })),
      contactsReceived: hrContactsReceived.map((h) => ({ ...h, createdAt: h.createdAt.toISOString() })),
      placementsAsHr: placementsAsHr.map((p) => ({ ...p, placedAt: p.placedAt.toISOString() })),
      placementsAsCandidate: placementsAsCandidate.map((p) => ({ ...p, placedAt: p.placedAt.toISOString() })),
    },
    colleagueInquiries: {
      sent: colleagueInquiriesSent.map((ci) => ({
        ...ci,
        createdAt: ci.createdAt.toISOString(),
        answeredAt: ci.answeredAt?.toISOString() ?? null,
        expiresAt: ci.expiresAt.toISOString(),
      })),
      received: colleagueInquiriesReceived.map((ci) => ({
        ...ci,
        createdAt: ci.createdAt.toISOString(),
        answeredAt: ci.answeredAt?.toISOString() ?? null,
        expiresAt: ci.expiresAt.toISOString(),
      })),
      aboutMe: colleagueInquiriesAbout.map((ci) => ({
        ...ci,
        createdAt: ci.createdAt.toISOString(),
        answeredAt: ci.answeredAt?.toISOString() ?? null,
        expiresAt: ci.expiresAt.toISOString(),
      })),
    },
    actionEvents: actionEvents.map((ae) => ({ ...ae, createdAt: ae.createdAt.toISOString() })),
    edu: {
      courses: userCourses.map((uc) => ({
        id: uc.id,
        status: uc.status,
        startedAt: uc.startedAt.toISOString(),
        completedAt: uc.completedAt?.toISOString() ?? null,
        certificateNftId: uc.certificateNftId,
        courseTitle: uc.course.title,
        courseProvider: uc.course.provider,
      })),
    },
    ads: {
      impressions: adImpressions.map((ai) => ({ ...ai, createdAt: ai.createdAt.toISOString() })),
    },
    companies: {
      followed: followCompanies.map((f) => ({ ...f, createdAt: f.createdAt.toISOString() })),
      reviews: companyReviews.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })),
      culturalSignals: culturalSignals.map((cs) => ({ ...cs, createdAt: cs.createdAt.toISOString() })),
    },
  };

  // AuditLog — фиксируем факт экспорта (152-ФЗ ст. 19)
  await db.auditLog.create({
    data: {
      actorId: user.id,
      action: 'data_export',
      resource: 'user',
      resourceId: user.id,
      metadata: JSON.stringify({
        exportedAt: exportedAt.toISOString(),
        format: EXPORT_FORMAT,
        version: EXPORT_VERSION,
        userAgent: req.headers.get('user-agent')?.slice(0, 200) ?? null,
      }),
    },
  });

  const dateStr = exportedAt.toISOString().slice(0, 10).replace(/-/g, '');
  const filename = `bizon-export-${user.id.slice(-8)}-${dateStr}.json`;

  return new Response(JSON.stringify(exportPayload, null, 2), {
    status: 200,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'content-disposition': `attachment; filename="${filename}"`,
      'cache-control': 'no-store',
    },
  });
}
