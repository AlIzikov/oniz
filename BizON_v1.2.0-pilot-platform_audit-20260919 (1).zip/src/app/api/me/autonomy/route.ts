// BizON API — /api/me/autonomy (W3.3, REC-GOV-06)
// GET  — текущий режим автономии пользователя
// PATCH — смена режима: ТОЛЬКО manual | collaborative (Q2: стартовые режимы;
// delegated/autopilot — после пилотных метрик, флаг BIZON_AUTOPILOT_ENABLED)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const state = await GovernanceService.getAutonomy(user.id);
  return json(state);
}

export async function PATCH(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const body = await req.json().catch(() => null);
  const mode = String((body as any)?.mode ?? '');
  if (mode !== 'manual' && mode !== 'collaborative') {
    return errorJson('На старте доступны только режимы manual и collaborative', 422);
  }
  const authority = await GovernanceService.setAutonomy(user.id, mode);
  return json({
    ok: true,
    mode,
    autonomyLevel: authority.autonomyLevel,
    version: authority.version,
  });
}
