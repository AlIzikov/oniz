// BizON API — GET /api/me/career-outcome
//
// KPI Career Outcome Rate (Стратегия v5→v6, п.24 стр. 53-54):
//   «Главный KPI не CTR и не количество откликов, а карьерный результат».
//
// Считает по JobApplication текущего пользователя за окно 180 дней (6 месяцев):
//   - outcomeRate    — доля отправленных откликов, дошедших до interview и дальше
//                      (interview/offer/accepted/hired — по траектории statusHistory);
//   - quality        — доля отклонённых откликов, у которых указана причина (rejectReason);
//   - progression    — разница Professional Capital за окно. CapitalService существует,
//                      но исторических снапшотов капитала в БД нет (ProfessionalCapital —
//                      одна строка на юзера; CapitalService.getTrend() честно возвращает
//                      stable/0) → возвращаем null, а не выдуманную дельту;
//   - regretSignals  — отклики, отклонённые ПОСЛЕ оффера (rejected, в траектории был offer);
//   - counts         — submitted / interview+ / offer+ / hired / rejected.
//
// Эвристика без LLM. При пустых данных — 200 с нулями (нулевые KPI — валидный ответ).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CapitalService } from '@/lib/services/capital-service';

export const runtime = 'nodejs';

const WINDOW_DAYS = 180;
const DAY_MS = 24 * 60 * 60 * 1000;

const round2 = (v: number) => Math.round(v * 100) / 100;

interface HistoryEntry {
  status: string;
  at: string;
  reason?: string;
}

/** Безопасный разбор statusHistory (JSON [{status, at}]) */
function parseHistory(raw: string | null | undefined): HistoryEntry[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (e): e is HistoryEntry =>
        typeof e === 'object' && e !== null &&
        typeof (e as HistoryEntry).status === 'string' &&
        typeof (e as HistoryEntry).at === 'string'
    );
  } catch {
    return [];
  }
}

/** Порядок стадий — зеркало PATCH /api/applications/[id]/status */
const STAGE_ORDER: Record<string, number> = {
  draft: 0,
  preparing: 1,
  submitted: 2,
  viewed: 3,
  reviewed: 4,
  interview: 5,
  offer: 6,
  accepted: 7,
  hired: 7,
};

/** Достигла ли траектория статуса (по истории; для legacy — по текущему статусу) */
function reachedStage(history: HistoryEntry[], current: string, status: string): boolean {
  if (history.some((h) => h.status === status)) return true;
  return (STAGE_ORDER[current] ?? -1) >= (STAGE_ORDER[status] ?? 999);
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const since = new Date(Date.now() - WINDOW_DAYS * DAY_MS);

  const [applications, capital] = await Promise.all([
    db.jobApplication.findMany({
      where: { userId: user.id, createdAt: { gte: since } },
      select: { status: true, rejectReason: true, statusHistory: true, createdAt: true },
    }),
    // Professional Capital — текущее значение для контекста (см. progression ниже)
    CapitalService.get(user.id).catch(() => null),
  ]);

  let submitted = 0;
  let reachedInterview = 0;
  let reachedOffer = 0;
  let hired = 0;
  let rejected = 0;
  let rejectedWithReason = 0;
  let regretSignals = 0;

  for (const a of applications) {
    const history = parseHistory(a.statusHistory);

    // Не отправленные (draft/preparing) и отозванные (withdrawn) — вне карьерного цикла
    if (a.status === 'draft' || a.status === 'preparing' || a.status === 'withdrawn') continue;
    submitted += 1;

    if (a.status === 'rejected') {
      rejected += 1;
      if (a.rejectReason && a.rejectReason.trim().length > 0) rejectedWithReason += 1;
      // Regret Rate (п.24): оффер был, но исход — отказ
      if (history.some((h) => h.status === 'offer')) regretSignals += 1;
    }

    // Финальный позитивный исход
    if (a.status === 'accepted' || a.status === 'hired') hired += 1;

    // «Дошёл до X+» — по траектории (interview+ / offer+)
    if (reachedStage(history, a.status, 'interview')) reachedInterview += 1;
    if (reachedStage(history, a.status, 'offer')) reachedOffer += 1;
  }

  const outcomeRate = submitted === 0 ? 0 : round2(reachedInterview / submitted);
  const quality = rejected === 0 ? 0 : round2(rejectedWithReason / rejected);

  return json({
    outcomeRate,
    quality,
    // Разница Professional Capital: снапшотов истории нет → честный null
    // (не выдумываем дельту; CapitalService.getTrend() в v6 тоже stable/0)
    progression: null as number | null,
    progressionNote: capital
      ? 'Исторических снапшотов Professional Capital нет — разница станет доступна после накопления еженедельных пересчётов'
      : 'Professional Capital ещё не рассчитан',
    currentCapitalTotal: capital?.total ?? null,
    regretSignals,
    windowDays: WINDOW_DAYS,
    counts: {
      submitted,
      interview: reachedInterview,
      offer: reachedOffer,
      hired,
      rejected,
    },
    generatedAt: new Date().toISOString(),
  });
}
