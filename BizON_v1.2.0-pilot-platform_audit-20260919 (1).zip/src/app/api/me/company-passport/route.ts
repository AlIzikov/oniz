// BizON API — GET /api/me/company-passport
// Phase 10: Company Passport — статус (enabled + token) для дашборда компании.
//
// Возвращает:
//   { enabled, token, publicUrl, companyName }
//
// Если token=null и enabled=false — паспорт ещё не инициализирован.
// Авторизация: только пользователь с accountType='company'/'hr_agency' + companyId.

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (user.accountType !== 'company' && user.accountType !== 'hr_agency') {
    return errorJson('Только для аккаунтов компаний', 403);
  }
  if (!user.companyId) {
    return errorJson('Аккаунт не привязан к компании', 400);
  }

  try {
    const company = await db.company.findUnique({
      where: { id: user.companyId },
      select: {
        id: true,
        name: true,
        passportToken: true,
        passportEnabled: true,
        updatedAt: true,
      },
    });
    if (!company) return errorJson('Компания не найдена', 404);

    const enabled = !!company.passportEnabled;
    const token = company.passportToken ?? null;

    return json({
      enabled,
      token,
      publicUrl: token ? `/c/${token}` : null,
      companyName: company.name,
      updatedAt: company.updatedAt.toISOString(),
    });
  } catch (e) {
    console.error('[company-passport status] error:', e);
    return errorJson('Ошибка получения статуса Company Passport', 500);
  }
}
