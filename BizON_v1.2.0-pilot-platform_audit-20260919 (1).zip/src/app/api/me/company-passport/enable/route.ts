// BizON API — POST /api/me/company-passport/enable
// Phase 10: Company Passport — включение публичного паспорта компании.
//
// Авторизация: только пользователь с accountType='company' (или hr_agency),
// у которого есть companyId. Только владелец-администратор компании может включать
// публичный паспорт.
//
// Что делает:
//   • Генерирует непредсказуемый token (32 байта → 64 hex)
//   • Выставляет Company.passportEnabled=true
//   • Возвращает token + публичный URL (для QR-кода и share)
//
// Если уже включён — переиспользуем существующий token (idempotent).

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { CompanyPassportService } from '@/lib/services/company-passport-service';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

function buildPublicUrl(token: string): string {
  // Относительный URL — клиент подставит origin.
  return `/c/${token}`;
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только компания (или hr_agency) с привязкой companyId
  if (user.accountType !== 'company' && user.accountType !== 'hr_agency') {
    return errorJson('Только для аккаунтов компаний', 403);
  }
  if (!user.companyId) {
    return errorJson('Аккаунт не привязан к компании', 400);
  }

  // Soft-deleted не может менять настройки
  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  try {
    // Доп. проверка: пользователь действительно владелец/админ компании.
    // На MVP — любой сотрудник компании может управлять passport-флагом.
    // (Расширение: добавить CompanyAdminRole и проверку.)
    const company = await db.company.findUnique({
      where: { id: user.companyId },
      select: { id: true, name: true },
    });
    if (!company) return errorJson('Компания не найдена', 404);

    const { token, updatedAt } = await CompanyPassportService.enable(company.id);

    await AuditLog.log({
      actorId: user.id,
      action: 'enable_company_passport',
      resource: 'company',
      resourceId: company.id,
      ip: getClientIP(req),
      metadata: { companyName: company.name, updatedAt },
    });

    return json({
      enabled: true,
      token,
      publicUrl: buildPublicUrl(token),
      absoluteUrlHint:
        'Клиент строит абсолютный URL из window.location.origin + publicUrl',
      updatedAt,
    });
  } catch (e) {
    console.error('[company-passport/enable] error:', e);
    return errorJson('Ошибка включения Company Passport', 500);
  }
}
