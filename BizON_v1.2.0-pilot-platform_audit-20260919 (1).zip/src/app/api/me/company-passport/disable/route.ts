// BizON API — POST /api/me/company-passport/disable
// Phase 10: Company Passport — отключение публичного паспорта компании.
//
// Что делает:
//   • Выставляет Company.passportEnabled=false
//   • Token НЕ стираем (для быстрого re-enable без перегенерации)
//   • Публичная ссылка /c/<token> сразу возвращает 404
//
// Авторизация: только пользователь с accountType='company'/'hr_agency' + companyId.

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { CompanyPassportService } from '@/lib/services/company-passport-service';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (user.accountType !== 'company' && user.accountType !== 'hr_agency') {
    return errorJson('Только для аккаунтов компаний', 403);
  }
  if (!user.companyId) {
    return errorJson('Аккаунт не привязан к компании', 400);
  }

  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  try {
    const company = await db.company.findUnique({
      where: { id: user.companyId },
      select: { id: true, name: true },
    });
    if (!company) return errorJson('Компания не найдена', 404);

    const { updatedAt } = await CompanyPassportService.disable(company.id);

    await AuditLog.log({
      actorId: user.id,
      action: 'disable_company_passport',
      resource: 'company',
      resourceId: company.id,
      ip: getClientIP(req),
      metadata: { companyName: company.name, updatedAt },
    });

    return json({ enabled: false, updatedAt });
  } catch (e) {
    console.error('[company-passport/disable] error:', e);
    return errorJson('Ошибка отключения Company Passport', 500);
  }
}
