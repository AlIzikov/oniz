import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MemoryService } from '@/lib/services/memory-service';
import { ProfessionalMemoryService } from '@/lib/services/professional-memory-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    // v6.2 (Task 9-b, doc_a §32/§53): trajectory — годовая траектория
    // профессионала (аддитивно; старые поля narrative/evolution не изменены).
    const [narrative, evolution, trajectory] = await Promise.all([
      MemoryService.buildNarrative(user.id),
      MemoryService.getEvolution(user.id),
      ProfessionalMemoryService.getYearlyTrajectory(user.id).catch((e: unknown) => {
        // Fail-open: траектория не должна ломать старый ответ memory
        console.error('[api/me/memory] trajectory failed:', e);
        return null;
      }),
    ]);
    return json({ narrative, evolution, trajectory });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
