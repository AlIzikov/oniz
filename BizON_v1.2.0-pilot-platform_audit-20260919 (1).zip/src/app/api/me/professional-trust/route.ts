// BizON v6 — Professional Trust API (doc_a §41)
// GET  → текущий Professional Trust (кэш 24ч; пересчёт по устареванию)
// POST → принудительный пересчёт и возврат результата
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { getProfessionalTrust, computeProfessionalTrust } from '@/lib/services/professional-trust-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const trust = await getProfessionalTrust(user.id);
    return json({
      score: trust.score,
      factors: trust.factors,
      explanations: trust.explanations,
      summary: trust.summary,
      formulaVersion: trust.formulaVersion,
      metrics: trust.metrics,
      computedAt: trust.computedAt,
    });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Ошибка';
    return errorJson(message, 500);
  }
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const rl = checkUserRateLimit(user.id, 'professional-trust:recompute', 30, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);
  try {
    const trust = await computeProfessionalTrust(user.id);
    return json({
      score: trust.score,
      factors: trust.factors,
      explanations: trust.explanations,
      summary: trust.summary,
      formulaVersion: trust.formulaVersion,
      metrics: trust.metrics,
      computedAt: trust.computedAt,
      recomputed: true,
    });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Ошибка';
    return errorJson(message, 500);
  }
}
