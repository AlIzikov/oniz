// BizON API — GET /api/me/mentorships
// Phase 11: Mentor Graph — мои наставничества (as mentee + as mentor).
//
// Возвращает:
//   {
//     asMentee: MentorshipPublic[],
//     asMentor: MentorshipPublic[]
//   }
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MentorService } from '@/lib/services/mentor-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const result = await MentorService.listMyMentorships(user.id);
    return json(result);
  } catch (e) {
    console.error('[api/me/mentorships] error:', e);
    return errorJson('Ошибка загрузки наставничеств', 500);
  }
}
