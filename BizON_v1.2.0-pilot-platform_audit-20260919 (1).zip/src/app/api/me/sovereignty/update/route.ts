// BizON v6 — Data Sovereignty onboarding: сбор согласий пользователя
// PDF «doc_scaling» §2-4, 27: Gateway проверяет User.citizenship/region/consentAiAnalysis/
// consentCrossBorder, но раньше эти поля нигде не заполнялись → regulation всегда 'none',
// gateway был инертен. Эта ручка включает их сбор из UI настроек.

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { SovereigntyGateway } from '@/lib/sovereignty/gateway';

export const runtime = 'nodejs';

const CITIZENSHIPS = ['RU', 'EU', 'BRICS', 'OTHER'] as const;
type Citizenship = (typeof CITIZENSHIPS)[number];

type SovereigntyPatch = {
  citizenship?: string | null;
  region?: string | null;
  consentAiAnalysis?: boolean;
  consentCrossBorder?: boolean;
};

/** GET — текущие значения 4 полей + computed regulation (через Gateway). */
export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const stored = await db.user.findUnique({
      where: { id: user.id },
      select: { citizenship: true, region: true, consentAiAnalysis: true, consentCrossBorder: true },
    });
    // Пустой список полей: Gateway в этом случае только вычисляет regulation
    // по citizenship/region из БД (findUnique без кэша — данные всегда свежие).
    const decision = await SovereigntyGateway.check(user.id, 'sovereignty.status', []);
    return json({
      citizenship: (stored?.citizenship as Citizenship | null) ?? null,
      region: stored?.region ?? null,
      consentAiAnalysis: stored?.consentAiAnalysis ?? false,
      consentCrossBorder: stored?.consentCrossBorder ?? false,
      regulation: decision.regulation,
    });
  } catch (e: unknown) {
    return errorJson(e instanceof Error ? e.message : 'Ошибка загрузки настроек суверенитета', 500);
  }
}

/** PATCH — частичное обновление настроек суверенитета + sovereignty-проверка. */
export async function PATCH(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const body: unknown = await req.json().catch(() => null);
    if (typeof body !== 'object' || body === null || Array.isArray(body)) {
      return errorJson('Ожидался JSON-объект', 422);
    }
    const b = body as Record<string, unknown>;
    const data: SovereigntyPatch = {};

    if ('citizenship' in b) {
      const c = b.citizenship;
      if (c !== null && !(typeof c === 'string' && (CITIZENSHIPS as readonly string[]).includes(c))) {
        return errorJson('citizenship: ожидается RU | EU | BRICS | OTHER | null', 422);
      }
      data.citizenship = (c as Citizenship | null) ?? null;
    }

    if ('region' in b) {
      const r = b.region;
      if (r !== null && typeof r !== 'string') {
        return errorJson('region: ожидается строка до 50 символов или null', 422);
      }
      if (typeof r === 'string') {
        const trimmed = r.trim();
        if (trimmed.length > 50) return errorJson('region: максимум 50 символов', 422);
        data.region = trimmed.length > 0 ? trimmed : null;
      } else {
        data.region = null;
      }
    }

    if ('consentAiAnalysis' in b) {
      if (typeof b.consentAiAnalysis !== 'boolean') {
        return errorJson('consentAiAnalysis: ожидается boolean', 422);
      }
      data.consentAiAnalysis = b.consentAiAnalysis;
    }

    if ('consentCrossBorder' in b) {
      if (typeof b.consentCrossBorder !== 'boolean') {
        return errorJson('consentCrossBorder: ожидается boolean', 422);
      }
      data.consentCrossBorder = b.consentCrossBorder;
    }

    if (Object.keys(data).length === 0) {
      return errorJson('Нет полей для обновления: citizenship, region, consentAiAnalysis, consentCrossBorder', 422);
    }

    const updated = await db.user.update({
      where: { id: user.id },
      data,
      select: { citizenship: true, region: true, consentAiAnalysis: true, consentCrossBorder: true },
    });

    // Gateway каждый раз читает User через db.user.findUnique (без кэша),
    // поэтому после update он сразу применяет правила 152-ФЗ/GDPR.
    const decision = await SovereigntyGateway.check(user.id, 'sovereignty.settings', ['citizenship', 'region']);

    return json({
      citizenship: (updated.citizenship as Citizenship | null) ?? null,
      region: updated.region,
      consentAiAnalysis: updated.consentAiAnalysis,
      consentCrossBorder: updated.consentCrossBorder,
      decision,
    });
  } catch (e: unknown) {
    return errorJson(e instanceof Error ? e.message : 'Ошибка сохранения настроек суверенитета', 500);
  }
}
