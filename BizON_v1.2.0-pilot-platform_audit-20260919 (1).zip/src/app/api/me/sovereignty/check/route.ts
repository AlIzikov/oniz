import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { SovereigntyGateway } from '@/lib/sovereignty/gateway';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const body = await req.json();
    const { operation, fields, region } = body ?? {};
    if (!operation || !Array.isArray(fields)) return errorJson('operation и fields[] обязательны', 422);
    const decision = await SovereigntyGateway.check(user.id, operation, fields, region);
    return json({ decision });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
