// BizON API — POST /api/me/passport/disable
// P0-4: Professional Passport — отключение публичного паспорта.
//
// Что делает:
//   • Выставляет passportEnabled=false
//   • Token НЕ стираем (для быстрого re-enable без перегенерации)
//   • Публичная ссылка /p/<token> сразу возвращает 404
//
// Авторизация: только сам владелец (cookie session).

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { PassportService } from '@/lib/services';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  try {
    const { updatedAt } = await PassportService.disable(user.id);

    await AuditLog.log({
      actorId: user.id,
      action: 'disable_passport',
      resource: 'user',
      resourceId: user.id,
      ip: getClientIP(req),
      metadata: { updatedAt },
    });

    return json({ enabled: false, updatedAt });
  } catch (e) {
    console.error('[passport/disable] error:', e);
    return errorJson('Ошибка отключения паспорта', 500);
  }
}
