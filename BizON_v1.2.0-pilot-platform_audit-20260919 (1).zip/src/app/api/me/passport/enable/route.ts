// BizON API — POST /api/me/passport/enable
// P0-4: Professional Passport — включение публичного паспорта.
//
// Что делает:
//   • Генерирует непредсказуемый token (32 байта → 64 hex)
//   • Выставляет passportEnabled=true
//   • Возвращает token + публичный URL (для QR-кода и share)
//
// Авторизация: только сам владелец (cookie session).
// Если уже включён — переиспользуем существующий token (idempotent).

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { PassportService } from '@/lib/services';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

function buildPublicUrl(token: string): string {
  // Относительный URL — клиент сам подставит origin (для QR / share).
  // В preview-среде origin = preview-домен z.ai; в prod — bizon.app.
  return `/p/${token}`;
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Soft-deleted не может менять настройки
  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  try {
    const { token, updatedAt } = await PassportService.enable(user.id);

    // AuditLog: фиксируем включение публичного паспорта (152-ФЗ ст. 19)
    await AuditLog.log({
      actorId: user.id,
      action: 'enable_passport',
      resource: 'user',
      resourceId: user.id,
      ip: getClientIP(req),
      metadata: { updatedAt },
    });

    return json({
      enabled: true,
      token,
      publicUrl: buildPublicUrl(token),
      absoluteUrlHint:
        'Клиент строит абсолютный URL из window.location.origin + publicUrl',
      updatedAt,
    });
  } catch (e) {
    console.error('[passport/enable] error:', e);
    return errorJson('Ошибка включения паспорта', 500);
  }
}
