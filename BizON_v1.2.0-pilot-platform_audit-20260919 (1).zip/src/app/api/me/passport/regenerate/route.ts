// BizON API — POST /api/me/passport/regenerate
// P0-4: Professional Passport — смена публичной ссылки (token rotation).
//
// Что делает:
//   • Генерирует новый token, старый аннулируется (UNIQUE constraint → перезапись)
//   • passportEnabled=true (если был выключен — включает)
//   • Возвращает новый token + URL
//
// Когда использовать:
//   • Ссылка утекла (отправили не тому человеку)
//   • Хочется «новую чистую ссылку»
//
// Авторизация: только сам владелец.

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { PassportService } from '@/lib/services';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if ((user as { deletedAt?: Date | null }).deletedAt) {
    return errorJson('Аккаунт помечен на удаление', 410);
  }

  try {
    const { token, updatedAt } = await PassportService.regenerate(user.id);

    await AuditLog.log({
      actorId: user.id,
      action: 'regenerate_passport',
      resource: 'user',
      resourceId: user.id,
      ip: getClientIP(req),
      metadata: { updatedAt },
    });

    return json({
      enabled: true,
      token,
      publicUrl: `/p/${token}`,
      updatedAt,
    });
  } catch (e) {
    console.error('[passport/regenerate] error:', e);
    return errorJson('Ошибка перегенерации ссылки', 500);
  }
}
