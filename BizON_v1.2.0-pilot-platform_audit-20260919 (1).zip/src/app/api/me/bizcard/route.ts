// BizON API — /api/me/bizcard (Wave 1, S-022): цифровая визитка 1:1 на пользователя.
// POST: собирает карточку (REUSE паспорт-токена /p/[token]); QR генерируется
// server-side (qrcode уже в зависимостях). Включаемые поля — по чекбоксам владельца.
// Никаких публичных чисел: только имя/роль/контакты/навыки.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import QRCode from 'qrcode';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';
import { PassportService } from '@/lib/services/passport-service';
import { appUrl } from '@/lib/services/verification-token';

export const runtime = 'nodejs';

const bizcardSchema = z.object({
  displayName: z.string().max(60).optional(),
  includes: z.object({
    email: z.boolean().default(true),
    phone: z.boolean().default(false),
    skills: z.boolean().default(true),
  }).default({ email: true, phone: false, skills: true }),
});

export const POST = withRoute(async (_req, ctx) => {
  const data = bizcardSchema.parse(ctx.data ?? {});

  // REUSE: токен/включение публичной страницы паспорта.
  const { token } = await PassportService.enable(ctx.user.id);
  const user = await db.user.findUnique({
    where: { id: ctx.user.id },
    select: {
      name: true, title: true, email: true, phone: true,
      emailVerified: true, location: true,
    },
  });
  if (!user) return NextResponse.json({ error: 'Пользователь не найден' }, { status: 404 });

  // Топ-навыки: по числу подтверждений (внутренний сигнал сортировки).
  const skillRows = await db.userSkill.findMany({
    where: { userId: ctx.user.id, skill: { name: { not: '' } } },
    select: { confirmationsCount: true, skill: { select: { name: true } } },
    orderBy: { confirmationsCount: 'desc' },
    take: 5,
  });
  const skills = skillRows.map((s) => s.skill.name);

  const url = `${appUrl()}/p/${token}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 240, margin: 1 });

  return NextResponse.json({
    displayName: data.displayName?.trim() || user.name,
    headline: user.title ?? user.location ?? null,
    qrDataUrl,
    publicToken: token,
    includes: data.includes,
    contactEmail: user.emailVerified ? user.email : null, // email только подтверждённый
    contactPhone: user.phone ?? null,
    skills,
  });
});
