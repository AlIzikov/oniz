// BizON API — GET /api/me/skills/graph
// Phase 5 / Spec §D.2 — Skill Graph: explainable skill vector for current user.
//
// Возвращает массив навыков с:
//   - currentLevel (1..10) — после decay
//   - peakLevel   (1..10) — исторический максимум (монотонно не убывает)
//   - confidence  (0..1)
//   - decayStatus (fresh | stale | decayed)
//   - breakdown   (B1..B4 points)
//   - explanation (human-readable)
//   - evidence[]  (drilldown до Proof nodes)
//
// Опциональные query-параметры:
//   ?persist=false — не записывать вычисленные поля в UserSkill (для preview)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { buildSkillGraphForUser } from '@/lib/services/skill-graph-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const persistParam = req.nextUrl.searchParams.get('persist');
  const persist = persistParam !== 'false';

  try {
    const skills = await buildSkillGraphForUser(user.id, { persist });
    return json({
      skills,
      stats: {
        total: skills.length,
        fresh: skills.filter((s) => s.decayStatus === 'fresh').length,
        stale: skills.filter((s) => s.decayStatus === 'stale').length,
        decayed: skills.filter((s) => s.decayStatus === 'decayed').length,
        avgLevel: skills.length
          ? Math.round((skills.reduce((a, s) => a + s.currentLevel, 0) / skills.length) * 10) / 10
          : 0,
        avgConfidence: skills.length
          ? Math.round((skills.reduce((a, s) => a + s.confidence, 0) / skills.length) * 100) / 100
          : 0,
      },
    });
  } catch (e) {
    console.error('[api/me/skills/graph] error:', e);
    return errorJson('Ошибка построения Skill Graph', 500);
  }
}
