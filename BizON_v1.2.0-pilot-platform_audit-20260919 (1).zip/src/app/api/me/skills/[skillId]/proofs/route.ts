// BizON API — GET /api/me/skills/[skillId]/proofs
// Phase 6 / Spec §D.9 — Proof-of-Skill drilldown.
//
// Возвращает плоский массив всех доказательств для конкретного навыка:
//   - Projects где пользователь участник и навык в requiredSkills/tags
//   - SkillConfirmations для этого навыка
//   - Claims с этим навыком (skill | experience | achievement | role | result)
//   - Results (COMPLETED project outcome | result-type Claim)
//   - Recommendations (ClaimVerification с comment)
//
// Каждый proof содержит: { source, type, date, projectName, role, result,
//   verifier, confidence, status } — для UI drilldown «ПОЧЕМУ у меня level X?».
//
// Авторизация: только сам владелец (cookie session).

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { getProofsForSkill } from '@/lib/skills/proof-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, ctx: { params: Promise<{ skillId: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { skillId } = await ctx.params;

  try {
    const result = await getProofsForSkill(user.id, skillId);
    if (!result) return errorJson('Навык не найден', 404);
    return json(result);
  } catch (e) {
    console.error('[api/me/skills/[skillId]/proofs] error:', e);
    return errorJson('Ошибка построения Proof-of-Skill', 500);
  }
}
