// BizON API — POST /api/me/skills/[skillId]/resurrect
// Phase 5 / Spec §D.7 Resurrection path — AI-recommended (не authoritative).
//
// Тело (опционально):
//   { "targetLevel": 7 }  — целевой уровень (по умолчанию = peakLevel)
//
// Возвращает:
//   - currentLevel, peakLevel, decayStatus
//   - steps[] — конкретные действия для восстановления
//   - estimatedTime — оценка времени
//   - deltaLevels — на сколько уровней нужно подняться
//
// ВАЖНО: endpoint НЕ мутирует currentLevel — только возвращает план действий.
// Реальное восстановление происходит после добавления новых проектов/подтверждений.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { buildResurrectionPath } from '@/lib/services/skill-graph-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, ctx: { params: Promise<{ skillId: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { skillId } = await ctx.params;

  let targetLevel: number | undefined;
  try {
    const body = await req.json().catch(() => ({}));
    if (typeof body?.targetLevel === 'number') {
      targetLevel = Math.max(1, Math.min(10, Math.floor(body.targetLevel)));
    }
  } catch {
    // body пустой — ОК, используем peakLevel по умолчанию
  }

  try {
    const path = await buildResurrectionPath(user.id, skillId, targetLevel);
    if (!path) return errorJson('Навык не найден', 404);

    return json(path);
  } catch (e) {
    console.error('[api/me/skills/[skillId]/resurrect] error:', e);
    return errorJson('Ошибка построения маршрута восстановления', 500);
  }
}
