// BizON API — GET /api/me/skills/[skillId]/explain
// Phase 5 / Spec §D.9 — "Почему у меня Skill Level X?" → полная разбивка.
//
// Возвращает:
//   - текущий level, peak, confidence, decayStatus
//   - breakdown по 4 бакетам (B1..B4 points / ceiling)
//   - explanation (human-readable)
//   - evidence[] — drilldown до Proof nodes
//   - nextLevelRequirements[] — детерминированный checklist (Spec §D.8)
//   - rawScore — сумма бакетов (0..100)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { buildSkillExplain } from '@/lib/services/skill-graph-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, ctx: { params: Promise<{ skillId: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { skillId } = await ctx.params;

  try {
    const explain = await buildSkillExplain(user.id, skillId);
    if (!explain) return errorJson('Навык не найден', 404);

    return json({
      ...explain,
      formulaVersion: explain.formulaVersion,
    });
  } catch (e) {
    console.error('[api/me/skills/[skillId]/explain] error:', e);
    return errorJson('Ошибка построения explain', 500);
  }
}
