// BizON API — /api/me/moments
// P0-5 (ЧАСТЬ 14): Professional Moments — последние 10 событий Professional Change Loop.
// Типы: trust_up, evidence_added, skill_verified, recommendation_received,
//       project_verified, new_opportunity, company_viewed_profile,
//       recruiter_invitation, blind_spot_discovered
// Источник: ActionEventService.getProfessionalMoments (с синтетическим заполнением
// из ReputationSnapshot / SkillConfirmation / JobApplication для онбординга).
import { NextRequest } from 'next/server';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';
import { ActionEventService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = Math.min(
    Math.max(Number(req.nextUrl.searchParams.get('limit') ?? 10), 1),
    50,
  );

  const moments = await ActionEventService.getProfessionalMoments(user.id, { limit });

  return json({
    moments: moments.map((m) => ({
      type: m.type,
      title: m.title,
      description: m.description,
      timestamp: m.timestamp,
      metadata: m.metadata,
    })),
    total: moments.length,
  });
}
