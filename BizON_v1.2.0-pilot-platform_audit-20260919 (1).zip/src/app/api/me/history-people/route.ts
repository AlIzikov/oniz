// BizON API — GET /api/me/history-people
// Phase 3 (Правка 2): «Из вашей истории» — люди из общих проектов.
// Алгоритм:
//   1. Берём все ProjectMember где userId = текущий.
//   2. Для каждого такого проекта — берём всех остальных участников.
//   3. Группируем по пользователю: какие общие проекты, год-диапазоны.
//   4. Сортируем по последнему совместному проекту (desc).
//
// Формат: { people: [{ id, name, title, avatarUrl, accountType, isVerified,
//   projects: [{ title, yearRange }], projectsCount, latestYear }], total }
//
// Принципы:
//   • БЕЗ IP-score публично (только владельцу)
//   • БЕЗ email/phone
//   • Только не удалённые пользователи (deletedAt = null)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const MAX_PROJECTS_SCAN = 200; // защитный лимит

function fmtYear(d: Date): string {
  return String(d.getFullYear());
}

function fmtYearRange(start: Date, end: Date | null | undefined): string {
  const s = fmtYear(start);
  if (!end) return `${s}—настоящее`;
  const e = fmtYear(end);
  return s === e ? s : `${s}—${e}`;
}

interface HistoryPerson {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  accountType: string;
  isVerified: boolean;
  roles: string[];
  company: { id: string; name: string; logoUrl: string | null } | null;
  projects: Array<{ title: string; yearRange: string }>;
  projectsCount: number;
  latestYear: number;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // 1. Все мои проекты (только id) — ограниченный набор
  const myMemberships = await db.projectMember.findMany({
    where: { userId: user.id },
    select: { projectId: true },
    take: MAX_PROJECTS_SCAN,
  });

  if (myMemberships.length === 0) {
    return json({
      people: [],
      total: 0,
      message: 'У вас пока нет проектов. Создайте проект или присоединитесь к существующему.',
    });
  }

  const myProjectIds = myMemberships.map((m) => m.projectId);

  // 2. Все участники моих проектов (включая меня — отфильтруем ниже)
  const memberships = await db.projectMember.findMany({
    where: { projectId: { in: myProjectIds } },
    include: {
      project: {
        select: {
          id: true,
          title: true,
          startedAt: true,
          completedAt: true,
        },
      },
      user: {
        select: {
          id: true,
          name: true,
          title: true,
          avatarUrl: true,
          accountType: true,
          isVerified: true,
          roles: true,
          deletedAt: true,
          company: { select: { id: true, name: true, logoUrl: true } },
        },
      },
    },
    orderBy: { joinedAt: 'desc' },
  });

  // 3. Группируем по userId (исключая себя и удалённых)
  const peopleMap = new Map<string, HistoryPerson>();

  for (const m of memberships) {
    if (m.userId === user.id) continue;
    if (m.user.deletedAt) continue;

    const project = m.project;
    const yearRange = fmtYearRange(project.startedAt, project.completedAt);
    const startYear = project.startedAt.getFullYear();

    const existing = peopleMap.get(m.userId);
    if (existing) {
      existing.projects.push({ title: project.title, yearRange });
      existing.projectsCount = existing.projects.length;
      if (startYear > existing.latestYear) existing.latestYear = startYear;
    } else {
      peopleMap.set(m.userId, {
        id: m.user.id,
        name: m.user.name,
        title: m.user.title,
        avatarUrl: m.user.avatarUrl,
        accountType: m.user.accountType,
        isVerified: m.user.isVerified,
        roles: m.user.roles ? m.user.roles.split(',').filter(Boolean) : [],
        company: m.user.company
          ? { id: m.user.company.id, name: m.user.company.name, logoUrl: m.user.company.logoUrl }
          : null,
        projects: [{ title: project.title, yearRange }],
        projectsCount: 1,
        latestYear: startYear,
      });
    }
  }

  // 4. Сортировка: по последнему совместному проекту (desc), затем по числу совместных проектов (desc)
  const people = Array.from(peopleMap.values())
    .sort((a, b) => {
      if (b.latestYear !== a.latestYear) return b.latestYear - a.latestYear;
      if (b.projectsCount !== a.projectsCount) return b.projectsCount - a.projectsCount;
      return a.name.localeCompare(b.name);
    })
    // Ограничиваем до 30 — для UI хватит
    .slice(0, 30)
    // Каждый user — максимум 2 проекта в projects (для компактности карточки)
    .map((p) => ({
      ...p,
      projects: p.projects.slice(0, 2),
    }));

  return json({
    people,
    total: peopleMap.size,
  });
}
