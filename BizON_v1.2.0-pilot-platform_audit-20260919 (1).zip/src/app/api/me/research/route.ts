// BizON API — /api/me/research (W4.1, T8)
// GET  — активные research-сигналы + определение опросника (если предлагать)
// POST — сохранить ответы { answers: {q_id: 1..5}, consent: true, version }
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import {
  RESEARCH_QUESTIONS,
  RESEARCH_KIND,
  RESEARCH_KIND_VERSION,
  ResearchService,
} from '@/lib/services/research-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const [results, shouldOffer] = await Promise.all([
    ResearchService.listActive(user.id),
    ResearchService.shouldOffer(user.id),
  ]);
  return json({
    results,
    offer: shouldOffer
      ? {
          kind: RESEARCH_KIND,
          version: RESEARCH_KIND_VERSION,
          questions: RESEARCH_QUESTIONS,
          note: 'Опросник — добровольный. Результат используется как AI-сигнал с датой устаревания, не как истина о вас.',
        }
      : null,
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // защита от накрутки: не чаще 3 раз в час
  const rl = checkUserRateLimit(user.id, 'research:submit', 3, 3_600_000);
  if (!rl.allowed) return errorJson(`Слишком часто. Повторите через ${rl.retryAfter} с.`, 429);

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== 'object') return errorJson('Некорректный JSON', 400);

  const answers = (body as any).answers;
  if (!answers || typeof answers !== 'object' || Array.isArray(answers)) {
    return errorJson('answers обязателен (объект вопрос → оценка)', 422);
  }
  const consent = (body as any).consent === true;
  const version = typeof (body as any).version === 'number' ? (body as any).version : undefined;

  const res = await ResearchService.submit({ userId: user.id, answers, consent, version });
  if (!res.ok) {
    const status = res.code === 'CONSENT_REQUIRED' ? 403 : 422;
    return errorJson(res.message, status);
  }
  return json({ ok: true, id: res.id, score: res.score, profile: res.profile, expiresAt: res.expiresAt }, 201);
}
