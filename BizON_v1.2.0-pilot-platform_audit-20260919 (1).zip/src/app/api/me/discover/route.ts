// BizON API — /api/me/discover
// Phase 3 — BIZON DISCOVER: 3-5 персональных находок каждый день.
//
// Типы находок:
//   • job_match        — топ-1 вакансия с matchConfidence > 70% (по verified skills)
//   • person_to_meet   — 1 человек с общими контактами (2-hop friends-of-friends)
//   • event_upcoming   — ближайшее событие (Event где startDate > now)
//   • company_update   — компания с новыми вакансиями за последние 7 дней
//   • bizon_insight    — BIZON MOMENT (если есть непрочитанный AiInsight)
//
// Если данных для какого-то типа нет — он просто не возвращается.
// Минимум 0 элементов (всё пусто), максимум 5.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { BizonMomentService } from '@/lib/services/bizon-moment-service';

export const runtime = 'nodejs';

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const MIN_MATCH = 0.7;

interface DiscoverItem {
  type: 'job_match' | 'person_to_meet' | 'event_upcoming' | 'company_update' | 'bizon_insight';
  title: string;
  subtitle: string;
  matchConfidence?: number;
  meta?: Record<string, unknown>;
  action: {
    label: string;
    view?: string;          // AppView key для SPA-навигации
    entityId?: string;      // id вакансии/пользователя/компании/события
    externalUrl?: string;
  };
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // ========================================================================
  // Параллельно собираем 5 типов данных
  // ========================================================================
  const since7days = new Date(Date.now() - WEEK_MS);

  // 1) Подтверждённые навыки пользователя (для расчёта matchConfidence вакансий)
  const userSkillNamesPromise = db.userSkill.findMany({
    where: { userId: user.id, verificationLevel: { not: 'claimed' } },
    include: { skill: { select: { name: true } } },
  });

  // 2) Вакансии, на которые уже откликнулся (исключаем)
  const myAppliedJobIdsPromise = db.jobApplication.findMany({
    where: { userId: user.id, status: { not: 'withdrawn' } },
    select: { jobId: true },
  });

  // 3) Активные вакансии (для подбора top-1)
  const activeJobsPromise = db.job.findMany({
    where: { active: true },
    orderBy: { createdAt: 'desc' },
    take: 100,
    select: {
      id: true,
      title: true,
      company: true,
      companyId: true,
      requiredSkills: true,
      growthScore: true,
      salaryFrom: true,
      salaryTo: true,
      currency: true,
      location: true,
      createdAt: true,
    },
  });

  // 4) People to meet — 2-hop friends-of-friends (через Connection)
  // Берём мои accepted связи → для каждой связи её accepted связи → исключаем себя и прямых друзей
  const myConnectionsRawPromise = db.connection.findMany({
    where: {
      OR: [{ fromUserId: user.id }, { toUserId: user.id }],
      status: 'accepted',
    },
    select: { fromUserId: true, toUserId: true },
    take: 200,
  });

  // 5) Ближайшее событие (startDate > now)
  const upcomingEventPromise = db.event.findFirst({
    where: { startDate: { gt: new Date() } },
    orderBy: { startDate: 'asc' },
    select: {
      id: true,
      title: true,
      description: true,
      format: true,
      category: true,
      startDate: true,
      location: true,
      imageUrl: true,
      trustScore: true,
      company: { select: { id: true, name: true } },
      organizer: { select: { id: true, name: true } },
      _count: { select: { participants: true } },
    },
  });

  // 6) Company update — компании с новыми вакансиями за неделю
  const companiesWithNewJobsPromise = db.company.findMany({
    where: {
      jobs: { some: { createdAt: { gte: since7days }, active: true } },
    },
    select: {
      id: true,
      name: true,
      logoUrl: true,
      industry: true,
      _count: { select: { jobs: { where: { createdAt: { gte: since7days }, active: true } } } },
    },
    orderBy: { name: 'asc' },
    take: 5,
  });

  // 7) Bizon Moment insight
  const bizonInsightPromise = BizonMomentService.getCurrent(user.id).catch(() => null);

  const [
    userSkillNames,
    myAppliedJobIds,
    activeJobs,
    myConnectionsRaw,
    upcomingEvent,
    companiesWithNewJobs,
    bizonInsight,
  ] = await Promise.all([
    userSkillNamesPromise,
    myAppliedJobIdsPromise,
    activeJobsPromise,
    myConnectionsRawPromise,
    upcomingEventPromise,
    companiesWithNewJobsPromise,
    bizonInsightPromise,
  ]);

  const items: DiscoverItem[] = [];

  // ========================================================================
  // 1. JOB MATCH — топ-1 вакансия с matchConfidence > 70%
  // ========================================================================
  const appliedJobIds = new Set(myAppliedJobIds.map((a) => a.jobId));
  const verifiedSkillNames = userSkillNames.map((s) => s.skill.name.toLowerCase());

  let bestJob: { job: typeof activeJobs[number]; match: number } | null = null;
  for (const j of activeJobs) {
    if (appliedJobIds.has(j.id)) continue;
    const req = j.requiredSkills
      ? j.requiredSkills.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)
      : [];
    if (req.length === 0) continue;
    const overlap = req.filter((s) => verifiedSkillNames.includes(s)).length;
    const match = overlap / req.length;
    if (match >= MIN_MATCH) {
      if (!bestJob || match > bestJob.match) {
        bestJob = { job: j, match };
      }
    }
  }

  if (bestJob) {
    const j = bestJob.job;
    const matchPercent = Math.round(bestJob.match * 100);
    const salaryStr =
      j.salaryFrom != null
        ? ` · ${j.salaryFrom}${j.salaryTo ? `–${j.salaryTo}` : ''} ${j.currency ?? 'RUB'}`
        : '';
    items.push({
      type: 'job_match',
      title: `${j.title} — ${j.company}`,
      subtitle: `${matchPercent}% match${salaryStr}${j.location ? ` · ${j.location}` : ''}`,
      matchConfidence: bestJob.match,
      meta: { jobId: j.id, companyId: j.companyId ?? null },
      action: { label: 'Открыть', view: 'jobs', entityId: j.id },
    });
  }

  // ========================================================================
  // 2. PERSON TO MEET — 2-hop friend-of-friend с макс. общими контактами
  // ========================================================================
  const myFriendIds = new Set<string>();
  for (const c of myConnectionsRaw) {
    if (c.fromUserId !== user.id) myFriendIds.add(c.fromUserId);
    if (c.toUserId !== user.id) myFriendIds.add(c.toUserId);
  }

  if (myFriendIds.size > 0) {
    const friendIdsArray = Array.from(myFriendIds);
    const secondHopRaw = await db.connection.findMany({
      where: {
        status: 'accepted',
        OR: [
          { fromUserId: { in: friendIdsArray } },
          { toUserId: { in: friendIdsArray } },
        ],
      },
      select: { fromUserId: true, toUserId: true },
      take: 1000,
    });

    // mutualMap: candidateId → Set(friendId)
    const mutualMap = new Map<string, Set<string>>();
    for (const c of secondHopRaw) {
      let friendId: string | null = null;
      let candidateId: string | null = null;
      if (myFriendIds.has(c.fromUserId) && c.toUserId !== user.id && !myFriendIds.has(c.toUserId)) {
        friendId = c.fromUserId;
        candidateId = c.toUserId;
      } else if (myFriendIds.has(c.toUserId) && c.fromUserId !== user.id && !myFriendIds.has(c.fromUserId)) {
        friendId = c.toUserId;
        candidateId = c.fromUserId;
      }
      if (friendId && candidateId) {
        if (!mutualMap.has(candidateId)) mutualMap.set(candidateId, new Set());
        mutualMap.get(candidateId)!.add(friendId);
      }
    }

    if (mutualMap.size > 0) {
      // Берём топ-1 по mutual count
      const sortedCandidates = Array.from(mutualMap.entries())
        .sort((a, b) => b[1].size - a[1].size)
        .slice(0, 1);
      const candidateId = sortedCandidates[0][0];
      const mutualCount = sortedCandidates[0][1].size;

      const candidate = await db.user.findFirst({
        where: { id: candidateId, deletedAt: null },
        select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true },
      });

      if (candidate) {
        items.push({
          type: 'person_to_meet',
          title: candidate.name,
          subtitle:
            candidate.title ??
            `${mutualCount} ${pluralize(mutualCount, 'общий контакт', 'общих контакта', 'общих контактов')}`,
          matchConfidence: Math.min(0.99, 0.5 + mutualCount * 0.1),
          meta: {
            userId: candidate.id,
            mutualCount,
            ipScore: candidate.ipScore,
          },
          action: {
            label: 'Профиль',
            view: 'profile',
            entityId: candidate.id,
          },
        });
      }
    }
  }

  // ========================================================================
  // 3. EVENT UPCOMING — ближайшее событие
  // ========================================================================
  if (upcomingEvent) {
    const startDate = new Date(upcomingEvent.startDate);
    const now = new Date();
    const diffMs = startDate.getTime() - now.getTime();
    const diffDays = Math.floor(diffMs / (24 * 60 * 60 * 1000));
    const diffHours = Math.floor(diffMs / (60 * 60 * 1000));

    let whenLabel: string;
    if (diffHours < 24) {
      whenLabel = diffHours <= 1 ? 'меньше часа' : `через ${diffHours} ч`;
    } else if (diffDays === 0) {
      whenLabel = 'сегодня';
    } else if (diffDays === 1) {
      whenLabel = 'завтра';
    } else if (diffDays < 7) {
      whenLabel = `через ${diffDays} дн`;
    } else {
      whenLabel = startDate.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
    }

    const categoryLabel =
      upcomingEvent.category === 'conference'
        ? 'конференция'
        : upcomingEvent.category === 'meetup'
          ? 'митап'
          : upcomingEvent.category === 'workshop'
            ? 'воркшоп'
            : upcomingEvent.category === 'webinar'
              ? 'вебинар'
              : upcomingEvent.category === 'hackathon'
                ? 'хакатон'
                : 'событие';

    const subtitleParts: string[] = [`${categoryLabel} · ${whenLabel}`];
    if (upcomingEvent._count.participants > 0) {
      subtitleParts.push(
        `${upcomingEvent._count.participants} ${pluralize(
          upcomingEvent._count.participants,
          'участник',
          'участника',
          'участников',
        )}`,
      );
    }
    if (upcomingEvent.format === 'online') subtitleParts.push('онлайн');

    items.push({
      type: 'event_upcoming',
      title: upcomingEvent.title,
      subtitle: subtitleParts.join(' · '),
      matchConfidence: upcomingEvent.trustScore,
      meta: {
        eventId: upcomingEvent.id,
        startDate: upcomingEvent.startDate.toISOString(),
        category: upcomingEvent.category,
        format: upcomingEvent.format,
      },
      action: { label: 'Записаться', view: 'events', entityId: upcomingEvent.id },
    });
  }

  // ========================================================================
  // 4. COMPANY UPDATE — компания с новыми вакансиями за неделю
  // ========================================================================
  if (companiesWithNewJobs.length > 0) {
    const c = companiesWithNewJobs[0];
    const jobsCount = c._count.jobs;
    items.push({
      type: 'company_update',
      title: c.name,
      subtitle: `${jobsCount} ${pluralize(
        jobsCount,
        'новая вакансия',
        'новые вакансии',
        'новых вакансий',
      )} за неделю${c.industry ? ` · ${c.industry}` : ''}`,
      matchConfidence: undefined,
      meta: { companyId: c.id, jobsCount },
      action: { label: 'Смотреть', view: 'company', entityId: c.id },
    });
  }

  // ========================================================================
  // 5. BIZON INSIGHT — BIZON MOMENT (если есть непрочитанный)
  // ========================================================================
  if (bizonInsight) {
    const confidencePercent = Math.round(bizonInsight.confidence * 100);
    items.push({
      type: 'bizon_insight',
      title: bizonInsight.insight,
      subtitle: `BizON · ${confidencePercent}% уверенность`,
      matchConfidence: bizonInsight.confidence,
      meta: {
        insightId: bizonInsight.id,
        pattern: bizonInsight.pattern,
      },
      action: { label: 'Почему', view: 'me' },
    });
  }

  return json({
    items,
    total: items.length,
    generatedAt: new Date().toISOString(),
  });
}

function pluralize(n: number, one: string, few: string, many: string): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}
