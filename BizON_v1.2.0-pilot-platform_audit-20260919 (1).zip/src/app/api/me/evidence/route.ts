import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const evidence = await db.professionalEvidence.findMany({
      where: { userId: user.id, status: 'active' },
      orderBy: { date: 'desc' },
      take: 50,
    });
    return json({ evidence });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const body = await req.json();
    const { type, source, skillId, role, responsibility, action, result, date } = body ?? {};
    if (!type || !source) return errorJson('type и source обязательны', 422);
    const evidence = await db.professionalEvidence.create({
      data: {
        userId: user.id, type, source,
        skillId: skillId ?? null,
        role: role ?? null,
        responsibility: responsibility ?? null,
        action: action ?? null,
        result: result ?? null,
        verificationLevel: 'claimed',
        confidence: 0.5,
        date: date ? new Date(date) : new Date(),
      },
    });
    return json({ evidence }, 201);
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
