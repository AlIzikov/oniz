// BizON API — /api/me/accept-tos (FIX-08: юридический контур люмен-программы)
//
// PATCH — фиксирует принятие «Пользовательского соглашения и условий
// люмен-программы» (/legal): User.acceptedTosAt = now.
// Вызывается кнопкой «Принимаю» из баннера app shell. Идемпотентен:
// повторный вызов просто обновляет метку времени.
// FIX-07: withRoute — auth 401 по умолчанию, единый маппинг ошибок.
import { db } from '@/lib/db';
import { json, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export const PATCH = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;

    const updated = await db.user.update({
      where: { id: user.id },
      data: { acceptedTosAt: new Date() },
      select: { id: true, acceptedTosAt: true },
    });

    return json({
      ok: true,
      tosAccepted: true,
      acceptedTosAt: updated.acceptedTosAt?.toISOString() ?? null,
    });
  },
  {
    rateLimit: { key: 'me:accept-tos', limit: 10, windowMs: 60_000 },
  },
);
