// BizON API — GET /api/me/evidence-graph
// P0-3: Evidence Graph — визуализация доказательств
//   claim → project → skill → confirmer → result → trust
//
// Логика: для каждого verified Claim → найти Project → найти SkillConfirmation →
// найти Confirmer → найти Result. Финальный узел «trust» показывает, как
// накопленные доказательства превращаются в репутацию.
//
// Параметры:
//   ?userId=...  — целевой пользователь (по умолчанию текущий).
//                  Для чужого профиля возвращаются только публичные данные:
//                  верифицированные claims, завершённые проекты, подтверждённые
//                  навыки и имена confirmer-ов (без PII).
//
// Возвращает: { nodes: [...], edges: [...] }
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { cache, CACHE_TTL } from '@/lib/cache';

export const runtime = 'nodejs';

// Лимиты, чтобы граф не разрастался бесконтрольно (MVP).
const MAX_CLAIMS = 30;
const MAX_CONFIRMERS_PER_SKILL = 5;

// Статус claim, который считается «доказанным» (не просто заявленным).
function isVerifiedClaimStatus(s: string): boolean {
  return s === 'verified' || s === 'project_verified' || s === 'expert_verified';
}

// Человекочитаемая роль confirmer-а (из ClaimVerification.role или ProjectMember.role).
function humanizeConfirmerRole(role: string | null | undefined): string {
  if (!role) return 'коллега';
  const map: Record<string, string> = {
    colleague: 'коллега',
    manager: 'руководитель',
    client: 'клиент',
    expert: 'эксперт',
    FOUNDER: 'основатель',
    CO_FOUNDER: 'кофаундер',
    CONTRIBUTOR: 'участник',
    MENTOR: 'ментор',
    OBSERVER: 'наблюдатель',
  };
  return map[role] ?? role;
}

export async function GET(req: NextRequest) {
  const currentUser = await getUserFromRequest(req);
  if (!currentUser) return errorJson('Не авторизован', 401);

  const targetUserId = req.nextUrl.searchParams.get('userId') ?? currentUser.id;
  // Публичный режим: смотрим чужой профиль (либо не авторизованы как owner).
  const isOwner = targetUserId === currentUser.id;

  // Phase 16: кэш 5 минут по targetUserId + isOwner (публичный/приватный режим
  // дают разные графы). Сам currentUser не влияет на содержимое ответа —
  // только на флаг isOwner, который уже учтён в ключе.
  const cacheKey = `evidence-graph:${targetUserId}:${isOwner ? 'owner' : 'public'}`;
  const cached = cache.get<unknown>(cacheKey);
  if (cached !== null) return json(cached);

  const result = await computeEvidenceGraph(targetUserId, isOwner);
  if (!result) return errorJson('Пользователь не найден', 404);

  cache.set(cacheKey, result, CACHE_TTL.MEDIUM);
  return json(result);
}

async function computeEvidenceGraph(targetUserId: string, isOwner: boolean) {

  const targetUser = await db.user.findUnique({
    where: { id: targetUserId },
    select: {
      id: true,
      name: true,
      ipScore: true,
      level: true,
    },
  });
  if (!targetUser) return null;

  // === Шаг 1. Загружаем verified claims (для публичного режима — только verified) ===
  const claims = await db.claim.findMany({
    where: isOwner
      ? { userId: targetUserId }
      : { userId: targetUserId, status: { not: 'claimed' } },
    orderBy: { createdAt: 'desc' },
    take: MAX_CLAIMS,
    include: {
      verifications: {
        where: { status: 'confirmed' },
        select: {
          verifierId: true,
          role: true,
          comment: true,
          verifier: { select: { id: true, name: true, title: true } },
        },
      },
    },
  });

  // === Шаг 2. Собираем проекты и userSkills, на которые ссылаются claims ===
  const projectIds = Array.from(
    new Set(claims.map((c) => c.projectId).filter(Boolean) as string[])
  );
  const userSkillIds = Array.from(
    new Set(claims.map((c) => c.skillId).filter(Boolean) as string[])
  );

  const [projects, userSkills] = await Promise.all([
    projectIds.length === 0
      ? []
      : db.project.findMany({
          where: { id: { in: projectIds } },
          select: {
            id: true,
            title: true,
            description: true,
            status: true,
            outcome: true,
            completedAt: true,
          },
        }),
    userSkillIds.length === 0
      ? []
      : db.userSkill.findMany({
          where: { id: { in: userSkillIds } },
          include: {
            skill: { select: { name: true } },
            confirmations: {
              take: MAX_CONFIRMERS_PER_SKILL,
              orderBy: { createdAt: 'desc' },
              include: {
                confirmer: { select: { id: true, name: true, title: true } },
                project: { select: { id: true, title: true } },
              },
            },
          },
        }),
  ]);

  const projectById = new Map<string, typeof projects[number]>(
    projects.map((p) => [p.id, p] as const)
  );
  const userSkillById = new Map<string, typeof userSkills[number]>(
    userSkills.map((us) => [us.id, us] as const)
  );

  // === Шаг 3. Строим nodes и edges ===
  type GraphNode = {
    id: string;
    type: 'claim' | 'project' | 'skill' | 'confirmer' | 'result' | 'trust';
    label: string;
    status?: string;
    role?: string;
    description?: string;
    meta?: Record<string, string | number | boolean | null>;
  };
  type GraphEdge = { from: string; to: string; label: string };

  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const nodeIds = new Set<string>();
  const confirmerCache = new Map<string, GraphNode>(); // id → node (deduplication)

  function pushNode(n: GraphNode) {
    if (!nodeIds.has(n.id)) {
      nodeIds.add(n.id);
      nodes.push(n);
    }
  }

  function pushEdge(from: string, to: string, label: string) {
    // dedup by from+to+label
    const exists = edges.some(
      (e) => e.from === from && e.to === to && e.label === label
    );
    if (!exists) edges.push({ from, to, label });
  }

  function makeConfirmerNode(
    userId: string,
    name: string,
    title: string | null,
    role: string | null
  ): GraphNode {
    const cached = confirmerCache.get(userId);
    if (cached) return cached;
    const node: GraphNode = {
      id: `confirmer-${userId}`,
      type: 'confirmer',
      label: name,
      role: humanizeConfirmerRole(role),
      description: title ?? undefined,
    };
    confirmerCache.set(userId, node);
    pushNode(node);
    return node;
  }

  // Trust node — финальный узел графа, показывающий накопленную репутацию.
  const trustNode: GraphNode = {
    id: 'trust-self',
    type: 'trust',
    label: `Trust ${targetUser.ipScore}`,
    status: targetUser.level,
    description: 'Совокупная репутация пользователя на основе подтверждённых доказательств',
    meta: {
      ipScore: targetUser.ipScore,
      level: targetUser.level,
      verifiedClaims: 0,
    },
  };

  let verifiedClaimsCount = 0;

  for (const claim of claims) {
    const verified = isVerifiedClaimStatus(claim.status);
    // Для владельца — показываем все claims (включая 'claimed').
    // Для публичного режима — только verified (фильтр уже на уровне БД).
    if (verified) verifiedClaimsCount += 1;

    pushNode({
      id: `claim-${claim.id}`,
      type: 'claim',
      label: claim.title,
      status: claim.status,
      description: claim.description ?? undefined,
      meta: {
        type: claim.type,
        verifications: claim.verifications.length,
      },
    });

    // Edge: claim → trust (каждое утверждение усиливает trust, особенно verified).
    pushEdge(`claim-${claim.id}`, trustNode.id, verified ? 'усиливает' : 'заявлено в');

    // Project link
    if (claim.projectId) {
      const project = projectById.get(claim.projectId);
      if (project) {
        pushNode({
          id: `project-${project.id}`,
          type: 'project',
          label: project.title,
          status: project.status,
          description: project.description,
          meta: {
            completedAt: project.completedAt?.toISOString() ?? null,
          },
        });
        pushEdge(`claim-${claim.id}`, `project-${project.id}`, 'доказан в');

        // Result link (только для завершённых проектов с outcome)
        if (
          project.status === 'completed' &&
          project.outcome &&
          project.outcome.trim().length > 0
        ) {
          pushNode({
            id: `result-${project.id}`,
            type: 'result',
            label: project.outcome,
          });
          pushEdge(`project-${project.id}`, `result-${project.id}`, 'результат');
          // result → trust
          pushEdge(`result-${project.id}`, trustNode.id, 'формирует');
        }

        // Confirmer-ы через SkillConfirmation, где projectId совпадает,
        // обрабатываются ниже в контексте skill.
      }
    }

    // Skill link
    if (claim.skillId) {
      const us = userSkillById.get(claim.skillId);
      if (us) {
        const skillStatus = us.nftEligible ? 'nft' : us.verificationLevel;
        pushNode({
          id: `skill-${us.id}`,
          type: 'skill',
          label: us.skill.name,
          status: skillStatus,
          meta: {
            level: us.level,
            confirmations: us.confirmationsCount,
          },
        });
        pushEdge(`claim-${claim.id}`, `skill-${us.id}`, 'подтверждает');

        // Confirmer-ы (через SkillConfirmation). Берём первые N.
        for (const conf of us.confirmations) {
          const confirmerNode = makeConfirmerNode(
            conf.confirmer.id,
            conf.confirmer.name,
            conf.confirmer.title,
            null // role в SkillConfirmation не хранится — берётся из ClaimVerification
          );
          pushEdge(`skill-${us.id}`, confirmerNode.id, 'подтверждён');

          // Если confirmer подтвердил через проект, указанный в claim — связываем.
          if (claim.projectId && conf.projectId === claim.projectId) {
            pushEdge(`project-${claim.projectId}`, confirmerNode.id, 'заверил в проекте');
          }
        }
      }
    }

    // Confirmer-ы через ClaimVerification (кто верифицировал сам claim).
    for (const v of claim.verifications) {
      const confirmerNode = makeConfirmerNode(
        v.verifier.id,
        v.verifier.name,
        v.verifier.title,
        v.role
      );
      pushEdge(`claim-${claim.id}`, confirmerNode.id, 'верифицировал');
    }
  }

  // Финализируем trust node с числом verified claims.
  trustNode.meta = {
    ...(trustNode.meta ?? {}),
    verifiedClaims: verifiedClaimsCount,
  };
  // Добавляем trust node в граф, даже если claims нет — показываем «голый» trust.
  // Но если nodes вообще пусто — отдаём empty state на фронте (не добавляем trust).
  if (nodes.length > 0) {
    pushNode(trustNode);
  }

  return {
    userId: targetUserId,
    isOwner,
    nodes,
    edges,
    stats: {
      totalNodes: nodes.length,
      totalEdges: edges.length,
      verifiedClaims: verifiedClaimsCount,
    },
  };
}
