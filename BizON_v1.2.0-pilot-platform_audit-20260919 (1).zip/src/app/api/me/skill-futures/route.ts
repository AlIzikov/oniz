// BizON API — GET /api/me/skill-futures (9-c, doc_a §37 Skill Futures UI)
//
// МИНИМАЛЬНЫЙ read-only агрегат для панели «Ваши траектории».
//
// Почему он нужен: существующий прогноз — GET /api/skills/[id]/forecast
// (SkillFuturesService.forecast) принимает **Skill.id**, но ни один GET-роут
// не отдаёт Skill.id навыков текущего пользователя (Skill Graph отдаёт
// UserSkill.id — это другой идентификатор). Здесь мы резолвим навыки
// пользователя и переиспользуем СУЩЕСТВУЮЩИЙ SkillFuturesService БЕЗ правок.
//
// Ответ: { items: SkillForecast[], total, skipped, disclaimer }
//   • items — максимум SKILL_FUTURES_LIMIT прогнозов (по текущему уровню навыка)
//   • skipped — сколько навыков не попало в лимит (для честной приписки «и ещё N»)
//   • ошибки по отдельным навыкам молча пропускаются (панель не должна падать)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { SkillFuturesService, type SkillForecast } from '@/lib/services/skill-futures-service';

export const runtime = 'nodejs';

// Панель «Ваши траектории» — дайджест, а не таблица: ограничиваем выборку.
const SKILL_FUTURES_LIMIT = 6;

export async function GET(_req: NextRequest) {
  const user = await getUserFromRequest(_req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    // Навыки пользователя: приоритет — подтверждённые и с высоким текущим уровнем;
    // при равенстве — более давние навыки (стабильная часть профиля) впереди.
    const userSkills = await db.userSkill.findMany({
      where: { userId: user.id },
      include: { skill: { select: { id: true, name: true } } },
      orderBy: [{ level: 'desc' }, { confirmationsCount: 'desc' }, { createdAt: 'asc' }],
      take: SKILL_FUTURES_LIMIT,
    });

    const skippedRow = await db.userSkill.count({ where: { userId: user.id } });
    const skipped = Math.max(0, skippedRow - userSkills.length);

    // Существующий сервис вызывается по Skill.id (см. комментарий выше).
    const settled = await Promise.allSettled(
      userSkills
        .filter((us) => us.skill)
        .map((us) => SkillFuturesService.forecast(us.skill.id)),
    );

    const items: SkillForecast[] = [];
    for (const r of settled) {
      if (r.status === 'fulfilled' && r.value) items.push(r.value);
    }

    return json({
      items,
      total: items.length,
      skipped,
      disclaimer: items[0]?.disclaimer ?? null,
      generatedAt: new Date().toISOString(),
    });
  } catch (e: any) {
    console.error('[/api/me/skill-futures] error:', e?.message ?? e);
    // Graceful degradation — как в /api/me/signals: UI не должен падать.
    return json({
      items: [],
      total: 0,
      skipped: 0,
      disclaimer: null,
      generatedAt: new Date().toISOString(),
    });
  }
}
