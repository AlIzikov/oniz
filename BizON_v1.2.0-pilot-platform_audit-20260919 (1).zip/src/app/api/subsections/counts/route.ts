// BizON API — /api/subsections/counts
// Возвращает счётчики для подразделов правого rail (SubSectionBar)
// Включает ОБЪЁМЫ (всего постов/вакансий в системе) для контекста
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Параллельные запросы для подсчётов
  const [
    myPostsCount,
    savedPostsCount,
    myCommunitiesCount,
    appliedJobsCount,
    savedJobsCount,
    myPathJobsCount,    // Task 7-d: отклики на поздних стадиях «Моего пути» (interview+offer+accepted+hired)
    savedAdsCount,
    friendsCount,
    allPostsCount,      // ОБЪЁМ: всего постов в системе
    allJobsCount,       // ОБЪЁМ: всего активных вакансий
    allAdsCount,        // ОБЪЁМ: всего активных объявлений
    allCommunitiesCount,// ОБЪЁМ: всего сообществ
  ] = await Promise.all([
    db.post.count({ where: { authorId: user.id } }),
    db.savedPost.count({ where: { userId: user.id } }),
    db.communityMember.count({ where: { userId: user.id } }),
    db.jobApplication.count({ where: { userId: user.id } }),
    db.savedJob.count({ where: { userId: user.id } }),
    db.jobApplication.count({
      where: { userId: user.id, status: { in: ['interview', 'offer', 'accepted', 'hired'] } },
    }),
    db.savedAd.count({ where: { userId: user.id } }),
    db.connection.count({
      where: {
        OR: [
          { fromUserId: user.id, status: 'accepted' },
          { toUserId: user.id, status: 'accepted' },
        ],
      },
    }),
    // ОБЪЁМЫ — общий счётчик в системе
    db.post.count({ where: { isHidden: false } }),
    db.job.count({ where: { active: true } }),
    db.ad.count({ where: { active: true } }),
    db.community.count(),
  ]);

  // Подсчёт "Горячих" вакансий — те, где match >= 0.7
  const hotJobsCount = await db.job.count({
    where: { active: true, matchConfidence: { gte: 0.7 } },
  });

  return json({
    feed: {
      recommended: allPostsCount,  // ОБЪЁМ — всего постов (для recommended)
      all: allPostsCount,           // ОБЪЁМ
      mine: myPostsCount,
      favorites: savedPostsCount,
      favGroups: myCommunitiesCount,
      favNews: allPostsCount,       // proxy — всего авторов
      friends: friendsCount,
    },
    jobs: {
      recommended: allJobsCount,    // ОБЪЁМ
      all: allJobsCount,            // ОБЪЁМ
      hot: hotJobsCount,
      mine: appliedJobsCount,
      applied: appliedJobsCount,
      'my-path': myPathJobsCount,   // Task 7-d: бейдж подраздела «Мой путь» (пайплайн Стратегия п.18)
      saved: savedJobsCount,
      favCompanies: 0,
    },
    ads: {
      recommended: allAdsCount,     // ОБЪЁМ
      all: allAdsCount,             // ОБЪЁМ
      mine: 0,
      saved: savedAdsCount,
      favSellers: 0,
    },
  });
}
