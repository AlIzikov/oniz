// BizON API — /api/users/[id]
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson, toUserPublic, toUserPublicLite } from '@/lib/api-helpers';
import { encrypt } from '@/lib/security/crypto';
import { getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  // FIX-02 (аудит P0-3): эндпоинт больше НЕ анонимный — без сессии 401.
  const currentUser = await getUserFromRequest(req);
  if (!currentUser) return errorJson('Не авторизован: требуется сессия', 401);

  const user = await db.user.findUnique({ where: { id } });
  if (!user) return errorJson('Пользователь не найден', 404);

  // FIX-02 (P0-3): полная проекция (с расшифрованными контактами) — ТОЛЬКО
  // владелец профиля ИЛИ пользователь со принятым Connection (status='accepted').
  // Всем остальным — toUserPublicLite без email/phone/birthday/location/bio/roles.
  const isOwner = currentUser.id === id;
  let isAcceptedConnection = false;
  if (!isOwner) {
    const connection = await db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: currentUser.id, toUserId: id },
          { fromUserId: id, toUserId: currentUser.id },
        ],
        status: 'accepted',
      },
      select: { id: true },
    });
    isAcceptedConnection = !!connection;
  }

  const [publicUser, skills, projects] = await Promise.all([
    isOwner || isAcceptedConnection ? toUserPublic(user) : toUserPublicLite(user),
    db.userSkill.findMany({
      where: { userId: id },
      include: { skill: true },
      orderBy: { confirmationsCount: 'desc' },
    }),
    db.projectMember.findMany({
      where: { userId: id },
      include: {
        project: {
          include: {
            owner: { select: { id: true, name: true, title: true, avatarUrl: true } },
            members: {
              include: { user: { select: { id: true, name: true, title: true, avatarUrl: true } } },
            },
          },
        },
      },
      orderBy: { joinedAt: 'desc' },
    }),
  ]);

  // Блок «Общее» — только если смотрит авторизованный пользователь и не свой профиль
  // ОПТИМИЗАЦИЯ: используем минимальные проекции и 1 batched query вместо 6
  let common: any = undefined;
  if (!isOwner) {
    // Берём только ID проектов и имена навыков — без тяжёлых includes
    const [myMemberships, theirMemberships, mySkills, theirSkills, myConnections, theirConnections] = await Promise.all([
      db.projectMember.findMany({ where: { userId: currentUser.id }, select: { projectId: true } }),
      db.projectMember.findMany({ where: { userId: id }, select: { projectId: true, role: true } }),
      db.userSkill.findMany({ where: { userId: currentUser.id }, select: { skill: { select: { name: true } } } }),
      db.userSkill.findMany({ where: { userId: id }, select: { skill: { select: { name: true } } } }),
      db.connection.findMany({
        where: { OR: [{ fromUserId: currentUser.id }, { toUserId: currentUser.id }], status: 'accepted' },
        select: { fromUserId: true, toUserId: true },
        take: 200, // лимит чтобы не вытягивать весь граф
      }),
      db.connection.findMany({
        where: { OR: [{ fromUserId: id }, { toUserId: id }], status: 'accepted' },
        select: { fromUserId: true, toUserId: true },
        take: 200,
      }),
    ]);

    // Общие проекты — берём роль из theirMemberships (роль пользователя в проекте)
    const myProjectIds = new Set(myMemberships.map((m) => m.projectId));
    const commonProjectsFromTheir = theirMemberships.filter((m) => myProjectIds.has(m.projectId));
    const commonProjectIds = commonProjectsFromTheir.map((m) => m.projectId);

    const commonProjectsData = commonProjectIds.length > 0
      ? await db.project.findMany({
          where: { id: { in: commonProjectIds } },
          select: { id: true, title: true },
          take: 10, // лимит
        })
      : [];

    // Мапа role по projectId из theirMemberships (роль того, на кого смотрим)
    const roleByProject: Record<string, string> = {};
    commonProjectsFromTheir.forEach((m) => { roleByProject[m.projectId] = m.role; });

    // Общие навыки
    const mySkillNames = new Set(mySkills.map((s) => s.skill.name));
    const commonSkills = theirSkills.filter((s) => mySkillNames.has(s.skill.name)).map((s) => s.skill.name);

    // Общие контакты — через Set
    const myConnIds = new Set<string>();
    myConnections.forEach((c) => {
      if (c.fromUserId !== currentUser.id) myConnIds.add(c.fromUserId);
      if (c.toUserId !== currentUser.id) myConnIds.add(c.toUserId);
    });
    const theirConnIds = new Set<string>();
    theirConnections.forEach((c) => {
      if (c.fromUserId !== id) theirConnIds.add(c.fromUserId);
      if (c.toUserId !== id) theirConnIds.add(c.toUserId);
    });
    let commonConnections = 0;
    myConnIds.forEach((uid) => { if (theirConnIds.has(uid)) commonConnections++; });

    common = {
      commonProjects: commonProjectsData.map((p) => ({ id: p.id, title: p.title, role: roleByProject[p.id] ?? 'member' })),
      commonSkills: commonSkills.slice(0, 10),
      commonConnections,
      commonEmployer: null,
    };
  }

  return json({
    user: publicUser,
    skills: skills.map((us) => ({
      id: us.id,
      level: us.level,
      confirmationsCount: us.confirmationsCount,
      nftEligible: us.nftEligible,
      skill: { id: us.skill.id, name: us.skill.name, category: us.skill.category },
    })),
    projects: projects.map((pm) => ({
      id: pm.project.id,
      title: pm.project.title,
      description: pm.project.description,
      status: pm.project.status,
      rating: pm.project.rating,
      tags: pm.project.tags ? pm.project.tags.split(',').filter(Boolean) : [],
      startedAt: pm.project.startedAt.toISOString(),
      completedAt: pm.project.completedAt?.toISOString() ?? null,
      role: pm.role,
      owner: pm.project.owner,
      members: pm.project.members.map((m) => ({
        userId: m.userId,
        role: m.role,
        user: m.user,
      })),
    })),
    common,
  });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  // C3: Auth + ownership check — критично для предотвращения IDOR
  const currentUser = await getUserFromRequest(req);
  if (!currentUser) return errorJson('Не авторизован', 401);
  if (currentUser.id !== id) return errorJson('Можно редактировать только свой профиль', 403);

  try {
    const body = await req.json();
    const data: any = {};

    // FIX-02 (аудит P0-2: privilege escalation через mass-assignment).
    // Строгий whitelist редактируемых полей. Раньше body.roles попадал в БД,
    // а /api/admin/* проверял 'admin' по этому же полю → любой пользователь мог
    // выдать себе admin. Теперь:
    //  1) roles и прочие привилегированные поля (twoFactor*, subscription*,
    //     isVerified, onboardingStep, passport* и т.п.) в whitelist НЕ входят
    //     и молча игнорируются (стиль кодовой базы — поле-за-полем, без 400);
    //  2) смена привилегий возможна только админом через серверный путь, не API-профилем.

    // H8: Валидация всех полей — max-length, type-check, форматы
    if (body.name !== undefined) {
      if (typeof body.name !== 'string' || body.name.length === 0 || body.name.length > 100) {
        return errorJson('Имя должно быть строкой 1-100 символов', 422);
      }
      data.name = body.name.trim();
    }

    if (body.title !== undefined) {
      if (typeof body.title !== 'string' || body.title.length > 200) {
        return errorJson('Должность должна быть строкой до 200 символов', 422);
      }
      data.title = body.title.trim() || null;
    }

    if (body.avatarUrl !== undefined) {
      // H8: валидация URL — только https, длина ≤ 2048
      if (body.avatarUrl !== null) {
        if (typeof body.avatarUrl !== 'string' || body.avatarUrl.length > 2048) {
          return errorJson('URL аватара слишком длинный', 422);
        }
        try {
          const url = new URL(body.avatarUrl);
          if (url.protocol !== 'https:' && url.protocol !== 'http:') {
            return errorJson('URL аватара должен быть http/https', 422);
          }
        } catch {
          return errorJson('Некорректный URL аватара', 422);
        }
      }
      data.avatarUrl = body.avatarUrl;
    }

    // roles НЕ редактируется через профиль (FIX-02/P0-2) — молча игнорируется.

    // PII поля — шифруем при сохранении (AES-256-GCM)
    if (body.bio !== undefined) {
      if (typeof body.bio !== 'string' || body.bio.length > 2000) {
        return errorJson('О себе должно быть строкой до 2000 символов', 422);
      }
      data.bio = body.bio;
      data.bioEncrypted = encrypt(body.bio);
    }

    if (body.location !== undefined) {
      if (typeof body.location !== 'string' || body.location.length > 200) {
        return errorJson('Локация должна быть строкой до 200 символов', 422);
      }
      data.location = body.location;
      data.locationEncrypted = encrypt(body.location);
    }

    if (body.phone !== undefined) {
      if (typeof body.phone !== 'string' || body.phone.length > 50) {
        return errorJson('Телефон должен быть строкой до 50 символов', 422);
      }
      data.phone = body.phone;
      data.phoneEncrypted = encrypt(body.phone);
    }

    if (body.birthday !== undefined) {
      if (body.birthday === null) {
        data.birthday = null;
      } else {
        const d = new Date(body.birthday);
        if (isNaN(d.getTime())) {
          return errorJson('Некорректная дата рождения', 422);
        }
        // Проверка: не будущая дата, не старше 150 лет
        const now = new Date();
        const minDate = new Date(now.getFullYear() - 150, 0, 1);
        if (d > now || d < minDate) {
          return errorJson('Дата рождения вне допустимого диапазона', 422);
        }
        data.birthday = d;
      }
    }

    // Whitelist (продолжение): не-привилегированные настройки, которые реально
    // редактирует UI (src/components/cv/career-compass.tsx).
    if (body.hobbies !== undefined) {
      if (typeof body.hobbies !== 'string' || body.hobbies.length > 500) {
        return errorJson('Хобби должны быть строкой до 500 символов', 422);
      }
      data.hobbies = body.hobbies.trim();
    }
    if (body.crossDomainOptIn !== undefined) {
      if (typeof body.crossDomainOptIn !== 'boolean') {
        return errorJson('crossDomainOptIn должен быть boolean', 422);
      }
      data.crossDomainOptIn = body.crossDomainOptIn;
    }
    if (body.showHobbiesToHr !== undefined) {
      if (typeof body.showHobbiesToHr !== 'boolean') {
        return errorJson('showHobbiesToHr должен быть boolean', 422);
      }
      data.showHobbiesToHr = body.showHobbiesToHr;
    }

    const updated = await db.user.update({ where: { id }, data });

    // H13: Audit log — обновление PII (152-ФЗ ст. 19)
    const updatedFields = Object.keys(data).filter(k => !k.endsWith('Encrypted'));
    AuditLog.log({
      actorId: currentUser.id,
      action: 'update_pii',
      resource: 'user',
      resourceId: id,
      ip: getClientIP(req),
      metadata: { fields: updatedFields },
    });

    // Ответ — полные данные, т.к. PATCH доступен только владельцу (проверка выше)
    const publicUser = await toUserPublic(updated);
    return json({ user: publicUser });
  } catch (e) {
    console.error('[users/update] error:', e);
    return errorJson('Ошибка обновления профиля', 500);
  }
}
