// BizON API — GET /api/users/[id]/recommendations (W2.3)
// Публичный список рекомендаций пользователя с группировкой по контексту.
// Правило «нажал → увидел»: каждый счётчик раскрывается — показываем автора,
// основание и наличие связи с подтверждённым проектом. Скрытая сила
// (RecommendationStrength) НЕ отдаётся — только флаги доказательности.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const subject = await db.user.findUnique({ where: { id }, select: { id: true } });
  if (!subject) return errorJson('Пользователь не найден', 404);

  const recs = await db.recommendation.findMany({
    where: { subjectId: id, status: 'active' },
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      author: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true } },
      project: {
        select: {
          id: true,
          title: true,
          clientStatus: true,
          status: true,
        },
      },
    },
  });

  // Группировка «Рекомендуют для: X»
  const byContext = new Map<string, number>();
  for (const r of recs) {
    const key = r.context?.trim() || (r.type === 'client' ? 'как заказчик' : 'в работе');
    byContext.set(key, (byContext.get(key) ?? 0) + 1);
  }
  const verifiedCount = recs.filter(
    (r) => r.project && (r.project.clientStatus === 'verified' || r.project.clientStatus === 'verified_with_changes'),
  ).length;

  return json({
    total: recs.length,
    verifiedProjectCount: verifiedCount,
    byContext: Array.from(byContext.entries()).map(([context, count]) => ({ context, count })),
    recommendations: recs.map((r) => ({
      id: r.id,
      type: r.type,
      context: r.context,
      text: r.text,
      skills: r.skills ? r.skills.split(',').filter(Boolean) : [],
      createdAt: r.createdAt,
      author: r.author,
      evidence: r.project
        ? {
            projectId: r.project.id,
            projectTitle: r.project.title,
            clientVerified:
              r.project.clientStatus === 'verified' || r.project.clientStatus === 'verified_with_changes',
          }
        : null,
    })),
  });
}
