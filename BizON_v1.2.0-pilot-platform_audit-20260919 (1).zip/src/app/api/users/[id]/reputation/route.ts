// BizON API — /api/users/[id]/reputation
// H4: только сам пользователь может пересчитать свой IP-score (anti-IDOR + anti-DoS)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ReputationService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;

  // H4: ownership check — только сам пользователь может пересчитать свой IP-score
  // Раньше любой залогиненный мог дёрнуть recompute для любого userId → DoS на CPU базы
  if (user.id !== id) {
    return errorJson('Можно пересчитывать только свой IP-score', 403);
  }

  const result = await ReputationService.recompute(id);
  return json({
    userId: id,
    ipScore: result.ipScore,
    level: result.level,
  });
}
