// BizON API — /api/users/[id]/persona
// Этап 3.2 — Блок R: Public Persona (нарратив вместо рейтинга)
// Возвращает данные для публичного профиля в формате:
//   «Делает X / Делал вместе с N,M,K / Проекты / NFT-навыки»
// БЕЗ чисел (IP-score, confirmationsCount, level) — только факты.
//
// fix-adversarial (ADV-A109, red team): persona больше НЕ анонимная —
// 1) без сессии 401 (единая политика с GET /api/users/[id], FIX-02/P0-3);
// 2) bio и roles — только владелец или принятый Connection (accepted),
//    остальным — null (та же PII-проекция, что в users/[id]).
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson } from '@/lib/api-helpers';
import { getUserFromRequest } from '@/lib/auth';

export const runtime = 'nodejs';

function fmtYear(d: Date): string {
  return String(d.getFullYear());
}

function fmtYearRange(start: Date, end: Date | null | undefined): string {
  const s = fmtYear(start);
  if (!end) return `${s}—настоящее`;
  const e = fmtYear(end);
  return s === e ? s : `${s}—${e}`;
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  // fix-adversarial (ADV-A109): auth-гейт — без валидной сессии 401.
  const viewer = await getUserFromRequest(req);
  if (!viewer) return errorJson('Не авторизован: требуется сессия', 401);

  const { id } = await ctx.params;
  const limitParam = req.nextUrl.searchParams.get('limit');
  const collaboratorsLimit = Math.max(1, Math.min(50, Number(limitParam) || 5));

  const user = await db.user.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      title: true,
      bio: true,
      avatarUrl: true,
      roles: true,
      accountType: true,
      hrInvisible: true,
      createdAt: true,
      professionalStatus: true,
    },
  });
  if (!user) return errorJson('Пользователь не найден', 404);

  // fix-adversarial (ADV-A109): bio/roles — только владелец или принятая связь
  // (политика FIX-02/P0-3: посторонним — lite-проекция без PII).
  const isOwner = viewer.id === id;
  let isAcceptedConnection = false;
  if (!isOwner) {
    const connection = await db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: viewer.id, toUserId: id },
          { fromUserId: id, toUserId: viewer.id },
        ],
        status: 'accepted',
      },
      select: { id: true },
    });
    isAcceptedConnection = !!connection;
  }
  const canSeePii = isOwner || isAcceptedConnection;

  // 1) «ДЕЛАЕТ» — топ навыков (без чисел). Берём по verificationLevel
  //    (project_verified/expert_verified — приоритет), затем по confirmationsCount.
  const skills = await db.userSkill.findMany({
    where: { userId: id },
    include: { skill: true },
    orderBy: [
      { verificationLevel: 'desc' },
      { confirmationsCount: 'desc' },
    ],
    take: 6,
  });

  // 2) «ДЕЛАЛ ВМЕСТЕ С» — все проекты пользователя + участники этих проектов.
  //    Группируем по человеку, считаем общие проекты.
  const memberships = await db.projectMember.findMany({
    where: { userId: id },
    include: {
      project: {
        select: {
          id: true,
          title: true,
          status: true,
          startedAt: true,
          completedAt: true,
          members: {
            include: {
              user: {
                select: { id: true, name: true, title: true, avatarUrl: true },
              },
            },
          },
        },
      },
    },
    orderBy: { joinedAt: 'desc' },
  });

  // Собираем мапу collaboratorId → { user, projects: [{title, yearRange}] }
  const collaboratorsMap = new Map<string, {
    id: string;
    name: string;
    title: string | null;
    avatarUrl: string | null;
    projects: Array<{ title: string; yearRange: string }>;
    latestYear: number; // для сортировки (по последнему совместному проекту)
  }>();

  for (const m of memberships) {
    const project = m.project;
    const yearRange = fmtYearRange(project.startedAt, project.completedAt);
    const startYear = project.startedAt.getFullYear();

    for (const other of project.members) {
      if (other.userId === id) continue;
      const existing = collaboratorsMap.get(other.userId);
      if (existing) {
        existing.projects.push({ title: project.title, yearRange });
        if (startYear > existing.latestYear) existing.latestYear = startYear;
      } else {
        collaboratorsMap.set(other.userId, {
          id: other.user.id,
          name: other.user.name,
          title: other.user.title,
          avatarUrl: other.user.avatarUrl,
          projects: [{ title: project.title, yearRange }],
          latestYear: startYear,
        });
      }
    }
  }

  const collaboratorsAll = Array.from(collaboratorsMap.values()).sort((a, b) => b.latestYear - a.latestYear);
  const collaboratorsTotal = collaboratorsAll.length;
  const collaborators = collaboratorsAll.slice(0, collaboratorsLimit).map((c) => ({
    id: c.id,
    name: c.name,
    title: c.title,
    avatarUrl: c.avatarUrl,
    // Один collaborator может иметь несколько общих проектов — показываем до 2 в карточке
    projects: c.projects.slice(0, 2),
    projectsCount: c.projects.length,
  }));

  // 3) «ПРОЕКТЫ» — список с командой и годами
  const projects = memberships.map((m) => ({
    id: m.project.id,
    title: m.project.title,
    teamSize: m.project.members.length,
    yearRange: fmtYearRange(m.project.startedAt, m.project.completedAt),
    status: m.project.status,
    role: m.role,
  }));

  // 4) «NFT-НАВЫКИ (факты)» — навыки с NFTSkill (minted/confirmed) + кто подтвердил
  const nftSkillsRaw = await db.nFTSkill.findMany({
    where: { userId: id, status: { in: ['minted', 'confirmed'] } },
    take: 12,
    orderBy: { createdAt: 'desc' },
  });

  // Для каждого NFT-навыка подтягиваем SkillConfirmation + имя confirmer
  const nftSkills = await Promise.all(
    nftSkillsRaw.map(async (nft) => {
      const confirmations = await db.skillConfirmation.findMany({
        where: { userSkillId: nft.userSkillId },
        include: {
          confirmer: { select: { id: true, name: true } },
        },
        take: 5,
        orderBy: { createdAt: 'desc' },
      });
      return {
        skillName: nft.skillName,
        level: nft.level,
        confirmedBy: confirmations.map((c) => c.confirmer.name),
      };
    })
  );

  // 5) «с YYYY в профессии» — earliest CareerEntry startDate (если нет — fallback на createdAt)
  const earliestCareer = await db.careerEntry.findFirst({
    where: { userId: id },
    orderBy: { startDate: 'asc' },
    select: { startDate: true },
  });
  const professionalSince = earliestCareer?.startDate
    ? earliestCareer.startDate.getFullYear()
    : user.createdAt.getFullYear();

  return json({
    user: {
      id: user.id,
      name: user.name,
      title: user.title,
      // fix-adversarial (ADV-A109): PII — только владельцу/принятой связи
      bio: canSeePii ? user.bio : null,
      avatarUrl: user.avatarUrl,
      roles: canSeePii ? (user.roles ? user.roles.split(',').filter(Boolean) : []) : [],
      accountType: user.accountType,
      hrInvisible: user.hrInvisible,
      createdAt: user.createdAt.toISOString(),
      professionalStatus: user.professionalStatus,
    },
    professionalSince,
    does: skills.map((s) => s.skill.name),
    collaborators,
    collaboratorsTotal,
    projects,
    nftSkills,
  });
}
