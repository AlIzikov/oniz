// BizON API — /api/users/[id]/transferable (Этап 5.3 — HR view transferable skills)
// Для HR-агентств: возвращает confirmed skills + хобби + AI-аннотацию transferable skills.
//
// Этика / Privacy:
//   • Хобби показываются только если user.showHobbiesToHr=true (по умолчанию false)
//   • Если showHobbiesToHr=false — хобби анонимизируются (просто не возвращаем список,
//     только счётчик «N хобби» для контекста)
//   • Доступ только для авторизованных HR-агентств (accountType='hr_agency')
import { getZaiClient as getZai, type ZaiClient } from '@/lib/ai-core/llm-client'; // W1.6: SDK только в ai-core

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { AIGateway } from '@/lib/ai-core';

// AI-аннотация transferable skills идёт через AIGateway (Task 4-h: rate limit,
// кэш SHA-256, Sovereignty-минимизация); прямой вызов z-ai-web-dev-sdk остался
// только внутри llm-колбэка гейтвея. Промпт/этика/fallback портированы из v5
// (bizon-recovery/src/lib/ai.ts) без изменений.



function asString(v: unknown, fallback = ''): string {
  return typeof v === 'string' ? v : fallback;
}
function asStringArray(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : [];
}
function errMessage(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

function buildFallbackHrAnnotation(
  confirmedSkills: Array<{ name: string; level: number }>,
  hobbies: string[],
): string {
  const strengths = confirmedSkills.slice(0, 3).map((s) => s.name);
  const transferable = [...strengths, ...hobbies.slice(0, 2)].slice(0, 4);
  if (strengths.length === 0) {
    return `Transferable для: ${transferable.join(', ') || 'требуется заполнение профиля'}.`;
  }
  return `Сильные стороны: ${strengths.join(', ')}. Transferable для: ${transferable.join(', ')}.`;
}

/**
 * AI-аннотация «Сильные стороны: X, Y. Transferable для: A, B, C» для HR view.
 * Возвращает короткий текст без оценочных суждений «достоин/недостоин».
 * Выполняется через AIGateway: Sovereignty-субъект — КАНДИДАТ (targetUserId),
 * т.к. в LLM уходит его профиль (классы A/B), а не данные HR-зрителя.
 */
async function generateHrTransferableAnnotation(
  targetUserId: string,
  userName: string,
  confirmedSkills: Array<{ name: string; level: number }>,
  hobbies: string[],
): Promise<{ annotation: string; engine: 'llm' | 'fallback' }> {
  if (confirmedSkills.length === 0 && hobbies.length === 0) {
    return {
      annotation: 'Подтверждённые навыки и хобби пока не заполнены.',
      engine: 'fallback',
    };
  }

  const fallbackAnnotation = (): string => buildFallbackHrAnnotation(confirmedSkills, hobbies);

  try {
    const result = await AIGateway.run<string>({
      userId: targetUserId,
      operation: 'hr.transferable.annotation',
      fields: ['name', 'skills', 'hobbies'],
      priority: 'normal',
      data: {
        name: userName,
        skills: confirmedSkills.map((s) => `${s.name} (${s.level}/5)`),
        hobbies,
      },
      llm: async (minimized) => {
        try {
          const zai = await getZai();
          const m = minimized as Record<string, unknown>;
          const response = await zai.chat.completions.create({
            messages: [
              {
                role: 'system',
                content:
                  'Ты — HR-аналитик BizON. Дай короткую конструктивную аннотацию transferable skills кандидата. ' +
                  'Только факты. Запрещены оценочные суждения «достоин/недостоин». Формат: ' +
                  '"Сильные стороны: X, Y. Transferable для: A, B, C." — одно-два предложения на русском.',
              },
              {
                role: 'user',
                content: `Кандидат: ${asString(m.name, 'Профессионал')}\nПодтверждённые навыки: ${asStringArray(m.skills).join(', ') || 'нет'}\nХобби: ${asStringArray(m.hobbies).join(', ') || 'не указаны'}`,
              },
            ],
            thinking: { type: 'disabled' },
            temperature: 0.4,
            max_tokens: 200,
          });
          const text = (response.choices?.[0]?.message?.content ?? '').trim();
          return text || fallbackAnnotation();
        } catch (e: unknown) {
          console.error('[AI-HR-Annotation] LLM error:', errMessage(e));
          return null; // → gateway fallback
        }
      },
      fallback: fallbackAnnotation,
    });
    if (!result) return { annotation: fallbackAnnotation(), engine: 'fallback' }; // rate limit
    return { annotation: result.value, engine: result.provider === 'llm' ? 'llm' : 'fallback' };
  } catch (e: unknown) {
    console.error('[AI-HR-Annotation] gateway error:', errMessage(e));
    return {
      annotation: fallbackAnnotation(),
      engine: 'fallback',
    };
  }
}

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const currentUser = await getUserFromRequest(req);
  if (!currentUser) return errorJson('Не авторизован', 401);

  // Доступ только для HR-агентств
  if (currentUser.accountType !== 'hr_agency') {
    return errorJson('Доступ только для HR-агентств', 403);
  }

  // Privacy Shield: если кандидат hrInvisible — HR не видит ничего
  const target = await db.user.findUnique({
    where: { id },
    select: {
      id: true,
      name: true,
      title: true,
      bio: true,
      ipScore: true,
      level: true,
      avatarUrl: true,
      hrInvisible: true,
      hobbies: true,
      showHobbiesToHr: true,
    },
  });
  if (!target) return errorJson('Пользователь не найден', 404);

  if (target.hrInvisible) {
    return errorJson('Кандидат отключил видимость для HR (Privacy Shield)', 403);
  }

  // Подтверждённые навыки (verificationLevel != 'claimed')
  const userSkills = await db.userSkill.findMany({
    where: { userId: id, verificationLevel: { not: 'claimed' } },
    include: { skill: true },
    orderBy: { confirmationsCount: 'desc' },
    take: 30,
  });
  const confirmedSkills = userSkills.map((us) => ({
    id: us.id,
    name: us.skill.name,
    level: us.level,
    verificationLevel: us.verificationLevel,
    confirmationsCount: us.confirmationsCount,
  }));

  // Хобби: если showHobbiesToHr=true — полный список, иначе только счётчик
  const hobbiesAll = target.hobbies
    ? target.hobbies.split(',').map((h) => h.trim()).filter(Boolean)
    : [];

  const hobbies =
    target.showHobbiesToHr && hobbiesAll.length > 0
      ? hobbiesAll
      : []; // пустой массив если нет opt-in

  const hobbiesCount = hobbiesAll.length; // счётчик показываем всегда

  // AI-аннотация transferable skills (AIGateway; sovereignty — кандидат)
  const annotationResult = await generateHrTransferableAnnotation(
    target.id,
    target.name,
    confirmedSkills.map((s) => ({ name: s.name, level: s.level })),
    hobbies
  );

  return json({
    user: {
      id: target.id,
      name: target.name,
      title: target.title,
      bio: target.bio,
      ipScore: target.ipScore,
      level: target.level,
      avatarUrl: target.avatarUrl,
    },
    confirmedSkills,
    // Полный список хобби — только если user дал opt-in (showHobbiesToHr=true)
    hobbies,
    // Счётчик хобби показываем всегда (для контекста «у кандидата 3 хобби»)
    hobbiesCount,
    hobbiesVisible: target.showHobbiesToHr,
    annotation: annotationResult.annotation,
    engine: annotationResult.engine,
  });
}
