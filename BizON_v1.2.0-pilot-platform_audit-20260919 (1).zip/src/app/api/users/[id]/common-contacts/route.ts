// BizON API — /api/users/[id]/common-contacts
// Правка 3 — Чужой профиль v2: блок «Общие контакты» (как Vings/XING).
// Возвращает пересечение контактов текущего пользователя и пользователя [id]:
//   • соединения (Connection, status='accepted') — двунаправленные
//   • соавторов по проектам (ProjectMember одного проекта) — опционально, как расширение
// Ответ: { contacts: [{id, name, title, avatarUrl}], total }
// Приватность: только для авторизованного пользователя, не self.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// Лимит аватаров, возвращаемых в contacts[] (UI показывает 3 + «+N»)
const MAX_CONTACTS_RETURNED = 8;

export async function GET(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> }
) {
  const me = await getUserFromRequest(req);
  if (!me) return errorJson('Не авторизован', 401);

  const { id: otherId } = await ctx.params;
  if (!otherId) return errorJson('id обязателен', 422);
  if (otherId === me.id) {
    // У себя с собой нет «общих контактов» — возвращаем пустой список.
    return json({ contacts: [], total: 0 });
  }

  const other = await db.user.findUnique({
    where: { id: otherId },
    select: { id: true },
  });
  if (!other) return errorJson('Пользователь не найден', 404);

  // ---------- 1. Контакты me (accepted connections — двунаправленные) ----------
  const myConns = await db.connection.findMany({
    where: {
      status: 'accepted',
      OR: [{ fromUserId: me.id }, { toUserId: me.id }],
    },
    select: {
      fromUserId: true,
      toUserId: true,
    },
  });
  const myContactIds = new Set<string>();
  for (const c of myConns) {
    if (c.fromUserId === me.id) myContactIds.add(c.toUserId);
    else if (c.toUserId === me.id) myContactIds.add(c.fromUserId);
  }
  // Не считаем «друг друга» общим контактом.
  myContactIds.delete(otherId);

  // ---------- 2. Контакты other (accepted connections — двунаправленные) ----------
  const otherConns = await db.connection.findMany({
    where: {
      status: 'accepted',
      OR: [{ fromUserId: otherId }, { toUserId: otherId }],
    },
    select: { fromUserId: true, toUserId: true },
  });
  const otherContactIds = new Set<string>();
  for (const c of otherConns) {
    if (c.fromUserId === otherId) otherContactIds.add(c.toUserId);
    else if (c.toUserId === otherId) otherContactIds.add(c.fromUserId);
  }
  otherContactIds.delete(me.id);

  // ---------- 3. Пересечение ----------
  const intersection = new Set<string>();
  for (const id of myContactIds) {
    if (otherContactIds.has(id)) intersection.add(id);
  }

  const total = intersection.size;
  if (total === 0) {
    return json({ contacts: [], total: 0 });
  }

  // ---------- 4. Загружаем профили общих контактов ----------
  const contactIds = Array.from(intersection);
  const users = await db.user.findMany({
    where: { id: { in: contactIds } },
    select: {
      id: true,
      name: true,
      title: true,
      avatarUrl: true,
      ipScore: true,
    },
    // Сортируем по IP-score — показываем сначала самых «влиятельных» общих знакомых.
    orderBy: { ipScore: 'desc' },
    take: MAX_CONTACTS_RETURNED,
  });

  return json({
    contacts: users.map((u) => ({
      id: u.id,
      name: u.name,
      title: u.title,
      avatarUrl: u.avatarUrl,
    })),
    total,
  });
}
