// BizON API — POST /api/users/[id]/view
// Phase 3: записывает факт просмотра профиля пользователя [id] текущим юзером.
// Дедупликация: если тот же viewer смотрел тот же профиль за последние 24 часа —
// новая запись не создаётся (возвращаем { ok: true } как при успехе).
// Self-view игнорируется (нельзя «посмотреть на себя» в статистике).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// 24 часа в миллисекундах — окно дедупликации ProfileView
const DEDUP_WINDOW_MS = 24 * 60 * 60 * 1000;

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  const currentUser = await getUserFromRequest(req);
  if (!currentUser) return errorJson('Не авторизован', 401);

  // Self-view не записываем (бессмысленно для статистики «кто обратил внимание»)
  if (currentUser.id === id) {
    return json({ ok: true, deduplicated: true, reason: 'self' });
  }

  // Проверяем, что viewed-пользователь существует и не удалён
  const viewed = await db.user.findUnique({
    where: { id },
    select: { id: true, deletedAt: true },
  });
  if (!viewed || viewed.deletedAt) {
    return errorJson('Пользователь не найден', 404);
  }

  // Дедупликация: ищем запись ProfileView от этого viewer за последние 24 часа
  const since = new Date(Date.now() - DEDUP_WINDOW_MS);
  const existing = await db.profileView.findFirst({
    where: {
      viewerId: currentUser.id,
      viewedId: id,
      viewedAt: { gte: since },
    },
    select: { id: true },
  });

  if (existing) {
    // Уже смотрел недавно — не дублируем
    return json({ ok: true, deduplicated: true });
  }

  // Создаём новую запись ProfileView
  await db.profileView.create({
    data: {
      viewerId: currentUser.id,
      viewedId: id,
    },
  });

  return json({ ok: true, deduplicated: false });
}
