// BizON API — /api/users/recommendations
// AI Matchmaker fallback: если /api/ai/matchmaker без q не отдаёт рекомендации,
// показываем людей с общими контактами (2-hop friends-of-friends).
//
// Алгоритм:
//   1. Берём все принятые связи текущего пользователя (1-hop).
//   2. Для каждого 1-hop друга — берём его связи (2-hop).
//   3. Исключаем: себя, своих прямых друзей, declined/pending.
//   4. Группируем 2-hop людей по числу общих контактов (mutual count).
//   5. Берём ТОП-5 по mutual count,.tie-break по isVerified, затем по имени.
//
// Принципы:
//   • БЕЗ IP-score публично (только владельцу)
//   • БЕЗ email/phone
//   • «через N рукопожатий» = число общих контактов (2 рукопожатия = 1 mutual)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const RECO_LIMIT = 5;
const MAX_HOP_SCAN = 200; // лимит 1-hop друзей, чтобы не положить БД

interface RecoCandidate {
  id: string;
  name: string;
  title: string | null;
  avatarUrl: string | null;
  location: string | null;
  accountType: string;
  isVerified: boolean;
  roles: string[];
  company: { id: string; name: string; logoUrl: string | null } | null;
  commonConnections: number;
  commonConnectionUsers: Array<{ id: string; name: string; avatarUrl: string | null }>;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // 1. Мои прямые связи (1-hop)
  const myConnectionsRaw = await db.connection.findMany({
    where: {
      OR: [{ fromUserId: user.id }, { toUserId: user.id }],
      status: 'accepted',
    },
    select: { fromUserId: true, toUserId: true },
    take: MAX_HOP_SCAN,
  });

  const myFriendIds = new Set<string>();
  for (const c of myConnectionsRaw) {
    if (c.fromUserId !== user.id) myFriendIds.add(c.fromUserId);
    if (c.toUserId !== user.id) myFriendIds.add(c.toUserId);
  }

  // Если у пользователя нет друзей — вернуть пустой список
  if (myFriendIds.size === 0) {
    return json({ recommendations: [], message: 'Пока нет общих контактов. Добавьте коллег во вкладке «Все люди».' });
  }

  // 2. Связи моих друзей (2-hop) — берём все accepted соединения, где один конец = мой друг
  const friendIdsArray = Array.from(myFriendIds);
  const secondHopRaw = await db.connection.findMany({
    where: {
      status: 'accepted',
      OR: [
        { fromUserId: { in: friendIdsArray } },
        { toUserId: { in: friendIdsArray } },
      ],
    },
    select: { fromUserId: true, toUserId: true },
    take: 1000, // защитный лимит
  });

  // 3. Группируем 2-hop кандидатов → считаем mutual (через каких общих друзей мы связаны)
  // mutualMap: candidateId → Set(friendId кто нас связывает)
  const mutualMap = new Map<string, Set<string>>();
  for (const c of secondHopRaw) {
    let friendId: string | null = null;
    let candidateId: string | null = null;

    if (myFriendIds.has(c.fromUserId) && c.toUserId !== user.id && !myFriendIds.has(c.toUserId)) {
      friendId = c.fromUserId;
      candidateId = c.toUserId;
    } else if (myFriendIds.has(c.toUserId) && c.fromUserId !== user.id && !myFriendIds.has(c.fromUserId)) {
      friendId = c.toUserId;
      candidateId = c.fromUserId;
    }

    if (friendId && candidateId) {
      if (!mutualMap.has(candidateId)) mutualMap.set(candidateId, new Set());
      mutualMap.get(candidateId)!.add(friendId);
    }
  }

  if (mutualMap.size === 0) {
    return json({ recommendations: [], message: 'Пока нет общих контактов. Добавьте коллег во вкладке «Все люди».' });
  }

  // 4. Берём ТОП-5 кандидатов по mutual count
  const sortedCandidates = Array.from(mutualMap.entries())
    .sort((a, b) => b[1].size - a[1].size)
    .slice(0, RECO_LIMIT * 3); // берём с запасом, потом отфильтруем

  // 5. Загружаем полные данные по кандидатам + по общим друзьям одним батчем
  const candidateIds = sortedCandidates.map(([id]) => id);
  const allMutualIds = new Set<string>();
  for (const [, friends] of sortedCandidates) {
    for (const fid of friends) allMutualIds.add(fid);
  }

  const [candidateUsers, mutualUsers] = await Promise.all([
    db.user.findMany({
      where: { id: { in: candidateIds }, deletedAt: null },
      select: {
        id: true,
        name: true,
        title: true,
        avatarUrl: true,
        location: true,
        accountType: true,
        isVerified: true,
        roles: true,
        ipScore: true, // только для сортировки — НЕ возвращается наружу
        company: { select: { id: true, name: true, logoUrl: true } },
      },
    }),
    db.user.findMany({
      where: { id: { in: Array.from(allMutualIds) } },
      select: { id: true, name: true, avatarUrl: true },
    }),
  ]);

  // Мапы для быстрого доступа
  const candidateMap = new Map(candidateUsers.map((u) => [u.id, u]));
  const mutualMap2 = new Map(mutualUsers.map((u) => [u.id, u]));

  // 6. Формируем итоговый массив рекомендаций
  const recommendations: RecoCandidate[] = sortedCandidates
    .map(([candidateId, mutualFriends]) => {
      const u = candidateMap.get(candidateId);
      if (!u) return null;
      // Берём первые 3 общих друга для аватарок
      const commonUsers = Array.from(mutualFriends)
        .slice(0, 3)
        .map((fid) => mutualMap2.get(fid))
        .filter(Boolean)
        .map((mu) => ({ id: mu!.id, name: mu!.name, avatarUrl: mu!.avatarUrl }));

      return {
        id: u.id,
        name: u.name,
        title: u.title,
        avatarUrl: u.avatarUrl,
        location: u.location,
        accountType: u.accountType,
        isVerified: u.isVerified,
        roles: u.roles ? u.roles.split(',').filter(Boolean) : [],
        company: u.company
          ? { id: u.company.id, name: u.company.name, logoUrl: u.company.logoUrl }
          : null,
        commonConnections: mutualFriends.size,
        commonConnectionUsers: commonUsers,
      } as RecoCandidate;
    })
    .filter((x): x is RecoCandidate => x !== null)
    // tie-break по isVerified, затем по имени
    .sort((a, b) => {
      if (b.commonConnections !== a.commonConnections) return b.commonConnections - a.commonConnections;
      if (a.isVerified !== b.isVerified) return a.isVerified ? -1 : 1;
      return a.name.localeCompare(b.name);
    })
    .slice(0, RECO_LIMIT);

  return json({
    recommendations,
    total: mutualMap.size,
  });
}
