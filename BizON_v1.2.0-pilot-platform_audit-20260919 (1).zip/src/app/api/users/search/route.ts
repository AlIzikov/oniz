// BizON API — /api/users/search?q=...
// Добавлен auth check + убран email из результатов поиска (PII защита)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const q = req.nextUrl.searchParams.get('q')?.trim() ?? '';
  const limit = Math.min(Number(req.nextUrl.searchParams.get('limit') ?? 20), 50);
  if (q.length < 2) return json({ users: [] });

  const users = await db.user.findMany({
    where: {
      OR: [
        { name: { contains: q } },
        { title: { contains: q } },
        { location: { contains: q } },
      ],
    },
    take: limit,
    orderBy: { ipScore: 'desc' },
    select: {
      id: true, name: true, title: true, location: true,
      avatarUrl: true, ipScore: true, level: true, bio: true, roles: true,
      accountType: true, isVerified: true,
      // email НЕ возвращаем в поиске — PII защита
    },
  });

  return json({
    users: users.map((u) => ({
      ...u,
      roles: u.roles ? u.roles.split(',').filter(Boolean) : [],
    })),
  });
}
