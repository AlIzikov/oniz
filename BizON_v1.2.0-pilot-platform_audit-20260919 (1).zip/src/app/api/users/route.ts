// BizON API — /api/users
// Список всех пользователей BizON (для раздела «Все люди»).
// Принципы:
//   • БЕЗ IP-score публично (только владелец видит свой — /api/auth/me)
//   • БЕЗ email/phone (PII защита)
//   • Auth required
//   • Пагинация 20, фильтры: location / skill / q / accountType
//   • Текущий пользователь исключается из выдачи
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const PAGE_SIZE = 20;
const MAX_PAGE_SIZE = 50;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const sp = req.nextUrl.searchParams;
  const q = sp.get('q')?.trim() ?? '';
  const location = sp.get('location')?.trim() ?? '';
  const skill = sp.get('skill')?.trim() ?? '';
  const accountType = sp.get('accountType')?.trim() ?? '';
  const cursor = sp.get('cursor')?.trim() ?? '';
  const limit = Math.min(Number(sp.get('limit') ?? PAGE_SIZE), MAX_PAGE_SIZE);

  // Базовый where — исключаем себя и soft-deleted
  const where: any = {
    id: { not: user.id },
    deletedAt: null,
  };

  if (q) {
    where.OR = [
      { name: { contains: q } },
      { title: { contains: q } },
      { roles: { contains: q } },
    ];
  }

  if (location) {
    // location хранится в encrypted-виде, но для MVP фильтруем по plaintext (часть пользователей имеет старый plaintext)
    // и по public полю locationEncrypted не contains — fallback: совпадение только если plaintext заполнен
    where.location = { contains: location };
  }

  if (accountType && ['individual', 'company', 'hr_agency'].includes(accountType)) {
    where.accountType = accountType;
  }

  // Фильтр по навыку — через UserSkill → Skill.name contains
  if (skill) {
    where.skills = {
      some: {
        skill: { name: { contains: skill } },
      },
    };
  }

  // Запрос списка + total одним заходом
  const [users, total] = await Promise.all([
    db.user.findMany({
      where,
      orderBy: [{ isVerified: 'desc' }, { createdAt: 'desc' }],
      take: limit + 1, // +1 чтобы понять, есть ли ещё
      ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      select: {
        id: true,
        name: true,
        title: true,
        avatarUrl: true,
        location: true,
        accountType: true,
        isVerified: true,
        roles: true,
        company: { select: { id: true, name: true, logoUrl: true } },
      },
    }),
    db.user.count({ where }),
  ]);

  const hasMore = users.length > limit;
  const slice = hasMore ? users.slice(0, limit) : users;
  const nextCursor = hasMore ? slice[slice.length - 1]?.id ?? null : null;

  return json({
    users: slice.map((u) => ({
      id: u.id,
      name: u.name,
      title: u.title,
      avatarUrl: u.avatarUrl,
      location: u.location,
      accountType: u.accountType,
      isVerified: u.isVerified,
      roles: u.roles ? u.roles.split(',').filter(Boolean) : [],
      company: u.company
        ? { id: u.company.id, name: u.company.name, logoUrl: u.company.logoUrl }
        : null,
    })),
    total,
    hasMore,
    nextCursor,
  });
}
