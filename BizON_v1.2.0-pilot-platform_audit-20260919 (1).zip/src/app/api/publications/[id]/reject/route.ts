// BizON API — /api/publications/[id]/reject
// Этап 7.3 — co-author отклоняет приглашение (удаляет запись PublicationAuthor)
// Автор не может отклонить (нельзя удалить публикацию через этот endpoint).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { NotificationService } from '@/lib/services';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;

  try {
    const pub = await db.publication.findUnique({ where: { id } });
    if (!pub) return errorJson('Публикация не найдена', 404);

    const invite = await db.publicationAuthor.findUnique({
      where: { publicationId_userId: { publicationId: id, userId: user.id } },
    });

    if (!invite) {
      return errorJson('Вас не пригласили в соавторы этой публикации', 403);
    }
    if (invite.role === 'author') {
      return errorJson('Автор не может отклонить своё собственное приглашение', 400);
    }

    // Удаляем запись — соавтор отклонил приглашение
    await db.publicationAuthor.delete({ where: { id: invite.id } });

    // Уведомить автора публикации об отклонении
    const author = await db.publicationAuthor.findFirst({
      where: { publicationId: id, role: 'author' },
      select: { userId: true },
    });
    if (author) {
      NotificationService.notify(author.userId, {
        type: 'mention',
        title: `Соавтор отклонил приглашение`,
        body: `${user.name} отклонил приглашение соавторства публикации «${pub.title}».`,
        link: `/api/publications/${pub.id}`,
        metadata: { publicationId: pub.id, rejectedUserId: user.id },
      }).catch(() => {});
    }

    return json({ ok: true });
  } catch (e) {
    console.error('[publications/reject] error:', e);
    return errorJson('Ошибка отклонения приглашения', 500);
  }
}
