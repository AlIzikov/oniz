// BizON API — /api/publications/[id]/accept
// Этап 7.3 — co-author принимает приглашение (acceptedAt = now())
// Только пользователь с role=co_author|contributor и acceptedAt IS NULL может принять.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ActionEventService, NotificationService } from '@/lib/services';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;

  try {
    const pub = await db.publication.findUnique({ where: { id } });
    if (!pub) return errorJson('Публикация не найдена', 404);

    // Найти запись соавтора для текущего пользователя
    const invite = await db.publicationAuthor.findUnique({
      where: { publicationId_userId: { publicationId: id, userId: user.id } },
    });

    if (!invite) {
      return errorJson('Вас не пригласили в соавторы этой публикации', 403);
    }
    if (invite.role === 'author') {
      return errorJson('Вы уже являетесь автором публикации', 400);
    }
    if (invite.acceptedAt) {
      return errorJson('Приглашение уже принято', 400);
    }

    await db.publicationAuthor.update({
      where: { id: invite.id },
      data: { acceptedAt: new Date() },
    });

    // ActionEvent: article_published для соавтора (он присоединился к публикации)
    ActionEventService.logAction({
      userId: user.id,
      type: 'article_published',
      title: `Присоединился как соавтор публикации «${pub.title}»`,
      description: pub.content.slice(0, 280),
      metadata: {
        publicationId: pub.id,
        type: pub.type,
        role: invite.role,
        asCoAuthor: true,
      },
    }).catch(() => {});

    // Уведомить автора публикации (и других уже принятых соавторов)
    const allAuthors = await db.publicationAuthor.findMany({
      where: { publicationId: id, acceptedAt: { not: null }, userId: { not: user.id } },
      select: { userId: true },
    });
    for (const a of allAuthors) {
      NotificationService.notify(a.userId, {
        type: 'mention',
        title: `Соавтор принял приглашение`,
        body: `${user.name} присоединился к публикации «${pub.title}» как ${invite.role}.`,
        link: `/api/publications/${pub.id}`,
        metadata: { publicationId: pub.id, acceptedUserId: user.id },
      }).catch(() => {});
    }

    return json({ ok: true, acceptedAt: new Date().toISOString() });
  } catch (e) {
    console.error('[publications/accept] error:', e);
    return errorJson('Ошибка принятия приглашения', 500);
  }
}
