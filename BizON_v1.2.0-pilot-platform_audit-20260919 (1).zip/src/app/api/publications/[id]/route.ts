// BizON API — /api/publications/[id]
// Этап 7.3 — детали публикации с авторами
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

function authorSelect() {
  return {
    id: true,
    userId: true,
    role: true,
    acceptedAt: true,
    user: {
      select: {
        id: true,
        name: true,
        title: true,
        avatarUrl: true,
        ipScore: true,
        level: true,
      },
    },
  } as const;
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const pub = await db.publication.findUnique({ where: { id } });
  if (!pub) return errorJson('Публикация не найдена', 404);

  const authors = await db.publicationAuthor.findMany({
    where: { publicationId: id },
    orderBy: [{ role: 'asc' }, { acceptedAt: 'asc' }],
    select: authorSelect(),
  });

  const myInvite = (() => {
    const me = authors.find((a) => a.userId === user.id);
    if (!me) return null;
    return {
      role: me.role,
      acceptedAt: me.acceptedAt ? me.acceptedAt.toISOString() : null,
    };
  })();
  const isAuthor = authors.some((a) => a.userId === user.id && a.role === 'author');

  return json({
    publication: {
      id: pub.id,
      title: pub.title,
      type: pub.type,
      content: pub.content,
      externalUrl: pub.externalUrl,
      imageUrl: pub.imageUrl,
      readingTime: pub.readingTime,
      projectId: pub.projectId,
      publishedAt: pub.publishedAt.toISOString(),
      createdAt: pub.createdAt.toISOString(),
      authors: authors.map((a) => ({
        id: a.id,
        userId: a.userId,
        role: a.role,
        acceptedAt: a.acceptedAt ? a.acceptedAt.toISOString() : null,
        user: a.user,
      })),
      myInvite,
      isAuthor,
    },
  });
}
