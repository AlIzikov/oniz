// BizON API — /api/publications
// Этап 7.3 — Publications co-authoring (до 5 авторов: 1 author + до 4 co_author)
// Создание публикации + список с фильтром по type.
// FIX-07: POST через withRoute — auth 401, zod-схема createPublication (whitelist,
// strip), единый маппинг ошибок (Prisma P2002→409); без сырых e.message для 5xx.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { ActionEventService, NotificationService } from '@/lib/services';
import type { PublicationAuthorPublic, PublicationPublic } from '@/lib/types';

export const runtime = 'nodejs';

const PUBLICATION_TYPES = [
  'ARTICLE',
  'CASE_STUDY',
  'OPINION',
  'RESEARCH',
  'TUTORIAL',
  'INTERVIEW',
] as const;
type PublicationType = (typeof PUBLICATION_TYPES)[number];

const MAX_CO_AUTHORS = 4; // +1 author = 5 authors total
// FIX-07: лимиты title (≤240) и content (≤50000) переехали в schemas.createPublication
// (src/lib/validation.ts) — валидация через withRoute opts.schema.
const MAX_URL = 2048;

function isPublicationType(v: unknown): v is PublicationType {
  return typeof v === 'string' && (PUBLICATION_TYPES as readonly string[]).includes(v);
}

function authorSelect() {
  return {
    id: true,
    publicationId: true, // FIX-06: нужен для группировки авторов по публикациям
    userId: true,
    role: true,
    acceptedAt: true,
    user: {
      select: {
        id: true,
        name: true,
        title: true,
        avatarUrl: true,
        ipScore: true,
        level: true,
      },
    },
  } as const;
}

function mapAuthor(a: any): PublicationAuthorPublic {
  return {
    id: a.id,
    userId: a.userId,
    role: a.role,
    acceptedAt: a.acceptedAt ? a.acceptedAt.toISOString() : null,
    user: a.user,
  };
}

function toPublic(pub: any, currentUserId: string | null): PublicationPublic {
  const myInvite = currentUserId
    ? (() => {
        const me = pub.authors?.find((a: any) => a.userId === currentUserId);
        if (!me) return null;
        return {
          role: me.role,
          acceptedAt: me.acceptedAt ? me.acceptedAt.toISOString() : null,
        };
      })()
    : null;
  const isAuthor = currentUserId
    ? pub.authors?.some((a: any) => a.userId === currentUserId && a.role === 'author')
    : false;
  return {
    id: pub.id,
    title: pub.title,
    type: pub.type,
    content: pub.content,
    externalUrl: pub.externalUrl,
    imageUrl: pub.imageUrl,
    readingTime: pub.readingTime,
    projectId: pub.projectId,
    publishedAt: pub.publishedAt.toISOString(),
    createdAt: pub.createdAt.toISOString(),
    authors: (pub.authors ?? []).map(mapAuthor),
    myInvite,
    isAuthor,
  };
}

// === GET /api/publications — список с фильтром по type ===
// Query:
//   type=ARTICLE         — фильтр по типу (один)
//   limit=20             — лимит (макс 100)
//   offset=0             — смещение
//   mine=true            — только публикации, где я author или co_author
//   pending=true         — только приглашения, ожидающие моего ответа (acceptedAt IS NULL)
export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const sp = req.nextUrl.searchParams;
  const typeFilter = sp.get('type');
  const mine = sp.get('mine') === 'true';
  const pending = sp.get('pending') === 'true';
  const limit = Math.min(100, Math.max(1, parseInt(sp.get('limit') ?? '20', 10) || 20));
  const offset = Math.max(0, parseInt(sp.get('offset') ?? '0', 10) || 0);

  const where: any = {};
  if (typeFilter && isPublicationType(typeFilter)) {
    where.type = typeFilter;
  } else if (typeFilter) {
    return errorJson(`type: один из ${PUBLICATION_TYPES.join(' | ')}`, 422);
  }

  if (mine && !pending) {
    where.authors = { some: { userId: user.id } };
  }
  if (pending) {
    // Только приглашения, ожидающие моего ответа (co_author с acceptedAt IS NULL)
    where.authors = {
      some: { userId: user.id, acceptedAt: null, role: { not: 'author' } },
    };
  }

  const [items, total] = await Promise.all([
    db.publication.findMany({
      where,
      orderBy: { publishedAt: 'desc' },
      take: limit,
      skip: offset,
    }),
    db.publication.count({ where }),
  ]);

  // FIX-06 (N+1): раньше — publicationAuthor.findMany на каждую публикацию в
  // списке. Теперь ОДИН запрос where publicationId in: + группировка Map в JS
  // (сортировка внутри публикации: role asc, acceptedAt asc — как раньше).
  const pubIds = items.map((p) => p.id);
  const allAuthors =
    pubIds.length > 0
      ? await db.publicationAuthor.findMany({
          where: { publicationId: { in: pubIds } },
          orderBy: [{ role: 'asc' }, { acceptedAt: 'asc' }],
          select: authorSelect(),
        })
      : [];
  const authorsByPublication = new Map<string, typeof allAuthors>();
  for (const a of allAuthors) {
    const arr = authorsByPublication.get(a.publicationId) ?? [];
    arr.push(a);
    authorsByPublication.set(a.publicationId, arr);
  }

  const publications = items.map((p) => ({
    ...p,
    authors: (authorsByPublication.get(p.id) ?? []).sort((a, b) => {
      if (a.role !== b.role) return a.role < b.role ? -1 : 1;
      const at = a.acceptedAt?.getTime() ?? Number.NEGATIVE_INFINITY;
      const bt = b.acceptedAt?.getTime() ?? Number.NEGATIVE_INFINITY;
      return at - bt;
    }),
  }));

  return json({
    items: publications.map((p) => toPublic(p, user.id)),
    total,
    hasMore: offset + items.length < total,
    filters: { types: [...PUBLICATION_TYPES] },
  });
}

// === POST /api/publications — создать публикацию ===
// Body: { title, type, content, externalUrl?, imageUrl?, readingTime?, projectId?, coAuthorIds: string[] }
// FIX-07: валидация — schema.createPublication (title ≤240 = MAX_TITLE, content ≤50000,
// type enum, coAuthorIds ≤4, strip неизвестных полей).
export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const {
      title,
      type,
      content,
      externalUrl,
      imageUrl,
      readingTime,
      projectId,
      coAuthorIds,
    } = ctx.data as {
      title: string;
      type: PublicationType;
      content: string;
      externalUrl?: string;
      imageUrl?: string;
      readingTime?: number;
      projectId?: string;
      coAuthorIds?: string[];
    };

    const cleanExternalUrl =
      typeof externalUrl === 'string' && externalUrl.trim()
        ? externalUrl.trim().slice(0, MAX_URL)
        : null;
    const cleanImageUrl =
      typeof imageUrl === 'string' && imageUrl.trim()
        ? imageUrl.trim().slice(0, MAX_URL)
        : null;
    const cleanReadingTime =
      typeof readingTime === 'number' && Number.isFinite(readingTime) && readingTime > 0
        ? Math.min(600, Math.floor(readingTime))
        : null;
    const cleanProjectId =
      typeof projectId === 'string' && projectId.trim() ? projectId.trim() : null;

    // Co-author IDs: dedupe + не себя + лимит 4
    let coAuthors: string[] = [];
    if (Array.isArray(coAuthorIds)) {
      const uniq = Array.from(
        new Set(coAuthorIds.map((id) => String(id)).filter((id) => id && id !== user.id)),
      );
      coAuthors = uniq.slice(0, MAX_CO_AUTHORS);
    }

    // Проверяем что co-author IDs существуют в БД
    if (coAuthors.length > 0) {
      const found = await db.user.findMany({
        where: { id: { in: coAuthors } },
        select: { id: true },
      });
      if (found.length !== coAuthors.length) {
        return errorJson('Один или несколько coAuthorIds не существуют', 422);
      }
    }

    // Создаём публикацию с author + co_authors в одной транзакции
    const publication = await db.$transaction(async (tx) => {
      const pub = await tx.publication.create({
        data: {
          title: title.trim(),
          type,
          content,
          externalUrl: cleanExternalUrl,
          imageUrl: cleanImageUrl,
          readingTime: cleanReadingTime,
          projectId: cleanProjectId,
        },
      });

      // Создатель — author (принял сразу)
      await tx.publicationAuthor.create({
        data: {
          publicationId: pub.id,
          userId: user.id,
          role: 'author',
          acceptedAt: new Date(),
        },
      });

      // Co-authors — приглашены (acceptedAt = null)
      if (coAuthors.length > 0) {
        // Создаём по одному, чтобы обработать коллизию уникального индекса (publicationId, userId).
        // Prisma SQLite не поддерживает skipDuplicates в createMany — фильтруем дубли на уровне приложения.
        const seen = new Set<string>();
        for (const uid of coAuthors) {
          if (seen.has(uid)) continue;
          seen.add(uid);
          try {
            await tx.publicationAuthor.create({
              data: {
                publicationId: pub.id,
                userId: uid,
                role: 'co_author',
                acceptedAt: null,
              },
            });
          } catch {
            // Дубль (publicationId, userId) — пропускаем
          }
        }
      }

      const authors = await tx.publicationAuthor.findMany({
        where: { publicationId: pub.id },
        orderBy: [{ role: 'asc' }, { acceptedAt: 'asc' }],
        select: authorSelect(),
      });

      return { ...pub, authors };
    });

    // ActionEvent: article_published для автора
    ActionEventService.logAction({
      userId: user.id,
      type: 'article_published',
      title: `Опубликована статья «${publication.title}»`,
      description: publication.content.slice(0, 280),
      metadata: {
        publicationId: publication.id,
        type: publication.type,
        coAuthorsCount: coAuthors.length,
      },
    }).catch(() => {});

    // Уведомления соавторам: «Вас пригласили стать соавтором»
    for (const coId of coAuthors) {
      NotificationService.notify(coId, {
        type: 'mention',
        title: `Вас пригласили стать соавтором публикации`,
        body: `«${publication.title}» — примите или отклоните приглашение.`,
        link: `/api/publications/${publication.id}`,
        metadata: { publicationId: publication.id, invitedBy: user.id },
      }).catch(() => {});
    }

    return json({ publication: toPublic(publication, user.id) }, 201);
  },
  { schema: schemas.createPublication },
);
