// BizON API — /api/career-entries/[id]
// GPT Truth Engine (A8): PATCH/DELETE записи карьеры (только owner)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

function parseDate(v: unknown): Date | null {
  if (typeof v !== 'string' && typeof v !== 'number') return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  try {
    const entry = await db.careerEntry.findUnique({ where: { id } });
    if (!entry) return errorJson('Запись не найдена', 404);
    if (entry.userId !== user.id) return errorJson('Только владелец может редактировать запись', 403);

    const body = await req.json();
    const { company, position, startDate, endDate, description, location } = body ?? {};

    const data: {
      company?: string;
      position?: string;
      startDate?: Date;
      endDate?: Date | null;
      description?: string | null;
      location?: string | null;
    } = {};

    if (company !== undefined) {
      if (typeof company !== 'string' || company.trim().length === 0 || company.length > 200) {
        return errorJson('company должен быть строкой 1-200 символов', 422);
      }
      data.company = company.trim();
    }
    if (position !== undefined) {
      if (typeof position !== 'string' || position.trim().length === 0 || position.length > 200) {
        return errorJson('position должен быть строкой 1-200 символов', 422);
      }
      data.position = position.trim();
    }
    if (startDate !== undefined) {
      const start = parseDate(startDate);
      if (!start) return errorJson('startDate должен быть корректной датой', 422);
      data.startDate = start;
    }
    if (endDate !== undefined) {
      if (endDate === null) {
        data.endDate = null;
      } else {
        const end = parseDate(endDate);
        if (!end) return errorJson('endDate должен быть корректной датой или null', 422);
        data.endDate = end;
      }
    }
    if (description !== undefined) {
      if (description !== null && (typeof description !== 'string' || description.length > 5000)) {
        return errorJson('description должен быть строкой до 5000 символов или null', 422);
      }
      data.description = description?.trim() || null;
    }
    if (location !== undefined) {
      if (location !== null && (typeof location !== 'string' || location.length > 200)) {
        return errorJson('location должен быть строкой до 200 символов или null', 422);
      }
      data.location = location?.trim() || null;
    }

    // Согласованность дат
    const finalStart = data.startDate ?? entry.startDate;
    const finalEnd = data.endDate !== undefined ? data.endDate : entry.endDate;
    if (finalStart && finalEnd && finalEnd < finalStart) {
      return errorJson('endDate не может быть раньше startDate', 422);
    }

    const updated = await db.careerEntry.update({ where: { id }, data });

    AuditLog.log({
      actorId: user.id,
      action: 'update',
      resource: 'career_entry',
      resourceId: id,
      ip: getClientIP(req),
      metadata: { fields: Object.keys(data) },
    });

    return json({ entry: updated });
  } catch (e) {
    console.error('[career-entries/patch] error:', e);
    return errorJson('Ошибка обновления записи', 500);
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  try {
    const entry = await db.careerEntry.findUnique({ where: { id } });
    if (!entry) return errorJson('Запись не найдена', 404);
    if (entry.userId !== user.id) return errorJson('Только владелец может удалить запись', 403);

    await db.careerEntry.delete({ where: { id } });

    AuditLog.log({
      actorId: user.id,
      action: 'delete',
      resource: 'career_entry',
      resourceId: id,
      ip: getClientIP(req),
      metadata: { company: entry.company, position: entry.position },
    });

    return json({ ok: true });
  } catch (e) {
    console.error('[career-entries/delete] error:', e);
    return errorJson('Ошибка удаления записи', 500);
  }
}
