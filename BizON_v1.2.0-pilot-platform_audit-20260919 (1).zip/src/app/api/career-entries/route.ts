// BizON API — /api/career-entries
// GPT Truth Engine (A8): Career Timeline — список + создание записей о карьере
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS, getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

function parseDate(v: unknown): Date | null {
  if (typeof v !== 'string' && typeof v !== 'number') return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const entries = await db.careerEntry.findMany({
    where: { userId: user.id },
    orderBy: { startDate: 'desc' },
  });

  return json({
    entries: entries.map((e) => ({
      id: e.id,
      company: e.company,
      position: e.position,
      startDate: e.startDate?.toISOString() ?? null,
      endDate: e.endDate?.toISOString() ?? null,
      description: e.description,
      location: e.location,
      verificationLevel: e.verificationLevel,
      createdAt: e.createdAt.toISOString(),
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'career:create', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { company, position, startDate, endDate, description, location, title } = body ?? {};

    if (typeof company !== 'string' || company.trim().length === 0 || company.length > 200) {
      return errorJson('company должен быть строкой 1-200 символов', 422);
    }
    if (typeof position !== 'string' || position.trim().length === 0 || position.length > 200) {
      return errorJson('position должен быть строкой 1-200 символов', 422);
    }
    const start = parseDate(startDate);
    if (!start) return errorJson('startDate обязателен и должен быть корректной датой', 422);
    const end = endDate ? parseDate(endDate) : null;
    if (endDate && !end) return errorJson('endDate должен быть корректной датой или null', 422);
    if (end && end < start) return errorJson('endDate не может быть раньше startDate', 422);
    if (description !== undefined && description !== null &&
        (typeof description !== 'string' || description.length > 5000)) {
      return errorJson('description должен быть строкой до 5000 символов', 422);
    }
    if (location !== undefined && location !== null &&
        (typeof location !== 'string' || location.length > 200)) {
      return errorJson('location должен быть строкой до 200 символов', 422);
    }

    const entry = await db.careerEntry.create({
      data: {
        userId: user.id,
        title: typeof title === 'string' && title.trim().length > 0 ? title.trim().slice(0, 200) : position.trim(),
        company: company.trim(),
        position: position.trim(),
        startDate: start,
        endDate: end,
        description: description?.trim() || null,
        location: location?.trim() || null,
        verificationLevel: 'claimed',
      },
    });

    AuditLog.log({
      actorId: user.id,
      action: 'create',
      resource: 'career_entry',
      resourceId: entry.id,
      ip: getClientIP(req),
      metadata: { company: entry.company, position: entry.position },
    });

    return json({ entry }, 201);
  } catch (e) {
    console.error('[career-entries/create] error:', e);
    return errorJson('Ошибка создания записи о карьере', 500);
  }
}
