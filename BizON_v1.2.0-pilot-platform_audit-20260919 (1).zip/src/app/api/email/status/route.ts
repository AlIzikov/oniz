// BizON API — /api/email/status
// Этап 8.6 — Email re-engagement: возвращает признак «SMTP настроен на сервере».
//
// Используется в Настройках (settings-view.tsx) для показа warning'а, если
// email-уведомления недоступны на сервере. Не требует авторизации — это
// публичная конфигурационная информация (без раскрытия SMTP-учёток).
import { NextRequest } from 'next/server';
import { json } from '@/lib/api-helpers';
import { isSmtpConfigured } from '@/lib/services/email-service';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest) {
  return json({
    smtpConfigured: isSmtpConfigured(),
    // emailNotificationsEnabled — это per-user настройка, её клиент берёт из /api/auth/me
  });
}
