// DAO API — список proposals + создание
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const status = req.nextUrl.searchParams.get('status') ?? 'active';
  const proposals = await db.daoProposal.findMany({
    where: status === 'all' ? {} : { status },
    orderBy: { createdAt: 'desc' },
    take: 30,
    include: {
      proposer: { select: { id: true, name: true, avatarUrl: true, ipScore: true } },
      _count: { select: { votes: true } },
      votes: { where: { voterId: user.id }, select: { id: true, vote: true } },
    },
  });

  return json({
    proposals: proposals.map(p => ({
      ...p,
      myVote: p.votes[0]?.vote ?? null,
      totalVotes: p._count.votes,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только IP-score 31+ могут создавать proposals (Trust-Adaptive)
  if (user.ipScore < 31) {
    return errorJson('Требуется IP-score 31+ для создания предложений', 403);
  }

  try {
    const { title, description, type, durationDays } = await req.json();
    if (!title || !description) return errorJson('title и description обязательны', 422);

    const endDate = new Date(Date.now() + (durationDays ?? 7) * 24 * 60 * 60 * 1000);

    const proposal = await db.daoProposal.create({
      data: {
        title,
        description,
        type: type ?? 'governance',
        proposerId: user.id,
        endDate,
        minIpScore: 31,
      },
    });

    return json({ proposal }, 201);
  } catch (e) {
    return errorJson('Ошибка', 500);
  }
}
