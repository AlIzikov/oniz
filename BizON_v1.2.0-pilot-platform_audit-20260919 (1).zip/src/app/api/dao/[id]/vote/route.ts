// DAO Vote API — голосовать (вес = IP-score)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  try {
    const { vote } = await req.json();
    if (!['for', 'against', 'abstain'].includes(vote)) {
      return errorJson('vote: for | against | abstain', 422);
    }

    const proposal = await db.daoProposal.findUnique({ where: { id } });
    if (!proposal) return errorJson('Предложение не найдено', 404);
    if (proposal.status !== 'active') return errorJson('Голосование завершено', 400);
    if (proposal.endDate < new Date()) return errorJson('Срок истёк', 400);

    // Trust-Adaptive: минимальный IP-score
    if (user.ipScore < proposal.minIpScore) {
      return errorJson(`Требуется IP-score ${proposal.minIpScore}+. Ваш: ${user.ipScore}`, 403);
    }

    // Проверяем — не голосовал ли уже
    const existing = await db.daoVote.findUnique({
      where: { proposalId_voterId: { proposalId: id, voterId: user.id } },
    }).catch(() => null);
    if (existing) return errorJson('Вы уже голосовали', 400);

    // Создаём голос (вес = IP-score голосующего — уникальная фича!)
    const voteRecord = await db.daoVote.create({
      data: {
        proposalId: id,
        voterId: user.id,
        vote,
        weight: user.ipScore,
      },
    });

    // Обновляем счётчики
    const field = vote === 'for' ? 'forVotes' : vote === 'against' ? 'againstVotes' : 'abstainVotes';
    await db.daoProposal.update({
      where: { id },
      data: { [field]: { increment: user.ipScore } },
    });

    return json({ vote: voteRecord, weight: user.ipScore }, 201);
  } catch (e) {
    return errorJson('Ошибка', 500);
  }
}
