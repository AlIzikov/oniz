// BizON API — /api/wallet/transfer (DEPRECATED)
// Этап 8.1 (T) — Trust ≠ Currency.
//
// Раньше в ТЗ фигурировала концепция «tTRUST» как передаваемой валюты доверия.
// Этап 8.1 явно фиксирует: trust — это ВНУТРЕННЕЕ состояние, не валюта.
// Поэтому любой endpoint, пытающийся «перевести trust» между аккаунтами,
// должен вернуть 410 Gone (Permanently Removed).
//
// Этот route намеренно ловит ВСЕ HTTP-методы — чтобы старые клиенты,
// пытающиеся POST/GET здесь transfer, получили единый deprecated-ответ.

import { NextRequest } from 'next/server';
import { json } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const DEPRECATED_BODY = {
  error: 'Gone',
  code: 'TRUST_NOT_CURRENCY',
  message:
    'Trust — это внутреннее состояние пользователя, не валюта. ' +
    'Передача/продажа trust между аккаунтами невозможна и не планируется. ' +
    'Используйте GET /api/me/trust-state для просмотра своего состояния доверия.',
  deprecatedAt: '2025-01-01',
  alternative: '/api/me/trust-state',
};

const GONE_INIT: ResponseInit = { headers: { 'Cache-Control': 'no-store' } };

export async function GET(_req: NextRequest) {
  return json(DEPRECATED_BODY, 410, GONE_INIT);
}

export async function POST(_req: NextRequest) {
  return json(DEPRECATED_BODY, 410, GONE_INIT);
}

export async function PUT(_req: NextRequest) {
  return json(DEPRECATED_BODY, 410, GONE_INIT);
}

// fix-adversarial (ADV-C107): стаб обязан покрывать ВСЕ методы — иначе PATCH
// отдаёт 405 вместо контракта 410 TRUST_NOT_CURRENCY.
export async function PATCH(_req: NextRequest) {
  return json(DEPRECATED_BODY, 410, GONE_INIT);
}

export async function DELETE(_req: NextRequest) {
  return json(DEPRECATED_BODY, 410, GONE_INIT);
}
