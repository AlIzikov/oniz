// BizON API — Дни рождения среди принятых контактов
// GET: { today: [...], thisMonth: [...] } — честные данные из User.birthday
// (контакт без birthday в списки не попадает — никаких выдуманных дат).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

interface BirthdayFriend {
  userId: string;
  name: string;
  title: string | null;
  company: string | null;
  avatarUrl: string | null;
  birthday: string;
  month: number;
  day: number;
  isToday: boolean;
  daysLeft: number;
}

/** Сколько дней до следующего наступления (month, day). 0 = сегодня. */
function daysLeftFor(month: number, day: number, now: Date): number {
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const thisYear = new Date(now.getFullYear(), month - 1, day);
  const diff = Math.round((thisYear.getTime() - todayStart.getTime()) / 86_400_000);
  if (diff >= 0) return diff;
  const nextYear = new Date(now.getFullYear() + 1, month - 1, day);
  return Math.round((nextYear.getTime() - todayStart.getTime()) / 86_400_000);
}

/** Название компании: связь аккаунта компании (User.company) или текущее подтверждённое место работы (Employee). */
function resolveCompanyName(u: {
  company?: { name: string } | null;
  employments?: Array<{ company: { name: string } }>;
}): string | null {
  if (u.company?.name) return u.company.name;
  const current = u.employments?.[0]?.company?.name;
  return current ?? null;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'network:birthdays', 60, 60_000);
  if (!rl.allowed) return errorJson('Слишком много запросов, попробуйте позже', 429);

  const connections = await db.connection.findMany({
    where: {
      OR: [{ fromUserId: user.id }, { toUserId: user.id }],
      status: 'accepted',
    },
    include: {
      fromUser: {
        select: {
          id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, birthday: true,
          company: { select: { name: true } },
          employments: { where: { isCurrent: true }, take: 1, select: { company: { select: { name: true } } } },
        },
      },
      toUser: {
        select: {
          id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, birthday: true,
          company: { select: { name: true } },
          employments: { where: { isCurrent: true }, take: 1, select: { company: { select: { name: true } } } },
        },
      },
    },
  });

  const now = new Date();
  const todayMonth = now.getMonth() + 1; // 1..12
  const todayDay = now.getDate(); // 1..31

  const friends: BirthdayFriend[] = [];
  for (const c of connections) {
    const other = c.fromUserId === user.id ? c.toUser : c.fromUser;
    if (!other.birthday) continue; // честность: без даты — не попадает в списки

    const month = other.birthday.getMonth() + 1;
    const day = other.birthday.getDate();
    const isToday = month === todayMonth && day === todayDay;

    friends.push({
      userId: other.id,
      name: other.name,
      title: other.title,
      company: resolveCompanyName(other),
      avatarUrl: other.avatarUrl,
      birthday: other.birthday.toISOString(),
      month,
      day,
      isToday,
      daysLeft: daysLeftFor(month, day, now),
    });
  }

  // thisMonth: месяц совпадает с текущим, сортировка по дню (today с day=todayDay — естественно первый)
  const thisMonth = friends
    .filter((f) => f.month === todayMonth)
    .sort((a, b) => a.day - b.day || a.name.localeCompare(b.name));

  // today: только сегодняшние
  const today = friends.filter((f) => f.isToday);

  return json({ today, thisMonth, total: friends.length, checkedAt: now.toISOString() });
}
