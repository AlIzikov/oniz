// Trust Graph API — граф доверия пользователя
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Получаем прямые связи пользователя
  const connections = await db.connection.findMany({
    where: { OR: [{ fromUserId: user.id }, { toUserId: user.id }], status: 'accepted' },
    include: {
      fromUser: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true } },
      toUser: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true } },
    },
    take: 50,
  });

  // Формируем узлы и связи
  const nodes: any[] = [{ id: user.id, name: user.name, title: user.title, avatarUrl: user.avatarUrl, ipScore: user.ipScore, isCenter: true }];
  const edges: any[] = [];
  const seen = new Set<string>([user.id]);

  for (const c of connections) {
    const other = c.fromUserId === user.id ? c.toUser : c.fromUser;
    if (!seen.has(other.id)) {
      seen.add(other.id);
      nodes.push({ id: other.id, name: other.name, title: other.title, avatarUrl: other.avatarUrl, ipScore: other.ipScore, isCenter: false });
    }
    edges.push({ from: user.id, to: other.id, weight: 1 });
  }

  // Получаем связи между связями (2-hop) для богатого графа
  const connectionIds = Array.from(seen).filter(id => id !== user.id);
  if (connectionIds.length > 0) {
    const secondHop = await db.connection.findMany({
      where: {
        OR: [
          { fromUserId: { in: connectionIds }, toUserId: { in: connectionIds } },
        ],
        status: 'accepted',
      },
      take: 30,
    });
    for (const e of secondHop) {
      if (e.fromUserId !== e.toUserId) {
        edges.push({ from: e.fromUserId, to: e.toUserId, weight: 0.5 });
      }
    }
  }

  return json({ nodes, edges: edges.filter(e => e.from !== e.to) });
}
