// BizON API — GET /api/ai/governance/status (W3.3)
// Статус governance-контура для владельца/оператора:
// агенты и их статусы, kill-switch, счётчики действий.
// PATCH — управление: pause/resume агента, global kill (без участия AI).
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

async function requireAdmin(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return { error: errorJson('Не авторизован', 401) as Response } as const;
  const roles = (user.roles ?? '').split(',').map((r) => r.trim().toLowerCase());
  const isAdmin =
    roles.includes('admin') ||
    roles.includes('administrator') ||
    roles.includes('owner') ||
    user.id === 'cmtlwo7cr000ome6uscm1ipkt'; // владелец-демо
  if (!isAdmin) return { error: errorJson('Только оператор платформы', 403) as Response } as const;
  return { user } as const;
}

export async function GET(req: NextRequest) {
  const guard = await requireAdmin(req);
  if ('error' in guard) return guard.error;

  const agents = await db.aiAgent.findMany({ orderBy: { key: 'asc' } });
  const [actionsTotal, pendingApprovals, blocked, incidents] = await Promise.all([
    db.aiAction.count(),
    db.aiApproval.count({ where: { status: 'pending' } }),
    db.aiAction.count({ where: { status: 'policy_blocked' } }),
    db.aiIncident.count({ where: { status: 'open' } }),
  ]);
  return json({
    // D2 (Agent 7): честная витрина — персистентная политика, а не только env
    globalKill: await GovernanceService.isAutonomyKilled(),
    agents: agents.map((a) => ({
      key: a.key, name: a.name, status: a.status, autonomyLevel: a.autonomyLevel, version: a.version,
    })),
    stats: { actionsTotal, pendingApprovals, policyBlocked: blocked, openIncidents: incidents },
  });
}

export async function PATCH(req: NextRequest) {
  const guard = await requireAdmin(req);
  if ('error' in guard) return guard.error;
  const userId = guard.user!.id;

  const body = await req.json().catch(() => null);
  const op = String((body as any)?.op ?? '');

  switch (op) {
    case 'pause_agent': {
      const key = String((body as any).agentKey ?? '');
      const ok = await GovernanceService.pauseAgent(key, userId);
      return ok ? json({ ok: true }) : errorJson('Агент не найден', 404);
    }
    case 'resume_agent': {
      const key = String((body as any).agentKey ?? '');
      const ok = await GovernanceService.resumeAgent(key, userId);
      return ok ? json({ ok: true }) : errorJson('Агент не найден или не в паузе', 404);
    }
    case 'global_kill': {
      // Честный kill: env-флаг действует только до рестарта; для персистентного
      // состояния пишем системную политику enabled=false (PolicyEngine проверяет
      // оба сигнала).
      const enable = (body as any).enable === true;
      if (!enable) {
        await db.aiPolicy.upsert({
          where: { key: 'global_autonomy' },
          create: { key: 'global_autonomy', mode: 'manual', enabled: false, rules: '{}' },
          update: { enabled: false, mode: 'manual' },
        });
      } else {
        await db.aiPolicy.upsert({
          where: { key: 'global_autonomy' },
          create: { key: 'global_autonomy', mode: 'collaborative', enabled: true, rules: '{}' },
          update: { enabled: true, mode: 'collaborative' },
        });
      }
      await GovernanceService.audit({
        event: enable ? 'governance.global_kill_released' : 'governance.global_kill_engaged',
        actorType: 'user',
        actorId: userId,
        actionKey: 'GOVERNANCE',
        status: enable ? 'active' : 'killed',
        metadata: {},
      });
      return json({ ok: true, globalKill: !enable });
    }
    default:
      return errorJson('op: pause_agent | resume_agent | global_kill', 422);
  }
}
