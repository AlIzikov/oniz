// BizON API — PATCH /api/ai/autonomy (Wave 6, S-137/S-138).
// IL-слайдер автономии 0..4: гейты по тиру (basic→1, verified→3, pro/business→4),
// HOP anti-creeping: повышение — только явным действием пользователя (сессия),
// вызов с caller=agent невозможен по построению (роут всегда user-сессия).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { GovernanceService } from '@/lib/ai-governance/governance-service';

export const runtime = 'nodejs';

const schema = z.object({ level: z.number().int().min(0).max(4) });

export const GET = withRoute(async (req, ctx) => {
  const state = await GovernanceService.getAutonomy(ctx.user.id);
  return NextResponse.json(state);
});

export const PATCH = withRoute(async (req, ctx) => {
  const input = schema.parse(ctx.data);
  const result = await GovernanceService.setAutonomyLevel(ctx.user.id, input.level, 'user');
  // Найдено E2E: контракт setAutonomyLevel = { ok, level } — прежний
  // NextResponse.json(result.data) сериализовал undefined → 500.
  if (result.ok) return NextResponse.json({ ok: true, level: result.level });
  return NextResponse.json(
    { error: result.message, code: result.code },
    { status: result.httpStatus ?? 400 },
  );
}, {
  rateLimit: { key: 'ai-autonomy-patch', limit: 20, windowMs: 60 * 60 * 1000 },
});
