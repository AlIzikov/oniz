// BizON API — /api/ai/career (LLM карьерный агент)
// H12: rate limit по тарифу (free: 5/ч, pro: 50/ч, business: 500/ч)
// Волна 14: Free — 1 люмен за запуск (клик активации); Pro/Business — безлимит.
// FIX-07: withRoute — auth 401, единый маппинг ошибок; сырой e.message для 5xx не возвращается.
import { db } from '@/lib/db';
import { json, errorJson, toUserPublic, withRoute } from '@/lib/api-helpers';
import { runCareerAgent, computeJobMatch } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';
import { LumenService } from '@/lib/services/lumen-service';

export const runtime = 'nodejs';

export const POST = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  // H12: AI rate limit по тарифу — защита от LLM-billing DoS
  const [max, windowMs] = getAiLimitKey('career', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:career', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит AI-Career-Agent исчерпан (${max} запросов в час для тарифа ${user.subscriptionTier}). Повторите через ${rl.retryAfter} секунд.`,
      429
    );
  }

  // === Волна 14: ИИ-действия за люмены ===
  // Free: 1 люмен за запуск. Списание атомарное; при ошибке ИИ — возврат.
  const spend = user.subscriptionTier === 'free'
    ? await LumenService.spend(user.id, 'career_agent')
    : null;
  if (spend && !spend.ok) {
    if (spend.code === 'insufficient') {
      return json(
        {
          error: `Недостаточно люменов: нужно ${spend.need}, есть ${spend.have}. Пополните кошелёк — 1 ₽ = 1 люмен.`,
          need: spend.need,
          have: spend.have,
        },
        402
      );
    }
    return errorJson('Неизвестное ИИ-действие', 422);
  }

  try {
    // Загружаем релевантные вакансии
    const userSkills = await db.userSkill.findMany({
      where: { userId: user.id },
      include: { skill: true },
    });

    const userSkillNames = userSkills.map((us) => us.skill.name);

    const jobs = await db.job.findMany({ where: { active: true }, take: 50 });
    const ranked = jobs
      .map((j) => {
        const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
        const match = computeJobMatch(userSkillNames, user.ipScore, {
          requiredSkills,
          growthScore: j.growthScore,
        });
        return {
          id: j.id,
          title: j.title,
          company: j.company,
          description: j.description,
          requiredSkills,
          salaryFrom: j.salaryFrom,
          salaryTo: j.salaryTo,
          location: j.location,
          growthScore: j.growthScore,
          matchConfidence: match,
          createdAt: j.createdAt.toISOString(),
        };
      })
      .sort((a, b) => b.matchConfidence - a.matchConfidence)
      .slice(0, 5);

    const publicUser = await toUserPublic(user);
    const enrichedUser = {
      ...publicUser,
      // добавляем навыки в объект пользователя для AI
      roles: [...publicUser.roles, ...userSkillNames.slice(0, 5)],
    };

    const result = await runCareerAgent(enrichedUser as any, ranked);
    return json(result);
  } catch (e: unknown) {
    // Честность: люмен списан, но ИИ упал — возвращаем (платите за реальный ИИ)
    if (spend?.ok) {
      await LumenService.refund(user.id, 'career_agent', 'Ошибка AI-Career-Agent — люмен возвращён', spend.transactionId);
    }
    // FIX-07: пробрасываем дальше — withRoute залогирует одной строкой и вернёт
    // общий 500 без сырого e.message
    throw e;
  }
});
