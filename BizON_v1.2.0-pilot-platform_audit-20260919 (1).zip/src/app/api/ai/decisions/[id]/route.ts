// BizON API — PATCH /api/ai/decisions/[id] (W3.3, REC-GOV-05)
// Решение человека по предложенному AI-действию: approved | rejected.
// Транзакция: approval + action + AiAuditLog. Одобрение НЕ исполняет действие.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const body = await req.json().catch(() => null);
  const decision = String((body as any)?.decision ?? '');
  if (decision !== 'approved' && decision !== 'rejected') {
    return errorJson('decision должен быть approved или rejected', 422);
  }
  const reason = typeof (body as any)?.reason === 'string' ? (body as any).reason : undefined;

  const res = await GovernanceService.decideAction({
    actionId: id,
    userId: user.id,
    decision,
    reason,
  });
  if (!res.ok) {
    const status =
      res.code === 'NOT_FOUND' ? 404
      : res.code === 'FORBIDDEN' ? 403
      : res.code === 'ALREADY_DECIDED' || res.code === 'EXPIRED' ? 409
      : 500;
    return errorJson(res.message, status);
  }

  return json({ ok: true, status: res.status, message: 'Решение зафиксировано (действие не исполнено — executor отдельный контур)' });
}
