// BizON API — GET /api/ai/decisions (W3.3, REC-GOV-04)
// Decision Inbox: список действий, ожидающих решения человека.
// ВАЖНО: inbox НЕ исполняет действия (safety property, мастер-задание §38).
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { GovernanceService } from '@/lib/ai-governance';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const decisions = await GovernanceService.listPendingDecisions(user.id);
  const autonomy = await GovernanceService.getAutonomy(user.id);
  return json({ decisions, autonomy });
}
