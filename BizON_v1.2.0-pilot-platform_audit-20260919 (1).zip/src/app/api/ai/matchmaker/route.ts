// BizON API — /api/ai/matchmaker (5 рукопожатий)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { findMatch } from '@/lib/matchmaker';
import { ReputationService } from '@/lib/services';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { toUserId } = body ?? {};
    if (!toUserId) return errorJson('toUserId обязателен', 422);

    const target = await db.user.findUnique({ where: { id: toUserId } });
    if (!target) return errorJson('Целевой пользователь не найден', 404);
    if (toUserId === user.id) return errorJson('Нельзя искать путь к самому себе', 400);

    const result = await findMatch(user.id, toUserId);

    if (result.found) {
      // FIX-06: reputation event + пересчёт IP-score одной пачкой (awardBulk)
      await ReputationService.awardBulk({
        userIds: [user.id],
        eventType: 'intro_sent',
        weight: 1,
        payload: {
          to: target.name,
          toId: target.id,
          pathLength: result.path.length,
          confidence: result.confidence,
        },
      });
    }

    return json(result);
  } catch (e) {
    console.error('[ai/matchmaker] error:', e);
    return errorJson('Ошибка AI-Matchmaker', 500);
  }
}
