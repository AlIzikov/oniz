// BizON API — /api/workforce/overview (doc_a §35, Task 9-g)
// ============================================================================
// Полная цепочка Workforce Intelligence одним ответом:
//   Company demand → Current workforce → Skill gap → Training → Mentoring →
//   → Talent pipeline
//
// GET ?companyId=...   (по умолчанию User.companyId)
//
// Доступ: только company | hr_agency (individual → 403). Аккаунт с привязкой
// к companyId не может смотреть чужую компанию; явный companyId разрешён
// только аккаунтам без привязки (sandbox-реальность demo-аккаунтов).
//
// Аддитивно к существующему /api/companies/[id]/workforce-gap (не меняется):
// этот роут добавляет Training (Course/UserCourse × gap), Mentoring
// (Mentorship + пары «наставник-ментируемый») и Pipeline (воронка
// source→screen→interview→offer→hired по JobApplication + Placement).
// Для hr_agency дополнительно возвращается outreach-статистика HrContact.

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';
import { WorkforceService } from '@/lib/services/workforce-service';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'workforce:overview', 30, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter}с`, 429);

  if (user.accountType !== 'company' && user.accountType !== 'hr_agency') {
    return errorJson('Workforce Intelligence доступен только компаниям и HR-агентствам', 403);
  }

  const url = new URL(req.url);
  const explicitCompanyId = url.searchParams.get('companyId');
  let companyId: string | null = null;

  if (user.companyId) {
    if (explicitCompanyId && explicitCompanyId !== user.companyId) {
      return errorJson('Доступ запрещён: нельзя смотреть workforce чужой компании', 403);
    }
    companyId = user.companyId;
  } else {
    // Sandbox: company/hr_agency-аккаунты без привязки указывают companyId явно.
    companyId = explicitCompanyId;
  }

  if (!companyId) {
    return json({
      companyId: null,
      generatedAt: new Date().toISOString(),
      chain: ['demand', 'gap', 'training', 'mentoring', 'pipeline'],
      demand: { activeJobs: 0, gapSkills: 0, criticalGaps: 0 },
      gap: [],
      training: {
        recommendations: [],
        employeeEnrollments: [],
        catalogSize: 0,
        note: 'Компания не привязана к аккаунту и companyId не указан — укажите ?companyId=... (пустое состояние).',
      },
      mentoring: {
        activeMentorships: [],
        recommendations: [],
        note: 'Компания не привязана к аккаунту и companyId не указан — укажите ?companyId=... (пустое состояние).',
      },
      pipeline: null,
      hrAgencyOutreach: null,
    });
  }

  const company = await db.company.findUnique({ where: { id: companyId }, select: { id: true, name: true } });
  if (!company) return errorJson('Компания не найдена', 404);

  const overview = await WorkforceService.getOverview(companyId);

  // HR-агентства дополнительно видят свою outreach-статистику (HrContact:
  // лимит 1 контакт/неделю на кандидата — Privacy Shield)
  let hrAgencyOutreach: { total: number; active: number; blocked: number } | null = null;
  if (user.accountType === 'hr_agency') {
    const contacts = await db.hrContact.groupBy({
      by: ['status'],
      where: { hrAgencyId: user.id },
      _count: { id: true },
    });
    const total = contacts.reduce((a, c) => a + c._count.id, 0);
    hrAgencyOutreach = {
      total,
      active: contacts.find((c) => c.status === 'active')?._count.id ?? 0,
      blocked: contacts.find((c) => c.status === 'blocked')?._count.id ?? 0,
    };
  }

  return json({ ...overview, companyName: company.name, hrAgencyOutreach });
}
