// BizON API — /api/communities/[slug]
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CommunityService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const community = await CommunityService.getBySlug(slug, user.id);
  if (!community) return errorJson('Сообщество не найдено', 404);
  return json({ community });
}
