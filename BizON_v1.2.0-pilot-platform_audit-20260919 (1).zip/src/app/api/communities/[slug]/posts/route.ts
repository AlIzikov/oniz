// BizON API — /api/communities/[slug]/posts
// FIX-07: withRoute — auth 401, zod-схема createCommunityPostBySlug (whitelist,
// content ≤5000, strip), единый маппинг ошибок; бизнес-ошибки сервиса теперь
// BizonError (ForbiddenError/NotFoundError) — сырой e.message больше не утекает.
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { CommunityService } from '@/lib/services';
import { schemas } from '@/lib/validation';

export const runtime = 'nodejs';

export const POST = withRoute<{ slug: string }>(
  async (req, ctx) => {
    const { slug } = ctx.params;
    const user = ctx.user!;
    const { content, tags } = ctx.data as { content: string; tags?: string[] };

    const community = await CommunityService.getBySlug(slug, user.id);
    if (!community) return errorJson('Сообщество не найдено', 404);
    const post = await CommunityService.createPost(community.id, user.id, content, tags ?? []);
    return json({ post }, 201);
  },
  { schema: schemas.createCommunityPostBySlug },
);
