// BizON API — /api/communities/[slug]/join
// FIX-07: withRoute — auth 401, единый маппинг ошибок; бизнес-ошибки
// CommunityService теперь BizonError (404/403/409) — без сырых e.message.
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { CommunityService } from '@/lib/services';

export const runtime = 'nodejs';

export const POST = withRoute<{ slug: string }>(async (req, ctx) => {
  const { slug } = ctx.params;
  const user = ctx.user!;

  // Get community by slug first
  const community = await CommunityService.getBySlug(slug, user.id);
  if (!community) return errorJson('Сообщество не найдено', 404);
  const result = await CommunityService.join(community.id, user.id, user.ipScore);
  return json(result);
});

export const DELETE = withRoute<{ slug: string }>(async (req, ctx) => {
  const { slug } = ctx.params;
  const user = ctx.user!;

  const community = await CommunityService.getBySlug(slug, user.id);
  if (!community) return errorJson('Сообщество не найдено', 404);
  const result = await CommunityService.leave(community.id, user.id);
  return json(result);
});
