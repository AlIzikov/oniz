// BizON API — /api/communities
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CommunityService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const category = req.nextUrl.searchParams.get('category') ?? undefined;
  const communities = await CommunityService.list(user.id, category);
  return json({ communities });
}
