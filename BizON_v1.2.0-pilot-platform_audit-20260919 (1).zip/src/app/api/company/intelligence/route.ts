// BizON API — GET /api/company/intelligence (v6.2, Task 9-b, doc_a §31, §33)
//
// «Память компании» (Company Intelligence):
//   • trustSignals      — сигналы доверия (верификации, claims, отзывы, культура)
//   • currentNeeds      — текущие потребности (открытые вакансии Job + топ навыков)
//   • competencyMemory  — какие компетенции накоплены / технологии появляются/исчезают
//   • timeline          — таймлайн событий компании (news/job/review/cultural/claim/placement/employee)
//
// Query: companyId=<id существующей компании> (обязателен)
// Детерминированно, без LLM. Честные empty states при отсутствии данных.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { CompanyIntelligenceService } from '@/lib/services/company-intelligence-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'company:intelligence', 60, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);

  const companyId = req.nextUrl.searchParams.get('companyId');
  if (!companyId) return errorJson('companyId обязателен: /api/company/intelligence?companyId=<id>', 422);

  try {
    const intelligence = await CompanyIntelligenceService.getIntelligence(companyId);
    if (!intelligence) return errorJson('Компания не найдена', 404);
    return json(intelligence);
  } catch (e: unknown) {
    console.error('[api/company/intelligence GET] error:', e);
    return errorJson('Ошибка сборки памяти компании. Попробуйте позже.', 500);
  }
}
