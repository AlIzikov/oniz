// BizON API — /api/lumens (волна 14, монетизация)
// GET — состояние кошелька люменов.
//
// При каждом чтении автоматически начисляются дивиденды (15% годовых,
// люменами) за реально прошедшее время — начисление это реальный процесс,
// а не ручная кнопка. Возвращает баланс, базу (внесённые ₽), проекции
// дивидендов, каталог ИИ-действий за люмены и последние 25 операций.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { LumenService } from '@/lib/services/lumen-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // W1.8: лимит на чтение кошелька — чтение производит начисление дивидендов
  // (запись), поэтому без лимита возможна накрутка вызовов
  const rl = checkUserRateLimit(user.id, 'lumens:wallet', 30, 60_000);
  if (!rl.allowed) {
    return errorJson(`Слишком часто. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const wallet = await LumenService.getWallet(user.id);
  if (!wallet) return errorJson('Профиль не найден', 404);

  return json(wallet);
}
