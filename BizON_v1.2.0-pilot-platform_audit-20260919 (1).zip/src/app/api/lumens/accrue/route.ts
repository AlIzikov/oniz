// BizON API — /api/lumens/accrue (волна 14, монетизация)
// POST — демо-ускорение дивидендов: начисляет как за 30 дней.
//
// В проде дивиденды (15% годовых) начисляются реальным временем при
// каждом чтении кошелька. Кнопка «как за месяц» — честно помеченное
// демо-ускорение, чтобы механику было видно без ожидания месяца.
// Кредитуются только целые люмены; дробный остаток копится и не сгорает.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { LumenService } from '@/lib/services/lumen-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'lumens:accrue', 10, 60_000);
  if (!rl.allowed) {
    return errorJson(`Слишком часто. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const result = await LumenService.accrueDemoMonth(user.id);
  if (!result.ok) return errorJson(result.error, 422);

  return json({
    ok: true,
    credited: result.credited,
    pendingFraction: result.pendingFraction,
    note: 'Демо-ускорение: начислено как за 30 дней по ставке 15% годовых. В проде — реальное время.',
  });
}
