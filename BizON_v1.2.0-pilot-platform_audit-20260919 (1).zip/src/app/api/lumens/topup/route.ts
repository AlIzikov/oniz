// BizON API — /api/lumens/topup (волна 14, монетизация)
// POST { amount: 100|300|500|1000 } — пополнение кошелька.
//
// Курс 1 ₽ = 1 люмен. Демо-шлюз: реальные деньги НЕ списываются —
// это песочница, что честно указано в ответе и в UI.
// Новая внесённая сумма добавляется к базе дивидендов (15% годовых).
// FIX-07: withRoute — auth 401, zod-схема lumensTopup (amount — целое число, strip),
// rate limit, единый маппинг ошибок; без сырых e.message для 5xx.
// FIX-08: гейт «только реальные данные» — пополнение доступно только
// пользователям с подтверждённым email (403 EMAIL_NOT_VERIFIED).
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { LumenService } from '@/lib/services/lumen-service';

export const runtime = 'nodejs';

const HONEST_NOTE =
  'Демо-шлюз: реальные деньги не списываются. В проде — YooKassa/CloudPayments через ExternalGatewayAdapter.';

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const { amount } = ctx.data as { amount: number };

    // FIX-08: до реальных платежей email обязан быть подтверждён
    // (письмо с одноразовой ссылкой /api/auth/verify-email).
    if (!user.emailVerified) {
      return json(
        { error: 'Подтвердите email, чтобы пополнять баланс', code: 'EMAIL_NOT_VERIFIED' },
        403,
      );
    }

    const result = await LumenService.topup(user.id, amount);
    if (!result.ok) return errorJson(result.error, 422);

    return json({
      ok: true,
      balance: result.balance,
      rublesDeposited: result.rublesDeposited,
      credited: amount,
      note: HONEST_NOTE,
    });
  },
  {
    schema: schemas.lumensTopup,
    rateLimit: { key: 'lumens:topup', limit: 20, windowMs: 60_000 },
  },
);
