// BizON API — GET /api/market/intelligence (v6.2, Task 9-b, doc_a §17)
//
// Единый снапшот рынка «BIZON Market Intelligence»:
//   • demandBySkills  — спрос по навыкам (топ из вакансий, окна 30/30 дней)
//   • hiringDynamics  — динамика найма (вакансии по неделям + Placement + News)
//   • hotDirections   — горячие направления (отрасли/категории с ростом)
//   • segments: SIGNAL / NEWS / IMPACT / OPPORTUNITY / ACTION
//
// Детерминированно, без LLM. Персональные сегменты (OPPORTUNITY/ACTION)
// строятся для текущего авторизованного пользователя.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MarketIntelligenceService } from '@/lib/services/market-intelligence-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'market:intelligence', 30, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Повторите через ${rl.retryAfter}с`, 429);

  try {
    const snapshot = await MarketIntelligenceService.getSnapshot(user.id);
    return json(snapshot);
  } catch (e: unknown) {
    console.error('[api/market/intelligence GET] error:', e);
    return errorJson('Ошибка сборки снапшота рынка. Попробуйте позже.', 500);
  }
}
