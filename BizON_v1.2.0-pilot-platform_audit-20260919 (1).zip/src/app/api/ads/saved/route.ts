// BizON API — /api/ads/saved (Избранные объявления пользователя)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const saved = await db.savedAd.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: { ad: true },
  });

  return json({
    ads: saved.map(s => ({
      id: s.ad.id,
      title: s.ad.title,
      content: s.ad.content,
      imageUrl: s.ad.imageUrl,
      adTrustIndex: s.ad.adTrustIndex,
      moderationScore: s.ad.moderationScore,
      savedAt: s.createdAt.toISOString(),
      createdAt: s.ad.createdAt.toISOString(),
    })),
    total: saved.length,
  });
}
