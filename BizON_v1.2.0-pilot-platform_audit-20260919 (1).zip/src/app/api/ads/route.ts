// BizON API — /api/ads (AI-Ad-Moderator stub)
// Возвращает релевантное рекламное объявление для пользователя
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isUrlSafeForStorage } from '@/lib/security/ssrf';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Подбираем广告 под уровень доверия пользователя
  const segment = user.level; // basic | extended | expert
  const candidates = await db.ad.findMany({
    where: {
      active: true,
      moderationScore: { gte: 0.7 },
      OR: [
        { targetTrustSegment: 'all' },
        { targetTrustSegment: segment },
      ],
    },
    take: 5,
    orderBy: { adTrustIndex: 'desc' },
  });

  if (candidates.length === 0) return json({ ad: null });

  // Случайный выбор из топ-3
  const top = candidates.slice(0, 3);
  const ad = top[Math.floor(Math.random() * top.length)];

  // Фиксируем показ
  await db.adImpression.create({
    data: { adId: ad.id, userId: user.id, clicked: false },
  });

  return json({
    ad: {
      id: ad.id,
      title: ad.title,
      content: ad.content,
      imageUrl: ad.imageUrl,
      adTrustIndex: ad.adTrustIndex,
      moderationScore: ad.moderationScore,
      sponsor: 'BizON Ads Network',
      // W2.4 (DEF-14): outbound-цель; отдаётся только если проходит SSRF-проверку
      targetUrl: ad.targetUrl && (await isUrlSafeForStorage(ad.targetUrl)) ? ad.targetUrl : null,
    },
  });
}

// Регистрация клика
export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const body = await req.json();
  const { adId } = body ?? {};
  if (!adId) return errorJson('adId обязателен', 422);

  // Обновляем последний показ пользователя как clicked
  const last = await db.adImpression.findFirst({
    where: { adId, userId: user.id },
    orderBy: { createdAt: 'desc' },
  });
  if (last) {
    await db.adImpression.update({ where: { id: last.id }, data: { clicked: true } });
  }

  // W2.4 (DEF-14): возврат валидированного outbound-URL для перехода клиента
  const ad = await db.ad.findUnique({ where: { id: adId }, select: { targetUrl: true } });
  const targetUrl =
    ad?.targetUrl && (await isUrlSafeForStorage(ad.targetUrl)) ? ad.targetUrl : null;

  return json({ ok: true, targetUrl });
}
