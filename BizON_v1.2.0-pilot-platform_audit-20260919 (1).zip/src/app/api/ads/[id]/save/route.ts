// BizON API — /api/ads/[id]/save (toggle сохранения объявления в Избранное)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id: adId } = await params;
  if (!adId) return errorJson('adId обязателен', 422);

  const existing = await db.savedAd.findUnique({
    where: { userId_adId: { userId: user.id, adId } },
  });

  if (existing) {
    await db.savedAd.delete({ where: { id: existing.id } });
    return json({ saved: false });
  }

  await db.savedAd.create({ data: { userId: user.id, adId } });
  return json({ saved: true });
}
