// BizON API — /api/sponsored/feed (Phase 13)
// GET — релевантные sponsored opportunities для текущего пользователя
// с учётом Ad Pressure Engine.
//
// Возвращает максимум 3 позиции (для UI-блока «Спонсорские возможности» в feed).
// Алгоритм:
//   1. AdPressureService.canShowAd(user.id) — если false, возвращаем пустой список.
//   2. Берём активные позиции с остатком бюджета (spent < budget), не от своей компании.
//   3. Фильтруем по targeting (skills / industries / intentTypes / locations).
//   4. Сортируем по CPM (больше платит — выше) с лёгкой рандомизацией.
//   5. Берём top-3. Не показываем повторно позиции, которые пользователь
//      уже видел > 3 раз (для разнообразия).
//   6. НЕ вызываем recordImpression здесь — это делает клиент после фактического
//      показа (POST /api/sponsored/[id]/impression). Иначе можно списать бюджет
//      за показ, который пользователь не увидел.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { AdPressureService } from '@/lib/services/ad-pressure-service';

export const runtime = 'nodejs';

interface SponsoredTargeting {
  skills?: string[];
  industries?: string[];
  intentTypes?: string[];
  locations?: string[];
}

function parseTargeting(raw: string | null | undefined): SponsoredTargeting | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as SponsoredTargeting;
  } catch {
    return null;
  }
}

/** Проверить, подходит ли пользователь под таргетинг позиции. */
function matchesTargeting(
  targeting: SponsoredTargeting | null,
  ctx: { skills: Set<string>; industry: string | null; intents: Set<string>; location: string | null },
): boolean {
  if (!targeting) return true; // нет таргетинга → показываем всем
  if (targeting.skills && targeting.skills.length > 0) {
    if (!targeting.skills.some((s) => ctx.skills.has(s))) return false;
  }
  if (targeting.industries && targeting.industries.length > 0) {
    if (!ctx.industry || !targeting.industries.includes(ctx.industry)) return false;
  }
  if (targeting.intentTypes && targeting.intentTypes.length > 0) {
    if (!targeting.intentTypes.some((t) => ctx.intents.has(t))) return false;
  }
  if (targeting.locations && targeting.locations.length > 0) {
    if (!ctx.location || !targeting.locations.includes(ctx.location)) return false;
  }
  return true;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // 1) Проверка Ad Pressure
  const pressure = await AdPressureService.canShowAd(user.id);
  if (!pressure.canShow) {
    return json({
      items: [],
      reason: pressure.reason,
      pressure: await AdPressureService.getTodayStats(user.id),
    });
  }

  // 2) Загружаем активные позиции с остатком бюджета, не от своей компании
  const all = await db.sponsoredOpportunity.findMany({
    where: {
      status: 'active',
      advertiserId: user.companyId ? { not: user.companyId } : undefined,
    },
    orderBy: [{ cpm: 'desc' }, { createdAt: 'desc' }],
    take: 30,
  });

  // 3) Фильтруем по бюджету и таргетингу
  const withBudget = all.filter((o) => o.spent < o.budget);

  // 4) Контекст пользователя для таргетинга
  const [userSkills, company, intents] = await Promise.all([
    db.userSkill.findMany({
      where: { userId: user.id },
      include: { skill: { select: { name: true } } },
    }),
    user.companyId
      ? db.company.findUnique({ where: { id: user.companyId }, select: { industry: true } })
      : Promise.resolve(null),
    db.professionalIntent.findMany({
      where: { userId: user.id, isActive: true },
      select: { type: true },
    }),
  ]);

  // Decrypt user.location for targeting. Получаем зашифрованное поле из БД.
  const userRow = await db.user.findUnique({
    where: { id: user.id },
    select: { locationEncrypted: true, location: true },
  });
  // location — уже nullable plaintext; для MVP используем как есть.
  const userLocation = userRow?.location ?? null;

  const ctx = {
    skills: new Set(userSkills.map((us) => us.skill.name.toLowerCase())),
    industry: company?.industry ?? null,
    intents: new Set(intents.map((i) => i.type)),
    location: userLocation,
  };

  const filtered = withBudget.filter((o) => {
    const targeting = parseTargeting(o.targeting);
    return matchesTargeting(targeting, ctx);
  });

  // 5) Берём top-3 с лёгкой рандомизацией внутри корзины одного CPM
  const shuffled = filtered
    .map((o) => ({ o, r: Math.random() }))
    .sort((a, b) => b.o.cpm - a.o.cpm || a.r - b.r)
    .slice(0, 3)
    .map(({ o }) => o);

  return json({
    items: shuffled.map((o) => ({
      id: o.id,
      type: o.type,
      title: o.title,
      description: o.description,
      url: o.url,
      imageUrl: o.imageUrl,
      cpm: o.cpm,
      advertiserId: o.advertiserId,
    })),
    pressure: await AdPressureService.getTodayStats(user.id),
  });
}
