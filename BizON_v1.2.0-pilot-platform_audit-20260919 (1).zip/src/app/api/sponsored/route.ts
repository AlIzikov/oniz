// BizON API — /api/sponsored (Phase 13)
// POST — создать SponsoredOpportunity (только company admin).
// GET  — список спонсорских позиций текущего рекламодателя.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';
import { validate, schemas } from '@/lib/validation';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (!user.companyId) {
    return errorJson('Только для company-аккаунтов', 403);
  }

  const items = await db.sponsoredOpportunity.findMany({
    where: { advertiserId: user.companyId },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return json({ items });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только company / hr_agency с привязанной Company могут создавать спонсорские позиции.
  if (!user.companyId) {
    return errorJson('Только для company-аккаунтов. Привяжите компанию в профиле.', 403);
  }

  // Rate limit: 10 позиций в час на компанию (через userId)
  const rl = checkUserRateLimit(user.id, 'sponsored:create', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson('Слишком много позиций. Попробуйте позже.', 429);
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return errorJson('Неверный JSON', 400);
  }

  const result = validate(schemas.createSponsoredOpportunity, body);
  if (!result.ok) {
    return errorJson(
      `Неверные данные: ${JSON.stringify(result.errors.fieldErrors)}`,
      422,
    );
  }
  const data = result.data;

  // Бюджет должен быть положительным
  if (data.budget <= 0) {
    return errorJson('Бюджет должен быть больше 0', 422);
  }

  const created = await db.sponsoredOpportunity.create({
    data: {
      advertiserId: user.companyId,
      type: data.type,
      title: data.title,
      description: data.description,
      url: data.url,
      imageUrl: data.imageUrl ?? null,
      budget: data.budget,
      cpm: data.cpm ?? 100,
      targeting: data.targeting ? JSON.stringify(data.targeting) : null,
      // status: 'pending' — премодерация. Активируется админом или автоматически
      // при высоком ATI (Company.adTrustIndex).
      status: 'pending',
    },
  });

  return json({ item: created }, 201);
}
