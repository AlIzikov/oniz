// BizON API — /api/sponsored/[id]/impression (Phase 13)
// POST — записать показ спонсорской позиции (фактический рендер в UI).
// Инкрементирует SponsoredOpportunity.impressions, спишет CPM-стоимость из
// бюджета и обновит AdPressure (adsShown++, lastAdShownAt=now()).
//
// Клиент вызывает этот эндпоинт ПОСЛЕ того, как позиция отрендерилась в viewport
// (через IntersectionObserver или аналог). Иначе можно списать бюджет за
// показ, который пользователь не увидел.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';
import { AdPressureService } from '@/lib/services/ad-pressure-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  if (!id) return errorJson('id обязателен', 422);

  // Rate limit: 30 показов/мин (защита от накрутки)
  const rl = checkUserRateLimit(user.id, 'sponsored:impression', ...MUTATION_LIMITS.adClick);
  if (!rl.allowed) {
    return errorJson('Слишком много показов. Попробуйте позже.', 429);
  }

  // Двойная проверка Ad Pressure (race-condition safety)
  const canShow = await AdPressureService.canShowAd(user.id);
  if (!canShow.canShow) {
    return json({ ok: false, reason: canShow.reason }, 429);
  }

  const opp = await db.sponsoredOpportunity.findUnique({ where: { id } });
  if (!opp) return errorJson('Позиция не найдена', 404);
  if (opp.status !== 'active') return errorJson('Позиция не активна', 409);

  await AdPressureService.recordImpression(user.id, id);

  return json({ ok: true });
}
