// BizON API — /api/sponsored/[id]/click (Phase 13)
// POST — записать клик по спонсорской позиции.
// Инкрементирует SponsoredOpportunity.clicks и AdPressure.adsClicked.
//
// Rate limit: 30 кликов/мин (MUTATION_LIMITS.adClick).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';
import { AdPressureService } from '@/lib/services/ad-pressure-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  if (!id) return errorJson('id обязателен', 422);

  // Rate limit: 30 кликов в минуту
  const rl = checkUserRateLimit(user.id, 'sponsored:click', ...MUTATION_LIMITS.adClick);
  if (!rl.allowed) {
    return errorJson('Слишком много кликов. Попробуйте позже.', 429);
  }

  // Проверяем, что позиция существует и активна
  const opp = await db.sponsoredOpportunity.findUnique({ where: { id } });
  if (!opp) return errorJson('Позиция не найдена', 404);
  if (opp.status !== 'active') return errorJson('Позиция не активна', 409);

  // Записываем клик через AdPressureService (инкремент и SponsoredOpportunity, и AdPressure)
  await AdPressureService.recordClick(user.id, id);

  return json({ ok: true, url: opp.url });
}
