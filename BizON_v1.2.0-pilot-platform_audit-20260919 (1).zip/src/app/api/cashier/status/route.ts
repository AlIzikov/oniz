// BizON API — /api/cashier/status (Виртуальная касса, решение владельца №4)
// GET — честный статус единого платёжного модуля: режим (virtual|real),
// комиссия платформы, «прилавки» (эскроу Store / пополнения / подписки)
// и состояние KYC-гейта реальных денег (docs/KYC-REAL-GATEWAY-GATE.md).
// Данных пользователей не содержит — но требует авторизации, чтобы статус
// платёжного контура не светился наружу.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { VirtualCashierService } from '@/lib/services/virtual-cashier-service';
import { CashierPortsService } from '@/lib/services/cashier-ports-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'cashier:status', 30, 60_000);
  if (!rl.allowed) {
    return errorJson(`Слишком часто. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const status = VirtualCashierService.status();
  const ports = await CashierPortsService.statusSummary();
  return json({ ...status, ports });
}
