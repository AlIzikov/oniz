// BizON API — /api/cashier/ports (Виртуальная касса, VC-2).
// Клиентская видимость портов-хаба: только активные, без внутренностей
// (тип адаптера, режим, секреты и статус готовности не выдаются).
// Клиенту достаточно знать: есть куда платить, в каких валютах/странах.
import { json } from '@/lib/api-helpers';
import { withRoute } from '@/lib/with-route';
import { CashierPortsService } from '@/lib/services/cashier-ports-service';

export const runtime = 'nodejs';

export const GET = withRoute(
  async (req, ctx) => {
    const ports = await CashierPortsService.listClientPorts();
    return json({ ports });
  },
  { rateLimit: { key: 'cashier:ports', limit: 30, windowMs: 60_000 } },
);
