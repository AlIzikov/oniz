// BizON API — /api/cashier/pay (Виртуальная касса, VC-2, Решение 5).
// ЕДИНСТВЕННЫЙ вход оплаты для клиента: «Оплатить» — без выбора кассы.
// Порт подбирается автоматически (приоритет/валюта/страна). Какая касса
// за портом — клиенту не видно. Идемпотентно по idempotencyKey.
import { z } from 'zod';
import { json } from '@/lib/api-helpers';
import { withRoute } from '@/lib/with-route';
import { CashierPortsService } from '@/lib/services/cashier-ports-service';

export const runtime = 'nodejs';

const schema = z.object({
  amount: z.number().int().min(1).max(1_000_000),
  currency: z.string().trim().toUpperCase().regex(/^[A-Z]{3}$/).optional(),
  country: z.string().trim().toUpperCase().regex(/^[A-Z]{2}$/).optional(),
  purpose: z.string().trim().min(2).max(64),
  purposeRef: z.string().trim().min(1).max(128).optional(),
  idempotencyKey: z.string().trim().min(8).max(128),
});

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const input = ctx.data as z.infer<typeof schema>;

    const result = await CashierPortsService.pay({
      userId: user.id,
      amount: input.amount,
      ...(input.currency ? { currency: input.currency } : {}),
      ...(input.country ? { country: input.country } : {}),
      purpose: input.purpose,
      ...(input.purposeRef ? { purposeRef: input.purposeRef } : {}),
      idempotencyKey: input.idempotencyKey,
    });
    return json(result);
  },
  {
    schema,
    rateLimit: { key: 'cashier:pay', limit: 20, windowMs: 60_000 },
  },
);
