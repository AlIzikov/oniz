// BizON API — /api/claims
// GPT Truth Engine (A1): список claims пользователя + создание нового claim
// Валидация: title 1-200, type ∈ ['skill','experience','achievement','role','result']
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS, getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const ALLOWED_TYPES = ['skill', 'experience', 'achievement', 'role', 'result'] as const;
type ClaimType = (typeof ALLOWED_TYPES)[number];
function isClaimType(v: unknown): v is ClaimType {
  return typeof v === 'string' && (ALLOWED_TYPES as readonly string[]).includes(v);
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const sp = req.nextUrl.searchParams;
  const status = sp.get('status') ?? undefined;
  const type = sp.get('type') ?? undefined;
  const page = Math.max(1, Number(sp.get('page') ?? 1));
  const pageSize = Math.min(100, Math.max(1, Number(sp.get('pageSize') ?? 20)));
  const skip = (page - 1) * pageSize;

  const where: { userId: string; status?: string; type?: string } = { userId: user.id };
  if (status) where.status = status;
  if (type) where.type = type;

  const [claims, total] = await Promise.all([
    db.claim.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize,
      include: { _count: { select: { verifications: true } } },
    }),
    db.claim.count({ where }),
  ]);

  return json({
    claims: claims.map((c) => ({
      id: c.id,
      type: c.type,
      title: c.title,
      description: c.description,
      status: c.status,
      projectId: c.projectId,
      skillId: c.skillId,
      verificationsCount: c._count.verifications,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    })),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'claims:create', ...MUTATION_LIMITS.eventsCreate);
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { type, title, description, projectId, skillId } = body ?? {};

    if (!isClaimType(type)) {
      return errorJson(`type должен быть одним из: ${ALLOWED_TYPES.join(', ')}`, 422);
    }
    if (typeof title !== 'string' || title.trim().length === 0 || title.length > 200) {
      return errorJson('title должен быть строкой 1-200 символов', 422);
    }
    if (description !== undefined && description !== null &&
        (typeof description !== 'string' || description.length > 5000)) {
      return errorJson('description должен быть строкой до 5000 символов', 422);
    }

    // Опциональная проверка projectId — пользователь должен быть участником
    if (projectId) {
      const membership = await db.projectMember.findUnique({
        where: { projectId_userId: { projectId, userId: user.id } },
      }).catch(() => null);
      if (!membership) {
        return errorJson('projectId должен быть проектом, в котором вы состоите', 422);
      }
    }
    // Опциональная проверка skillId — должен принадлежать пользователю
    if (skillId) {
      const us = await db.userSkill.findUnique({ where: { id: skillId } }).catch(() => null);
      if (!us || us.userId !== user.id) {
        return errorJson('skillId должен быть вашим UserSkill', 422);
      }
    }

    // fix-adversarial (ADV-C103): дедупликация — идентичный claim того же автора
    // (type+title, не отклонённый) не создаётся повторно: защита от спама
    // и «фермы верификаций» на дублях.
    const duplicate = await db.claim.findFirst({
      where: { userId: user.id, type, title: title.trim(), status: { not: 'rejected' } },
      select: { id: true },
    });
    if (duplicate) {
      return errorJson('Похожий claim уже существует', 409);
    }

    const claim = await db.claim.create({
      data: {
        userId: user.id,
        type,
        // Claim.content — обязательное поле схемы; собираем из description + title
        content: description?.trim() || title.trim(),
        title: title.trim(),
        description: description?.trim() || null,
        status: 'claimed',
        projectId: projectId ?? null,
        skillId: skillId ?? null,
      },
    });

    AuditLog.log({
      actorId: user.id,
      action: 'create',
      resource: 'claim',
      resourceId: claim.id,
      ip: getClientIP(req),
      metadata: { type, title: claim.title, projectId: projectId ?? null, skillId: skillId ?? null },
    });

    return json({ claim }, 201);
  } catch (e) {
    console.error('[claims/create] error:', e);
    return errorJson('Ошибка создания claim', 500);
  }
}
