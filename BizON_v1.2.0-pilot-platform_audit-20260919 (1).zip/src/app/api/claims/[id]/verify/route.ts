// BizON API — /api/claims/[id]/verify
// GPT Truth Engine (A1/A3): запрос подтверждения claim другим пользователем
// - Нельзя подтверждать свой claim
// - При confirm: обновить status claim → verified | project_verified | expert_verified
// - Создать уведомление владельцу + AuditLog
// SEC-7: pre-flight canConfirm + analyzeConfirmationPattern перед записью
//         fire-and-forget scoreSuspicion после действия
// FIX-07: withRoute — auth 401, zod-схема verifyClaim (whitelist), rate limit,
// единый маппинг ошибок (Prisma P2002→409, P2025→404); без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { MUTATION_LIMITS, getClientIP } from '@/lib/security/rate-limiter';
import { schemas } from '@/lib/validation';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { canConfirm, analyzeConfirmationPattern, runScoreSuspicionAsync } from '@/lib/security/anti-fraud';
import { ActionEventService } from '@/lib/services';

export const runtime = 'nodejs';

/**
 * A3: вычислить новый status claim на основе всех подтверждений
 * - 1+ confirmed → verified
 * - есть projectId + 1+ confirmed → project_verified
 * - есть role=expert + 1+ confirmed → expert_verified (высший приоритет)
 */
function computeClaimStatus(
  confirmationsCount: number,
  hasProject: boolean,
  hasExpertConfirm: boolean,
): string {
  if (confirmationsCount === 0) return 'claimed';
  if (hasExpertConfirm) return 'expert_verified';
  if (hasProject) return 'project_verified';
  return 'verified';
}

export const POST = withRoute<{ id: string }>(
  async (req, ctx) => {
    const user = ctx.user!;
    const { id } = ctx.params;
    const { status, role, comment } = ctx.data as {
      status: 'confirmed' | 'rejected';
      role: 'colleague' | 'manager' | 'client' | 'expert';
      comment?: string;
    };

    // 1. Загружаем claim
    const claim = await db.claim.findUnique({ where: { id } });
    if (!claim) return errorJson('Claim не найден', 404);

    // 2. Нельзя подтверждать свой claim
    if (claim.userId === user.id) {
      return errorJson('Нельзя подтверждать свой собственный claim', 403);
    }

    // 3. Не было ли уже верификации этим пользователем (unique [claimId, verifierId])
    const existing = await db.claimVerification.findUnique({
      where: { claimId_verifierId: { claimId: id, verifierId: user.id } },
    }).catch(() => null);
    if (existing) {
      return errorJson('Вы уже верифицировали этот claim', 400);
    }

    // 4. SEC-7: pre-flight anti-fraud check
    //    canConfirm проверяет: заморозку, бото-аккаунт, паттерн подтверждений.
    //    FAIL-OPEN: при ошибке проверка пропускается (allowed=true).
    try {
      const preFlight = await canConfirm(user.id, claim.userId);
      if (!preFlight.allowed) {
        // Логируем FRAUD_SUSPECTED для аудита
        try {
          AuditLog.logSecurity('FRAUD_SUSPECTED', {
            actorId: user.id,
            resource: 'claim',
            resourceId: id,
            ip: getClientIP(req),
            metadata: {
              targetId: claim.userId,
              score: preFlight.score,
              triggered: preFlight.triggered,
              reason: preFlight.reason,
              action: 'claims:verify',
            },
          });
        } catch {
          // fail-open
        }
        return errorJson(preFlight.reason ?? 'Подозрительная активность. Действие заблокировано.', 403);
      }
      // Параллельно запускаем анализ паттерна (non-blocking) — для раннего обнаружения
      // подозрительных пар, даже если canConfirm пропустил.
      analyzeConfirmationPattern(user.id, claim.userId).catch(() => {});
    } catch (e) {
      console.error('[claims/verify] anti-fraud pre-flight error:', e);
      // FAIL-OPEN — не блокируем легитимные действия
    }

    // 5. Создаём верификацию
    const verification = await db.claimVerification.create({
      data: {
        claimId: id,
        verifierId: user.id,
        status,
        role,
        comment: comment?.trim() || null,
      },
    });

    // 6. Если confirmed — пересчёт status claim
    let newClaimStatus = claim.status;
    if (status === 'confirmed') {
      const allVerifications = await db.claimVerification.findMany({
        where: { claimId: id },
        select: { status: true, role: true },
      });
      const confirmed = allVerifications.filter((v) => v.status === 'confirmed');
      const hasExpert = confirmed.some((v) => v.role === 'expert');
      newClaimStatus = computeClaimStatus(
        confirmed.length,
        Boolean(claim.projectId),
        hasExpert,
      );
      await db.claim.update({
        where: { id },
        data: { status: newClaimStatus },
      });

      // A6: если claim связан с skillId — обновим verificationLevel у UserSkill
      if (claim.skillId) {
        const levelMap: Record<string, string> = {
          claimed: 'claimed',
          verified: 'verified',
          project_verified: 'project_verified',
          expert_verified: 'expert_verified',
        };
        const newLevel = levelMap[newClaimStatus] ?? 'claimed';
        // Поднимаем уровень только вверх по иерархии
        const order = ['claimed', 'verified', 'project_verified', 'expert_verified'];
        const us = await db.userSkill.findUnique({ where: { id: claim.skillId } });
        if (us) {
          const curIdx = order.indexOf(us.verificationLevel);
          const newIdx = order.indexOf(newLevel);
          if (newIdx > curIdx) {
            await db.userSkill.update({
              where: { id: claim.skillId },
              data: { verificationLevel: newLevel },
            });
          }
        }
      }
    }

    // 7. Уведомление владельцу claim
    const actionText = status === 'confirmed' ? 'подтвердил' : 'опровергнул';
    const roleText = role === 'colleague' ? 'коллега' :
                     role === 'manager' ? 'руководитель' :
                     role === 'client' ? 'клиент' : 'эксперт';
    const notif = await db.notification.create({
      data: {
        userId: claim.userId,
        type: 'claim_verified',
        title: `Claim «${claim.title}» — ${actionText}`,
        content: `${roleText} ${user.name} ${actionText} ваше утверждение. Новый статус: ${newClaimStatus}.`,
        link: `/profile?claim=${claim.id}`,
      },
    }).catch((e) => {
      console.error('[claims/verify] notification error:', e);
      return null;
    });
    if (notif) notifyNotificationNew(claim.userId, notif);

    // 8. AuditLog
    AuditLog.log({
      actorId: user.id,
      action: 'verify',
      resource: 'claim',
      resourceId: id,
      ip: getClientIP(req),
      metadata: { status, role, claimOwnerId: claim.userId, newClaimStatus },
    });

    // R10: Actions Timeline — логируем подтверждение claim (только для confirmed)
    if (status === 'confirmed') {
      ActionEventService.logAction({
        userId: claim.userId,
        type: 'claim_verified',
        title: `Утверждение «${claim.title}» подтверждено`,
        description: `Новый статус: ${newClaimStatus}. Подтвердил: ${user.name} (${roleText}).`,
        metadata: {
          claimId: claim.id,
          claimType: claim.type,
          newStatus: newClaimStatus,
          verifierRole: role,
        },
      }).catch((e) => console.error('[claims/verify] actionEvent error:', e));
    }

    // 9. SEC-7: NON-BLOCKING scoreSuspicion — fire-and-forget после действия.
    //    Если score высокий → applyAutoTakedown сработает внутри.
    runScoreSuspicionAsync(user.id);

    return json({
      verification,
      claimStatus: newClaimStatus,
    }, 201);
  },
  { schema: schemas.verifyClaim, rateLimit: { key: 'claims:verify', limit: MUTATION_LIMITS.skillsConfirm[0], windowMs: MUTATION_LIMITS.skillsConfirm[1] } },
);
