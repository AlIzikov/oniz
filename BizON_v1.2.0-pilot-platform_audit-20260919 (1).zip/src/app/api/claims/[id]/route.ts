// BizON API — /api/claims/[id]
// GPT Truth Engine (A1): один claim + verifications, PATCH/DELETE (только owner, только если status=claimed)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const ALLOWED_TYPES = ['skill', 'experience', 'achievement', 'role', 'result'] as const;
function isClaimType(v: unknown): boolean {
  return typeof v === 'string' && (ALLOWED_TYPES as readonly string[]).includes(v);
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const claim = await db.claim.findUnique({
    where: { id },
    include: {
      verifications: {
        orderBy: { createdAt: 'desc' },
        include: {
          verifier: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true } },
        },
      },
    },
  });
  if (!claim) return errorJson('Claim не найден', 404);

  // Privacy: только owner видит verifiers полностью; чужие — только публичные данные
  const isOwner = claim.userId === user.id;

  return json({
    claim: {
      id: claim.id,
      userId: claim.userId,
      type: claim.type,
      title: claim.title,
      description: claim.description,
      status: claim.status,
      projectId: claim.projectId,
      skillId: claim.skillId,
      evidence: claim.evidence,
      createdAt: claim.createdAt.toISOString(),
      updatedAt: claim.updatedAt.toISOString(),
      verifications: claim.verifications.map((v) => ({
        id: v.id,
        status: v.status,
        role: v.role,
        comment: v.comment,
        createdAt: v.createdAt.toISOString(),
        verifier: isOwner
          ? v.verifier
          : { id: v.verifier.id, name: v.verifier.name, avatarUrl: v.verifier.avatarUrl, title: v.verifier.title },
      })),
    },
  });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  try {
    const claim = await db.claim.findUnique({ where: { id } });
    if (!claim) return errorJson('Claim не найден', 404);
    if (claim.userId !== user.id) return errorJson('Только владелец может редактировать claim', 403);
    // A3: редактировать можно только claim в статусе "claimed"
    if (claim.status !== 'claimed') {
      return errorJson('Нельзя редактировать claim после начала верификации', 409);
    }

    const body = await req.json();
    const { type, title, description, projectId, skillId } = body ?? {};

    const data: {
      type?: string;
      title?: string;
      description?: string | null;
      projectId?: string | null;
      skillId?: string | null;
    } = {};

    if (type !== undefined) {
      if (!isClaimType(type)) return errorJson(`type должен быть одним из: ${ALLOWED_TYPES.join(', ')}`, 422);
      data.type = type;
    }
    if (title !== undefined) {
      if (typeof title !== 'string' || title.trim().length === 0 || title.length > 200) {
        return errorJson('title должен быть строкой 1-200 символов', 422);
      }
      data.title = title.trim();
    }
    if (description !== undefined) {
      if (description !== null && (typeof description !== 'string' || description.length > 5000)) {
        return errorJson('description должен быть строкой до 5000 символов или null', 422);
      }
      data.description = description?.trim() || null;
    }
    if (projectId !== undefined) {
      if (projectId !== null) {
        const membership = await db.projectMember.findUnique({
          where: { projectId_userId: { projectId, userId: user.id } },
        }).catch(() => null);
        if (!membership) {
          return errorJson('projectId должен быть проектом, в котором вы состоите', 422);
        }
      }
      data.projectId = projectId;
    }
    if (skillId !== undefined) {
      if (skillId !== null) {
        const us = await db.userSkill.findUnique({ where: { id: skillId } }).catch(() => null);
        if (!us || us.userId !== user.id) {
          return errorJson('skillId должен быть вашим UserSkill', 422);
        }
      }
      data.skillId = skillId;
    }

    const updated = await db.claim.update({ where: { id }, data });

    AuditLog.log({
      actorId: user.id,
      action: 'update',
      resource: 'claim',
      resourceId: id,
      ip: getClientIP(req),
      metadata: { fields: Object.keys(data) },
    });

    return json({ claim: updated });
  } catch (e) {
    console.error('[claims/patch] error:', e);
    return errorJson('Ошибка обновления claim', 500);
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  try {
    const claim = await db.claim.findUnique({ where: { id } });
    if (!claim) return errorJson('Claim не найден', 404);
    if (claim.userId !== user.id) return errorJson('Только владелец может удалить claim', 403);
    if (claim.status !== 'claimed') {
      return errorJson('Нельзя удалить claim после начала верификации', 409);
    }

    await db.claim.delete({ where: { id } });

    AuditLog.log({
      actorId: user.id,
      action: 'delete',
      resource: 'claim',
      resourceId: id,
      ip: getClientIP(req),
      metadata: { title: claim.title, type: claim.type },
    });

    return json({ ok: true });
  } catch (e) {
    console.error('[claims/delete] error:', e);
    return errorJson('Ошибка удаления claim', 500);
  }
}
