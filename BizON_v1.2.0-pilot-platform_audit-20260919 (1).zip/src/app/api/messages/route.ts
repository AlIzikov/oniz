// Messages API — список диалогов + отправка
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson, withRoute } from '@/lib/api-helpers'; // FIX-07: withRoute
import { notifyChatBroadcast, notifyNotificationNew } from '@/lib/chat-notify';
import { schemas } from '@/lib/validation';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const conversations = await db.conversation.findMany({
    where: { OR: [{ fromUserId: user.id }, { toUserId: user.id }] },
    orderBy: { lastMessageAt: 'desc' },
    take: 30,
    include: {
      fromUser: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true } },
      toUser: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true } },
      messages: { orderBy: { createdAt: 'desc' }, take: 1, select: { id: true, content: true, authorId: true, createdAt: true } },
      _count: { select: { messages: { where: { isRead: false, NOT: { authorId: user.id } } } } },
    },
  });

  return json({
    conversations: conversations.map((c) => {
      const other = c.fromUserId === user.id ? c.toUser : c.fromUser;
      return {
        id: c.id,
        otherUser: other,
        lastMessage: c.messages[0] ?? null,
        unreadCount: c._count.messages,
      };
    }),
  });
}

// FIX-07: withRoute — auth 401, zod-схема createMessage (toUserId, content ≤4000, strip),
// единый маппинг ошибок; сырой e.message для 5xx больше не возвращается.
export const POST = withRoute(async (req, ctx) => {
  const user = ctx.user!;
  const { toUserId, content } = ctx.data as { toUserId: string; content: string };

  // Бизнес-лимит сообщения (жёстче schema-лимита 4000)
  if (content.length > 2000) return errorJson('Максимум 2000 символов', 422);

  // M4: проверка connection — можно писать только тем, с кем есть accepted connection,
  // ЛИBI если у отправителя IP-score >= 30 (базовый уровень доверия — анти-спам)
  // Это позволяет экспертам отправлять интро незнакомцам, но блокирует спам от новичков
  if (toUserId !== user.id) {
    const connection = await db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: user.id, toUserId, status: 'accepted' },
          { fromUserId: toUserId, toUserId: user.id, status: 'accepted' },
        ],
      },
    });

    if (!connection && user.ipScore < 30) {
      return errorJson(
        'Чтобы написать этому пользователю, установите с ним связь (connection) или повысьте свой IP-score до 30+.',
        403
      );
    }
  }

  // Находим или создаём диалог
  let conv = await db.conversation.findFirst({
    where: {
      OR: [
        { fromUserId: user.id, toUserId },
        { fromUserId: toUserId, toUserId: user.id },
      ],
    },
  });

  if (!conv) {
    conv = await db.conversation.create({ data: { fromUserId: user.id, toUserId } });
  }

  const message = await db.message.create({
    data: { conversationId: conv.id, authorId: user.id, content: content.trim() },
  });

  await db.conversation.update({ where: { id: conv.id }, data: { lastMessageAt: new Date() } });

  // Создаём уведомление
  const notif = await db.notification.create({
    data: { userId: toUserId, type: 'message', title: `Новое сообщение от ${user.name}`, content: content.trim().slice(0, 100), link: '/messages' },
  }).catch(() => null);
  if (notif) notifyNotificationNew(toUserId, notif);

  // RT (направление А): реалтайм-доставка через chat-service (fire-and-forget).
  // REST каноничен — при недоступности сервиса деградация к обновлению по действию.
  notifyChatBroadcast(conv.id, message, [user.id, toUserId]);

  return json({ message, conversationId: conv.id }, 201);
}, { schema: schemas.createMessage });
