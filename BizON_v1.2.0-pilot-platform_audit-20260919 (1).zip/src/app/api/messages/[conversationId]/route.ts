// Messages API — получить сообщения диалога + отметить прочитанными
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { notifyChatRead } from '@/lib/chat-notify';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ conversationId: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { conversationId } = await ctx.params;

  const conv = await db.conversation.findUnique({ where: { id: conversationId } });
  if (!conv || (conv.fromUserId !== user.id && conv.toUserId !== user.id)) {
    return errorJson('Диалог не найден', 404);
  }

  const messages = await db.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: 'asc' },
    take: 100,
    include: { author: { select: { id: true, name: true, avatarUrl: true } } },
  });

  // Отметить прочитанными (+ реалтайм-read-receipt автору, если что-то отмечено)
  const marked = await db.message
    .updateMany({
      where: { conversationId, isRead: false, NOT: { authorId: user.id } },
      data: { isRead: true },
    })
    .catch(() => ({ count: 0 }));

  if (marked.count > 0) notifyChatRead(conversationId, user.id);

  return json({ messages });
}
