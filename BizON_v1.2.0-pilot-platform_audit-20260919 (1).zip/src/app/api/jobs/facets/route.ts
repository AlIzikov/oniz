// BizON API — /api/jobs/facets (Wave 5, S-114, ТЗ 4.3 API-01).
// Фильтры 10 секций с фактическими агрегациями-счётчиками (facet-паттерн).
// Публичный read (анонимный поиск — норма ТЗ), без чисел доверия (§3.3).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { JobFiltersService } from '@/lib/services/job-filters-service';

export const runtime = 'nodejs';

const querySchema = z.object({
  q: z.string().max(200).optional(),
  employmentType: z.string().max(30).optional(),
  schedule: z.string().max(30).optional(),
  salaryMin: z.coerce.number().int().min(0).optional(),
  level: z.string().max(30).optional(),
  workFormat: z.string().max(30).optional(),
  industry: z.string().max(80).optional(),
  location: z.string().max(80).optional(),
  flags: z.string().max(120).optional(), // CSV: disability,age14,students…
  verifiedOnly: z.enum(['0', '1']).optional(),
  limit: z.coerce.number().int().min(1).max(50).optional(),
});

export const GET = withRoute(async (req, ctx) => {
  const q = querySchema.parse(ctx.data);
  const result = await JobFiltersService.search({
    q: q.q,
    employmentType: q.employmentType,
    schedule: q.schedule,
    salaryMin: q.salaryMin,
    level: q.level,
    workFormat: q.workFormat,
    industry: q.industry,
    location: q.location,
    flags: q.flags ? q.flags.split(',').map((f) => f.trim()).filter(Boolean) : undefined,
    verifiedOnly: q.verifiedOnly === '1',
  }, q.limit ?? 30);
  return NextResponse.json(result);
}, { auth: false });
