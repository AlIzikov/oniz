// BizON API — /api/jobs/analyze-url (Phase 4 — «Проверить вакансию»)
// POST { url } — проверяет: есть ли компания с таким доменом в BizON,
//               есть ли вакансия по этому URL/домену, и возвращает анализ.
//
// Возвращает:
//   {
//     found: boolean,
//     company?: { id, name, isVerified, industry, location, website, ... },
//     job?:     { id, title, companyName, salaryMin, salaryMax, ... },
//     analysis: string  — текстовое резюме для пользователя
//   }
//
// Логика:
//   1. Извлекаем домен из URL (www.example.ru → example.ru)
//   2. Ищем Company, где website содержит этот домен (case-insensitive, ILIKE)
//   3. Если компания найдена — ищем её активные вакансии
//   4. Если в URL есть идентификатор вакансии (куски пути) — пробуем exact match
//      по title или описанию
//   5. Возвращаем текстовый analysis в зависимости от найденного
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

/**
 * Безопасно извлечь домен 2-го уровня из URL.
 * Примеры:
 *   'https://www.example.ru/vacancies/123' → 'example.ru'
 *   'https://jobs.example.ru/path'          → 'example.ru'
 *   'https://EXAMPLE.com'                   → 'example.com'
 *   'example.ru'                            → 'example.ru'
 *   'не-url'                                → null
 */
function extractDomain(input: string): string | null {
  if (!input || typeof input !== 'string') return null;
  let raw = input.trim();
  if (!raw) return null;
  // Добавляем схему, если её нет, чтобы URL-конструктор не падал
  if (!/^https?:\/\//i.test(raw)) {
    raw = 'https://' + raw;
  }
  let host: string | null = null;
  try {
    const u = new URL(raw);
    host = u.hostname.toLowerCase();
  } catch {
    return null;
  }
  if (!host) return null;
  // Берём последние 2 части (example.ru, example.co.uk — упрощённо 2 части)
  const parts = host.split('.');
  if (parts.length < 2) return null;
  // Если домен 3-го уровня (jobs.example.ru) — берём последние 2
  // Для co.uk/com.au и т.п. это упрощение может дать «co.uk», но для наших
  // кейсов (российские компании) это достаточно.
  return parts.slice(-2).join('.');
}

/**
 * Извлечь «хвост» URL после домена — для поиска по title/описанию вакансии.
 * Например: /vacancies/glavnyy-inzhener-proekta → ['glavnyy', 'inzhener', 'proekta']
 */
function extractPathTokens(input: string): string[] {
  if (!input) return [];
  let raw = input.trim();
  if (!/^https?:\/\//i.test(raw)) {
    raw = 'https://' + raw;
  }
  let path: string | null = null;
  try {
    const u = new URL(raw);
    path = u.pathname;
  } catch {
    return [];
  }
  if (!path) return [];
  // Делим по не-буквенно-цифровым, фильтруем короткие токены
  return path
    .split(/[^a-zа-яё0-9]+/i)
    .map((t) => t.toLowerCase())
    .filter((t) => t.length >= 4);
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    return errorJson('Тело запроса должно быть JSON', 400);
  }
  const url = typeof body?.url === 'string' ? body.url.trim() : '';
  if (!url) {
    return errorJson('url обязателен', 422);
  }
  if (url.length > 2000) {
    return errorJson('url слишком длинный', 422);
  }

  const domain = extractDomain(url);
  if (!domain) {
    return json({
      found: false,
      analysis: 'Не удалось распознать домен из URL. Проверьте ссылку.',
    });
  }

  // ========================================================================
  // 1. Ищем Company с website, содержащим этот домен.
  //    SQLite (Prisma): contains уже case-insensitive (mode='insensitive'
  //    не поддерживается SQLite — Prisma его просто игнорирует бы).
  // ========================================================================
  const companies = await db.company.findMany({
    where: {
      OR: [
        { website: { contains: domain } },
        { name: { contains: domain.split('.')[0] } },
      ],
    },
    select: {
      id: true,
      name: true,
      isVerified: true,
      industry: true,
      location: true,
      website: true,
      size: true,
      description: true,
      employerTrust: true,
      businessTrust: true,
      deliveryTrust: true,
      transparency: true,
      _count: { select: { jobs: true } },
    },
    take: 5,
  });

  if (companies.length === 0) {
    return json({
      found: false,
      domain,
      analysis:
        `Компании с доменом «${domain}» нет в BizON. ` +
        'Это не значит, что вакансия недействительна — но мы не можем проверить её через наш граф доверия. ' +
        'Если вы представляете эту компанию — зарегистрируйте её на BizON, чтобы получить бейдж Verified Employer.',
    });
  }

  // Берём первую (наиболее релевантную) компанию
  const company = companies[0];

  // ========================================================================
  // 2. Ищем вакансии этой компании.
  //    Если в URL есть path-токены — пробуем найти вакансию по совпадению
  //    токенов в title (case-insensitive contains).
  // ========================================================================
  const pathTokens = extractPathTokens(url);
  const activeJobs = await db.job.findMany({
    where: { companyId: company.id, active: true },
    select: {
      id: true,
      title: true,
      company: true,
      salaryMin: true,
      salaryMax: true,
      salaryFrom: true,
      salaryTo: true,
      currency: true,
      location: true,
      createdAt: true,
      verificationStatus: true,
      vacancyTrust: true,
      requiredSkills: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 20,
  });

  // Поиск вакансии по path-токенам (если есть) — матч по 2+ совпадениям в title.
  let matchedJob: typeof activeJobs[number] | null = null;
  if (pathTokens.length > 0 && activeJobs.length > 0) {
    const titleLower = (t: string) => t.toLowerCase();
    let bestScore = 0;
    for (const j of activeJobs) {
      const t = titleLower(j.title);
      let score = 0;
      for (const tok of pathTokens) {
        if (t.includes(tok)) score++;
      }
      if (score > bestScore) {
        bestScore = score;
        matchedJob = j;
      }
    }
    // Требуем хотя бы 2 совпадения или 1 длинный токен (>=6 символов)
    if (bestScore < 2 && !(bestScore === 1 && pathTokens.some((t) => t.length >= 6))) {
      matchedJob = null;
    }
  }

  // ========================================================================
  // 3. Формируем анализ.
  // ========================================================================
  const trustAvg = Math.round(
    (company.employerTrust + company.businessTrust + company.deliveryTrust + company.transparency) / 4,
  );
  const verifiedLabel = company.isVerified ? 'Verified Employer' : 'не верифицирована';
  const parts: string[] = [];
  parts.push(
    `Найдена компания «${company.name}» (${verifiedLabel}, ` +
    `Trust: ${trustAvg}/100, ${company._count.jobs} вакансий).`,
  );

  if (matchedJob) {
    const salaryMin = matchedJob.salaryMin ?? matchedJob.salaryFrom;
    const salaryMax = matchedJob.salaryMax ?? matchedJob.salaryTo;
    const salaryStr = salaryMin && salaryMax
      ? `${salaryMin.toLocaleString('ru-RU')}–${salaryMax.toLocaleString('ru-RU')} ${matchedJob.currency ?? '₽'}`
      : 'зарплата не указана';
    const verified = matchedJob.verificationStatus === 'verified' ? '✓ Verified Vacancy' : '';
    parts.push(
      `Найдена вакансия: «${matchedJob.title}» (${salaryStr})${verified ? `, ${verified}` : ''}.`,
    );
  } else if (activeJobs.length > 0) {
    parts.push(
      `Точная вакансия не идентифицирована по URL, но у компании есть ${activeJobs.length} активных вакансий в BizON.`,
    );
  } else {
    parts.push('У компании пока нет активных вакансий в BizON.');
  }

  // Рекомендация BizON
  if (company.isVerified && trustAvg >= 50 && activeJobs.length > 0) {
    parts.push('BizON: компания проверена — можно доверять отклику через наш граф доверия.');
  } else if (!company.isVerified) {
    parts.push('BizON: компания не верифицирована — откликайтесь через BizON Profile для безопасности.');
  } else {
    parts.push('BizON: компания есть в каталоге, но индексы доверия пока низкие.');
  }

  const analysis = parts.join(' ');

  return json({
    found: true,
    domain,
    company: {
      id: company.id,
      name: company.name,
      isVerified: company.isVerified,
      industry: company.industry,
      location: company.location,
      website: company.website,
      size: company.size,
      description: company.description,
      trust: {
        employerTrust: company.employerTrust,
        businessTrust: company.businessTrust,
        deliveryTrust: company.deliveryTrust,
        transparency: company.transparency,
        overall: trustAvg,
      },
      jobsCount: company._count.jobs,
    },
    job: matchedJob
      ? {
          id: matchedJob.id,
          title: matchedJob.title,
          companyName: matchedJob.company,
          salaryMin: matchedJob.salaryMin ?? matchedJob.salaryFrom,
          salaryMax: matchedJob.salaryMax ?? matchedJob.salaryTo,
          currency: matchedJob.currency,
          location: matchedJob.location,
          createdAt: matchedJob.createdAt.toISOString(),
          verificationStatus: matchedJob.verificationStatus,
          vacancyTrust: matchedJob.vacancyTrust,
          requiredSkills: matchedJob.requiredSkills
            ? matchedJob.requiredSkills.split(',').filter(Boolean)
            : [],
        }
      : null,
    analysis,
  });
}
