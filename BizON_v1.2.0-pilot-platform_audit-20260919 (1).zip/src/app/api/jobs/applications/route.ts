// BizON API — /api/jobs/applications
// Возвращает вакансии, на которые пользователь откликнулся (для подменю "Моё → Мои отклики")
// FIX-07: withRoute — auth 401, единый маппинг ошибок (Prisma/BizonError), без сырых e.message.
import { db } from '@/lib/db';
import { json, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  const applications = await db.jobApplication.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: { job: true },
  });

  return json({
    applications: applications.map(a => ({
      id: a.id,
      status: a.status,
      matchConfidence: a.matchConfidence,
      appliedAt: a.createdAt.toISOString(),
      job: {
        id: a.job.id,
        title: a.job.title,
        company: a.job.company,
        description: a.job.description,
        requiredSkills: a.job.requiredSkills ? a.job.requiredSkills.split(',').filter(Boolean) : [],
        salaryFrom: a.job.salaryFrom,
        salaryTo: a.job.salaryTo,
        location: a.job.location,
        growthScore: a.job.growthScore,
        matchConfidence: a.matchConfidence,
        createdAt: a.job.createdAt.toISOString(),
      },
    })),
    total: applications.length,
  });
});
