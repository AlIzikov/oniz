// BizON API — /api/jobs/applications/[id]/withdraw
// Отменить отклик (статус 'withdrawn'). Доступно только владельцу отклика.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const application = await db.jobApplication.findUnique({
    where: { id },
    select: { id: true, userId: true, status: true, jobId: true },
  });
  if (!application) return errorJson('Отклик не найден', 404);

  if (application.userId !== user.id) {
    return errorJson('Нет прав на отмену чужого отклика', 403);
  }

  if (application.status === 'withdrawn') {
    return json({ application, alreadyWithdrawn: true });
  }

  // Нельзя отозвать отклик в статусе offer (нужно отдельно decline)
  if (application.status === 'offer') {
    return errorJson(
      'Нельзя отозвать отклик в статусе offer — используйте отказ от оффера',
      422,
    );
  }

  const updated = await db.jobApplication.update({
    where: { id },
    data: { status: 'withdrawn' },
  });

  return json({ application: updated });
}
