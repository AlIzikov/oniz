// BizON API — /api/jobs/compare (P1: Side-by-side сравнение вакансий)
// POST body: { jobIds: string[] }  (2..4 ID вакансий)
// Возвращает сравнительную таблицу по всем метрикам:
//   - Match % (вычисляется из навыков текущего пользователя)
//   - Hiring Reality Index (через HiringRealityService)
//   - Employer Trust (через CompanyTrustService, если есть companyId)
//   - Среднее время ответа HM (responseTimeHours → человеко-читаемый)
//   - Зарплатный диапазон (salaryMin..salaryMax)
//   - Среднее время закрытия вакансий компании (из HiringReality c8 detail)
//   - Проекты (есть ли trustChain до HM)
//   - Growth Score (потенциал роста, 0..1 → «низкий/средний/высокой»)
//   - AI рекомендация (какую выбрать)
//
// Все тяжёлые метрики считаются серверно — UI получает готовый объект.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { computeJobMatchExplainable } from '@/lib/ai';
import { HiringRealityService } from '@/lib/services/hiring-reality-service';
import { CompanyTrustService } from '@/lib/services/company-trust-service';
import { cache, CACHE_TTL } from '@/lib/cache';

export const runtime = 'nodejs';

const MIN_JOBS = 2;
const MAX_JOBS = 4;

interface CompareRow {
  jobId: string;
  title: string;
  company: string;
  companyId: string | null;
  // === Метрики ===
  match: number; // 0..100
  hiringReality: number; // 0..100
  employerTrust: number | null; // 0..100 (null если нет companyId)
  responseDays: number | null; // среднее время ответа в днях (null — неизвестно)
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  closureDays: number | null; // среднее время закрытия вакансий компании
  hasTrustChain: boolean; // есть ли проектный путь до HM (true если есть completed projects)
  growthScore: number; // 0..1 (исходное)
  growthLabel: 'низкий' | 'средний' | 'высокий' | 'оч. высокий';
  requiredSkills: string[];
  matchedSkills: string[];
  missingSkills: string[];
}

function growthLabel(score: number): CompareRow['growthLabel'] {
  if (score >= 0.85) return 'оч. высокий';
  if (score >= 0.65) return 'высокий';
  if (score >= 0.4) return 'средний';
  return 'низкий';
}

function extractClosureDays(criteria: Array<{ name: string; detail?: string }>): number | null {
  const c = criteria.find((cc) => cc.name.includes('время закрытия'));
  if (!c?.detail) return null;
  // detail: "Среднее: 34 дн." или "Нет закрытых откликов"
  const m = c.detail.match(/(\d+)/);
  return m ? Number(m[1]) : null;
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    return errorJson('Невалидный JSON', 400);
  }

  const jobIds: unknown = body?.jobIds;
  if (!Array.isArray(jobIds) || jobIds.length < MIN_JOBS || jobIds.length > MAX_JOBS) {
    return errorJson(`Передайте от ${MIN_JOBS} до ${MAX_JOBS} ID вакансий`, 422);
  }
  // Дедуп + валидация строк
  const uniqueIds = Array.from(
    new Set(jobIds.filter((id): id is string => typeof id === 'string' && id.length > 0)),
  );
  if (uniqueIds.length < MIN_JOBS) {
    return errorJson(`Нужно минимум ${MIN_JOBS} валидных ID`, 422);
  }

  // Загружаем вакансии с hiringManager
  const jobs = await db.job.findMany({
    where: { id: { in: uniqueIds } },
    include: {
      hiringManager: {
        select: { id: true, name: true, title: true, avatarUrl: true },
      },
      companyRel: {
        select: { id: true, name: true, isVerified: true },
      },
    },
  });
  if (jobs.length === 0) return errorJson('Вакансии не найдены', 404);

  // Навыки текущего пользователя
  const userSkillsRows = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkillsRows.map((us) => us.skill.name);

  // Verified projects count (для computeJobMatchExplainable)
  const verifiedProjects = await db.projectMember.findMany({
    where: { userId: user.id, project: { status: 'completed' } },
    select: { projectId: true },
  });
  const verifiedProjectsCount = verifiedProjects.length;

  // Композируем строки сравнения параллельно.
  // HiringReality — кэшируется на уровне сервиса (через cache).
  const rows: CompareRow[] = await Promise.all(
    jobs.map(async (j) => {
      const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
      const matchedSkills = requiredSkills.filter((s) =>
        userSkillNames.some((u) => u.toLowerCase() === s.toLowerCase()),
      );
      const missingSkills = requiredSkills.filter(
        (s) => !userSkillNames.some((u) => u.toLowerCase() === s.toLowerCase()),
      );

      // === Match % (explainable) ===
      const explain = computeJobMatchExplainable({
        userSkills: userSkillNames,
        userIpScore: user.ipScore,
        job: {
          id: j.id,
          title: j.title,
          company: j.company,
          requiredSkills,
          growthScore: j.growthScore,
        },
        verifiedProjectsCount,
        commonContactsCount: 0,
        similarProjectsCount: 0,
        culturalFitScore: undefined,
      });
      // totalMatch уже в шкале 0..100 (контракт computeJobMatchExplainable) — не умножаем повторно
      const match = Math.round(explain.totalMatch);

      // === Hiring Reality Index (кэш) ===
      let hiringReality = 0;
      let closureDays: number | null = null;
      try {
        const cacheKey = `hiring-reality:${j.id}`;
        let hr = cache.get<{
          score: number;
          criteria: Array<{ name: string; detail?: string }>;
        }>(cacheKey);
        if (!hr) {
          const evaluated = await HiringRealityService.evaluate(j.id);
          if (evaluated) {
            hr = {
              score: evaluated.score,
              criteria: evaluated.criteria.map((c) => ({
                name: c.name,
                detail: c.detail,
              })),
            };
            cache.set(cacheKey, hr, CACHE_TTL.LONG);
          }
        }
        if (hr) {
          hiringReality = hr.score;
          closureDays = extractClosureDays(hr.criteria);
        }
      } catch {
        // Не критично — оставляем 0
      }

      // === Employer Trust (только если есть companyId) ===
      let employerTrust: number | null = null;
      if (j.companyId) {
        try {
          const trust = await CompanyTrustService.calculate(j.companyId);
          if (trust) employerTrust = Math.round(trust.overall);
        } catch {
          // ignore
        }
      }

      // === Response time (часы → дни) ===
      const responseHours = j.responseTimeHours ?? null;
      const responseDays =
        responseHours != null ? Math.round((responseHours / 24) * 10) / 10 : null;

      // === Trust chain: есть ли у HM общие проекты с кандидатом ===
      // Упрощённо: если есть hiringManagerId и у пользователя есть completed projects,
      // считаем что потенциально есть chain. Полный расчёт computeTrustChain тут избыточен.
      const hasTrustChain =
        !!j.hiringManagerId && j.hiringManagerId !== user.id && verifiedProjectsCount > 0;

      // Salary
      const salaryMin = j.salaryMin ?? j.salaryFrom ?? null;
      const salaryMax = j.salaryMax ?? j.salaryTo ?? null;

      return {
        jobId: j.id,
        title: j.title,
        company: j.company,
        companyId: j.companyId ?? null,
        match,
        hiringReality,
        employerTrust,
        responseDays,
        salaryMin,
        salaryMax,
        currency: j.currency ?? 'RUB',
        closureDays,
        hasTrustChain,
        growthScore: j.growthScore,
        growthLabel: growthLabel(j.growthScore),
        requiredSkills,
        matchedSkills,
        missingSkills,
      } satisfies CompareRow;
    }),
  );

  // === AI рекомендация: какую выбрать ===
  // Простая, но полезная эвристика (без LLM, чтобы быстро работало):
  //   composite = 0.4*match + 0.3*hiringReality + 0.2*employerTrust (или 50 fallback) + 0.1*growth*100
  const recommendation = buildRecommendation(rows);

  return json({
    rows,
    recommendation,
    meta: {
      userId: user.id,
      userSkillsCount: userSkillNames.length,
      generatedAt: new Date().toISOString(),
    },
  });
}

function buildRecommendation(rows: CompareRow[]): string {
  if (rows.length === 0) return 'Недостаточно данных для рекомендации.';

  // Composite score
  const scored = rows.map((r) => {
    const trust = r.employerTrust ?? 50;
    const growth = r.growthScore * 100;
    const composite = 0.4 * r.match + 0.3 * r.hiringReality + 0.2 * trust + 0.1 * growth;
    return { r, composite };
  });
  scored.sort((a, b) => b.composite - a.composite);
  const best = scored[0];
  const worst = scored[scored.length - 1];

  // Идентифицируем вакансии по букве (A, B, C, D) — как в таблице сравнения
  const letter = (idx: number) => String.fromCharCode(65 + idx);
  const bestIdx = rows.indexOf(best.r);
  const worstIdx = rows.indexOf(worst.r);

  const parts: string[] = [];

  if (best.r.hiringReality >= 70 && worst.r.hiringReality < 50) {
    parts.push(
      `Если важна вероятность найма — выберите ${letter(bestIdx)} (Hiring Reality ${best.r.hiringReality}).`,
    );
  }
  if (best.r.growthLabel === 'оч. высокий' || best.r.growthLabel === 'высокий') {
    parts.push(
      `Если важен рост — ${letter(bestIdx)} (${best.r.growthLabel} потенциал, ${Math.round(best.r.growthScore * 100)}%).`,
    );
  }
  if (best.r.match >= 85) {
    parts.push(`Лучшее совпадение навыков — ${letter(bestIdx)} (${best.r.match}%).`);
  }
  if (parts.length === 0) {
    parts.push(
      `Сбалансированный выбор — ${letter(bestIdx)}: match ${best.r.match}%, hiring reality ${best.r.hiringReality}, рост ${best.r.growthLabel}.`,
    );
  }
  return parts.join(' ');
}
