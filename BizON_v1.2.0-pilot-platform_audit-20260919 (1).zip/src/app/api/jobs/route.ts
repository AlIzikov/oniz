// BizON API — /api/jobs (с лимитами по типу аккаунта)
// Free: 1 вакансия для company/hr_agency
// Pro/Business: безлимит вакансий + безлимит регионов
//
// v6.1 (Task 7-c) — intention-first поиск (Стратегия «Вакансии → Работа», п.C/D/E/X):
//   GET /api/jobs?q=...&mode=quick|nl|precise|explore&important=salary,remote,growth,leadership,industry,stability
//                &minSalary=...&location=...&workFormat=remote|hybrid|onsite&level=...&industry=...
//   • Без параметров — прежний ответ (обратно совместимо), НО скрытые
//     вакансии (IgnoredTopic, source jobs|feed) вырезаются и в нём (анти-эхо).
//   • С параметрами: intent-парсинг (SemanticSearchService), бусты important,
//     группы выдачи matchTier exact|strong|adjacent + groups-счётчики,
//     explanation {reasons, missing} («Почему это вам» / «Что не совпадает»),
//     при mode=nl — parsedIntent («Я правильно вас поняли?»).
//
// v6.1 (Task 9-g, doc_a §44) — Professional Query: профессиональный слой
//   поверх q. Включается параметром prof=1 и работает ТОЛЬКО вместе с q
//   (prof без q игнорируется — парсить нечего). Аддитивно к 7-c:
//   • professionalQuery — распознанные измерения намерения: role/skills/
//     location/salaryMin/workFormat/industry/seniority + handsOn, management,
//     relocationReady («готов к переезду») — детерминированные regex-правила,
//     без LLM;
//   • synonym-матчинг: вакансии, совпавшие с q через синонимы SkillSynonym
//     (напр. «мл» ↔ «Machine Learning»), получают профессиональный буст и
//     прозрачный professionalContext.synonymsMatched;
//   • adjacent_role: вакансии смежных ролей (ADJACENT_ROLE_GRAPH) получают
//     professionalContext + пояснение «смежная роль»;
//   • management: high → мягкий буст руководящих позиций; handsOn
//     распознаётся, но НЕ влияет на ранжирование (на модели Job нет
//     соответствующего признака — честно указано в professionalQuery.note);
//   • relocationReady=true смягчает жёсткий location-фильтр mode=precise.
//   При prof≠1 ответ байт-в-байт как в 7-c (обратная совместимость строгая).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { EventService } from '@/lib/services';
import { EventBus } from '@/lib/event-bus';
import { computeJobMatch } from '@/lib/ai';
import {
  SemanticSearchService,
  getAdjacentRoles,
  type SearchIntent,
} from '@/lib/services/semantic-search-service';
import { parseRequiredSkillsWithLevels } from '@/lib/services/job-growth-service';
import { buildSynonymIndex } from '@/lib/services/build-talent-service';

export const runtime = 'nodejs';

// Лимиты вакансий по типу аккаунта и тарифу
const JOB_LIMITS: Record<string, Record<string, number>> = {
  individual: { free: 0, pro: 0, business: 0 }, // частные лица не могут публиковать вакансии
  company: { free: 1, pro: Infinity, business: Infinity },
  hr_agency: { free: 1, pro: Infinity, business: Infinity },
};

// ============================================================================
// v6.1 (Task 7-c): intention-first поиск — типы и helpers
// ============================================================================

type ImportantFlag = 'salary' | 'remote' | 'growth' | 'leadership' | 'industry' | 'stability';
const IMPORTANT_FLAGS: readonly ImportantFlag[] = [
  'salary', 'remote', 'growth', 'leadership', 'industry', 'stability',
];

type WorkFormat = 'remote' | 'hybrid' | 'onsite';
type MatchTier = 'exact' | 'strong' | 'adjacent';

function clamp01(v: number): number {
  return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : 0;
}

/** Парсит CSV «Что для вас важно?» в набор флагов буста. */
function parseImportant(raw: string | null): Set<ImportantFlag> {
  const out = new Set<ImportantFlag>();
  if (!raw) return out;
  for (const part of raw.split(',')) {
    const f = part.trim().toLowerCase();
    if ((IMPORTANT_FLAGS as readonly string[]).includes(f)) out.add(f as ImportantFlag);
  }
  return out;
}

/**
 * Матч формата работы. Если поле Job.workFormat не заполнено —
 * эвристика по location/description («удалён», «remote», «гибрид», «офис»).
 */
function workFormatMatches(
  job: { workFormat: string | null; location: string | null; description: string | null },
  wanted: WorkFormat,
): boolean {
  const jf = (job.workFormat ?? '').toLowerCase();
  if (jf === 'remote' || jf === 'hybrid' || jf === 'onsite') return jf === wanted;
  const text = `${job.location ?? ''} ${job.description ?? ''}`.toLowerCase();
  if (wanted === 'remote') return /удал[её]н|remote|дистанционн/.test(text);
  if (wanted === 'hybrid') return /гибрид|hybrid/.test(text);
  return /офис|onsite|on-site/.test(text) && !/удал[её]н|remote/.test(text);
}

/** Верхняя граница зарплаты вакансии (salaryMax → salaryTo → salaryFrom → salaryMin). */
function jobSalaryMax(j: {
  salaryMax?: number | null; salaryTo?: number | null; salaryFrom?: number | null; salaryMin?: number | null;
}): number {
  return j.salaryMax ?? j.salaryTo ?? j.salaryFrom ?? j.salaryMin ?? 0;
}

/**
 * Анти-эхо-камера: скрытые вакансии пользователя.
 * IgnoredTopic (source in ['jobs','feed']): targetId = конкретная вакансия,
 * topic = тема, которая встречается в lowercase-заголовке вакансии.
 */
async function loadHiddenJobs(userId: string): Promise<{ hiddenIds: Set<string>; topics: string[] }> {
  const rows = await db.ignoredTopic.findMany({
    where: { userId, source: { in: ['jobs', 'feed'] } },
    select: { topic: true, targetId: true },
  });
  const hiddenIds = new Set<string>();
  const topics = new Set<string>();
  for (const r of rows) {
    if (r.targetId) hiddenIds.add(r.targetId);
    const t = r.topic.toLowerCase().trim();
    if (t.length >= 3) topics.add(t); // короткие темы ловим только точным targetId
  }
  return { hiddenIds, topics: [...topics] };
}

function isHiddenJob(
  job: { id: string; title: string },
  hidden: { hiddenIds: Set<string>; topics: string[] },
): boolean {
  if (hidden.hiddenIds.has(job.id)) return true;
  const titleLower = job.title.toLowerCase();
  return hidden.topics.some((t) => titleLower.includes(t));
}

/** requiredSkills CSV с опциональными уровнями «Навык:L» → [{name, level}] */
function parseRequiredSkills(csv: string): Array<{ name: string; level: number | null }> {
  return parseRequiredSkillsWithLevels(csv);
}

// ============================================================================
// v6.1 (Task 9-g): Professional Query (doc_a §44) — профессиональный слой q
// ============================================================================

/** Распознанные Professional Query-измерения намерения (§44, детерминированно). */
type ProfessionalParsed = {
  role: string | null;
  skills: string[];
  location: string | null;
  salaryMin: number | null;
  workFormat: 'remote' | 'hybrid' | 'onsite' | null;
  industry: string | null;
  seniority: 'junior' | 'middle' | 'senior' | 'lead' | null;
  handsOn: 'high' | null;
  management: 'high' | null;
  relocationReady: boolean;
};

type ProfessionalQuery = {
  enabled: true;
  parsed: ProfessionalParsed;
  expansions: {
    synonymSkills: Array<{ term: string; synonyms: string[] }>;
    adjacentRoles: string[];
  };
  note: string;
};

/** Профессиональный контекст вакансии (аддитивное поле при prof=1). */
type JobProfessionalContext = {
  matchedVia: string[]; // 'synonym' | 'adjacent_role'
  synonymsMatched: string[]; // «мл → Machine Learning»
  adjacentRole: string | null;
};

/**
 * Парсит §44-измерения намерения из q поверх parseIntent.
 * handsOn: «руками/практика/hands-on/не чисто административную» — высокие
 * практические требования. management: «руковод/менедж/управлен». relocation:
 * «готов к переезду/переезд». Всё — lookbehind-regex на кириллице (без \b).
 */
function parseProfessionalDimensions(q: string, intent: SearchIntent): ProfessionalParsed {
  const lower = q.toLowerCase();

  const handsOn =
    /(?<![a-zа-яё])(руками|hands-?on|практик|инженерн|техническ|не.?хочу.?чисто.?административн)/.test(lower)
      ? ('high' as const)
      : null;
  const management =
    /(?<![a-zа-яё])(руковод|управлен|менеджер|лидер|тимлид|директор)/.test(lower)
      ? ('high' as const)
      : null;
  const relocationReady = /(?<![a-zа-яё])(готов.{0,8}переезд|переезд|релокаци|relocation)/.test(lower);

  return {
    role: intent.role,
    skills: intent.skills,
    location: intent.location,
    salaryMin: intent.salaryMin,
    workFormat: intent.workFormat,
    industry: intent.industry,
    seniority: intent.seniority,
    handsOn,
    management,
    relocationReady,
  };
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Если company/hr_agency — показываем их вакансии + кандидатов
  if (user.accountType === 'company' || user.accountType === 'hr_agency') {
    const jobs = await db.job.findMany({
      where: { companyId: user.companyId ?? undefined },
      orderBy: { createdAt: 'desc' },
      include: {
        applications: {
          include: {
            user: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, location: true } },
          },
        },
        _count: { select: { applications: true } },
      },
    });

    // Лимиты
    const limit = JOB_LIMITS[user.accountType]?.[user.subscriptionTier] ?? 0;
    const used = jobs.length;
    const remaining = limit === Infinity ? Infinity : Math.max(0, limit - used);

    return json({
      jobs: jobs.map(j => ({
        id: j.id,
        title: j.title,
        description: j.description,
        requiredSkills: j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [],
        salaryFrom: j.salaryFrom,
        salaryTo: j.salaryTo,
        location: j.location,
        growthScore: j.growthScore,
        active: j.active,
        createdAt: j.createdAt.toISOString(),
        applicationsCount: j._count.applications,
        candidates: j.applications.map(a => ({
          id: a.id,
          status: a.status,
          matchConfidence: a.matchConfidence,
          appliedAt: a.createdAt.toISOString(),
          user: a.user,
        })),
      })),
      limits: {
        max: limit === Infinity ? 'unlimited' : limit,
        used,
        remaining: remaining === Infinity ? 'unlimited' : remaining,
        canPostMore: remaining > 0,
        tier: user.subscriptionTier,
      },
    });
  }

  // ==========================================================================
  // Для individual — поиск вакансий (v6.1: intention-first, обратно совместимо)
  // ==========================================================================
  const url = new URL(req.url);
  const q = (url.searchParams.get('q') ?? '').trim();
  const mode = url.searchParams.get('mode'); // quick | nl | precise | explore
  const important = parseImportant(url.searchParams.get('important'));
  const minSalaryParam = Number(url.searchParams.get('minSalary')) || null;
  const locationParam = (url.searchParams.get('location') ?? '').trim() || null;
  const workFormatRaw = (url.searchParams.get('workFormat') ?? '').trim().toLowerCase();
  const workFormatParam: WorkFormat | null =
    workFormatRaw === 'remote' || workFormatRaw === 'hybrid' || workFormatRaw === 'onsite'
      ? (workFormatRaw as WorkFormat)
      : null;
  const levelParam = (url.searchParams.get('level') ?? '').trim() || null;
  const industryParam = (url.searchParams.get('industry') ?? '').trim() || null;

  // v6.1 (Task 9-g): Professional Query (§44) — только вместе с q (см. шапку)
  const profEnabled = (url.searchParams.get('prof') ?? '').trim() === '1' && q.length > 0;

  const enriched =
    q.length > 0 ||
    mode !== null ||
    important.size > 0 ||
    minSalaryParam !== null ||
    locationParam !== null ||
    workFormatParam !== null ||
    levelParam !== null ||
    industryParam !== null;

  // Пул вакансий (одним запросом для обоих путей)
  const jobs = await db.job.findMany({
    where: { active: true },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });

  // Профиль юзера для матчинга
  const userSkills = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkills.map(us => us.skill.name);
  const userSkillSetLower = new Set(userSkillNames.map(s => s.toLowerCase().trim()).filter(Boolean));

  // Анти-эхо-камера: исключаем скрытые вакансии (IgnoredTopic jobs|feed)
  const hidden = await loadHiddenJobs(user.id);
  const visibleJobs = jobs.filter((j) => !isHiddenJob(j, hidden));

  // --------------------------------------------------------------------------
  // Без параметров — прежний вид ответа (обратно совместимо)
  // --------------------------------------------------------------------------
  if (!enriched) {
    return json({
      jobs: visibleJobs.slice(0, 50).map(j => {
        const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
        const overlap = requiredSkills.filter(s => userSkillNames.includes(s)).length;
        const match = requiredSkills.length === 0 ? 0.3 : overlap / requiredSkills.length;
        return {
          id: j.id, title: j.title, company: j.company, description: j.description,
          requiredSkills, salaryFrom: j.salaryFrom, salaryTo: j.salaryTo, location: j.location,
          growthScore: j.growthScore, matchConfidence: match, createdAt: j.createdAt.toISOString(),
          // Wave 11-c: «Горячие» = платные/срочные размещения — фронту нужны признаки
          boosted: j.boosted, boostedUntil: j.boostedUntil ? j.boostedUntil.toISOString() : null,
        };
      }),
    });
  }

  // --------------------------------------------------------------------------
  // v6.1: intention-first выдача — ранжирование, группы, объяснения
  // --------------------------------------------------------------------------
  const intent: SearchIntent | null = q.length > 0
    ? await SemanticSearchService.parseIntent(q, user.id)
    : null;

  // Эффективные фильтры: явные параметры приоритетнее intent из текста
  const eff = {
    minSalary: minSalaryParam ?? intent?.salaryMin ?? null,
    location: locationParam ?? intent?.location ?? null,
    workFormat: workFormatParam ?? intent?.workFormat ?? null,
    level: levelParam,
    industry: industryParam ?? intent?.industry ?? null,
  };

  // Смежные роли (Career Adjacency) для группы «adjacent»
  const adjacentRoles = getAdjacentRoles(intent?.role ?? null);

  // --- v6.1 (Task 9-g): Professional Query — синтез-слой §44 -----------------
  let professional: ProfessionalQuery | null = null;
  // term → варианты совпадения: match — lowercase для поиска в тексте вакансии,
  // display — оригинальный регистр (имя Skill/синонима из SkillSynonym) для объяснения
  const synonymExpansionMap: Map<string, Array<{ match: string; display: string }>> = new Map();
  let relaxLocation = false; // relocationReady + location из intent → смягчить precise-фильтр
  if (profEnabled && intent) {
    const parsed = parseProfessionalDimensions(q, intent);
    const synonymIndex = await buildSynonymIndex();
    for (const term of parsed.skills.slice(0, 10)) {
      const key = term.toLowerCase().trim();
      const variants = [...(synonymIndex.get(key) ?? new Set<string>())]
        .filter((x) => x.toLowerCase().trim() !== key)
        .map((display) => ({ match: display.toLowerCase(), display }));
      synonymExpansionMap.set(key, variants);
    }
    relaxLocation = parsed.relocationReady && locationParam === null && parsed.location !== null;
    professional = {
      enabled: true,
      parsed,
      expansions: {
        synonymSkills: [...synonymExpansionMap.entries()]
          .filter(([, variants]) => variants.length > 0)
          .map(([term, variants]) => ({ term, synonyms: variants.map((v) => v.display) })),
        adjacentRoles,
      },
      note:
        'Профессиональный слой: synonym-матчинг через SkillSynonym + смежные роли (Career Adjacency) + измерения намерения §44. handsOn распознан, но не влияет на ранжирование (на модели Job нет соответствующего признака).',
    };
  }

  type Scored = {
    id: string; title: string; company: string; description: string;
    requiredSkills: string[]; salaryFrom: number | null; salaryTo: number | null;
    salaryMin: number | null; salaryMax: number | null; currency: string;
    location: string | null; level: string | null; workFormat: string | null;
    industry: string | null; verificationStatus: string; vacancyTrust: number;
    growthScore: number; createdAt: string;
    matchConfidence: number;
    rankScore: number;
    matchTier: MatchTier;
    explanation: { reasons: string[]; missing: string[] };
    professionalContext?: JobProfessionalContext; // v6.1 (9-g): только при prof=1
  };

  const scored: Scored[] = visibleJobs.map((j) => {
    const parsed = parseRequiredSkills(j.requiredSkills);
    const requiredSkills = parsed.map((p) => p.name);
    const reqLower = requiredSkills.map((s) => s.toLowerCase());
    const matchedLower = reqLower.filter((s) => userSkillSetLower.has(s));
    const overlapRatio = requiredSkills.length === 0 ? 0 : matchedLower.length / requiredSkills.length;

    // Базовый match (навыки 60% / trust 25% / growth 15%) — computeJobMatch из lib/ai
    const base = computeJobMatch(userSkillNames, user.ipScore, {
      requiredSkills,
      growthScore: j.growthScore,
    });

    const titleLower = j.title.toLowerCase();
    const descLower = j.description.toLowerCase();

    // --- Семантика запроса q ---
    let semantic = 0;
    let semanticHits = 0;
    let roleFullHit = false;
    if (intent) {
      if (intent.role) {
        const roleWords = intent.role.toLowerCase().split(/\s+/).filter((w) => w.length >= 3);
        const hits = roleWords.filter((w) => titleLower.includes(w)).length;
        if (hits > 0) {
          semantic += 0.3 * (hits / roleWords.length);
          roleFullHit = hits === roleWords.length;
          if (roleFullHit) semanticHits += 1;
        }
      }
      const termSet = new Set(intent.skills.map((s) => s.toLowerCase()));
      if (termSet.size > 0) {
        const termHits = [...termSet].filter(
          (t) => titleLower.includes(t) || descLower.includes(t) || reqLower.includes(t),
        ).length;
        semantic += 0.4 * Math.min(1, termHits / termSet.size);
        if (termHits >= 2) semanticHits += 1;
      }
      if (eff.minSalary !== null) {
        const mx = jobSalaryMax(j);
        if (mx >= eff.minSalary) {
          semantic += 0.15;
          semanticHits += 1;
        }
      }
      if (eff.location && (j.location ?? '').toLowerCase().includes(eff.location.toLowerCase())) {
        semantic += 0.1;
        semanticHits += 1;
      }
      if (eff.workFormat && workFormatMatches(j, eff.workFormat)) {
        semantic += 0.1;
        semanticHits += 1;
      }
      if (eff.level && (j.level ?? '').toLowerCase() === eff.level.toLowerCase()) {
        semantic += 0.1;
        semanticHits += 1;
      }
      if (eff.industry) {
        const ind = eff.industry.toLowerCase();
        const jobIndustry = (j.industry ?? '').toLowerCase();
        if (jobIndustry && (jobIndustry.includes(ind) || ind.includes(jobIndustry))) semanticHits += 1;
      }
    }

    // --- Бусты «Что для вас важно?» ---
    let boost = 0;
    const reasons: string[] = [];

    if (roleFullHit && intent?.role) reasons.push(`соответствует запросу «${intent.role}»`);
    if (important.has('salary') && eff.minSalary !== null) {
      const mx = jobSalaryMax(j);
      if (mx >= eff.minSalary) {
        boost += 0.08;
        reasons.push(mx > eff.minSalary * 1.15 ? 'зарплата выше цели' : 'зарплата соответствует цели');
      }
    }
    if (important.has('remote') && workFormatMatches(j, 'remote')) {
      boost += 0.08;
      reasons.push('удалённая работа');
    }
    if (important.has('growth') && j.growthScore >= 0.7) {
      boost += j.growthScore * 0.1;
      reasons.push('высокий потенциал роста');
    }
    if (important.has('leadership')) {
      const levelLower = (j.level ?? '').toLowerCase();
      if (levelLower === 'lead' || levelLower === 'director' || /руковод/.test(titleLower)) {
        boost += 0.08;
        reasons.push('руководящая позиция');
      }
    }
    if (important.has('industry') && eff.industry) {
      const ind = eff.industry.toLowerCase();
      const jobIndustry = (j.industry ?? '').toLowerCase();
      const industryHit =
        (jobIndustry && (jobIndustry.includes(ind) || ind.includes(jobIndustry))) ||
        titleLower.includes(ind) ||
        descLower.includes(ind);
      if (industryHit) {
        boost += 0.08;
        reasons.push(`отрасль: ${j.industry ?? eff.industry}`);
      }
    }
    if (important.has('stability')) {
      const vt = j.vacancyTrust ?? 0;
      boost += clamp01(vt) * 0.05;
      if (j.verificationStatus === 'verified') {
        boost += 0.05;
        reasons.push('проверенная вакансия');
      }
    }
    if (matchedLower.length > 0) {
      reasons.unshift(`${matchedLower.length} из ${requiredSkills.length} навыков совпадает`);
    }

    // --- v6.1 (Task 9-g): Professional Query — synonym/adjacent слой (§44) ---
    let professionalContext: JobProfessionalContext | undefined;
    if (professional) {
      const matchedVia: string[] = [];
      const synonymsMatched: string[] = [];
      let profBoost = 0;

      // 1) Синонимический матчинг: совпадение через SkillSynonym, которого
      //    не было прямым термином (напр. «мл» ↔ «Machine Learning»)
      for (const [term, variants] of synonymExpansionMap) {
        const directHit =
          titleLower.includes(term) || descLower.includes(term) || reqLower.includes(term);
        if (directHit) continue;
        const synHit = variants.find(
          (v) =>
            titleLower.includes(v.match) || descLower.includes(v.match) || reqLower.includes(v.match),
        );
        if (synHit) {
          synonymsMatched.push(`${term} → ${synHit.display}`);
        }
      }
      if (synonymsMatched.length > 0) {
        matchedVia.push('synonym');
        profBoost += Math.min(0.1, 0.05 * synonymsMatched.length);
        reasons.push(`совпадение по смыслу: ${synonymsMatched[0]}`);
      }

      // 2) Смежная роль (Career Adjacency) — вакансия вне прямого запроса,
      //    но профессионально близкая (§43 «главный инженер по РЗА»)
      let adjacentHit: string | null = null;
      if (!roleFullHit) {
        adjacentHit =
          adjacentRoles.find((a) => {
            const words = a.toLowerCase().split(/\s+/).filter((w) => w.length >= 3);
            return words.length > 0 && words.every((w) => titleLower.includes(w));
          }) ?? null;
        if (adjacentHit) {
          matchedVia.push('adjacent_role');
          profBoost += 0.04;
          reasons.push(`смежная роль: ${adjacentHit}`);
        }
      }

      // 3) management: high — мягкий буст руководящих позиций (без дублей
      //    с important=leadership)
      if (professional.parsed.management === 'high' && !important.has('leadership')) {
        const levelLower = (j.level ?? '').toLowerCase();
        if (levelLower === 'lead' || levelLower === 'director' || /руковод/.test(titleLower)) {
          profBoost += 0.05;
        }
      }
      // handsOn: распознан, но сознательно не влияет на ранжирование
      // (на модели Job нет признака «практичность» — не выдумываем).

      boost += profBoost;
      if (matchedVia.length > 0) {
        professionalContext = {
          matchedVia,
          synonymsMatched: synonymsMatched.slice(0, 3),
          adjacentRole: adjacentHit,
        };
      }
    }

    // Итоговый ранжирующий score
    const rankScore = clamp01(
      (q.length > 0 ? 0.5 * base + 0.5 * Math.min(1, semantic) : base) + boost,
    );

    // --- Группа выдачи (Точное / Сильное / Смежные) ---
    const titleAdjacentHit = adjacentRoles.some((a) => {
      const words = a.toLowerCase().split(/\s+/).filter((w) => w.length >= 3);
      return words.length > 0 && words.every((w) => titleLower.includes(w));
    });
    let matchTier: MatchTier;
    if (roleFullHit || overlapRatio >= 0.6) {
      matchTier = 'exact';
    } else if (semanticHits >= 2 || overlapRatio >= 0.3) {
      matchTier = 'strong';
    } else {
      matchTier = 'adjacent'; // смежные роли / расширение кругозора
    }

    // --- Что не совпадает (⚠️, максимум 2) ---
    const missing = parsed
      .filter((p) => !userSkillSetLower.has(p.name.toLowerCase()))
      .slice(0, 2)
      .map((p) => (p.level !== null ? `требуется ${p.name} (уровень ${p.level})` : `требуется ${p.name}`));

    return {
      id: j.id,
      title: j.title,
      company: j.company,
      description: j.description,
      requiredSkills,
      salaryFrom: j.salaryFrom,
      salaryTo: j.salaryTo,
      salaryMin: j.salaryMin,
      salaryMax: j.salaryMax,
      currency: j.currency,
      location: j.location,
      level: j.level,
      workFormat: j.workFormat,
      industry: j.industry,
      verificationStatus: j.verificationStatus,
      vacancyTrust: j.vacancyTrust,
      growthScore: j.growthScore,
      createdAt: j.createdAt.toISOString(),
      matchConfidence: base,
      rankScore: Math.round(rankScore * 100) / 100,
      matchTier,
      // Wave 11-c: признаки платного размещения (для раздела «Горячие»)
      boosted: j.boosted,
      boostedUntil: j.boostedUntil ? j.boostedUntil.toISOString() : null,
      explanation: { reasons: reasons.slice(0, 3), missing },
      ...(professionalContext ? { professionalContext } : {}),
    };
  });

  scored.sort((a, b) => b.rankScore - a.rankScore);

  // Режим «Точный поиск» — жёсткие фильтры (стратегия: не использовать AI там,
  // где SQL/фильтр справляется лучше). В остальных режимах — мягкий буст.
  // v6.1 (9-g): relocationReady («готов к переезду») смягчает location-фильтр,
  // если локация пришла из intent (явный ?location= параметр сильнее текста).
  const filtered =
    mode === 'precise'
      ? scored.filter((s) => {
          if (eff.minSalary !== null && jobSalaryMax(s) < eff.minSalary) return false;
          if (eff.location && !relaxLocation && !(s.location ?? '').toLowerCase().includes(eff.location.toLowerCase())) return false;
          if (eff.workFormat && !workFormatMatches(s, eff.workFormat)) return false;
          if (eff.level && (s.level ?? '').toLowerCase() !== eff.level.toLowerCase()) return false;
          if (eff.industry && !(s.industry ?? '').toLowerCase().includes(eff.industry.toLowerCase())) return false;
          return true;
        })
      : scored;

  const groups = { exact: 0, strong: 0, adjacent: 0 };
  for (const s of filtered) groups[s.matchTier] += 1;

  const parsedIntent =
    mode === 'nl'
      ? {
          role: intent?.role ?? null,
          industry: intent?.industry ?? null,
          location: intent?.location ?? null,
          minSalary: intent?.salaryMin ?? null,
          workFormat: intent?.workFormat ?? null,
          level: intent?.seniority ?? null,
        }
      : undefined;

  return json({
    jobs: filtered,
    totalFound: filtered.length,
    groups,
    applied: {
      q: q || null,
      mode: mode ?? 'quick',
      important: [...important],
      minSalary: eff.minSalary,
      location: eff.location,
      workFormat: eff.workFormat,
      level: eff.level,
      industry: eff.industry,
    },
    ...(parsedIntent ? { parsedIntent } : {}),
    ...(professional ? { professionalQuery: professional } : {}),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только company/hr_agency могут создавать вакансии
  if (user.accountType === 'individual') {
    return errorJson('Частные лица не могут публиковать вакансии. Зарегистрируйтесь как юр. лицо или HR-агентство.', 403);
  }

  // Проверка лимита
  const limit = JOB_LIMITS[user.accountType]?.[user.subscriptionTier] ?? 0;
  if (limit === 0) {
    return errorJson('Нет прав на публикацию вакансий', 403);
  }

  const existingCount = await db.job.count({
    where: { companyId: user.companyId ?? 'no-company' },
  });

  if (limit !== Infinity && existingCount >= limit) {
    return errorJson(
      `Лимит бесплатного тарифа: ${limit} вакансия. Перейдите на Pro (${user.accountType === 'hr_agency' ? '1499' : '1499'}₽/мес) для безлимитных вакансий и регионов.`,
      402 // Payment Required
    );
  }

  try {
    const body = await req.json();
    const { title, description, requiredSkills, salaryFrom, salaryTo, location, growthScore } = body ?? {};
    if (!title || !description) return errorJson('title и description обязательны', 422);

    // Найти или создать название компании
    const company = user.companyId ? await db.company.findUnique({ where: { id: user.companyId } }) : null;

    const job = await db.job.create({
      data: {
        title,
        company: company?.name ?? user.name,
        companyId: user.companyId,
        description,
        requiredSkills: Array.isArray(requiredSkills) ? requiredSkills.join(',') : '',
        salaryFrom: salaryFrom || null,
        salaryTo: salaryTo || null,
        location: location || null,
        growthScore: growthScore ?? 0.5,
      },
    });

    // Event Bus: вакансия опубликована (ошибки шины не влияют на ответ API)
    EventBus.publish('job.posted', { userId: user.id, jobId: job.id, title: job.title }).catch(() => undefined);

    return json({ job }, 201);
  } catch (e) {
    console.error('[jobs/create] error:', e);
    return errorJson('Ошибка создания вакансии', 500);
  }
}
