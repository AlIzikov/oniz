// BizON API — /api/jobs/[id]/growth (v6.1, Task 7-c)
// «Подготовить меня к этой вакансии» (Стратегия «Вакансии → Работа», п.7).
//
// Считает от Skill Graph (skill-graph-service, persist:false — read-only):
//   requiredSkills вакансии (CSV, опционально «Навык:L», шкала 1..10)
//   vs текущие уровни навыков пользователя.
//
// Ответ (всегда 200, даже при пустых данных):
//   {
//     readiness: [{ skill, requiredLevel, currentLevel, ok }],   // ✓/✕ чеклист
//     actions:   ["Получить опыт «X»", "Подтвердить «Y»", ...],  // «Что сделать», ≤5
//     gives:     ["Budget Management", ...],                     // «Что эта работа даст» —
//                                                                //  skill gap, которые вакансия ЗАКРОЕТ
//     forecast:  "После 12–24 месяцев на позиции вы закроете N карьерных
//                 дефицитов и расширите доступные вакансии."    // эвристика, без LLM
//   }
//
// Контракт отмечаемых просмотров вакансии (для «Мы заметили интерес»):
//   фронт при ОТКРЫТИИ деталей вакансии вызывает POST /api/jobs/[id]/view —
//   он публикует job.viewed в Event Bus и пишет ActionEvent(type='job_viewed')
//   не чаще 1 раза в сутки на пользователя/вакансию. growth-роут просмотры
//   НЕ отмечает (открытие чеклиста ≠ просмотр вакансии).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { JobGrowthService } from '@/lib/services/job-growth-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const job = await db.job.findUnique({
    where: { id },
    select: { id: true, title: true, requiredSkills: true },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  const result = await JobGrowthService.evaluate(user.id, job.requiredSkills);

  return json({
    jobId: job.id,
    jobTitle: job.title,
    readiness: result.readiness,
    actions: result.actions,
    gives: result.gives,
    forecast: result.forecast,
  });
}
