// BizON API — /api/jobs/[id]/hiring-reality (Phase 3 — Hiring Reality Index)
// GET — возвращает Hiring Reality Index (11 критериев + score + level).
//   {
//     "score": 91,
//     "level": "high",
//     "criteria": [{ "name": "...", "passed": true, "points": 10 }, ...]
//   }
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { HiringRealityService } from '@/lib/services/hiring-reality-service';
import { cache, CACHE_TTL } from '@/lib/cache';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Phase 16: кэш 1 час по jobId — Hiring Reality Index дорогой (11 критериев
  // с JOIN'ами по job/applications/hiringManager). Сам индекс зависит только
  // от структуры вакансии, которая не меняется между откликами.
  // Инвалидация: cache.delete(`hiring-reality:${id}`) при изменении вакансии.
  const cacheKey = `hiring-reality:${id}`;
  const cached = cache.get<unknown>(cacheKey);
  if (cached !== null) return json(cached);

  const result = await HiringRealityService.evaluate(id);
  if (!result) return errorJson('Вакансия не найдена', 404);

  // Спецификационный формат ответа — плоский { score, level, criteria }
  const response = {
    score: result.score,
    level: result.level,
    criteria: result.criteria.map((c) => ({
      name: c.name,
      passed: c.passed,
      points: c.points,
      ...(c.detail ? { detail: c.detail } : {}),
    })),
    computedAt: result.computedAt,
  };
  cache.set(cacheKey, response, CACHE_TTL.LONG);
  return json(response);
}
