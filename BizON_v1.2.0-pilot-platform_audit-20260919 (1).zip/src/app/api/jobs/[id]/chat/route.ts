// BizON API — /api/jobs/[id]/chat (Путь A: начать чат с hiring manager)
// Создаёт Message thread + отправляет первое сообщение от кандидата.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'messages:create', ...MUTATION_LIMITS.messagesCreate);
  if (!rl.allowed) return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);

  const job = await db.job.findUnique({
    where: { id },
    include: { hiringManager: { select: { id: true, name: true } } },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  // === Путь A: чат с hiring manager ===
  // Если hiringManagerId не указан — fallback на владельца компании (если есть)
  let toUserId = job.hiringManagerId;
  if (!toUserId) {
    // Fallback: ищем любого пользователя компании с ролью company/hr_agency
    const companyUser = job.companyId
      ? await db.user.findFirst({
          where: {
            companyId: job.companyId,
            accountType: { in: ['company', 'hr_agency'] },
          },
          select: { id: true, name: true },
        })
      : null;
    if (!companyUser) {
      return errorJson('У вакансии не указан hiring manager и не найден представитель компании', 422);
    }
    toUserId = companyUser.id;
  }

  if (toUserId === user.id) {
    return errorJson('Нельзя начать чат с самим собой', 422);
  }

  // Парсим тело — сообщение опционально (если нет — используем шаблон)
  let content: string | null = null;
  try {
    const body = await req.json();
    if (body && typeof body.message === 'string') {
      content = body.message.trim();
    }
  } catch {
    // Пустое тело — нормально
  }

  if (!content) {
    content = `Здравствуйте! Меня интересует вакансия «${job.title}». Хотел(а) бы обсудить детали.`;
  }
  if (content.length > 2000) {
    return errorJson('Максимум 2000 символов', 422);
  }

  // Находим или создаём диалог
  let conv = await db.conversation.findFirst({
    where: {
      OR: [
        { fromUserId: user.id, toUserId },
        { fromUserId: toUserId, toUserId: user.id },
      ],
    },
  });
  if (!conv) {
    conv = await db.conversation.create({ data: { fromUserId: user.id, toUserId } });
  }

  const message = await db.message.create({
    data: { conversationId: conv.id, authorId: user.id, content: content.trim() },
  });
  await db.conversation.update({ where: { id: conv.id }, data: { lastMessageAt: new Date() } });

  // Создаём JobApplication с applyPath='chat' (статус 'submitted')
  // Это позволяет видеть в трекере, что был начат чат по вакансии
  const existing = await db.jobApplication.findUnique({
    where: { jobId_userId: { jobId: id, userId: user.id } },
  }).catch(() => null);

  if (existing && existing.status !== 'withdrawn') {
    // Обновляем applyPath на chat (если ранее был persona)
    if (existing.applyPath !== 'chat') {
      await db.jobApplication.update({
        where: { id: existing.id },
        data: { applyPath: 'chat' },
      });
    }
  } else if (existing) {
    // Был withdrawn — реанимируем
    await db.jobApplication.update({
      where: { id: existing.id },
      data: { status: 'submitted', applyPath: 'chat', hiringManagerResponse: null },
    });
  } else {
    await db.jobApplication.create({
      data: { jobId: id, userId: user.id, status: 'submitted', applyPath: 'chat' },
    });

    // Event Bus: отклик отправлен (через чат с hiring manager) — только при
    // СОЗДАНИИ заявки (публикация не должна ломать отправку сообщения)
    try {
      void EventBus.publish('job.applied', {
        userId: user.id,
        jobId: job.id,
        jobTitle: job.title,
      }).catch(() => undefined);
    } catch {
      // fail-open: ошибки шины игнорируем
    }
  }

  // Уведомление hiring manager'у
  const notif = await db.notification.create({
    data: {
      userId: toUserId,
      type: 'message',
      title: `Новое сообщение от ${user.name} по вакансии «${job.title}»`,
      content: content.trim().slice(0, 100),
      link: '/messages',
    },
  }).catch(() => null);
  if (notif) notifyNotificationNew(toUserId, notif);

  return json({ conversationId: conv.id, message }, 201);
}
