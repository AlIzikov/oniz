// BizON API — /api/jobs/[id]/save (toggle сохранения вакансии в Избранное)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id: jobId } = await params;
  if (!jobId) return errorJson('jobId обязателен', 422);

  const existing = await db.savedJob.findUnique({
    where: { userId_jobId: { userId: user.id, jobId } },
  });

  if (existing) {
    await db.savedJob.delete({ where: { id: existing.id } });
    return json({ saved: false });
  }

  await db.savedJob.create({ data: { userId: user.id, jobId } });
  return json({ saved: true });
}
