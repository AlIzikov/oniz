// BizON API — /api/jobs/[id]/apply
// FIX-07: withRoute — auth 401, единый маппинг ошибок (Prisma P2002→409, P2025→404),
// без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { computeJobMatch } from '@/lib/ai';
import { ReputationService } from '@/lib/services';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const { id } = ctx.params;
  const user = ctx.user!;

  const job = await db.job.findUnique({ where: { id } });
  if (!job) return errorJson('Вакансия не найдена', 404);

  const existing = await db.jobApplication.findUnique({
    where: { jobId_userId: { jobId: id, userId: user.id } },
  }).catch(() => null);
  if (existing) return errorJson('Вы уже откликнулись', 400);

  const userSkills = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkills.map((us) => us.skill.name);
  const requiredSkills = job.requiredSkills ? job.requiredSkills.split(',').filter(Boolean) : [];
  const match = computeJobMatch(userSkillNames, user.ipScore, {
    requiredSkills,
    growthScore: job.growthScore,
  });

  const app = await db.jobApplication.create({
    data: {
      jobId: id,
      userId: user.id,
      status: 'submitted',
      matchConfidence: match,
    },
  });

  // Event Bus: отклик отправлен (публикация не должна ломать отклик)
  try {
    void EventBus.publish('job.applied', {
      userId: user.id,
      jobId: job.id,
      jobTitle: job.title,
    }).catch(() => undefined);
  } catch {
    // fail-open: ошибки шины игнорируем
  }

  // FIX-06: reputation event + пересчёт IP-score одной пачкой (awardBulk)
  await ReputationService.awardBulk({
    userIds: [user.id],
    eventType: 'job_matched',
    weight: 2,
    payload: {
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      matchConfidence: match,
    },
    impactPayload: { rating: match * 5 },
  });

  return json({ application: app, matchConfidence: match }, 201);
});
