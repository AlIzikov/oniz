// BizON API — /api/jobs/[id]/apply-via-contact (Путь C: отклик через общий контакт)
// Body: { contactId: string, message?: string }
// Contact получает запрос «порекомендуй меня» (через ColleagueInquiry + Notification).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'jobs:apply', ...MUTATION_LIMITS.jobsApply);
  if (!rl.allowed) return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);

  const job = await db.job.findUnique({
    where: { id },
    include: { hiringManager: { select: { id: true, name: true } } },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  let body: any = {};
  try { body = await req.json() ?? {}; } catch { body = {}; }

  const { contactId, message } = body ?? {};
  if (typeof contactId !== 'string' || contactId.length === 0) {
    return errorJson('contactId обязателен', 422);
  }
  if (contactId === user.id) {
    return errorJson('Нельзя рекомендовать самого себя', 422);
  }

  // Проверяем, что контакт существует
  const contact = await db.user.findUnique({
    where: { id: contactId },
    select: { id: true, name: true, title: true, avatarUrl: true },
  });
  if (!contact) return errorJson('Контакт не найден', 404);

  // Проверяем, что контакт действительно является общим (connection accepted ИЛИ общий проект)
  const [conn, sharedProject] = await Promise.all([
    db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: user.id, toUserId: contactId, status: 'accepted' },
          { fromUserId: contactId, toUserId: user.id, status: 'accepted' },
        ],
      },
      select: { id: true },
    }),
    (async () => {
      const myProjects = await db.projectMember.findMany({
        where: { userId: user.id },
        select: { projectId: true },
      });
      if (myProjects.length === 0) return null;
      return db.projectMember.findFirst({
        where: {
          userId: contactId,
          projectId: { in: myProjects.map(p => p.projectId) },
        },
        select: { id: true },
      });
    })(),
  ]);

  if (!conn && !sharedProject) {
    return errorJson(
      'Этот контакт не является общим — нет ни accepted connection, ни общего проекта.',
      403,
    );
  }

  const note = typeof message === 'string' ? message.trim().slice(0, 2000) : '';

  // Создаём ColleagueInquiry — запрос «порекомендуй меня» (aboutUser = сам кандидат,
  // поскольку мы спрашиваем «какой я работник?». Но ColleagueInquiry требует, чтобы
  // toUser (contact) и aboutUser имели общий проект. Поскольку наш кандидат и contact
  // уже имеют общий проект (мы это проверили выше) — aboutUserId = user.id подходит.
  // Гарантируем, что есть общий проект между contact и user (уже проверено выше).
  let inquiryId: string | null = null;
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 дней
  try {
    const inquiry = await db.colleagueInquiry.create({
      data: {
        fromUserId: user.id,
        toUserId: contactId,
        aboutUserId: job.hiringManagerId ?? user.id, // спрашиваем про HM (если есть) или про себя
        message: `Порекомендуй меня для вакансии «${job.title}» в ${job.company}${note ? `: ${note}` : ''}`,
        isAnonymous: false,
        expiresAt,
      },
    });
    inquiryId = inquiry.id;
  } catch (e) {
    // Fallback: если ColleagueInquiry не получилось (например, contact и aboutUser не имеют общего проекта)
    // — просто используем Notification
    console.error('[apply-via-contact] ColleagueInquiry create failed:', e);
  }

  // Уведомление контакту: «Порекомендуй меня»
  const notif = await db.notification.create({
    data: {
      userId: contactId,
      type: 'colleague_inquiry',
      title: `${user.name} просит рекомендации для вакансии «${job.title}»`,
      content: note || `Здравствуйте! Порекомендуйте меня, пожалуйста, для этой вакансии.`,
      link: '/me',
    },
  }).catch(() => null);
  if (notif) notifyNotificationNew(contactId, notif);

  // Создаём JobApplication с applyPath='via_contact' (статус 'submitted' но с пометкой)
  const existing = await db.jobApplication.findUnique({
    where: { jobId_userId: { jobId: id, userId: user.id } },
  }).catch(() => null);

  let application;
  if (existing && existing.status !== 'withdrawn') {
    application = await db.jobApplication.update({
      where: { id: existing.id },
      data: {
        applyPath: 'via_contact',
        coverLetter: note || existing.coverLetter,
      },
    });
  } else if (existing) {
    application = await db.jobApplication.update({
      where: { id: existing.id },
      data: {
        status: 'submitted',
        applyPath: 'via_contact',
        coverLetter: note || null,
        hiringManagerResponse: null,
      },
    });
  } else {
    application = await db.jobApplication.create({
      data: {
        jobId: id,
        userId: user.id,
        status: 'submitted',
        applyPath: 'via_contact',
        coverLetter: note || null,
      },
    });

    // Event Bus: отклик отправлен — только при СОЗДАНИИ заявки
    // (публикация не должна ломать отклик)
    try {
      void EventBus.publish('job.applied', {
        userId: user.id,
        jobId: job.id,
        jobTitle: job.title,
      }).catch(() => undefined);
    } catch {
      // fail-open: ошибки шины игнорируем
    }
  }

  return json({
    application,
    contact: { id: contact.id, name: contact.name },
    inquiryId,
    message: `Запрос отправлен контакту: ${contact.name}. Ожидайте рекомендации.`,
  }, 201);
}
