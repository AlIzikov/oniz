// BizON API — POST /api/jobs/[id]/view (v6.1, Task 7-c)
// Лёгкая точка отметки ПРОСМОТРА вакансии. Фронт вызывает её при открытии
// деталей вакансии (контракт задокументирован в /api/jobs/[id]/growth).
//
// Делает две вещи (idемпотентно, ≤1 раза в сутки на пользователя/вакансию):
//   1. Публикует job.viewed в Event Bus (замыкание звена ACTION цикла
//      PERSON→…→NEXT LEVEL; долг Task 4-e; сигнал для AI Insights
//      «Мы заметили интерес» / bizon-signal).
//   2. Пишет ActionEvent(type='job_viewed', metadata {jobId}) — Professional
//      Memory / траектория поведения. Дедуп: если такой ActionEvent за текущий
//      UTC-день уже есть (createdAt >= startOfDay), событие НЕ дублируется.
//
// Ответ: { ok: true, counted: boolean } — counted=false при дедупе.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const job = await db.job.findUnique({
    where: { id },
    select: { id: true, title: true },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  // Дедуп: один ActionEvent 'job_viewed' на пользователя/вакансию в сутки (UTC).
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);

  const todayEvents = await db.actionEvent.findMany({
    where: {
      userId: user.id,
      type: 'job_viewed',
      createdAt: { gte: startOfDay },
    },
    select: { metadata: true },
    take: 100,
  });

  const alreadyViewed = todayEvents.some((e) => {
    if (!e.metadata) return false;
    try {
      const meta = JSON.parse(e.metadata) as Record<string, unknown>;
      return meta.jobId === job.id;
    } catch {
      return false;
    }
  });

  if (!alreadyViewed) {
    // ActionEvent — траектория поведения (Professional Memory). Пишем напрямую
    // (type='job_viewed' не входит в ActionEventType-union Professional Moments —
    // это поведение, а не момент). metadata.jobTitle — контракт с coach-service
    // (Task 7-d): гипотеза job_interest («Мы заметили интерес») токенизирует
    // именно jobTitle из metadata просмотров.
    await db.actionEvent
      .create({
        data: {
          userId: user.id,
          type: 'job_viewed',
          title: `Смотрел вакансию «${job.title}»`,
          metadata: JSON.stringify({ jobId: job.id, jobTitle: job.title }),
          isPublic: false, // поведение приватно, в отличие от Moments
        },
      })
      .catch(() => undefined);

    // Event Bus: замыкание ACTION (job.viewed). Ошибки шины не влияют на ответ.
    try {
      void EventBus.publish('job.viewed', {
        userId: user.id,
        jobId: job.id,
        jobTitle: job.title,
      }).catch(() => undefined);
    } catch {
      // fail-open
    }
  }

  return json({ ok: true, counted: !alreadyViewed });
}
