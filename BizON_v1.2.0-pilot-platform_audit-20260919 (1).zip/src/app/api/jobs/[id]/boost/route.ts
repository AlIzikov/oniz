// BizON API — /api/jobs/[id]/boost (Платное продвижение — заглушка)
// Помечает boosted=true, boostedUntil = +7 дней.
// Доступ: admin или company owner (пользователь, чья компания владеет вакансией).
// FIX-07: withRoute — auth 401, единый маппинг ошибок (Prisma P2002→409, P2025→404),
// без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { notifyNotificationNew } from '@/lib/chat-notify';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли

export const runtime = 'nodejs';

const BOOST_DURATION_DAYS = 7;

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const { id } = ctx.params;
  const user = ctx.user!;

  const job = await db.job.findUnique({ where: { id } });
  if (!job) return errorJson('Вакансия не найдена', 404);

  // Проверка прав: admin или владелец компании
  const isOwner = job.companyId && user.companyId === job.companyId &&
    (user.accountType === 'company' || user.accountType === 'hr_agency');
  if (!isAdminRole(user.roles) && !isOwner) {
    return errorJson('Нет прав на продвижение этой вакансии', 403);
  }

  // === Заглушка платного продвижения ===
  // В реальной системе здесь был бы платёжный шаг (payment-service),
  // списание с баланса компании или активация подписки. Сейчас — сразу помечаем.
  const boostedUntil = new Date(Date.now() + BOOST_DURATION_DAYS * 24 * 60 * 60 * 1000);

  const updated = await db.job.update({
    where: { id },
    data: {
      boosted: true,
      boostedUntil,
    },
  });

  // Уведомление владельцу компании (если он не тот, кто делает запрос)
  if (job.companyId && user.companyId !== job.companyId) {
    const notif = await db.notification.create({
      data: {
        userId: user.id, // упрощённо — самому себе
        type: 'system',
        title: `Вакансия «${job.title}» продвигается`,
        content: `Платное продвижение активно до ${boostedUntil.toLocaleDateString('ru-RU')}. ФЗ-38: реклама.`,
        link: '/jobs',
      },
    }).catch(() => null);
    if (notif) notifyNotificationNew(user.id, notif);
  }

  return json({
    job: {
      id: updated.id,
      boosted: updated.boosted,
      boostedUntil: updated.boostedUntil?.toISOString() ?? null,
    },
    // ФЗ-38 маркировка: рекламируется
    adLabel: 'Реклама',
    boostedUntilDays: BOOST_DURATION_DAYS,
  });
});

// Снять продвижение (опционально)
export const DELETE = withRoute<{ id: string }>(async (req, ctx) => {
  const { id } = ctx.params;
  const user = ctx.user!;

  const job = await db.job.findUnique({ where: { id } });
  if (!job) return errorJson('Вакансия не найдена', 404);

  const isOwner = job.companyId && user.companyId === job.companyId &&
    (user.accountType === 'company' || user.accountType === 'hr_agency');
  if (!isAdminRole(user.roles) && !isOwner) {
    return errorJson('Нет прав на снятие продвижения', 403);
  }

  const updated = await db.job.update({
    where: { id },
    data: { boosted: false, boostedUntil: null },
  });

  return json({ job: { id: updated.id, boosted: false, boostedUntil: null } });
});
