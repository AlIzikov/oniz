// BizON API — /api/jobs/[id]/match-explain
// P0-5 (ЧАСТЬ 7, 11): BIZON MATCH — двусторонний + explainable.
//
// v6.1 (Task 7-c): «Карта соответствия» — 8 компонент (Стратегия «Вакансии →
// Работа», п.5). Каждый 0..1; 87% — не рейтинг человека, а степень соответствия
// конкретной вакансии:
//   {
//     overall: 0..1,
//     breakdown: { skills, experience, level, industry, projects, location, salary, careerGoal }, // 0..1
//     reasons: string[],   // «Почему вы подходите» (≤3)
//     missing: string[],   // «Что не совпадает» ⚠️ (≤3)
//     candidateFit, companyFit (null если нет Cultural Signals), totalMatch,
//     classicBreakdown: { skills: {score, matched, missing}, trust, growth }, // легаси P0-5
//     why, whatYouGet, whatCompanyGets, context
//   }
// Честность (правка аудита 6-b): companyFit больше НЕ заглушка 88 — если у
// компании нет Cultural Signals, companyFit=null и totalMatch=candidateFit.
//   • verifiedProjectsCount — завершённые проекты кандидата
//   • commonContactsCount — пересечение контактов кандидата и hiring manager
//   • similarProjectsCount — проекты кандидата с пересечением по навыкам
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { computeJobMatchExplainable } from '@/lib/ai';
import { IntentService } from '@/lib/services/intent-service';
import { parseRequiredSkillsWithLevels } from '@/lib/services/job-growth-service';

export const runtime = 'nodejs';

// --- helpers для 8 компонент ---

function clamp01(v: number): number {
  return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : 0;
}

function round2(v: number): number {
  return Math.round(clamp01(v) * 100) / 100;
}

/** Требуемый «стаж» по уровню вакансии (эвристика 0..1). */
function needExperience(level: string | null): number {
  switch ((level ?? '').toLowerCase()) {
    case 'junior': return 0.25;
    case 'middle': return 0.45;
    case 'senior': return 0.65;
    case 'lead': return 0.8;
    case 'director': return 1.0;
    default: return 0.5;
  }
}

/** Seniority пользователя из title/roles (эвристика 1..5). */
function userSeniority(title: string | null, roles: string | null): number {
  const text = `${title ?? ''} ${roles ?? ''}`.toLowerCase();
  if (/(директор|director|ceo|cto|cfo|cmo|coo|\bvp\b|chief)/i.test(text)) return 5;
  if (/(lead|head|лид|тимлид|главный)/i.test(text)) return 4;
  if (/(senior|сеньор|старший)/i.test(text)) return 3;
  if (/(middle|миддл)/i.test(text)) return 2;
  if (/(junior|джун|начинающ)/i.test(text)) return 1;
  return 2; // дефолт — middle
}

/** Seniority вакансии по Job.level (1..5, null если не указан). */
function jobSeniority(level: string | null): number | null {
  switch ((level ?? '').toLowerCase()) {
    case 'junior': return 1;
    case 'middle': return 2;
    case 'senior': return 3;
    case 'lead': return 4;
    case 'director': return 5;
    default: return null;
  }
}

function isRemoteJob(job: { workFormat: string | null; location: string | null; description: string | null }): boolean {
  if ((job.workFormat ?? '').toLowerCase() === 'remote') return true;
  const text = `${job.location ?? ''} ${job.description ?? ''}`.toLowerCase();
  return /удал[её]н|remote|дистанционн/.test(text);
}

const STOP_WORDS_RU_EN = new Set([
  'и', 'в', 'на', 'с', 'по', 'для', 'от', 'до', 'под', 'при', 'или', 'the', 'and', 'for', 'with', 'a', 'of', 'to', 'in',
  'работа', 'работы', 'требуется', 'опыт', 'знание', 'навыки', 'умение', 'обязанности', 'требования', 'нашего',
]);

/** Ключевые слова описания вакансии (для релевантности проектов). */
function jobKeywords(title: string, description: string): string[] {
  const raw = `${title} ${description}`
    .toLowerCase()
    .split(/[^\wа-яё+.#]+/iu)
    .filter((w) => w.length >= 4 && !STOP_WORDS_RU_EN.has(w));
  return [...new Set(raw)].slice(0, 40);
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const job = await db.job.findUnique({
    where: { id },
    include: {
      companyRel: {
        select: {
          id: true,
          name: true,
          industry: true,
          culturalScore: true,
        },
      },
      hiringManager: {
        select: { id: true, name: true, title: true, avatarUrl: true },
      },
    },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  // ---------- 1. Навыки кандидата ----------
  const userSkillsRows = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkillsRows.map((us) => us.skill.name);
  // v6.1: requiredSkills могут быть с уровнями «Навык:L» — отделяем имя от уровня
  // (и для матчинга навыков, и для человекочитаемых missing).
  const parsedRequired = parseRequiredSkillsWithLevels(job.requiredSkills);
  const requiredSkills = parsedRequired.map((r) => r.name).filter(Boolean);

  // ---------- 2. Verified projects count ----------
  // Завершённые проекты пользователя (status='completed').
  const verifiedProjects = await db.projectMember.findMany({
    where: { userId: user.id, project: { status: 'completed' } },
    select: { projectId: true, project: { select: { id: true, title: true, tags: true, requiredSkills: true } } },
  });
  const verifiedProjectsCount = verifiedProjects.length;

  // ---------- 3. Similar projects count ----------
  // Проекты пользователя, где теги / requiredSkills пересекаются с требованиями вакансии.
  const requiredLower = requiredSkills.map((s) => s.toLowerCase());
  const similarProjectsCount = verifiedProjects.filter((m) => {
    const tags = (m.project.tags ?? '').split(',').filter(Boolean).map((t) => t.toLowerCase());
    const projSkills = (m.project.requiredSkills ?? '').split(',').filter(Boolean).map((s) => s.toLowerCase());
    const combined = [...tags, ...projSkills];
    return requiredLower.some((r) => combined.includes(r));
  }).length;

  // ---------- 4. Common contacts with hiring manager ----------
  let commonContactsCount = 0;
  if (job.hiringManagerId && job.hiringManagerId !== user.id) {
    const [myConns, hmConns] = await Promise.all([
      db.connection.findMany({
        where: { status: 'accepted', OR: [{ fromUserId: user.id }, { toUserId: user.id }] },
        select: { fromUserId: true, toUserId: true },
      }),
      db.connection.findMany({
        where: { status: 'accepted', OR: [{ fromUserId: job.hiringManagerId }, { toUserId: job.hiringManagerId }] },
        select: { fromUserId: true, toUserId: true },
      }),
    ]);
    const myIds = new Set<string>();
    for (const c of myConns) {
      if (c.fromUserId === user.id) myIds.add(c.toUserId);
      else if (c.toUserId === user.id) myIds.add(c.fromUserId);
    }
    myIds.delete(job.hiringManagerId);
    const hmIds = new Set<string>();
    for (const c of hmConns) {
      if (c.fromUserId === job.hiringManagerId) hmIds.add(c.toUserId);
      else if (c.toUserId === job.hiringManagerId) hmIds.add(c.fromUserId);
    }
    hmIds.delete(user.id);
    let inter = 0;
    for (const id2 of myIds) if (hmIds.has(id2)) inter++;
    commonContactsCount = inter;
  }

  // ---------- 5. Cultural Fit Score ----------
  // Если у компании есть Cultural Signals — усредняем rating опубликованных отзывов.
  // v6.1: БЕЗ заглушки 88 — если сигналов нет, companyFit будет null (честно).
  let culturalFitScore: number | undefined;
  if (job.companyRel) {
    const signals = await db.culturalSignal.findMany({
      where: { companyId: job.companyRel.id, status: 'published' },
      select: { rating: true },
    });
    if (signals.length > 0) {
      const avg = signals.reduce((s, r) => s + r.rating, 0) / signals.length;
      // rating 1..5 → 0..100
      culturalFitScore = Math.round((avg / 5) * 100);
    }
  }

  // ---------- 6. Compute explainable match ----------
  const result = computeJobMatchExplainable({
    userSkills: userSkillNames,
    userIpScore: user.ipScore,
    job: {
      id: job.id,
      title: job.title,
      company: job.company,
      requiredSkills,
      growthScore: job.growthScore,
    },
    verifiedProjectsCount,
    commonContactsCount,
    similarProjectsCount,
    culturalFitScore,
  });

  // ======================================================================
  // v6.1 (Task 7-c): «Карта соответствия» — 8 компонент 0..1
  // ======================================================================

  // --- (1) skills: совпадение requiredSkills ---
  const skills = round2(result.breakdown.skills.score / 100);

  // --- (2) experience: опыт пользователя vs требования уровня вакансии ---
  const verifiedSkillsCount = userSkillsRows.filter((us) => us.verificationLevel !== 'claimed').length;
  const userExperience = clamp01(
    (user.ipScore / 100) * 0.5 +
      Math.min(1, verifiedProjectsCount / 5) * 0.3 +
      Math.min(1, verifiedSkillsCount / 8) * 0.2,
  );
  const needExp = needExperience(job.level);
  const experience = round2(needExp <= userExperience ? 1 : userExperience / needExp);

  // --- (3) level: seniority fit ---
  const js = jobSeniority(job.level);
  const us = userSeniority(user.title, user.roles);
  const level = round2(
    js === null
      ? 0.6 // уровень вакансии не указан — нейтрально
      : Math.abs(js - us) === 0
        ? 1
        : Math.abs(js - us) === 1
          ? 0.7
          : Math.abs(js - us) === 2
            ? 0.4
            : 0.2,
  );

  // --- (4) industry: Job.industry vs опыт/навыки пользователя ---
  let industry: number;
  if (!job.industry) {
    industry = 0.6; // отрасль не указана — нейтрально
  } else {
    const indLower = job.industry.toLowerCase();
    const profileText = [
      ...userSkillNames,
      user.title ?? '',
      user.roles ?? '',
      ...verifiedProjects.map((m) => `${m.project.title} ${(m.project.tags ?? '')} ${(m.project.requiredSkills ?? '')}`),
    ]
      .join(' ')
      .toLowerCase();
    industry = profileText.includes(indLower) ? 1 : 0.4;
  }
  industry = round2(industry);

  // --- (5) projects: релевантность проектов описанию (по ключевым словам) ---
  const keywords = jobKeywords(job.title, job.description);
  let projects: number;
  if (verifiedProjects.length === 0) {
    projects = 0.3; // проектов нет — оценённая нейтральная база
  } else if (keywords.length === 0) {
    projects = 0.5;
  } else {
    let best = 0;
    for (const m of verifiedProjects) {
      const pText = `${m.project.title} ${(m.project.tags ?? '')} ${(m.project.requiredSkills ?? '')}`.toLowerCase();
      const hits = keywords.filter((k) => pText.includes(k)).length;
      best = Math.max(best, hits / keywords.length);
    }
    projects = round2(Math.min(1, best + (similarProjectsCount > 0 ? 0.1 : 0)));
  }

  // --- (6) location: локация/удалённость ---
  const userLocation = (user.location ?? '').trim();
  const remote = isRemoteJob(job);
  let location: number;
  if (remote) {
    location = 0.9; // удалёнка — подходит почти всем
  } else if (!userLocation) {
    location = 0.5;
  } else if (!job.location) {
    location = 0.6;
  } else {
    const ul = userLocation.toLowerCase();
    const jl = job.location.toLowerCase();
    location = ul.includes(jl.split(/[(,]/)[0].trim()) || jl.includes(ul.split(/[(,]/)[0].trim()) ? 1 : 0.3;
  }
  location = round2(location);

  // --- (7) salary: вилка vs предпочтения пользователя (если есть) ---
  const jobHasSalary =
    job.salaryMin != null || job.salaryMax != null || job.salaryFrom != null || job.salaryTo != null;
  // Зарплатные предпочтения пользователя в профиле не хранятся (модель User без
  // salary-полей) — честная нейтральная оценка, без выдуманных данных.
  const salary = round2(jobHasSalary ? 0.6 : 0.5);

  // --- (8) careerGoal: рост × близость к карьерному intent ---
  const activeIntents = await IntentService.getActiveIntentTypes(user.id);
  const proximity = activeIntents.has('promotion') || activeIntents.has('career_change')
    ? 1
    : activeIntents.has('job_search')
      ? 0.8
      : activeIntents.has('skill_development') || activeIntents.has('learning')
        ? 0.6
        : 0.5; // нет активных намерений — нейтрально
  const careerGoal = round2((job.growthScore ?? 0) * (0.5 + 0.5 * proximity));

  // --- overall: взвешенная сумма 8 компонент ---
  const overall = round2(
    skills * 0.25 +
      experience * 0.15 +
      level * 0.1 +
      industry * 0.05 +
      projects * 0.1 +
      location * 0.1 +
      salary * 0.1 +
      careerGoal * 0.15,
  );

  // --- reasons (2-3 коротких) / missing (⚠️, максимум 2) ---
  const reasons: string[] = [];
  if (requiredSkills.length > 0) {
    reasons.push(
      `${result.breakdown.skills.matched.length} из ${requiredSkills.length} навыков совпадает`,
    );
  }
  if (level >= 0.7 && experience >= 0.7) reasons.push('уровень и опыт соответствуют позиции');
  if (remote) reasons.push('удалённая работа');
  if (industry === 1) reasons.push(`есть опыт в отрасли «${job.industry}»`);
  if (careerGoal >= 0.6) reasons.push('высокий потенциал карьерного роста');
  if (similarProjectsCount > 0) reasons.push(`есть похожий проект: ${similarProjectsCount}`);

  const missing: string[] = result.breakdown.skills.missing
    .slice(0, 2)
    .map((s) => {
      const req = parsedRequired.find((r) => r.name.toLowerCase() === s.toLowerCase());
      return req?.level != null ? `требуется ${s} (уровень ${req.level})` : `требуется ${s}`;
    });
  if (js !== null && Math.abs(js - us) >= 2) {
    missing.push(`позиция уровня ${job.level}, ваш профиль выглядит как уровень ${us}`);
  }

  // ---------- 7. Честный Company Fit (v6.1: без заглушки 88) ----------
  const companyFit = typeof culturalFitScore === 'number' ? result.companyFit : null;
  const totalMatch = companyFit === null ? result.candidateFit : result.totalMatch;

  return json({
    candidateFit: result.candidateFit,
    companyFit, // v6.1: null если нет Cultural Signals (была заглушка 88)
    totalMatch,
    // v6.1: Карта соответствия — 8 компонент (0..1) — основной контракт
    overall,
    breakdown: {
      skills,
      experience,
      level,
      industry,
      projects,
      location,
      salary,
      careerGoal,
    },
    reasons: reasons.slice(0, 3),
    missing: missing.slice(0, 3),
    // Легаси-разбивка P0-5 (skills/trust/growth) — сохранена для старых потребителей
    classicBreakdown: result.breakdown,
    why: result.why,
    whatYouGet: result.whatYouGet,
    whatCompanyGets: result.whatCompanyGets,
    // Доп. контекст, полезный для UI:
    context: {
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      companyId: job.companyRel?.id ?? null,
      culturalFitScore: culturalFitScore ?? null,
      companyFitAvailable: typeof culturalFitScore === 'number', // v6.1: замена isStub
      commonContactsCount,
      verifiedProjectsCount,
      similarProjectsCount,
    },
  });
}
