// BizON API — /api/jobs/[id]/verify (Phase 2 — Verified Vacancy)
// POST — пересчитать статус верификации вакансии и сохранить в БД.
// Доступ: владелец компании / админ / hiring manager этой вакансии.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { VacancyVerificationService } from '@/lib/services/vacancy-verification-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const job = await db.job.findUnique({
    where: { id },
    select: { id: true, companyId: true, hiringManagerId: true },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  // Доступ: админ / hiring manager / владелец компании (accountType company и companyId === job.companyId)
  // FIX-02: проверка роли через единый isAdminRole
  const isAdmin = isAdminRole(user.roles);
  const isHm = job.hiringManagerId === user.id;

  let isCompanyOwner = false;
  if (job.companyId && user.companyId === job.companyId && (user.accountType === 'company' || user.accountType === 'hr_agency')) {
    isCompanyOwner = true;
  }

  if (!isAdmin && !isHm && !isCompanyOwner) {
    return errorJson('Нет прав на верификацию этой вакансии', 403);
  }

  const result = await VacancyVerificationService.apply(id);
  if (!result) return errorJson('Не удалось посчитать верификацию', 500);

  return json({ verification: result });
}
