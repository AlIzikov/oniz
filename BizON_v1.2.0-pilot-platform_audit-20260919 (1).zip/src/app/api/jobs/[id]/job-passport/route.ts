// BizON API — /api/jobs/[id]/job-passport (Phase 3 — Job Passport)
// GET — объединяет match-explain + hiring-reality + company trust в один ответ.
// Используется в Job Passport карточке (src/components/jobs/job-passport.tsx).
//
// Ответ:
//   {
//     job: { id, title, company, companyId, ... },
//     match: { candidateFit, companyFit, totalMatch, breakdown, why, whatYouGet, whatCompanyGets },
//     hiringReality: { score, level, criteria },
//     companyTrust: { employerTrust, businessTrust, deliveryTrust, transparency, overall },
//     responseTimeHours,             // усреднённое время ответа HM (если есть)
//     recommendation: 'apply' | 'skip',   // эвристика BizON
//     recommendationReason: string
//   }
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { computeJobMatchExplainable } from '@/lib/ai';
import { HiringRealityService } from '@/lib/services/hiring-reality-service';
import { CompanyTrustService } from '@/lib/services/company-trust-service';
import { TimeValueService } from '@/lib/services/time-value-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const job = await db.job.findUnique({
    where: { id },
    include: {
      companyRel: {
        select: {
          id: true,
          name: true,
          industry: true,
          culturalScore: true,
        },
      },
      hiringManager: {
        select: { id: true, name: true, title: true, avatarUrl: true },
      },
    },
  });
  if (!job) return errorJson('Вакансия не найдена', 404);

  // =========================================================================
  // 1. Match-explain (повторяет логику /api/jobs/[id]/match-explain)
  // =========================================================================
  const userSkillsRows = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkillsRows.map((us) => us.skill.name);
  const requiredSkills = job.requiredSkills ? job.requiredSkills.split(',').filter(Boolean) : [];

  const verifiedProjects = await db.projectMember.findMany({
    where: { userId: user.id, project: { status: 'completed' } },
    select: { projectId: true, project: { select: { id: true, title: true, tags: true, requiredSkills: true } } },
  });
  const verifiedProjectsCount = verifiedProjects.length;

  const requiredLower = requiredSkills.map((s) => s.toLowerCase());
  const similarProjectsCount = verifiedProjects.filter((m) => {
    const tags = (m.project.tags ?? '').split(',').filter(Boolean).map((t) => t.toLowerCase());
    const projSkills = (m.project.requiredSkills ?? '').split(',').filter(Boolean).map((s) => s.toLowerCase());
    const combined = [...tags, ...projSkills];
    return requiredLower.some((r) => combined.includes(r));
  }).length;

  let commonContactsCount = 0;
  if (job.hiringManagerId && job.hiringManagerId !== user.id) {
    const [myConns, hmConns] = await Promise.all([
      db.connection.findMany({
        where: { status: 'accepted', OR: [{ fromUserId: user.id }, { toUserId: user.id }] },
        select: { fromUserId: true, toUserId: true },
      }),
      db.connection.findMany({
        where: { status: 'accepted', OR: [{ fromUserId: job.hiringManagerId }, { toUserId: job.hiringManagerId }] },
        select: { fromUserId: true, toUserId: true },
      }),
    ]);
    const myIds = new Set<string>();
    for (const c of myConns) {
      if (c.fromUserId === user.id) myIds.add(c.toUserId);
      else if (c.toUserId === user.id) myIds.add(c.fromUserId);
    }
    myIds.delete(job.hiringManagerId);
    const hmIds = new Set<string>();
    for (const c of hmConns) {
      if (c.fromUserId === job.hiringManagerId) hmIds.add(c.toUserId);
      else if (c.toUserId === job.hiringManagerId) hmIds.add(c.fromUserId);
    }
    hmIds.delete(user.id);
    let inter = 0;
    for (const id2 of myIds) if (hmIds.has(id2)) inter++;
    commonContactsCount = inter;
  }

  let culturalFitScore: number | undefined;
  if (job.companyRel) {
    const signals = await db.culturalSignal.findMany({
      where: { companyId: job.companyRel.id, status: 'published' },
      select: { rating: true },
    });
    if (signals.length > 0) {
      const avg = signals.reduce((s, r) => s + r.rating, 0) / signals.length;
      culturalFitScore = Math.round((avg / 5) * 100);
    }
  }

  const matchResult = computeJobMatchExplainable({
    userSkills: userSkillNames,
    userIpScore: user.ipScore,
    job: {
      id: job.id,
      title: job.title,
      company: job.company,
      requiredSkills,
      growthScore: job.growthScore,
    },
    verifiedProjectsCount,
    commonContactsCount,
    similarProjectsCount,
    culturalFitScore,
  });

  // =========================================================================
  // 2. Hiring Reality Index
  // =========================================================================
  const hiringReality = await HiringRealityService.evaluate(id);
  // Не должно быть null (job существует), но на всякий случай — fallback.
  const hiringRealityPublic = hiringReality
    ? {
        score: hiringReality.score,
        level: hiringReality.level,
        criteria: hiringReality.criteria.map((c) => ({
          name: c.name,
          passed: c.passed,
          points: c.points,
          ...(c.detail ? { detail: c.detail } : {}),
        })),
      }
    : { score: 0, level: 'low' as const, criteria: [] };

  // =========================================================================
  // 3. Company Trust (4 индекса)
  // =========================================================================
  let companyTrust: {
    employerTrust: number;
    businessTrust: number;
    deliveryTrust: number;
    transparency: number;
    overall: number;
  } | null = null;
  if (job.companyRel) {
    const trust = await CompanyTrustService.calculate(job.companyRel.id);
    if (trust) {
      companyTrust = {
        employerTrust: trust.employerTrust,
        businessTrust: trust.businessTrust,
        deliveryTrust: trust.deliveryTrust,
        transparency: trust.transparency,
        overall: trust.overall,
      };
    }
  }

  // =========================================================================
  // 4. Response time — из HM или самой вакансии (если есть)
  // =========================================================================
  const responseTimeHours = job.responseTimeHours ?? null;

  // =========================================================================
  // 5. BizON рекомендация (legacy эвристика — оставлена для обратной совместимости):
  //    apply / skip. Phase 4 использует более точный TimeValueService ниже
  //    (apply / skip / consider).
  // =========================================================================
  const matchPct = matchResult.totalMatch;
  const hrScore = hiringRealityPublic.score;
  let recommendation: 'apply' | 'skip' = 'skip';
  let recommendationReason = '';
  if (matchPct >= 80) {
    recommendation = 'apply';
    recommendationReason = 'Отличное совпадение навыков — высокая ценность отклика';
  } else if (matchPct >= 60 && hrScore >= 50) {
    recommendation = 'apply';
    recommendationReason = 'Хорошее совпадение + реальная вакансия — стоит откликнуться';
  } else if (matchPct >= 40 && hrScore >= 70) {
    recommendation = 'apply';
    recommendationReason = 'Среднее совпадение, но наниматель активен и реален';
  } else if (matchPct < 30 || hrScore < 30) {
    recommendation = 'skip';
    recommendationReason = 'Низкое совпадение или признаки нереальной вакансии — не тратьте время';
  } else {
    recommendation = 'skip';
    recommendationReason = 'Слабая ценность отклика — лучше поискать другие варианты';
  }

  // =========================================================================
  // 6. Phase 4 — BIZON TIME VALUE: apply / skip / consider + factors
  //    Формула ТЗ: match > 80 AND hiringReality > 70 AND salary matches → 'apply'
  //                match < 60 OR hiringReality < 40                  → 'skip'
  //                иначе                                              → 'consider'
  // =========================================================================
  const timeValue = await TimeValueService.evaluate(id, user.id);

  // Контекст для блока «Почему вам подходит» — какие навыки подтверждены,
  // сколько похожих проектов, каких навыков не хватает (для кнопки PROVE IT).
  const matchedSkills = matchResult.breakdown.skills.matched;
  const missingSkills = matchResult.breakdown.skills.missing;
  const totalRequiredSkills = requiredSkills.length;
  const verifiedSkillsMatched = totalRequiredSkills > 0
    ? `${matchedSkills.length}/${totalRequiredSkills}`
    : '0/0';

  return json({
    job: {
      id: job.id,
      title: job.title,
      company: job.company,
      companyId: job.companyRel?.id ?? null,
      companyName: job.companyRel?.name ?? job.company,
      location: job.location,
      salaryMin: job.salaryMin ?? job.salaryFrom,
      salaryMax: job.salaryMax ?? job.salaryTo,
      currency: job.currency,
      createdAt: job.createdAt.toISOString(),
      hiringManager: job.hiringManager
        ? {
            id: job.hiringManager.id,
            name: job.hiringManager.name,
            title: job.hiringManager.title,
            avatarUrl: job.hiringManager.avatarUrl,
          }
        : null,
    },
    match: {
      candidateFit: matchResult.candidateFit,
      companyFit: matchResult.companyFit,
      totalMatch: matchResult.totalMatch,
      breakdown: matchResult.breakdown,
      why: matchResult.why,
      whatYouGet: matchResult.whatYouGet,
      whatCompanyGets: matchResult.whatCompanyGets,
    },
    hiringReality: hiringRealityPublic,
    companyTrust,
    responseTimeHours,
    // Legacy recommendation (apply/skip) — оставлена для обратной совместимости
    // со старым UI. Phase 4 UI использует timeValue.recommendation (3-state).
    recommendation,
    recommendationReason,
    // === Phase 4 — BIZON TIME VALUE ===
    timeValue: {
      recommendation: timeValue.recommendation,
      reason: timeValue.reason,
      factors: timeValue.factors,
      computedAt: timeValue.computedAt,
    },
    // Контекст «Почему вам подходит» — для UI (✓ N/M подтверждены, X нет навыка → PROVE IT)
    context: {
      verifiedProjectsCount,
      similarProjectsCount,
      commonContactsCount,
      matchedSkills,
      missingSkills,
      verifiedSkillsMatched,
      totalRequiredSkills,
    },
  });
}
