// BizON API — /api/jobs/[id]/verification (Phase 2 — Verified Vacancy)
// GET — возвращает оценку верификации вакансии (8 критериев + score + status).
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { VacancyVerificationService } from '@/lib/services/vacancy-verification-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const result = await VacancyVerificationService.evaluate(id);
  if (!result) return errorJson('Вакансия не найдена', 404);

  return json({ verification: result });
}
