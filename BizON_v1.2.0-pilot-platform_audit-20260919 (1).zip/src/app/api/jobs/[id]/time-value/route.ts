// BizON API — /api/jobs/[id]/time-value (Phase 4 — BIZON TIME VALUE)
// GET — оценка «ценности времени» отклика на вакансию.
//
// Возвращает:
//   {
//     recommendation: 'apply' | 'skip' | 'consider',
//     reason: string,
//     factors: { match, hiringReality, salaryFit, trustFit },  // 0..100
//     computedAt: string
//   }
//
// Формула (ТЗ Phase 4):
//   apply    (высокая ценность): match > 80 AND hiringReality > 70 AND salary matches
//   skip     (не тратьте время): match < 60 OR  hiringReality < 40
//   consider (стоит рассмотреть): во всех остальных случаях
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { TimeValueService } from '@/lib/services/time-value-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const result = await TimeValueService.evaluate(id, user.id);

  return json({
    recommendation: result.recommendation,
    reason: result.reason,
    factors: result.factors,
    computedAt: result.computedAt,
  });
}
