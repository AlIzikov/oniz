// BizON API — POST /api/jobs/[id]/view-log (Wave 5, S-108/S-114, ТЗ 4.3 VIEW_LOG).
// Отметить просмотр вакансии (идемпотентно, ≤1/день).
// Календарь просмотров: GET /api/jobs/view-log/calendar.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { db } from '@/lib/db';
import { JobFiltersService } from '@/lib/services/job-filters-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const job = await db.job.findUnique({ where: { id: ctx.params.id }, select: { id: true } });
  if (!job) return NextResponse.json({ error: 'Вакансия не найдена' }, { status: 404 });
  const result = await JobFiltersService.logView(ctx.user.id, ctx.params.id);
  return NextResponse.json(result);
});
