// BizON API — GET /api/jobs/view-log/calendar (Wave 5, S-114, ТЗ 4.3 VIEW_LOG).
// Календарь просмотров вакансий по датам (личный, 30 дней).
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { JobFiltersService } from '@/lib/services/job-filters-service';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const sp = new URL(req.url).searchParams;
  const days = Number(sp.get('days') ?? '30');
  const calendar = await JobFiltersService.viewCalendar(ctx.user.id, Number.isFinite(days) ? Math.min(90, Math.max(7, days)) : 30);
  return NextResponse.json({ calendar });
});
