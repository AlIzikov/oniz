// BizON API — /api/jobs/saved (Избранные вакансии пользователя)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const saved = await db.savedJob.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: { job: true },
  });

  // Считаем match для текущего пользователя
  const userSkills = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkills.map(us => us.skill.name);

  return json({
    jobs: saved.map(s => {
      const requiredSkills = s.job.requiredSkills ? s.job.requiredSkills.split(',').filter(Boolean) : [];
      const overlap = requiredSkills.filter(s => userSkillNames.includes(s)).length;
      const match = requiredSkills.length === 0 ? 0.3 : overlap / requiredSkills.length;
      return {
        id: s.job.id,
        title: s.job.title,
        company: s.job.company,
        description: s.job.description,
        requiredSkills,
        salaryFrom: s.job.salaryFrom,
        salaryTo: s.job.salaryTo,
        location: s.job.location,
        growthScore: s.job.growthScore,
        matchConfidence: match,
        savedAt: s.createdAt.toISOString(),
        createdAt: s.job.createdAt.toISOString(),
      };
    }),
    total: saved.length,
  });
}
