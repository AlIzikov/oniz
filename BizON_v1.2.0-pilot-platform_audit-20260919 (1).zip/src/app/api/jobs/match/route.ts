// BizON API — /api/jobs/match
// AI-подбор вакансий: top-3 по matchConfidence + LLM-симмаризация
// H12: rate limit по тарифу + кэш на 1 час (LLM-генерация дорогая)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson, toUserPublic } from '@/lib/api-helpers';
import { computeJobMatch, generateJobMatchSummary } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

// H12: In-memory кэш на 1 час — key=userId, value={ data, expiresAt }
// LLM-генерация дорогая, результат не меняется часто
const CACHE_TTL = 60 * 60 * 1000; // 1 час
const cache = new Map<string, { data: any; expiresAt: number }>();

// Очистка кэша каждые 10 минут
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of cache) {
    if (entry.expiresAt < now) cache.delete(key);
  }
}, 10 * 60 * 1000);

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // H12: AI rate limit по тарифу — защита от LLM-billing DoS
  const [max, windowMs] = getAiLimitKey('jobsMatch', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:jobsMatch', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит AI-подбора вакансий исчерпан (${max} запросов в час для тарифа ${user.subscriptionTier}). Повторите через ${rl.retryAfter} секунд.`,
      429
    );
  }

  // H12: Проверяем кэш — если есть свежий результат, возвращаем без LLM-вызова
  const cached = cache.get(user.id);
  if (cached && cached.expiresAt > Date.now()) {
    return json({ ...cached.data, cached: true, cachedUntil: new Date(cached.expiresAt).toISOString() });
  }

  const userSkills = await db.userSkill.findMany({
    where: { userId: user.id },
    include: { skill: true },
  });
  const userSkillNames = userSkills.map((us) => us.skill.name);

  const jobs = await db.job.findMany({
    where: { active: true },
    take: 50,
  });

  const ranked = jobs
    .map((j) => {
      const requiredSkills = j.requiredSkills ? j.requiredSkills.split(',').filter(Boolean) : [];
      const match = computeJobMatch(userSkillNames, user.ipScore, {
        requiredSkills,
        growthScore: j.growthScore,
      });
      return {
        id: j.id,
        title: j.title,
        company: j.company,
        description: j.description,
        requiredSkills,
        salaryFrom: j.salaryFrom,
        salaryTo: j.salaryTo,
        location: j.location,
        growthScore: j.growthScore,
        matchConfidence: match,
        createdAt: j.createdAt.toISOString(),
      };
    })
    .sort((a, b) => b.matchConfidence - a.matchConfidence)
    .slice(0, 3);

  // LLM-симмаризация top-3
  const publicUser = await toUserPublic(user);
  const enriched = await Promise.all(
    ranked.map(async (j) => ({
      ...j,
      aiSummary: await generateJobMatchSummary(publicUser, j, j.matchConfidence),
    }))
  );

  const result = { jobs: enriched };

  // H12: Сохраняем в кэш на 1 час
  cache.set(user.id, { data: result, expiresAt: Date.now() + CACHE_TTL });

  return json({ ...result, cached: false });
}
