// BizON API — /api/colleague-inquiries
// R9 «Спроси у коллег»: создать личный запрос к коллеге с просьбой поделиться
// опытом работы с третьим человеком.
//
// POST — создать запрос. Валидация:
//   • toUserId должен иметь хотя бы один общий проект с aboutUserId
//   • лимит 3 запроса/неделю от одного fromUserId к одному toUserId
// GET  — список входящих pending-запросов для текущего пользователя
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_INQUIRIES_PER_PAIR_PER_WEEK = 3;
const MAX_MESSAGE_LENGTH = 2000;

/**
 * Проверяет, есть ли у toUser хотя бы один общий проект с aboutUser.
 * Ищем проекты, в которых оба числятся участниками.
 */
async function hasCommonProject(toUserId: string, aboutUserId: string): Promise<boolean> {
  // Находим проекты toUser
  const toUserMemberships = await db.projectMember.findMany({
    where: { userId: toUserId },
    select: { projectId: true },
  });
  if (toUserMemberships.length === 0) return false;

  const projectIds = toUserMemberships.map((m) => m.projectId);
  // Проверяем, есть ли aboutUser в любом из этих проектов
  const common = await db.projectMember.findFirst({
    where: { userId: aboutUserId, projectId: { in: projectIds } },
    select: { id: true },
  });
  return !!common;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const status = (req.nextUrl.searchParams.get('status') ?? 'pending') as
    | 'pending'
    | 'answered'
    | 'declined'
    | 'expired'
    | 'all';

  const where: any = { toUserId: user.id };
  if (status !== 'all') where.status = status;

  const inquiries = await db.colleagueInquiry.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      fromUser: {
        select: { id: true, name: true, title: true, avatarUrl: true },
      },
      aboutUser: {
        select: { id: true, name: true, title: true, avatarUrl: true },
      },
    },
  });

  return json({
    inquiries: inquiries.map((i) => ({
      id: i.id,
      message: i.message,
      status: i.status,
      response: i.response,
      isAnonymous: i.isAnonymous,
      createdAt: i.createdAt.toISOString(),
      answeredAt: i.answeredAt?.toISOString() ?? null,
      expiresAt: i.expiresAt.toISOString(),
      // Если анонимно — скрываем имя fromUser
      fromUser: i.isAnonymous
        ? { id: null, name: 'Аноним', title: null, avatarUrl: null }
        : i.fromUser,
      aboutUser: i.aboutUser,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(
    user.id,
    'colleagueInquiries:create',
    ...MUTATION_LIMITS.connectionsCreate,
  );
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { toUserId, aboutUserId, message, isAnonymous = false } = body ?? {};

    // === Валидация входных данных ===
    if (!toUserId || typeof toUserId !== 'string') {
      return errorJson('toUserId обязателен', 422);
    }
    if (!aboutUserId || typeof aboutUserId !== 'string') {
      return errorJson('aboutUserId обязателен', 422);
    }
    if (!message || typeof message !== 'string' || !message.trim()) {
      return errorJson('message обязателен', 422);
    }
    if (message.length > MAX_MESSAGE_LENGTH) {
      return errorJson(`message слишком длинный (макс. ${MAX_MESSAGE_LENGTH} символов)`, 422);
    }
    if (typeof isAnonymous !== 'boolean') {
      return errorJson('isAnonymous должен быть boolean', 422);
    }

    // === Семантические проверки ===
    if (toUserId === user.id) {
      return errorJson('Нельзя спросить самого себя', 400);
    }
    if (aboutUserId === user.id) {
      return errorJson('Нельзя спрашивать про самого себя', 400);
    }
    if (toUserId === aboutUserId) {
      return errorJson('Коллега и человек, про которого спрашивают, должны быть разными людьми', 400);
    }

    // Проверяем существование обоих пользователей
    const [toUser, aboutUser] = await Promise.all([
      db.user.findUnique({ where: { id: toUserId }, select: { id: true, name: true } }),
      db.user.findUnique({ where: { id: aboutUserId }, select: { id: true, name: true } }),
    ]);
    if (!toUser) return errorJson('Коллега не найден', 404);
    if (!aboutUser) return errorJson('Пользователь, про которого спрашивают, не найден', 404);

    // === Валидация: toUser должен иметь общий проект с aboutUser ===
    const hasShared = await hasCommonProject(toUserId, aboutUserId);
    if (!hasShared) {
      return errorJson(
        'Можно спрашивать только у коллег, которые работали с этим человеком над общим проектом',
        422,
      );
    }

    // === Лимит 3 запроса/неделю от fromUser к toUser ===
    const weekAgo = new Date(Date.now() - WEEK_MS);
    const recentCount = await db.colleagueInquiry.count({
      where: {
        fromUserId: user.id,
        toUserId,
        createdAt: { gte: weekAgo },
      },
    });
    if (recentCount >= MAX_INQUIRIES_PER_PAIR_PER_WEEK) {
      return errorJson(
        `Вы уже отправили ${MAX_INQUIRIES_PER_PAIR_PER_WEEK} запроса этому коллеге за неделю. Попробуйте позже.`,
        429,
      );
    }

    // === Создаём запрос ===
    const expiresAt = new Date(Date.now() + WEEK_MS);
    const inquiry = await db.colleagueInquiry.create({
      data: {
        fromUserId: user.id,
        toUserId,
        aboutUserId,
        message: message.trim(),
        isAnonymous,
        expiresAt,
      },
    });

    // === Уведомление получателю ===
    await db.notification
      .create({
        data: {
          userId: toUserId,
          type: 'colleague_inquiry',
          title: isAnonymous
            ? 'Анонимный запрос о коллеге'
            : `${user.name} спрашивает вас о коллеге`,
          content: `Про ${aboutUser.name}. Загляните в раздел «Я → Что нового», чтобы ответить.`,
          link: '/me',
        },
      })
      .catch((e) => console.error('[colleague-inquiries] notification error:', e));

    return json(
      {
        inquiry: {
          id: inquiry.id,
          status: inquiry.status,
          createdAt: inquiry.createdAt.toISOString(),
          expiresAt: inquiry.expiresAt.toISOString(),
        },
      },
      201,
    );
  } catch (e) {
    console.error('[colleague-inquiries/create] error:', e);
    return errorJson('Ошибка создания запроса', 500);
  }
}
