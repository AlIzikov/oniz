// BizON API — /api/colleague-inquiries/[id]/respond
// R9: ответить на входящий запрос (answered | declined)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const ALLOWED_STATUSES = ['answered', 'declined'] as const;
const MAX_RESPONSE_LENGTH = 5000;

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { status, response } = body ?? {};

    if (!ALLOWED_STATUSES.includes(status)) {
      return errorJson(`status должен быть одним из: ${ALLOWED_STATUSES.join(', ')}`, 422);
    }

    // response обязателен для answered, опционален для declined
    if (status === 'answered' && (!response || typeof response !== 'string' || !response.trim())) {
      return errorJson('Для ответа нужно заполнить текст', 422);
    }
    if (response && (typeof response !== 'string' || response.length > MAX_RESPONSE_LENGTH)) {
      return errorJson(`response слишком длинный (макс. ${MAX_RESPONSE_LENGTH} символов)`, 422);
    }

    // Находим запрос
    const inquiry = await db.colleagueInquiry.findUnique({ where: { id } });
    if (!inquiry) return errorJson('Запрос не найден', 404);

    // Только получатель может отвечать
    if (inquiry.toUserId !== user.id) {
      return errorJson('Только получатель может ответить', 403);
    }
    // Нельзя отвечать на уже отвеченный/просроченный
    if (inquiry.status !== 'pending') {
      return errorJson(`Запрос уже в статусе «${inquiry.status}»`, 400);
    }
    // Проверка срока действия
    if (inquiry.expiresAt < new Date()) {
      await db.colleagueInquiry.update({ where: { id }, data: { status: 'expired' } });
      return errorJson('Срок действия запроса истёк', 410);
    }

    const updated = await db.colleagueInquiry.update({
      where: { id },
      data: {
        status,
        response: status === 'answered' ? response.trim() : null,
        answeredAt: new Date(),
      },
    });

    // Уведомление отправителю (если не анонимный)
    if (!inquiry.isAnonymous) {
      await db.notification
        .create({
          data: {
            userId: inquiry.fromUserId,
            type: 'colleague_inquiry',
            title:
              status === 'answered'
                ? 'Коллега ответил на ваш запрос'
                : 'Коллега отклонил ваш запрос',
            content:
              status === 'answered'
                ? `Получен ответ о коллеге. Загляните в раздел «Я → Что нового».`
                : 'Запрос отклонён.',
            link: '/me',
          },
        })
        .catch((e) => console.error('[colleague-inquiries/respond] notification error:', e));
    }

    return json({
      inquiry: {
        id: updated.id,
        status: updated.status,
        response: updated.response,
        answeredAt: updated.answeredAt?.toISOString() ?? null,
      },
    });
  } catch (e) {
    console.error('[colleague-inquiries/respond] error:', e);
    return errorJson('Ошибка ответа на запрос', 500);
  }
}
