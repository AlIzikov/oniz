// BizON API — /api/integrations/telegram (Этап 5.6 — INT: Integrations Hub)
// POST — заглушка Telegram bot. Возвращает 501 с понятным сообщением.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  return json(
    {
      provider: 'telegram',
      status: 'coming_soon',
      message: 'Telegram bot — скоро. Мы уже готовим интеграцию.',
    },
    501
  );
}
