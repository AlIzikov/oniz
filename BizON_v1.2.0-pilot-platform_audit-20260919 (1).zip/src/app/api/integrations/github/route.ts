// BizON API — /api/integrations/github (Этап 5.6 — INT: Integrations Hub)
// POST — заглушка OAuth2 с GitHub. Возвращает 501 с понятным сообщением.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  return json(
    {
      provider: 'github',
      status: 'coming_soon',
      message: 'OAuth2 с GitHub — скоро. Мы уже готовим интеграцию.',
    },
    501
  );
}
