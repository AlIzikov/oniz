// BizON API — /api/integrations (Этап 5.6 — INT: Integrations Hub)
// GET — список интеграций пользователя (пока заглушки, всегда пустой).
// Интеграции (LinkedIn, GitHub, Telegram) — TODO в следующих этапах.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Заглушка: интеграции ещё не реализованы. Возвращаем статус для UI.
  // В будущем — будут храниться в таблице UserIntegration (provider, externalId, accessToken, ...).
  const integrations = [
    {
      provider: 'linkedin',
      label: 'LinkedIn',
      connected: false,
      connectedAt: null,
      externalId: null,
    },
    {
      provider: 'github',
      label: 'GitHub',
      connected: false,
      connectedAt: null,
      externalId: null,
    },
    {
      provider: 'telegram',
      label: 'Telegram',
      connected: false,
      connectedAt: null,
      externalId: null,
    },
  ];

  return json({ integrations });
}
