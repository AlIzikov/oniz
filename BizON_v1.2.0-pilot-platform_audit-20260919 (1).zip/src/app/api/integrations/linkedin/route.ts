// BizON API — /api/integrations/linkedin (Этап 5.6 — INT: Integrations Hub)
// POST — заглушка OAuth2 с LinkedIn. Возвращает 501 с понятным сообщением.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // OAuth2 с LinkedIn — скоро. Возвращаем понятный статус для UI toast.
  return json(
    {
      provider: 'linkedin',
      status: 'coming_soon',
      message: 'OAuth2 с LinkedIn — скоро. Мы уже готовим интеграцию.',
    },
    501
  );
}
