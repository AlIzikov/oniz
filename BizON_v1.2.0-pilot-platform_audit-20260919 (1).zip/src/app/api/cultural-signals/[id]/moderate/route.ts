// BizON API — /api/cultural-signals/[id]/moderate (admin only)
// POST { action: 'approve' | 'reject' } — модерация pending отзыва
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { CulturalSignalsService } from '@/lib/services/cultural-signals-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (!isAdminRole(user.roles)) {
    return errorJson('Только администратор может модерировать отзывы', 403);
  }

  try {
    const body = await req.json();
    const action = body?.action;
    if (action !== 'approve' && action !== 'reject') {
      return errorJson('action должен быть "approve" или "reject"', 422);
    }

    await CulturalSignalsService.moderateSignal(id, action, true);
    return json({ ok: true, action });
  } catch (e: any) {
    const msg = e?.message || 'Ошибка модерации отзыва';
    if (msg.includes('не найден')) return errorJson(msg, 404);
    if (msg.includes('Только администратор') || msg.includes('Можно модерировать')) {
      return errorJson(msg, 403);
    }
    console.error('[cultural-signals/moderate] error:', e);
    return errorJson(msg, 500);
  }
}
