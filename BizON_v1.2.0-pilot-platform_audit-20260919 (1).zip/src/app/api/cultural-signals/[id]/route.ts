// BizON API — /api/cultural-signals/[id]
// DELETE — удалить отзыв (автор или админ). Мягкое удаление → status='removed'.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { CulturalSignalsService } from '@/lib/services/cultural-signals-service';

export const runtime = 'nodejs';

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    await CulturalSignalsService.removeSignal(id, user.id, isAdminRole(user.roles));
    return json({ ok: true });
  } catch (e: any) {
    const msg = e?.message || 'Ошибка удаления отзыва';
    if (msg.includes('не найден')) return errorJson(msg, 404);
    if (msg.includes('Нет прав')) return errorJson(msg, 403);
    console.error('[cultural-signals/delete] error:', e);
    return errorJson(msg, 500);
  }
}
