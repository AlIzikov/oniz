// BizON API — /api/complaints (Wave 1 щит, S-019).
// POST — жалоба из 7 закрытых категорий на любую сущность (единый модерационный контур).
// GET  — админ: очередь открытых жалоб (?status=open|resolved|dismissed).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';
import { checkVelocity } from '@/lib/security/velocity';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const COMPLAINT_CATEGORIES = ['spam', 'fraud', 'abuse', 'inappropriate', 'fake', 'privacy', 'other'] as const;
const TARGET_TYPES = ['post', 'user', 'recommendation', 'community', 'event', 'project', 'intro'] as const;

const complaintSchema = z.object({
  targetType: z.enum(TARGET_TYPES),
  targetId: z.string().min(1).max(64),
  category: z.enum(COMPLAINT_CATEGORIES),
  details: z.string().max(500).optional(),
});

export const POST = withRoute(async (_req, ctx) => {
  const data = complaintSchema.parse(ctx.data);

  // Velocity: ≤10 жалоб/час (basic-тир — 2/час) — против жалобных войн.
  if (!checkVelocity(ctx.user.id, { key: 'complaint', limit: 10, windowMs: 60 * 60 * 1000 })) {
    return NextResponse.json({ error: 'Слишком много жалоб. Попробуйте позже.' }, { status: 429 });
  }

  // Дедуп: одна открытая жалоба от пользователя на цель.
  const dup = await db.complaint.findFirst({
    where: { reporterId: ctx.user.id, targetType: data.targetType, targetId: data.targetId, status: 'open' },
    select: { id: true },
  });
  if (dup) return NextResponse.json({ error: 'Вы уже отправили жалобу на этот объект' }, { status: 409 });

  const created = await db.complaint.create({
    data: {
      reporterId: ctx.user.id,
      targetType: data.targetType,
      targetId: data.targetId,
      category: data.category,
      details: data.details?.trim() || null,
    },
  });

  AuditLog.logSecurity('COMPLAINT_FILED', {
    actorId: ctx.user.id,
    resource: 'Complaint',
    resourceId: created.id,
    metadata: { targetType: data.targetType, category: data.category },
  });

  return NextResponse.json({ id: created.id, status: created.status }, { status: 201 });
});

export const GET = withRoute(async (req, ctx) => {
  // Очередь модерации — только роли admin (проверка по roles CSV).
  const roles = (ctx.user.roles ?? '').split(',').map((r) => r.trim());
  if (!roles.includes('admin')) {
    return NextResponse.json({ error: 'Доступ запрещён' }, { status: 403 });
  }
  const status = new URL(req.url).searchParams.get('status') ?? 'open';
  const complaints = await db.complaint.findMany({
    where: { status },
    orderBy: { createdAt: 'desc' },
    take: 100,
    select: {
      id: true, targetType: true, targetId: true, category: true, details: true, status: true, createdAt: true,
      reporter: { select: { id: true, name: true } },
    },
  });
  return NextResponse.json({ complaints });
});
