// BizON API — /api/resumes/[id]/blocks (Wave 5, S-114, ТЗ 4.3 RESUME-конструктор).
// GET — прочитать блоки; PUT — валидация и сохранение (about ≤5000,
// EXPERIENCE job/education + YYYY-MM, QUALIFICATION, SKILL ≤5 + 1 is_primary).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { ResumeBlocksService } from '@/lib/services/resume-blocks-service';

export const runtime = 'nodejs';

const blockSchema = z.object({
  kind: z.enum(['about', 'experience', 'qualification', 'skill']),
  text: z.string().max(5000).optional(),
  title: z.string().max(200).optional(),
  organization: z.string().max(200).optional(),
  expKind: z.enum(['job', 'education']).optional(),
  start_ym: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/).optional(),
  end_ym: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/).nullable().optional(),
  description: z.string().max(5000).optional(),
  qualification: z.string().max(200).optional(),
  award: z.string().max(500).optional(),
  skill: z.string().max(60).optional(),
  is_primary: z.boolean().optional(),
});

const putSchema = z.object({ blocks: z.array(blockSchema).max(50) });

export const GET = withRoute<{ id: string }>(async (req, ctx) => {
  const blocks = await ResumeBlocksService.load(ctx.user.id, ctx.params.id);
  return NextResponse.json({ blocks });
});

export const PUT = withRoute<{ id: string }>(async (req, ctx) => {
  const input = putSchema.parse(ctx.data);
  const result = await ResumeBlocksService.save(ctx.user.id, ctx.params.id, input.blocks);
  if (result.ok) return NextResponse.json({ resumeId: result.resumeId });
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, {
  rateLimit: { key: 'resume-blocks-put', limit: 30, windowMs: 60 * 60 * 1000 },
});
