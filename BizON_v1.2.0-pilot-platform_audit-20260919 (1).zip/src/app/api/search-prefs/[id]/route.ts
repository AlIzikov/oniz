// BizON API — /api/search-prefs/[id] (Wave 5, S-114).
// PATCH — обновить/включить-выключить подписку; DELETE — удалить.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { SearchPreferenceService } from '@/lib/services/search-preference-service';

export const runtime = 'nodejs';

const patchSchema = z.object({
  kind: z.enum(['seeker', 'employer']).optional(),
  query: z.string().max(200).nullable().optional(),
  skills: z.array(z.string().min(1).max(40)).max(15).optional(),
  regions: z.array(z.string().min(1).max(60)).max(10).optional(),
  filters: z.record(z.string(), z.unknown()).optional(),
  isActive: z.boolean().optional(),
});

export const PATCH = withRoute<{ id: string }>(async (req, ctx) => {
  const input = patchSchema.parse(ctx.data);
  const result = await SearchPreferenceService.update(ctx.user.id, ctx.params.id, input);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
});

export const DELETE = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await SearchPreferenceService.delete(ctx.user.id, ctx.params.id);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
});
