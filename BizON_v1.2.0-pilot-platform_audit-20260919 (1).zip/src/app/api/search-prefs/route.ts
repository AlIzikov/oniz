// BizON API — /api/search-prefs (Wave 5, S-114, ТЗ 4.3 SEARCH_PREF).
// GET — список подписок автопоиска; POST — создать (≤5 активных).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { SearchPreferenceService } from '@/lib/services/search-preference-service';

export const runtime = 'nodejs';

const createSchema = z.object({
  kind: z.enum(['seeker', 'employer']).optional(),
  query: z.string().max(200).nullable().optional(),
  skills: z.array(z.string().min(1).max(40)).max(15).optional(),
  regions: z.array(z.string().min(1).max(60)).max(10).optional(),
  filters: z.record(z.string(), z.unknown()).optional(),
  isActive: z.boolean().optional(),
});

export const GET = withRoute(async (req, ctx) => {
  const result = await SearchPreferenceService.list(ctx.user.id);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
});

export const POST = withRoute(async (req, ctx) => {
  const input = createSchema.parse(ctx.data);
  const result = await SearchPreferenceService.create(ctx.user.id, input);
  if (result.ok) return NextResponse.json(result.data, { status: 201 });
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, {
  rateLimit: { key: 'search-pref-create', limit: 20, windowMs: 60 * 60 * 1000 },
});
