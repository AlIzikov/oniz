// BizON API — /api/connections/[id]/verify (Wave 1, S-014): re-strengthening ребра.
// Подтверждение контакта сдвигает lastVerifiedAt → decay-вес восстанавливается
// до W0 (src/lib/trust/decay.ts). Числа наружу не отдаём — только факт подтверждения.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

const verifySchema = z.object({
  kind: z.enum(['friend', 'colleague', 'partner', 'former', 'common']).optional(),
});

export const POST = withRoute<{ id: string }>(async (_req, ctx) => {
  const { kind } = (verifySchema.parse(ctx.data ?? {}));

  const conn = await db.connection.findUnique({ where: { id: ctx.params.id }, select: { id: true, fromUserId: true, toUserId: true, status: true } });
  if (!conn || (conn.fromUserId !== ctx.user.id && conn.toUserId !== ctx.user.id)) {
    return NextResponse.json({ error: 'Связь не найдена' }, { status: 404 });
  }
  if (conn.status !== 'accepted') {
    return NextResponse.json({ error: 'Связь ещё не подтверждена обеими сторонами' }, { status: 409 });
  }

  await db.connection.update({
    where: { id: conn.id },
    data: { lastVerifiedAt: new Date(), ...(kind ? { kind } : {}) },
  });

  AuditLog.logSecurity('CONNECTION_VERIFIED', {
    actorId: ctx.user.id,
    resource: 'Connection',
    resourceId: conn.id,
    metadata: { kind: kind ?? null },
  });

  return NextResponse.json({ ok: true });
});
