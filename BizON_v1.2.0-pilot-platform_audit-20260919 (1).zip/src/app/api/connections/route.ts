// BizON API — /api/connections
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ReputationService } from '@/lib/services';

export const runtime = 'nodejs';

// Список моих связей (входящие/исходящие/принятые)
export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const status = (req.nextUrl.searchParams.get('status') ?? 'all') as 'all' | 'pending' | 'accepted' | 'declined';
  const direction = req.nextUrl.searchParams.get('direction') ?? 'all'; // all | incoming | outgoing

  const where: any = {
    OR: [{ fromUserId: user.id }, { toUserId: user.id }],
  };
  if (status !== 'all') where.status = status;
  if (direction === 'incoming') where.OR = [{ toUserId: user.id }];
  if (direction === 'outgoing') where.OR = [{ fromUserId: user.id }];

  const conns = await db.connection.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    include: {
      // company (аккаунт компании) + employments (текущее подтверждённое место работы) —
      // нужно для табличного вида контактов (11-b); аддитивно, старым потребителям не мешает
      fromUser: {
        select: {
          id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, birthday: true,
          company: { select: { name: true } },
          employments: { where: { isCurrent: true }, take: 1, select: { company: { select: { name: true } } } },
        },
      },
      toUser: {
        select: {
          id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, birthday: true,
          company: { select: { name: true } },
          employments: { where: { isCurrent: true }, take: 1, select: { company: { select: { name: true } } } },
        },
      },
    },
  });

  const companyName = (u: typeof conns[number]['fromUser']): string | null =>
    u.company?.name ?? u.employments?.[0]?.company?.name ?? null;

  return json({
    connections: conns.map((c) => ({
      id: c.id,
      fromUser: { ...c.fromUser, company: companyName(c.fromUser) },
      toUser: { ...c.toUser, company: companyName(c.toUser) },
      status: c.status,
      note: c.note,
      createdAt: c.createdAt.toISOString(),
      // помечаем направление относительно текущего пользователя
      direction: c.fromUserId === user.id ? 'outgoing' : 'incoming',
    })),
  });
}

// Создание запроса на связь
export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { toUserId, note } = body ?? {};
    if (!toUserId) return errorJson('toUserId обязателен', 422);
    if (toUserId === user.id) return errorJson('Нельзя добавить себя', 400);

    const target = await db.user.findUnique({ where: { id: toUserId } });
    if (!target) return errorJson('Пользователь не найден', 404);

    const existing = await db.connection.findFirst({
      where: {
        OR: [
          { fromUserId: user.id, toUserId },
          { fromUserId: toUserId, toUserId: user.id },
        ],
      },
    });
    if (existing) return errorJson('Запрос уже существует', 400);

    const conn = await db.connection.create({
      data: { fromUserId: user.id, toUserId, status: 'pending', note },
    });
    return json({ connection: conn }, 201);
  } catch (e) {
    console.error('[connections/create] error:', e);
    return errorJson('Ошибка создания связи', 500);
  }
}

// Принять/отклонить запрос
export async function PATCH(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { connectionId, action } = body ?? {};
    if (!connectionId || !action) return errorJson('connectionId и action обязательны', 422);
    if (!['accept', 'decline'].includes(action)) return errorJson('action: accept | decline', 422);

    const conn = await db.connection.findUnique({ where: { id: connectionId } });
    if (!conn) return errorJson('Связь не найдена', 404);
    if (conn.toUserId !== user.id) return errorJson('Только получатель может принять/отклонить', 403);

    const updated = await db.connection.update({
      where: { id: connectionId },
      data: { status: action === 'accept' ? 'accepted' : 'declined' },
    });

    if (action === 'accept') {
      // FIX-06: репутация обоим участникам одной пачкой (awardBulk) вместо
      // 2 × ~10 последовательных запросов (event + findUnique + recompute)
      const participants = await db.user.findMany({
        where: { id: { in: [conn.fromUserId, conn.toUserId] } },
        select: { id: true, name: true },
      });
      const nameById = new Map(participants.map((p) => [p.id, p.name]));
      await ReputationService.awardBulk({
        userIds: [conn.fromUserId, conn.toUserId],
        eventType: 'connection_accepted',
        weight: 2,
        payload: (uid) => ({
          with: uid === conn.fromUserId ? nameById.get(conn.toUserId) : nameById.get(conn.fromUserId),
        }),
      });
    }

    return json({ connection: updated });
  } catch (e) {
    console.error('[connections/patch] error:', e);
    return errorJson('Ошибка', 500);
  }
}
