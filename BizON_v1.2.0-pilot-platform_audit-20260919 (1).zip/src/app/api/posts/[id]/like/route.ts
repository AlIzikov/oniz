// BizON API — /api/posts/[id]/like
// FIX-07: withRoute — auth 401, единый маппинг ошибок (Prisma P2002→409, P2025→404),
// без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const { id } = ctx.params;
  const user = ctx.user!;

  const post = await db.post.findUnique({ where: { id } });
  if (!post) return errorJson('Пост не найден', 404);

  const existing = await db.postLike.findUnique({
    where: { postId_userId: { postId: id, userId: user.id } },
  }).catch(() => null);

  if (existing) {
    // unlike
    await db.postLike.delete({ where: { id: existing.id } });
    await db.post.update({ where: { id }, data: { likesCount: { decrement: 1 } } });
    return json({ liked: false, likesCount: post.likesCount - 1 });
  } else {
    await db.postLike.create({ data: { postId: id, userId: user.id } });
    await db.post.update({ where: { id }, data: { likesCount: { increment: 1 } } });
    return json({ liked: true, likesCount: post.likesCount + 1 });
  }
});
