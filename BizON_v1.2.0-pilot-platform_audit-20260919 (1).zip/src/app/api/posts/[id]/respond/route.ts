// BizON API — POST /api/posts/[id]/respond (Wave 11-a «Отклик в платформе»)
//
// Зачем: раньше CTA commercial-поста был прямой ссылкой (часто mailto:) и
// открывал почтовый клиент посетителя. Теперь отклик происходит ВНУТРИ
// платформы:
//   1) создаётся Notification автору поста (type='post_response') — отклик
//      всегда приходит в уведомления платформы;
//   2) создаётся приватный ActionEvent (type='post_response', isPublic:false)
//      для честной аналитики — паттерн 10-c (/api/feed/dwell);
//   3) если автор включил notifyByEmail И его email известен — в ответе
//      возвращается authorEmail, и фронт показывает кнопку «Продублировать
//      письмом» (mailto) УЖЕ ПОСЛЕ отправки отклика в платформе.
//
// ЧЕСТНОСТЬ: реальная отправка email в sandbox не настроена — сервер письмо
// НЕ отправляет и не притворяется, что отправил. Механизм дублирования —
// mailto-кнопка в почтовом клиенте пользователя, поэтому в ответе
// emailDelivery: 'mailto_fallback' (или null, если дублирование не включено).
//
// ПРИВАТНОСТЬ: authorEmail возвращается ТОЛЬКО при notifyByEmail=true
// (иначе null) — email автора не раскрывается откликнувшимся без его
// явного согласия. Email читается из emailEncrypted (PII-защита C1) —
// тот же паттерн, что в toUserPublic (src/lib/api-helpers).
//
// ЛИМИТ: не более 10 откликов в минуту на пользователя (in-memory KV,
// src/lib/security/rate-limiter.ts — паттерн H11 checkUserRateLimit).
//
// КОНТРАКТ ОТВЕТА:
//   200 { ok: true, notifyByEmail: boolean, authorEmail: string | null,
//         emailDelivery: 'mailto_fallback' | null }
//   401 не авторизован; 404 пост не найден; 422 — не commercial / свой пост /
//       пустой или длинный content / скрыт модератором; 429 rate-limit.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';
import { decrypt } from '@/lib/security/crypto';

export const runtime = 'nodejs';

const MAX_CONTENT_LENGTH = 1000;
// Wave 11-a: 10 откликов / минуту / юзера (анти-спам)
const RESPOND_RATE_LIMIT = [10, 60 * 1000] as const;

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Rate limit (паттерн H11: per-user mutation limit)
  const rl = checkUserRateLimit(user.id, 'posts:respond', ...RESPOND_RATE_LIMIT);
  if (!rl.allowed) {
    return errorJson('Слишком много откликов подряд — не более 10 в минуту. Попробуйте позже.', 429);
  }

  // --- Валидация тела ---
  let content: unknown;
  try {
    const body = await req.json();
    content = body?.content;
  } catch {
    return errorJson('Некорректный JSON в теле запроса', 400);
  }
  if (typeof content !== 'string' || content.trim().length < 1) {
    return errorJson('Сообщение отклика обязательно', 422);
  }
  const trimmed = content.trim();
  if (trimmed.length > MAX_CONTENT_LENGTH) {
    return errorJson(`Максимум ${MAX_CONTENT_LENGTH} символов`, 422);
  }

  // --- Валидация поста ---
  const post = await db.post.findUnique({
    where: { id },
    select: { id: true, authorId: true, type: true, ctaText: true, isHidden: true, notifyByEmail: true },
  });
  if (!post) return errorJson('Пост не найден', 404);
  if (post.type !== 'commercial') {
    return errorJson('Отклик доступен только на commercial-посты', 422);
  }
  if (post.authorId === user.id) {
    return errorJson('Нельзя откликнуться на свой пост', 422);
  }
  if (post.isHidden) {
    return errorJson('Пост скрыт модератором — отклик недоступен', 422);
  }

  // --- Email автора (только для решения о дублировании письмом) ---
  const author = await db.user.findUnique({
    where: { id: post.authorId },
    select: { email: true, emailEncrypted: true },
  });
  const authorEmailRaw = author?.emailEncrypted ? decrypt(author.emailEncrypted) : (author?.email || '');
  const authorEmail = authorEmailRaw.trim();
  // Дублирование письмом — только с явного согласия автора и если email известен
  const notifyByEmail = post.notifyByEmail === true && authorEmail.length > 0;

  // --- 1) Отклик = Notification автору поста (in-platform) ---
  const ctaLabel = (post.ctaText?.trim() || 'предложение').slice(0, 80);
  await db.notification
    .create({
      data: {
        userId: post.authorId,
        type: 'post_response',
        title: `${user.name} откликнулся на «${ctaLabel}»`,
        content: trimmed.slice(0, 200),
        link: '/messages',
      },
    })
    .catch((e) => console.error('[posts/respond] notification error:', e));

  // --- 2) Приватный ActionEvent (без текста отклика в metadata) ---
  await db.actionEvent
    .create({
      data: {
        userId: user.id,
        type: 'post_response',
        title: `Откликнулся на предложение «${ctaLabel}»`,
        description: null,
        metadata: JSON.stringify({ postId: post.id, postType: 'commercial', ctaText: ctaLabel.slice(0, 120) }),
        isPublic: false, // поведение приватно — не попадает в Professional Moments
      },
    })
    .catch(() => {});

  return json({
    ok: true,
    notifyByEmail,
    // Приватность: email автора — только если он сам разрешил дублирование
    authorEmail: notifyByEmail ? authorEmail : null,
    // Честность: сервер письмо не отправляет; mailto-кнопка — фолбэк на фронте
    emailDelivery: notifyByEmail ? 'mailto_fallback' : null,
  });
}
