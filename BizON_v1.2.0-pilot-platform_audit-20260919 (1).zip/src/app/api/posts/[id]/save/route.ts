// BizON API — /api/posts/[id]/save (toggle сохранения поста в Избранное)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id: postId } = await params;
  if (!postId) return errorJson('postId обязателен', 422);

  const existing = await db.savedPost.findUnique({
    where: { userId_postId: { userId: user.id, postId } },
  });

  if (existing) {
    await db.savedPost.delete({ where: { id: existing.id } });
    return json({ saved: false });
  }

  await db.savedPost.create({ data: { userId: user.id, postId } });
  return json({ saved: true });
}
