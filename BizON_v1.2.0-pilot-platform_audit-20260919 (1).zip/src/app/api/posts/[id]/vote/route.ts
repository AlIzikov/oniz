// BizON API — /api/posts/[id]/vote (Wave 3, S-060): голос в опросе.
// Один голос на пользователя (переголосование разрешено), идемпотентен.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/api-helpers';
import { votePoll } from '@/lib/services/post-types-service';

export const runtime = 'nodejs';

const voteSchema = z.object({ optionId: z.string().min(1).max(24) });

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const input = voteSchema.parse(ctx.data);
  const result = await votePoll(ctx.user.id, ctx.params.id, input.optionId);
  return NextResponse.json(result);
}, { rateLimit: { key: 'poll-vote', limit: 60, windowMs: 60 * 60 * 1000 } });
