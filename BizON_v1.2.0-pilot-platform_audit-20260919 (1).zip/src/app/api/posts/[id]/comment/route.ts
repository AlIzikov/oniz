// BizON API — /api/posts/[id]/comment
// FIX-07: withRoute — auth 401, zod-схема createPostComment (whitelist, strip),
// единый маппинг ошибок; без сырых e.message для 5xx.
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { sanitizeUserText } from '@/lib/sanitize';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(
  async (req, ctx) => {
    const { id } = ctx.params;
    const user = ctx.user!;
    const { content } = ctx.data as { content: string };

    // Бизнес-лимит комментария (жёстче schema-лимита 2000)
    if (content.length > 500) return errorJson('Максимум 500 символов', 422);

    const post = await db.post.findUnique({ where: { id } });
    if (!post) return errorJson('Пост не найден', 404);

    const comment = await db.postComment.create({
      data: {
        postId: id,
        authorId: user.id,
        // fix-adversarial (ADV-B109): stored-XSS носители вырезаются на входе
        content: sanitizeUserText(content.trim()),
      },
      include: {
        author: { select: { id: true, name: true, avatarUrl: true } },
      },
    });

    await db.post.update({ where: { id }, data: { commentsCount: { increment: 1 } } });

    return json({
      comment: {
        id: comment.id,
        content: comment.content,
        createdAt: comment.createdAt.toISOString(),
        author: comment.author,
      },
    }, 201);
  },
  { schema: schemas.createPostComment },
);
