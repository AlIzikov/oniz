// BizON API — /api/posts/[id]/unlock (Wave 3, S-060): покупка доступа к
// subscription-посту (люмены → автору мгновенно, идемпотентно).
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { unlockSubscription } from '@/lib/services/post-types-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await unlockSubscription(ctx.user.id, ctx.params.id);
  return NextResponse.json(result);
}, { rateLimit: { key: 'post-unlock', limit: 30, windowMs: 60 * 60 * 1000 } });
