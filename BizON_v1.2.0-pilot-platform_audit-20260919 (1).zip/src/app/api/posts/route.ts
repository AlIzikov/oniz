// BizON API — /api/posts
// CRUD для пользовательских постов в Trust Stream
// Free: можно публиковать regular посты
// Business: можно публиковать commercial посты (с CTA)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson, withRoute } from '@/lib/api-helpers'; // FIX-07: withRoute
import { schemas } from '@/lib/validation';
import { ReputationService } from '@/lib/services';
import { runAdModerator } from '@/lib/ai';
import { isUrlSafeForStorage, safeFetch } from '@/lib/security/ssrf';
import { sanitizeUserText } from '@/lib/sanitize';
import { EventBus } from '@/lib/event-bus';
import type { PostPublic, SubscriptionTier } from '@/lib/types';
// Wave 3 (S-058…S-062): типы постов 4.2 ТЗ + POLL/SUBSCRIPTION/TERM
import {
  validateTypeSpecific,
  checkBanWords,
  termNotExpired,
  parsePollOptions,
  POST_ALL_TYPES_SET,
  type PollOption,
} from '@/lib/services/post-types-service';

export const runtime = 'nodejs';

const MAX_POST_LENGTH = 2000;
const FREE_TIER_MAX_POSTS_PER_DAY = 5;

// fix-adversarial (ADV-B108): безопасный парсинг пагинации — NaN/мусор
// (?limit=abc) не должен доходить до Prisma take/skip (иначе сырой 500).
function parseIntParam(raw: string | null, def: number, min: number, max: number): number {
  const n = Number(raw ?? def);
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, Math.floor(n)));
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const limit = parseIntParam(req.nextUrl.searchParams.get('limit'), 30, 1, 100);
  const offset = parseIntParam(req.nextUrl.searchParams.get('offset'), 0, 0, Number.MAX_SAFE_INTEGER);
  const authorId = req.nextUrl.searchParams.get('authorId'); // для профиля

  const where: any = { isHidden: false };
  if (authorId) where.authorId = authorId;
  // Wave 3 S-058: term-посты скрываются после дедлайна
  Object.assign(where, termNotExpired());

  const posts = await db.post.findMany({
    where,
    take: limit,
    skip: offset,
    orderBy: [{ createdAt: 'desc' }],
    include: {
      author: {
        select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, subscriptionTier: true },
      },
      likes: { where: { userId: user.id }, select: { id: true } },
      pollVotes: { where: { userId: user.id }, select: { optionId: true } },
      accessGrants: { where: { userId: user.id }, select: { id: true } },
      comments: {
        orderBy: { createdAt: 'asc' },
        take: 5,
        include: {
          author: { select: { id: true, name: true, avatarUrl: true } },
        },
      },
    },
  });

  // Wave 3: итоги опросов — один groupBy на все poll-посты страницы
  const pollIds = posts.filter((p) => p.type === 'poll').map((p) => p.id);
  const voteGroups = pollIds.length
    ? await db.postPollVote.groupBy({
        by: ['postId', 'optionId'],
        where: { postId: { in: pollIds } },
        _count: { optionId: true },
      })
    : [];

  const result: PostPublic[] = posts.map((p) => {
    const isMine = p.authorId === user.id;
    const hasAccess = p.accessGrants.length > 0 || isMine;
    const locked = p.type === 'subscription' && !hasAccess;
    const options = parsePollOptions(p.pollOptions);
    const pollResults =
      p.type === 'poll' && options.length > 0
        ? {
            options: options.map((o) => ({
              id: o.id,
              text: o.text,
              votes: voteGroups.find((v) => v.postId === p.id && v.optionId === o.id)?._count.optionId ?? 0,
            })),
            totalVotes: voteGroups.filter((v) => v.postId === p.id).reduce((s, v) => s + v._count.optionId, 0),
            myVote: p.pollVotes[0]?.optionId ?? null,
          }
        : undefined;
    const content = locked
      ? `${p.content.slice(0, 120)}${p.content.length > 120 ? '…' : ''}`
      : p.content;
    return {
      id: p.id,
      content,
      tags: p.tags ? p.tags.split(',').filter(Boolean) : [],
      type: p.type as PostPublic['type'],
      ctaText: p.ctaText,
      ctaUrl: p.ctaUrl,
      imageUrl: p.imageUrl,
      linkPreview: p.linkPreview ? JSON.parse(p.linkPreview) : null,
      likesCount: p.likesCount,
      commentsCount: p.commentsCount,
      likedByMe: p.likes.length > 0,
      createdAt: p.createdAt.toISOString(),
      author: {
        ...p.author,
        level: p.author.level as PostPublic['author']['level'],
        subscriptionTier: p.author.subscriptionTier as PostPublic['author']['subscriptionTier'],
      },
      comments: p.comments.map((c) => ({
        id: c.id,
        content: c.content,
        createdAt: c.createdAt.toISOString(),
        author: c.author,
      })),
      pollOptions: options.length > 0 ? options : undefined,
      pollResults,
      subscriptionPriceLumens: p.subscriptionPriceLumens,
      termExpiresAt: p.termExpiresAt?.toISOString() ?? null,
      locked,
      hasAccess,
      isMine,
    };
  });

  return json({ posts: result, total: result.length });
}

// FIX-07: withRoute — auth 401, zod-схема (whitelist, content ≤5000),
// Prisma/BizonError маппинг, без сырых e.message для 5xx.
export const POST = withRoute(async (req, ctx) => {
  const user = ctx.user!;
  const { content, tags, type, ctaText, ctaUrl, imageUrl, notifyByEmail, pollOptions, subscriptionPriceLumens, termExpiresAt } =
    ctx.data as {
      content: string;
      tags?: string[];
      type?: string;
      ctaText?: string;
      ctaUrl?: string;
      imageUrl?: string;
      notifyByEmail?: boolean;
      pollOptions?: PollOption[];
      subscriptionPriceLumens?: number;
      termExpiresAt?: string;
    };
  const postType = type ?? 'regular';

  // Wave 3: whitelist типов (незнакомый → 422, а не тихий regular)
  if (!POST_ALL_TYPES_SET.has(postType)) {
    return errorJson('Неизвестный тип поста', 422);
  }

  // Бизнес-лимит поста (жёстче schema-лимита 5000)
  if (content.length > MAX_POST_LENGTH) {
    return errorJson(`Максимум ${MAX_POST_LENGTH} символов`, 422);
  }

  // Wave 3 S-068: единый BAN_WORD фильтр контента (до AI-модерации)
  const ban = await checkBanWords(content);
  if (ban.blocked) {
    return errorJson('Пост содержит запрещённое выражение', 422);
  }

  // Проверка прав на commercial посты (только Business)
  if (postType === 'commercial' && user.subscriptionTier !== 'business') {
    return errorJson('Commercial-посты доступны только на тарифе Business', 403);
  }

  // Wave 3 S-058: платная подписка на автора — монетизация, только платные тарифы
  if (postType === 'subscription' && user.subscriptionTier === 'free') {
    return errorJson('Платные посты доступны на тарифах Pro и Business', 403);
  }

  // Типо-специфичная валидация (poll 2..6 вариантов / цена / дедлайн ≤30 дней)
  let typed;
  try {
    typed = validateTypeSpecific({
      type: postType,
      pollOptions,
      subscriptionPriceLumens,
      termExpiresAt,
    });
  } catch (e) {
    if (e instanceof Error) return errorJson(e.message, 422);
    throw e;
  }

  // Лимит для free: не более 5 постов в день
  if (user.subscriptionTier === 'free') {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayCount = await db.post.count({
      where: { authorId: user.id, createdAt: { gte: todayStart } },
    });
    if (todayCount >= FREE_TIER_MAX_POSTS_PER_DAY) {
      return errorJson(`На бесплатном тарифе — не более ${FREE_TIER_MAX_POSTS_PER_DAY} постов в день. Перейдите на Pro для безлимита.`, 403);
    }
  }

  // Модерация commercial постов через AI-Ad-Moderator; BAN_WORD-flag — скрытие до ревью
  let moderationScore = 1.0;
  let isHidden = ban.flagged; // flag-слово → на ревью (honest: скрыто, не удалено)
  if (postType === 'commercial') {
    const mod = await runAdModerator(content);
    moderationScore = mod.moderationScore;
    if (mod.verdict === 'block') {
      return errorJson(`Пост заблокирован модератором: ${mod.reason}`, 422);
    }
    if (mod.verdict === 'review') {
      isHidden = true;
    }
  }

  // Auto-detect link preview (если в тексте есть URL)
  let linkPreview: string | null = null;
  const urlMatch = content.match(/https?:\/\/[^\s]+/);
  if (urlMatch) {
    const url = urlMatch[0];
    try {
      const preview = await fetchLinkPreview(url);
      linkPreview = JSON.stringify(preview);
    } catch {}
  }

  // C4: SSRF protection для imageUrl — проверяем что URL не ведёт в приватную сеть
  let safeImageUrl: string | null = null;
  if (imageUrl) {
    const isSafe = await isUrlSafeForStorage(imageUrl);
    if (!isSafe) {
      return errorJson('URL изображения небезопасен (приватная сеть или запрещённый протокол)', 422);
    }
    safeImageUrl = imageUrl;
  }

  const post = await db.post.create({
    data: {
      authorId: user.id,
      // fix-adversarial (ADV-B109): stored-XSS носители вырезаются на входе
      // (defense-in-depth к React-экранированию на рендере).
      content: sanitizeUserText(content.trim()),
      tags: tags?.join(',') ?? '',
      type: postType,
      pollOptions: typed.pollOptionsJson,
      subscriptionPriceLumens: typed.subscriptionPrice,
      termExpiresAt: typed.termExpires,
      ctaText: postType === 'commercial' ? ctaText : null,
      ctaUrl: postType === 'commercial' ? ctaUrl : null,
      // Wave 11-a: дублирование откликов письмом — только по выбору автора (commercial)
      notifyByEmail: postType === 'commercial' ? notifyByEmail === true : false,
      imageUrl: safeImageUrl,
      linkPreview,
      moderationScore,
      isHidden,
    },
    include: {
      author: {
        select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, subscriptionTier: true },
      },
    },
  });

  // FIX-06: reputation event + пересчёт IP-score одной пачкой (awardBulk)
  await ReputationService.awardBulk({
    userIds: [user.id],
    eventType: 'post_published',
    weight: postType === 'commercial' ? 2 : 1,
    payload: {
      postId: post.id,
      postType: post.type,
      preview: post.content.slice(0, 100),
    },
  });

  // Event Bus: пост опубликован (ошибки шины не влияют на ответ API)
  EventBus.publish('post.published', { userId: user.id, postId: post.id, type: post.type }).catch(() => undefined);

  const result: PostPublic = {
    id: post.id,
    content: post.content,
    tags: post.tags ? post.tags.split(',').filter(Boolean) : [],
    type: post.type as PostPublic['type'],
    ctaText: post.ctaText,
    ctaUrl: post.ctaUrl,
    imageUrl: post.imageUrl,
    linkPreview: linkPreview ? JSON.parse(linkPreview) : null,
    likesCount: 0,
    commentsCount: 0,
    likedByMe: false,
    createdAt: post.createdAt.toISOString(),
    author: {
      ...post.author,
      level: post.author.level as PostPublic['author']['level'],
      subscriptionTier: post.author.subscriptionTier as PostPublic['author']['subscriptionTier'],
    },
    comments: [],
    // Wave 3 S-058: полный объект сразу (оптимистичный рендер опроса/пейволла)
    pollOptions: parsePollOptions(post.pollOptions).length > 0 ? parsePollOptions(post.pollOptions) : undefined,
    pollResults:
      post.type === 'poll' && parsePollOptions(post.pollOptions).length > 0
        ? {
            options: parsePollOptions(post.pollOptions).map((o) => ({ ...o, votes: 0 })),
            totalVotes: 0,
            myVote: null,
          }
        : undefined,
    subscriptionPriceLumens: post.subscriptionPriceLumens,
    termExpiresAt: post.termExpiresAt?.toISOString() ?? null,
    locked: false,
    hasAccess: true,
    isMine: true,
  };

  return json({ post: result }, 201);
}, { schema: schemas.createPost });

// Простая функция link preview — извлекает title из HTML
// C4: использует safeFetch с SSRF protection (блокировка приватных подсетей, запрет редиректов)
async function fetchLinkPreview(url: string): Promise<{ url: string; title: string; description: string; image: string | null }> {
  try {
    const res = await safeFetch(url, { timeoutMs: 5000 });
    if (!res) {
      // URL заблокирован SSRF protection или fetch не удался
      return { url, title: url, description: '', image: null };
    }
    if (!res.ok) throw new Error('fetch failed');
    // C4: проверяем — если это редирект (3xx), НЕ следуем (manual redirect mode)
    if (res.status >= 300 && res.status < 400) {
      return { url, title: url, description: '', image: null };
    }
    const html = await res.text();
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const descMatch = html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i)
      || html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i);
    const imageMatch = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i);
    return {
      url,
      title: titleMatch ? titleMatch[1].trim().slice(0, 120) : url,
      description: descMatch ? descMatch[1].trim().slice(0, 200) : '',
      image: imageMatch ? imageMatch[1] : null,
    };
  } catch {
    return { url, title: url, description: '', image: null };
  }
}
