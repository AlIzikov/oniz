// BizON API — /api/posts/saved (Избранные посты пользователя)
// Возвращает список постов, сохранённых пользователем (для подменю "Моё → Избранное")
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const saved = await db.savedPost.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      post: {
        include: {
          author: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true, level: true, subscriptionTier: true } },
          _count: { select: { likes: true, comments: true } },
        },
      },
    },
  });

  return json({
    posts: saved.map(s => ({
      id: s.post.id,
      content: s.post.content,
      tags: s.post.tags ? s.post.tags.split(',').filter(Boolean) : [],
      type: s.post.type,
      ctaText: s.post.ctaText,
      ctaUrl: s.post.ctaUrl,
      imageUrl: s.post.imageUrl,
      linkPreview: s.post.linkPreview ? JSON.parse(s.post.linkPreview) : null,
      likesCount: s.post._count.likes,
      commentsCount: s.post._count.comments,
      likedByMe: false,
      savedAt: s.createdAt.toISOString(),
      createdAt: s.post.createdAt.toISOString(),
      author: s.post.author,
    })),
    total: saved.length,
  });
}
