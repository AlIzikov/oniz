// BizON API — PATCH /api/applications/[id]/status
//
// Карьерный цикл отклика (Стратегия v5→v6: п.18 «Мой путь» + KPI Career Outcome Rate п.24
// + ЭТАП 7 Professional Memory — траектория).
//
// Обязанности:
//   (а) IDOR: менять статус может только владелец отклика;
//   (б) валидация перехода: вперёд по пайплайну (пропуски стадий разрешены,
//       назад — запрещено: interview→draft/preparing/submitted невозможны);
//   (в) статус-история statusHistory (JSON [{status, at: ISO}]) — append;
//   (г) при status='rejected' требуется и сохраняется rejectReason;
//   (д) Event Bus: подходящего типизированного события нет (реестр из 31 типа не
//       содержит job.application.status_changed; повторный job.applied дал бы ложное
//       уведомление «Отклик отправлен», а payload'ы строго типизированы без metadata) —
//       по ТЗ НЕ публикуем, ограничиваемся statusHistory;
//   (е) переходы в interview/offer/hired пишут ActionEvent (Professional Memory
//       траектория, ЭТАП 7): type 'job_interview' | 'job_offer' | 'job_hired',
//       isPublic: false (ActionEvent.type в схеме — String, отдельный тип безопасен).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

/** Порядок стадий карьерного цикла (чем больше число — тем дальше по «Моему пути») */
const STAGE_ORDER: Record<string, number> = {
  draft: 0,
  preparing: 1,
  submitted: 2,
  viewed: 3,
  reviewed: 4,
  interview: 5,
  offer: 6,
  accepted: 7,
  hired: 7,
};

/** Статусы, разрешённые в PATCH (draft создаётся только при создании отклика) */
const ALLOWED_TARGETS = new Set([
  'preparing', 'submitted', 'viewed', 'reviewed',
  'interview', 'offer', 'accepted', 'hired', 'rejected',
]);

/** Терминальные статусы: из них переходов нет */
const TERMINAL_STATUSES = new Set(['rejected', 'withdrawn']);

interface HistoryEntry {
  status: string;
  at: string;
  reason?: string;
}

/** Безопасный разбор statusHistory (JSON-строка в БД) */
function parseHistory(raw: string | null | undefined): HistoryEntry[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (e): e is HistoryEntry =>
        typeof e === 'object' && e !== null &&
        typeof (e as HistoryEntry).status === 'string' &&
        typeof (e as HistoryEntry).at === 'string'
    );
  } catch {
    return [];
  }
}

/** Траектория достигла ли статуса (по истории или текущему статусу) */
function reachedStage(history: HistoryEntry[], current: string, status: string): boolean {
  if (history.some((h) => h.status === status)) return true;
  // Fallback для legacy-откликов без истории: текущий статус = вершина траектории
  return (STAGE_ORDER[current] ?? -1) >= (STAGE_ORDER[status] ?? 999);
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // ── Тело запроса ──
  let body: { status?: unknown; rejectReason?: unknown };
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON в теле запроса', 400);
  }
  const target = typeof body.status === 'string' ? body.status : '';
  if (!ALLOWED_TARGETS.has(target)) {
    return errorJson(
      `Недопустимый статус «${target || '—'}». Разрешены: ${[...ALLOWED_TARGETS].join(', ')}`,
      400
    );
  }
  const rejectReason =
    typeof body.rejectReason === 'string' && body.rejectReason.trim().length > 0
      ? body.rejectReason.trim().slice(0, 500)
      : null;
  if (target === 'rejected' && !rejectReason) {
    return errorJson('При переводе в rejected требуется rejectReason (причина отказа)', 400);
  }

  // ── Отклик + владелец (IDOR) ──
  const application = await db.jobApplication.findUnique({
    where: { id },
    include: { job: { select: { id: true, title: true, company: true } } },
  });
  if (!application) return errorJson('Отклик не найден', 404);
  if (application.userId !== user.id) {
    return errorJson('Нет прав на изменение чужого отклика', 403);
  }

  const current = application.status;

  // ── Валидация перехода ──
  if (current === target) {
    // Идемпотентный no-op: статус не меняется, история не дублируется
    return json({
      application: {
        id: application.id,
        status: current,
        previousStatus: current,
        rejectReason: application.rejectReason,
        statusHistory: parseHistory(application.statusHistory),
      },
      changed: false,
      message: 'Отклик уже в этом статусе',
    });
  }
  if (TERMINAL_STATUSES.has(current)) {
    return errorJson(
      `Статус «${current}» терминальный — переходы из него запрещены`,
      422
    );
  }
  if (current === 'accepted' && target === 'hired') {
    // Единственный разрешённый переход внутри финальной стадии: принял → вышел на работу
  } else if (target === 'rejected') {
    // Отказ возможен из любой стадии ПОСЛЕ отправки отклика (submitted+);
    // отклонить черновик/подготовку нельзя — отклик ещё не отправлен.
    if ((STAGE_ORDER[current] ?? -1) < STAGE_ORDER.submitted) {
      return errorJson('Нельзя отклонить отклик до отправки (draft/preparing)', 422);
    }
  } else {
    const curOrder = STAGE_ORDER[current] ?? -1;
    const newOrder = STAGE_ORDER[target] ?? -1;
    if (curOrder === -1) {
      return errorJson(`Неизвестный текущий статус «${current}» — переход запрещён`, 422);
    }
    if (newOrder <= curOrder) {
      return errorJson(
        `Переход назад запрещён: ${current} → ${target}. Пайплайн движется только вперёд (пропуск стадий разрешён)`,
        422
      );
    }
  }

  // ── Статус-история: seed из createdAt для legacy-откликов + append ──
  const history = parseHistory(application.statusHistory);
  if (history.length === 0) {
    history.push({ status: current, at: application.createdAt.toISOString() });
  }
  history.push({ status: target, at: new Date().toISOString() });

  const updated = await db.jobApplication.update({
    where: { id: application.id },
    data: {
      status: target,
      // rejectReason пишем при отказе; при «возврате в игру» (не бывает — rejected терминален) не чистим
      rejectReason: target === 'rejected' ? rejectReason : application.rejectReason,
      statusHistory: JSON.stringify(history),
    },
  });

  // ── (е) Professional Memory траектория: ActionEvent для ключевых стадий ──
  // type — String в схеме; в union ActionEventType (action-event-service.ts, вне зоны)
  // эти типы не входят, поэтому пишем напрямую через db (fail-open).
  if (target === 'interview' || target === 'offer' || target === 'hired') {
    // Дедуп: не пишем второй раз тот же milestone (история уже содержит статус)
    const alreadyLogged = history.slice(0, -1).some((h) => h.status === target);
    if (!alreadyLogged) {
      const moment = {
        interview: {
          type: 'job_interview',
          title: `Интервью: ${application.job.title}`,
          description: `Собеседование по вакансии «${application.job.title}» (${application.job.company})`,
        },
        offer: {
          type: 'job_offer',
          title: `Предложение о работе: ${application.job.title}`,
          description: `Получено предложение по вакансии «${application.job.title}» (${application.job.company})`,
        },
        hired: {
          type: 'job_hired',
          title: `Выход на работу: ${application.job.title}`,
          description: `Вы вышли на работу по вакансии «${application.job.title}» (${application.job.company})`,
        },
      }[target] as { type: string; title: string; description: string };

      try {
        await db.actionEvent.create({
          data: {
            userId: user.id,
            type: moment.type,
            title: moment.title.slice(0, 300),
            description: moment.description.slice(0, 2000),
            metadata: JSON.stringify({
              applicationId: application.id,
              jobId: application.job.id,
              jobTitle: application.job.title,
              company: application.job.company,
              source: 'career-cycle',
            }),
            isPublic: false, // ЭТАП 7: траектория — приватная часть Professional Memory
          },
        });
      } catch (e) {
        // fail-open: логирование траектории не должно ломать смену статуса
        console.error('[applications/status] ActionEvent log failed:', e);
      }
    }
  }

  return json({
    application: {
      id: updated.id,
      status: updated.status,
      previousStatus: current,
      rejectReason: updated.rejectReason,
      statusHistory: parseHistory(updated.statusHistory),
    },
    job: { id: application.job.id, title: application.job.title },
    changed: true,
  });
}
