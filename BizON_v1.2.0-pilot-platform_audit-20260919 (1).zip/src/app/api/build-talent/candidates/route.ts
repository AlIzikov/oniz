// BizON API — /api/build-talent/candidates (doc_a §34, Task 9-g)
// ============================================================================
// Talent pool для компании/HR: ранжирование кандидатов под набор требуемых
// навыков (из Job.requiredSkills или явного списка) с explainable «why».
//
// GET  ?skills=TypeScript:8,Python [&companyId=...] [&jobId=...] [&limit=25]
// POST { skills?: string[], jobId?: string, companyId?: string, limit?: number }
//
// Доступ: только company | hr_agency (как публикация вакансий в /api/jobs).
// companyId: по умолчанию User.companyId; явный параметр разрешён только
// аккаунтам без привязки к компании (sandbox-реальность demo-аккаунтов,
// напр. GreenAI Corp). Аккаунт с companyId не может смотреть чужую компанию.
//
// Ответ: { totalCandidates, candidates: [...{score, matchedSkills, why}],
//          requiredSkills, formula, privacy, note? } — 200 даже при 0 кандидатов
//          (честный empty state), 422 при отсутствии навыков во входе.

import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';
import { BuildTalentService } from '@/lib/services/build-talent-service';
import type { RequiredSkill } from '@/lib/services/build-talent-service';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

type BuildTalentInput = {
  skills?: string[] | string | null;
  jobId?: string | null;
  companyId?: string | null;
  limit?: number;
};

/**
 * Разрешает компанию-заказчика. Возвращает errorJson-ответ при нарушении прав
 * или null, если доступ разрешён.
 */
function resolveCompanyAccess(
  user: { id: string; accountType: string; companyId: string | null },
  explicitCompanyId: string | null,
): { companyId: string | null } | { error: Response } {
  if (user.accountType !== 'company' && user.accountType !== 'hr_agency') {
    return { error: errorJson('Build Talent доступен только компаниям и HR-агентствам', 403) };
  }
  if (user.companyId) {
    if (explicitCompanyId && explicitCompanyId !== user.companyId) {
      return { error: errorJson('Доступ запрещён: нельзя смотреть talent pool чужой компании', 403) };
    }
    return { companyId: user.companyId };
  }
  // Sandbox: аккаунты компаний без привязки (companyId=null) могут указать
  // companyId явно — это документированное поведение, аналогичное /api/companies/[id]/*.
  return { companyId: explicitCompanyId };
}

async function handle(
  user: { id: string; accountType: string; companyId: string | null },
  input: BuildTalentInput,
): Promise<Response> {
  // 1) Права доступа + компания
  const access = resolveCompanyAccess(user, input.companyId ?? null);
  if ('error' in access) return access.error;
  let companyId = access.companyId;

  // 2) Требуемые навыки: jobId → Job.requiredSkills; явный skills приоритетнее
  let requiredSkills: RequiredSkill[] = [];
  if (typeof input.skills === 'string') {
    requiredSkills = BuildTalentService.parseSkillsCsv(input.skills);
  } else if (Array.isArray(input.skills)) {
    requiredSkills = BuildTalentService.parseSkillsCsv(
      input.skills.filter((s) => typeof s === 'string').join(','),
    );
  }

  let jobId: string | null = null;
  if (input.jobId && typeof input.jobId === 'string') {
    const job = await db.job.findUnique({
      where: { id: input.jobId },
      select: { id: true, title: true, companyId: true, requiredSkills: true },
    });
    if (!job) return errorJson('Вакансия не найдена', 404);
    // Вакансия чужой компании недоступна (если компания резолвится)
    if (companyId && job.companyId && job.companyId !== companyId) {
      return errorJson('Вакансия принадлежит другой компании', 403);
    }
    if (!companyId && job.companyId) companyId = job.companyId;
    if (requiredSkills.length === 0) {
      requiredSkills = BuildTalentService.parseSkillsCsv(job.requiredSkills);
    }
    jobId = job.id;
  }

  if (requiredSkills.length === 0) {
    return errorJson(
      'Укажите требуемые навыки: ?skills=TypeScript:8,Python или {skills:[...]} / {jobId}',
      422,
    );
  }

  // 3) Talent pool
  const result = await BuildTalentService.buildTalentPool({
    requiredSkills,
    companyId,
    jobId,
    limit: typeof input.limit === 'number' ? input.limit : undefined,
  });

  return json(result);
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'build-talent:candidates', 30, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter}с`, 429);

  const url = new URL(req.url);
  return handle(user, {
    skills: url.searchParams.get('skills'),
    jobId: url.searchParams.get('jobId'),
    companyId: url.searchParams.get('companyId'),
    limit: Number(url.searchParams.get('limit')) || undefined,
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'build-talent:candidates', 30, 60 * 60 * 1000);
  if (!rl.allowed) return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter}с`, 429);

  let body: BuildTalentInput;
  try {
    body = (await req.json()) ?? {};
  } catch {
    return errorJson('Неверный JSON', 400);
  }

  return handle(user, body);
}
