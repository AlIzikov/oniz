// NFT Skills API — список + минт
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

// Список NFT-навыков пользователя
export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const nftSkills = await db.nFTSkill.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
  });

  return json({ nftSkills });
}

// Запросить минт NFT для навыка (3+ подтверждений)
export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const { userSkillId } = await req.json();
    if (!userSkillId) return errorJson('userSkillId обязателен', 422);

    // Проверяем что навык имеет 3+ подтверждений
    const us = await db.userSkill.findUnique({
      where: { id: userSkillId },
      include: { skill: true },
    });
    if (!us || us.userId !== user.id) return errorJson('Навык не найден', 404);
    if (us.confirmationsCount < 3) {
      return errorJson(`Нужно 3+ подтверждений. Сейчас: ${us.confirmationsCount}`, 403);
    }

    // Проверяем — нет ли уже NFT
    const existing = await db.nFTSkill.findFirst({
      where: { userSkillId, status: { in: ['pending', 'minted'] } },
    });
    if (existing) return errorJson('NFT уже запрошен', 400);

    // Создаём запрос на минт (заглушка — в проде вызов смарт-контракта)
    const nft = await db.nFTSkill.create({
      data: {
        userSkillId,
        userId: user.id,
        skillName: us.skill.name,
        level: us.level,
        endorsementsCount: us.confirmationsCount,
        status: 'pending',
        metadataUri: `ipfs://bizon-skills/${us.skill.name.toLowerCase().replace(/\s+/g, '-')}-${user.id}`,
      },
    });

    return json({ nft }, 201);
  } catch (e) {
    return errorJson('Ошибка', 500);
  }
}
