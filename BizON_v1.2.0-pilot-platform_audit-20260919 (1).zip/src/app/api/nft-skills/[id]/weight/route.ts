// BizON API — /api/nft-skills/[id]/weight
// Этап 6.2 N: показать weight NFT-навыка (только для владельца)
//
// Логика:
//   - Если NFT уже сминчен — берём сохранённый weight
//   - Если ещё pending — пересчитываем через canMintNftSkill
//   - Доступ: только владелец NFT
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { NftSkillsService } from '@/lib/services';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  const nft = await db.nFTSkill.findUnique({
    where: { id },
  });

  if (!nft) return errorJson('NFT не найден', 404);
  if (nft.userId !== user.id) {
    return errorJson('Weight доступен только владельцу NFT', 403);
  }

  // Загружаем UserSkill + confirmations отдельно (нет прямой relation в schema)
  const userSkill = await db.userSkill.findUnique({
    where: { id: nft.userSkillId },
    include: {
      confirmations: { select: { confirmerId: true, createdAt: true } },
    },
  });

  // Если NFT сминчен — берём сохранённый weight
  if (nft.status === 'minted' && nft.weight > 0) {
    return json({
      nftId: nft.id,
      skillName: nft.skillName,
      weight: nft.weight,
      weightLabel: NftSkillsService.weightLabel(nft.weight),
      weightDescription: NftSkillsService.weightDescription(nft.weight),
      decayStatus: nft.decayStatus,
      lastConfirmedAt: nft.lastConfirmedAt?.toISOString() ?? null,
      status: nft.status,
      source: 'stored',
    });
  }

  // Если pending — пересчитываем через canMintNftSkill
  // Берём лучшего confirmer'а
  const confirmerIds = userSkill
    ? [...new Set(userSkill.confirmations.map((c) => c.confirmerId))]
    : [];
  let bestWeight = 0;
  let bestReason = 'Нет подтверждений';
  let bestDetails: any = null;
  let bestConfirmerId: string | null = null;

  for (const confirmerId of confirmerIds) {
    const check = await NftSkillsService.canMintNftSkill(
      nft.userSkillId,
      confirmerId,
      nft.userId,
    );
    if (check.weight > bestWeight) {
      bestWeight = check.weight;
      bestReason = check.reason;
      bestDetails = check.details;
      bestConfirmerId = confirmerId;
    }
  }

  return json({
    nftId: nft.id,
    skillName: nft.skillName,
    weight: bestWeight,
    weightLabel: NftSkillsService.weightLabel(bestWeight),
    weightDescription: NftSkillsService.weightDescription(bestWeight),
    decayStatus: bestDetails?.decayStatus ?? nft.decayStatus,
    lastConfirmedAt: nft.lastConfirmedAt?.toISOString() ?? null,
    status: nft.status,
    source: 'computed',
    confirmerId: bestConfirmerId,
    reason: bestReason,
    details: bestDetails,
  });
}
