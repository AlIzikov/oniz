// NFT Skill — минт (заглушка смарт-контракта)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  const nft = await db.nFTSkill.findUnique({ where: { id } });
  if (!nft || nft.userId !== user.id) return errorJson('NFT не найден', 404);
  if (nft.status === 'minted') return errorJson('Уже сминчено', 400);

  // Заглушка минта — в проде вызов ERC-1155 контракта на Polygon
  const tokenId = `0x${Math.random().toString(16).slice(2).padStart(64, '0').slice(0, 64)}`;
  const contractAddress = '0xBizON1155ContractAddress';

  const updated = await db.nFTSkill.update({
    where: { id },
    data: {
      status: 'minted',
      tokenId,
      contractAddress,
      mintedAt: new Date(),
    },
  });

  return json({ nft: updated });
}
