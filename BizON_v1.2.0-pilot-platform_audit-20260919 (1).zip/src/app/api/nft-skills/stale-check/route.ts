// BizON API — /api/nft-skills/stale-check
// Этап 6.2 N: admin cron — помечать decayed навыки.
//
// Принимает запрос от admin-пользователя (роль 'admin') и запускает
// массовую проверку decay по всем NFT-навыкам.
//
// Защита: только admin. В проде — вызов из cron-сервиса с api-key.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { NftSkillsService } from '@/lib/services';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (!isAdminRole(user.roles)) {
    return errorJson('Только администратор может запускать stale-check', 403);
  }

  try {
    const result = await NftSkillsService.massCheckDecay({ batchSize: 500 });
    return json({
      ok: true,
      ...result,
      message: `Проверено ${result.checked} NFT-навыков, обновлено ${result.updated}. Свежих: ${result.summary.fresh}, устаревших: ${result.summary.stale}, протухших: ${result.summary.decayed}.`,
    });
  } catch (e) {
    console.error('[nft-skills/stale-check] error:', e);
    return errorJson('Ошибка при массовом обновлении decay-статусов', 500);
  }
}
