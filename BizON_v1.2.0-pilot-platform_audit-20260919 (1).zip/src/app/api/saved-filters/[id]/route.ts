// BizON API — /api/saved-filters/[id] (Wave 11-c, фильтры-мониторы)
//
// PATCH  → переименовать / изменить параметры / переключить мониторинг.
//          White-list полей: name, params, monitoring. ТОЛЬКО владелец.
//          lastRunAt намеренно НЕ принимается (поле для будущих cron'ов).
// DELETE → удалить фильтр. ТОЛЬКО владелец.
//
// 401 не авторизован; 404 фильтр не найден или чужой; 422 валидация; 429 rate-limit.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const MAX_NAME_LENGTH = 60;
const MAX_PARAMS_BYTES = 2048;
const MUTATION_RATE_LIMIT = [30, 60 * 1000] as const;

type ParamsValue = Record<string, unknown>;

/** Валидирует params (строка с JSON или объект) → каноничная строка ≤2КБ. */
function validateParams(raw: unknown): { ok: true; value: string } | { ok: false; error: string } {
  let parsed: unknown;
  if (typeof raw === 'string') {
    try {
      parsed = JSON.parse(raw);
    } catch {
      return { ok: false, error: 'params должен быть валидным JSON' };
    }
  } else {
    parsed = raw;
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { ok: false, error: 'params должен быть JSON-объектом вида { q, mode, ... }' };
  }
  const obj = parsed as ParamsValue;
  for (const [k, v] of Object.entries(obj)) {
    if (!['string', 'number', 'boolean'].includes(typeof v)) {
      return { ok: false, error: `params.${k}: допускаются только строковые/числовые/булевы значения` };
    }
  }
  const serialized = JSON.stringify(obj);
  if (Buffer.byteLength(serialized, 'utf8') > MAX_PARAMS_BYTES) {
    return { ok: false, error: `Максимум ${Math.floor(MAX_PARAMS_BYTES / 1024)}КБ параметров фильтра` };
  }
  return { ok: true, value: serialized };
}

/** Загружает фильтр и проверяет владение (чужой/несуществующий → 404). */
async function loadOwnFilter(id: string, userId: string) {
  const filter = await db.savedFilter.findUnique({ where: { id } });
  if (!filter || filter.userId !== userId) return null;
  return filter;
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'saved-filters:mutate', ...MUTATION_RATE_LIMIT);
  if (!rl.allowed) {
    return errorJson('Слишком много действий подряд — попробуйте через минуту.', 429);
  }

  const filter = await loadOwnFilter(id, user.id);
  if (!filter) return errorJson('Фильтр не найден', 404);

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON в теле запроса', 400);
  }

  const data: { name?: string; params?: string; monitoring?: boolean } = {};

  if (body.name !== undefined) {
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    if (name.length < 1) return errorJson('Название фильтра обязательно', 422);
    if (name.length > MAX_NAME_LENGTH) return errorJson(`Максимум ${MAX_NAME_LENGTH} символов в названии`, 422);
    data.name = name;
  }

  if (body.params !== undefined) {
    const paramsResult = validateParams(body.params);
    if (!paramsResult.ok) return errorJson(paramsResult.error, 422);
    data.params = paramsResult.value;
  }

  if (body.monitoring !== undefined) {
    data.monitoring = body.monitoring === true;
  }

  if (Object.keys(data).length === 0) {
    return errorJson('Нечего обновлять: передайте name, params и/или monitoring', 422);
  }

  const updated = await db.savedFilter.update({ where: { id: filter.id }, data });

  return json({
    item: {
      id: updated.id,
      name: updated.name,
      target: updated.target,
      params: updated.params,
      monitoring: updated.monitoring,
      lastRunAt: updated.lastRunAt?.toISOString() ?? null,
      createdAt: updated.createdAt.toISOString(),
    },
  });
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'saved-filters:mutate', ...MUTATION_RATE_LIMIT);
  if (!rl.allowed) {
    return errorJson('Слишком много действий подряд — попробуйте через минуту.', 429);
  }

  const filter = await loadOwnFilter(id, user.id);
  if (!filter) return errorJson('Фильтр не найден', 404);

  await db.savedFilter.delete({ where: { id: filter.id } });

  return json({ ok: true });
}
