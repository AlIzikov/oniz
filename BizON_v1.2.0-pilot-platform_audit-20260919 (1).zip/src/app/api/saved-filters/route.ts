// BizON API — /api/saved-filters (Wave 11-c, отзыв пользователя: «Избранные фильтры»)
//
// Фильтры-мониторы для поиска работы: пользователь настраивает поиск в разделе
// «Работа», сохраняет его как фильтр (максимум 9 на пользователя — по отзыву),
// и может в один клик применить фильтр обратно к поиску.
//
// МОДЕЛЬ: SavedFilter (prisma/schema.prisma — userId, name ≤60, target,
// params JSON-строка, monitoring, lastRunAt?, createdAt).
//
// КОНТРАКТЫ:
//   GET  → 200 { items: [{ id, name, target, params, paramsParsed, monitoring,
//                        lastRunAt, createdAt }], cap } — только свои, createdAt asc.
//          params отдаётся как есть (строкой) + paramsParsed (безопасный парс)
//          для удобства фронта.
//   POST → 200 { item, cap } — создать фильтр.
//     Валидация: name 1..60 (после trim); target ∈ jobs|projects|news|people
//     (default 'jobs'); params — валидный JSON-ОБЪЕКТ ≤2КБ после stringify
//     (принимаем строку с JSON или готовый объект); monitoring boolean
//     (default false).
//     КАП: не более 9 фильтров на пользователя → 422
//     «Максимум 9 фильтров — удалите один из старых».
//   401 не авторизован; 400 некорректный JSON тела; 422 валидация; 429 rate-limit.
//
// lastRunAt здесь НЕ трогаем — поле для будущих cron-мониторов (честно не
// имитируем «отслеживание», которого в этой волне нет; monitoring — только
// намерение пользователя, сервером пока не исполняется).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

// Отзыв пользователя: «максимум не более 9 фильтров»
export const SAVED_FILTERS_CAP = 9;
// Белый список целей (в этой волне UI использует только 'jobs')
const TARGETS = ['jobs', 'projects', 'news', 'people'] as const;
const MAX_NAME_LENGTH = 60;
const MAX_PARAMS_BYTES = 2048; // ≤2КБ после stringify
// Мутации: 20/мин/юзер (создание фильтров — редкое действие, анти-спам)
const FILTERS_RATE_LIMIT = [20, 60 * 1000] as const;

type ParamsValue = Record<string, unknown>;

/** Валидирует params (строка с JSON или объект) → каноничная строка ≤2КБ. */
function validateParams(raw: unknown): { ok: true; value: string; parsed: ParamsValue } | { ok: false; error: string } {
  let parsed: unknown;
  if (typeof raw === 'string') {
    try {
      parsed = JSON.parse(raw);
    } catch {
      return { ok: false, error: 'params должен быть валидным JSON' };
    }
  } else {
    parsed = raw;
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { ok: false, error: 'params должен быть JSON-объектом вида { q, mode, ... }' };
  }
  const obj = parsed as ParamsValue;
  // Значения params — только строки/числа/булевы (защита от вложенных payload'ов)
  for (const [k, v] of Object.entries(obj)) {
    if (!['string', 'number', 'boolean'].includes(typeof v)) {
      return { ok: false, error: `params.${k}: допускаются только строковые/числовые/булевы значения` };
    }
  }
  const serialized = JSON.stringify(obj);
  if (Buffer.byteLength(serialized, 'utf8') > MAX_PARAMS_BYTES) {
    return { ok: false, error: `Максимум ${Math.floor(MAX_PARAMS_BYTES / 1024)}КБ параметров фильтра` };
  }
  return { ok: true, value: serialized, parsed: obj };
}

/** Безопасный парс params из БД (поле может содержать произвольную историю). */
function safeParseParams(raw: string): ParamsValue | null {
  try {
    const parsed: unknown = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as ParamsValue;
    }
    return null;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rows = await db.savedFilter.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'asc' },
    take: 50,
  });

  return json({
    items: rows.map((f) => ({
      id: f.id,
      name: f.name,
      target: f.target,
      params: f.params,
      paramsParsed: safeParseParams(f.params),
      monitoring: f.monitoring,
      lastRunAt: f.lastRunAt?.toISOString() ?? null,
      createdAt: f.createdAt.toISOString(),
    })),
    cap: SAVED_FILTERS_CAP,
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'saved-filters:create', ...FILTERS_RATE_LIMIT);
  if (!rl.allowed) {
    return errorJson('Слишком много действий подряд — попробуйте через минуту.', 429);
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON в теле запроса', 400);
  }

  // --- name ---
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (name.length < 1) return errorJson('Название фильтра обязательно', 422);
  if (name.length > MAX_NAME_LENGTH) return errorJson(`Максимум ${MAX_NAME_LENGTH} символов в названии`, 422);

  // --- target (white-list) ---
  const target = typeof body.target === 'string' && body.target.trim() ? body.target.trim() : 'jobs';
  if (!(TARGETS as readonly string[]).includes(target)) {
    return errorJson(`target должен быть одним из: ${TARGETS.join(', ')}`, 422);
  }

  // --- params ---
  const paramsResult = validateParams(body.params ?? {});
  if (!paramsResult.ok) return errorJson(paramsResult.error, 422);

  // --- monitoring ---
  const monitoring = body.monitoring === undefined ? false : body.monitoring === true;

  // --- КАП 9 на пользователя (по отзыву) ---
  const count = await db.savedFilter.count({ where: { userId: user.id } });
  if (count >= SAVED_FILTERS_CAP) {
    return errorJson(`Максимум ${SAVED_FILTERS_CAP} фильтров — удалите один из старых`, 422);
  }

  const created = await db.savedFilter.create({
    data: {
      userId: user.id,
      name,
      target,
      params: paramsResult.value,
      monitoring,
    },
  });

  return json({
    item: {
      id: created.id,
      name: created.name,
      target: created.target,
      params: created.params,
      paramsParsed: paramsResult.parsed,
      monitoring: created.monitoring,
      lastRunAt: null,
      createdAt: created.createdAt.toISOString(),
    },
    cap: SAVED_FILTERS_CAP,
  }, 200);
}
