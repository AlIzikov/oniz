// BizON API — /api/opportunities (Phase 5: Opportunity Engine)
// GET — список возможностей для текущего пользователя.
//   Query:
//     type=job|project|mentor|partnership|expert|education|event|business
//     limit=10 (1..50)
//
// Если type не задан — берём типы, соответствующие активным Intent'ам пользователя
// (job_search → job, project_search → project, и т.д.). Если активных Intent'ов
// нет — возвращаем микс типов (job + project + event + education).
import { NextRequest } from 'next/server';
import { json, errorJson, getUserFromRequest } from '@/lib/api-helpers';
import { OpportunityService } from '@/lib/services/opportunity-service';
import type { OpportunityType } from '@/lib/services/opportunity-service';

export const runtime = 'nodejs';

const VALID_TYPES: OpportunityType[] = [
  'job',
  'project',
  'mentor',
  'partnership',
  'expert',
  'education',
  'event',
  'business',
  // === Wave 5 (S-102): 12 типов ===
  'cofounder',
  'supplier',
  'investor',
  'gig',
];

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const sp = req.nextUrl.searchParams;
  const typeParam = sp.get('type');
  const limitParam = sp.get('limit');

  let type: OpportunityType | undefined;
  if (typeParam) {
    if (!VALID_TYPES.includes(typeParam as OpportunityType)) {
      return errorJson(
        `type должен быть одним из: ${VALID_TYPES.join(', ')}`,
        422,
      );
    }
    type = typeParam as OpportunityType;
  }

  let limit = 10;
  if (limitParam) {
    const parsed = parseInt(limitParam, 10);
    if (!Number.isFinite(parsed) || parsed < 1 || parsed > 50) {
      return errorJson('limit должен быть числом 1..50', 422);
    }
    limit = parsed;
  }

  try {
    const items = await OpportunityService.findOpportunities(user.id, { type, limit });
    return json({
      items,
      total: items.length,
      type: type ?? 'auto',
      generatedAt: new Date().toISOString(),
    });
  } catch (e: any) {
    console.error('[api/opportunities GET] error:', e);
    return errorJson('Ошибка поиска возможностей. Попробуйте позже.', 500);
  }
}
