// BizON API — /api/opportunities/radar (Wave 5, S-114, §71 Opportunity Radar).
// Прогноз возможностей 3/7/30/90 дней (RMI — внутренний сигнал, §3.3:
// публичны только окна и объяснения). Честный гейт: <7 дней истории →
// dataSufficient=false без имитации прогноза.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { OpportunityRadar } from '@/lib/services/opportunity-radar';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const forecast = await OpportunityRadar.forecast(ctx.user.id);
  return NextResponse.json(forecast);
});
