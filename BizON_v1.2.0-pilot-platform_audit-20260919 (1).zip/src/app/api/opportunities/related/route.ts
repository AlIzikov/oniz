// BizON API — /api/opportunities/related (Wave 5, S-105: Opportunity Graph).
// Граф-навигация между типами возможностей от опорной сущности:
//   project → gig-лоты проекта + вакансии компании-владельца + события компании
//   job → другие вакансии компании + gig лоты проекта с теми же скиллами
//   company → вакансии + события + bridge-возможности (supplier/investor)
// Честные рёбра: только реальные связи в БД, без синтетики.
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

const querySchema = z.object({
  projectId: z.string().optional(),
  jobId: z.string().optional(),
  companyId: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(20).optional(),
});

export const GET = withRoute(async (req, ctx) => {
  const q = querySchema.parse(ctx.data);
  const limit = q.limit ?? 8;
  const related: Array<{ kind: string; type: string; id: string; title: string; meta?: Record<string, unknown> }> = [];

  let companyId = q.companyId ?? null;
  let projectId = q.projectId ?? null;

  // От вакансии → компания и скиллы
  if (q.jobId) {
    const job = await db.job.findUnique({
      where: { id: q.jobId },
      select: { id: true, companyId: true, requiredSkills: true },
    });
    if (!job) return NextResponse.json({ related: [] });
    companyId = companyId ?? job.companyId;
    if (companyId) {
      const jobs = await db.job.findMany({
        where: { companyId, active: true, id: { not: job.id } },
        select: { id: true, title: true },
        take: limit,
      });
      for (const j of jobs) related.push({ kind: 'job', type: 'job', id: j.id, title: j.title });
    }
    const skills = job.requiredSkills.split(',').map((s) => s.trim()).filter(Boolean);
    if (skills.length > 0) {
      const gigs = await db.projectLot.findMany({
        where: {
          status: 'open',
          OR: skills.map((s) => ({ skills: { contains: s } })),
        },
        select: { id: true, title: true, projectId: true, budgetLumens: true },
        take: limit,
      });
      for (const g of gigs) related.push({ kind: 'gig', type: 'gig', id: g.id, title: g.title, meta: { projectId: g.projectId, budgetLumens: g.budgetLumens } });
    }
  }

  // От проекта → LOT'ы + cofounder/investor-соседи
  if (projectId) {
    const lots = await db.projectLot.findMany({
      where: { projectId, status: { in: ['open', 'accepted'] } },
      select: { id: true, title: true, budgetLumens: true },
      take: limit,
    });
    for (const l of lots) related.push({ kind: 'gig', type: 'gig', id: l.id, title: l.title, meta: { budgetLumens: l.budgetLumens } });
    const project = await db.project.findUnique({ where: { id: projectId }, select: { companyId: true, fundingType: true } });
    companyId = companyId ?? project?.companyId ?? null;
  }

  // От компании → вакансии, события, bridge-возможности
  if (companyId) {
    const jobs = await db.job.findMany({
      where: { companyId, active: true },
      select: { id: true, title: true },
      take: limit,
    });
    for (const j of jobs) related.push({ kind: 'job', type: 'job', id: j.id, title: j.title });
    const events = await db.event.findMany({
      where: { companyId, status: { not: 'cancelled' }, startDate: { gt: new Date() } },
      select: { id: true, title: true },
      take: limit,
    });
    for (const e of events) related.push({ kind: 'event', type: 'event', id: e.id, title: e.title });
    const bridgeOpps = await db.opportunity.findMany({
      where: { companyId, type: { in: ['supplier', 'investor'] } },
      select: { id: true, title: true, type: true },
      take: limit,
      orderBy: { createdAt: 'desc' },
    });
    for (const o of bridgeOpps) related.push({ kind: o.type, type: o.type, id: o.id, title: o.title });
  }

  // дедуп по (kind,id)
  const seen = new Set<string>();
  const deduped = related.filter((r) => {
    const key = `${r.kind}:${r.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return NextResponse.json({ related: deduped.slice(0, limit * 2) });
}, { auth: false });
