// BizON API — /api/subscriptions
// Использует PaymentService (микросервисный слой) — без дублирования PLANS
// FIX-07: POST/DELETE через withRoute — auth 401, zod-схема subscribePlan,
// единый маппинг ошибок (Prisma P2002→409, P2025→404); без сырых e.message для 5xx.
import { json, toUserPublic, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { PaymentService, PLANS } from '@/lib/services';
import type { SubscriptionTier } from '@/lib/types';

export const runtime = 'nodejs';

export async function GET() {
  // PLANS импортируются из PaymentService — без дублирования
  return json({ plans: PLANS });
}

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;
    const { tier, period } = ctx.data as { tier: 'pro' | 'business'; period: 'monthly' | 'yearly' };

    const result = await PaymentService.subscribe(user.id, tier as SubscriptionTier, period);
    const publicUser = await toUserPublic(result.user as never);
    return json({
      user: publicUser,
      tier,
      period,
      activeUntil: result.activeUntil.toISOString(),
      paymentUrl: null,
      message: `Подписка активирована на ${period === 'yearly' ? 'год' : 'месяц'}`,
    });
  },
  { schema: schemas.subscribePlan },
);

export const DELETE = withRoute(async (req, ctx) => {
  const user = ctx.user!;

  const updated = await PaymentService.unsubscribe(user.id);
  const publicUser = await toUserPublic(updated as never);
  return json({ user: publicUser, message: 'Подписка отменена' });
});
