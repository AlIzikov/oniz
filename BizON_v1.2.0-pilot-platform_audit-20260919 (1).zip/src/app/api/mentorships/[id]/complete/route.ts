// BizON API — POST /api/mentorships/[id]/complete
// Phase 11: Mentor Graph — завершить наставничество с оценкой и growth-данными.
//
// Тело:
//   {
//     rating: 1..5,
//     growth: {
//       skillBefore: 1..10,
//       skillAfter:  1..10,
//       newProjects?: number,
//       newRole?:     string | null
//     }
//   }
//
// Только mentee может завершить наставничество.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MentorService } from '@/lib/services/mentor-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id: mentorshipId } = await ctx.params;

  try {
    const body = await req.json();
    const { rating, growth } = body ?? {};

    if (typeof rating !== 'number' || rating < 1 || rating > 5) {
      return errorJson('rating должен быть числом от 1 до 5', 422);
    }
    if (!growth || typeof growth !== 'object') {
      return errorJson('growth обязателен', 422);
    }
    if (typeof growth.skillBefore !== 'number' || typeof growth.skillAfter !== 'number') {
      return errorJson('growth.skillBefore и growth.skillAfter обязательны (числа)', 422);
    }

    const result = await MentorService.completeMentorship(
      mentorshipId,
      user.id,
      rating,
      growth,
    );
    return json({ mentorship: result });
  } catch (e: any) {
    const msg = e?.message ?? 'Ошибка завершения наставничества';
    const status = msg.includes('не найден') ? 404
      : msg.includes('Только mentee') ? 403
      : 422;
    console.error('[api/mentorships/[id]/complete] error:', e);
    return errorJson(msg, status);
  }
}
