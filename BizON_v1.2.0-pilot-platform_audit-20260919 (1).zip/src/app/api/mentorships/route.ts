// BizON API — POST /api/mentorships
// Phase 11: Mentor Graph — создать наставничество (mentee → mentor).
//
// Тело:
//   { mentorId: string, skillId?: string }
//
// Текущий пользователь = mentee.
// Запрещено: mentee === mentor, повторное активное наставничество по тому же skillId.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MentorService } from '@/lib/services/mentor-service';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(
    user.id,
    'mentorships:create',
    ...MUTATION_LIMITS.connectionsCreate,
  );
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { mentorId, skillId } = body ?? {};

    if (!mentorId || typeof mentorId !== 'string') {
      return errorJson('mentorId обязателен', 422);
    }
    if (skillId !== undefined && skillId !== null && typeof skillId !== 'string') {
      return errorJson('skillId должен быть строкой', 422);
    }

    const result = await MentorService.startMentorship(
      mentorId,
      user.id,
      skillId ?? null,
    );
    return json({ mentorship: result }, 201);
  } catch (e: any) {
    const msg = e?.message ?? 'Ошибка создания наставничества';
    // Семантические ошибки — 422, прочие — 500
    const status = msg.includes('не найден') || msg.includes('не может') || msg.includes('нельзя')
      ? 422
      : 500;
    console.error('[api/mentorships/create] error:', e);
    return errorJson(msg, status);
  }
}
