// BizON API — /api/intros (Wave 1 «Кольцо доверия», S-015).
// POST — создать интро-запрос (через introService: guard + matchmaker + governance).
// GET  — список моих интро (?box=incoming|outgoing|all).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';
import { introService } from '@/lib/services/intro-service';
import { checkVelocity } from '@/lib/security/velocity';

export const runtime = 'nodejs';

const createSchema = z.object({
  targetId: z.string().min(1).max(64),
  purpose: z.enum(['job', 'project', 'mentorship', 'partnership', 'other']),
  message: z.string().max(2000).optional(),
});

export const POST = withRoute(async (req, ctx) => {
  const data = createSchema.parse(ctx.data);

  // Тир верификации → velocity-лимит (§8.2-1/§8.2-3): basic = 4x ниже.
  const tierRow = await db.user.findUnique({ where: { id: ctx.user.id }, select: { verificationTier: true } });
  const tier = tierRow?.verificationTier ?? 'basic';
  if (!checkVelocity(ctx.user.id, { key: 'intro', limit: 20, windowMs: 60 * 60 * 1000 }, tier)) {
    return NextResponse.json({ error: 'Слишком много запросов на знакомство. Попробуйте позже.' }, { status: 429 });
  }

  const created = await introService.create(ctx.user.id, data.targetId, data.purpose, data.message);
  return NextResponse.json(
    { id: created.id, introducerId: created.introducerId, introducerName: created.introducerName, expiresAt: created.expiresAt.toISOString() },
    { status: 201 },
  );
}, { rateLimit: { key: 'intros-post', limit: 30, windowMs: 60 * 60 * 1000 } });

export const GET = withRoute(async (req, ctx) => {
  const box = new URL(req.url).searchParams.get('box') ?? 'all';
  const where =
    box === 'incoming' ? { introducerId: ctx.user.id } :
    box === 'outgoing' ? { requesterId: ctx.user.id } :
    { OR: [{ introducerId: ctx.user.id }, { requesterId: ctx.user.id }] };

  const rows = await db.introductionRequest.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 50,
    select: {
      id: true, requesterId: true, introducerId: true, targetId: true,
      purpose: true, status: true, createdAt: true, expiresAt: true,
      requester: { select: { id: true, name: true, title: true, avatarUrl: true } },
      introducer: { select: { id: true, name: true, avatarUrl: true } },
      target: { select: { id: true, name: true, title: true, avatarUrl: true } },
    },
  });

  return NextResponse.json({
    intros: rows.map((r) => ({
      id: r.id,
      purpose: r.purpose,
      status: r.status,
      createdAt: r.createdAt.toISOString(),
      expiresAt: r.expiresAt.toISOString(),
      requester: r.requester,
      introducer: r.introducer,
      target: r.target,
      role:
        r.introducerId === ctx.user.id ? 'introducer' :
        r.requesterId === ctx.user.id ? 'requester' : 'target',
    })),
  });
});
