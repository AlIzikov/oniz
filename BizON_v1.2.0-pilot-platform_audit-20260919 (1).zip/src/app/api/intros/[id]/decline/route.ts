// BizON API — /api/intros/[id]/decline (S-015): отказ посредника.
// Текст requester'а цели НЕ передаётся.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { introService } from '@/lib/services/intro-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (_req, ctx) => {
  await introService.decline(ctx.params.id, ctx.user.id);
  return NextResponse.json({ ok: true });
});
