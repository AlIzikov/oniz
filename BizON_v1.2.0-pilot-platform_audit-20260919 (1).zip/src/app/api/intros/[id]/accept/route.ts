// BizON API — /api/intros/[id]/accept (S-015): согласие посредника.
// Только introducer может принять; сообщение уходит цели внутри сервиса.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { introService } from '@/lib/services/intro-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (_req, ctx) => {
  await introService.accept(ctx.params.id, ctx.user.id);
  return NextResponse.json({ ok: true });
});
