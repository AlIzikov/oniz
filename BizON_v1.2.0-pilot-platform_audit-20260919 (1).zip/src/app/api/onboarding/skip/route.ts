// Onboarding — skip
// Этап 6.4 — ONB: пропустить онбординг.
// Разрешено только если ipScore > 50.
//
// POST /api/onboarding/skip
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { OnboardingService, TOTAL_ONBOARDING_STEPS } from '@/lib/services/onboarding-service';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // UserLike требует onboardingStep, которого нет в auth-DTO — берём из БД
  const current = await db.user.findUnique({
    where: { id: user.id },
    select: { onboardingStep: true },
  });
  const userLike = {
    id: user.id,
    accountType: user.accountType,
    onboardingStep: current?.onboardingStep ?? 0,
    ipScore: user.ipScore,
  };

  const result = await OnboardingService.skip(userLike);
  if (!result.ok) {
    return errorJson(result.reason ?? 'Пропуск онбординга недоступен', 403);
  }

  const fresh = await db.user.findUnique({
    where: { id: user.id },
    select: { onboardingStep: true },
  });

  return json({
    ok: true,
    onboardingStep: fresh?.onboardingStep ?? TOTAL_ONBOARDING_STEPS,
    isComplete: true,
  });
}
