// Onboarding — complete-step
// Этап 6.4 — ONB: отметить шаг выполненным.
//
// POST /api/onboarding/complete-step
// Body: { step: 1..5 }
//
// Правила:
//   - step должен быть 1..5
//   - не уменьшаем прогресс (если уже на шаге 3, попытка завершить шаг 2 игнорируется)
//   - можно перепрыгивать вперёд (если пользователь уже сделал что-то раньше)
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { OnboardingService, TOTAL_ONBOARDING_STEPS } from '@/lib/services/onboarding-service';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  let body: any;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 422);
  }

  const step = Number(body?.step);
  if (!Number.isInteger(step) || step < 1 || step > TOTAL_ONBOARDING_STEPS) {
    return errorJson(`step должен быть целым от 1 до ${TOTAL_ONBOARDING_STEPS}`, 422);
  }

  // UserLike требует onboardingStep, которого нет в auth-DTO — берём из БД
  const current = await db.user.findUnique({
    where: { id: user.id },
    select: { onboardingStep: true },
  });
  const userLike = {
    id: user.id,
    accountType: user.accountType,
    onboardingStep: current?.onboardingStep ?? 0,
    ipScore: user.ipScore,
  };

  // Завершаем шаг
  const newStep = await OnboardingService.completeStep(userLike, step);

  // Если только что завершили онбординг (newStep === 5 и старый < 5) —
  // можно залогировать через ActionEvent (но не обязательно)
  if (newStep >= TOTAL_ONBOARDING_STEPS && userLike.onboardingStep < TOTAL_ONBOARDING_STEPS) {
    // Обновляем user в store клиента — возвращаем обновлённый onboardingStep
  }

  // Возвращаем обновлённый прогресс (перечитываем из БД для надёжности)
  const fresh = await db.user.findUnique({
    where: { id: user.id },
    select: { onboardingStep: true },
  });

  return json({
    ok: true,
    onboardingStep: fresh?.onboardingStep ?? newStep,
    isComplete: (fresh?.onboardingStep ?? newStep) >= TOTAL_ONBOARDING_STEPS,
  });
}
