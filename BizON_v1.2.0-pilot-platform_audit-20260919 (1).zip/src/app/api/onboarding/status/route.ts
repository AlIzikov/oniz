// Onboarding — status
// Этап 6.4 — ONB: текущий шаг + прогресс.
//
// GET /api/onboarding/status
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { OnboardingService } from '@/lib/services/onboarding-service';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // UserLike требует onboardingStep, которого нет в auth-DTO — берём из БД
  const current = await db.user.findUnique({
    where: { id: user.id },
    select: { onboardingStep: true },
  });
  const userLike = {
    id: user.id,
    accountType: user.accountType,
    onboardingStep: current?.onboardingStep ?? 0,
    ipScore: user.ipScore,
  };

  const progress = OnboardingService.getProgress(userLike);
  const canSkip = user.ipScore > 50;

  return json({
    step: progress.step,
    total: progress.total,
    percent: progress.percent,
    isComplete: progress.isComplete,
    steps: progress.steps,
    canSkip,
    ipScore: user.ipScore,
    accountType: user.accountType,
  });
}
