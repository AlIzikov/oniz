// BizON API — /api/skills (add skill to user profile)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { name, level, category } = body ?? {};
    if (!name) return errorJson('name обязательно', 422);

    // find or create skill
    const skill = await db.skill.upsert({
      where: { name },
      create: { name, category: category ?? null },
      update: {},
    });

    const existing = await db.userSkill.findUnique({
      where: { userId_skillId: { userId: user.id, skillId: skill.id } },
    }).catch(() => null);
    if (existing) return errorJson('Навык уже добавлен', 400);

    const us = await db.userSkill.create({
      data: {
        userId: user.id,
        skillId: skill.id,
        level: Math.max(1, Math.min(5, Number(level ?? 1))),
      },
      include: { skill: true },
    });

    return json({
      userSkill: {
        id: us.id,
        level: us.level,
        confirmationsCount: us.confirmationsCount,
        nftEligible: us.nftEligible,
        skill: { id: us.skill.id, name: us.skill.name, category: us.skill.category },
      },
    }, 201);
  } catch (e) {
    console.error('[skills/add] error:', e);
    return errorJson('Ошибка добавления навыка', 500);
  }
}
