// BizON API — /api/skills/confirm
// FR-4: Подтверждение навыка возможно только при наличии общего завершённого проекта
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { ReputationService } from '@/lib/services';
import { computeImpactScore } from '@/lib/reputation';
import { EventBus } from '@/lib/event-bus';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json();
    const { userSkillId, projectId, comment } = body ?? {};
    if (!userSkillId || !projectId) return errorJson('userSkillId и projectId обязательны', 422);

    // 1. Получаем userSkill — чей навык подтверждается
    const us = await db.userSkill.findUnique({
      where: { id: userSkillId },
      include: { skill: true },
    });
    if (!us) return errorJson('Навык не найден', 404);

    // Нельзя подтверждать свой навык
    if (us.userId === user.id) return errorJson('Нельзя подтверждать свой навык', 400);

    // 2. Проверка общего проекта (FR-4)
    const myMembership = await db.projectMember.findUnique({
      where: { projectId_userId: { projectId, userId: user.id } },
    }).catch(() => null);
    const theirMembership = await db.projectMember.findUnique({
      where: { projectId_userId: { projectId, userId: us.userId } },
    }).catch(() => null);

    if (!myMembership || !theirMembership) {
      return errorJson('Подтверждение возможно только через общий проект (ТЗ FR-4)', 403);
    }

    // 3. Проверка — не подтверждён ли уже этим пользователем
    const existing = await db.skillConfirmation.findUnique({
      where: {
        userSkillId_confirmerId_projectId: {
          userSkillId, confirmerId: user.id, projectId,
        },
      },
    }).catch(() => null);
    if (existing) return errorJson('Вы уже подтвердили этот навык в этом проекте', 400);

    // 4. Создаём подтверждение
    const conf = await db.skillConfirmation.create({
      data: { userSkillId, confirmerId: user.id, projectId, comment },
    });

    // Event Bus: навык подтверждён (публикация не должна ломать подтверждение)
    try {
      void EventBus.publish('skill.verified', {
        userId: us.userId,
        skillId: us.skillId,
        skillName: us.skill.name,
      }).catch(() => undefined);
    } catch {
      // fail-open: ошибки шины игнорируем
    }

    // 5. Увеличиваем счётчик
    await db.userSkill.update({
      where: { id: userSkillId },
      data: {
        confirmationsCount: { increment: 1 },
        nftEligible: us.confirmationsCount + 1 >= 3,
      },
    });

    // 6. Создаём reputation_event для владельца навыка
    const event = await db.reputationEvent.create({
      data: {
        userId: us.userId,
        eventType: 'skill_confirmed',
        payload: JSON.stringify({
          skill: us.skill.name,
          by: user.name,
          byId: user.id,
          projectId,
          confirmationsCount: us.confirmationsCount + 1,
        }),
        weight: 3,
      },
    });

    // 7. Пересчитываем IP-score владельца навыка
    const updated = await ReputationService.recompute(us.userId);

    // 8. Досчитываем impactScore для события
    const impact = computeImpactScore('skill_confirmed', updated.ipScore, {
      confirmationsCount: us.confirmationsCount + 1,
    });
    await db.reputationEvent.update({ where: { id: event.id }, data: { impactScore: impact } });

    return json({
      confirmation: conf,
      newConfirmationsCount: us.confirmationsCount + 1,
      nftEligible: us.confirmationsCount + 1 >= 3,
      newIpScore: updated.ipScore,
    }, 201);
  } catch (e) {
    console.error('[skills/confirm] error:', e);
    return errorJson('Ошибка подтверждения', 500);
  }
}
