// BizON API — /api/skills/[id]/self-assessment
// GPT Truth Engine (A6): установить selfAssessment (1-100) для UserSkill
// Auth обязателен, только owner skill. truthGap = verifiedScore - selfAssessment
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS, getClientIP } from '@/lib/security/rate-limiter';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  const rl = checkUserRateLimit(user.id, 'skills:self-assessment', ...MUTATION_LIMITS.skillsConfirm);
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { selfAssessment } = body ?? {};

    if (typeof selfAssessment !== 'number' ||
        !Number.isFinite(selfAssessment) ||
        selfAssessment < 1 || selfAssessment > 100) {
      return errorJson('selfAssessment должен быть числом 1-100', 422);
    }

    const us = await db.userSkill.findUnique({ where: { id } });
    if (!us) return errorJson('Навык не найден', 404);
    if (us.userId !== user.id) {
      return errorJson('Только владелец может изменять самооценку', 403);
    }

    const updated = await db.userSkill.update({
      where: { id },
      data: { selfAssessment: Math.round(selfAssessment) },
      include: { skill: true },
    });

    // A6: truthGap = verifiedScore - selfAssessment (если оба определены)
    const truthGap =
      updated.verifiedScore !== null && updated.selfAssessment !== null
        ? updated.verifiedScore - updated.selfAssessment
        : null;

    AuditLog.log({
      actorId: user.id,
      action: 'update',
      resource: 'user_skill:self_assessment',
      resourceId: id,
      ip: getClientIP(req),
      metadata: {
        skill: updated.skill.name,
        selfAssessment: updated.selfAssessment,
        verifiedScore: updated.verifiedScore,
        truthGap,
      },
    });

    return json({
      userSkill: {
        id: updated.id,
        selfAssessment: updated.selfAssessment,
        verifiedScore: updated.verifiedScore,
        truthGap,
      },
    });
  } catch (e) {
    console.error('[skills/self-assessment] error:', e);
    return errorJson('Ошибка сохранения самооценки', 500);
  }
}
