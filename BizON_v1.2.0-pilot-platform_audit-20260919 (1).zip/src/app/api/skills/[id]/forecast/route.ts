import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { SkillFuturesService } from '@/lib/services/skill-futures-service';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  try {
    const { id } = await ctx.params;
    const forecast = await SkillFuturesService.forecast(id);
    if (!forecast) return errorJson('Навык не найден', 404);
    return json({ forecast });
  } catch (e: any) {
    return errorJson(e?.message ?? 'Ошибка', 500);
  }
}
