// BizON API — /api/skills/[id]/evidence
// GPT Truth Engine (A6): evidence для конкретного навыка (UserSkill)
// Параметр: id = userSkillId
// Возвращает: { skill, level, verificationLevel, selfAssessment, verifiedScore, truthGap,
//               confirmations: [...], projects: [...] }
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id } = await ctx.params;

  const us = await db.userSkill.findUnique({
    where: { id },
    include: {
      skill: true,
      confirmations: {
        orderBy: { createdAt: 'desc' },
        include: {
          confirmer: { select: { id: true, name: true, title: true, avatarUrl: true, ipScore: true } },
          project: { select: { id: true, title: true, status: true, rating: true } },
        },
      },
    },
  });

  if (!us) return errorJson('Навык не найден', 404);

  // A6: truthGap = verifiedScore - selfAssessment (если оба определены)
  const truthGap =
    us.verifiedScore !== null && us.selfAssessment !== null
      ? us.verifiedScore - us.selfAssessment
      : null;

  // projects: проекты, где навык подтверждён (из confirmations)
  const projectsMap = new Map<string, { id: string; title: string; status: string; rating: number }>();
  for (const c of us.confirmations) {
    if (c.project && !projectsMap.has(c.project.id)) {
      projectsMap.set(c.project.id, {
        id: c.project.id,
        title: c.project.title,
        status: c.project.status,
        rating: c.project.rating,
      });
    }
  }

  return json({
    id: us.id,
    skill: { id: us.skill.id, name: us.skill.name, category: us.skill.category },
    level: us.level,
    verificationLevel: us.verificationLevel,
    selfAssessment: us.selfAssessment,
    verifiedScore: us.verifiedScore,
    truthGap,
    confirmationsCount: us.confirmationsCount,
    nftEligible: us.nftEligible,
    confirmations: us.confirmations.map((c) => ({
      id: c.id,
      comment: c.comment,
      createdAt: c.createdAt.toISOString(),
      confirmer: c.confirmer,
      project: c.project,
    })),
    projects: Array.from(projectsMap.values()),
  });
}
