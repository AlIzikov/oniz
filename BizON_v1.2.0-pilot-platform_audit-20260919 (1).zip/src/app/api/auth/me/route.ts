// BizON API — /api/auth/me
// Использует AuthService
import { NextRequest } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { json, errorJson, toUserSelfView } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function GET(_req: NextRequest) {
  const user = await getUserFromRequest(_req);
  if (!user) return errorJson('Не авторизован', 401);
  const publicUser = await toUserSelfView(user);
  return json({ user: publicUser });
}
