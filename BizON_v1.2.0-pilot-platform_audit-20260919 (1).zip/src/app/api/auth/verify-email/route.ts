// BizON API — /api/auth/verify-email (FIX-08: подтверждение email)
//
// GET ?token=... — переход по ссылке из письма (клик в почтовом клиенте).
// Логика: sha256(токен) → lookup VerificationToken (purpose=email_verify,
// tokenHash @unique) → не просрочен → user.emailVerified=true, токен удалён
// (одноразовость) → 302 redirect на / (браузерный сценарий).
// Невалидный/просроченный токен → 400 (JSON, без деталей о существовании
// токена — чтобы не раскрывать per-user статус).
//
// Сырой токен хранится ТОЛЬКО в письме; в БД — исключительно sha256-хэш.

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { errorJson } from '@/lib/api-helpers';
import { findEmailVerificationToken } from '@/lib/services/verification-token';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get('token');
  if (!token) return errorJson('Токен не передан', 400);

  let found: { userId: string; recordId: string } | null = null;
  try {
    found = await findEmailVerificationToken(token);
  } catch (e) {
    console.error('[verify-email] lookup failed:', e);
    return errorJson('Неверный или просроченный токен', 400);
  }
  if (!found) return errorJson('Неверный или просроченный токен', 400);

  try {
    // Подтверждаем email и удаляем токен — атомарно (одноразовый переход:
    // повторный клик по ссылке → токена уже нет → 400)
    // Wave 1 §8.2-1: подтверждение контакта поднимает тир верификации
    // (consent = само действие подтверждения по ссылке).
    await db.$transaction([
      db.user.update({
        where: { id: found.userId },
        data: { emailVerified: true, verificationTier: 'contact_verified' },
      }),
      db.verificationToken.delete({ where: { id: found.recordId } }),
    ]);
  } catch (e) {
    console.error('[verify-email] confirm failed:', e);
    return errorJson('Неверный или просроченный токен', 400);
  }

  AuditLog.log({
    actorId: found.userId,
    action: 'email_verified',
    resource: 'user',
    resourceId: found.userId,
  });

  // Успех → браузерный redirect на главную (клик по ссылке из письма)
  return NextResponse.redirect(new URL('/', req.url), 302);
}
