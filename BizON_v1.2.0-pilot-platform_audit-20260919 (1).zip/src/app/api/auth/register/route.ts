// BizON API — /api/auth/register
// Поддерживает 3 типа аккаунта + rate limiting + password policy
// FIX-08: ToS-согласие обязательно (acceptedTos:true, иначе 400) + письмо
// с одноразовой ссылкой подтверждения email (токен в БД — только sha256-хэш).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { AuthService } from '@/lib/services';
import { setSessionCookie } from '@/lib/auth';
import { json, errorJson, toUserSelfView } from '@/lib/api-helpers';
import { ReputationService } from '@/lib/services';
import { checkRateLimit, getClientIP } from '@/lib/security/rate-limiter';
import { validatePasswordPolicy } from '@/lib/security/password-policy';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { createHash } from 'node:crypto';
import { sendEmail } from '@/lib/services/email-service';
import { createEmailVerificationToken, appUrl } from '@/lib/services/verification-token';
import type { AccountType } from '@/lib/types';

export const runtime = 'nodejs';

const REGISTER_RATE_LIMIT = 5; // 5 регистраций в час с одного IP
const REGISTER_RATE_WINDOW = 60 * 60 * 1000;

export async function POST(req: NextRequest) {
  // Rate limiting — защита от спам-регистраций
  const rateLimit = checkRateLimit(req, 'register', REGISTER_RATE_LIMIT, REGISTER_RATE_WINDOW);
  if (!rateLimit.allowed) {
    return errorJson('Слишком много регистраций. Повторите позже.', 429);
  }

  try {
    const body = await req.json();
    const { email, password, name, title, accountType, legalForm, website, specialization, acceptedTos } = body ?? {};

    // Wave 1 §8.2-2: HONEYPOT — скрытое поле, которое человек не заполнит.
    // Бот заполняет → тихий «успех» без создания аккаунта (не обучаем бота).
    if (typeof body?.websiteConfirmation === 'string' && body.websiteConfirmation.trim().length > 0) {
      return json({ ok: true, user: null });
    }

    if (!email || !password || !name) {
      return errorJson('Email, пароль и имя обязательны', 422);
    }

    // FIX-08: юридический контур люмен-программы — без согласия с условиями
    // (/legal) аккаунт не создаётся.
    if (acceptedTos !== true) {
      return errorJson('Необходимо принять условия', 400);
    }

    // H2: парольная политика через общий валидатор (blocklist + сложность + длина)
    const passwordCheck = validatePasswordPolicy(password);
    if (!passwordCheck.ok) {
      return errorJson(passwordCheck.reason, 422);
    }

    if (!email.includes('@')) {
      return errorJson('Некорректный email', 422);
    }

    const validTypes: AccountType[] = ['individual', 'company', 'hr_agency'];
    const acctType = validTypes.includes(accountType) ? accountType : 'individual';

    // Для company/hr_agency — создаём Company запись автоматически
    let companyId: string | null = null;
    if (acctType === 'company' || acctType === 'hr_agency') {
      const company = await db.company.create({
        data: {
          name,
          description: specialization ? `HR-агентство. Специализация: ${specialization}` : `Компания ${name}`,
          industry: acctType === 'hr_agency' ? 'HR Agency' : (legalForm || 'Company'),
          website: website || null,
          adTrustIndex: 0.5,
        },
      });
      companyId = company.id;
    }

    const user = await AuthService.register({
      email,
      password,
      name: acctType === 'individual' ? name : name,
      title: title || (acctType === 'company' ? legalForm : acctType === 'hr_agency' ? 'HR Agency' : null),
      accountType: acctType,
      companyId: companyId ?? undefined,
      acceptedTos: true,
    });

    // P2-4: Реферальная программа — если есть ?ref=CODE, создаём referral запись

    // Wave 1 §8.2-2: coarse device fingerprint — ТОЛЬКО хэш, без PII:
    // sha256(UA | язык | /24-подсеть IP). Пишется в AuditLog → кластеры
    // DEVICE_SHARED / будущий GNN (§8.1) видят железо-кластеры ферм.
    try {
      const ua = req.headers.get('user-agent') ?? '';
      const lang = req.headers.get('accept-language') ?? '';
      const ip = getClientIP(req);
      const ipPrefix = ip.split('.').slice(0, 3).join('.');
      const deviceHash = createHash('sha256').update(`${ua}|${lang}|${ipPrefix}`).digest('hex').slice(0, 32);
      AuditLog.logSecurity('REGISTER_DEVICE', {
        actorId: user.id,
        resource: 'User',
        resourceId: user.id,
        metadata: { deviceHash },
      });
    } catch { /* fail-open: телеметрия не ломает регистрацию */ }

    const refCode = req.nextUrl.searchParams.get('ref');
    if (refCode && refCode.length >= 8) {
      try {
        // Находим реферера по коду (первые 8 символов userId)
        const referrer = await db.user.findFirst({
          where: { id: { startsWith: refCode } },
          select: { id: true },
        });
        if (referrer && referrer.id !== user.id) {
          await db.referral.create({
            data: {
              referrerId: referrer.id,
              referredId: user.id,
              code: refCode,
            },
          }).catch(() => {}); // unique constraint — один юзер один реферал
        }
      } catch {}
    }

    const token = await AuthService.createSession(user.id);
    await setSessionCookie(token);
    await ReputationService.recompute(user.id);

    // FIX-08: письмо с одноразовой ссылкой подтверждения email.
    // Токен живёт только в письме (в БД — sha256-хэш); сырой токен НИКОГДА
    // не попадает в API-ответ. Отправка не должна ломать регистрацию (fail-open).
    let emailVerificationSent = false;
    try {
      const { token: verifyToken } = await createEmailVerificationToken(user.id);
      const verifyUrl = `${appUrl()}/api/auth/verify-email?token=${verifyToken}`;
      const emailPlain = user.email ?? email;
      const sendRes = await sendEmail({
        to: emailPlain,
        subject: 'BizON: подтвердите email',
        html:
          `<p>Здравствуйте, ${name}!</p>` +
          `<p>Подтвердите email, чтобы пополнять баланс люменов и пользоваться платформой:</p>` +
          `<p><a href="${verifyUrl}">Подтвердить email</a></p>` +
          `<p style="color:#64748b">Ссылка действует 24 часа. Если вы не регистрировались в BizON — просто проигнорируйте это письмо.</p>`,
        text: `Подтвердите email в BizON: ${verifyUrl} (ссылка действует 24 часа)`,
      });
      emailVerificationSent = sendRes.ok;
    } catch (mailError) {
      console.error('[register] verification email failed (non-critical):', mailError);
    }

    // H13: Audit log — регистрация нового пользователя
    AuditLog.log({
      actorId: user.id,
      action: 'register',
      resource: 'user',
      resourceId: user.id,
      ip: getClientIP(req),
      metadata: { accountType: acctType },
    });

    const publicUser = await toUserSelfView(user);
    // C5: token НЕ возвращаем в JSON — только HttpOnly cookie.
    // FIX-08: emailVerificationSent — флаг, что письмо отправлено (токен не отдаём).
    return json({ user: publicUser, emailVerificationSent });
  } catch (e: any) {
    if (e?.message?.includes('уже существует')) return errorJson(e.message, 409);
    console.error('[register] error:', e);
    return errorJson('Внутренняя ошибка сервера', 500);
  }
}
