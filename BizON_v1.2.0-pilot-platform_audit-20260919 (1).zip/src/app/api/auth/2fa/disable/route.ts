// BizON API — POST /api/auth/2fa/disable
// Этап 8.5 — отключение 2FA.
// FIX-03 (P2): требует ТЕКУЩИЙ ПАРОЛЬ (re-authentication) + rate-limit.
// Раньше допускалась альтернатива «TOTP/backup-код вместо пароля» — убрана:
// атакующий с украденной сессией и TOTP-устройством не должен иметь возможности
// отключить 2FA, не зная пароля. Body: { password }.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { checkRateLimit } from '@/lib/security/rate-limiter';
import { AuthService } from '@/lib/services';
import { decrypt } from '@/lib/security/crypto';

export const runtime = 'nodejs';

const DISABLE_RATE_LIMIT = 5; // 5 попыток / IP / мин — парольная операция
const DISABLE_RATE_WINDOW = 60_000;

export async function POST(req: NextRequest) {
  // FIX-03 (P2): rate limit — защита от перебора пароля на этом эндпоинте
  const rl = checkRateLimit(req, '2fa-disable', DISABLE_RATE_LIMIT, DISABLE_RATE_WINDOW);
  if (!rl.allowed) {
    return errorJson(`Слишком много попыток. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  if (!user.twoFactorEnabled) {
    return errorJson('2FA не включена', 400);
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }
  const password = String(body?.password || '');

  if (!password) {
    return errorJson('Пароль обязателен для отключения 2FA', 422);
  }

  // FIX-03 (P2): строгое re-auth — только текущий пароль.
  const email = user.emailEncrypted ? decrypt(user.emailEncrypted) : (user.email || '');
  try {
    await AuthService.login(email, password);
  } catch {
    return errorJson('Неверный пароль. Для отключения 2FA введите корректный пароль.', 401);
  }

  // Отключаем 2FA и очищаем секрет + backup-коды
  await db.user.update({
    where: { id: user.id },
    data: {
      twoFactorEnabled: false,
      twoFactorSecret: null,
      backupCodes: null,
    },
  });

  return json({ ok: true, message: '2FA отключена' });
}
