// BizON API — POST /api/auth/2fa/confirm
// Этап 8.5 — 2FA TOTP setup: шаг 2 из 2.
// Принимает { token } — первый TOTP-код от пользователя (после сканирования QR).
// Проверяет код против секрета, сохранённого в БД при /enable.
// Если код верный → twoFactorEnabled = true.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/services/totp-service';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // W1.8: rate limit — защита от брутфорса 6-значного TOTP
  // (1 000 000 комбинаций; без лимита перебор реалистичен при 30-сек окне)
  const rl = checkUserRateLimit(user.id, 'auth:2fa:confirm', 5, 60_000);
  if (!rl.allowed) {
    return errorJson(`Слишком много попыток. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  // Если 2FA уже включена — подтвержать нечего
  if (user.twoFactorEnabled) {
    return errorJson('2FA уже включена', 409);
  }

  // Должен быть секрет, сохранённый при /enable
  if (!user.twoFactorSecret) {
    return errorJson('Сначала запросите новый секрет через /2fa/enable', 400);
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }
  const token = String(body?.token || '').trim();

  if (!/^\d{6}$/.test(token)) {
    return errorJson('Код должен состоять из 6 цифр', 422);
  }

  const ok = verifyToken(token, user.twoFactorSecret);
  if (!ok) {
    return errorJson('Неверный код. Проверьте время на устройстве и попробуйте снова.', 401);
  }

  // Код верный → включаем 2FA
  await db.user.update({
    where: { id: user.id },
    data: { twoFactorEnabled: true },
  });

  return json({ ok: true, message: '2FA включена' });
}
