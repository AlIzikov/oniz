// BizON API — POST /api/auth/2fa/enable
// Этап 8.5 — 2FA TOTP setup: шаг 1 из 2.
// FIX-03 (P2): требует ТЕКУЩИЙ ПАРОЛЬ в теле ({ password }) — включение 2FA
// это security-critical операция; украденная сессия не должна иметь возможность
// включить 2FA незаметно (attacker-in-the-middle) без знания пароля.
// Плюс rate-limit на подбор пароля.
// Генерирует новый TOTP-секрет + QR-код URL + 10 backup-кодов.
// НЕ сохраняет решение «включено» в БД — пользователь должен подтвердить первым кодом
// (POST /api/auth/2fa/confirm), и только тогда twoFactorEnabled = true.
// Это защищает от ситуации: пользователь "включил" 2FA, но не добавил секрет
// в Google Authenticator → потерял бы доступ к аккаунту.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { decrypt } from '@/lib/security/crypto';
import { generateSecretForUser, generateBackupCodes } from '@/lib/services/totp-service';
import { AuthService } from '@/lib/services';
import { checkRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const ENABLE_RATE_LIMIT = 5; // 5 попыток / IP / мин — парольная операция
const ENABLE_RATE_WINDOW = 60_000;

export async function POST(req: NextRequest) {
  // Rate limit — защита от перебора пароля на этом эндпоинте
  const rl = checkRateLimit(req, '2fa-enable', ENABLE_RATE_LIMIT, ENABLE_RATE_WINDOW);
  if (!rl.allowed) {
    return errorJson(`Слишком много попыток. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  let body: any;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }
  const password = String(body?.password || '');
  if (!password) {
    return errorJson('Текущий пароль обязателен для включения 2FA', 422);
  }

  // FIX-03 (P2): проверяем текущий пароль (re-authentication).
  const email = user.emailEncrypted ? decrypt(user.emailEncrypted) : (user.email || '');
  try {
    await AuthService.login(email, password);
  } catch {
    return errorJson('Неверный пароль', 401);
  }

  // Если 2FA уже включена — не даём сгенерировать новый секрет (иначе пользователь
  // потеряет старый, не зная нового). Сначала пусть отключит.
  if (user.twoFactorEnabled) {
    return errorJson('2FA уже включена. Сначала отключите её, чтобы перенастроить.', 409);
  }

  // Расшифровываем email (для подстановки в otpauth URL — он показывается в
  // приложении как имя аккаунта)
  if (!email) {
    return errorJson('Не удалось определить email аккаунта', 500);
  }

  // Генерируем секрет + QR URL + backup-коды
  const { secret, qrUrl, encryptedSecret } = generateSecretForUser(email);
  const { plain: backupCodesPlain, hashed: backupCodesHashed } = generateBackupCodes(user.emailHash || user.id);

  // Сохраняем в БД зашифрованный секрет + хэши backup-кодов, НО
  // twoFactorEnabled остаётся false до подтверждения первым кодом.
  // Это позволяет нам на /confirm проверить код против этого секрета.
  await db.user.update({
    where: { id: user.id },
    data: {
      twoFactorSecret: encryptedSecret,
      backupCodes: backupCodesHashed,
    },
  });

  return json({
    qrUrl,
    secret, // plaintext — для ручного ввода, если QR не сканируется
    backupCodes: backupCodesPlain, // plaintext — показать один раз, попросить сохранить
    // ВАЖНО: секрет и backup-коды показываются пользователю, но 2FA ещё НЕ включена.
    // Frontend должен сразу показать QR + поле ввода кода для подтверждения.
  });
}
