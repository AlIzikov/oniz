// BizON API — POST /api/auth/2fa/verify
// Этап 8.5 — финальный шаг 2FA-логина (FIX-03/P0-4).
// Принимает { tempToken, code } (или { tempToken, token }, или { tempToken, backupCode }).
// tempToken — получен из POST /api/auth/login после успешной проверки email+password
// (выдаётся ТОЛЬКО если у пользователя включена 2FA).
// code — 6-значный TOTP-код из приложения; если поле выглядит как 8-значный
// backup-код (XXXX-XXXX) — проверяется как одноразовый backup-код.
// Если код верный → создаём настоящую сессию и возвращаем user.
import { NextRequest } from 'next/server';
import { json, errorJson, toUserSelfView } from '@/lib/api-helpers';
import { setSessionCookie } from '@/lib/auth';
import { AuthService } from '@/lib/services';
import { db } from '@/lib/db';
import {
  consume2FATempToken,
  verifyToken,
  verifyBackupCode,
} from '@/lib/services/totp-service';
import { AuditLog } from '@/lib/data-vault/audit-log';
import { checkRateLimit, getClientIP } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const VERIFY_RATE_LIMIT = 10; // 10 попыток / IP / мин
const VERIFY_RATE_WINDOW = 60_000;

export async function POST(req: NextRequest) {
  // Rate limit — защита от brute-force 6-значного кода
  const rl = checkRateLimit(req, '2fa-verify', VERIFY_RATE_LIMIT, VERIFY_RATE_WINDOW);
  if (!rl.allowed) {
    return errorJson(`Слишком много попыток. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }
  const tempToken = String(body?.tempToken || '');
  // FIX-03: каноническое поле — `code`; `token` оставлен для обратной совместимости
  const token = body?.token ? String(body.token).trim() : body?.code ? String(body.code).trim() : '';
  const backupCode = body?.backupCode ? String(body.backupCode).trim() : '';

  if (!tempToken) {
    return errorJson('tempToken обязателен', 422);
  }
  if (!token && !backupCode) {
    return errorJson('Введите TOTP-код или backup-код', 422);
  }

  // Извлекаем userId из tempToken (одноразовый — удаляется)
  const userId = consume2FATempToken(tempToken);
  if (!userId) {
    return errorJson('Сессия истекла или неверна. Войдите заново.', 401);
  }

  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) {
    return errorJson('Пользователь не найден', 404);
  }
  // На случай если 2FA была отключена после выдачи tempToken
  if (!user.twoFactorEnabled) {
    return errorJson('2FA больше не требуется. Войдите заново.', 409);
  }

  // Проверяем код: сначала TOTP, потом backup
  // FIX-03: если пользователь ввёл 8-значный backup-код в единое поле `code`
  // (без отдельного backupCode) — распознаём по формату XXXX-XXXX / 8 цифр.
  let codeOk = false;
  let method = '';
  if (token && user.twoFactorSecret) {
    if (verifyToken(token, user.twoFactorSecret)) {
      codeOk = true;
      method = 'totp';
    }
  }
  if (!codeOk && token && /^\d{4}-?\d{4}$/.test(token.replace(/\s/g, ''))) {
    if (await verifyBackupCode(token, user)) {
      codeOk = true;
      method = 'backup';
    }
  }
  if (!codeOk && backupCode) {
    if (await verifyBackupCode(backupCode, user)) {
      codeOk = true;
      method = 'backup';
    }
  }

  if (!codeOk) {
    return errorJson('Неверный код', 401);
  }

  // Код верный → создаём настоящую сессию
  const sessionToken = await AuthService.createSession(user.id);
  await setSessionCookie(sessionToken);

  // Audit log
  AuditLog.log({
    actorId: user.id,
    action: 'login',
    resource: 'user:session',
    resourceId: user.id,
    ip: getClientIP(req),
    metadata: { method: `2fa-${method}` },
  });

  const publicUser = await toUserSelfView(user);
  return json({ user: publicUser });
}
