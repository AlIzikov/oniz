// BizON API — /api/auth/logout
// Использует AuthService
import { NextRequest } from 'next/server';
import { getUserFromRequest } from '@/lib/auth';
import { AuthService } from '@/lib/services';
import { clearSessionCookie } from '@/lib/auth';
import { json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(_req: NextRequest) {
  try {
    const user = await getUserFromRequest(_req);
    if (user) {
      await AuthService.logout(user.id);
    }
    await clearSessionCookie();
    return json({ ok: true });
  } catch (e) {
    console.error('[logout] error:', e);
    return errorJson('Ошибка выхода', 500);
  }
}
