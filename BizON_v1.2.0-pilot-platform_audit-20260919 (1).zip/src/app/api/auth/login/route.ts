// BizON API — /api/auth/login
// Использует AuthService + Rate Limiter (IP flood) + экспоненциальный backoff.
//
// FIX-03 (P0-4): если у пользователя включена 2FA — после проверки пароля
// сессия НЕ выдаётся. Вместо неё возвращается одноразовый short-lived
// tempToken (TTL 5 мин) → клиент обязан отправить TOTP/backup-код на
// POST /api/auth/2fa/verify, и только там создаётся настоящая сессия.
//
// FIX-03 (P1-7): вместо жёсткой блокировки аккаунта по email (5 неудач → 15 мин
// блок — атакующий мог «залочить» жертву, зная её email) — экспоненциальный
// backoff на паре IP+email: 1с → 2с → 4с → … кап 15 минут. Задержка исчезает
// сама, жертва с другого IP не страдает, brute-force всё равно невозможен.
import { NextRequest } from 'next/server';
import { AuthService } from '@/lib/services';
import { setSessionCookie } from '@/lib/auth';
import { json, errorJson, toUserSelfView } from '@/lib/api-helpers';
import {
  checkRateLimit,
  getClientIp,
  LoginBackoff,
  loginBackoffKey,
} from '@/lib/security/rate-limiter';
import { create2FATempToken } from '@/lib/services/totp-service';
import { AuditLog } from '@/lib/data-vault/audit-log';

export const runtime = 'nodejs';

// ТЗ 3.7: Auth → 5 запросов / IP / мин
const LOGIN_RATE_LIMIT = 10; // 10 попыток в минуту (баланс безопасности и UX)
const LOGIN_RATE_WINDOW = 60_000; // 1 минута

export async function POST(req: NextRequest) {
  // Rate limiting — защита от IP-flood (грубый лимит поверх backoff)
  const rateLimit = checkRateLimit(req, 'login', LOGIN_RATE_LIMIT, LOGIN_RATE_WINDOW);
  if (!rateLimit.allowed) {
    return errorJson(`Слишком много попыток входа. Повторите через ${rateLimit.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json().catch(() => null);
    const { email, password } = body ?? {};
    if (!email || !password) return errorJson('Email и пароль обязательны', 422);

    // FIX-03 (P1-7): экспоненциальный backoff на паре IP+email.
    const ip = getClientIp(req);
    const backoffKey = loginBackoffKey(ip, String(email));
    const backoff = LoginBackoff.check(backoffKey);
    if (!backoff.allowed) {
      return errorJson(
        `Слишком много неудачных попыток входа. Повторите через ${backoff.retryAfterSec} секунд.`,
        429
      );
    }

    try {
      const user = await AuthService.login(email, password);
      // Успешный вход — сбрасываем серию неудач
      LoginBackoff.reset(backoffKey);

      // FIX-03 (P0-4): при включённой 2FA НЕ выдаём сессию по одному паролю.
      // Выдаём одноразовый tempToken (TTL 5 мин) — полный session cookie
      // создаётся только в /api/auth/2fa/verify после проверки TOTP/backup-кода.
      if (user.twoFactorEnabled) {
        const tempToken = create2FATempToken(user.id);
        AuditLog.log({
          actorId: user.id,
          action: 'login',
          resource: 'user:session',
          resourceId: user.id,
          ip,
          metadata: { method: 'password', twoFactor: 'challenge-issued' },
        });
        return json({ twoFactorRequired: true, tempToken });
      }

      const token = await AuthService.createSession(user.id);
      await setSessionCookie(token);

      // H13: Audit log — фиксируем факт доступа к PII (152-ФЗ ст. 19)
      AuditLog.log({
        actorId: user.id,
        action: 'login',
        resource: 'user:session',
        resourceId: user.id,
        ip,
        metadata: { method: 'password' },
      });

      const publicUser = await toUserSelfView(user);
      return json({ user: publicUser });
    } catch (loginError: any) {
      if (loginError?.message?.includes('Неверный')) {
        // FIX-03: неудача → наращиваем backoff (1с, 2с, 4с … кап 15 мин)
        const st = LoginBackoff.recordFailure(backoffKey);
        return errorJson(
          `Неверный email или пароль. Следующая попытка через ${st.retryAfterSec} с.`,
          401
        );
      }
      throw loginError;
    }
  } catch (e: any) {
    console.error('[login] error:', e);
    return errorJson('Внутренняя ошибка сервера', 500);
  }
}
