// BizON API — /api/cv/generate (Этап 5.3 — CV блок: AI-резюме)
// Генерирует 3 типа резюме через z-ai-web-dev-sdk:
//   • short       — короткое резюме в один экран
//   • long        — полное резюме
//   • cover_letter — сопроводительное письмо под вакансию (50-280 символов)
//
// Этика:
//   • Только VERIFIED факты (CLAIMED не включаются в резюме)
//   • Graceful fallback на структуру из доступных данных при ошибке LLM
//   • Rate limit: Free 5/час, Pro 50/час, Business 500/час (как AI-Career-Agent)
// FIX-07: withRoute — auth 401, zod-схема cvGenerate (type enum, jobId whitelist),
// единый маппинг ошибок; сырой e.message для 5xx больше не возвращается.
import { db } from '@/lib/db';
import { json, errorJson, withRoute } from '@/lib/api-helpers';
import { schemas } from '@/lib/validation';
import { generateResume, type ResumeType } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';
import { LumenService } from '@/lib/services/lumen-service';

export const runtime = 'nodejs';

export const POST = withRoute(
  async (req, ctx) => {
    const user = ctx.user!;

    // Rate limit по тарифу (как AI-Career-Agent)
    const [max, windowMs] = getAiLimitKey('career', user.subscriptionTier);
    const rl = checkUserRateLimit(user.id, 'ai:cv:generate', max, windowMs);
    if (!rl.allowed) {
      const isFree = user.subscriptionTier === 'free';
      return errorJson(
        isFree
          ? `Лимит генерации резюме исчерпан (${max} в час для Free). Повторите через ${rl.retryAfter} секунд.`
          : `Превышен fair-use лимит (${max} в час для тарифа ${user.subscriptionTier}). Повторите через ${rl.retryAfter} секунд.`,
        429
      );
    }

    const { type, jobId } = ctx.data as { type: ResumeType; jobId?: string };

    let spent = false;
    let spendTransactionId: string | undefined;
    try {
      // Загружаем профиль пользователя (полный, с hobbies и т.д.)
      const profile = await db.user.findUnique({ where: { id: user.id } });
      if (!profile) return errorJson('Профиль не найден', 404);

    // 1. Подтверждённые навыки (verificationLevel != 'claimed')
    const userSkills = await db.userSkill.findMany({
      where: { userId: user.id, verificationLevel: { not: 'claimed' } },
      include: { skill: true },
      orderBy: { confirmationsCount: 'desc' },
      take: 30,
    });
    const verifiedSkills = userSkills.map((us) => ({
      name: us.skill.name,
      level: us.level,
      verificationLevel: us.verificationLevel,
    }));

    // 2. Завершённые проекты (status = 'COMPLETED')
    const memberships = await db.projectMember.findMany({
      where: { userId: user.id },
      include: { project: true },
      orderBy: { joinedAt: 'desc' },
      take: 30,
    });
    const completedProjects = memberships
      .filter((m) => m.project.status === 'COMPLETED')
      .map((m) => ({
        title: m.project.title,
        description: m.project.description,
        role: m.role,
        startedAt: m.project.startedAt.toISOString(),
        completedAt: m.project.completedAt?.toISOString() ?? null,
        rating: m.project.rating,
      }));

    // 3. Career entries (только verified, не claimed)
    const careerEntries = await db.careerEntry.findMany({
      where: { userId: user.id, verificationLevel: { not: 'claimed' } },
      orderBy: { startDate: 'desc' },
      take: 20,
    });
    const careerCtx = careerEntries.map((e) => ({
      company: e.company,
      position: e.position,
      startDate: e.startDate?.toISOString() ?? null,
      endDate: e.endDate?.toISOString() ?? null,
      description: e.description,
      verificationLevel: e.verificationLevel,
    }));

    // 4. Если есть jobId — загружаем вакансию для персонализации cover_letter
    let job: {
      title: string;
      company: string;
      description: string;
      requiredSkills: string[];
    } | null = null;
    if (jobId) {
      const jobRow = await db.job.findUnique({ where: { id: jobId } });
      if (jobRow) {
        job = {
          title: jobRow.title,
          company: jobRow.company,
          description: jobRow.description,
          requiredSkills: jobRow.requiredSkills
            ? jobRow.requiredSkills.split(',').filter(Boolean)
            : [],
        };
      } else {
        return errorJson('Вакансия не найдена', 404);
      }
    }
    // cover_letter требует jobId — иначе возвращаем 422
    if (type === 'cover_letter' && !job) {
      return errorJson('Для cover_letter укажите jobId', 422);
    }

    // === Волна 14: ИИ-действия за люмены ===
    // Free: 2 люмена за генерацию (тяжёлый LLM-вызов); Pro/Business — безлимит.
    // Списание ПОСЛЕ всех валидаций и загрузки данных — за неверный запрос не платите.
    if (user.subscriptionTier === 'free') {
      const spend = await LumenService.spend(user.id, 'cv_generate');
      if (!spend.ok) {
        if (spend.code === 'insufficient') {
          return json(
            {
              error: `Недостаточно люменов: нужно ${spend.need}, есть ${spend.have}. Пополните кошелёк — 1 ₽ = 1 люмен.`,
              need: spend.need,
              have: spend.have,
            },
            402
          );
        }
        return errorJson('Неизвестное ИИ-действие', 422);
      }
      spent = true;
      spendTransactionId = spend.ok ? spend.transactionId : undefined;
    }

    // 5. Запускаем LLM (с fallback)
    const { content, engine } = await generateResume(type, {
      user: {
        name: profile.name,
        title: profile.title,
        bio: profile.bio,
        location: profile.location,
        ipScore: profile.ipScore,
        level: profile.level,
      },
      verifiedSkills,
      completedProjects,
      careerEntries: careerCtx,
      job,
    });

    // 6. Сохраняем в Resume
    const resume = await db.resume.create({
      data: {
        userId: user.id,
        type,
        jobId: jobId ?? null,
        content: JSON.stringify(content),
        aiGenerated: engine === 'llm',
      },
    });

    // Честность: если LLM недоступен и резюме собрано из фактов (fallback) —
    // люмены возвращаются: платите только за реальный ИИ
    let lumenRefunded = false;
    if (engine !== 'llm' && spent) {
      await LumenService.refund(user.id, 'cv_generate', 'fallback-движок — люмены возвращены', spendTransactionId);
      lumenRefunded = true;
      spent = false;
    }

    return json({
      resumeId: resume.id,
      type,
      content,
      engine,
      aiGenerated: resume.aiGenerated,
      lumenRefunded,
    });
    } catch (e: unknown) {
      // Честность: списание прошло, но генерация упала — возвращаем люмены
      if (spent) {
        await LumenService.refund(user.id, 'cv_generate', 'Ошибка генерации — люмены возвращены', spendTransactionId);
      }
      // FIX-07: пробрасываем дальше — withRoute вернёт общий 500 без сырого e.message
      throw e;
    }
  },
  { schema: schemas.cvGenerate },
);
