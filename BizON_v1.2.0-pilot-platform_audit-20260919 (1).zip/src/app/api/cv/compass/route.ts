// BizON API — /api/cv/compass (Этап 5.3 — Карьерный компас / cross-domain навигатор)
// Анализирует transferable skills и предлагает 3-5 смежных областей.
//
// Этика:
//   • Cross-domain подсказки — только если user.crossDomainOptIn=true
//   • Запрет «вы недостойны» — только «можете рассмотреть»
//   • matchPercent 0-95 (не 100 — реалистичная оценка)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { runCareerCompass } from '@/lib/ai';
import { checkUserRateLimit, getAiLimitKey } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Rate limit
  const [max, windowMs] = getAiLimitKey('career', user.subscriptionTier);
  const rl = checkUserRateLimit(user.id, 'ai:cv:compass', max, windowMs);
  if (!rl.allowed) {
    return errorJson(
      `Лимит карьерного компаса исчерпан (${max} в час). Повторите через ${rl.retryAfter} секунд.`,
      429
    );
  }

  try {
    const body = await req.json().catch(() => ({}));
    const currentRoleOverride =
      typeof body?.currentRole === 'string' && body.currentRole.trim()
        ? body.currentRole.trim().slice(0, 100)
        : undefined;
    const currentDomainOverride =
      typeof body?.currentDomain === 'string' && body.currentDomain.trim()
        ? body.currentDomain.trim().slice(0, 100)
        : undefined;

    // Загружаем полный профиль (с hobbies, crossDomainOptIn)
    const profile = await db.user.findUnique({ where: { id: user.id } });
    if (!profile) return errorJson('Профиль не найден', 404);

    // 1. Подтверждённые навыки (verificationLevel != 'claimed')
    const userSkills = await db.userSkill.findMany({
      where: { userId: user.id, verificationLevel: { not: 'claimed' } },
      include: { skill: true },
      orderBy: { confirmationsCount: 'desc' },
      take: 30,
    });
    const confirmedSkills = userSkills.map((us) => ({
      name: us.skill.name,
      level: us.level,
    }));

    // 2. Хобби — парсим CSV
    const hobbies = profile.hobbies
      ? profile.hobbies.split(',').map((h) => h.trim()).filter(Boolean)
      : [];

    // 3. Достижения — Claim со статусом verified/project_verified/expert_verified
    const claims = await db.claim.findMany({
      where: {
        userId: user.id,
        status: { not: 'claimed' },
        type: 'achievement',
      },
      orderBy: { updatedAt: 'desc' },
      take: 20,
    });
    const achievements = claims.map((c) => ({
      title: c.title,
      description: c.description,
      status: c.status,
    }));

    // 4. Запускаем компас (с fallback)
    const result = await runCareerCompass({
      user: {
        name: profile.name,
        title: profile.title,
        ipScore: profile.ipScore,
        level: profile.level,
        crossDomainOptIn: profile.crossDomainOptIn,
      },
      confirmedSkills,
      hobbies,
      achievements,
      currentRole: currentRoleOverride,
      currentDomain: currentDomainOverride,
    });

    // 5. Сохраняем в CareerCompass
    const compass = await db.careerCompass.create({
      data: {
        userId: user.id,
        currentRole: result.currentRole,
        currentDomain: result.currentDomain,
        transferableSkills: JSON.stringify(result.transferableSkills),
        suggestedDomains: JSON.stringify(result.suggestedDomains),
      },
    });

    return json({
      compassId: compass.id,
      currentRole: result.currentRole,
      currentDomain: result.currentDomain,
      transferableSkills: result.transferableSkills,
      suggestedDomains: result.suggestedDomains,
      engine: result.engine,
      crossDomainOptIn: profile.crossDomainOptIn,
      generatedAt: compass.generatedAt.toISOString(),
    });
  } catch (e: any) {
    console.error('[cv/compass] error:', e);
    return errorJson('Ошибка карьерного компаса. Попробуйте позже.', 500);
  }
}

// GET — последний сгенерированный компас пользователя (для UI при перезагрузке)
export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const latest = await db.careerCompass.findFirst({
    where: { userId: user.id },
    orderBy: { generatedAt: 'desc' },
  });
  if (!latest) return json({ compass: null });

  return json({
    compass: {
      id: latest.id,
      currentRole: latest.currentRole,
      currentDomain: latest.currentDomain,
      transferableSkills: safeParseArray(latest.transferableSkills),
      suggestedDomains: safeParseArray(latest.suggestedDomains),
      generatedAt: latest.generatedAt.toISOString(),
    },
  });
}

function safeParseArray(s: string): any[] {
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}
