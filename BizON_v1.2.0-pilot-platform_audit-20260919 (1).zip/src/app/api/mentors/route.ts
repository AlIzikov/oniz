// BizON API — GET /api/mentors
// Phase 11: Mentor Graph — найти наставников для текущего пользователя.
//
// Query:
//   ?skillId=...  — фильтр по конкретному навыку (опционально)
//   ?limit=20     — макс. число результатов (1..50)
//
// Возвращает массив MentorSuggestion (см. mentor-service.ts).
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MentorService } from '@/lib/services/mentor-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const skillId = req.nextUrl.searchParams.get('skillId');
  const limitParam = req.nextUrl.searchParams.get('limit');
  let limit = 20;
  if (limitParam) {
    const parsed = parseInt(limitParam, 10);
    if (!Number.isNaN(parsed)) limit = Math.max(1, Math.min(50, parsed));
  }

  try {
    const mentors = await MentorService.findMentors(
      user.id,
      skillId ?? null,
      limit,
    );
    return json({ mentors });
  } catch (e) {
    console.error('[api/mentors] error:', e);
    return errorJson('Ошибка поиска менторов', 500);
  }
}
