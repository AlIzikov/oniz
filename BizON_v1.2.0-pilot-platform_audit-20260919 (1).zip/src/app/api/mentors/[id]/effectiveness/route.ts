// BizON API — GET /api/mentors/[id]/effectiveness
// Phase 11: Mentor Graph — эффективность наставника.
//
// Возвращает { score, menteeCount, growthRate, newRoleRate, avgRating, totalMenteeCount }.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { MentorService } from '@/lib/services/mentor-service';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);
  const { id: mentorId } = await ctx.params;

  try {
    const effectiveness = await MentorService.calculateMentorEffectiveness(mentorId);
    return json(effectiveness);
  } catch (e) {
    console.error('[api/mentors/[id]/effectiveness] error:', e);
    return errorJson('Ошибка расчёта эффективности', 500);
  }
}
