// BizON API — /api/hypotheses/run (Wave 3, S-054): ручной запуск генерации.
// Дневной лимит ≤3 внутри сервиса (MAX_HYPOTHESES_PER_DAY); governance:
// HYPOTHESIS_GENERATE в реестре AI_OPERATIONS, аудит HYPOTHESES_GENERATED.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { generateHypotheses } from '@/lib/services/hypothesis-service';

export const runtime = 'nodejs';

export const POST = withRoute(async (req, ctx) => {
  const result = await generateHypotheses(ctx.user.id);
  return NextResponse.json(result, { status: 201 });
}, { rateLimit: { key: 'hypotheses-run', limit: 10, windowMs: 60 * 60 * 1000 } });
