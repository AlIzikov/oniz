// BizON API — /api/hypotheses (Wave 3, S-054): карточки гипотез пользователя.
// GET — список последних гипотез; PATCH — accept/dismiss (обратная связь для ML).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/api-helpers';
import { listHypotheses, decideHypothesis } from '@/lib/services/hypothesis-service';

export const runtime = 'nodejs';

const decideSchema = z.object({
  id: z.string().min(1).max(64),
  decision: z.enum(['accepted', 'dismissed']),
});

export const GET = withRoute(async (req, ctx) => {
  const hypotheses = await listHypotheses(ctx.user.id);
  return NextResponse.json({ hypotheses });
});

export const PATCH = withRoute(async (req, ctx) => {
  const input = decideSchema.parse(ctx.data);
  const row = await decideHypothesis(ctx.user.id, input.id, input.decision);
  return NextResponse.json({ id: row.id, status: row.status });
}, { rateLimit: { key: 'hypotheses-patch', limit: 60, windowMs: 60 * 60 * 1000 } });
