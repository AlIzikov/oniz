// BizON API — /api/store/items/[id]/book (Wave 2, S-036): покупка/бронирование.
// Эскроу: люмены списываются в held; velocity STORE_BOOK (тиры верификации).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';
import { checkVelocity } from '@/lib/security/velocity';

export const runtime = 'nodejs';

const bookSchema = z.object({
  slotAt: z.string().datetime().optional(),
  notes: z.string().max(1000).optional(),
});

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const input = bookSchema.parse(ctx.data);

  // Тир верификации → velocity-лимит (§8.2): basic = 4x ниже (антискам-фильтр).
  const tierRow = await db.user.findUnique({ where: { id: ctx.user.id }, select: { verificationTier: true } });
  const tier = tierRow?.verificationTier ?? 'basic';
  if (!checkVelocity(ctx.user.id, { key: 'store_book', limit: 10, windowMs: 60 * 60 * 1000 }, tier)) {
    return NextResponse.json({ error: 'Слишком много покупок подряд. Попробуйте позже.' }, { status: 429 });
  }

  const booking = await StoreService.requestBooking(ctx.user.id, ctx.params.id, input);
  return NextResponse.json({ booking }, { status: 201 });
}, { rateLimit: { key: 'store-book', limit: 15, windowMs: 60 * 60 * 1000 } });
