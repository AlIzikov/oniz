// BizON API — /api/store/items/[id] (Wave 2, S-035): обновление товара владельцем.
// Цена блокируется при открытых сделках (guard в StoreService.updateItem).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';

export const runtime = 'nodejs';

const patchSchema = z.object({
  title: z.string().min(1).max(120).optional(),
  description: z.string().max(4000).optional(),
  priceLumens: z.number().int().min(1).max(100_000).optional(),
  status: z.enum(['active', 'paused', 'archived']).optional(),
  isPremium: z.boolean().optional(),
  slotsTotal: z.number().int().min(0).max(1000).optional(),
});

export const PATCH = withRoute<{ id: string }>(async (req, ctx) => {
  const patch = patchSchema.parse(ctx.data);
  const item = await StoreService.updateItem(ctx.user.id, ctx.params.id, patch);
  return NextResponse.json({ item });
}, { rateLimit: { key: 'store-items-patch', limit: 60, windowMs: 60 * 60 * 1000 } });
