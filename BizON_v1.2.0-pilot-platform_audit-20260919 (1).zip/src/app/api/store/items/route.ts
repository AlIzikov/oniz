// BizON API — /api/store/items (Wave 2 Store MVP, S-034).
// GET  — витрина: активные товары (premium первыми), фильтры type/q/ownerId/premiumOnly.
// POST — создать товар/услугу (владелец; premium — только Pro/Business).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';

export const runtime = 'nodejs';

const createSchema = z.object({
  type: z.enum(['services', 'digital', 'expert-access']),
  title: z.string().min(1).max(120),
  description: z.string().max(4000).default(''),
  priceLumens: z.number().int().min(1).max(100_000),
  deliveryMode: z.enum(['online-meeting', 'async', 'file-delivery']),
  evidenceRefs: z.array(z.string().max(64)).max(10).optional(),
  isPremium: z.boolean().optional(),
  slotsTotal: z.number().int().min(0).max(1000).optional(),
});

export const GET = withRoute(async (req, ctx) => {
  const sp = new URL(req.url).searchParams;
  // mine=1 — личная витрина владельца (все статусы); требует сессию (auth:false
  // сверху, здесь проверяем факт логина — без него обычный публичный список).
  if (sp.get('mine') === '1' && ctx.user) {
    const items = await StoreService.myItems(ctx.user.id);
    return NextResponse.json({ items });
  }
  const items = await StoreService.listItems({
    type: sp.get('type') ?? undefined,
    q: sp.get('q') ?? undefined,
    ownerId: sp.get('ownerId') ?? undefined,
    premiumOnly: sp.get('premiumOnly') === '1',
  });
  return NextResponse.json({ items });
}, { auth: false });

export const POST = withRoute(async (req, ctx) => {
  const input = createSchema.parse(ctx.data);
  const item = await StoreService.createItem(ctx.user.id, input);
  return NextResponse.json({ item }, { status: 201 });
}, { rateLimit: { key: 'store-items-post', limit: 20, windowMs: 60 * 60 * 1000 } });
