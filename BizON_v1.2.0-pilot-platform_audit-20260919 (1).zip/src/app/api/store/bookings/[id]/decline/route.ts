// BizON API — /api/store/bookings/[id]/decline (Wave 2, S-037): отказ продавца + возврат.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await StoreService.decline(ctx.user.id, ctx.params.id);
  return NextResponse.json(result);
}, { rateLimit: { key: 'store-decline', limit: 60, windowMs: 60 * 60 * 1000 } });
