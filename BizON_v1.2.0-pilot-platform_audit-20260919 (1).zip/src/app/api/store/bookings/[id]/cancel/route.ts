// BizON API — /api/store/bookings/[id]/cancel (Wave 2, S-037): отмена покупателем + возврат.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await StoreService.cancel(ctx.user.id, ctx.params.id);
  return NextResponse.json(result);
}, { rateLimit: { key: 'store-cancel', limit: 60, windowMs: 60 * 60 * 1000 } });
