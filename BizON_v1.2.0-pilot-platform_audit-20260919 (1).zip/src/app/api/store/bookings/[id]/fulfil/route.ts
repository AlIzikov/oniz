// BizON API — /api/store/bookings/[id]/fulfil (Wave 2, S-037): продавец отметил исполнение.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await StoreService.fulfil(ctx.user.id, ctx.params.id);
  return NextResponse.json(result);
}, { rateLimit: { key: 'store-fulfil', limit: 60, windowMs: 60 * 60 * 1000 } });
