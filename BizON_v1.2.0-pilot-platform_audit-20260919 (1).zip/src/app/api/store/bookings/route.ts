// BizON API — /api/store/bookings (Wave 2, S-037): мои сделки в обеих ролях.
// GET — продажи + покупки (opportunistic sweep зависших состояний внутри).
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/api-helpers';
import { StoreService } from '@/lib/services/store-service';

export const runtime = 'nodejs';

export const GET = withRoute(async (req, ctx) => {
  const data = await StoreService.myBookings(ctx.user.id);
  return NextResponse.json(data);
}, { rateLimit: { key: 'store-bookings-get', limit: 120, windowMs: 60 * 60 * 1000 } });
