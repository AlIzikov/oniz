// BizON API — /api/lots/[id]/respond (Wave 4, S-086): отклик кандидата на LOT.
// Velocity-тиры: basic-аккаунты получают лимит в 4 раза ниже (§8.2-1).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { db } from '@/lib/db';
import { checkVelocity } from '@/lib/security/velocity';
import { LotService } from '@/lib/services/lot-service';

export const runtime = 'nodejs';

const schema = z.object({
  message: z.string().min(10).max(2000),
  proposedLumens: z.number().int().min(1).max(1_000_000).nullable().optional(),
});

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const tierRow = await db.user.findUnique({ where: { id: ctx.user.id }, select: { verificationTier: true } });
  const tier = tierRow?.verificationTier ?? 'basic';
  if (!checkVelocity(ctx.user.id, { key: 'lot_respond', limit: 20, windowMs: 60 * 60 * 1000 }, tier)) {
    return NextResponse.json({ error: 'Слишком много откликов подряд. Попробуйте позже.' }, { status: 429 });
  }
  const input = schema.parse(ctx.data);
  const result = await LotService.respond(ctx.params.id, ctx.user.id, input);
  if (result.ok) return NextResponse.json(result.data, { status: 201 });
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, {
  rateLimit: { key: 'lot-respond', limit: 30, windowMs: 60 * 60 * 1000 },
});
