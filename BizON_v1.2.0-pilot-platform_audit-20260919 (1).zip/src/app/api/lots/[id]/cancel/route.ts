// BizON API — /api/lots/[id]/cancel (Wave 4, S-086): отмена лота владельцем
// (open → cancel без денег; accepted → refund эскроу).
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { LotService } from '@/lib/services/lot-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await LotService.cancel(ctx.params.id, ctx.user.id);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, {
  rateLimit: { key: 'lot-cancel', limit: 30, windowMs: 60 * 60 * 1000 },
});
