// BizON API — /api/lots/[id]/accept (Wave 4, S-086): решение владельца по отклику.
// action: 'accept' (default) | 'decline'. Accept замораживает бюджет (эскроу).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { LotService } from '@/lib/services/lot-service';

export const runtime = 'nodejs';

const schema = z.object({
  responseId: z.string().min(1),
  action: z.enum(['accept', 'decline']).default('accept'),
});

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const input = schema.parse(ctx.data);
  const result = input.action === 'accept'
    ? await LotService.acceptResponse(ctx.params.id, input.responseId, ctx.user.id)
    : await LotService.declineResponse(ctx.params.id, input.responseId, ctx.user.id);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, {
  rateLimit: { key: 'lot-decide', limit: 60, windowMs: 60 * 60 * 1000 },
});
