// BizON API — /api/lots/[id]/complete (Wave 4, S-086): завершение лота,
// release эскроу исполнителю. §3.3: публичных чисел доверия не пишет.
import { NextResponse } from 'next/server';
import { withRoute } from '@/lib/with-route';
import { LotService } from '@/lib/services/lot-service';

export const runtime = 'nodejs';

export const POST = withRoute<{ id: string }>(async (req, ctx) => {
  const result = await LotService.complete(ctx.params.id, ctx.user.id);
  if (result.ok) return NextResponse.json(result.data);
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}, {
  rateLimit: { key: 'lot-complete', limit: 30, windowMs: 60 * 60 * 1000 },
});
