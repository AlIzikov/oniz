// BizON API — /api/lots (Wave 4, S-086): LOT-биржа.
// GET  — список LOT'ов: ?projectId=… (публично; полные отклики — только
//        владельцу проекта) или ?mine=1 (мои LOT'ы с откликами).
// POST — создать LOT (владелец проекта).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { db } from '@/lib/db';
import { LotService, serializeLot } from '@/lib/services/lot-service';

export const runtime = 'nodejs';

const createSchema = z.object({
  projectId: z.string().min(1),
  title: z.string().min(3).max(120),
  description: z.string().min(10).max(4000),
  skills: z.array(z.string().min(1).max(40)).max(15).optional(),
  budgetLumens: z.number().int().min(1).max(1_000_000).nullable().optional(),
  durationDays: z.number().int().min(1).max(365).nullable().optional(),
  acceptUntil: z.string().min(1),
});

const querySchema = z.object({
  projectId: z.string().min(1).optional(),
  mine: z.enum(['0', '1']).optional(),
});

function toOk(result: { ok: true; data: unknown } | { ok: false; code: string; message: string; httpStatus: number }) {
  if (result.ok) return NextResponse.json(result.data, { status: 201 });
  return NextResponse.json({ error: result.message, code: result.code }, { status: result.httpStatus });
}

export const GET = withRoute(async (req, ctx) => {
  const q = querySchema.parse(ctx.data);
  const viewerId = ctx.user?.id ?? null;

  if (q.mine === '1') {
    if (!viewerId) return NextResponse.json({ error: 'Не авторизован' }, { status: 401 });
    const lots = await db.projectLot.findMany({
      where: { ownerId: viewerId },
      orderBy: { createdAt: 'desc' },
      include: {
        responses: {
          include: { user: { select: { id: true, name: true, avatarUrl: true } } },
          orderBy: { createdAt: 'desc' },
        },
      },
    });
    return NextResponse.json({ lots: lots.map((l) => ({ ...serializeLot(l), responses: l.responses })) });
  }

  if (!q.projectId) return NextResponse.json({ error: 'Укажите projectId или mine=1' }, { status: 400 });

  const project = await db.project.findUnique({
    where: { id: q.projectId },
    select: { ownerId: true, visibility: true, confidentiality: true },
  });
  if (!project) return NextResponse.json({ error: 'Проект не найден' }, { status: 404 });
  const isPublic = (project.visibility ?? 'public').toUpperCase() === 'PUBLIC' && (project.confidentiality ?? 'public').toUpperCase() === 'PUBLIC';
  const isOwner = viewerId === project.ownerId;
  if (!isPublic && !isOwner) return NextResponse.json({ error: 'Проект не найден' }, { status: 404 });

  const lots = await db.projectLot.findMany({
    where: { projectId: q.projectId },
    orderBy: { createdAt: 'desc' },
    include: {
      responses: {
        // полные отклики видит только владелец проекта; остальным — агрегаты
        select: isOwner ? undefined : { status: true },
      },
    },
  });
  return NextResponse.json({
    lots: lots.map((l) => ({
      ...serializeLot(l),
      responsesCount: l.responses.length,
      pendingCount: l.responses.filter((r) => (r as { status?: string }).status === 'pending').length,
      // полные объекты откликов — только владельцу
      responses: isOwner ? l.responses : undefined,
    })),
  });
}, { auth: false, schema: querySchema });

export const POST = withRoute(async (req, ctx) => {
  const input = createSchema.parse(ctx.data);
  const result = await LotService.createLot(input.projectId, ctx.user.id, {
    title: input.title,
    description: input.description,
    skills: input.skills,
    budgetLumens: input.budgetLumens ?? null,
    durationDays: input.durationDays ?? null,
    acceptUntil: input.acceptUntil,
  });
  return toOk(result);
}, {
  rateLimit: { key: 'lot-create', limit: 30, windowMs: 60 * 60 * 1000 },
});
