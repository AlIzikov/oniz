// BizON API — /api/placements
// Этап 4.2 — HR Persona: Placement Portfolio.
// POST — HR-агентство (accountType='hr_agency') создаёт placement — фиксирует
//         факт трудоустройства кандидата в компанию. Может быть анонимным
//         (candidateId=null → "Кандидат N").
// GET  — список placements (по умолчанию для текущего HR-агентства; ?hrAgencyId=...
//         для просмотра портфолио конкретного HR; ?candidateId=... для кандидата).
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit, MUTATION_LIMITS } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const MAX_JOB_TITLE_LENGTH = 200;
const MAX_CANDIDATE_NAME_LENGTH = 200;

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const sp = req.nextUrl.searchParams;
  const hrAgencyId = sp.get('hrAgencyId');
  const candidateId = sp.get('candidateId');
  const companyId = sp.get('companyId');

  // По умолчанию: если HR запрашивает без параметров — отдаём его placements
  const targetHrId = hrAgencyId ?? (user.accountType === 'hr_agency' ? user.id : null);

  const where: any = { isPublic: true };
  if (targetHrId) where.hrAgencyId = targetHrId;
  if (candidateId) where.candidateId = candidateId;
  if (companyId) where.companyId = companyId;
  // Если запрашивают конкретный профиль кандидата — НЕ фильтруем по isPublic
  // (кандидат видит все свои placements, в т.ч. приватные)
  if (candidateId && candidateId === user.id) {
    delete where.isPublic;
  }

  const placements = await db.placement.findMany({
    where,
    orderBy: { placedAt: 'desc' },
    take: 100,
    include: {
      hrAgency: { select: { id: true, name: true, avatarUrl: true, title: true } },
      company: { select: { id: true, name: true, logoUrl: true, industry: true } },
      candidate: { select: { id: true, name: true, avatarUrl: true, title: true } },
    },
  });

  return json({
    placements: placements.map((p) => ({
      id: p.id,
      candidateName: p.candidateName,
      jobTitle: p.jobTitle,
      placedAt: p.placedAt.toISOString(),
      confirmedByCandidate: p.confirmedByCandidate,
      confirmedByCompany: p.confirmedByCompany,
      isPublic: p.isPublic,
      hrAgency: p.hrAgency,
      company: p.company,
      candidate: p.candidateId ? p.candidate : null,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  // Только HR-агентство может создавать placement
  if (user.accountType !== 'hr_agency') {
    return errorJson('Только HR-агентства могут создавать placement', 403);
  }

  const rl = checkUserRateLimit(
    user.id,
    'placements:create',
    ...MUTATION_LIMITS.eventsCreate,
  );
  if (!rl.allowed) {
    return errorJson(`Слишком много запросов. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  try {
    const body = await req.json();
    const { candidateId, candidateName, companyId, jobTitle, isPublic = true } = body ?? {};

    // === Валидация ===
    if (!companyId || typeof companyId !== 'string') {
      return errorJson('companyId обязателен', 422);
    }
    if (!jobTitle || typeof jobTitle !== 'string' || !jobTitle.trim() || jobTitle.length > MAX_JOB_TITLE_LENGTH) {
      return errorJson(`jobTitle обязателен (макс. ${MAX_JOB_TITLE_LENGTH} символов)`, 422);
    }
    if (typeof isPublic !== 'boolean') {
      return errorJson('isPublic должен быть boolean', 422);
    }

    // candidateId опционален (анонимный placement)
    let resolvedCandidateId: string | null = null;
    let resolvedCandidateName = '';
    if (candidateId) {
      if (typeof candidateId !== 'string') {
        return errorJson('candidateId должен быть строкой', 422);
      }
      const candidate = await db.user.findUnique({
        where: { id: candidateId },
        select: { id: true, name: true, accountType: true },
      });
      if (!candidate) return errorJson('Кандидат не найден', 404);
      if (candidate.id === user.id) {
        return errorJson('Нельзя создать placement для самого себя', 422);
      }
      resolvedCandidateId = candidate.id;
      resolvedCandidateName = candidate.name;
    } else {
      // Анонимный placement — нужен candidateName (по умолчанию "Кандидат N")
      if (candidateName && typeof candidateName === 'string' && candidateName.trim()) {
        if (candidateName.length > MAX_CANDIDATE_NAME_LENGTH) {
          return errorJson(`candidateName слишком длинный (макс. ${MAX_CANDIDATE_NAME_LENGTH})`, 422);
        }
        resolvedCandidateName = candidateName.trim();
      } else {
        // Генерируем "Кандидат N" — N = порядковый номер анонимного placement'а у этого HR
        const countAnon = await db.placement.count({
          where: { hrAgencyId: user.id, candidateId: null },
        });
        resolvedCandidateName = `Кандидат ${countAnon + 1}`;
      }
    }

    // Проверяем существование компании
    const company = await db.company.findUnique({
      where: { id: companyId },
      select: { id: true, name: true },
    });
    if (!company) return errorJson('Компания не найдена', 404);

    const placement = await db.placement.create({
      data: {
        hrAgencyId: user.id,
        candidateId: resolvedCandidateId,
        candidateName: resolvedCandidateName,
        companyId,
        jobTitle: jobTitle.trim(),
        isPublic,
      },
    });

    // Уведомляем кандидата (если placement не анонимный)
    if (resolvedCandidateId) {
      await db.notification
        .create({
          data: {
            userId: resolvedCandidateId,
            type: 'hr_placement',
            title: 'HR-агентство добавило placement',
            content: `Позиция: ${jobTitle.trim()} в компании «${company.name}». Подтвердите, чтобы отобразилось в портфолио HR.`,
            link: '/settings',
          },
        })
        .catch((e) => console.error('[placements/create] notification error:', e));
    }

    return json(
      {
        placement: {
          id: placement.id,
          candidateName: placement.candidateName,
          jobTitle: placement.jobTitle,
          placedAt: placement.placedAt.toISOString(),
          confirmedByCandidate: placement.confirmedByCandidate,
          confirmedByCompany: placement.confirmedByCompany,
          isPublic: placement.isPublic,
          companyId: placement.companyId,
          candidateId: placement.candidateId,
        },
      },
      201,
    );
  } catch (e) {
    console.error('[placements/create] error:', e);
    return errorJson('Ошибка создания placement', 500);
  }
}
