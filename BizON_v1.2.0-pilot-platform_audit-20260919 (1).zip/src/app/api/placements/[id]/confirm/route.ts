// BizON API — /api/placements/[id]/confirm
// Этап 4.2 — Placement Portfolio: кандидат или компания подтверждают placement.
// Подтверждение компанией: текущий пользователь должен быть сотрудником компании
//   (Employee с isCurrent=true) или админом-владельцем (User.companyId === placement.companyId).
// Подтверждение кандидатом: текущий пользователь должен быть placement.candidateId.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const placement = await db.placement.findUnique({
      where: { id },
      include: {
        company: { select: { id: true, name: true } },
        candidate: { select: { id: true, name: true } },
        hrAgency: { select: { id: true, name: true } },
      },
    });
    if (!placement) return errorJson('Placement не найден', 404);

    // Определяем, кто подтверждает: кандидат или компания
    const isCandidate = placement.candidateId === user.id;
    let isCompanyRep = false;
    if (user.companyId === placement.companyId && (user.accountType === 'company' || user.accountType === 'hr_agency')) {
      isCompanyRep = true;
    } else {
      // Проверяем, является ли пользователь текущим сотрудником компании
      const emp = await db.employee.findFirst({
        where: { companyId: placement.companyId, userId: user.id, isCurrent: true },
        select: { id: true },
      });
      if (emp) isCompanyRep = true;
    }

    if (!isCandidate && !isCompanyRep) {
      return errorJson('У вас нет прав подтверждать этот placement', 403);
    }

    const data: any = {};
    if (isCandidate && !placement.confirmedByCandidate) data.confirmedByCandidate = true;
    if (isCompanyRep && !placement.confirmedByCompany) data.confirmedByCompany = true;

    // Если нечего обновлять — возвращаем текущее состояние
    if (Object.keys(data).length === 0) {
      return json({
        placement: {
          id: placement.id,
          confirmedByCandidate: placement.confirmedByCandidate,
          confirmedByCompany: placement.confirmedByCompany,
        },
        alreadyConfirmed: true,
      });
    }

    const updated = await db.placement.update({ where: { id }, data });

    // Уведомляем HR об подтверждении
    await db.notification
      .create({
        data: {
          userId: placement.hrAgencyId,
          type: 'hr_placement',
          title: 'Placement подтверждён',
          content: `${isCandidate ? 'Кандидат' : 'Компания'} подтвердил(а) placement: ${placement.candidateName} → ${placement.jobTitle} в «${placement.company.name}».`,
          link: '/dashboard',
        },
      })
      .catch((e) => console.error('[placements/confirm] notification error:', e));

    return json({
      placement: {
        id: updated.id,
        confirmedByCandidate: updated.confirmedByCandidate,
        confirmedByCompany: updated.confirmedByCompany,
      },
      alreadyConfirmed: false,
    });
  } catch (e) {
    console.error('[placements/confirm] error:', e);
    return errorJson('Ошибка подтверждения placement', 500);
  }
}
