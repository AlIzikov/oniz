// BizON API — /api/insights/bizon-moment/dismiss
// Phase 2 — BIZON MOMENT: пометить текущий инсайт прочитанным (dismiss).
// Body: { insightId } — ID инсайта для dismiss.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { BizonMomentService } from '@/lib/services/bizon-moment-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json().catch(() => ({}));
    const { insightId } = body ?? {};

    if (insightId && typeof insightId === 'string') {
      // Dismiss конкретного инсайта
      await BizonMomentService.markRead(insightId, user.id);
    } else {
      // Dismiss всех unread инсайтов (fallback)
      await db.aiInsight.updateMany({
        where: { userId: user.id, type: 'bizon_moment', isRead: false },
        data: { isRead: true },
      });
    }

    return json({ ok: true });
  } catch (e) {
    console.error('[bizon-moment/dismiss] error:', e);
    return errorJson('Ошибка dismiss', 500);
  }
}
