// BizON API — /api/insights/bizon-moment/opt-in
// Phase 2 — BIZON MOMENT: toggle opt-in.
// Body: { optIn: boolean } — новое значение.
// Возвращает обновлённый optIn.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { BizonMomentService } from '@/lib/services/bizon-moment-service';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  try {
    const body = await req.json().catch(() => ({}));
    const { optIn } = body ?? {};

    if (typeof optIn !== 'boolean') {
      return errorJson('optIn должен быть boolean', 422);
    }

    const result = await BizonMomentService.setOptIn(user.id, optIn);
    return json(result);
  } catch (e) {
    console.error('[bizon-moment/opt-in] error:', e);
    return errorJson('Ошибка toggle opt-in', 500);
  }
}
