// BizON API — Плановые уведомления о днях рождения (BirthdayPlan)
// GET: список планов текущего владельца, сортировка (dateMonth, dateDay)
// POST: создание плана (кап 50 на владельца).
// Честность: напоминания пока только сохраняются (крона нет) —
// в ответе scheduled: false + примечание, фронт показывает это как подпись.
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const CHANNELS = ['in_platform', 'sms', 'call', 'in_person', 'gift'] as const;
type Channel = (typeof CHANNELS)[number];

const MAX_PLANS = 50;
export const HONEST_NOTE = 'Напоминание сохранено; отправка по каналу появится в следующих версиях';

function isValidDate(month: number, day: number): boolean {
  // Проверяем через реальную дату: 31.04 → Date сам «перекатит» на 1 мая — отсеиваем
  const d = new Date(2024, month - 1, day);
  return d.getMonth() === month - 1 && d.getDate() === day;
}

export async function GET(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const plans = await db.birthdayPlan.findMany({
    where: { ownerId: user.id },
    orderBy: [{ dateMonth: 'asc' }, { dateDay: 'asc' }, { createdAt: 'asc' }],
    take: MAX_PLANS,
  });

  return json({
    plans: plans.map((p) => ({
      id: p.id,
      personUserId: p.personUserId,
      personName: p.personName,
      dateMonth: p.dateMonth,
      dateDay: p.dateDay,
      channel: p.channel as Channel,
      comment: p.comment,
      remindBefore: p.remindBefore,
      status: p.status as 'planned' | 'done',
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    })),
    total: plans.length,
    max: MAX_PLANS,
  });
}

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'birthday-plans:create', 20, 60_000);
  if (!rl.allowed) return errorJson('Слишком много запросов, попробуйте позже', 429);

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }

  // personName — обязателен, 1..80
  const personName = typeof body.personName === 'string' ? body.personName.trim() : '';
  if (!personName || personName.length > 80) {
    return errorJson('Укажите имя человека (до 80 символов)', 422);
  }

  // dateMonth 1..12
  const dateMonth = Number(body.dateMonth);
  if (!Number.isInteger(dateMonth) || dateMonth < 1 || dateMonth > 12) {
    return errorJson('Месяц должен быть числом от 1 до 12', 422);
  }

  // dateDay 1..31 + валидность даты
  const dateDay = Number(body.dateDay);
  if (!Number.isInteger(dateDay) || dateDay < 1 || dateDay > 31 || !isValidDate(dateMonth, dateDay)) {
    return errorJson('Такой даты не существует (проверьте день и месяц)', 422);
  }

  // channel — белый список
  const channel = body.channel as Channel | undefined;
  if (!channel || !CHANNELS.includes(channel)) {
    return errorJson('Недопустимый канал', 422);
  }

  // comment — обязателен (требование продукта: плановое уведомление всегда с комментарием), ≤500
  const comment = typeof body.comment === 'string' ? body.comment.trim() : '';
  if (!comment) {
    return errorJson('Комментарий обязателен — что именно сделать (позвонить, направить СМС и т.д.)', 422);
  }
  if (comment.length > 500) {
    return errorJson('Комментарий — максимум 500 символов', 422);
  }

  // remindBefore 0..14
  const remindBefore = body.remindBefore === undefined ? 0 : Number(body.remindBefore);
  if (!Number.isInteger(remindBefore) || remindBefore < 0 || remindBefore > 14) {
    return errorJson('Напоминание — от 0 до 14 дней до даты', 422);
  }

  // personUserId — опционально, строка (если передан)
  let personUserId: string | null = null;
  if (body.personUserId !== undefined && body.personUserId !== null && body.personUserId !== '') {
    if (typeof body.personUserId !== 'string') {
      return errorJson('personUserId должен быть строкой', 422);
    }
    personUserId = body.personUserId;
  }

  // Кап на владельца
  const count = await db.birthdayPlan.count({ where: { ownerId: user.id } });
  if (count >= MAX_PLANS) {
    return errorJson('Слишком много планов — максимум 50. Удалите старые, чтобы добавить новый', 422);
  }

  const plan = await db.birthdayPlan.create({
    data: {
      ownerId: user.id,
      personUserId,
      personName,
      dateMonth,
      dateDay,
      channel,
      comment,
      remindBefore,
      status: 'planned',
    },
  });

  // Честно: планировщик напоминаний пока не реализован — сохраняем и сообщаем
  return json({
    plan: {
      id: plan.id,
      personUserId: plan.personUserId,
      personName: plan.personName,
      dateMonth: plan.dateMonth,
      dateDay: plan.dateDay,
      channel: plan.channel as Channel,
      comment: plan.comment,
      remindBefore: plan.remindBefore,
      status: plan.status as 'planned' | 'done',
      createdAt: plan.createdAt.toISOString(),
      updatedAt: plan.updatedAt.toISOString(),
    },
    scheduled: false,
    note: HONEST_NOTE,
  });
}
