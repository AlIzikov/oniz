// BizON API — Плановое уведомление о ДР: обновление / удаление (только владелец)
import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';

export const runtime = 'nodejs';

const CHANNELS = ['in_platform', 'sms', 'call', 'in_person', 'gift'] as const;
const STATUSES = ['planned', 'done'] as const;

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await params;
  const plan = await db.birthdayPlan.findUnique({ where: { id } });
  if (!plan) return errorJson('План не найден', 404);
  if (plan.ownerId !== user.id) return errorJson('Нет доступа к этому плану', 403);

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return errorJson('Некорректный JSON', 400);
  }

  const data: { comment?: string; channel?: string; remindBefore?: number; status?: string } = {};

  if (body.comment !== undefined) {
    if (typeof body.comment !== 'string' || body.comment.trim().length > 500) {
      return errorJson('Комментарий — максимум 500 символов', 422);
    }
    data.comment = body.comment.trim();
  }

  if (body.channel !== undefined) {
    const channel = body.channel;
    if (typeof channel !== 'string' || !CHANNELS.includes(channel as (typeof CHANNELS)[number])) {
      return errorJson('Недопустимый канал', 422);
    }
    data.channel = channel;
  }

  if (body.remindBefore !== undefined) {
    const remindBefore = Number(body.remindBefore);
    if (!Number.isInteger(remindBefore) || remindBefore < 0 || remindBefore > 14) {
      return errorJson('Напоминание — от 0 до 14 дней до даты', 422);
    }
    data.remindBefore = remindBefore;
  }

  if (body.status !== undefined) {
    const status = body.status;
    if (typeof status !== 'string' || !STATUSES.includes(status as (typeof STATUSES)[number])) {
      return errorJson('Статус — planned или done', 422);
    }
    data.status = status;
  }

  if (Object.keys(data).length === 0) {
    return errorJson('Нет полей для обновления', 422);
  }

  const updated = await db.birthdayPlan.update({ where: { id }, data });

  return json({
    plan: {
      id: updated.id,
      personUserId: updated.personUserId,
      personName: updated.personName,
      dateMonth: updated.dateMonth,
      dateDay: updated.dateDay,
      channel: updated.channel,
      comment: updated.comment,
      remindBefore: updated.remindBefore,
      status: updated.status,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    },
  });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await params;
  const plan = await db.birthdayPlan.findUnique({ where: { id } });
  if (!plan) return errorJson('План не найден', 404);
  if (plan.ownerId !== user.id) return errorJson('Нет доступа к этому плану', 403);

  await db.birthdayPlan.delete({ where: { id } });

  return json({ ok: true });
}
