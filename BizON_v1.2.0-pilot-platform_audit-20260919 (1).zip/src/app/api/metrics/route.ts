// BizON API — /api/metrics
// Этап 6.6 MON: Monitoring — метрики для Prometheus scrape + JSON-снимок для админ-панели.
//
// v6.1 (Task 9-d, doc_scaling §8 BizON Scaling Controller + аудит п.8):
//   • bizon_http_requests_total / bizon_http_request_duration_seconds — больше НЕ
//     заглушки: реальные сборщики через instrumentation-хук (src/instrumentation.ts →
//     src/lib/scaling/http-metrics.ts, ring-buffer через KV). RPS/p95 — реальные.
//   • Добавлены метрики resilience-слоя (doc_scaling §31/§33): Circuit Breaker'ы,
//     Backpressure-очереди, Compute Router (провайдеры/классы задач).
//   • Добавлены метрики Scaling Controller (рекомендации scale_up/scale_down/stable,
//     предиктив пика EMA+линейная проекция). HPA/k8s остаются выключенными —
//     контроллер работает в advisory-режиме (advisoryOnly=true).
//
// По умолчанию (без query-параметра): Prometheus exposition format (text/plain).
// При `?format=json` (или Accept: application/json): JSON-снимок для UI-дашборда,
//   идентичный по структуре /api/admin/metrics — но доступный на каноническом пути.
//
// JSON-формат (Phase 16 + v6.1 расширения):
//   {
//     "users":   { "total": N, "active24h": N },
//     "content": { "posts": N, "projects": N, "jobs": N, "events": N },
//     "api":     { "cacheSize": N, "cacheHits": N, "cacheMisses": N, "cacheHitRate": 0.65 },
//     "system":  { "uptime": N, "memory": "120MB", "memoryRssBytes": N, "dbStatus": "ok" },
//     "http":    { "rps1m": N, "rps5m": N, "p50Ms": N, "p95Ms": N, "p99Ms": N,
//                  "errorRate": N, "totalRequests": N },                  // v6.1
//     "resilience": { "circuitBreakers": [...], "backpressureQueues": [...] }, // v6.1
//     "compute": { "tasksExecuted": N, "tasksFailed": N, "byClass": {...},
//                  "providers": [...] },                                   // v6.1
//     "scaling": { "status", "recommendation", "reasons", "predictive",
//                  "recommendedReplicas", "forecast": {...}, "capacity": {...},
//                  "advisoryOnly": true },                                 // v6.1
//     "version": "2.0.0",
//     "timestamp": "2026-..."
//   }
//
// Auth: admin user (через сессию) ИЛИ через METRICS_TOKEN env (Bearer токен).
// Это позволяет отделить scrape-credentials от пользовательских аккаунтов.

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromRequest } from '@/lib/api-helpers';
import { isAdminRole } from '@/lib/admin-guard'; // FIX-02: единая проверка роли
import { cache } from '@/lib/cache';
import {
  snapshot as httpSnapshot,
  getRequestTotals,
  getDurationTotals,
  ensureHttpMetricsHook,
} from '@/lib/scaling/http-metrics';
import { ScalingController } from '@/lib/scaling/controller';
import { getAllCircuitBreakerMetrics } from '@/lib/resilience/circuit-breaker';
import { getAllBackpressureMetrics } from '@/lib/resilience/backpressure';
import { ComputeRouter } from '@/lib/compute/router';

export const runtime = 'nodejs';

// Service start time — для расчёта uptime
const START_TIME = Date.now();
// Phase 16: bumped to 2.0.0 (perf + monitoring)
const VERSION = '2.0.0';

async function checkAuth(req: NextRequest): Promise<boolean> {
  // Путь 1: METRICS_TOKEN env (Bearer токен) — для Prometheus scrape
  const metricsToken = process.env.METRICS_TOKEN;
  if (metricsToken) {
    const auth = req.headers.get('authorization');
    if (auth?.startsWith('Bearer ') && auth.slice(7) === metricsToken) {
      return true;
    }
  }
  // Путь 2: admin через обычную сессию (cookie/Bearer)
  // FIX-02: проверка роли через единый isAdminRole (src/lib/admin-guard.ts)
  // FIX-03: dev-релаксация удалена (аудит) — доступ только role admin или
  // METRICS_TOKEN. Метрики раскрывают инфраструктуру — любому аутентифицированному
  // пользователю их смотреть нельзя и в dev-песочнице тоже.
  try {
    const user = await getUserFromRequest(req);
    if (user && isAdminRole(user.roles)) return true;
  } catch (e) {
    // ignore — fall through to 401
  }
  return false;
}

function formatRss(): number {
  // process.memoryUsage().rss — resident set size в байтах
  try {
    return process.memoryUsage().rss;
  } catch {
    return 0;
  }
}

function formatMb(bytes: number): string {
  return `${Math.round(bytes / 1024 / 1024)}MB`;
}

/** Prometheus label-value escaping (exposition format). */
function escapeLabel(v: string): string {
  return v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
}

const CB_STATE_NUM: Record<string, number> = { closed: 0, 'half-open': 1, open: 2 };
const SCALING_STATUS_NUM: Record<string, number> = { normal: 0, elevated: 1, high_load: 2, degraded: 3 };
const SCALING_REC_NUM: Record<string, number> = { stable: 0, scale_up: 1, scale_down: 2 };

/**
 * Phase 16: JSON-снимок метрик для админ-дашборда.
 * Аналогичен /api/admin/metrics, доступен здесь для канонического пути /api/metrics.
 * Возвращается при `?format=json` или Accept: application/json.
 * v6.1: добавлены секции http/resilience/compute/scaling (старые поля не тронуты).
 */
function buildJsonPayload(opts: {
  usersTotal: number;
  usersActive24h: number;
  postsTotal: number;
  projectsActive: number;
  jobsOpen: number;
  eventsUpcoming: number;
  dbStatus: string;
  cacheStats: { size: number; hits: number; misses: number; hitRate: number };
  rssBytes: number;
  uptimeSeconds: number;
}) {
  const http = httpSnapshot();
  const scaling = ScalingController.evaluate();
  return {
    users: {
      total: opts.usersTotal,
      active24h: opts.usersActive24h,
    },
    content: {
      posts: opts.postsTotal,
      projects: opts.projectsActive,
      jobs: opts.jobsOpen,
      events: opts.eventsUpcoming,
    },
    api: {
      cacheSize: opts.cacheStats.size,
      cacheHits: opts.cacheStats.hits,
      cacheMisses: opts.cacheStats.misses,
      cacheHitRate: Number(opts.cacheStats.hitRate.toFixed(4)),
    },
    system: {
      uptime: opts.uptimeSeconds,
      memory: formatMb(opts.rssBytes),
      memoryRssBytes: opts.rssBytes,
      dbStatus: opts.dbStatus,
    },
    // === v6.1: реальные HTTP-метрики (Scaling Controller фундамент) ===
    http: {
      rps1m: http.rps1m,
      rps5m: http.rps5m,
      p50Ms: http.p50Ms,
      p95Ms: http.p95Ms,
      p99Ms: http.p99Ms,
      errorRate: http.errorRate,
      totalRequests: http.totalRequests,
      topPaths: http.topPaths,
    },
    // === v6.1: resilience (Circuit Breaker / Backpressure) ===
    resilience: {
      circuitBreakers: getAllCircuitBreakerMetrics(),
      backpressureQueues: getAllBackpressureMetrics(),
    },
    // === v6.1: Compute Router (провайдеры, классы задач) ===
    compute: ComputeRouter.getStats(),
    // === v6.1: Scaling Controller (advisory-режим) ===
    scaling: {
      at: scaling.at,
      status: scaling.status,
      recommendation: scaling.recommendation,
      reasons: scaling.reasons,
      predictive: scaling.predictive,
      recommendedReplicas: scaling.recommendedReplicas,
      advisoryOnly: scaling.advisoryOnly,
      forecast: scaling.forecast,
      capacity: scaling.capacity,
      signals: {
        rps1m: scaling.current.rps1m,
        rps5m: scaling.current.rps5m,
        p95Ms: scaling.current.p95Ms,
        p99Ms: scaling.current.p99Ms,
        errorRate: scaling.current.errorRate,
        queueDepth: scaling.current.queueDepth,
        breakersTripped: scaling.current.breakersTripped,
      },
    },
    version: VERSION,
    timestamp: new Date().toISOString(),
  };
}

/** Определяем, хочет ли клиент JSON (вместо Prometheus text). */
function wantsJson(req: NextRequest): boolean {
  const fmt = req.nextUrl.searchParams.get('format');
  if (fmt === 'json') return true;
  if (fmt === 'prometheus' || fmt === 'text') return false;
  // Если format не задан — смотрим на Accept-header.
  const accept = req.headers.get('accept') ?? '';
  return accept.includes('application/json') && !accept.includes('text/plain');
}

export async function GET(req: NextRequest) {
  const ok = await checkAuth(req);
  if (!ok) {
    return new Response('Unauthorized', {
      status: 401,
      headers: { 'content-type': 'text/plain; charset=utf-8', 'www-authenticate': 'Bearer' },
    });
  }

  // v6.1: самоактивация HTTP-инструментирования — если сервер стартовал до
  // появления хука (dev-сервер не перезапускался), первый scrape включает
  // сбор RPS/p95 (идемпотентно, fail-open; сама метрика этого запроса
  // запишется у СЛЕДУЮЩИХ запросов — патч ставится на будущие 'request').
  await ensureHttpMetricsHook().catch(() => undefined);

  // Считаем метрики одним параллельным Promise.all (6 простых count-запросов).
  let usersTotal = 0;
  let usersActive24h = 0;
  let postsTotal = 0;
  let projectsActive = 0;
  let jobsOpen = 0;
  let eventsUpcoming = 0;
  let dbStatus = 'ok';
  try {
    const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const now = new Date();
    [
      usersTotal,
      usersActive24h,
      postsTotal,
      projectsActive,
      jobsOpen,
      eventsUpcoming,
    ] = await Promise.all([
      db.user.count(),
      db.user.count({ where: { lastSeenAt: { gte: since24h } } }),
      db.post.count({ where: { isHidden: false } }),
      db.project.count({ where: { status: 'ACTIVE' } }),
      db.job.count({ where: { active: true } }),
      db.event.count({ where: { startDate: { gte: now } } }),
    ]);
  } catch (e: unknown) {
    console.error('[metrics] DB query failed:', e instanceof Error ? e.message : e);
    dbStatus = 'error';
  }

  const uptimeSeconds = Math.floor((Date.now() - START_TIME) / 1000);
  const cacheStats = cache.stats();
  // Periodically sweep expired entries while we're here (cheap O(n))
  cache.sweep();
  const rssBytes = formatRss();

  // === Phase 16: JSON-снимок для админ-дашборда ===
  // /api/metrics?format=json → JSON; иначе — Prometheus text exposition.
  if (wantsJson(req)) {
    const payload = buildJsonPayload({
      usersTotal,
      usersActive24h,
      postsTotal,
      projectsActive,
      jobsOpen,
      eventsUpcoming,
      dbStatus,
      cacheStats,
      rssBytes,
      uptimeSeconds,
    });
    return Response.json(payload, {
      status: 200,
      headers: {
        'cache-control': 'no-store',
      },
    });
  }

  // === v6.1: реальные сборщики (http-metrics + resilience + compute + scaling) ===
  const http = httpSnapshot();
  const requestTotals = getRequestTotals();
  const durationTotals = getDurationTotals();
  const breakers = getAllCircuitBreakerMetrics();
  const queues = getAllBackpressureMetrics();
  const computeStats = ComputeRouter.getStats();
  const scaling = ScalingController.evaluate();

  // === Prometheus exposition format ===
  // Спецификация: https://prometheus.io/docs/instrumenting/exposition_formats/
  // Каждая метрика — HELP (описание), TYPE (тип), и значения.
  const lines: string[] = [];

  lines.push('# HELP bizon_users_total Total registered users.');
  lines.push('# TYPE bizon_users_total gauge');
  lines.push(`bizon_users_total ${usersTotal}`);

  lines.push('# HELP bizon_users_active_24h Users active in last 24h (lastSeenAt).');
  lines.push('# TYPE bizon_users_active_24h gauge');
  lines.push(`bizon_users_active_24h ${usersActive24h}`);

  lines.push('# HELP bizon_posts_total Total non-hidden posts.');
  lines.push('# TYPE bizon_posts_total gauge');
  lines.push(`bizon_posts_total ${postsTotal}`);

  lines.push('# HELP bizon_projects_active Number of projects with status=ACTIVE.');
  lines.push('# TYPE bizon_projects_active gauge');
  lines.push(`bizon_projects_active ${projectsActive}`);

  lines.push('# HELP bizon_jobs_open Number of open jobs (active=true).');
  lines.push('# TYPE bizon_jobs_open gauge');
  lines.push(`bizon_jobs_open ${jobsOpen}`);

  lines.push('# HELP bizon_events_upcoming Number of upcoming events (startDate >= now).');
  lines.push('# TYPE bizon_events_upcoming gauge');
  lines.push(`bizon_events_upcoming ${eventsUpcoming}`);

  // === Phase 16: Cache metrics ===
  lines.push('# HELP bizon_cache_size Current number of entries in in-memory cache.');
  lines.push('# TYPE bizon_cache_size gauge');
  lines.push(`bizon_cache_size ${cacheStats.size}`);

  lines.push('# HELP bizon_cache_hits_total Total cache hits.');
  lines.push('# TYPE bizon_cache_hits_total counter');
  lines.push(`bizon_cache_hits_total ${cacheStats.hits}`);

  lines.push('# HELP bizon_cache_misses_total Total cache misses (including expired).');
  lines.push('# TYPE bizon_cache_misses_total counter');
  lines.push(`bizon_cache_misses_total ${cacheStats.misses}`);

  lines.push('# HELP bizon_cache_hit_rate Cache hit rate 0..1.');
  lines.push('# TYPE bizon_cache_hit_rate gauge');
  lines.push(`bizon_cache_hit_rate ${cacheStats.hitRate.toFixed(4)}`);

  // === Phase 16: System metrics ===
  lines.push('# HELP bizon_process_memory_rss_bytes Process RSS memory in bytes.');
  lines.push('# TYPE bizon_process_memory_rss_bytes gauge');
  lines.push(`bizon_process_memory_rss_bytes ${rssBytes}`);

  // === v6.1: РЕАЛЬНЫЕ HTTP-метрики (instrumentation-хук → http-metrics.ts) ===
  // Counter — lifetime по (method, path, status); path нормализован
  // (id-сегменты → ':id'), кардинальность ограничена (сверх — '_overflow_').
  lines.push('# HELP bizon_http_requests_total Total HTTP requests by method/path/status.');
  lines.push('# TYPE bizon_http_requests_total counter');
  for (const s of requestTotals) {
    lines.push(
      `bizon_http_requests_total{method="${escapeLabel(s.method)}",path="${escapeLabel(s.path)}",status="${s.status}"} ${s.count}`
    );
  }

  // Summary латентностей: lifetime _count/_sum + квантили окна 5 минут.
  lines.push('# HELP bizon_http_request_duration_seconds Request duration (summary: lifetime count/sum, 5m-window quantiles).');
  lines.push('# TYPE bizon_http_request_duration_seconds summary');
  lines.push(`bizon_http_request_duration_seconds_count ${durationTotals.count}`);
  lines.push(`bizon_http_request_duration_seconds_sum ${Math.round((durationTotals.sumMs / 1000) * 10000) / 10000}`);
  lines.push(`bizon_http_request_duration_seconds{quantile="0.5"} ${Math.round((http.p50Ms / 1000) * 10000) / 10000}`);
  lines.push(`bizon_http_request_duration_seconds{quantile="0.95"} ${Math.round((http.p95Ms / 1000) * 10000) / 10000}`);
  lines.push(`bizon_http_request_duration_seconds{quantile="0.99"} ${Math.round((http.p99Ms / 1000) * 10000) / 10000}`);

  lines.push('# HELP bizon_http_rps Requests per second (1m and 5m windows).');
  lines.push('# TYPE bizon_http_rps gauge');
  lines.push(`bizon_http_rps{window="1m"} ${http.rps1m}`);
  lines.push(`bizon_http_rps{window="5m"} ${http.rps5m}`);

  lines.push('# HELP bizon_http_error_rate Share of 5xx responses, 5m window (0..1).');
  lines.push('# TYPE bizon_http_error_rate gauge');
  lines.push(`bizon_http_error_rate ${http.errorRate}`);

  // === v6.1: Circuit Breakers (doc_scaling §31) ===
  lines.push('# HELP bizon_circuit_breaker_state Breaker state: 0=closed, 1=half-open, 2=open.');
  lines.push('# TYPE bizon_circuit_breaker_state gauge');
  lines.push('# HELP bizon_circuit_breaker_calls_rejected_total Calls rejected by open breaker.');
  lines.push('# TYPE bizon_circuit_breaker_calls_rejected_total counter');
  lines.push('# HELP bizon_circuit_breaker_opens_total Total breaker open cycles.');
  lines.push('# TYPE bizon_circuit_breaker_opens_total counter');
  for (const b of breakers) {
    const labels = `name="${escapeLabel(b.name)}"`;
    lines.push(`bizon_circuit_breaker_state{${labels}} ${CB_STATE_NUM[b.state] ?? 0}`);
    lines.push(`bizon_circuit_breaker_calls_rejected_total{${labels}} ${b.callsRejected}`);
    lines.push(`bizon_circuit_breaker_opens_total{${labels}} ${b.totalOpens}`);
  }

  // === v6.1: Backpressure очереди (doc_scaling §33) ===
  lines.push('# HELP bizon_backpressure_active Currently executing in queue.');
  lines.push('# TYPE bizon_backpressure_active gauge');
  lines.push('# HELP bizon_backpressure_queued Currently waiting for a slot (queue depth).');
  lines.push('# TYPE bizon_backpressure_queued gauge');
  lines.push('# HELP bizon_backpressure_rejected_total Rejected due to full queue/timeout.');
  lines.push('# TYPE bizon_backpressure_rejected_total counter');
  for (const q of queues) {
    const labels = `queue="${escapeLabel(q.name)}"`;
    lines.push(`bizon_backpressure_active{${labels}} ${q.active}`);
    lines.push(`bizon_backpressure_queued{${labels}} ${q.queued}`);
    lines.push(`bizon_backpressure_rejected_total{${labels}} ${q.rejected}`);
  }

  // === v6.1: Compute Router (провайдеры / классы задач) ===
  lines.push('# HELP bizon_compute_tasks_total Compute Router tasks executed/failed.');
  lines.push('# TYPE bizon_compute_tasks_total counter');
  lines.push(`bizon_compute_tasks_total{outcome="executed"} ${computeStats.tasksExecuted}`);
  lines.push(`bizon_compute_tasks_total{outcome="failed"} ${computeStats.tasksFailed}`);
  lines.push('# HELP bizon_compute_tasks_by_class Tasks executed by task class.');
  lines.push('# TYPE bizon_compute_tasks_by_class counter');
  for (const [cls, n] of Object.entries(computeStats.byClass)) {
    lines.push(`bizon_compute_tasks_by_class{class="${escapeLabel(cls)}"} ${n}`);
  }
  lines.push('# HELP bizon_compute_provider_calls_total Provider calls by provider and outcome.');
  lines.push('# TYPE bizon_compute_provider_calls_total counter');
  for (const p of computeStats.providers) {
    const labels = `provider="${escapeLabel(p.id)}"`;
    lines.push(`bizon_compute_provider_calls_total{${labels},outcome="calls"} ${p.calls}`);
    lines.push(`bizon_compute_provider_calls_total{${labels},outcome="errors"} ${p.errors}`);
    lines.push(`bizon_compute_provider_calls_total{${labels},outcome="fallbacks"} ${p.fallbacks}`);
  }

  // === v6.1: Scaling Controller (advisory: только рекомендации, HPA выключен) ===
  lines.push('# HELP bizon_scaling_status Scaling status: 0=normal, 1=elevated, 2=high_load, 3=degraded.');
  lines.push('# TYPE bizon_scaling_status gauge');
  lines.push(`bizon_scaling_status ${SCALING_STATUS_NUM[scaling.status] ?? 0}`);
  lines.push('# HELP bizon_scaling_recommendation Recommendation: 0=stable, 1=scale_up, 2=scale_down.');
  lines.push('# TYPE bizon_scaling_recommendation gauge');
  lines.push(`bizon_scaling_recommendation ${SCALING_REC_NUM[scaling.recommendation] ?? 0}`);
  lines.push('# HELP bizon_scaling_recommended_replicas Recommended replica count (advisory).');
  lines.push('# TYPE bizon_scaling_recommended_replicas gauge');
  lines.push(`bizon_scaling_recommended_replicas ${scaling.recommendedReplicas}`);
  lines.push('# HELP bizon_scaling_forecast_rps Predicted peak RPS (EMA/linear projection, advisory).');
  lines.push('# TYPE bizon_scaling_forecast_rps gauge');
  lines.push(`bizon_scaling_forecast_rps{horizon_min="${scaling.forecast.horizonMin}"} ${scaling.forecast.peakForecastRps}`);
  lines.push('# HELP bizon_scaling_utilization Peak forecast / capacity of current replicas.');
  lines.push('# TYPE bizon_scaling_utilization gauge');
  lines.push(`bizon_scaling_utilization ${scaling.capacity.utilization}`);

  // Service health
  lines.push('# HELP bizon_uptime_seconds Process uptime in seconds.');
  lines.push('# TYPE bizon_uptime_seconds gauge');
  lines.push(`bizon_uptime_seconds ${uptimeSeconds}`);

  lines.push('# HELP bizon_db_status Database status (1=ok, 0=error).');
  lines.push('# TYPE bizon_db_status gauge');
  lines.push(`bizon_db_status ${dbStatus === 'ok' ? 1 : 0}`);

  const body = lines.join('\n') + '\n';
  return new Response(body, {
    status: 200,
    headers: {
      'content-type': 'text/plain; version=0.0.4; charset=utf-8',
      'cache-control': 'no-store',
    },
  });
}
