// BizON API — /api/recommendations (W2.3, REC-PROJECT-02 / план v5 P2)
// POST — создать структурированную рекомендацию человека человеку.
//
// Принципы:
//   • нельзя рекомендовать себя (анти-коллюзия);
//   • основание ОБЯЗАТЕЛЬНО: «что конкретно сделал хорошо» — не пустая похвала;
//   • связь с проектом опциональна, но projectId принадлежит автору или субъекту
//     (существующее доказательство, не выдуманное);
//   • duplicate-защита: unique(authorId, subjectId, projectId).
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';
import { checkUserRateLimit } from '@/lib/security/rate-limiter';

export const runtime = 'nodejs';

const TYPES = new Set(['personal', 'professional', 'client']);

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const rl = checkUserRateLimit(user.id, 'recommendations:create', 10, 60 * 60_000);
  if (!rl.allowed) {
    return errorJson(`Слишком часто. Повторите через ${rl.retryAfter} секунд.`, 429);
  }

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== 'object') return errorJson('Некорректный JSON', 400);

  const subjectId = String((body as any).subjectId ?? '');
  const type = String((body as any).type ?? 'professional');
  const context = typeof (body as any).context === 'string' ? (body as any).context.slice(0, 300) : null;
  const text = String((body as any).text ?? '').trim();
  const skills: string[] = Array.isArray((body as any).skills)
    ? (body as any).skills.filter((s: unknown) => typeof s === 'string').slice(0, 10)
    : [];
  const projectId = typeof (body as any).projectId === 'string' && (body as any).projectId ? (body as any).projectId : null;

  if (!subjectId) return errorJson('subjectId обязателен', 422);
  if (!TYPES.has(type)) return errorJson('type: personal | professional | client', 422);
  if (text.length < 10) return errorJson('Укажите основание: что конкретно сделал хорошо (мин. 10 символов)', 422);
  if (text.length > 2000) return errorJson('text max 2000 символов', 422);

  // Анти-коллюзия №1: нельзя рекомендовать себя
  if (subjectId === user.id) return errorJson('Нельзя рекомендовать самого себя', 403);

  // Субъект существует
  const subject = await db.user.findUnique({ where: { id: subjectId }, select: { id: true, name: true } });
  if (!subject) return errorJson('Пользователь не найден', 404);

  // Evidence-связь: проект существует и relates к автору или субъекту
  let evidenceVerified = false;
  if (projectId) {
    const project = await db.project.findUnique({
      where: { id: projectId },
      select: {
        id: true,
        ownerId: true,
        clientStatus: true,
        members: { select: { userId: true } },
      },
    });
    if (!project) return errorJson('Проект не найден', 404);
    const isRelated =
      project.ownerId === user.id ||
      project.ownerId === subjectId ||
      project.members.some((m) => m.userId === user.id || m.userId === subjectId);
    if (!isRelated) return errorJson('Проект не связан с автором или рекомендуемым', 403);
    evidenceVerified = project.clientStatus === 'verified' || project.clientStatus === 'verified_with_changes';
  }

  try {
    const rec = await db.recommendation.create({
      data: {
        authorId: user.id,
        subjectId,
        type,
        context,
        text,
        skills: skills.join(','),
        projectId,
      },
    });
    // Уведомляем рекомендуемого
    await db.notification
      .create({
        data: {
          userId: subjectId,
          type: 'recommendation_received',
          title: 'Вас рекомендовали',
          content: `${user.name}: «${text.slice(0, 100)}${text.length > 100 ? '…' : ''}»`,
          link: '/profile',
        },
      })
      .catch(() => undefined);
    await db.auditLog
      .create({
        data: {
          actorId: user.id,
          action: 'recommendation_created',
          resource: 'user',
          resourceId: subjectId,
          metadata: JSON.stringify({ recommendationId: rec.id, type, projectId, evidenceVerified }),
        },
      })
      .catch(() => undefined);

    return json(
      {
        recommendation: rec,
        message: evidenceVerified
          ? 'Рекомендация создана и связана с подтверждённым проектом'
          : 'Рекомендация создана',
      },
      201,
    );
  } catch (e: any) {
    if (e?.code === 'P2002') {
      return errorJson('Вы уже рекомендовали этого пользователя в этом контексте', 409);
    }
    console.error('[recommendations/create] error:', e);
    return errorJson('Внутренняя ошибка сервера', 500);
  }
}
