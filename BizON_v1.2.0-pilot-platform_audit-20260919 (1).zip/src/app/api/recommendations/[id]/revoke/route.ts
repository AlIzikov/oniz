// BizON API — POST /api/recommendations/[id]/revoke (W2.3)
// Отзыв рекомендации. Отозвать может только автор. Recommendation остаётся
// в истории (status=revoked) — принцип честных данных: не удаляем факт,
// помечаем отзыв.
import { NextRequest } from 'next/server';
import { getUserFromRequest, json, errorJson } from '@/lib/api-helpers';
import { db } from '@/lib/db';

export const runtime = 'nodejs';

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUserFromRequest(req);
  if (!user) return errorJson('Не авторизован', 401);

  const { id } = await ctx.params;
  const rec = await db.recommendation.findUnique({ where: { id }, select: { id: true, authorId: true, status: true } });
  if (!rec) return errorJson('Рекомендация не найдена', 404);
  if (rec.authorId !== user.id) return errorJson('Отозвать может только автор', 403);
  if (rec.status === 'revoked') return json({ ok: true, message: 'Рекомендация уже отозвана' });

  await db.recommendation.update({
    where: { id },
    data: { status: 'revoked', revokedAt: new Date() },
  });
  await db.auditLog
    .create({
      data: {
        actorId: user.id,
        action: 'recommendation_revoked',
        resource: 'recommendation',
        resourceId: id,
        metadata: '{}',
      },
    })
    .catch(() => undefined);

  return json({ ok: true, message: 'Рекомендация отозвана' });
}
