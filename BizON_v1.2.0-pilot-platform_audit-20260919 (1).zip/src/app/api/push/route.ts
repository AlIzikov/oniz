// BizON API — /api/push (Wave 6, S-141, Web Push VAPID).
// POST — сохранить подписку браузера; DELETE — убрать; GET — статус VAPID
// (честно: configured=true/false; без ключей отправка недоступна).
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { withRoute } from '@/lib/with-route';
import { WebPushService } from '@/lib/services/web-push-service';

export const runtime = 'nodejs';

const subSchema = z.object({
  endpoint: z.string().url().max(1000),
  keys: z.object({ p256dh: z.string().min(10).max(300), auth: z.string().min(6).max(300) }),
});

export const GET = withRoute(async (req, ctx) => {
  return NextResponse.json({ vapidConfigured: WebPushService.vapidConfigured() });
});

export const POST = withRoute(async (req, ctx) => {
  const input = subSchema.parse(ctx.data);
  const result = await WebPushService.save(ctx.user.id, {
    endpoint: input.endpoint,
    keys: input.keys,
    userAgent: req.headers.get('user-agent') ?? undefined,
  });
  return NextResponse.json(result, { status: 201 });
}, {
  rateLimit: { key: 'push-subscribe', limit: 10, windowMs: 60 * 60 * 1000 },
});

export const DELETE = withRoute(async (req, ctx) => {
  const input = subSchema.pick({ endpoint: true }).parse(ctx.data);
  const result = await WebPushService.remove(ctx.user.id, input.endpoint);
  return NextResponse.json(result);
});
