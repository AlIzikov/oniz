// BizON — OG Image (динамический, через next/og)
// P2-2: превью при share в Telegram/Twitter/VK
import { ImageResponse } from 'next/og';

export const runtime = 'edge';
export const alt = 'BizON — профессиональная сеть доверия';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, #1e3a8a 0%, #059669 100%)',
          color: 'white',
          fontFamily: 'sans-serif',
        }}
      >
        <div style={{ display: 'flex', fontSize: 72, fontWeight: 800, marginBottom: 20 }}>
          <span style={{ color: '#93c5fd' }}>Biz</span>
          <span style={{ color: '#6ee7b7' }}>ON</span>
        </div>
        <div style={{ display: 'flex', fontSize: 42, fontWeight: 600, textAlign: 'center', maxWidth: 800, lineHeight: 1.3 }}>
          Не сеть контактов. Сеть доверия.
        </div>
        <div style={{ display: 'flex', fontSize: 24, color: 'rgba(255,255,255,0.7)', marginTop: 20 }}>
          AI-агенты · IP-score · Карьерные траектории
        </div>
      </div>
    ),
    { ...size }
  );
}
