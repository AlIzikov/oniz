'use client';

import * as React from 'react';
import { useAppStore } from '@/stores/app-store';
import { TrustStreamView } from '@/components/feed/trust-stream';
import { AppShell } from '@/components/shell/app-shell';
import { ProfileView } from '@/components/profile/profile-view';
import { MeView } from '@/components/me/me-view';
import { ProjectsView } from '@/components/projects/projects-view';
import { JobsView } from '@/components/jobs/jobs-view';
import { MatchmakerView } from '@/components/ai/matchmaker-view';
import { CareerAgentView } from '@/components/ai/career-agent-view';
import { NetworkView } from '@/components/network/network-view';
import { SettingsView } from '@/components/settings/settings-view';
import { SubscriptionView } from '@/components/settings/subscription-view';
import { CompaniesView } from '@/components/companies/companies-view';
import { CompanyView } from '@/components/companies/company-view';
import { CompanyDashboard } from '@/components/companies/company-dashboard';
import { EventsView } from '@/components/events/events-view';
import { CommunitiesView } from '@/components/communities/communities-view';
import { CommunityView } from '@/components/communities/community-view';
import { DashboardView } from '@/components/dashboard/dashboard-view';
import { MessagesView } from '@/components/messages/messages-view';
import { TrustGraphView } from '@/components/trust-graph/trust-graph-view';
import { NFTSkillsView } from '@/components/nft-skills/nft-skills-view';
import { DAOView } from '@/components/dao/dao-view';
import { MentorView } from '@/components/mentor/mentor-view';
import { TruthProfile } from '@/components/truth/truth-profile';
import { PublicationsView } from '@/components/publications/publications-view';
import { StoreView } from '@/components/store/store-view';
import { LoadingScreen } from '@/components/common/loading-screen';
import { DailyBrief } from '@/components/dashboard/daily-brief';
import { PredictiveFlow } from '@/components/dashboard/predictive-flow';
import { LandingPage } from '@/components/landing/landing-page';
import { useAppStore as useStore } from '@/stores/app-store';

// FIX-01: bypass «IS_DEV=true» удалён — реальная auth-состояние теперь
// определяется ТОЛЬКО сервером через GET /api/auth/me (bizon_session cookie).
// Неавторизованные видят LandingPage с рабочим входом (AuthScreen).
export default function Home() {
  const { user, view, _hasHydrated, setUser, profileUserId, setView } = useAppStore();
  const [bootstrapped, setBootstrapped] = React.useState(false);
  const [authCheckAttempted, setAuthCheckAttempted] = React.useState(false);
  // Deep-link ?view=jobs&jobId=... (Task 7-b): из поиска/карусели можно открыть вакансию напрямую
  const [deepLinkJobId, setDeepLinkJobId] = React.useState<string | null>(null);

  // 1. Ждём, пока persist восстановит view из localStorage
  React.useEffect(() => {
    const store = useStore as any;
    if (store.persist) {
      store.persist.rehydrate();
    }
  }, []);

  // 2. Когда hydration завершён — единственный источник правды: сервер.
  //    Всегда проверяем сессию через /api/auth/me (cookie отправляется
  //    автоматически, middleware может подставить demo-сессию при
  //    BIZON_DEMO_AUTH=1). 200 → показываем app; 401/ошибка → сбрасываем
  //    устаревшего persisted-пользователя и показываем login UI.
  React.useEffect(() => {
    if (!_hasHydrated) return;

    if (authCheckAttempted) {
      setBootstrapped(true);
      return;
    }

    setAuthCheckAttempted(true);
    // C5: cookie отправляется автоматически, без Bearer header
    fetch('/api/auth/me')
      .then((r) => (r.ok ? r.json() : Promise.reject(r)))
      .then((res) => setUser(res.user))
      .catch(() => {
        // Сессии нет (или истекла) — сбрасываем persisted-пользователя,
        // неавторизованным будет показан LandingPage → AuthScreen
        setUser(null);
      })
      .finally(() => setBootstrapped(true));
  }, [_hasHydrated, user, authCheckAttempted]);

  // Deep-link: ?view=jobs&jobId=... — при монтировании открываем раздел «Работа»
  // и детальный диалог вакансии (JobsView сам снимет флаг после обработки).
  React.useEffect(() => {
    if (!_hasHydrated) return; // после rehydrate, чтобы persist не затёр view
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('view') === 'jobs') {
        if (view !== 'jobs') setView('jobs');
        const jobId = params.get('jobId');
        if (jobId) setDeepLinkJobId(jobId);
      }
    } catch {
      // URL недоступен (нестандартное окружение) — deep-link просто не сработает
    }
  }, [_hasHydrated]);

  // Не рендерим ничего содержимого до полной инициализации
  if (!_hasHydrated || !bootstrapped) {
    return <LoadingScreen />;
  }

  // Неавторизованные → LandingPage (P1-1): внутри по кнопкам
  // «Войти»/«Начать бесплатно» открывается AuthScreen (email+пароль →
  // POST /api/auth/login → setUser → app).
  if (!user) {
    return <LandingPage />;
  }

  return (
    <AppShell>
      <DailyBrief />
      <PredictiveFlow />
      {view === 'dashboard' && (user.accountType === 'company' || user.accountType === 'hr_agency' ? <CompanyDashboard /> : <DashboardView />)}
      {view === 'feed' && <TrustStreamView />}
      {view === 'profile' && (profileUserId ? <ProfileView /> : <MeView />)}
      {view === 'me' && <MeView />}
      {view === 'projects' && <ProjectsView />}
      {view === 'jobs' && (
        <JobsView
          deepLinkJobId={deepLinkJobId}
          onDeepLinkHandled={() => setDeepLinkJobId(null)}
        />
      )}
      {view === 'matchmaker' && <MatchmakerView />}
      {view === 'career' && <CareerAgentView />}
      {view === 'network' && <NetworkView />}
      {view === 'subscription' && <SubscriptionView />}
      {view === 'companies' && <CompaniesView />}
      {view === 'company' && <CompanyView />}
      {view === 'events' && <EventsView />}
      {view === 'communities' && <CommunitiesView />}
      {view === 'community' && <CommunityView />}
      {view === 'messages' && <MessagesView />}
      {view === 'trust-graph' && <TrustGraphView />}
      {view === 'nft-skills' && <NFTSkillsView />}
      {view === 'dao' && <DAOView />}
      {view === 'settings' && <SettingsView />}
      {/* Phase 11 — Mentor Graph: кнопки «Найти наставника» (skill-graph-view, career-scenario-card) ведут сюда */}
      {view === 'mentor' && <MentorView />}
      {/* Этап 7.3 — Publications: соавторский долгоживущий контент */}
      {view === 'publications' && <PublicationsView />}
      {/* Wave 2 — Store MVP: витрина услуг/товаров с эскроу на люменах */}
      {view === 'store' && <StoreView />}
      {/* Truth Engine: «Не говори, кто ты. Докажи» — Claims/Proof/Truth Gap */}
      {view === 'truth' && <TruthProfile />}
    </AppShell>
  );
}
