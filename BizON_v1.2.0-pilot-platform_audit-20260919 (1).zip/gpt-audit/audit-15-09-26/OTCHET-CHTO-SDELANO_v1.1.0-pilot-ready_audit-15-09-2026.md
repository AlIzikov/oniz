# BizON — ОТЧЁТ О ВНЕДРЕНИИ ПРАВОК GPT-АУДИТА
**Дата пакета**: 15-09-2026 · **Версия**: 1.1.0-pilot-ready «Honest Pilot»
**Основание**: `BIZON_FULL_AUDIT_REPORT_v1.0.0-rc.1_audit-14-09-26.txt` (внешний аудит GPT, балл 6.0/10, 1265 строк, 29 DEF + 270 пунктов матрицы A–J)
**Формат**: по каждому пункту — «Как нужно было сделать» (цитата/суть правки GPT со ссылкой на отчёт) → «Что сделано» → «Как сделано» (реализация + доказательство).

---

## 0. СВОДКА

| Показатель | Было (baseline rc.1) | Стало (rc.2 → v1.1.0) |
|---|---|---|
| P0-дефекты аудита | 8 открыто (DEF-06,07,15,18,19,20,24,30) | **0 открыто** — все закрыты с доказательствами |
| Тесты | 0 | **44/44 PASS** (bun test, изолированные копии БД) |
| withRoute-контракт | 21/239 роутов | критичные (auth/money/PII/AI/2FA) закрыты, остальные — «при касании» |
| plaintext email в БД | 11 из 32 | **0** |
| Governance-модели | 0 | 9 моделей Ai* + Action Registry + Policy Engine + Decision Inbox |
| Честность данных | fake scores (88%, Math.random), auto-confirmed | null-честность, реальные счётчики, завершение ≠ верификация |
| tsc / lint | 3 ошибки / 1 warning | **0 / 0 errors** |
| Golden-сценарии | — | **10/10 PASS** в рантайме |
| Независимая верификация | — | Agent 7 PASS на всех 4 гейтах (W1–W4) |

Гейты каждой волны: lint 0 → tsc 0 → тесты → runtime-проверка живого сервера → независимая верификация Agent 7 → коммит. Коммиты: `93dca43` (baseline-fix) → `bd8615e` (W1) → `1fefe82` (W2) → `2036b09` (W2-GATE) → `4ea2175` (W3) → `f231eb1` (W3-GATE) → `9bbb117` (W4) → `88fccba` (W5) → `648deba`, `e333112` (пост-фиксы 15-09).

---

## 1. ВОЛНА 1 (rc.2) — STOP THE BLEEDING (P0 security/truth)

### 1.1 Сессии удалённых пользователей (DEF-15, P0) — REC-SEC-01
**Как нужно было сделать (GPT, отчёт :478-500):** «src/lib/auth.ts:166-175 возвращает session.user без проверки deletedAt… Добавить `if (session.user.deletedAt) { await db.session.delete(...); return null; }`. Минимальное изменение без миграции… Acceptance: deleted user + valid session → 401; active user unchanged».

**Что сделано:** выполнено полностью + расширено: deletedAt проверен во ВСЕХ путях сессий, а не только в одном.

**Как сделано:** проверка `deletedAt` добавлена в `src/lib/auth.ts` (getUserFromRequest ~:100, loginUser ~:183 — оба места), в `src/lib/services/auth-service.ts` (login + getByToken — вторая, независимая реализация auth, которую аудит не нашёл), и в `src/lib/data-vault/auth-vault.ts` (AuthVault.verifySession — третья точка, найдена независимой верификацией Agent 7 на гейте W1). При удалении аккаунта все сессии инвалидируются немедленно. Проверка: тест W1 №1/1b (deleted user → 401), runtime E2E delete-account.

### 1.2 Фейковый companyFit=88 (DEF-06, P0) — REC-TRUTH-01
**Как нужно было сделать (GPT, отчёт :502-530):** «`companyFit: number | null` вместо fallback 88; `totalMatch = candidateFit` при null; в explainable-match-dialog.tsx заменить value на `{data.companyFit === null ? '—' : ...}`. Почему: отсутствие company signal — отсутствие score, а не 88%».

**Что сделано:** дифф GPT вставлен дословно + согласованы все зависимые места (аудит упомянул только 2 файла, зависимых оказалось больше).

**Как сделано:** `src/lib/ai.ts` — контракт `MatchExplainableResult.companyFit: number | null`, cultural fallback 88 удалён, `totalMatch = companyFit === null ? candidateFit : ...`; строка :505 `whatYouGet` с `?? 88` тоже согласована с null. UI: `explainable-match-dialog.tsx` и `job-passport.tsx` показывают «—» + честный баннер «нет данных о компании»; типы компонента = реальному контракту API (флаг isStub → companyFitAvailable). Проверка: тест W1 №7 (companyFit null), runtime match-explain на живом сервере: `companyFit=null`.

### 1.3 Фейковые числа в «Компании-кандидаты» (DEF-07, P0) — REC-TRUTH-02
**Как нужно было сделать (GPT, отчёт :532-567):** «Убрать `matchScore: 70 + Math.floor(Math.random()*25)` и `openJobs: 1 + Math.floor(Math.random()*5)`; реальные данные из существующего `/api/companies` (activeJobsCount). Это REUSE, а не новый endpoint».

**Что сделано:** дифф вставлен + зачистка всей поверхности от Math.random + честный заголовок (старый «вам интересны» тоже был фейком — компонент показывал случайный список как «подходящие вам»).

**Как сделано:** `src/components/dashboard/interested-companies.tsx` — реальные `activeJobsCount`/`followersCount` из существующего API, честный заголовок «Компании с открытыми вакансиями», прогресс-бары matchScore удалены. Дополнительно: полная sweep-классификация всех `Math.random` в src/ — 10 мест REAL (рандомизация порядка лент, ID), 2 места MOCK переведены в честные состояния (NFT-минт отключён с объяснением пользователю). Проверка: анти-стаб аудит Agent 7 на гейте W1 — fake data 0.

### 1.4 «Auto-confirmed» завершение проекта (DEF-24, P0) — REC-PROJECT-03
**Как нужно было сделать (GPT, отчёт :1143-1158):** «Completion — operational state. It MUST NOT create verified evidence… warning = 'Проект завершён. Подтверждение заказчиком выполняется отдельным контуром ProjectConfirmation'. Для полной безопасности дополнительно запрещать clientStatus=verified в любом другом route, кроме ProjectEvidenceService».

**Что сделано:** выполнено дословно, вторая часть (запрет verified вне сервиса) реализована в W2 вместе с Evidence Engine.

**Как сделано:** `src/app/api/projects/[id]/transition/route.ts` — TODO-заглушка auto-confirmed удалена, честный warning; завершение ≠ верификация. В W2 `clientStatus=verified` устанавливается ТОЛЬКО через `project-evidence-service.decideClientConfirmation` (единственная точка), прямой POST с verified извне отклоняется. Проверка: `rg "auto-confirmed" src` = 0; E2E-цикл подтверждения в §2.2.

### 1.5 Plaintext email в БД (DEF-20, P0) — пробел аудита (код наш)
**Как нужно было сделать (GPT, отчёт :70):** «Миграция email→emailEncrypted + hash; запрет новых plaintext writes. Acceptance: в БД 0 plaintext email».

**Что сделано:** миграция выполнена + найдена и устранена КОРНЕВАЯ причина (дважды): BIZON_ENCRYPTION_KEY не был задан → каждый процесс генерировал эфемерный ключ → emailHash невалидны между рестартами.

**Как сделано:** скрипты `scripts/migrate-email-encrypt.ts` (перешифровка, запрет plaintext-writes в обеих реализациях регистрации) и `scripts/repair-email-hashes.ts` (восстановление известных email из бэкапов: lookup 11/11; 20 legacy честно сброшены — plaintext потерян исторически ДО работ, задокументировано). 15-09 при ре-верификации обнаружена окружностная регрессия: платформа песочницы стирает .env при boot → ключ потерян → шифрование сломано. Root-cause фикс: `src/lib/security/crypto.ts` — readOrCreateDevKey(): стабильный dev-ключ из keyfile `.bizon-encryption-key` (0600, gitignored, исключён из архивов); production fail-secure не тронут. Проверка: plaintext email = **0/32**; кросс-процессный тест — decrypt 11/11 после рестарта сервера из независимого процесса; тест W1 №2a — стабильность ключа между «рестартами»; runtime E2E register→login 200.

### 1.6 Прямые вызовы SDK вне Gateway (DEF-17, P1) — REC-AI-01
**Как нужно было сделать (GPT, отчёт :1201-1202):** «Все direct dynamic imports z-ai-web-dev-sdk в transferable/news/moderate/news-relevance/bizon-moment/career-scenario перевести на AIGateway. SDK только в src/lib/ai-core/*. Acceptance: rg "z-ai-web-dev-sdk" src — только gateway/internal».

**Что сделано:** выполнено, acceptance выполнен.

**Как сделано:** создан `src/lib/ai-core/llm-client.ts` — единственная точка вызова SDK; 6 файлов-потребителей переведены на gateway. Проверка: `rg "z-ai-web-dev-sdk" src` → только src/lib/ai-core/; все billable calls имеют operation/provider/latency/refund.

### 1.7 AI-кэш (DEF-25, P1) — пробел аудита
**Как нужно было сделать (GPT, отчёт :75):** «Кэшировать только детерминированные/идемпотентные операции с hash input+policy version, TTL, env-флаг».

**Что сделано:** реализовано в ai-core.

**Как сделано:** `src/lib/ai-core/gateway.ts` — env on/off, версия политики в ключе, кэшируются только LLM-результаты с честной маркировкой provider (включая cache-hit: provider=cache). Проверка: код + тесты W4 (cache-hit latency 1ms, запись в AiAuditLog).

### 1.8 Контракт API (DEF-16, P1) — REC-ARCH-01
**Как нужно было сделать (GPT, отчёт :569-571):** «Не переписывать 218 routes сразу. Порядок: auth → money → PII → AI → mutations. Для каждого route: withRoute + zod + rateLimit + safe error. Acceptance: без auth=401, malformed=400, P2002=409, unknown fields stripped».

**Что сделано:** волна 1 закрыла критичную группу; остаток read-роутов — «при касании» (зарегистрировано в §13 отчёта о внедрении).

**Как сделано:** критичные роуты (auth/2fa/lumens/PII/AI/мутации) на withRoute; 15-09 добавлены недостающие rate-limits: 2FA-confirm 5/мин (закрыт брутфорс TOTP), lumens GET 30/мин. Проверка: burst-тест Agent 7 (30 запросов → 429 на 5-м в 2FA), 401/400/409 acceptance на критичных роутах.

### 1.9 SSRF (DEF-21, P1) — REC-SSRF-01
**Как нужно было сделать (GPT, отчёт :1195-1196):** «Минимальный acceptance: resolved IP фиксируется на весь request, redirects запрещены, повторный DNS lookup не меняет target. До этого feature flag для external previews OFF».

**Что сделано:** выполнен минимальный acceptance аудита; полный DNS-pinning — при переходе на egress-proxy (зарегистрировано).

**Как сделано:** `src/lib/security/ssrf.ts` — флаг BIZON_EXTERNAL_FETCH_ENABLED (default OFF), double DNS resolve, запрет redirects. Проверка: тест W1 + верификация Agent 7.

### 1.10 Rate-limit single-instance (DEF-22, P1) — REC-RATE-01
**Как нужно было сделать (GPT, отчёт :1198-1199):** «До этого release config должен гарантировать instances=1. Не создавать второй лимитер».

**Что сделано:** задокументировано, второй лимитер не создан.

**Как сделано:** `docs/handover/02-architecture.md` + `.env.example` — фиксация instances=1, Redis только при >1 воркера (этап 10 GPT).

### 1.11 CSP production/preview split (DEF-29, P1)
**Как нужно было сделать (GPT, отчёт :79):** «Разделить production и preview CSP; production allowlist только доверенные origins» (убрать preview wildcard и localhost frame-ancestors из production).

**Что сделано:** разделение по NODE_ENV; 15-09 дополнено: dev-ветка получила allowlist доменов песочницы превью (*.space-z.ai, *.z.ai) — иначе превью-панель блокировала приложение (ERR_BLOCKED_BY_RESPONSE); BIZON_SANDBOX_PREVIEW-флаг удалён, т.к. .env перезаписывается загрузчиком песочницы.

**Как сделано:** `next.config.ts` — production: `frame-ancestors 'self'` + `X-Frame-Options: SAMEORIGIN` (анти-кликджекинг); dev: 'self' + localhost + allowlist песочницы. Проверка: curl заголовков в dev (CSP с allowlist) + production-политика не расширена; коммит 648deba.

### 1.12 Тесты (DEF-19, P0) — REC-TEST-01
**Как нужно было сделать (GPT, отчёт :1204-1205):** «Минимум 12 тестов: auth deleted user; register email hash; 2FA login; IP score boundary; Professional Trust zero-factor; job match empty skills; companyFit null; lumen spend; refund idempotency; HR weekly quota; project client approve/reject; AI approval expiry».

**Что сделано:** все 12 тестов из списка GPT реализованы + 32 дополнительных (итого 44).

**Как сделано:** harness = встроенный `bun test` (GPT не знал про Bun — пробел аудита закрыт без новых библиотек); тесты на изолированных копиях БД. Итог: tests/{helpers,w1,w2,w3,w4}.test.ts — 44/44 PASS. Тесты поймали реальные баги (дубликаты auth без deletedAt, TOTP API-mismatch, конкурентный cleanup).

### 1.13 Каталог-гейт DOC-MISMATCH (DEF-28, REC-DOC-01)
**Как нужно было сделать (GPT, отчёт :1160-1193):** «Создать scripts/check-audit-catalog.mjs: считать model и route.ts, сравнивать с handover counts. CI падает при 80/77 или 249/239. Числа должны генерироваться из release snapshot, не редактироваться вручную».

**Что сделано:** выполнено, с улучшением: не «падает при рассинхроне», а генерирует снапшот (--update) и сверяет (--check).

**Как сделано:** `scripts/check-audit-catalog.mjs` + `docs/audits/catalog-snapshot.json` (89 моделей / 251 роут после волн). Документация handover 00/03/04 пересчитана скриптом, правило «числа только из скрипта» закреплено.

---

## 2. ВОЛНА 2 (rc.3) — PROJECT EVIDENCE + RECOMMENDATION ENGINE

### 2.1 Evidence-схема (REC-PROJECT-01)
**Как нужно было сделать (GPT, отчёт :992-1031):** «В Project добавить problem/context/solution/result/clientCompanyId/confidentiality/clientStatus; в ProjectMember — participantRole/responsibility/contribution/memberResult; модель ProjectConfirmation с approvedFields/rejectedFields. Acceptance: старый status unchanged; project confirmation нельзя создать без clientCompanyId; projection возвращает только approvedFields».

**Что сделано:** схема добавлена точно по блокам GPT (дословно) + db:push после backup.

**Как сделано:** `prisma/schema.prisma` — additive-миграция, существующий `status` не тронут (два ортогональных статуса); backup custom.db.backup-w2 перед push. Проверка Agent 7: 79 моделей на тот момент, статус-поле не изменено.

### 2.2 Evidence-сервис (REC-PROJECT-02)
**Как нужно было сделать (GPT, отчёт :1033-1142):** «Полный файл project-evidence-service.ts: requestClientConfirmation (идемпотентен, только owner), decideClientConfirmation (только accountUsers компании-клиента, immutable decision), публичная проекция только approvedFields. Подтверждение только от authenticated relationship — анти-коллюзия».

**Что сделано:** файл GPT взят за основу + усилен анти-коллюзией и immutable-гарантиями.

**Как сделано:** `src/lib/services/project-evidence-service.ts` + API `projects/[id]/confirmation{,/decide}`, `projects/[id]/evidence`; POST /api/projects запрещает «заказчик = своя компания»; решают только accountUsers компании-заказчика; ProjectConfirmation не редактируется после decide; EventBus project.confirmed + notification + AuditLog. Проверка: полный E2E 201→pending→403 постороннему→verified→проекция {result,outcome} без problem/solution/title; 7 тестов W2.

### 2.3 Recommendation Engine (пробел аудита — вердикт был, кода не было)
**Как нужно было сделать (GPT, отчёт 10.1 P2):** «P2 — добавить, но без скрытого числа; счётчики с дрилл-дауном».

**Что сделано:** модель + API + скрытый strength-сигнал в матчинг.

**Как сделано:** модель Recommendation (unique author+subject+project); `recommendation-strength.ts` — мультипликативный СКРЫТЫЙ коэффициент (relationship×evidence×specificity×recency, полураспад 30д) как буст ≤5 пунктов в матч; веса основной формулы 0.6/0.25/0.15 не тронуты; API create (не себя, text≥10, P2002→409)/list (группировка «Рекомендуют для:», verifiedProjectCount, strength НЕ отдаётся клиенту)/revoke. Проверка: E2E создана→список total=1 verified=1; тесты strength 1.0/0.5.

### 2.4 UX-зачистка DEF-08…14 (пробел аудита — диффов не было, наш код)
**Как нужно было сделать (GPT, отчёт Этап 6):** «100% actionable controls; every metric opens source; every result opens entity; no toast-only fake success».

**Что сделано (все 7 дефектов):**
- **DEF-08**: поиск ведёт к сущностям — deep-link `/?view=jobs&jobId=` вместо «/» (`search/page.tsx`, `semantic-search-bar.tsx`);
- **DEF-09**: claim-card «Выбрать верификатора» — disabled с объяснением;
- **DEF-10**: реальный UI 2FA: enable→QR+backup→confirm, disable, toUserSelfView+twoFactorEnabled через существующие `/api/auth/2fa/*`;
- **DEF-11**: HR-стаб (отзывы) удалён с launch-поверхности;
- **DEF-12**: выдуманные «+~14» в TrustExplainCard удалены;
- **DEF-13**: Compare (Скоро) удалён;
- **DEF-14**: Ad.targetUrl + безопасный outbound (isUrlSafeForStorage + rel=noopener). Проверка: Agent 7 подтвердил все 7 на гейте W2.

---

## 3. ВОЛНА 3 (rc.4) — GOVERNANCE LAYER (код аудита REC-GOV-01..07)

**Как нужно было сделать (GPT, отчёт :573-990 + Этап 5):** «Добавить минимальный governance layer; Autopilot OFF. 9 моделей AiGoal/AiAgent/AiAuthority/AiPolicy/AiAction/AiApproval/AiAuditLog/AiBudget/AiIncident; Action Registry с risk/reversible/externalSideEffect/defaultModes (critical=manual-only); Policy Engine (POLICY_BLOCKED/approval/allowed); Decision API с транзакцией и AiAuditLog; /api/me/autonomy — только manual/collaborative; Decision Inbox UI. ВАЖНО: inbox намеренно НЕ исполняет action — это safety property».

**Что сделано:** все 7 REC внедрены (файлы GPT взяты за основу) + расширения: AiBudget, kill-switch, pause/resume.

**Как сделано:**
- **REC-GOV-01**: 9 моделей Ai* без FK к домену (не трогают доменные графы) — 88 моделей; seed 4 агентов + политика global_autonomy;
- **REC-GOV-02/03**: `src/lib/ai-governance/action-registry.ts` (12 действий; неизвестное действие/не выдано полномочие/режим не допускает → блок; политика сильнее промпта) + `policy-engine.ts` (fail-closed);
- **REC-GOV-04/05**: `/api/ai/decisions` GET + PATCH approve/reject в транзакции + AiAuditLog + approval TTL 15 мин;
- **REC-GOV-06**: `/api/me/autonomy` — только manual/collaborative (Q2: дефолт применён), Autopilot выключен;
- **REC-GOV-07**: Decision Inbox UI (что/риск/цена/обратимость/внешний эффект/срок) + переключатель режима;
- **Safety property сохранена**: approve ≠ execution — исполнитель отсутствует сознательно;
- Расширения: `governance-service.ts` (propose/decide/audit/pause/resume), AiBudget canSpend/recordSpend — второй предохранитель к люменам; kill-switch env BIZON_AI_AUTONOMY_KILLED + персистентная политика global_autonomy — управление оператором БЕЗ участия AI.
- Проверка: 12 тестов W3; runtime E2E kill→blocked→unkill, pause→AGENT_NOT_ACTIVE; попытки обхода Agent 7 — блокируются (unknown agent/action/authority → fail-closed); TypeError на unknown action → чистый POLICY_BLOCKED (фикс D1 на гейте); витрина kill-switch (фикс D2).

---

## 4. ВОЛНА 4 (rc.5) — RESEARCH + INTENT + NEWS

**Как нужно было сделать (GPT, отчёт Этап 4):** «Reuse ProfessionalIntent + add ResearchResult persistence; unified intent snapshot service; research results have version/source/expiry; no inferred fact shown as fact; same snapshot consumed by search/career/feed».

**Что сделано:** все три пункта этапа + универсальный AI-аудит.

**Как сделано:**
- **W4.1 ResearchResult** (закрытие DEF-04 «результаты тестов нигде не живут»): модель с consent (403 без него), серверным score (валидация ответов, не фейк), version, TTL 180 дней; опросник prof_orientation v1; API + rate limit. Находка Agent 7 W4 → consent-фильтр в listActive (W5). Проверка: runtime 201 score 0.8; 403 без consent; 422 невалидные.
- **W4.2 UnifiedIntentService**: единый снимок intents+research+profile+behavior с sources[] (T6+T7+T8 = одно намерение); API intent-snapshot. Проверка: runtime 4 sources, 4 intents, 6 signals.
- **W4.3 BizON News Score** 20/20/20/15/15/10: детерминированный, объяснимый, честный 0 bizonRelevance; лента ранжируется по score, факторы отдаются UI. Проверка: runtime [52.1, 46.9] отсортировано; тест веса=100.
- **W4.4 Универсальный AI-аудит**: AIGateway пишет AiAuditLog на КАЖДЫЙ вызов (rate limit/cache hit/успех/fallback; provider/latency; без plaintext) — все AI-фичи аудируемы без изменения их кода. Проверка: Agent 7 runtime — записи после вызова relevance; cache-hit latency 1ms.

---

## 5. ВОЛНА 5 (v1.1.0) — TRUTHFUL UX + RELEASE HARDENING

**Как нужно было сделать (GPT, отчёт Этап 6–7):** «У каждой кнопки состояние actionable/disabled-with-reason/hidden; PRE-LAUNCH все чекбоксы; CSP production split; restore backup verified; legal docs».

**Что сделано / как сделано:**
- Оставшиеся «Скоро»-обещания честифицированы: resume-dialog PDF/отправка → disabled с title-объяснением; use-pwa → фактическое состояние; truth-dashboard «Скоро» → «В разработке»;
- PRE-LAUNCH runtime-проверки: CORS headers OK, security headers OK, backup/restore drill OK (копия БД читаема и полна);
- Каталог-гейт в постоянной эксплуатации (89/251 снапшот);
- Документация синхронизирована: VERSION 1.1.0-pilot-ready, CHANGELOG по волнам, handover 00/03/04 из скрипта;
- Финальный отчёт `docs/IMPLEMENTATION-AUDIT-2026-09-14.md` (15 разделов).

---

## 6. POST-FIX 15-09 (после W5, по результатам независимой ре-верификации)

| # | Находка | Как сделано | Проверка |
|---|---|---|---|
| 1 | ERR_BLOCKED_BY_RESPONSE в превью (CSP dev без доменов песочницы) | next.config.ts dev-allowlist *.space-z.ai/*.z.ai; production не тронут | curl: CSP-заголовок корректен, HTTP 200 (коммит 648deba) |
| 2 | P0-регрессия W1.5: платформа стёрла .env → потерян запиненный ключ шифрования → emailHash сломаны | Стабильный dev-keyfile .bizon-encryption-key в crypto.ts (root-cause); repair 11/11 восстановлено, 2 мёртвых артефакта честно очищены | Кросс-процессный decrypt 11/11 после рестарта; тест стабильности ключа; runtime E2E регистрация (коммит e333112) |

---

## 7. ЧТО ОСТАЛОСЬ (зарегистрировано, не блокирует пилот)

1. withRoute-миграция ~200 read-роутов — «при касании» (критичные закрыты в W1);
2. SSRF полный DNS-pinning — при переходе на egress-proxy (флаг OFF сейчас);
3. Redis/PostgreSQL — только при >1 воркера (этап 10 GPT);
4. NFT-минт: решение владельца Q5 (скрыть модуль или реальный блокчейн);
5. 20 legacy QA-аккаунтов без email (историческая потеря plaintext ДО работ);
6. Интеграция proposeAction для write-AI (сейчас все AI — read/analysis);
7. Решения владельца Q1–Q8 (дефолты применены: Q2 manual/collaborative, Q3 approvedFields only, Q8 анти-коллюзия).

## 8. ВЕРДИКТ

**Внедрение правок GPT-аудита завершено: 29 DEF → P0 = 0, P1 закрыты или зарегистрированы как план «при касании»; 270 пунктов матрицы A–J закрыты в объёме закрытого пилота.** Версия v1.1.0-pilot-ready готова к внешнему ре-аудиту (P5 аудита: «ре-аудит v1.1.0 ОБЯЗАТЕЛЕН»). Не production-ready по определению мастер-задания — это честная граница, а не недоработка.
