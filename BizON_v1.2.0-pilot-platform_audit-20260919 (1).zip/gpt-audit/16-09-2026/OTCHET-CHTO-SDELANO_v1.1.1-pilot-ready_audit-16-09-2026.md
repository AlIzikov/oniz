# BizON — ОТЧЁТ «ЧТО ТРЕБОВАЛОСЬ → ЧТО СДЕЛАНО» (ре-аудит-2)
**Дата пакета**: 16-09-2026 · **Версия**: 1.1.1-pilot-ready «Honest Pilot»
**Основание**: `BIZON_FULL_AUDIT_REPORT_v1.0.0-rc.1_audit-14-09-26.txt` (внешний аудит GPT, балл 6.0/10, 29 DEF + гейты 7.1 + REC-матрица). Хронология проверок: аудит 14-09 → правки 15-09 (v1.1.0) → **независимая ре-сверка 15-09** (23 FIXED / 4 PARTIAL / 2 NOT FIXED) → **дозакрытие + стабилизация 16-09 (v1.1.1, этот пакет)**.
**Формат**: по каждому пункту — «Что требовалось» (суть требования GPT со ссылкой на его отчёт) → «Что сделано» → «Доказательство» (file:line из кода архива + команды + рантайм-результаты). Правило пакета: **никаких «OK» без доказательств**.

---

## 0. СВОДКА

| Показатель | Ре-аудит 15-09 | Стало (16-09, v1.1.1) |
|---|---|---|
| DEF из отчёта GPT 14-09 | 23 FIXED / 4 PARTIAL (12, 16, 21, 30) / 2 NOT FIXED (05, 23-вых) | **26 закрыты полностью; 4 остатка документированы** (DEF-16 полный охват, DEF-21, DEF-27-runtime, DEF-30) — все вне песочницы/поэтапные, см. §6 |
| Тесты | 79 (обнаружен флак: 1 падение из 2 прогонов) | **79/79 PASS × 5 прогонов подряд** — флак устранён (root cause §2) |
| tsc / lint | 0 / 0 | **0 / 0** |
| Каталог-гейт (модели/роуты vs docs) | OK 90/252 | **OK 90/252** (`node scripts/check-audit-catalog.mjs`) |
| PII-гейт (H13) | НЕ верифицирован | **MUST-AUDIT 10/10 с AuditLog** (`node scripts/pii-inventory.mjs`) |
| Rate-limit (H11) | lumens/ai/career без явного лимита | **live-проверено: 35 запросов → ровно 30×200 + 5×429** |
| Next Best Action (DEF-12) | хардкод-массив | **live: `{"action":"create_project","title":"Создайте первый проект"}`** из реального сервиса |
| Outbox (DEF-23) | отсутствует | **EventOutbox + emitDurable + drainOutbox + 3 теста** |
| Браузер | — | лендинг + дашборд рендерятся, Trust 0/100 «честно нулевая», консоль без ошибок |

---

## 1. ДОЗАКРЫТО 15→16 СЕНТЯБРЯ (по итогам ре-сверки 15-09)

### 1.1 DEF-05 (P1, DOC-MISMATCH) — Follow описан в docs, но не существует
**Что требовалось (GPT, DEF-05):** документация не должна описывать несуществующие сущности как готовые: «Follow упоминается как модель, но отсутствует в Prisma; фактическая follow-сущность не соответствует описанию».

**Что сделано:** ложные статусы заменены на честные; Follow не создаётся (решение аудита: не вводить сущность без product need — социальные связи закрывают Connection и CompanyFollower).

**Доказательство:** `docs/handover/04-api-catalog.md:141` — «~~POST/DELETE/GET /api/follows~~ — **НЕ РЕАЛИЗОВАНО** (исправлено W2.5, DEF-05): модель Follow в Prisma-схеме отсутствует, route `/api/follows` не существует…»; `docs/handover/03-data-model.md:166-169` — раздел «Follow — НЕ РЕАЛИЗОВАНО» с правилом синхронного создания модели+доков в будущем. Follow убран из списков каскадов/индексов. Ре-верифицировано 16-09 чтением обоих файлов.

### 1.2 DEF-12 (P2, UX) — заглушка Next Best Actions в TrustExplainCard
**Что требовалось (GPT, DEF-12):** «TrustExplainCard содержит вложенную заглушку Next Best Actions» — блок «Как повысить?» не должен показывать статичный список, не связанный с данными.

**Что сделано:** хардкод-массив NEXT_BEST_ACTIONS удалён; вместо него — реальный сервис рекомендаций следующего действия.

**Доказательство:**
- `src/components/truth/trust-explain-card.tsx:122-124` — комментарий «статичная заглушка Next Best Actions удалена»; `:343-355` — Collapsible «Как повысить?» рендерит `<NextBestActionCard />`, который сам фетчит `GET /api/me/next-best-action`.
- Роут существует: `src/app/api/me/next-best-action/route.ts`; источник — `src/lib/services/next-best-action-service.ts`.
- **Live (curl, 16-09):** ответ `{"action":{"action":"create_project","title":"Создайте первый проект","description":"Проекты — это доказательства ваших навыков…"}}` — реальный расчёт по состоянию пользователя.
- **Live (браузер, 16-09):** дашборд тест-юзера рендерит секцию «Что делать следующее → лучшее действие» с карточкой «Создайте первый проект» и кнопкой «Выполнить».

### 1.3 DEF-23 (P1, ARCH) — event bus in-process, события теряются при рестарте
**Что требовалось (GPT, DEF-23):** «Event bus in-process — события теряются при restart/горизонтальном scale. Для критичных событий использовать outbox; event bus оставить для local notifications».

**Что сделано:** Transactional Outbox по каноническому паттерну: persist → publish → drain; семантика at-least-once.

**Доказательство:**
- `prisma/schema.prisma:2120` — модель `EventOutbox` (event, payload, status pending/published, attempts, lastError, publishedAt).
- `src/lib/event-bus/outbox.ts:37-81` — `emitDurable()`: (1) строка persisted в БД (durable-точка, при сбое БД издатель получает ошибку — событие не теряется молча); (2) публикация в локальную шину; если шина упала — строка остаётся pending. `:93-125` — `drainOutbox(limit)`: переигрывание pending после рестарта, счётчики republished/failed, идемпотентность обработчиков обязательна (at-least-once).
- `DURABLE_EVENTS` (outbox.ts:28-31): `project.completed`, `project.confirmed` — деньги/trust-события.
- Проводка в реальных флоу: `src/app/api/projects/[id]/transition/route.ts:189` (`project.completed`), `src/lib/services/project-evidence-service.ts:209` (`project.confirmed`).
- Тесты: `tests/outbox.test.ts` — 3 теста (в общем suite 79/79).

### 1.4 H11 (P0/P1, гейт 7.1) — «нельзя оставлять ~200 endpoints "при касании"»
**Что требовалось (GPT, гейт 7.1 :461):** «H11 mutation rate limit → нельзя оставлять ~200 endpoints "при касании". P0 для auth/money/PII/write, P1 для остального».

**Что сделано:** все критичные классы (auth, 2FA, money, AI, необратимые PII-операции) под явными лимитами на KV-лимитере (DEF-22: Redis-swappable).

**Доказательство:**
- `src/app/api/lumens/route.ts:18-25` — withRoute + `checkUserRateLimit(user.id, 'lumens:wallet', 30, 60_000)` (лимит на ЧТЕНИЕ — чтение начисляет дивиденды, т.е. это write-эффект).
- `src/app/api/ai/career/route.ts:13-18` — тарифный лимит `getAiLimitKey('career', user.subscriptionTier)`.
- Полная карта лимитов (w2.5): auth/login+register 10/мин + backoff 1с→15мин; 2fa enable/confirm/disable/verify 5/мин; lumens 30/мин и accrue 10/мин; delete-account 3/10мин; forget-me 3/час.
- **Live-проверка 16-09:** 35 последовательных GET `/api/lumens` (валидная сессия) → HTTP-коды: **30×200, затем 5×429** — лимит работает с точностью до запроса.

### 1.5 H13 (гейт 7.1) — «inventory all PII routes»
**Что требовалось (GPT, гейт 7.1 :462):** «H13 PII AuditLog coverage → inventory all PII routes».

**Что сделано:** автоматизированный инвентаризационный гейт + закрытие найденных пробелов.

**Доказательство:**
- `scripts/pii-inventory.mjs` — сканирует 252 роута, классифицирует PII-маркеры, сверяет с снапшотом `docs/audits/pii-routes-inventory.json`, проверяет AuditLog-покрытие MUST-AUDIT-классов.
- **Результат 16-09:** «H13 PII inventory: 39/252 routes помечены как PII; MUST-AUDIT маршрутов: 10, без AuditLog: 0 → OK».
- По результатам гейта добавлены AuditLog-записи в `2fa/enable` (start+enabled) и `2fa/disable` (+confirm) — пробелы найдены машиной, а не человеком.

### 1.6 DEF-16 (P1) — withRoute: критичные классы закрыты
**Что требовалось (GPT, DEF-16 + REC-ARCH-01):** «Не переписывать все routes сразу. Порядок: auth → money → PII → AI → mutations. Для каждого route: withRoute + zod + rateLimit + safe error. Acceptance: без auth=401, malformed=400, P2002=409, unknown fields stripped».

**Что сделано:** мигрированы критичные классы по предписанному порядку.

**Доказательство:** 15 файлов переведены на withRoute+zod+rate-limit (w2.5): `auth/login`, `auth/register` (схема расширена опц. полями), `auth/logout` (+исправлен регресс: при auth:false явный `getUserFromRequest`), `auth/me`, `auth/verify-email`, `2fa/enable|confirm|disable|verify`, `lumens`, `lumens/accrue`, `ai/decisions` (+`[id]`), `me/delete-account`, `me/forget-me`. Итого 28/252 файлов на withRoute; остальные read-роуты покрыты errorJson (241/252) — полный охват честно числится поэтапным остатком (§6). Live-контракт проверен curl'ом 15-09: malformed JSON→400; unknown fields (`isAdmin`) вырезаются; register→200; P2002→409.

---

## 2. СТАБИЛИЗАЦИЯ 16-09: УСТРАНЁН ФЛАК ТЕСТОВ (новое, не из отчёта GPT)

**Симптом:** первый полный прогон 16-09 дал 78/79 — недетерминированно падал тест W3 «kill-switch в AIGateway: LLM не вызывается»; в изоляции файл проходил 15/15.

**Root cause (установлен по коду):** `tests/helpers/setup.ts` не изолировал ФОНОВУЮ AI-активность: события из w1/w2 (`user.registered`, `skill.verified`, …) запускали AI-подписчиков EventBus → `BizonAICore.onEvent` → **реальные вызовы z-ai-web-dev-sdk** (`src/lib/ai-core/index.ts:145-146`) → они проходят через ОБЩИЙ для процесса backpressure-очередь (`AI_LLM_QUEUE`, maxConcurrent=4, policy=reject) и circuit breaker `'zai-llm-fast'` (`src/lib/ai-core/gateway.ts:97-102, 309-312`) → в момент alive-фазы kill-switch теста мок-LLM-вызов отклонялся очередью/breaker'ом → gateway честно уходил в fallback → `provider='heuristic'` вместо `'llm'`.

**Что сделано:**
- `src/lib/event-bus/subscribers.ts:212-224` — env-gate `BIZON_AI_INSIGHTS`: `=0` отключает регистрацию фоновых AI-подписчиков (в проде по умолчанию ВКЛЮЧЕНЫ — продуктовое поведение не изменено); лог регистрации честно сообщает «ai-insight events ОТКЛЮЧЕНЫ: BIZON_AI_INSIGHTS=0».
- `tests/helpers/setup.ts:18` — `process.env.BIZON_AI_INSIGHTS = '0'` до импорта src-модулей.
- Проверено, что ни один тест не зависит от фоновых инсайтов (`grep onEvent|BizonAICore|insight tests/` → 0 совпадений).

**Доказательство:** 5 подряд прогонов `bun test tests/` → **79 pass / 0 fail** (346 expect) каждый.

---

## 3. ПОЛНАЯ ТАБЛИЦА 30 DEF — СТАТУС НА 16-09

| DEF | Суть (по отчёту GPT) | Статус | Доказательство (ключевое) |
|---|---|---|---|
| 01 | DOC-MISMATCH: моделей 80 vs 77 | ЗАКРЫТ | каталог-гейт: docs ↔ schema 90/90 OK |
| 02 | DOC-MISMATCH: роутов 249 vs 239 | ЗАКРЫТ | каталог-гейт: docs ↔ 252 роута OK |
| 03 | ProjectConfirmation отсутствует в schema | ЗАКРЫТ | `schema.prisma:1883` + Evidence Engine |
| 04 | ResearchResult отсутствует в schema | ЗАКРЫТ | `schema.prisma:2093` |
| 05 | Follow описан как существующий | **ЗАКРЫТ (16-09)** | `04-api-catalog.md:141`, `03-data-model.md:166-169` — «НЕ РЕАЛИЗОВАНО» |
| 06 | companyFit fallback=88 | ЗАКРЫТ | `src/lib/ai.ts:352-353, 466-471` — `number \| null` |
| 07 | Math.random в InterestedCompanies | ЗАКРЫТ | `interested-companies.tsx:3-5,41-45` — реальные activeJobsCount |
| 08 | Поиск ведёт на `/`, не на сущность | ЗАКРЫТ | `search/page.tsx:127-143` — openEntity + deep-link `/?view=jobs&jobId=` |
| 09 | Выбор верификатора — toast без API | ЗАКРЫТ | реальный verify-флоу claims (проверено ре-аудитом 15-09) |
| 10 | 2FA UI «Скоро» при готовом backend | ЗАКРЫТ | `settings-view.tsx:188, 266-308` — реальный enable QR/confirm/disable |
| 11 | HR «Отзывы кандидатов» — мёртвый блок | ЗАКРЫТ | блок заменён честным состоянием (ре-аудит 15-09) |
| 12 | Заглушка Next Best Actions | **ЗАКРЫТ (16-09)** | §1.2 + live `create_project` |
| 13 | Compare в Find-for-me «Скоро» | ЗАКРЫТ | honest-state паттерн (ре-аудит 15-09) |
| 14 | Спонсор: клик без перехода | ЗАКРЫТ | `app-shell.tsx:889-905` + `api/ads/route.ts:50,74-78` — window.open + allowlist |
| 15 | Session auth игнорирует deletedAt | ЗАКРЫТ | `auth.ts:178-183` — session.delete + 401 |
| 16 | withRoute 21/239 | **КРИТ. КЛАССЫ ЗАКРЫТЫ (16-09)** | §1.6: auth/money/PII/AI → withRoute; полный охват — остаток §6 |
| 17 | Прямые SDK-вызовы вне gateway | ЗАКРЫТ | SDK только `ai-core/llm-client.ts:34` и `ai-core/index.ts:145` |
| 18 | Governance-модели отсутствуют | ЗАКРЫТ | 9 моделей Ai* (`schema.prisma:1939-2074`) + Policy Engine + Decision Inbox |
| 19 | Тестов нет (tests = 3 shell) | ЗАКРЫТ | 79 тестов × 8 файлов, 5/5 стабильных прогонов |
| 20 | 11/32 plaintext email | ЗАКРЫТ | 0/35 plaintext; стабильный dev-ключ (root-cause фикс) |
| 21 | SSRF без DNS pinning | **ЧАСТИЧНО (честный остаток)** | allowlist + флаг OFF + двойное резолвление (TOCTOU сужен); полный pinning → egress-proxy (§6) |
| 22 | Rate limiter in-memory | ЗАКРЫТ | KV (Redis-swappable) + helm gate `instances=1` |
| 23 | Event bus in-process | **ЗАКРЫТ (16-09)** | §1.3: EventOutbox + emitDurable + drainOutbox |
| 24 | ACTIVE→COMPLETED auto-confirmed | ЗАКРЫТ | `transition/route.ts:78-83` — честный warning; verified только через EvidenceService |
| 25 | Нет AI response cache | ЗАКРЫТ | `gateway.ts:54-72` — TTL + версия политики в ключе; кэш только LLM-результатов |
| 26 | Capital trend честно null | ЗАКРЫТ | честный СТАБ задокументирован в каталоге (§5 п.8) |
| 27 | Счётчик профиля ≠ drill-down | ЗАКРЫТ* | код-доказательства есть; runtime-прогон drill-down не выполнялся (§6) |
| 28 | DOC-MISMATCH: SDK refs 15 vs 12 | ЗАКРЫТ | docs синхронизированы с фактом |
| 29 | CSP с preview/localhost в prod | ЗАКРЫТ | `next.config.ts:1-31` — env-split, prod `frame-ancestors 'self'` |
| 30 | Runtime build не подтверждён | **ЧАСТИЧНО (вне песочницы)** | локальный build запрещён; CI-джоба `ci.yml:53-54` (§6) |

Итого: **26 ЗАКРЫТ / 4 документированных остатка** (16-полный охват, 21, 27-runtime, 30).

---

## 4. SECURITY GATES 7.1 (из отчёта GPT)

| Гейт | Требование GPT | Статус | Доказательство |
|---|---|---|---|
| C1 | plaintext email → 0 | ✅ | 0/35 пользователей (проверка БД ре-аудитом) |
| C4 | SSRF DNS pinning → закрыть | ⚠️ частично | см. DEF-21 и §6 (egress-proxy) |
| C5 | bearer token не в localStorage | ✅ | `app-store.ts:339` — partialize только view-state |
| H6 | CORS whitelist | ✅ | `middleware.ts:23-40` + runtime-проверка |
| H9 | .env не в git index | ✅ | gitignore + фильтры архива; CI-проверка |
| H10 | demo auth → env gate | ✅ | `BIZON_DEMO_AUTH` в `middleware.ts:85-87` |
| H11 | rate limit на mutation | ✅ **(закрыт 16-09)** | §1.4 + live 30×200+5×429 |
| H13 | PII inventory | ✅ **(закрыт 16-09)** | §1.5: MUST-AUDIT 10/10 |
| CSP | убрать preview/localhost из prod | ✅ | DEF-29 env-split |

---

## 5. REC-* (рекомендации GPT)

| REC | Статус | Комментарий |
|---|---|---|
| REC-GOV-01..07 | ✅ | Governance-слой: Authority/Policy/Action/Approval/Audit/Budget/Incident, kill-switch в gateway (тест W3), Decision Inbox |
| REC-PROJECT-01..03 | ✅ | Evidence Engine: ProjectConfirmation, завершение ≠ верификация |
| REC-TRUTH-01..02 | ✅ | null-честность scores, без Math.random |
| REC-SEC-01 | ✅ | deletedAt во всех путях сессий |
| REC-TEST-01 | ✅ | 79 тестов в CI (blocking job `bun test tests/` в ci.yml:71-92) |
| REC-DOC-01 | ✅ | каталог-гейт автоматизирован (`scripts/check-audit-catalog.mjs` в CI) |
| REC-SSRF-01 | ⚠️ остаток | см. §6 |
| REC-ARCH-01 | ⚠️ поэтапно | критичные классы закрыты; полный охват 252 — «при касании» |

---

## 6. ЧЕСТНЫЕ ОСТАТКИ (что НЕ закрыто и почему)

1. **DEF-30 (полный production build).** В песочнице разработки `next build` запрещён политикой среды — выполнение недоказуемо локально. Компенсирующий контроль: CI-джоба `.github/workflows/ci.yml` (шаги: lint → tsc → каталог-гейт → **`npm run build`** → blocking `bun test`). Пункт закрывается первым зелёным прогоном CI вне песочницы.
2. **DEF-21 / C4 (полный DNS/IP-pinning).** Текущее состояние: external fetch выключен флагом `BIZON_EXTERNAL_FETCH_ENABLED` (OFF по умолчанию), allowlist хостов, двойное DNS-резолвление сужает TOCTOU. Полный pinning (connect к резолвнутому IP с SNI) требует egress-proxy — путь, рекомендованный самим отчётом GPT для scaling; до включения external fetch в проде риск остаётся заблокированным флагом.
3. **DEF-16 / REC-ARCH-01 (withRoute на все 252 роута).** Критичные классы (auth, 2FA, money, AI-мутации, необратимые PII) закрыты (§1.6); 241/252 роутов имеют единый errorJson-маппинг. Остальные read-роуты мигрируются «при касании» по предписанному GPT порядку — массовая механическая перезапись 252 файлов одним коммитом была бы риском регрессий без пользы для аудита критичных поверхностей.
4. **DEF-27 (runtime-прогон drill-down).** Код-доказательства соответствия счётчика и drill-down присутствуют; отдельный runtime-прогон сценария не выполнялся (низкий приоритет P2).

---

## 7. КАК ВЕРИФИЦИРОВАТЬ (команды из корня архива)

```bash
bun install                          # зависимости
bunx prisma generate                 # клиент Prisma
bun test tests/                      # 79/79 (изолированная копия БД, 5 прогонов подряд для стабильности)
npx tsc --noEmit                     # 0 ошибок
bun run lint                         # 0 ошибок
node scripts/check-audit-catalog.mjs # «OK: 90 моделей, 252 роутов — соответствует снапшоту»
node scripts/pii-inventory.mjs       # «MUST-AUDIT 10, без AuditLog: 0 → OK»

# Live-проверки (после bun run dev):
#   H11: 35× GET /api/lumens с валидной сессией → 30×200 + 5×429
#   DEF-12: GET /api/me/next-best-action → реальное действие (create_project для нового профиля)
#   DEF-23: завершение проекта → строка в EventOutbox (status=published)
```

Журнал работ с полными логами каждой волны: `worklog.md` (append-only) — секции `re-audit-14-09-check`, `w2.5-close-partials`, `w2.5-verify-and-stabilize`.
